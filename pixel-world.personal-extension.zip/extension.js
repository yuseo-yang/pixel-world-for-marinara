/* Pixel World for Marinara - bundled (three.js MIT). Source: https://github.com/yuseo-yang/pixel-world-for-marinara */
(()=>{var Ji={LEFT:0,MIDDLE:1,RIGHT:2,ROTATE:0,DOLLY:1,PAN:2},ji={ROTATE:0,PAN:1,DOLLY_PAN:2,DOLLY_ROTATE:3},Nu=0,cc=1,Ou=2;var zh=1,wl=2,ni=3,Mi=0,sn=1,Dn=2;var Yn=0,si=1,Rs=2,hc=3,uc=4,Fu=5,ki=100,Bu=101,zu=102,dc=103,fc=104,ku=200,Hu=201,Vu=202,Gu=203,Vo=204,Go=205,Wu=206,Xu=207,Yu=208,qu=209,Zu=210,Ju=211,ju=212,$u=213,Ku=214,Qu=0,td=1,ed=2,aa=3,nd=4,id=5,sd=6,rd=7,kh=0,ad=1,od=2,yi=0,El=1,Tl=2,Al=3,Sr=4,ld=5,Cl=6;var Hh=300,Ps=301,Ls=302,Wo=303,Xo=304,Fa=306,hr=1e3,Un=1001,Yo=1002,qe=1003,pc=1004;var ho=1005;var bn=1006,cd=1007;var ur=1008;var bi=1009,hd=1010,ud=1011,Rl=1012,Vh=1013,xi=1014,_i=1015,gn=1016,Gh=1017,Wh=1018,Vi=1020,dd=1021,Nn=1023,fd=1024,pd=1025,Gi=1026,Is=1027,md=1028,Xh=1029,gd=1030,Yh=1031,qh=1033,uo=33776,fo=33777,po=33778,mo=33779,mc=35840,gc=35841,xc=35842,_c=35843,Zh=36196,vc=37492,yc=37496,bc=37808,Mc=37809,Sc=37810,wc=37811,Ec=37812,Tc=37813,Ac=37814,Cc=37815,Rc=37816,Pc=37817,Lc=37818,Ic=37819,Dc=37820,Uc=37821,go=36492,Nc=36494,Oc=36495,xd=36283,Fc=36284,Bc=36285,zc=36286;var oa=2300,la=2301,xo=2302,kc=2400,Hc=2401,Vc=2402;var Jh=3e3,Wi=3001,_d=3200,vd=3201,jh=0,yd=1,Mn="",Ce="srgb",ri="srgb-linear",Pl="display-p3",Ba="display-p3-linear",ca="linear",xe="srgb",ha="rec709",ua="p3";var as=7680;var Gc=519,bd=512,Md=513,Sd=514,$h=515,wd=516,Ed=517,Td=518,Ad=519,Wc=35044;var Xc="300 es",qo=1035,ii=2e3,da=2001,qn=class{addEventListener(t,e){this._listeners===void 0&&(this._listeners={});let n=this._listeners;n[t]===void 0&&(n[t]=[]),n[t].indexOf(e)===-1&&n[t].push(e)}hasEventListener(t,e){if(this._listeners===void 0)return!1;let n=this._listeners;return n[t]!==void 0&&n[t].indexOf(e)!==-1}removeEventListener(t,e){if(this._listeners===void 0)return;let s=this._listeners[t];if(s!==void 0){let r=s.indexOf(e);r!==-1&&s.splice(r,1)}}dispatchEvent(t){if(this._listeners===void 0)return;let n=this._listeners[t.type];if(n!==void 0){t.target=this;let s=n.slice(0);for(let r=0,o=s.length;r<o;r++)s[r].call(this,t);t.target=null}}},Qe=["00","01","02","03","04","05","06","07","08","09","0a","0b","0c","0d","0e","0f","10","11","12","13","14","15","16","17","18","19","1a","1b","1c","1d","1e","1f","20","21","22","23","24","25","26","27","28","29","2a","2b","2c","2d","2e","2f","30","31","32","33","34","35","36","37","38","39","3a","3b","3c","3d","3e","3f","40","41","42","43","44","45","46","47","48","49","4a","4b","4c","4d","4e","4f","50","51","52","53","54","55","56","57","58","59","5a","5b","5c","5d","5e","5f","60","61","62","63","64","65","66","67","68","69","6a","6b","6c","6d","6e","6f","70","71","72","73","74","75","76","77","78","79","7a","7b","7c","7d","7e","7f","80","81","82","83","84","85","86","87","88","89","8a","8b","8c","8d","8e","8f","90","91","92","93","94","95","96","97","98","99","9a","9b","9c","9d","9e","9f","a0","a1","a2","a3","a4","a5","a6","a7","a8","a9","aa","ab","ac","ad","ae","af","b0","b1","b2","b3","b4","b5","b6","b7","b8","b9","ba","bb","bc","bd","be","bf","c0","c1","c2","c3","c4","c5","c6","c7","c8","c9","ca","cb","cc","cd","ce","cf","d0","d1","d2","d3","d4","d5","d6","d7","d8","d9","da","db","dc","dd","de","df","e0","e1","e2","e3","e4","e5","e6","e7","e8","e9","ea","eb","ec","ed","ee","ef","f0","f1","f2","f3","f4","f5","f6","f7","f8","f9","fa","fb","fc","fd","fe","ff"],Yc=1234567,ar=Math.PI/180,dr=180/Math.PI;function Bs(){let i=Math.random()*4294967295|0,t=Math.random()*4294967295|0,e=Math.random()*4294967295|0,n=Math.random()*4294967295|0;return(Qe[i&255]+Qe[i>>8&255]+Qe[i>>16&255]+Qe[i>>24&255]+"-"+Qe[t&255]+Qe[t>>8&255]+"-"+Qe[t>>16&15|64]+Qe[t>>24&255]+"-"+Qe[e&63|128]+Qe[e>>8&255]+"-"+Qe[e>>16&255]+Qe[e>>24&255]+Qe[n&255]+Qe[n>>8&255]+Qe[n>>16&255]+Qe[n>>24&255]).toLowerCase()}function en(i,t,e){return Math.max(t,Math.min(e,i))}function Ll(i,t){return(i%t+t)%t}function Cd(i,t,e,n,s){return n+(i-t)*(s-n)/(e-t)}function Rd(i,t,e){return i!==t?(e-i)/(t-i):0}function or(i,t,e){return(1-e)*i+e*t}function Pd(i,t,e,n){return or(i,t,1-Math.exp(-e*n))}function Ld(i,t=1){return t-Math.abs(Ll(i,t*2)-t)}function Id(i,t,e){return i<=t?0:i>=e?1:(i=(i-t)/(e-t),i*i*(3-2*i))}function Dd(i,t,e){return i<=t?0:i>=e?1:(i=(i-t)/(e-t),i*i*i*(i*(i*6-15)+10))}function Ud(i,t){return i+Math.floor(Math.random()*(t-i+1))}function Nd(i,t){return i+Math.random()*(t-i)}function Od(i){return i*(.5-Math.random())}function Fd(i){i!==void 0&&(Yc=i);let t=Yc+=1831565813;return t=Math.imul(t^t>>>15,t|1),t^=t+Math.imul(t^t>>>7,t|61),((t^t>>>14)>>>0)/4294967296}function Bd(i){return i*ar}function zd(i){return i*dr}function Zo(i){return(i&i-1)===0&&i!==0}function kd(i){return Math.pow(2,Math.ceil(Math.log(i)/Math.LN2))}function fa(i){return Math.pow(2,Math.floor(Math.log(i)/Math.LN2))}function Hd(i,t,e,n,s){let r=Math.cos,o=Math.sin,a=r(e/2),l=o(e/2),c=r((t+n)/2),u=o((t+n)/2),f=r((t-n)/2),p=o((t-n)/2),x=r((n-t)/2),y=o((n-t)/2);switch(s){case"XYX":i.set(a*u,l*f,l*p,a*c);break;case"YZY":i.set(l*p,a*u,l*f,a*c);break;case"ZXZ":i.set(l*f,l*p,a*u,a*c);break;case"XZX":i.set(a*u,l*y,l*x,a*c);break;case"YXY":i.set(l*x,a*u,l*y,a*c);break;case"ZYZ":i.set(l*y,l*x,a*u,a*c);break;default:console.warn("THREE.MathUtils: .setQuaternionFromProperEuler() encountered an unknown order: "+s)}}function Ss(i,t){switch(t.constructor){case Float32Array:return i;case Uint32Array:return i/4294967295;case Uint16Array:return i/65535;case Uint8Array:return i/255;case Int32Array:return Math.max(i/2147483647,-1);case Int16Array:return Math.max(i/32767,-1);case Int8Array:return Math.max(i/127,-1);default:throw new Error("Invalid component type.")}}function ln(i,t){switch(t.constructor){case Float32Array:return i;case Uint32Array:return Math.round(i*4294967295);case Uint16Array:return Math.round(i*65535);case Uint8Array:return Math.round(i*255);case Int32Array:return Math.round(i*2147483647);case Int16Array:return Math.round(i*32767);case Int8Array:return Math.round(i*127);default:throw new Error("Invalid component type.")}}var Kh={DEG2RAD:ar,RAD2DEG:dr,generateUUID:Bs,clamp:en,euclideanModulo:Ll,mapLinear:Cd,inverseLerp:Rd,lerp:or,damp:Pd,pingpong:Ld,smoothstep:Id,smootherstep:Dd,randInt:Ud,randFloat:Nd,randFloatSpread:Od,seededRandom:Fd,degToRad:Bd,radToDeg:zd,isPowerOfTwo:Zo,ceilPowerOfTwo:kd,floorPowerOfTwo:fa,setQuaternionFromProperEuler:Hd,normalize:ln,denormalize:Ss},Lt=class i{constructor(t=0,e=0){i.prototype.isVector2=!0,this.x=t,this.y=e}get width(){return this.x}set width(t){this.x=t}get height(){return this.y}set height(t){this.y=t}set(t,e){return this.x=t,this.y=e,this}setScalar(t){return this.x=t,this.y=t,this}setX(t){return this.x=t,this}setY(t){return this.y=t,this}setComponent(t,e){switch(t){case 0:this.x=e;break;case 1:this.y=e;break;default:throw new Error("index is out of range: "+t)}return this}getComponent(t){switch(t){case 0:return this.x;case 1:return this.y;default:throw new Error("index is out of range: "+t)}}clone(){return new this.constructor(this.x,this.y)}copy(t){return this.x=t.x,this.y=t.y,this}add(t){return this.x+=t.x,this.y+=t.y,this}addScalar(t){return this.x+=t,this.y+=t,this}addVectors(t,e){return this.x=t.x+e.x,this.y=t.y+e.y,this}addScaledVector(t,e){return this.x+=t.x*e,this.y+=t.y*e,this}sub(t){return this.x-=t.x,this.y-=t.y,this}subScalar(t){return this.x-=t,this.y-=t,this}subVectors(t,e){return this.x=t.x-e.x,this.y=t.y-e.y,this}multiply(t){return this.x*=t.x,this.y*=t.y,this}multiplyScalar(t){return this.x*=t,this.y*=t,this}divide(t){return this.x/=t.x,this.y/=t.y,this}divideScalar(t){return this.multiplyScalar(1/t)}applyMatrix3(t){let e=this.x,n=this.y,s=t.elements;return this.x=s[0]*e+s[3]*n+s[6],this.y=s[1]*e+s[4]*n+s[7],this}min(t){return this.x=Math.min(this.x,t.x),this.y=Math.min(this.y,t.y),this}max(t){return this.x=Math.max(this.x,t.x),this.y=Math.max(this.y,t.y),this}clamp(t,e){return this.x=Math.max(t.x,Math.min(e.x,this.x)),this.y=Math.max(t.y,Math.min(e.y,this.y)),this}clampScalar(t,e){return this.x=Math.max(t,Math.min(e,this.x)),this.y=Math.max(t,Math.min(e,this.y)),this}clampLength(t,e){let n=this.length();return this.divideScalar(n||1).multiplyScalar(Math.max(t,Math.min(e,n)))}floor(){return this.x=Math.floor(this.x),this.y=Math.floor(this.y),this}ceil(){return this.x=Math.ceil(this.x),this.y=Math.ceil(this.y),this}round(){return this.x=Math.round(this.x),this.y=Math.round(this.y),this}roundToZero(){return this.x=Math.trunc(this.x),this.y=Math.trunc(this.y),this}negate(){return this.x=-this.x,this.y=-this.y,this}dot(t){return this.x*t.x+this.y*t.y}cross(t){return this.x*t.y-this.y*t.x}lengthSq(){return this.x*this.x+this.y*this.y}length(){return Math.sqrt(this.x*this.x+this.y*this.y)}manhattanLength(){return Math.abs(this.x)+Math.abs(this.y)}normalize(){return this.divideScalar(this.length()||1)}angle(){return Math.atan2(-this.y,-this.x)+Math.PI}angleTo(t){let e=Math.sqrt(this.lengthSq()*t.lengthSq());if(e===0)return Math.PI/2;let n=this.dot(t)/e;return Math.acos(en(n,-1,1))}distanceTo(t){return Math.sqrt(this.distanceToSquared(t))}distanceToSquared(t){let e=this.x-t.x,n=this.y-t.y;return e*e+n*n}manhattanDistanceTo(t){return Math.abs(this.x-t.x)+Math.abs(this.y-t.y)}setLength(t){return this.normalize().multiplyScalar(t)}lerp(t,e){return this.x+=(t.x-this.x)*e,this.y+=(t.y-this.y)*e,this}lerpVectors(t,e,n){return this.x=t.x+(e.x-t.x)*n,this.y=t.y+(e.y-t.y)*n,this}equals(t){return t.x===this.x&&t.y===this.y}fromArray(t,e=0){return this.x=t[e],this.y=t[e+1],this}toArray(t=[],e=0){return t[e]=this.x,t[e+1]=this.y,t}fromBufferAttribute(t,e){return this.x=t.getX(e),this.y=t.getY(e),this}rotateAround(t,e){let n=Math.cos(e),s=Math.sin(e),r=this.x-t.x,o=this.y-t.y;return this.x=r*n-o*s+t.x,this.y=r*s+o*n+t.y,this}random(){return this.x=Math.random(),this.y=Math.random(),this}*[Symbol.iterator](){yield this.x,yield this.y}},oe=class i{constructor(t,e,n,s,r,o,a,l,c){i.prototype.isMatrix3=!0,this.elements=[1,0,0,0,1,0,0,0,1],t!==void 0&&this.set(t,e,n,s,r,o,a,l,c)}set(t,e,n,s,r,o,a,l,c){let u=this.elements;return u[0]=t,u[1]=s,u[2]=a,u[3]=e,u[4]=r,u[5]=l,u[6]=n,u[7]=o,u[8]=c,this}identity(){return this.set(1,0,0,0,1,0,0,0,1),this}copy(t){let e=this.elements,n=t.elements;return e[0]=n[0],e[1]=n[1],e[2]=n[2],e[3]=n[3],e[4]=n[4],e[5]=n[5],e[6]=n[6],e[7]=n[7],e[8]=n[8],this}extractBasis(t,e,n){return t.setFromMatrix3Column(this,0),e.setFromMatrix3Column(this,1),n.setFromMatrix3Column(this,2),this}setFromMatrix4(t){let e=t.elements;return this.set(e[0],e[4],e[8],e[1],e[5],e[9],e[2],e[6],e[10]),this}multiply(t){return this.multiplyMatrices(this,t)}premultiply(t){return this.multiplyMatrices(t,this)}multiplyMatrices(t,e){let n=t.elements,s=e.elements,r=this.elements,o=n[0],a=n[3],l=n[6],c=n[1],u=n[4],f=n[7],p=n[2],x=n[5],y=n[8],M=s[0],g=s[3],d=s[6],C=s[1],E=s[4],D=s[7],z=s[2],U=s[5],L=s[8];return r[0]=o*M+a*C+l*z,r[3]=o*g+a*E+l*U,r[6]=o*d+a*D+l*L,r[1]=c*M+u*C+f*z,r[4]=c*g+u*E+f*U,r[7]=c*d+u*D+f*L,r[2]=p*M+x*C+y*z,r[5]=p*g+x*E+y*U,r[8]=p*d+x*D+y*L,this}multiplyScalar(t){let e=this.elements;return e[0]*=t,e[3]*=t,e[6]*=t,e[1]*=t,e[4]*=t,e[7]*=t,e[2]*=t,e[5]*=t,e[8]*=t,this}determinant(){let t=this.elements,e=t[0],n=t[1],s=t[2],r=t[3],o=t[4],a=t[5],l=t[6],c=t[7],u=t[8];return e*o*u-e*a*c-n*r*u+n*a*l+s*r*c-s*o*l}invert(){let t=this.elements,e=t[0],n=t[1],s=t[2],r=t[3],o=t[4],a=t[5],l=t[6],c=t[7],u=t[8],f=u*o-a*c,p=a*l-u*r,x=c*r-o*l,y=e*f+n*p+s*x;if(y===0)return this.set(0,0,0,0,0,0,0,0,0);let M=1/y;return t[0]=f*M,t[1]=(s*c-u*n)*M,t[2]=(a*n-s*o)*M,t[3]=p*M,t[4]=(u*e-s*l)*M,t[5]=(s*r-a*e)*M,t[6]=x*M,t[7]=(n*l-c*e)*M,t[8]=(o*e-n*r)*M,this}transpose(){let t,e=this.elements;return t=e[1],e[1]=e[3],e[3]=t,t=e[2],e[2]=e[6],e[6]=t,t=e[5],e[5]=e[7],e[7]=t,this}getNormalMatrix(t){return this.setFromMatrix4(t).invert().transpose()}transposeIntoArray(t){let e=this.elements;return t[0]=e[0],t[1]=e[3],t[2]=e[6],t[3]=e[1],t[4]=e[4],t[5]=e[7],t[6]=e[2],t[7]=e[5],t[8]=e[8],this}setUvTransform(t,e,n,s,r,o,a){let l=Math.cos(r),c=Math.sin(r);return this.set(n*l,n*c,-n*(l*o+c*a)+o+t,-s*c,s*l,-s*(-c*o+l*a)+a+e,0,0,1),this}scale(t,e){return this.premultiply(_o.makeScale(t,e)),this}rotate(t){return this.premultiply(_o.makeRotation(-t)),this}translate(t,e){return this.premultiply(_o.makeTranslation(t,e)),this}makeTranslation(t,e){return t.isVector2?this.set(1,0,t.x,0,1,t.y,0,0,1):this.set(1,0,t,0,1,e,0,0,1),this}makeRotation(t){let e=Math.cos(t),n=Math.sin(t);return this.set(e,-n,0,n,e,0,0,0,1),this}makeScale(t,e){return this.set(t,0,0,0,e,0,0,0,1),this}equals(t){let e=this.elements,n=t.elements;for(let s=0;s<9;s++)if(e[s]!==n[s])return!1;return!0}fromArray(t,e=0){for(let n=0;n<9;n++)this.elements[n]=t[n+e];return this}toArray(t=[],e=0){let n=this.elements;return t[e]=n[0],t[e+1]=n[1],t[e+2]=n[2],t[e+3]=n[3],t[e+4]=n[4],t[e+5]=n[5],t[e+6]=n[6],t[e+7]=n[7],t[e+8]=n[8],t}clone(){return new this.constructor().fromArray(this.elements)}},_o=new oe;function Qh(i){for(let t=i.length-1;t>=0;--t)if(i[t]>=65535)return!0;return!1}function pa(i){return document.createElementNS("http://www.w3.org/1999/xhtml",i)}function Vd(){let i=pa("canvas");return i.style.display="block",i}var qc={};function lr(i){i in qc||(qc[i]=!0,console.warn(i))}var Zc=new oe().set(.8224621,.177538,0,.0331941,.9668058,0,.0170827,.0723974,.9105199),Jc=new oe().set(1.2249401,-.2249404,0,-.0420569,1.0420571,0,-.0196376,-.0786361,1.0982735),Ur={[ri]:{transfer:ca,primaries:ha,toReference:i=>i,fromReference:i=>i},[Ce]:{transfer:xe,primaries:ha,toReference:i=>i.convertSRGBToLinear(),fromReference:i=>i.convertLinearToSRGB()},[Ba]:{transfer:ca,primaries:ua,toReference:i=>i.applyMatrix3(Jc),fromReference:i=>i.applyMatrix3(Zc)},[Pl]:{transfer:xe,primaries:ua,toReference:i=>i.convertSRGBToLinear().applyMatrix3(Jc),fromReference:i=>i.applyMatrix3(Zc).convertLinearToSRGB()}},Gd=new Set([ri,Ba]),fe={enabled:!0,_workingColorSpace:ri,get workingColorSpace(){return this._workingColorSpace},set workingColorSpace(i){if(!Gd.has(i))throw new Error(`Unsupported working color space, "${i}".`);this._workingColorSpace=i},convert:function(i,t,e){if(this.enabled===!1||t===e||!t||!e)return i;let n=Ur[t].toReference,s=Ur[e].fromReference;return s(n(i))},fromWorkingColorSpace:function(i,t){return this.convert(i,this._workingColorSpace,t)},toWorkingColorSpace:function(i,t){return this.convert(i,t,this._workingColorSpace)},getPrimaries:function(i){return Ur[i].primaries},getTransfer:function(i){return i===Mn?ca:Ur[i].transfer}};function As(i){return i<.04045?i*.0773993808:Math.pow(i*.9478672986+.0521327014,2.4)}function vo(i){return i<.0031308?i*12.92:1.055*Math.pow(i,.41666)-.055}var os,ma=class{static getDataURL(t){if(/^data:/i.test(t.src)||typeof HTMLCanvasElement>"u")return t.src;let e;if(t instanceof HTMLCanvasElement)e=t;else{os===void 0&&(os=pa("canvas")),os.width=t.width,os.height=t.height;let n=os.getContext("2d");t instanceof ImageData?n.putImageData(t,0,0):n.drawImage(t,0,0,t.width,t.height),e=os}return e.width>2048||e.height>2048?(console.warn("THREE.ImageUtils.getDataURL: Image converted to jpg for performance reasons",t),e.toDataURL("image/jpeg",.6)):e.toDataURL("image/png")}static sRGBToLinear(t){if(typeof HTMLImageElement<"u"&&t instanceof HTMLImageElement||typeof HTMLCanvasElement<"u"&&t instanceof HTMLCanvasElement||typeof ImageBitmap<"u"&&t instanceof ImageBitmap){let e=pa("canvas");e.width=t.width,e.height=t.height;let n=e.getContext("2d");n.drawImage(t,0,0,t.width,t.height);let s=n.getImageData(0,0,t.width,t.height),r=s.data;for(let o=0;o<r.length;o++)r[o]=As(r[o]/255)*255;return n.putImageData(s,0,0),e}else if(t.data){let e=t.data.slice(0);for(let n=0;n<e.length;n++)e instanceof Uint8Array||e instanceof Uint8ClampedArray?e[n]=Math.floor(As(e[n]/255)*255):e[n]=As(e[n]);return{data:e,width:t.width,height:t.height}}else return console.warn("THREE.ImageUtils.sRGBToLinear(): Unsupported image type. No color space conversion applied."),t}},Wd=0,ga=class{constructor(t=null){this.isSource=!0,Object.defineProperty(this,"id",{value:Wd++}),this.uuid=Bs(),this.data=t,this.version=0}set needsUpdate(t){t===!0&&this.version++}toJSON(t){let e=t===void 0||typeof t=="string";if(!e&&t.images[this.uuid]!==void 0)return t.images[this.uuid];let n={uuid:this.uuid,url:""},s=this.data;if(s!==null){let r;if(Array.isArray(s)){r=[];for(let o=0,a=s.length;o<a;o++)s[o].isDataTexture?r.push(yo(s[o].image)):r.push(yo(s[o]))}else r=yo(s);n.url=r}return e||(t.images[this.uuid]=n),n}};function yo(i){return typeof HTMLImageElement<"u"&&i instanceof HTMLImageElement||typeof HTMLCanvasElement<"u"&&i instanceof HTMLCanvasElement||typeof ImageBitmap<"u"&&i instanceof ImageBitmap?ma.getDataURL(i):i.data?{data:Array.from(i.data),width:i.width,height:i.height,type:i.data.constructor.name}:(console.warn("THREE.Texture: Unable to serialize Texture."),{})}var Xd=0,Sn=class i extends qn{constructor(t=i.DEFAULT_IMAGE,e=i.DEFAULT_MAPPING,n=Un,s=Un,r=bn,o=ur,a=Nn,l=bi,c=i.DEFAULT_ANISOTROPY,u=Mn){super(),this.isTexture=!0,Object.defineProperty(this,"id",{value:Xd++}),this.uuid=Bs(),this.name="",this.source=new ga(t),this.mipmaps=[],this.mapping=e,this.channel=0,this.wrapS=n,this.wrapT=s,this.magFilter=r,this.minFilter=o,this.anisotropy=c,this.format=a,this.internalFormat=null,this.type=l,this.offset=new Lt(0,0),this.repeat=new Lt(1,1),this.center=new Lt(0,0),this.rotation=0,this.matrixAutoUpdate=!0,this.matrix=new oe,this.generateMipmaps=!0,this.premultiplyAlpha=!1,this.flipY=!0,this.unpackAlignment=4,typeof u=="string"?this.colorSpace=u:(lr("THREE.Texture: Property .encoding has been replaced by .colorSpace."),this.colorSpace=u===Wi?Ce:Mn),this.userData={},this.version=0,this.onUpdate=null,this.isRenderTargetTexture=!1,this.needsPMREMUpdate=!1}get image(){return this.source.data}set image(t=null){this.source.data=t}updateMatrix(){this.matrix.setUvTransform(this.offset.x,this.offset.y,this.repeat.x,this.repeat.y,this.rotation,this.center.x,this.center.y)}clone(){return new this.constructor().copy(this)}copy(t){return this.name=t.name,this.source=t.source,this.mipmaps=t.mipmaps.slice(0),this.mapping=t.mapping,this.channel=t.channel,this.wrapS=t.wrapS,this.wrapT=t.wrapT,this.magFilter=t.magFilter,this.minFilter=t.minFilter,this.anisotropy=t.anisotropy,this.format=t.format,this.internalFormat=t.internalFormat,this.type=t.type,this.offset.copy(t.offset),this.repeat.copy(t.repeat),this.center.copy(t.center),this.rotation=t.rotation,this.matrixAutoUpdate=t.matrixAutoUpdate,this.matrix.copy(t.matrix),this.generateMipmaps=t.generateMipmaps,this.premultiplyAlpha=t.premultiplyAlpha,this.flipY=t.flipY,this.unpackAlignment=t.unpackAlignment,this.colorSpace=t.colorSpace,this.userData=JSON.parse(JSON.stringify(t.userData)),this.needsUpdate=!0,this}toJSON(t){let e=t===void 0||typeof t=="string";if(!e&&t.textures[this.uuid]!==void 0)return t.textures[this.uuid];let n={metadata:{version:4.6,type:"Texture",generator:"Texture.toJSON"},uuid:this.uuid,name:this.name,image:this.source.toJSON(t).uuid,mapping:this.mapping,channel:this.channel,repeat:[this.repeat.x,this.repeat.y],offset:[this.offset.x,this.offset.y],center:[this.center.x,this.center.y],rotation:this.rotation,wrap:[this.wrapS,this.wrapT],format:this.format,internalFormat:this.internalFormat,type:this.type,colorSpace:this.colorSpace,minFilter:this.minFilter,magFilter:this.magFilter,anisotropy:this.anisotropy,flipY:this.flipY,generateMipmaps:this.generateMipmaps,premultiplyAlpha:this.premultiplyAlpha,unpackAlignment:this.unpackAlignment};return Object.keys(this.userData).length>0&&(n.userData=this.userData),e||(t.textures[this.uuid]=n),n}dispose(){this.dispatchEvent({type:"dispose"})}transformUv(t){if(this.mapping!==Hh)return t;if(t.applyMatrix3(this.matrix),t.x<0||t.x>1)switch(this.wrapS){case hr:t.x=t.x-Math.floor(t.x);break;case Un:t.x=t.x<0?0:1;break;case Yo:Math.abs(Math.floor(t.x)%2)===1?t.x=Math.ceil(t.x)-t.x:t.x=t.x-Math.floor(t.x);break}if(t.y<0||t.y>1)switch(this.wrapT){case hr:t.y=t.y-Math.floor(t.y);break;case Un:t.y=t.y<0?0:1;break;case Yo:Math.abs(Math.floor(t.y)%2)===1?t.y=Math.ceil(t.y)-t.y:t.y=t.y-Math.floor(t.y);break}return this.flipY&&(t.y=1-t.y),t}set needsUpdate(t){t===!0&&(this.version++,this.source.needsUpdate=!0)}get encoding(){return lr("THREE.Texture: Property .encoding has been replaced by .colorSpace."),this.colorSpace===Ce?Wi:Jh}set encoding(t){lr("THREE.Texture: Property .encoding has been replaced by .colorSpace."),this.colorSpace=t===Wi?Ce:Mn}};Sn.DEFAULT_IMAGE=null;Sn.DEFAULT_MAPPING=Hh;Sn.DEFAULT_ANISOTROPY=1;var Ee=class i{constructor(t=0,e=0,n=0,s=1){i.prototype.isVector4=!0,this.x=t,this.y=e,this.z=n,this.w=s}get width(){return this.z}set width(t){this.z=t}get height(){return this.w}set height(t){this.w=t}set(t,e,n,s){return this.x=t,this.y=e,this.z=n,this.w=s,this}setScalar(t){return this.x=t,this.y=t,this.z=t,this.w=t,this}setX(t){return this.x=t,this}setY(t){return this.y=t,this}setZ(t){return this.z=t,this}setW(t){return this.w=t,this}setComponent(t,e){switch(t){case 0:this.x=e;break;case 1:this.y=e;break;case 2:this.z=e;break;case 3:this.w=e;break;default:throw new Error("index is out of range: "+t)}return this}getComponent(t){switch(t){case 0:return this.x;case 1:return this.y;case 2:return this.z;case 3:return this.w;default:throw new Error("index is out of range: "+t)}}clone(){return new this.constructor(this.x,this.y,this.z,this.w)}copy(t){return this.x=t.x,this.y=t.y,this.z=t.z,this.w=t.w!==void 0?t.w:1,this}add(t){return this.x+=t.x,this.y+=t.y,this.z+=t.z,this.w+=t.w,this}addScalar(t){return this.x+=t,this.y+=t,this.z+=t,this.w+=t,this}addVectors(t,e){return this.x=t.x+e.x,this.y=t.y+e.y,this.z=t.z+e.z,this.w=t.w+e.w,this}addScaledVector(t,e){return this.x+=t.x*e,this.y+=t.y*e,this.z+=t.z*e,this.w+=t.w*e,this}sub(t){return this.x-=t.x,this.y-=t.y,this.z-=t.z,this.w-=t.w,this}subScalar(t){return this.x-=t,this.y-=t,this.z-=t,this.w-=t,this}subVectors(t,e){return this.x=t.x-e.x,this.y=t.y-e.y,this.z=t.z-e.z,this.w=t.w-e.w,this}multiply(t){return this.x*=t.x,this.y*=t.y,this.z*=t.z,this.w*=t.w,this}multiplyScalar(t){return this.x*=t,this.y*=t,this.z*=t,this.w*=t,this}applyMatrix4(t){let e=this.x,n=this.y,s=this.z,r=this.w,o=t.elements;return this.x=o[0]*e+o[4]*n+o[8]*s+o[12]*r,this.y=o[1]*e+o[5]*n+o[9]*s+o[13]*r,this.z=o[2]*e+o[6]*n+o[10]*s+o[14]*r,this.w=o[3]*e+o[7]*n+o[11]*s+o[15]*r,this}divideScalar(t){return this.multiplyScalar(1/t)}setAxisAngleFromQuaternion(t){this.w=2*Math.acos(t.w);let e=Math.sqrt(1-t.w*t.w);return e<1e-4?(this.x=1,this.y=0,this.z=0):(this.x=t.x/e,this.y=t.y/e,this.z=t.z/e),this}setAxisAngleFromRotationMatrix(t){let e,n,s,r,l=t.elements,c=l[0],u=l[4],f=l[8],p=l[1],x=l[5],y=l[9],M=l[2],g=l[6],d=l[10];if(Math.abs(u-p)<.01&&Math.abs(f-M)<.01&&Math.abs(y-g)<.01){if(Math.abs(u+p)<.1&&Math.abs(f+M)<.1&&Math.abs(y+g)<.1&&Math.abs(c+x+d-3)<.1)return this.set(1,0,0,0),this;e=Math.PI;let E=(c+1)/2,D=(x+1)/2,z=(d+1)/2,U=(u+p)/4,L=(f+M)/4,Q=(y+g)/4;return E>D&&E>z?E<.01?(n=0,s=.707106781,r=.707106781):(n=Math.sqrt(E),s=U/n,r=L/n):D>z?D<.01?(n=.707106781,s=0,r=.707106781):(s=Math.sqrt(D),n=U/s,r=Q/s):z<.01?(n=.707106781,s=.707106781,r=0):(r=Math.sqrt(z),n=L/r,s=Q/r),this.set(n,s,r,e),this}let C=Math.sqrt((g-y)*(g-y)+(f-M)*(f-M)+(p-u)*(p-u));return Math.abs(C)<.001&&(C=1),this.x=(g-y)/C,this.y=(f-M)/C,this.z=(p-u)/C,this.w=Math.acos((c+x+d-1)/2),this}min(t){return this.x=Math.min(this.x,t.x),this.y=Math.min(this.y,t.y),this.z=Math.min(this.z,t.z),this.w=Math.min(this.w,t.w),this}max(t){return this.x=Math.max(this.x,t.x),this.y=Math.max(this.y,t.y),this.z=Math.max(this.z,t.z),this.w=Math.max(this.w,t.w),this}clamp(t,e){return this.x=Math.max(t.x,Math.min(e.x,this.x)),this.y=Math.max(t.y,Math.min(e.y,this.y)),this.z=Math.max(t.z,Math.min(e.z,this.z)),this.w=Math.max(t.w,Math.min(e.w,this.w)),this}clampScalar(t,e){return this.x=Math.max(t,Math.min(e,this.x)),this.y=Math.max(t,Math.min(e,this.y)),this.z=Math.max(t,Math.min(e,this.z)),this.w=Math.max(t,Math.min(e,this.w)),this}clampLength(t,e){let n=this.length();return this.divideScalar(n||1).multiplyScalar(Math.max(t,Math.min(e,n)))}floor(){return this.x=Math.floor(this.x),this.y=Math.floor(this.y),this.z=Math.floor(this.z),this.w=Math.floor(this.w),this}ceil(){return this.x=Math.ceil(this.x),this.y=Math.ceil(this.y),this.z=Math.ceil(this.z),this.w=Math.ceil(this.w),this}round(){return this.x=Math.round(this.x),this.y=Math.round(this.y),this.z=Math.round(this.z),this.w=Math.round(this.w),this}roundToZero(){return this.x=Math.trunc(this.x),this.y=Math.trunc(this.y),this.z=Math.trunc(this.z),this.w=Math.trunc(this.w),this}negate(){return this.x=-this.x,this.y=-this.y,this.z=-this.z,this.w=-this.w,this}dot(t){return this.x*t.x+this.y*t.y+this.z*t.z+this.w*t.w}lengthSq(){return this.x*this.x+this.y*this.y+this.z*this.z+this.w*this.w}length(){return Math.sqrt(this.x*this.x+this.y*this.y+this.z*this.z+this.w*this.w)}manhattanLength(){return Math.abs(this.x)+Math.abs(this.y)+Math.abs(this.z)+Math.abs(this.w)}normalize(){return this.divideScalar(this.length()||1)}setLength(t){return this.normalize().multiplyScalar(t)}lerp(t,e){return this.x+=(t.x-this.x)*e,this.y+=(t.y-this.y)*e,this.z+=(t.z-this.z)*e,this.w+=(t.w-this.w)*e,this}lerpVectors(t,e,n){return this.x=t.x+(e.x-t.x)*n,this.y=t.y+(e.y-t.y)*n,this.z=t.z+(e.z-t.z)*n,this.w=t.w+(e.w-t.w)*n,this}equals(t){return t.x===this.x&&t.y===this.y&&t.z===this.z&&t.w===this.w}fromArray(t,e=0){return this.x=t[e],this.y=t[e+1],this.z=t[e+2],this.w=t[e+3],this}toArray(t=[],e=0){return t[e]=this.x,t[e+1]=this.y,t[e+2]=this.z,t[e+3]=this.w,t}fromBufferAttribute(t,e){return this.x=t.getX(e),this.y=t.getY(e),this.z=t.getZ(e),this.w=t.getW(e),this}random(){return this.x=Math.random(),this.y=Math.random(),this.z=Math.random(),this.w=Math.random(),this}*[Symbol.iterator](){yield this.x,yield this.y,yield this.z,yield this.w}},Jo=class extends qn{constructor(t=1,e=1,n={}){super(),this.isRenderTarget=!0,this.width=t,this.height=e,this.depth=1,this.scissor=new Ee(0,0,t,e),this.scissorTest=!1,this.viewport=new Ee(0,0,t,e);let s={width:t,height:e,depth:1};n.encoding!==void 0&&(lr("THREE.WebGLRenderTarget: option.encoding has been replaced by option.colorSpace."),n.colorSpace=n.encoding===Wi?Ce:Mn),n=Object.assign({generateMipmaps:!1,internalFormat:null,minFilter:bn,depthBuffer:!0,stencilBuffer:!1,depthTexture:null,samples:0},n),this.texture=new Sn(s,n.mapping,n.wrapS,n.wrapT,n.magFilter,n.minFilter,n.format,n.type,n.anisotropy,n.colorSpace),this.texture.isRenderTargetTexture=!0,this.texture.flipY=!1,this.texture.generateMipmaps=n.generateMipmaps,this.texture.internalFormat=n.internalFormat,this.depthBuffer=n.depthBuffer,this.stencilBuffer=n.stencilBuffer,this.depthTexture=n.depthTexture,this.samples=n.samples}setSize(t,e,n=1){(this.width!==t||this.height!==e||this.depth!==n)&&(this.width=t,this.height=e,this.depth=n,this.texture.image.width=t,this.texture.image.height=e,this.texture.image.depth=n,this.dispose()),this.viewport.set(0,0,t,e),this.scissor.set(0,0,t,e)}clone(){return new this.constructor().copy(this)}copy(t){this.width=t.width,this.height=t.height,this.depth=t.depth,this.scissor.copy(t.scissor),this.scissorTest=t.scissorTest,this.viewport.copy(t.viewport),this.texture=t.texture.clone(),this.texture.isRenderTargetTexture=!0;let e=Object.assign({},t.texture.image);return this.texture.source=new ga(e),this.depthBuffer=t.depthBuffer,this.stencilBuffer=t.stencilBuffer,t.depthTexture!==null&&(this.depthTexture=t.depthTexture.clone()),this.samples=t.samples,this}dispose(){this.dispatchEvent({type:"dispose"})}},Ke=class extends Jo{constructor(t=1,e=1,n={}){super(t,e,n),this.isWebGLRenderTarget=!0}},xa=class extends Sn{constructor(t=null,e=1,n=1,s=1){super(null),this.isDataArrayTexture=!0,this.image={data:t,width:e,height:n,depth:s},this.magFilter=qe,this.minFilter=qe,this.wrapR=Un,this.generateMipmaps=!1,this.flipY=!1,this.unpackAlignment=1}};var jo=class extends Sn{constructor(t=null,e=1,n=1,s=1){super(null),this.isData3DTexture=!0,this.image={data:t,width:e,height:n,depth:s},this.magFilter=qe,this.minFilter=qe,this.wrapR=Un,this.generateMipmaps=!1,this.flipY=!1,this.unpackAlignment=1}};var On=class{constructor(t=0,e=0,n=0,s=1){this.isQuaternion=!0,this._x=t,this._y=e,this._z=n,this._w=s}static slerpFlat(t,e,n,s,r,o,a){let l=n[s+0],c=n[s+1],u=n[s+2],f=n[s+3],p=r[o+0],x=r[o+1],y=r[o+2],M=r[o+3];if(a===0){t[e+0]=l,t[e+1]=c,t[e+2]=u,t[e+3]=f;return}if(a===1){t[e+0]=p,t[e+1]=x,t[e+2]=y,t[e+3]=M;return}if(f!==M||l!==p||c!==x||u!==y){let g=1-a,d=l*p+c*x+u*y+f*M,C=d>=0?1:-1,E=1-d*d;if(E>Number.EPSILON){let z=Math.sqrt(E),U=Math.atan2(z,d*C);g=Math.sin(g*U)/z,a=Math.sin(a*U)/z}let D=a*C;if(l=l*g+p*D,c=c*g+x*D,u=u*g+y*D,f=f*g+M*D,g===1-a){let z=1/Math.sqrt(l*l+c*c+u*u+f*f);l*=z,c*=z,u*=z,f*=z}}t[e]=l,t[e+1]=c,t[e+2]=u,t[e+3]=f}static multiplyQuaternionsFlat(t,e,n,s,r,o){let a=n[s],l=n[s+1],c=n[s+2],u=n[s+3],f=r[o],p=r[o+1],x=r[o+2],y=r[o+3];return t[e]=a*y+u*f+l*x-c*p,t[e+1]=l*y+u*p+c*f-a*x,t[e+2]=c*y+u*x+a*p-l*f,t[e+3]=u*y-a*f-l*p-c*x,t}get x(){return this._x}set x(t){this._x=t,this._onChangeCallback()}get y(){return this._y}set y(t){this._y=t,this._onChangeCallback()}get z(){return this._z}set z(t){this._z=t,this._onChangeCallback()}get w(){return this._w}set w(t){this._w=t,this._onChangeCallback()}set(t,e,n,s){return this._x=t,this._y=e,this._z=n,this._w=s,this._onChangeCallback(),this}clone(){return new this.constructor(this._x,this._y,this._z,this._w)}copy(t){return this._x=t.x,this._y=t.y,this._z=t.z,this._w=t.w,this._onChangeCallback(),this}setFromEuler(t,e=!0){let n=t._x,s=t._y,r=t._z,o=t._order,a=Math.cos,l=Math.sin,c=a(n/2),u=a(s/2),f=a(r/2),p=l(n/2),x=l(s/2),y=l(r/2);switch(o){case"XYZ":this._x=p*u*f+c*x*y,this._y=c*x*f-p*u*y,this._z=c*u*y+p*x*f,this._w=c*u*f-p*x*y;break;case"YXZ":this._x=p*u*f+c*x*y,this._y=c*x*f-p*u*y,this._z=c*u*y-p*x*f,this._w=c*u*f+p*x*y;break;case"ZXY":this._x=p*u*f-c*x*y,this._y=c*x*f+p*u*y,this._z=c*u*y+p*x*f,this._w=c*u*f-p*x*y;break;case"ZYX":this._x=p*u*f-c*x*y,this._y=c*x*f+p*u*y,this._z=c*u*y-p*x*f,this._w=c*u*f+p*x*y;break;case"YZX":this._x=p*u*f+c*x*y,this._y=c*x*f+p*u*y,this._z=c*u*y-p*x*f,this._w=c*u*f-p*x*y;break;case"XZY":this._x=p*u*f-c*x*y,this._y=c*x*f-p*u*y,this._z=c*u*y+p*x*f,this._w=c*u*f+p*x*y;break;default:console.warn("THREE.Quaternion: .setFromEuler() encountered an unknown order: "+o)}return e===!0&&this._onChangeCallback(),this}setFromAxisAngle(t,e){let n=e/2,s=Math.sin(n);return this._x=t.x*s,this._y=t.y*s,this._z=t.z*s,this._w=Math.cos(n),this._onChangeCallback(),this}setFromRotationMatrix(t){let e=t.elements,n=e[0],s=e[4],r=e[8],o=e[1],a=e[5],l=e[9],c=e[2],u=e[6],f=e[10],p=n+a+f;if(p>0){let x=.5/Math.sqrt(p+1);this._w=.25/x,this._x=(u-l)*x,this._y=(r-c)*x,this._z=(o-s)*x}else if(n>a&&n>f){let x=2*Math.sqrt(1+n-a-f);this._w=(u-l)/x,this._x=.25*x,this._y=(s+o)/x,this._z=(r+c)/x}else if(a>f){let x=2*Math.sqrt(1+a-n-f);this._w=(r-c)/x,this._x=(s+o)/x,this._y=.25*x,this._z=(l+u)/x}else{let x=2*Math.sqrt(1+f-n-a);this._w=(o-s)/x,this._x=(r+c)/x,this._y=(l+u)/x,this._z=.25*x}return this._onChangeCallback(),this}setFromUnitVectors(t,e){let n=t.dot(e)+1;return n<Number.EPSILON?(n=0,Math.abs(t.x)>Math.abs(t.z)?(this._x=-t.y,this._y=t.x,this._z=0,this._w=n):(this._x=0,this._y=-t.z,this._z=t.y,this._w=n)):(this._x=t.y*e.z-t.z*e.y,this._y=t.z*e.x-t.x*e.z,this._z=t.x*e.y-t.y*e.x,this._w=n),this.normalize()}angleTo(t){return 2*Math.acos(Math.abs(en(this.dot(t),-1,1)))}rotateTowards(t,e){let n=this.angleTo(t);if(n===0)return this;let s=Math.min(1,e/n);return this.slerp(t,s),this}identity(){return this.set(0,0,0,1)}invert(){return this.conjugate()}conjugate(){return this._x*=-1,this._y*=-1,this._z*=-1,this._onChangeCallback(),this}dot(t){return this._x*t._x+this._y*t._y+this._z*t._z+this._w*t._w}lengthSq(){return this._x*this._x+this._y*this._y+this._z*this._z+this._w*this._w}length(){return Math.sqrt(this._x*this._x+this._y*this._y+this._z*this._z+this._w*this._w)}normalize(){let t=this.length();return t===0?(this._x=0,this._y=0,this._z=0,this._w=1):(t=1/t,this._x=this._x*t,this._y=this._y*t,this._z=this._z*t,this._w=this._w*t),this._onChangeCallback(),this}multiply(t){return this.multiplyQuaternions(this,t)}premultiply(t){return this.multiplyQuaternions(t,this)}multiplyQuaternions(t,e){let n=t._x,s=t._y,r=t._z,o=t._w,a=e._x,l=e._y,c=e._z,u=e._w;return this._x=n*u+o*a+s*c-r*l,this._y=s*u+o*l+r*a-n*c,this._z=r*u+o*c+n*l-s*a,this._w=o*u-n*a-s*l-r*c,this._onChangeCallback(),this}slerp(t,e){if(e===0)return this;if(e===1)return this.copy(t);let n=this._x,s=this._y,r=this._z,o=this._w,a=o*t._w+n*t._x+s*t._y+r*t._z;if(a<0?(this._w=-t._w,this._x=-t._x,this._y=-t._y,this._z=-t._z,a=-a):this.copy(t),a>=1)return this._w=o,this._x=n,this._y=s,this._z=r,this;let l=1-a*a;if(l<=Number.EPSILON){let x=1-e;return this._w=x*o+e*this._w,this._x=x*n+e*this._x,this._y=x*s+e*this._y,this._z=x*r+e*this._z,this.normalize(),this}let c=Math.sqrt(l),u=Math.atan2(c,a),f=Math.sin((1-e)*u)/c,p=Math.sin(e*u)/c;return this._w=o*f+this._w*p,this._x=n*f+this._x*p,this._y=s*f+this._y*p,this._z=r*f+this._z*p,this._onChangeCallback(),this}slerpQuaternions(t,e,n){return this.copy(t).slerp(e,n)}random(){let t=Math.random(),e=Math.sqrt(1-t),n=Math.sqrt(t),s=2*Math.PI*Math.random(),r=2*Math.PI*Math.random();return this.set(e*Math.cos(s),n*Math.sin(r),n*Math.cos(r),e*Math.sin(s))}equals(t){return t._x===this._x&&t._y===this._y&&t._z===this._z&&t._w===this._w}fromArray(t,e=0){return this._x=t[e],this._y=t[e+1],this._z=t[e+2],this._w=t[e+3],this._onChangeCallback(),this}toArray(t=[],e=0){return t[e]=this._x,t[e+1]=this._y,t[e+2]=this._z,t[e+3]=this._w,t}fromBufferAttribute(t,e){return this._x=t.getX(e),this._y=t.getY(e),this._z=t.getZ(e),this._w=t.getW(e),this._onChangeCallback(),this}toJSON(){return this.toArray()}_onChange(t){return this._onChangeCallback=t,this}_onChangeCallback(){}*[Symbol.iterator](){yield this._x,yield this._y,yield this._z,yield this._w}},B=class i{constructor(t=0,e=0,n=0){i.prototype.isVector3=!0,this.x=t,this.y=e,this.z=n}set(t,e,n){return n===void 0&&(n=this.z),this.x=t,this.y=e,this.z=n,this}setScalar(t){return this.x=t,this.y=t,this.z=t,this}setX(t){return this.x=t,this}setY(t){return this.y=t,this}setZ(t){return this.z=t,this}setComponent(t,e){switch(t){case 0:this.x=e;break;case 1:this.y=e;break;case 2:this.z=e;break;default:throw new Error("index is out of range: "+t)}return this}getComponent(t){switch(t){case 0:return this.x;case 1:return this.y;case 2:return this.z;default:throw new Error("index is out of range: "+t)}}clone(){return new this.constructor(this.x,this.y,this.z)}copy(t){return this.x=t.x,this.y=t.y,this.z=t.z,this}add(t){return this.x+=t.x,this.y+=t.y,this.z+=t.z,this}addScalar(t){return this.x+=t,this.y+=t,this.z+=t,this}addVectors(t,e){return this.x=t.x+e.x,this.y=t.y+e.y,this.z=t.z+e.z,this}addScaledVector(t,e){return this.x+=t.x*e,this.y+=t.y*e,this.z+=t.z*e,this}sub(t){return this.x-=t.x,this.y-=t.y,this.z-=t.z,this}subScalar(t){return this.x-=t,this.y-=t,this.z-=t,this}subVectors(t,e){return this.x=t.x-e.x,this.y=t.y-e.y,this.z=t.z-e.z,this}multiply(t){return this.x*=t.x,this.y*=t.y,this.z*=t.z,this}multiplyScalar(t){return this.x*=t,this.y*=t,this.z*=t,this}multiplyVectors(t,e){return this.x=t.x*e.x,this.y=t.y*e.y,this.z=t.z*e.z,this}applyEuler(t){return this.applyQuaternion(jc.setFromEuler(t))}applyAxisAngle(t,e){return this.applyQuaternion(jc.setFromAxisAngle(t,e))}applyMatrix3(t){let e=this.x,n=this.y,s=this.z,r=t.elements;return this.x=r[0]*e+r[3]*n+r[6]*s,this.y=r[1]*e+r[4]*n+r[7]*s,this.z=r[2]*e+r[5]*n+r[8]*s,this}applyNormalMatrix(t){return this.applyMatrix3(t).normalize()}applyMatrix4(t){let e=this.x,n=this.y,s=this.z,r=t.elements,o=1/(r[3]*e+r[7]*n+r[11]*s+r[15]);return this.x=(r[0]*e+r[4]*n+r[8]*s+r[12])*o,this.y=(r[1]*e+r[5]*n+r[9]*s+r[13])*o,this.z=(r[2]*e+r[6]*n+r[10]*s+r[14])*o,this}applyQuaternion(t){let e=this.x,n=this.y,s=this.z,r=t.x,o=t.y,a=t.z,l=t.w,c=2*(o*s-a*n),u=2*(a*e-r*s),f=2*(r*n-o*e);return this.x=e+l*c+o*f-a*u,this.y=n+l*u+a*c-r*f,this.z=s+l*f+r*u-o*c,this}project(t){return this.applyMatrix4(t.matrixWorldInverse).applyMatrix4(t.projectionMatrix)}unproject(t){return this.applyMatrix4(t.projectionMatrixInverse).applyMatrix4(t.matrixWorld)}transformDirection(t){let e=this.x,n=this.y,s=this.z,r=t.elements;return this.x=r[0]*e+r[4]*n+r[8]*s,this.y=r[1]*e+r[5]*n+r[9]*s,this.z=r[2]*e+r[6]*n+r[10]*s,this.normalize()}divide(t){return this.x/=t.x,this.y/=t.y,this.z/=t.z,this}divideScalar(t){return this.multiplyScalar(1/t)}min(t){return this.x=Math.min(this.x,t.x),this.y=Math.min(this.y,t.y),this.z=Math.min(this.z,t.z),this}max(t){return this.x=Math.max(this.x,t.x),this.y=Math.max(this.y,t.y),this.z=Math.max(this.z,t.z),this}clamp(t,e){return this.x=Math.max(t.x,Math.min(e.x,this.x)),this.y=Math.max(t.y,Math.min(e.y,this.y)),this.z=Math.max(t.z,Math.min(e.z,this.z)),this}clampScalar(t,e){return this.x=Math.max(t,Math.min(e,this.x)),this.y=Math.max(t,Math.min(e,this.y)),this.z=Math.max(t,Math.min(e,this.z)),this}clampLength(t,e){let n=this.length();return this.divideScalar(n||1).multiplyScalar(Math.max(t,Math.min(e,n)))}floor(){return this.x=Math.floor(this.x),this.y=Math.floor(this.y),this.z=Math.floor(this.z),this}ceil(){return this.x=Math.ceil(this.x),this.y=Math.ceil(this.y),this.z=Math.ceil(this.z),this}round(){return this.x=Math.round(this.x),this.y=Math.round(this.y),this.z=Math.round(this.z),this}roundToZero(){return this.x=Math.trunc(this.x),this.y=Math.trunc(this.y),this.z=Math.trunc(this.z),this}negate(){return this.x=-this.x,this.y=-this.y,this.z=-this.z,this}dot(t){return this.x*t.x+this.y*t.y+this.z*t.z}lengthSq(){return this.x*this.x+this.y*this.y+this.z*this.z}length(){return Math.sqrt(this.x*this.x+this.y*this.y+this.z*this.z)}manhattanLength(){return Math.abs(this.x)+Math.abs(this.y)+Math.abs(this.z)}normalize(){return this.divideScalar(this.length()||1)}setLength(t){return this.normalize().multiplyScalar(t)}lerp(t,e){return this.x+=(t.x-this.x)*e,this.y+=(t.y-this.y)*e,this.z+=(t.z-this.z)*e,this}lerpVectors(t,e,n){return this.x=t.x+(e.x-t.x)*n,this.y=t.y+(e.y-t.y)*n,this.z=t.z+(e.z-t.z)*n,this}cross(t){return this.crossVectors(this,t)}crossVectors(t,e){let n=t.x,s=t.y,r=t.z,o=e.x,a=e.y,l=e.z;return this.x=s*l-r*a,this.y=r*o-n*l,this.z=n*a-s*o,this}projectOnVector(t){let e=t.lengthSq();if(e===0)return this.set(0,0,0);let n=t.dot(this)/e;return this.copy(t).multiplyScalar(n)}projectOnPlane(t){return bo.copy(this).projectOnVector(t),this.sub(bo)}reflect(t){return this.sub(bo.copy(t).multiplyScalar(2*this.dot(t)))}angleTo(t){let e=Math.sqrt(this.lengthSq()*t.lengthSq());if(e===0)return Math.PI/2;let n=this.dot(t)/e;return Math.acos(en(n,-1,1))}distanceTo(t){return Math.sqrt(this.distanceToSquared(t))}distanceToSquared(t){let e=this.x-t.x,n=this.y-t.y,s=this.z-t.z;return e*e+n*n+s*s}manhattanDistanceTo(t){return Math.abs(this.x-t.x)+Math.abs(this.y-t.y)+Math.abs(this.z-t.z)}setFromSpherical(t){return this.setFromSphericalCoords(t.radius,t.phi,t.theta)}setFromSphericalCoords(t,e,n){let s=Math.sin(e)*t;return this.x=s*Math.sin(n),this.y=Math.cos(e)*t,this.z=s*Math.cos(n),this}setFromCylindrical(t){return this.setFromCylindricalCoords(t.radius,t.theta,t.y)}setFromCylindricalCoords(t,e,n){return this.x=t*Math.sin(e),this.y=n,this.z=t*Math.cos(e),this}setFromMatrixPosition(t){let e=t.elements;return this.x=e[12],this.y=e[13],this.z=e[14],this}setFromMatrixScale(t){let e=this.setFromMatrixColumn(t,0).length(),n=this.setFromMatrixColumn(t,1).length(),s=this.setFromMatrixColumn(t,2).length();return this.x=e,this.y=n,this.z=s,this}setFromMatrixColumn(t,e){return this.fromArray(t.elements,e*4)}setFromMatrix3Column(t,e){return this.fromArray(t.elements,e*3)}setFromEuler(t){return this.x=t._x,this.y=t._y,this.z=t._z,this}setFromColor(t){return this.x=t.r,this.y=t.g,this.z=t.b,this}equals(t){return t.x===this.x&&t.y===this.y&&t.z===this.z}fromArray(t,e=0){return this.x=t[e],this.y=t[e+1],this.z=t[e+2],this}toArray(t=[],e=0){return t[e]=this.x,t[e+1]=this.y,t[e+2]=this.z,t}fromBufferAttribute(t,e){return this.x=t.getX(e),this.y=t.getY(e),this.z=t.getZ(e),this}random(){return this.x=Math.random(),this.y=Math.random(),this.z=Math.random(),this}randomDirection(){let t=(Math.random()-.5)*2,e=Math.random()*Math.PI*2,n=Math.sqrt(1-t**2);return this.x=n*Math.cos(e),this.y=n*Math.sin(e),this.z=t,this}*[Symbol.iterator](){yield this.x,yield this.y,yield this.z}},bo=new B,jc=new On,ai=class{constructor(t=new B(1/0,1/0,1/0),e=new B(-1/0,-1/0,-1/0)){this.isBox3=!0,this.min=t,this.max=e}set(t,e){return this.min.copy(t),this.max.copy(e),this}setFromArray(t){this.makeEmpty();for(let e=0,n=t.length;e<n;e+=3)this.expandByPoint(Rn.fromArray(t,e));return this}setFromBufferAttribute(t){this.makeEmpty();for(let e=0,n=t.count;e<n;e++)this.expandByPoint(Rn.fromBufferAttribute(t,e));return this}setFromPoints(t){this.makeEmpty();for(let e=0,n=t.length;e<n;e++)this.expandByPoint(t[e]);return this}setFromCenterAndSize(t,e){let n=Rn.copy(e).multiplyScalar(.5);return this.min.copy(t).sub(n),this.max.copy(t).add(n),this}setFromObject(t,e=!1){return this.makeEmpty(),this.expandByObject(t,e)}clone(){return new this.constructor().copy(this)}copy(t){return this.min.copy(t.min),this.max.copy(t.max),this}makeEmpty(){return this.min.x=this.min.y=this.min.z=1/0,this.max.x=this.max.y=this.max.z=-1/0,this}isEmpty(){return this.max.x<this.min.x||this.max.y<this.min.y||this.max.z<this.min.z}getCenter(t){return this.isEmpty()?t.set(0,0,0):t.addVectors(this.min,this.max).multiplyScalar(.5)}getSize(t){return this.isEmpty()?t.set(0,0,0):t.subVectors(this.max,this.min)}expandByPoint(t){return this.min.min(t),this.max.max(t),this}expandByVector(t){return this.min.sub(t),this.max.add(t),this}expandByScalar(t){return this.min.addScalar(-t),this.max.addScalar(t),this}expandByObject(t,e=!1){t.updateWorldMatrix(!1,!1);let n=t.geometry;if(n!==void 0){let r=n.getAttribute("position");if(e===!0&&r!==void 0&&t.isInstancedMesh!==!0)for(let o=0,a=r.count;o<a;o++)t.isMesh===!0?t.getVertexPosition(o,Rn):Rn.fromBufferAttribute(r,o),Rn.applyMatrix4(t.matrixWorld),this.expandByPoint(Rn);else t.boundingBox!==void 0?(t.boundingBox===null&&t.computeBoundingBox(),Nr.copy(t.boundingBox)):(n.boundingBox===null&&n.computeBoundingBox(),Nr.copy(n.boundingBox)),Nr.applyMatrix4(t.matrixWorld),this.union(Nr)}let s=t.children;for(let r=0,o=s.length;r<o;r++)this.expandByObject(s[r],e);return this}containsPoint(t){return!(t.x<this.min.x||t.x>this.max.x||t.y<this.min.y||t.y>this.max.y||t.z<this.min.z||t.z>this.max.z)}containsBox(t){return this.min.x<=t.min.x&&t.max.x<=this.max.x&&this.min.y<=t.min.y&&t.max.y<=this.max.y&&this.min.z<=t.min.z&&t.max.z<=this.max.z}getParameter(t,e){return e.set((t.x-this.min.x)/(this.max.x-this.min.x),(t.y-this.min.y)/(this.max.y-this.min.y),(t.z-this.min.z)/(this.max.z-this.min.z))}intersectsBox(t){return!(t.max.x<this.min.x||t.min.x>this.max.x||t.max.y<this.min.y||t.min.y>this.max.y||t.max.z<this.min.z||t.min.z>this.max.z)}intersectsSphere(t){return this.clampPoint(t.center,Rn),Rn.distanceToSquared(t.center)<=t.radius*t.radius}intersectsPlane(t){let e,n;return t.normal.x>0?(e=t.normal.x*this.min.x,n=t.normal.x*this.max.x):(e=t.normal.x*this.max.x,n=t.normal.x*this.min.x),t.normal.y>0?(e+=t.normal.y*this.min.y,n+=t.normal.y*this.max.y):(e+=t.normal.y*this.max.y,n+=t.normal.y*this.min.y),t.normal.z>0?(e+=t.normal.z*this.min.z,n+=t.normal.z*this.max.z):(e+=t.normal.z*this.max.z,n+=t.normal.z*this.min.z),e<=-t.constant&&n>=-t.constant}intersectsTriangle(t){if(this.isEmpty())return!1;this.getCenter(Qs),Or.subVectors(this.max,Qs),ls.subVectors(t.a,Qs),cs.subVectors(t.b,Qs),hs.subVectors(t.c,Qs),di.subVectors(cs,ls),fi.subVectors(hs,cs),Ni.subVectors(ls,hs);let e=[0,-di.z,di.y,0,-fi.z,fi.y,0,-Ni.z,Ni.y,di.z,0,-di.x,fi.z,0,-fi.x,Ni.z,0,-Ni.x,-di.y,di.x,0,-fi.y,fi.x,0,-Ni.y,Ni.x,0];return!Mo(e,ls,cs,hs,Or)||(e=[1,0,0,0,1,0,0,0,1],!Mo(e,ls,cs,hs,Or))?!1:(Fr.crossVectors(di,fi),e=[Fr.x,Fr.y,Fr.z],Mo(e,ls,cs,hs,Or))}clampPoint(t,e){return e.copy(t).clamp(this.min,this.max)}distanceToPoint(t){return this.clampPoint(t,Rn).distanceTo(t)}getBoundingSphere(t){return this.isEmpty()?t.makeEmpty():(this.getCenter(t.center),t.radius=this.getSize(Rn).length()*.5),t}intersect(t){return this.min.max(t.min),this.max.min(t.max),this.isEmpty()&&this.makeEmpty(),this}union(t){return this.min.min(t.min),this.max.max(t.max),this}applyMatrix4(t){return this.isEmpty()?this:($n[0].set(this.min.x,this.min.y,this.min.z).applyMatrix4(t),$n[1].set(this.min.x,this.min.y,this.max.z).applyMatrix4(t),$n[2].set(this.min.x,this.max.y,this.min.z).applyMatrix4(t),$n[3].set(this.min.x,this.max.y,this.max.z).applyMatrix4(t),$n[4].set(this.max.x,this.min.y,this.min.z).applyMatrix4(t),$n[5].set(this.max.x,this.min.y,this.max.z).applyMatrix4(t),$n[6].set(this.max.x,this.max.y,this.min.z).applyMatrix4(t),$n[7].set(this.max.x,this.max.y,this.max.z).applyMatrix4(t),this.setFromPoints($n),this)}translate(t){return this.min.add(t),this.max.add(t),this}equals(t){return t.min.equals(this.min)&&t.max.equals(this.max)}},$n=[new B,new B,new B,new B,new B,new B,new B,new B],Rn=new B,Nr=new ai,ls=new B,cs=new B,hs=new B,di=new B,fi=new B,Ni=new B,Qs=new B,Or=new B,Fr=new B,Oi=new B;function Mo(i,t,e,n,s){for(let r=0,o=i.length-3;r<=o;r+=3){Oi.fromArray(i,r);let a=s.x*Math.abs(Oi.x)+s.y*Math.abs(Oi.y)+s.z*Math.abs(Oi.z),l=t.dot(Oi),c=e.dot(Oi),u=n.dot(Oi);if(Math.max(-Math.max(l,c,u),Math.min(l,c,u))>a)return!1}return!0}var Yd=new ai,tr=new B,So=new B,Si=class{constructor(t=new B,e=-1){this.isSphere=!0,this.center=t,this.radius=e}set(t,e){return this.center.copy(t),this.radius=e,this}setFromPoints(t,e){let n=this.center;e!==void 0?n.copy(e):Yd.setFromPoints(t).getCenter(n);let s=0;for(let r=0,o=t.length;r<o;r++)s=Math.max(s,n.distanceToSquared(t[r]));return this.radius=Math.sqrt(s),this}copy(t){return this.center.copy(t.center),this.radius=t.radius,this}isEmpty(){return this.radius<0}makeEmpty(){return this.center.set(0,0,0),this.radius=-1,this}containsPoint(t){return t.distanceToSquared(this.center)<=this.radius*this.radius}distanceToPoint(t){return t.distanceTo(this.center)-this.radius}intersectsSphere(t){let e=this.radius+t.radius;return t.center.distanceToSquared(this.center)<=e*e}intersectsBox(t){return t.intersectsSphere(this)}intersectsPlane(t){return Math.abs(t.distanceToPoint(this.center))<=this.radius}clampPoint(t,e){let n=this.center.distanceToSquared(t);return e.copy(t),n>this.radius*this.radius&&(e.sub(this.center).normalize(),e.multiplyScalar(this.radius).add(this.center)),e}getBoundingBox(t){return this.isEmpty()?(t.makeEmpty(),t):(t.set(this.center,this.center),t.expandByScalar(this.radius),t)}applyMatrix4(t){return this.center.applyMatrix4(t),this.radius=this.radius*t.getMaxScaleOnAxis(),this}translate(t){return this.center.add(t),this}expandByPoint(t){if(this.isEmpty())return this.center.copy(t),this.radius=0,this;tr.subVectors(t,this.center);let e=tr.lengthSq();if(e>this.radius*this.radius){let n=Math.sqrt(e),s=(n-this.radius)*.5;this.center.addScaledVector(tr,s/n),this.radius+=s}return this}union(t){return t.isEmpty()?this:this.isEmpty()?(this.copy(t),this):(this.center.equals(t.center)===!0?this.radius=Math.max(this.radius,t.radius):(So.subVectors(t.center,this.center).setLength(t.radius),this.expandByPoint(tr.copy(t.center).add(So)),this.expandByPoint(tr.copy(t.center).sub(So))),this)}equals(t){return t.center.equals(this.center)&&t.radius===this.radius}clone(){return new this.constructor().copy(this)}},Kn=new B,wo=new B,Br=new B,pi=new B,Eo=new B,zr=new B,To=new B,Xi=class{constructor(t=new B,e=new B(0,0,-1)){this.origin=t,this.direction=e}set(t,e){return this.origin.copy(t),this.direction.copy(e),this}copy(t){return this.origin.copy(t.origin),this.direction.copy(t.direction),this}at(t,e){return e.copy(this.origin).addScaledVector(this.direction,t)}lookAt(t){return this.direction.copy(t).sub(this.origin).normalize(),this}recast(t){return this.origin.copy(this.at(t,Kn)),this}closestPointToPoint(t,e){e.subVectors(t,this.origin);let n=e.dot(this.direction);return n<0?e.copy(this.origin):e.copy(this.origin).addScaledVector(this.direction,n)}distanceToPoint(t){return Math.sqrt(this.distanceSqToPoint(t))}distanceSqToPoint(t){let e=Kn.subVectors(t,this.origin).dot(this.direction);return e<0?this.origin.distanceToSquared(t):(Kn.copy(this.origin).addScaledVector(this.direction,e),Kn.distanceToSquared(t))}distanceSqToSegment(t,e,n,s){wo.copy(t).add(e).multiplyScalar(.5),Br.copy(e).sub(t).normalize(),pi.copy(this.origin).sub(wo);let r=t.distanceTo(e)*.5,o=-this.direction.dot(Br),a=pi.dot(this.direction),l=-pi.dot(Br),c=pi.lengthSq(),u=Math.abs(1-o*o),f,p,x,y;if(u>0)if(f=o*l-a,p=o*a-l,y=r*u,f>=0)if(p>=-y)if(p<=y){let M=1/u;f*=M,p*=M,x=f*(f+o*p+2*a)+p*(o*f+p+2*l)+c}else p=r,f=Math.max(0,-(o*p+a)),x=-f*f+p*(p+2*l)+c;else p=-r,f=Math.max(0,-(o*p+a)),x=-f*f+p*(p+2*l)+c;else p<=-y?(f=Math.max(0,-(-o*r+a)),p=f>0?-r:Math.min(Math.max(-r,-l),r),x=-f*f+p*(p+2*l)+c):p<=y?(f=0,p=Math.min(Math.max(-r,-l),r),x=p*(p+2*l)+c):(f=Math.max(0,-(o*r+a)),p=f>0?r:Math.min(Math.max(-r,-l),r),x=-f*f+p*(p+2*l)+c);else p=o>0?-r:r,f=Math.max(0,-(o*p+a)),x=-f*f+p*(p+2*l)+c;return n&&n.copy(this.origin).addScaledVector(this.direction,f),s&&s.copy(wo).addScaledVector(Br,p),x}intersectSphere(t,e){Kn.subVectors(t.center,this.origin);let n=Kn.dot(this.direction),s=Kn.dot(Kn)-n*n,r=t.radius*t.radius;if(s>r)return null;let o=Math.sqrt(r-s),a=n-o,l=n+o;return l<0?null:a<0?this.at(l,e):this.at(a,e)}intersectsSphere(t){return this.distanceSqToPoint(t.center)<=t.radius*t.radius}distanceToPlane(t){let e=t.normal.dot(this.direction);if(e===0)return t.distanceToPoint(this.origin)===0?0:null;let n=-(this.origin.dot(t.normal)+t.constant)/e;return n>=0?n:null}intersectPlane(t,e){let n=this.distanceToPlane(t);return n===null?null:this.at(n,e)}intersectsPlane(t){let e=t.distanceToPoint(this.origin);return e===0||t.normal.dot(this.direction)*e<0}intersectBox(t,e){let n,s,r,o,a,l,c=1/this.direction.x,u=1/this.direction.y,f=1/this.direction.z,p=this.origin;return c>=0?(n=(t.min.x-p.x)*c,s=(t.max.x-p.x)*c):(n=(t.max.x-p.x)*c,s=(t.min.x-p.x)*c),u>=0?(r=(t.min.y-p.y)*u,o=(t.max.y-p.y)*u):(r=(t.max.y-p.y)*u,o=(t.min.y-p.y)*u),n>o||r>s||((r>n||isNaN(n))&&(n=r),(o<s||isNaN(s))&&(s=o),f>=0?(a=(t.min.z-p.z)*f,l=(t.max.z-p.z)*f):(a=(t.max.z-p.z)*f,l=(t.min.z-p.z)*f),n>l||a>s)||((a>n||n!==n)&&(n=a),(l<s||s!==s)&&(s=l),s<0)?null:this.at(n>=0?n:s,e)}intersectsBox(t){return this.intersectBox(t,Kn)!==null}intersectTriangle(t,e,n,s,r){Eo.subVectors(e,t),zr.subVectors(n,t),To.crossVectors(Eo,zr);let o=this.direction.dot(To),a;if(o>0){if(s)return null;a=1}else if(o<0)a=-1,o=-o;else return null;pi.subVectors(this.origin,t);let l=a*this.direction.dot(zr.crossVectors(pi,zr));if(l<0)return null;let c=a*this.direction.dot(Eo.cross(pi));if(c<0||l+c>o)return null;let u=-a*pi.dot(To);return u<0?null:this.at(u/o,r)}applyMatrix4(t){return this.origin.applyMatrix4(t),this.direction.transformDirection(t),this}equals(t){return t.origin.equals(this.origin)&&t.direction.equals(this.direction)}clone(){return new this.constructor().copy(this)}},ve=class i{constructor(t,e,n,s,r,o,a,l,c,u,f,p,x,y,M,g){i.prototype.isMatrix4=!0,this.elements=[1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1],t!==void 0&&this.set(t,e,n,s,r,o,a,l,c,u,f,p,x,y,M,g)}set(t,e,n,s,r,o,a,l,c,u,f,p,x,y,M,g){let d=this.elements;return d[0]=t,d[4]=e,d[8]=n,d[12]=s,d[1]=r,d[5]=o,d[9]=a,d[13]=l,d[2]=c,d[6]=u,d[10]=f,d[14]=p,d[3]=x,d[7]=y,d[11]=M,d[15]=g,this}identity(){return this.set(1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1),this}clone(){return new i().fromArray(this.elements)}copy(t){let e=this.elements,n=t.elements;return e[0]=n[0],e[1]=n[1],e[2]=n[2],e[3]=n[3],e[4]=n[4],e[5]=n[5],e[6]=n[6],e[7]=n[7],e[8]=n[8],e[9]=n[9],e[10]=n[10],e[11]=n[11],e[12]=n[12],e[13]=n[13],e[14]=n[14],e[15]=n[15],this}copyPosition(t){let e=this.elements,n=t.elements;return e[12]=n[12],e[13]=n[13],e[14]=n[14],this}setFromMatrix3(t){let e=t.elements;return this.set(e[0],e[3],e[6],0,e[1],e[4],e[7],0,e[2],e[5],e[8],0,0,0,0,1),this}extractBasis(t,e,n){return t.setFromMatrixColumn(this,0),e.setFromMatrixColumn(this,1),n.setFromMatrixColumn(this,2),this}makeBasis(t,e,n){return this.set(t.x,e.x,n.x,0,t.y,e.y,n.y,0,t.z,e.z,n.z,0,0,0,0,1),this}extractRotation(t){let e=this.elements,n=t.elements,s=1/us.setFromMatrixColumn(t,0).length(),r=1/us.setFromMatrixColumn(t,1).length(),o=1/us.setFromMatrixColumn(t,2).length();return e[0]=n[0]*s,e[1]=n[1]*s,e[2]=n[2]*s,e[3]=0,e[4]=n[4]*r,e[5]=n[5]*r,e[6]=n[6]*r,e[7]=0,e[8]=n[8]*o,e[9]=n[9]*o,e[10]=n[10]*o,e[11]=0,e[12]=0,e[13]=0,e[14]=0,e[15]=1,this}makeRotationFromEuler(t){let e=this.elements,n=t.x,s=t.y,r=t.z,o=Math.cos(n),a=Math.sin(n),l=Math.cos(s),c=Math.sin(s),u=Math.cos(r),f=Math.sin(r);if(t.order==="XYZ"){let p=o*u,x=o*f,y=a*u,M=a*f;e[0]=l*u,e[4]=-l*f,e[8]=c,e[1]=x+y*c,e[5]=p-M*c,e[9]=-a*l,e[2]=M-p*c,e[6]=y+x*c,e[10]=o*l}else if(t.order==="YXZ"){let p=l*u,x=l*f,y=c*u,M=c*f;e[0]=p+M*a,e[4]=y*a-x,e[8]=o*c,e[1]=o*f,e[5]=o*u,e[9]=-a,e[2]=x*a-y,e[6]=M+p*a,e[10]=o*l}else if(t.order==="ZXY"){let p=l*u,x=l*f,y=c*u,M=c*f;e[0]=p-M*a,e[4]=-o*f,e[8]=y+x*a,e[1]=x+y*a,e[5]=o*u,e[9]=M-p*a,e[2]=-o*c,e[6]=a,e[10]=o*l}else if(t.order==="ZYX"){let p=o*u,x=o*f,y=a*u,M=a*f;e[0]=l*u,e[4]=y*c-x,e[8]=p*c+M,e[1]=l*f,e[5]=M*c+p,e[9]=x*c-y,e[2]=-c,e[6]=a*l,e[10]=o*l}else if(t.order==="YZX"){let p=o*l,x=o*c,y=a*l,M=a*c;e[0]=l*u,e[4]=M-p*f,e[8]=y*f+x,e[1]=f,e[5]=o*u,e[9]=-a*u,e[2]=-c*u,e[6]=x*f+y,e[10]=p-M*f}else if(t.order==="XZY"){let p=o*l,x=o*c,y=a*l,M=a*c;e[0]=l*u,e[4]=-f,e[8]=c*u,e[1]=p*f+M,e[5]=o*u,e[9]=x*f-y,e[2]=y*f-x,e[6]=a*u,e[10]=M*f+p}return e[3]=0,e[7]=0,e[11]=0,e[12]=0,e[13]=0,e[14]=0,e[15]=1,this}makeRotationFromQuaternion(t){return this.compose(qd,t,Zd)}lookAt(t,e,n){let s=this.elements;return pn.subVectors(t,e),pn.lengthSq()===0&&(pn.z=1),pn.normalize(),mi.crossVectors(n,pn),mi.lengthSq()===0&&(Math.abs(n.z)===1?pn.x+=1e-4:pn.z+=1e-4,pn.normalize(),mi.crossVectors(n,pn)),mi.normalize(),kr.crossVectors(pn,mi),s[0]=mi.x,s[4]=kr.x,s[8]=pn.x,s[1]=mi.y,s[5]=kr.y,s[9]=pn.y,s[2]=mi.z,s[6]=kr.z,s[10]=pn.z,this}multiply(t){return this.multiplyMatrices(this,t)}premultiply(t){return this.multiplyMatrices(t,this)}multiplyMatrices(t,e){let n=t.elements,s=e.elements,r=this.elements,o=n[0],a=n[4],l=n[8],c=n[12],u=n[1],f=n[5],p=n[9],x=n[13],y=n[2],M=n[6],g=n[10],d=n[14],C=n[3],E=n[7],D=n[11],z=n[15],U=s[0],L=s[4],Q=s[8],S=s[12],R=s[1],V=s[5],nt=s[9],ft=s[13],I=s[2],k=s[6],$=s[10],Z=s[14],j=s[3],K=s[7],st=s[11],it=s[15];return r[0]=o*U+a*R+l*I+c*j,r[4]=o*L+a*V+l*k+c*K,r[8]=o*Q+a*nt+l*$+c*st,r[12]=o*S+a*ft+l*Z+c*it,r[1]=u*U+f*R+p*I+x*j,r[5]=u*L+f*V+p*k+x*K,r[9]=u*Q+f*nt+p*$+x*st,r[13]=u*S+f*ft+p*Z+x*it,r[2]=y*U+M*R+g*I+d*j,r[6]=y*L+M*V+g*k+d*K,r[10]=y*Q+M*nt+g*$+d*st,r[14]=y*S+M*ft+g*Z+d*it,r[3]=C*U+E*R+D*I+z*j,r[7]=C*L+E*V+D*k+z*K,r[11]=C*Q+E*nt+D*$+z*st,r[15]=C*S+E*ft+D*Z+z*it,this}multiplyScalar(t){let e=this.elements;return e[0]*=t,e[4]*=t,e[8]*=t,e[12]*=t,e[1]*=t,e[5]*=t,e[9]*=t,e[13]*=t,e[2]*=t,e[6]*=t,e[10]*=t,e[14]*=t,e[3]*=t,e[7]*=t,e[11]*=t,e[15]*=t,this}determinant(){let t=this.elements,e=t[0],n=t[4],s=t[8],r=t[12],o=t[1],a=t[5],l=t[9],c=t[13],u=t[2],f=t[6],p=t[10],x=t[14],y=t[3],M=t[7],g=t[11],d=t[15];return y*(+r*l*f-s*c*f-r*a*p+n*c*p+s*a*x-n*l*x)+M*(+e*l*x-e*c*p+r*o*p-s*o*x+s*c*u-r*l*u)+g*(+e*c*f-e*a*x-r*o*f+n*o*x+r*a*u-n*c*u)+d*(-s*a*u-e*l*f+e*a*p+s*o*f-n*o*p+n*l*u)}transpose(){let t=this.elements,e;return e=t[1],t[1]=t[4],t[4]=e,e=t[2],t[2]=t[8],t[8]=e,e=t[6],t[6]=t[9],t[9]=e,e=t[3],t[3]=t[12],t[12]=e,e=t[7],t[7]=t[13],t[13]=e,e=t[11],t[11]=t[14],t[14]=e,this}setPosition(t,e,n){let s=this.elements;return t.isVector3?(s[12]=t.x,s[13]=t.y,s[14]=t.z):(s[12]=t,s[13]=e,s[14]=n),this}invert(){let t=this.elements,e=t[0],n=t[1],s=t[2],r=t[3],o=t[4],a=t[5],l=t[6],c=t[7],u=t[8],f=t[9],p=t[10],x=t[11],y=t[12],M=t[13],g=t[14],d=t[15],C=f*g*c-M*p*c+M*l*x-a*g*x-f*l*d+a*p*d,E=y*p*c-u*g*c-y*l*x+o*g*x+u*l*d-o*p*d,D=u*M*c-y*f*c+y*a*x-o*M*x-u*a*d+o*f*d,z=y*f*l-u*M*l-y*a*p+o*M*p+u*a*g-o*f*g,U=e*C+n*E+s*D+r*z;if(U===0)return this.set(0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0);let L=1/U;return t[0]=C*L,t[1]=(M*p*r-f*g*r-M*s*x+n*g*x+f*s*d-n*p*d)*L,t[2]=(a*g*r-M*l*r+M*s*c-n*g*c-a*s*d+n*l*d)*L,t[3]=(f*l*r-a*p*r-f*s*c+n*p*c+a*s*x-n*l*x)*L,t[4]=E*L,t[5]=(u*g*r-y*p*r+y*s*x-e*g*x-u*s*d+e*p*d)*L,t[6]=(y*l*r-o*g*r-y*s*c+e*g*c+o*s*d-e*l*d)*L,t[7]=(o*p*r-u*l*r+u*s*c-e*p*c-o*s*x+e*l*x)*L,t[8]=D*L,t[9]=(y*f*r-u*M*r-y*n*x+e*M*x+u*n*d-e*f*d)*L,t[10]=(o*M*r-y*a*r+y*n*c-e*M*c-o*n*d+e*a*d)*L,t[11]=(u*a*r-o*f*r-u*n*c+e*f*c+o*n*x-e*a*x)*L,t[12]=z*L,t[13]=(u*M*s-y*f*s+y*n*p-e*M*p-u*n*g+e*f*g)*L,t[14]=(y*a*s-o*M*s-y*n*l+e*M*l+o*n*g-e*a*g)*L,t[15]=(o*f*s-u*a*s+u*n*l-e*f*l-o*n*p+e*a*p)*L,this}scale(t){let e=this.elements,n=t.x,s=t.y,r=t.z;return e[0]*=n,e[4]*=s,e[8]*=r,e[1]*=n,e[5]*=s,e[9]*=r,e[2]*=n,e[6]*=s,e[10]*=r,e[3]*=n,e[7]*=s,e[11]*=r,this}getMaxScaleOnAxis(){let t=this.elements,e=t[0]*t[0]+t[1]*t[1]+t[2]*t[2],n=t[4]*t[4]+t[5]*t[5]+t[6]*t[6],s=t[8]*t[8]+t[9]*t[9]+t[10]*t[10];return Math.sqrt(Math.max(e,n,s))}makeTranslation(t,e,n){return t.isVector3?this.set(1,0,0,t.x,0,1,0,t.y,0,0,1,t.z,0,0,0,1):this.set(1,0,0,t,0,1,0,e,0,0,1,n,0,0,0,1),this}makeRotationX(t){let e=Math.cos(t),n=Math.sin(t);return this.set(1,0,0,0,0,e,-n,0,0,n,e,0,0,0,0,1),this}makeRotationY(t){let e=Math.cos(t),n=Math.sin(t);return this.set(e,0,n,0,0,1,0,0,-n,0,e,0,0,0,0,1),this}makeRotationZ(t){let e=Math.cos(t),n=Math.sin(t);return this.set(e,-n,0,0,n,e,0,0,0,0,1,0,0,0,0,1),this}makeRotationAxis(t,e){let n=Math.cos(e),s=Math.sin(e),r=1-n,o=t.x,a=t.y,l=t.z,c=r*o,u=r*a;return this.set(c*o+n,c*a-s*l,c*l+s*a,0,c*a+s*l,u*a+n,u*l-s*o,0,c*l-s*a,u*l+s*o,r*l*l+n,0,0,0,0,1),this}makeScale(t,e,n){return this.set(t,0,0,0,0,e,0,0,0,0,n,0,0,0,0,1),this}makeShear(t,e,n,s,r,o){return this.set(1,n,r,0,t,1,o,0,e,s,1,0,0,0,0,1),this}compose(t,e,n){let s=this.elements,r=e._x,o=e._y,a=e._z,l=e._w,c=r+r,u=o+o,f=a+a,p=r*c,x=r*u,y=r*f,M=o*u,g=o*f,d=a*f,C=l*c,E=l*u,D=l*f,z=n.x,U=n.y,L=n.z;return s[0]=(1-(M+d))*z,s[1]=(x+D)*z,s[2]=(y-E)*z,s[3]=0,s[4]=(x-D)*U,s[5]=(1-(p+d))*U,s[6]=(g+C)*U,s[7]=0,s[8]=(y+E)*L,s[9]=(g-C)*L,s[10]=(1-(p+M))*L,s[11]=0,s[12]=t.x,s[13]=t.y,s[14]=t.z,s[15]=1,this}decompose(t,e,n){let s=this.elements,r=us.set(s[0],s[1],s[2]).length(),o=us.set(s[4],s[5],s[6]).length(),a=us.set(s[8],s[9],s[10]).length();this.determinant()<0&&(r=-r),t.x=s[12],t.y=s[13],t.z=s[14],Pn.copy(this);let c=1/r,u=1/o,f=1/a;return Pn.elements[0]*=c,Pn.elements[1]*=c,Pn.elements[2]*=c,Pn.elements[4]*=u,Pn.elements[5]*=u,Pn.elements[6]*=u,Pn.elements[8]*=f,Pn.elements[9]*=f,Pn.elements[10]*=f,e.setFromRotationMatrix(Pn),n.x=r,n.y=o,n.z=a,this}makePerspective(t,e,n,s,r,o,a=ii){let l=this.elements,c=2*r/(e-t),u=2*r/(n-s),f=(e+t)/(e-t),p=(n+s)/(n-s),x,y;if(a===ii)x=-(o+r)/(o-r),y=-2*o*r/(o-r);else if(a===da)x=-o/(o-r),y=-o*r/(o-r);else throw new Error("THREE.Matrix4.makePerspective(): Invalid coordinate system: "+a);return l[0]=c,l[4]=0,l[8]=f,l[12]=0,l[1]=0,l[5]=u,l[9]=p,l[13]=0,l[2]=0,l[6]=0,l[10]=x,l[14]=y,l[3]=0,l[7]=0,l[11]=-1,l[15]=0,this}makeOrthographic(t,e,n,s,r,o,a=ii){let l=this.elements,c=1/(e-t),u=1/(n-s),f=1/(o-r),p=(e+t)*c,x=(n+s)*u,y,M;if(a===ii)y=(o+r)*f,M=-2*f;else if(a===da)y=r*f,M=-1*f;else throw new Error("THREE.Matrix4.makeOrthographic(): Invalid coordinate system: "+a);return l[0]=2*c,l[4]=0,l[8]=0,l[12]=-p,l[1]=0,l[5]=2*u,l[9]=0,l[13]=-x,l[2]=0,l[6]=0,l[10]=M,l[14]=-y,l[3]=0,l[7]=0,l[11]=0,l[15]=1,this}equals(t){let e=this.elements,n=t.elements;for(let s=0;s<16;s++)if(e[s]!==n[s])return!1;return!0}fromArray(t,e=0){for(let n=0;n<16;n++)this.elements[n]=t[n+e];return this}toArray(t=[],e=0){let n=this.elements;return t[e]=n[0],t[e+1]=n[1],t[e+2]=n[2],t[e+3]=n[3],t[e+4]=n[4],t[e+5]=n[5],t[e+6]=n[6],t[e+7]=n[7],t[e+8]=n[8],t[e+9]=n[9],t[e+10]=n[10],t[e+11]=n[11],t[e+12]=n[12],t[e+13]=n[13],t[e+14]=n[14],t[e+15]=n[15],t}},us=new B,Pn=new ve,qd=new B(0,0,0),Zd=new B(1,1,1),mi=new B,kr=new B,pn=new B,$c=new ve,Kc=new On,_a=class i{constructor(t=0,e=0,n=0,s=i.DEFAULT_ORDER){this.isEuler=!0,this._x=t,this._y=e,this._z=n,this._order=s}get x(){return this._x}set x(t){this._x=t,this._onChangeCallback()}get y(){return this._y}set y(t){this._y=t,this._onChangeCallback()}get z(){return this._z}set z(t){this._z=t,this._onChangeCallback()}get order(){return this._order}set order(t){this._order=t,this._onChangeCallback()}set(t,e,n,s=this._order){return this._x=t,this._y=e,this._z=n,this._order=s,this._onChangeCallback(),this}clone(){return new this.constructor(this._x,this._y,this._z,this._order)}copy(t){return this._x=t._x,this._y=t._y,this._z=t._z,this._order=t._order,this._onChangeCallback(),this}setFromRotationMatrix(t,e=this._order,n=!0){let s=t.elements,r=s[0],o=s[4],a=s[8],l=s[1],c=s[5],u=s[9],f=s[2],p=s[6],x=s[10];switch(e){case"XYZ":this._y=Math.asin(en(a,-1,1)),Math.abs(a)<.9999999?(this._x=Math.atan2(-u,x),this._z=Math.atan2(-o,r)):(this._x=Math.atan2(p,c),this._z=0);break;case"YXZ":this._x=Math.asin(-en(u,-1,1)),Math.abs(u)<.9999999?(this._y=Math.atan2(a,x),this._z=Math.atan2(l,c)):(this._y=Math.atan2(-f,r),this._z=0);break;case"ZXY":this._x=Math.asin(en(p,-1,1)),Math.abs(p)<.9999999?(this._y=Math.atan2(-f,x),this._z=Math.atan2(-o,c)):(this._y=0,this._z=Math.atan2(l,r));break;case"ZYX":this._y=Math.asin(-en(f,-1,1)),Math.abs(f)<.9999999?(this._x=Math.atan2(p,x),this._z=Math.atan2(l,r)):(this._x=0,this._z=Math.atan2(-o,c));break;case"YZX":this._z=Math.asin(en(l,-1,1)),Math.abs(l)<.9999999?(this._x=Math.atan2(-u,c),this._y=Math.atan2(-f,r)):(this._x=0,this._y=Math.atan2(a,x));break;case"XZY":this._z=Math.asin(-en(o,-1,1)),Math.abs(o)<.9999999?(this._x=Math.atan2(p,c),this._y=Math.atan2(a,r)):(this._x=Math.atan2(-u,x),this._y=0);break;default:console.warn("THREE.Euler: .setFromRotationMatrix() encountered an unknown order: "+e)}return this._order=e,n===!0&&this._onChangeCallback(),this}setFromQuaternion(t,e,n){return $c.makeRotationFromQuaternion(t),this.setFromRotationMatrix($c,e,n)}setFromVector3(t,e=this._order){return this.set(t.x,t.y,t.z,e)}reorder(t){return Kc.setFromEuler(this),this.setFromQuaternion(Kc,t)}equals(t){return t._x===this._x&&t._y===this._y&&t._z===this._z&&t._order===this._order}fromArray(t){return this._x=t[0],this._y=t[1],this._z=t[2],t[3]!==void 0&&(this._order=t[3]),this._onChangeCallback(),this}toArray(t=[],e=0){return t[e]=this._x,t[e+1]=this._y,t[e+2]=this._z,t[e+3]=this._order,t}_onChange(t){return this._onChangeCallback=t,this}_onChangeCallback(){}*[Symbol.iterator](){yield this._x,yield this._y,yield this._z,yield this._order}};_a.DEFAULT_ORDER="XYZ";var fr=class{constructor(){this.mask=1}set(t){this.mask=(1<<t|0)>>>0}enable(t){this.mask|=1<<t|0}enableAll(){this.mask=-1}toggle(t){this.mask^=1<<t|0}disable(t){this.mask&=~(1<<t|0)}disableAll(){this.mask=0}test(t){return(this.mask&t.mask)!==0}isEnabled(t){return(this.mask&(1<<t|0))!==0}},Jd=0,Qc=new B,ds=new On,Qn=new ve,Hr=new B,er=new B,jd=new B,$d=new On,th=new B(1,0,0),eh=new B(0,1,0),nh=new B(0,0,1),Kd={type:"added"},Qd={type:"removed"},an=class i extends qn{constructor(){super(),this.isObject3D=!0,Object.defineProperty(this,"id",{value:Jd++}),this.uuid=Bs(),this.name="",this.type="Object3D",this.parent=null,this.children=[],this.up=i.DEFAULT_UP.clone();let t=new B,e=new _a,n=new On,s=new B(1,1,1);function r(){n.setFromEuler(e,!1)}function o(){e.setFromQuaternion(n,void 0,!1)}e._onChange(r),n._onChange(o),Object.defineProperties(this,{position:{configurable:!0,enumerable:!0,value:t},rotation:{configurable:!0,enumerable:!0,value:e},quaternion:{configurable:!0,enumerable:!0,value:n},scale:{configurable:!0,enumerable:!0,value:s},modelViewMatrix:{value:new ve},normalMatrix:{value:new oe}}),this.matrix=new ve,this.matrixWorld=new ve,this.matrixAutoUpdate=i.DEFAULT_MATRIX_AUTO_UPDATE,this.matrixWorldAutoUpdate=i.DEFAULT_MATRIX_WORLD_AUTO_UPDATE,this.matrixWorldNeedsUpdate=!1,this.layers=new fr,this.visible=!0,this.castShadow=!1,this.receiveShadow=!1,this.frustumCulled=!0,this.renderOrder=0,this.animations=[],this.userData={}}onBeforeShadow(){}onAfterShadow(){}onBeforeRender(){}onAfterRender(){}applyMatrix4(t){this.matrixAutoUpdate&&this.updateMatrix(),this.matrix.premultiply(t),this.matrix.decompose(this.position,this.quaternion,this.scale)}applyQuaternion(t){return this.quaternion.premultiply(t),this}setRotationFromAxisAngle(t,e){this.quaternion.setFromAxisAngle(t,e)}setRotationFromEuler(t){this.quaternion.setFromEuler(t,!0)}setRotationFromMatrix(t){this.quaternion.setFromRotationMatrix(t)}setRotationFromQuaternion(t){this.quaternion.copy(t)}rotateOnAxis(t,e){return ds.setFromAxisAngle(t,e),this.quaternion.multiply(ds),this}rotateOnWorldAxis(t,e){return ds.setFromAxisAngle(t,e),this.quaternion.premultiply(ds),this}rotateX(t){return this.rotateOnAxis(th,t)}rotateY(t){return this.rotateOnAxis(eh,t)}rotateZ(t){return this.rotateOnAxis(nh,t)}translateOnAxis(t,e){return Qc.copy(t).applyQuaternion(this.quaternion),this.position.add(Qc.multiplyScalar(e)),this}translateX(t){return this.translateOnAxis(th,t)}translateY(t){return this.translateOnAxis(eh,t)}translateZ(t){return this.translateOnAxis(nh,t)}localToWorld(t){return this.updateWorldMatrix(!0,!1),t.applyMatrix4(this.matrixWorld)}worldToLocal(t){return this.updateWorldMatrix(!0,!1),t.applyMatrix4(Qn.copy(this.matrixWorld).invert())}lookAt(t,e,n){t.isVector3?Hr.copy(t):Hr.set(t,e,n);let s=this.parent;this.updateWorldMatrix(!0,!1),er.setFromMatrixPosition(this.matrixWorld),this.isCamera||this.isLight?Qn.lookAt(er,Hr,this.up):Qn.lookAt(Hr,er,this.up),this.quaternion.setFromRotationMatrix(Qn),s&&(Qn.extractRotation(s.matrixWorld),ds.setFromRotationMatrix(Qn),this.quaternion.premultiply(ds.invert()))}add(t){if(arguments.length>1){for(let e=0;e<arguments.length;e++)this.add(arguments[e]);return this}return t===this?(console.error("THREE.Object3D.add: object can't be added as a child of itself.",t),this):(t&&t.isObject3D?(t.parent!==null&&t.parent.remove(t),t.parent=this,this.children.push(t),t.dispatchEvent(Kd)):console.error("THREE.Object3D.add: object not an instance of THREE.Object3D.",t),this)}remove(t){if(arguments.length>1){for(let n=0;n<arguments.length;n++)this.remove(arguments[n]);return this}let e=this.children.indexOf(t);return e!==-1&&(t.parent=null,this.children.splice(e,1),t.dispatchEvent(Qd)),this}removeFromParent(){let t=this.parent;return t!==null&&t.remove(this),this}clear(){return this.remove(...this.children)}attach(t){return this.updateWorldMatrix(!0,!1),Qn.copy(this.matrixWorld).invert(),t.parent!==null&&(t.parent.updateWorldMatrix(!0,!1),Qn.multiply(t.parent.matrixWorld)),t.applyMatrix4(Qn),this.add(t),t.updateWorldMatrix(!1,!0),this}getObjectById(t){return this.getObjectByProperty("id",t)}getObjectByName(t){return this.getObjectByProperty("name",t)}getObjectByProperty(t,e){if(this[t]===e)return this;for(let n=0,s=this.children.length;n<s;n++){let o=this.children[n].getObjectByProperty(t,e);if(o!==void 0)return o}}getObjectsByProperty(t,e,n=[]){this[t]===e&&n.push(this);let s=this.children;for(let r=0,o=s.length;r<o;r++)s[r].getObjectsByProperty(t,e,n);return n}getWorldPosition(t){return this.updateWorldMatrix(!0,!1),t.setFromMatrixPosition(this.matrixWorld)}getWorldQuaternion(t){return this.updateWorldMatrix(!0,!1),this.matrixWorld.decompose(er,t,jd),t}getWorldScale(t){return this.updateWorldMatrix(!0,!1),this.matrixWorld.decompose(er,$d,t),t}getWorldDirection(t){this.updateWorldMatrix(!0,!1);let e=this.matrixWorld.elements;return t.set(e[8],e[9],e[10]).normalize()}raycast(){}traverse(t){t(this);let e=this.children;for(let n=0,s=e.length;n<s;n++)e[n].traverse(t)}traverseVisible(t){if(this.visible===!1)return;t(this);let e=this.children;for(let n=0,s=e.length;n<s;n++)e[n].traverseVisible(t)}traverseAncestors(t){let e=this.parent;e!==null&&(t(e),e.traverseAncestors(t))}updateMatrix(){this.matrix.compose(this.position,this.quaternion,this.scale),this.matrixWorldNeedsUpdate=!0}updateMatrixWorld(t){this.matrixAutoUpdate&&this.updateMatrix(),(this.matrixWorldNeedsUpdate||t)&&(this.parent===null?this.matrixWorld.copy(this.matrix):this.matrixWorld.multiplyMatrices(this.parent.matrixWorld,this.matrix),this.matrixWorldNeedsUpdate=!1,t=!0);let e=this.children;for(let n=0,s=e.length;n<s;n++){let r=e[n];(r.matrixWorldAutoUpdate===!0||t===!0)&&r.updateMatrixWorld(t)}}updateWorldMatrix(t,e){let n=this.parent;if(t===!0&&n!==null&&n.matrixWorldAutoUpdate===!0&&n.updateWorldMatrix(!0,!1),this.matrixAutoUpdate&&this.updateMatrix(),this.parent===null?this.matrixWorld.copy(this.matrix):this.matrixWorld.multiplyMatrices(this.parent.matrixWorld,this.matrix),e===!0){let s=this.children;for(let r=0,o=s.length;r<o;r++){let a=s[r];a.matrixWorldAutoUpdate===!0&&a.updateWorldMatrix(!1,!0)}}}toJSON(t){let e=t===void 0||typeof t=="string",n={};e&&(t={geometries:{},materials:{},textures:{},images:{},shapes:{},skeletons:{},animations:{},nodes:{}},n.metadata={version:4.6,type:"Object",generator:"Object3D.toJSON"});let s={};s.uuid=this.uuid,s.type=this.type,this.name!==""&&(s.name=this.name),this.castShadow===!0&&(s.castShadow=!0),this.receiveShadow===!0&&(s.receiveShadow=!0),this.visible===!1&&(s.visible=!1),this.frustumCulled===!1&&(s.frustumCulled=!1),this.renderOrder!==0&&(s.renderOrder=this.renderOrder),Object.keys(this.userData).length>0&&(s.userData=this.userData),s.layers=this.layers.mask,s.matrix=this.matrix.toArray(),s.up=this.up.toArray(),this.matrixAutoUpdate===!1&&(s.matrixAutoUpdate=!1),this.isInstancedMesh&&(s.type="InstancedMesh",s.count=this.count,s.instanceMatrix=this.instanceMatrix.toJSON(),this.instanceColor!==null&&(s.instanceColor=this.instanceColor.toJSON())),this.isBatchedMesh&&(s.type="BatchedMesh",s.perObjectFrustumCulled=this.perObjectFrustumCulled,s.sortObjects=this.sortObjects,s.drawRanges=this._drawRanges,s.reservedRanges=this._reservedRanges,s.visibility=this._visibility,s.active=this._active,s.bounds=this._bounds.map(a=>({boxInitialized:a.boxInitialized,boxMin:a.box.min.toArray(),boxMax:a.box.max.toArray(),sphereInitialized:a.sphereInitialized,sphereRadius:a.sphere.radius,sphereCenter:a.sphere.center.toArray()})),s.maxGeometryCount=this._maxGeometryCount,s.maxVertexCount=this._maxVertexCount,s.maxIndexCount=this._maxIndexCount,s.geometryInitialized=this._geometryInitialized,s.geometryCount=this._geometryCount,s.matricesTexture=this._matricesTexture.toJSON(t),this.boundingSphere!==null&&(s.boundingSphere={center:s.boundingSphere.center.toArray(),radius:s.boundingSphere.radius}),this.boundingBox!==null&&(s.boundingBox={min:s.boundingBox.min.toArray(),max:s.boundingBox.max.toArray()}));function r(a,l){return a[l.uuid]===void 0&&(a[l.uuid]=l.toJSON(t)),l.uuid}if(this.isScene)this.background&&(this.background.isColor?s.background=this.background.toJSON():this.background.isTexture&&(s.background=this.background.toJSON(t).uuid)),this.environment&&this.environment.isTexture&&this.environment.isRenderTargetTexture!==!0&&(s.environment=this.environment.toJSON(t).uuid);else if(this.isMesh||this.isLine||this.isPoints){s.geometry=r(t.geometries,this.geometry);let a=this.geometry.parameters;if(a!==void 0&&a.shapes!==void 0){let l=a.shapes;if(Array.isArray(l))for(let c=0,u=l.length;c<u;c++){let f=l[c];r(t.shapes,f)}else r(t.shapes,l)}}if(this.isSkinnedMesh&&(s.bindMode=this.bindMode,s.bindMatrix=this.bindMatrix.toArray(),this.skeleton!==void 0&&(r(t.skeletons,this.skeleton),s.skeleton=this.skeleton.uuid)),this.material!==void 0)if(Array.isArray(this.material)){let a=[];for(let l=0,c=this.material.length;l<c;l++)a.push(r(t.materials,this.material[l]));s.material=a}else s.material=r(t.materials,this.material);if(this.children.length>0){s.children=[];for(let a=0;a<this.children.length;a++)s.children.push(this.children[a].toJSON(t).object)}if(this.animations.length>0){s.animations=[];for(let a=0;a<this.animations.length;a++){let l=this.animations[a];s.animations.push(r(t.animations,l))}}if(e){let a=o(t.geometries),l=o(t.materials),c=o(t.textures),u=o(t.images),f=o(t.shapes),p=o(t.skeletons),x=o(t.animations),y=o(t.nodes);a.length>0&&(n.geometries=a),l.length>0&&(n.materials=l),c.length>0&&(n.textures=c),u.length>0&&(n.images=u),f.length>0&&(n.shapes=f),p.length>0&&(n.skeletons=p),x.length>0&&(n.animations=x),y.length>0&&(n.nodes=y)}return n.object=s,n;function o(a){let l=[];for(let c in a){let u=a[c];delete u.metadata,l.push(u)}return l}}clone(t){return new this.constructor().copy(this,t)}copy(t,e=!0){if(this.name=t.name,this.up.copy(t.up),this.position.copy(t.position),this.rotation.order=t.rotation.order,this.quaternion.copy(t.quaternion),this.scale.copy(t.scale),this.matrix.copy(t.matrix),this.matrixWorld.copy(t.matrixWorld),this.matrixAutoUpdate=t.matrixAutoUpdate,this.matrixWorldAutoUpdate=t.matrixWorldAutoUpdate,this.matrixWorldNeedsUpdate=t.matrixWorldNeedsUpdate,this.layers.mask=t.layers.mask,this.visible=t.visible,this.castShadow=t.castShadow,this.receiveShadow=t.receiveShadow,this.frustumCulled=t.frustumCulled,this.renderOrder=t.renderOrder,this.animations=t.animations.slice(),this.userData=JSON.parse(JSON.stringify(t.userData)),e===!0)for(let n=0;n<t.children.length;n++){let s=t.children[n];this.add(s.clone())}return this}};an.DEFAULT_UP=new B(0,1,0);an.DEFAULT_MATRIX_AUTO_UPDATE=!0;an.DEFAULT_MATRIX_WORLD_AUTO_UPDATE=!0;var Ln=new B,ti=new B,Ao=new B,ei=new B,fs=new B,ps=new B,ih=new B,Co=new B,Ro=new B,Po=new B,Vr=!1,ws=class i{constructor(t=new B,e=new B,n=new B){this.a=t,this.b=e,this.c=n}static getNormal(t,e,n,s){s.subVectors(n,e),Ln.subVectors(t,e),s.cross(Ln);let r=s.lengthSq();return r>0?s.multiplyScalar(1/Math.sqrt(r)):s.set(0,0,0)}static getBarycoord(t,e,n,s,r){Ln.subVectors(s,e),ti.subVectors(n,e),Ao.subVectors(t,e);let o=Ln.dot(Ln),a=Ln.dot(ti),l=Ln.dot(Ao),c=ti.dot(ti),u=ti.dot(Ao),f=o*c-a*a;if(f===0)return r.set(0,0,0),null;let p=1/f,x=(c*l-a*u)*p,y=(o*u-a*l)*p;return r.set(1-x-y,y,x)}static containsPoint(t,e,n,s){return this.getBarycoord(t,e,n,s,ei)===null?!1:ei.x>=0&&ei.y>=0&&ei.x+ei.y<=1}static getUV(t,e,n,s,r,o,a,l){return Vr===!1&&(console.warn("THREE.Triangle.getUV() has been renamed to THREE.Triangle.getInterpolation()."),Vr=!0),this.getInterpolation(t,e,n,s,r,o,a,l)}static getInterpolation(t,e,n,s,r,o,a,l){return this.getBarycoord(t,e,n,s,ei)===null?(l.x=0,l.y=0,"z"in l&&(l.z=0),"w"in l&&(l.w=0),null):(l.setScalar(0),l.addScaledVector(r,ei.x),l.addScaledVector(o,ei.y),l.addScaledVector(a,ei.z),l)}static isFrontFacing(t,e,n,s){return Ln.subVectors(n,e),ti.subVectors(t,e),Ln.cross(ti).dot(s)<0}set(t,e,n){return this.a.copy(t),this.b.copy(e),this.c.copy(n),this}setFromPointsAndIndices(t,e,n,s){return this.a.copy(t[e]),this.b.copy(t[n]),this.c.copy(t[s]),this}setFromAttributeAndIndices(t,e,n,s){return this.a.fromBufferAttribute(t,e),this.b.fromBufferAttribute(t,n),this.c.fromBufferAttribute(t,s),this}clone(){return new this.constructor().copy(this)}copy(t){return this.a.copy(t.a),this.b.copy(t.b),this.c.copy(t.c),this}getArea(){return Ln.subVectors(this.c,this.b),ti.subVectors(this.a,this.b),Ln.cross(ti).length()*.5}getMidpoint(t){return t.addVectors(this.a,this.b).add(this.c).multiplyScalar(1/3)}getNormal(t){return i.getNormal(this.a,this.b,this.c,t)}getPlane(t){return t.setFromCoplanarPoints(this.a,this.b,this.c)}getBarycoord(t,e){return i.getBarycoord(t,this.a,this.b,this.c,e)}getUV(t,e,n,s,r){return Vr===!1&&(console.warn("THREE.Triangle.getUV() has been renamed to THREE.Triangle.getInterpolation()."),Vr=!0),i.getInterpolation(t,this.a,this.b,this.c,e,n,s,r)}getInterpolation(t,e,n,s,r){return i.getInterpolation(t,this.a,this.b,this.c,e,n,s,r)}containsPoint(t){return i.containsPoint(t,this.a,this.b,this.c)}isFrontFacing(t){return i.isFrontFacing(this.a,this.b,this.c,t)}intersectsBox(t){return t.intersectsTriangle(this)}closestPointToPoint(t,e){let n=this.a,s=this.b,r=this.c,o,a;fs.subVectors(s,n),ps.subVectors(r,n),Co.subVectors(t,n);let l=fs.dot(Co),c=ps.dot(Co);if(l<=0&&c<=0)return e.copy(n);Ro.subVectors(t,s);let u=fs.dot(Ro),f=ps.dot(Ro);if(u>=0&&f<=u)return e.copy(s);let p=l*f-u*c;if(p<=0&&l>=0&&u<=0)return o=l/(l-u),e.copy(n).addScaledVector(fs,o);Po.subVectors(t,r);let x=fs.dot(Po),y=ps.dot(Po);if(y>=0&&x<=y)return e.copy(r);let M=x*c-l*y;if(M<=0&&c>=0&&y<=0)return a=c/(c-y),e.copy(n).addScaledVector(ps,a);let g=u*y-x*f;if(g<=0&&f-u>=0&&x-y>=0)return ih.subVectors(r,s),a=(f-u)/(f-u+(x-y)),e.copy(s).addScaledVector(ih,a);let d=1/(g+M+p);return o=M*d,a=p*d,e.copy(n).addScaledVector(fs,o).addScaledVector(ps,a)}equals(t){return t.a.equals(this.a)&&t.b.equals(this.b)&&t.c.equals(this.c)}},tu={aliceblue:15792383,antiquewhite:16444375,aqua:65535,aquamarine:8388564,azure:15794175,beige:16119260,bisque:16770244,black:0,blanchedalmond:16772045,blue:255,blueviolet:9055202,brown:10824234,burlywood:14596231,cadetblue:6266528,chartreuse:8388352,chocolate:13789470,coral:16744272,cornflowerblue:6591981,cornsilk:16775388,crimson:14423100,cyan:65535,darkblue:139,darkcyan:35723,darkgoldenrod:12092939,darkgray:11119017,darkgreen:25600,darkgrey:11119017,darkkhaki:12433259,darkmagenta:9109643,darkolivegreen:5597999,darkorange:16747520,darkorchid:10040012,darkred:9109504,darksalmon:15308410,darkseagreen:9419919,darkslateblue:4734347,darkslategray:3100495,darkslategrey:3100495,darkturquoise:52945,darkviolet:9699539,deeppink:16716947,deepskyblue:49151,dimgray:6908265,dimgrey:6908265,dodgerblue:2003199,firebrick:11674146,floralwhite:16775920,forestgreen:2263842,fuchsia:16711935,gainsboro:14474460,ghostwhite:16316671,gold:16766720,goldenrod:14329120,gray:8421504,green:32768,greenyellow:11403055,grey:8421504,honeydew:15794160,hotpink:16738740,indianred:13458524,indigo:4915330,ivory:16777200,khaki:15787660,lavender:15132410,lavenderblush:16773365,lawngreen:8190976,lemonchiffon:16775885,lightblue:11393254,lightcoral:15761536,lightcyan:14745599,lightgoldenrodyellow:16448210,lightgray:13882323,lightgreen:9498256,lightgrey:13882323,lightpink:16758465,lightsalmon:16752762,lightseagreen:2142890,lightskyblue:8900346,lightslategray:7833753,lightslategrey:7833753,lightsteelblue:11584734,lightyellow:16777184,lime:65280,limegreen:3329330,linen:16445670,magenta:16711935,maroon:8388608,mediumaquamarine:6737322,mediumblue:205,mediumorchid:12211667,mediumpurple:9662683,mediumseagreen:3978097,mediumslateblue:8087790,mediumspringgreen:64154,mediumturquoise:4772300,mediumvioletred:13047173,midnightblue:1644912,mintcream:16121850,mistyrose:16770273,moccasin:16770229,navajowhite:16768685,navy:128,oldlace:16643558,olive:8421376,olivedrab:7048739,orange:16753920,orangered:16729344,orchid:14315734,palegoldenrod:15657130,palegreen:10025880,paleturquoise:11529966,palevioletred:14381203,papayawhip:16773077,peachpuff:16767673,peru:13468991,pink:16761035,plum:14524637,powderblue:11591910,purple:8388736,rebeccapurple:6697881,red:16711680,rosybrown:12357519,royalblue:4286945,saddlebrown:9127187,salmon:16416882,sandybrown:16032864,seagreen:3050327,seashell:16774638,sienna:10506797,silver:12632256,skyblue:8900331,slateblue:6970061,slategray:7372944,slategrey:7372944,snow:16775930,springgreen:65407,steelblue:4620980,tan:13808780,teal:32896,thistle:14204888,tomato:16737095,turquoise:4251856,violet:15631086,wheat:16113331,white:16777215,whitesmoke:16119285,yellow:16776960,yellowgreen:10145074},gi={h:0,s:0,l:0},Gr={h:0,s:0,l:0};function Lo(i,t,e){return e<0&&(e+=1),e>1&&(e-=1),e<1/6?i+(t-i)*6*e:e<1/2?t:e<2/3?i+(t-i)*6*(2/3-e):i}var qt=class{constructor(t,e,n){return this.isColor=!0,this.r=1,this.g=1,this.b=1,this.set(t,e,n)}set(t,e,n){if(e===void 0&&n===void 0){let s=t;s&&s.isColor?this.copy(s):typeof s=="number"?this.setHex(s):typeof s=="string"&&this.setStyle(s)}else this.setRGB(t,e,n);return this}setScalar(t){return this.r=t,this.g=t,this.b=t,this}setHex(t,e=Ce){return t=Math.floor(t),this.r=(t>>16&255)/255,this.g=(t>>8&255)/255,this.b=(t&255)/255,fe.toWorkingColorSpace(this,e),this}setRGB(t,e,n,s=fe.workingColorSpace){return this.r=t,this.g=e,this.b=n,fe.toWorkingColorSpace(this,s),this}setHSL(t,e,n,s=fe.workingColorSpace){if(t=Ll(t,1),e=en(e,0,1),n=en(n,0,1),e===0)this.r=this.g=this.b=n;else{let r=n<=.5?n*(1+e):n+e-n*e,o=2*n-r;this.r=Lo(o,r,t+1/3),this.g=Lo(o,r,t),this.b=Lo(o,r,t-1/3)}return fe.toWorkingColorSpace(this,s),this}setStyle(t,e=Ce){function n(r){r!==void 0&&parseFloat(r)<1&&console.warn("THREE.Color: Alpha component of "+t+" will be ignored.")}let s;if(s=/^(\w+)\(([^\)]*)\)/.exec(t)){let r,o=s[1],a=s[2];switch(o){case"rgb":case"rgba":if(r=/^\s*(\d+)\s*,\s*(\d+)\s*,\s*(\d+)\s*(?:,\s*(\d*\.?\d+)\s*)?$/.exec(a))return n(r[4]),this.setRGB(Math.min(255,parseInt(r[1],10))/255,Math.min(255,parseInt(r[2],10))/255,Math.min(255,parseInt(r[3],10))/255,e);if(r=/^\s*(\d+)\%\s*,\s*(\d+)\%\s*,\s*(\d+)\%\s*(?:,\s*(\d*\.?\d+)\s*)?$/.exec(a))return n(r[4]),this.setRGB(Math.min(100,parseInt(r[1],10))/100,Math.min(100,parseInt(r[2],10))/100,Math.min(100,parseInt(r[3],10))/100,e);break;case"hsl":case"hsla":if(r=/^\s*(\d*\.?\d+)\s*,\s*(\d*\.?\d+)\%\s*,\s*(\d*\.?\d+)\%\s*(?:,\s*(\d*\.?\d+)\s*)?$/.exec(a))return n(r[4]),this.setHSL(parseFloat(r[1])/360,parseFloat(r[2])/100,parseFloat(r[3])/100,e);break;default:console.warn("THREE.Color: Unknown color model "+t)}}else if(s=/^\#([A-Fa-f\d]+)$/.exec(t)){let r=s[1],o=r.length;if(o===3)return this.setRGB(parseInt(r.charAt(0),16)/15,parseInt(r.charAt(1),16)/15,parseInt(r.charAt(2),16)/15,e);if(o===6)return this.setHex(parseInt(r,16),e);console.warn("THREE.Color: Invalid hex color "+t)}else if(t&&t.length>0)return this.setColorName(t,e);return this}setColorName(t,e=Ce){let n=tu[t.toLowerCase()];return n!==void 0?this.setHex(n,e):console.warn("THREE.Color: Unknown color "+t),this}clone(){return new this.constructor(this.r,this.g,this.b)}copy(t){return this.r=t.r,this.g=t.g,this.b=t.b,this}copySRGBToLinear(t){return this.r=As(t.r),this.g=As(t.g),this.b=As(t.b),this}copyLinearToSRGB(t){return this.r=vo(t.r),this.g=vo(t.g),this.b=vo(t.b),this}convertSRGBToLinear(){return this.copySRGBToLinear(this),this}convertLinearToSRGB(){return this.copyLinearToSRGB(this),this}getHex(t=Ce){return fe.fromWorkingColorSpace(tn.copy(this),t),Math.round(en(tn.r*255,0,255))*65536+Math.round(en(tn.g*255,0,255))*256+Math.round(en(tn.b*255,0,255))}getHexString(t=Ce){return("000000"+this.getHex(t).toString(16)).slice(-6)}getHSL(t,e=fe.workingColorSpace){fe.fromWorkingColorSpace(tn.copy(this),e);let n=tn.r,s=tn.g,r=tn.b,o=Math.max(n,s,r),a=Math.min(n,s,r),l,c,u=(a+o)/2;if(a===o)l=0,c=0;else{let f=o-a;switch(c=u<=.5?f/(o+a):f/(2-o-a),o){case n:l=(s-r)/f+(s<r?6:0);break;case s:l=(r-n)/f+2;break;case r:l=(n-s)/f+4;break}l/=6}return t.h=l,t.s=c,t.l=u,t}getRGB(t,e=fe.workingColorSpace){return fe.fromWorkingColorSpace(tn.copy(this),e),t.r=tn.r,t.g=tn.g,t.b=tn.b,t}getStyle(t=Ce){fe.fromWorkingColorSpace(tn.copy(this),t);let e=tn.r,n=tn.g,s=tn.b;return t!==Ce?`color(${t} ${e.toFixed(3)} ${n.toFixed(3)} ${s.toFixed(3)})`:`rgb(${Math.round(e*255)},${Math.round(n*255)},${Math.round(s*255)})`}offsetHSL(t,e,n){return this.getHSL(gi),this.setHSL(gi.h+t,gi.s+e,gi.l+n)}add(t){return this.r+=t.r,this.g+=t.g,this.b+=t.b,this}addColors(t,e){return this.r=t.r+e.r,this.g=t.g+e.g,this.b=t.b+e.b,this}addScalar(t){return this.r+=t,this.g+=t,this.b+=t,this}sub(t){return this.r=Math.max(0,this.r-t.r),this.g=Math.max(0,this.g-t.g),this.b=Math.max(0,this.b-t.b),this}multiply(t){return this.r*=t.r,this.g*=t.g,this.b*=t.b,this}multiplyScalar(t){return this.r*=t,this.g*=t,this.b*=t,this}lerp(t,e){return this.r+=(t.r-this.r)*e,this.g+=(t.g-this.g)*e,this.b+=(t.b-this.b)*e,this}lerpColors(t,e,n){return this.r=t.r+(e.r-t.r)*n,this.g=t.g+(e.g-t.g)*n,this.b=t.b+(e.b-t.b)*n,this}lerpHSL(t,e){this.getHSL(gi),t.getHSL(Gr);let n=or(gi.h,Gr.h,e),s=or(gi.s,Gr.s,e),r=or(gi.l,Gr.l,e);return this.setHSL(n,s,r),this}setFromVector3(t){return this.r=t.x,this.g=t.y,this.b=t.z,this}applyMatrix3(t){let e=this.r,n=this.g,s=this.b,r=t.elements;return this.r=r[0]*e+r[3]*n+r[6]*s,this.g=r[1]*e+r[4]*n+r[7]*s,this.b=r[2]*e+r[5]*n+r[8]*s,this}equals(t){return t.r===this.r&&t.g===this.g&&t.b===this.b}fromArray(t,e=0){return this.r=t[e],this.g=t[e+1],this.b=t[e+2],this}toArray(t=[],e=0){return t[e]=this.r,t[e+1]=this.g,t[e+2]=this.b,t}fromBufferAttribute(t,e){return this.r=t.getX(e),this.g=t.getY(e),this.b=t.getZ(e),this}toJSON(){return this.getHex()}*[Symbol.iterator](){yield this.r,yield this.g,yield this.b}},tn=new qt;qt.NAMES=tu;var tf=0,wi=class extends qn{constructor(){super(),this.isMaterial=!0,Object.defineProperty(this,"id",{value:tf++}),this.uuid=Bs(),this.name="",this.type="Material",this.blending=si,this.side=Mi,this.vertexColors=!1,this.opacity=1,this.transparent=!1,this.alphaHash=!1,this.blendSrc=Vo,this.blendDst=Go,this.blendEquation=ki,this.blendSrcAlpha=null,this.blendDstAlpha=null,this.blendEquationAlpha=null,this.blendColor=new qt(0,0,0),this.blendAlpha=0,this.depthFunc=aa,this.depthTest=!0,this.depthWrite=!0,this.stencilWriteMask=255,this.stencilFunc=Gc,this.stencilRef=0,this.stencilFuncMask=255,this.stencilFail=as,this.stencilZFail=as,this.stencilZPass=as,this.stencilWrite=!1,this.clippingPlanes=null,this.clipIntersection=!1,this.clipShadows=!1,this.shadowSide=null,this.colorWrite=!0,this.precision=null,this.polygonOffset=!1,this.polygonOffsetFactor=0,this.polygonOffsetUnits=0,this.dithering=!1,this.alphaToCoverage=!1,this.premultipliedAlpha=!1,this.forceSinglePass=!1,this.visible=!0,this.toneMapped=!0,this.userData={},this.version=0,this._alphaTest=0}get alphaTest(){return this._alphaTest}set alphaTest(t){this._alphaTest>0!=t>0&&this.version++,this._alphaTest=t}onBuild(){}onBeforeRender(){}onBeforeCompile(){}customProgramCacheKey(){return this.onBeforeCompile.toString()}setValues(t){if(t!==void 0)for(let e in t){let n=t[e];if(n===void 0){console.warn(`THREE.Material: parameter '${e}' has value of undefined.`);continue}let s=this[e];if(s===void 0){console.warn(`THREE.Material: '${e}' is not a property of THREE.${this.type}.`);continue}s&&s.isColor?s.set(n):s&&s.isVector3&&n&&n.isVector3?s.copy(n):this[e]=n}}toJSON(t){let e=t===void 0||typeof t=="string";e&&(t={textures:{},images:{}});let n={metadata:{version:4.6,type:"Material",generator:"Material.toJSON"}};n.uuid=this.uuid,n.type=this.type,this.name!==""&&(n.name=this.name),this.color&&this.color.isColor&&(n.color=this.color.getHex()),this.roughness!==void 0&&(n.roughness=this.roughness),this.metalness!==void 0&&(n.metalness=this.metalness),this.sheen!==void 0&&(n.sheen=this.sheen),this.sheenColor&&this.sheenColor.isColor&&(n.sheenColor=this.sheenColor.getHex()),this.sheenRoughness!==void 0&&(n.sheenRoughness=this.sheenRoughness),this.emissive&&this.emissive.isColor&&(n.emissive=this.emissive.getHex()),this.emissiveIntensity&&this.emissiveIntensity!==1&&(n.emissiveIntensity=this.emissiveIntensity),this.specular&&this.specular.isColor&&(n.specular=this.specular.getHex()),this.specularIntensity!==void 0&&(n.specularIntensity=this.specularIntensity),this.specularColor&&this.specularColor.isColor&&(n.specularColor=this.specularColor.getHex()),this.shininess!==void 0&&(n.shininess=this.shininess),this.clearcoat!==void 0&&(n.clearcoat=this.clearcoat),this.clearcoatRoughness!==void 0&&(n.clearcoatRoughness=this.clearcoatRoughness),this.clearcoatMap&&this.clearcoatMap.isTexture&&(n.clearcoatMap=this.clearcoatMap.toJSON(t).uuid),this.clearcoatRoughnessMap&&this.clearcoatRoughnessMap.isTexture&&(n.clearcoatRoughnessMap=this.clearcoatRoughnessMap.toJSON(t).uuid),this.clearcoatNormalMap&&this.clearcoatNormalMap.isTexture&&(n.clearcoatNormalMap=this.clearcoatNormalMap.toJSON(t).uuid,n.clearcoatNormalScale=this.clearcoatNormalScale.toArray()),this.iridescence!==void 0&&(n.iridescence=this.iridescence),this.iridescenceIOR!==void 0&&(n.iridescenceIOR=this.iridescenceIOR),this.iridescenceThicknessRange!==void 0&&(n.iridescenceThicknessRange=this.iridescenceThicknessRange),this.iridescenceMap&&this.iridescenceMap.isTexture&&(n.iridescenceMap=this.iridescenceMap.toJSON(t).uuid),this.iridescenceThicknessMap&&this.iridescenceThicknessMap.isTexture&&(n.iridescenceThicknessMap=this.iridescenceThicknessMap.toJSON(t).uuid),this.anisotropy!==void 0&&(n.anisotropy=this.anisotropy),this.anisotropyRotation!==void 0&&(n.anisotropyRotation=this.anisotropyRotation),this.anisotropyMap&&this.anisotropyMap.isTexture&&(n.anisotropyMap=this.anisotropyMap.toJSON(t).uuid),this.map&&this.map.isTexture&&(n.map=this.map.toJSON(t).uuid),this.matcap&&this.matcap.isTexture&&(n.matcap=this.matcap.toJSON(t).uuid),this.alphaMap&&this.alphaMap.isTexture&&(n.alphaMap=this.alphaMap.toJSON(t).uuid),this.lightMap&&this.lightMap.isTexture&&(n.lightMap=this.lightMap.toJSON(t).uuid,n.lightMapIntensity=this.lightMapIntensity),this.aoMap&&this.aoMap.isTexture&&(n.aoMap=this.aoMap.toJSON(t).uuid,n.aoMapIntensity=this.aoMapIntensity),this.bumpMap&&this.bumpMap.isTexture&&(n.bumpMap=this.bumpMap.toJSON(t).uuid,n.bumpScale=this.bumpScale),this.normalMap&&this.normalMap.isTexture&&(n.normalMap=this.normalMap.toJSON(t).uuid,n.normalMapType=this.normalMapType,n.normalScale=this.normalScale.toArray()),this.displacementMap&&this.displacementMap.isTexture&&(n.displacementMap=this.displacementMap.toJSON(t).uuid,n.displacementScale=this.displacementScale,n.displacementBias=this.displacementBias),this.roughnessMap&&this.roughnessMap.isTexture&&(n.roughnessMap=this.roughnessMap.toJSON(t).uuid),this.metalnessMap&&this.metalnessMap.isTexture&&(n.metalnessMap=this.metalnessMap.toJSON(t).uuid),this.emissiveMap&&this.emissiveMap.isTexture&&(n.emissiveMap=this.emissiveMap.toJSON(t).uuid),this.specularMap&&this.specularMap.isTexture&&(n.specularMap=this.specularMap.toJSON(t).uuid),this.specularIntensityMap&&this.specularIntensityMap.isTexture&&(n.specularIntensityMap=this.specularIntensityMap.toJSON(t).uuid),this.specularColorMap&&this.specularColorMap.isTexture&&(n.specularColorMap=this.specularColorMap.toJSON(t).uuid),this.envMap&&this.envMap.isTexture&&(n.envMap=this.envMap.toJSON(t).uuid,this.combine!==void 0&&(n.combine=this.combine)),this.envMapIntensity!==void 0&&(n.envMapIntensity=this.envMapIntensity),this.reflectivity!==void 0&&(n.reflectivity=this.reflectivity),this.refractionRatio!==void 0&&(n.refractionRatio=this.refractionRatio),this.gradientMap&&this.gradientMap.isTexture&&(n.gradientMap=this.gradientMap.toJSON(t).uuid),this.transmission!==void 0&&(n.transmission=this.transmission),this.transmissionMap&&this.transmissionMap.isTexture&&(n.transmissionMap=this.transmissionMap.toJSON(t).uuid),this.thickness!==void 0&&(n.thickness=this.thickness),this.thicknessMap&&this.thicknessMap.isTexture&&(n.thicknessMap=this.thicknessMap.toJSON(t).uuid),this.attenuationDistance!==void 0&&this.attenuationDistance!==1/0&&(n.attenuationDistance=this.attenuationDistance),this.attenuationColor!==void 0&&(n.attenuationColor=this.attenuationColor.getHex()),this.size!==void 0&&(n.size=this.size),this.shadowSide!==null&&(n.shadowSide=this.shadowSide),this.sizeAttenuation!==void 0&&(n.sizeAttenuation=this.sizeAttenuation),this.blending!==si&&(n.blending=this.blending),this.side!==Mi&&(n.side=this.side),this.vertexColors===!0&&(n.vertexColors=!0),this.opacity<1&&(n.opacity=this.opacity),this.transparent===!0&&(n.transparent=!0),this.blendSrc!==Vo&&(n.blendSrc=this.blendSrc),this.blendDst!==Go&&(n.blendDst=this.blendDst),this.blendEquation!==ki&&(n.blendEquation=this.blendEquation),this.blendSrcAlpha!==null&&(n.blendSrcAlpha=this.blendSrcAlpha),this.blendDstAlpha!==null&&(n.blendDstAlpha=this.blendDstAlpha),this.blendEquationAlpha!==null&&(n.blendEquationAlpha=this.blendEquationAlpha),this.blendColor&&this.blendColor.isColor&&(n.blendColor=this.blendColor.getHex()),this.blendAlpha!==0&&(n.blendAlpha=this.blendAlpha),this.depthFunc!==aa&&(n.depthFunc=this.depthFunc),this.depthTest===!1&&(n.depthTest=this.depthTest),this.depthWrite===!1&&(n.depthWrite=this.depthWrite),this.colorWrite===!1&&(n.colorWrite=this.colorWrite),this.stencilWriteMask!==255&&(n.stencilWriteMask=this.stencilWriteMask),this.stencilFunc!==Gc&&(n.stencilFunc=this.stencilFunc),this.stencilRef!==0&&(n.stencilRef=this.stencilRef),this.stencilFuncMask!==255&&(n.stencilFuncMask=this.stencilFuncMask),this.stencilFail!==as&&(n.stencilFail=this.stencilFail),this.stencilZFail!==as&&(n.stencilZFail=this.stencilZFail),this.stencilZPass!==as&&(n.stencilZPass=this.stencilZPass),this.stencilWrite===!0&&(n.stencilWrite=this.stencilWrite),this.rotation!==void 0&&this.rotation!==0&&(n.rotation=this.rotation),this.polygonOffset===!0&&(n.polygonOffset=!0),this.polygonOffsetFactor!==0&&(n.polygonOffsetFactor=this.polygonOffsetFactor),this.polygonOffsetUnits!==0&&(n.polygonOffsetUnits=this.polygonOffsetUnits),this.linewidth!==void 0&&this.linewidth!==1&&(n.linewidth=this.linewidth),this.dashSize!==void 0&&(n.dashSize=this.dashSize),this.gapSize!==void 0&&(n.gapSize=this.gapSize),this.scale!==void 0&&(n.scale=this.scale),this.dithering===!0&&(n.dithering=!0),this.alphaTest>0&&(n.alphaTest=this.alphaTest),this.alphaHash===!0&&(n.alphaHash=!0),this.alphaToCoverage===!0&&(n.alphaToCoverage=!0),this.premultipliedAlpha===!0&&(n.premultipliedAlpha=!0),this.forceSinglePass===!0&&(n.forceSinglePass=!0),this.wireframe===!0&&(n.wireframe=!0),this.wireframeLinewidth>1&&(n.wireframeLinewidth=this.wireframeLinewidth),this.wireframeLinecap!=="round"&&(n.wireframeLinecap=this.wireframeLinecap),this.wireframeLinejoin!=="round"&&(n.wireframeLinejoin=this.wireframeLinejoin),this.flatShading===!0&&(n.flatShading=!0),this.visible===!1&&(n.visible=!1),this.toneMapped===!1&&(n.toneMapped=!1),this.fog===!1&&(n.fog=!1),Object.keys(this.userData).length>0&&(n.userData=this.userData);function s(r){let o=[];for(let a in r){let l=r[a];delete l.metadata,o.push(l)}return o}if(e){let r=s(t.textures),o=s(t.images);r.length>0&&(n.textures=r),o.length>0&&(n.images=o)}return n}clone(){return new this.constructor().copy(this)}copy(t){this.name=t.name,this.blending=t.blending,this.side=t.side,this.vertexColors=t.vertexColors,this.opacity=t.opacity,this.transparent=t.transparent,this.blendSrc=t.blendSrc,this.blendDst=t.blendDst,this.blendEquation=t.blendEquation,this.blendSrcAlpha=t.blendSrcAlpha,this.blendDstAlpha=t.blendDstAlpha,this.blendEquationAlpha=t.blendEquationAlpha,this.blendColor.copy(t.blendColor),this.blendAlpha=t.blendAlpha,this.depthFunc=t.depthFunc,this.depthTest=t.depthTest,this.depthWrite=t.depthWrite,this.stencilWriteMask=t.stencilWriteMask,this.stencilFunc=t.stencilFunc,this.stencilRef=t.stencilRef,this.stencilFuncMask=t.stencilFuncMask,this.stencilFail=t.stencilFail,this.stencilZFail=t.stencilZFail,this.stencilZPass=t.stencilZPass,this.stencilWrite=t.stencilWrite;let e=t.clippingPlanes,n=null;if(e!==null){let s=e.length;n=new Array(s);for(let r=0;r!==s;++r)n[r]=e[r].clone()}return this.clippingPlanes=n,this.clipIntersection=t.clipIntersection,this.clipShadows=t.clipShadows,this.shadowSide=t.shadowSide,this.colorWrite=t.colorWrite,this.precision=t.precision,this.polygonOffset=t.polygonOffset,this.polygonOffsetFactor=t.polygonOffsetFactor,this.polygonOffsetUnits=t.polygonOffsetUnits,this.dithering=t.dithering,this.alphaTest=t.alphaTest,this.alphaHash=t.alphaHash,this.alphaToCoverage=t.alphaToCoverage,this.premultipliedAlpha=t.premultipliedAlpha,this.forceSinglePass=t.forceSinglePass,this.visible=t.visible,this.toneMapped=t.toneMapped,this.userData=JSON.parse(JSON.stringify(t.userData)),this}dispose(){this.dispatchEvent({type:"dispose"})}set needsUpdate(t){t===!0&&this.version++}},xn=class extends wi{constructor(t){super(),this.isMeshBasicMaterial=!0,this.type="MeshBasicMaterial",this.color=new qt(16777215),this.map=null,this.lightMap=null,this.lightMapIntensity=1,this.aoMap=null,this.aoMapIntensity=1,this.specularMap=null,this.alphaMap=null,this.envMap=null,this.combine=kh,this.reflectivity=1,this.refractionRatio=.98,this.wireframe=!1,this.wireframeLinewidth=1,this.wireframeLinecap="round",this.wireframeLinejoin="round",this.fog=!0,this.setValues(t)}copy(t){return super.copy(t),this.color.copy(t.color),this.map=t.map,this.lightMap=t.lightMap,this.lightMapIntensity=t.lightMapIntensity,this.aoMap=t.aoMap,this.aoMapIntensity=t.aoMapIntensity,this.specularMap=t.specularMap,this.alphaMap=t.alphaMap,this.envMap=t.envMap,this.combine=t.combine,this.reflectivity=t.reflectivity,this.refractionRatio=t.refractionRatio,this.wireframe=t.wireframe,this.wireframeLinewidth=t.wireframeLinewidth,this.wireframeLinecap=t.wireframeLinecap,this.wireframeLinejoin=t.wireframeLinejoin,this.fog=t.fog,this}};var Ue=new B,Wr=new Lt,rn=class{constructor(t,e,n=!1){if(Array.isArray(t))throw new TypeError("THREE.BufferAttribute: array should be a Typed Array.");this.isBufferAttribute=!0,this.name="",this.array=t,this.itemSize=e,this.count=t!==void 0?t.length/e:0,this.normalized=n,this.usage=Wc,this._updateRange={offset:0,count:-1},this.updateRanges=[],this.gpuType=_i,this.version=0}onUploadCallback(){}set needsUpdate(t){t===!0&&this.version++}get updateRange(){return console.warn("THREE.BufferAttribute: updateRange() is deprecated and will be removed in r169. Use addUpdateRange() instead."),this._updateRange}setUsage(t){return this.usage=t,this}addUpdateRange(t,e){this.updateRanges.push({start:t,count:e})}clearUpdateRanges(){this.updateRanges.length=0}copy(t){return this.name=t.name,this.array=new t.array.constructor(t.array),this.itemSize=t.itemSize,this.count=t.count,this.normalized=t.normalized,this.usage=t.usage,this.gpuType=t.gpuType,this}copyAt(t,e,n){t*=this.itemSize,n*=e.itemSize;for(let s=0,r=this.itemSize;s<r;s++)this.array[t+s]=e.array[n+s];return this}copyArray(t){return this.array.set(t),this}applyMatrix3(t){if(this.itemSize===2)for(let e=0,n=this.count;e<n;e++)Wr.fromBufferAttribute(this,e),Wr.applyMatrix3(t),this.setXY(e,Wr.x,Wr.y);else if(this.itemSize===3)for(let e=0,n=this.count;e<n;e++)Ue.fromBufferAttribute(this,e),Ue.applyMatrix3(t),this.setXYZ(e,Ue.x,Ue.y,Ue.z);return this}applyMatrix4(t){for(let e=0,n=this.count;e<n;e++)Ue.fromBufferAttribute(this,e),Ue.applyMatrix4(t),this.setXYZ(e,Ue.x,Ue.y,Ue.z);return this}applyNormalMatrix(t){for(let e=0,n=this.count;e<n;e++)Ue.fromBufferAttribute(this,e),Ue.applyNormalMatrix(t),this.setXYZ(e,Ue.x,Ue.y,Ue.z);return this}transformDirection(t){for(let e=0,n=this.count;e<n;e++)Ue.fromBufferAttribute(this,e),Ue.transformDirection(t),this.setXYZ(e,Ue.x,Ue.y,Ue.z);return this}set(t,e=0){return this.array.set(t,e),this}getComponent(t,e){let n=this.array[t*this.itemSize+e];return this.normalized&&(n=Ss(n,this.array)),n}setComponent(t,e,n){return this.normalized&&(n=ln(n,this.array)),this.array[t*this.itemSize+e]=n,this}getX(t){let e=this.array[t*this.itemSize];return this.normalized&&(e=Ss(e,this.array)),e}setX(t,e){return this.normalized&&(e=ln(e,this.array)),this.array[t*this.itemSize]=e,this}getY(t){let e=this.array[t*this.itemSize+1];return this.normalized&&(e=Ss(e,this.array)),e}setY(t,e){return this.normalized&&(e=ln(e,this.array)),this.array[t*this.itemSize+1]=e,this}getZ(t){let e=this.array[t*this.itemSize+2];return this.normalized&&(e=Ss(e,this.array)),e}setZ(t,e){return this.normalized&&(e=ln(e,this.array)),this.array[t*this.itemSize+2]=e,this}getW(t){let e=this.array[t*this.itemSize+3];return this.normalized&&(e=Ss(e,this.array)),e}setW(t,e){return this.normalized&&(e=ln(e,this.array)),this.array[t*this.itemSize+3]=e,this}setXY(t,e,n){return t*=this.itemSize,this.normalized&&(e=ln(e,this.array),n=ln(n,this.array)),this.array[t+0]=e,this.array[t+1]=n,this}setXYZ(t,e,n,s){return t*=this.itemSize,this.normalized&&(e=ln(e,this.array),n=ln(n,this.array),s=ln(s,this.array)),this.array[t+0]=e,this.array[t+1]=n,this.array[t+2]=s,this}setXYZW(t,e,n,s,r){return t*=this.itemSize,this.normalized&&(e=ln(e,this.array),n=ln(n,this.array),s=ln(s,this.array),r=ln(r,this.array)),this.array[t+0]=e,this.array[t+1]=n,this.array[t+2]=s,this.array[t+3]=r,this}onUpload(t){return this.onUploadCallback=t,this}clone(){return new this.constructor(this.array,this.itemSize).copy(this)}toJSON(){let t={itemSize:this.itemSize,type:this.array.constructor.name,array:Array.from(this.array),normalized:this.normalized};return this.name!==""&&(t.name=this.name),this.usage!==Wc&&(t.usage=this.usage),t}};var va=class extends rn{constructor(t,e,n){super(new Uint16Array(t),e,n)}};var ya=class extends rn{constructor(t,e,n){super(new Uint32Array(t),e,n)}};var Ze=class extends rn{constructor(t,e,n){super(new Float32Array(t),e,n)}};var ef=0,yn=new ve,Io=new an,ms=new B,mn=new ai,nr=new ai,Ye=new B,hn=class i extends qn{constructor(){super(),this.isBufferGeometry=!0,Object.defineProperty(this,"id",{value:ef++}),this.uuid=Bs(),this.name="",this.type="BufferGeometry",this.index=null,this.attributes={},this.morphAttributes={},this.morphTargetsRelative=!1,this.groups=[],this.boundingBox=null,this.boundingSphere=null,this.drawRange={start:0,count:1/0},this.userData={}}getIndex(){return this.index}setIndex(t){return Array.isArray(t)?this.index=new(Qh(t)?ya:va)(t,1):this.index=t,this}getAttribute(t){return this.attributes[t]}setAttribute(t,e){return this.attributes[t]=e,this}deleteAttribute(t){return delete this.attributes[t],this}hasAttribute(t){return this.attributes[t]!==void 0}addGroup(t,e,n=0){this.groups.push({start:t,count:e,materialIndex:n})}clearGroups(){this.groups=[]}setDrawRange(t,e){this.drawRange.start=t,this.drawRange.count=e}applyMatrix4(t){let e=this.attributes.position;e!==void 0&&(e.applyMatrix4(t),e.needsUpdate=!0);let n=this.attributes.normal;if(n!==void 0){let r=new oe().getNormalMatrix(t);n.applyNormalMatrix(r),n.needsUpdate=!0}let s=this.attributes.tangent;return s!==void 0&&(s.transformDirection(t),s.needsUpdate=!0),this.boundingBox!==null&&this.computeBoundingBox(),this.boundingSphere!==null&&this.computeBoundingSphere(),this}applyQuaternion(t){return yn.makeRotationFromQuaternion(t),this.applyMatrix4(yn),this}rotateX(t){return yn.makeRotationX(t),this.applyMatrix4(yn),this}rotateY(t){return yn.makeRotationY(t),this.applyMatrix4(yn),this}rotateZ(t){return yn.makeRotationZ(t),this.applyMatrix4(yn),this}translate(t,e,n){return yn.makeTranslation(t,e,n),this.applyMatrix4(yn),this}scale(t,e,n){return yn.makeScale(t,e,n),this.applyMatrix4(yn),this}lookAt(t){return Io.lookAt(t),Io.updateMatrix(),this.applyMatrix4(Io.matrix),this}center(){return this.computeBoundingBox(),this.boundingBox.getCenter(ms).negate(),this.translate(ms.x,ms.y,ms.z),this}setFromPoints(t){let e=[];for(let n=0,s=t.length;n<s;n++){let r=t[n];e.push(r.x,r.y,r.z||0)}return this.setAttribute("position",new Ze(e,3)),this}computeBoundingBox(){this.boundingBox===null&&(this.boundingBox=new ai);let t=this.attributes.position,e=this.morphAttributes.position;if(t&&t.isGLBufferAttribute){console.error('THREE.BufferGeometry.computeBoundingBox(): GLBufferAttribute requires a manual bounding box. Alternatively set "mesh.frustumCulled" to "false".',this),this.boundingBox.set(new B(-1/0,-1/0,-1/0),new B(1/0,1/0,1/0));return}if(t!==void 0){if(this.boundingBox.setFromBufferAttribute(t),e)for(let n=0,s=e.length;n<s;n++){let r=e[n];mn.setFromBufferAttribute(r),this.morphTargetsRelative?(Ye.addVectors(this.boundingBox.min,mn.min),this.boundingBox.expandByPoint(Ye),Ye.addVectors(this.boundingBox.max,mn.max),this.boundingBox.expandByPoint(Ye)):(this.boundingBox.expandByPoint(mn.min),this.boundingBox.expandByPoint(mn.max))}}else this.boundingBox.makeEmpty();(isNaN(this.boundingBox.min.x)||isNaN(this.boundingBox.min.y)||isNaN(this.boundingBox.min.z))&&console.error('THREE.BufferGeometry.computeBoundingBox(): Computed min/max have NaN values. The "position" attribute is likely to have NaN values.',this)}computeBoundingSphere(){this.boundingSphere===null&&(this.boundingSphere=new Si);let t=this.attributes.position,e=this.morphAttributes.position;if(t&&t.isGLBufferAttribute){console.error('THREE.BufferGeometry.computeBoundingSphere(): GLBufferAttribute requires a manual bounding sphere. Alternatively set "mesh.frustumCulled" to "false".',this),this.boundingSphere.set(new B,1/0);return}if(t){let n=this.boundingSphere.center;if(mn.setFromBufferAttribute(t),e)for(let r=0,o=e.length;r<o;r++){let a=e[r];nr.setFromBufferAttribute(a),this.morphTargetsRelative?(Ye.addVectors(mn.min,nr.min),mn.expandByPoint(Ye),Ye.addVectors(mn.max,nr.max),mn.expandByPoint(Ye)):(mn.expandByPoint(nr.min),mn.expandByPoint(nr.max))}mn.getCenter(n);let s=0;for(let r=0,o=t.count;r<o;r++)Ye.fromBufferAttribute(t,r),s=Math.max(s,n.distanceToSquared(Ye));if(e)for(let r=0,o=e.length;r<o;r++){let a=e[r],l=this.morphTargetsRelative;for(let c=0,u=a.count;c<u;c++)Ye.fromBufferAttribute(a,c),l&&(ms.fromBufferAttribute(t,c),Ye.add(ms)),s=Math.max(s,n.distanceToSquared(Ye))}this.boundingSphere.radius=Math.sqrt(s),isNaN(this.boundingSphere.radius)&&console.error('THREE.BufferGeometry.computeBoundingSphere(): Computed radius is NaN. The "position" attribute is likely to have NaN values.',this)}}computeTangents(){let t=this.index,e=this.attributes;if(t===null||e.position===void 0||e.normal===void 0||e.uv===void 0){console.error("THREE.BufferGeometry: .computeTangents() failed. Missing required attributes (index, position, normal or uv)");return}let n=t.array,s=e.position.array,r=e.normal.array,o=e.uv.array,a=s.length/3;this.hasAttribute("tangent")===!1&&this.setAttribute("tangent",new rn(new Float32Array(4*a),4));let l=this.getAttribute("tangent").array,c=[],u=[];for(let R=0;R<a;R++)c[R]=new B,u[R]=new B;let f=new B,p=new B,x=new B,y=new Lt,M=new Lt,g=new Lt,d=new B,C=new B;function E(R,V,nt){f.fromArray(s,R*3),p.fromArray(s,V*3),x.fromArray(s,nt*3),y.fromArray(o,R*2),M.fromArray(o,V*2),g.fromArray(o,nt*2),p.sub(f),x.sub(f),M.sub(y),g.sub(y);let ft=1/(M.x*g.y-g.x*M.y);isFinite(ft)&&(d.copy(p).multiplyScalar(g.y).addScaledVector(x,-M.y).multiplyScalar(ft),C.copy(x).multiplyScalar(M.x).addScaledVector(p,-g.x).multiplyScalar(ft),c[R].add(d),c[V].add(d),c[nt].add(d),u[R].add(C),u[V].add(C),u[nt].add(C))}let D=this.groups;D.length===0&&(D=[{start:0,count:n.length}]);for(let R=0,V=D.length;R<V;++R){let nt=D[R],ft=nt.start,I=nt.count;for(let k=ft,$=ft+I;k<$;k+=3)E(n[k+0],n[k+1],n[k+2])}let z=new B,U=new B,L=new B,Q=new B;function S(R){L.fromArray(r,R*3),Q.copy(L);let V=c[R];z.copy(V),z.sub(L.multiplyScalar(L.dot(V))).normalize(),U.crossVectors(Q,V);let ft=U.dot(u[R])<0?-1:1;l[R*4]=z.x,l[R*4+1]=z.y,l[R*4+2]=z.z,l[R*4+3]=ft}for(let R=0,V=D.length;R<V;++R){let nt=D[R],ft=nt.start,I=nt.count;for(let k=ft,$=ft+I;k<$;k+=3)S(n[k+0]),S(n[k+1]),S(n[k+2])}}computeVertexNormals(){let t=this.index,e=this.getAttribute("position");if(e!==void 0){let n=this.getAttribute("normal");if(n===void 0)n=new rn(new Float32Array(e.count*3),3),this.setAttribute("normal",n);else for(let p=0,x=n.count;p<x;p++)n.setXYZ(p,0,0,0);let s=new B,r=new B,o=new B,a=new B,l=new B,c=new B,u=new B,f=new B;if(t)for(let p=0,x=t.count;p<x;p+=3){let y=t.getX(p+0),M=t.getX(p+1),g=t.getX(p+2);s.fromBufferAttribute(e,y),r.fromBufferAttribute(e,M),o.fromBufferAttribute(e,g),u.subVectors(o,r),f.subVectors(s,r),u.cross(f),a.fromBufferAttribute(n,y),l.fromBufferAttribute(n,M),c.fromBufferAttribute(n,g),a.add(u),l.add(u),c.add(u),n.setXYZ(y,a.x,a.y,a.z),n.setXYZ(M,l.x,l.y,l.z),n.setXYZ(g,c.x,c.y,c.z)}else for(let p=0,x=e.count;p<x;p+=3)s.fromBufferAttribute(e,p+0),r.fromBufferAttribute(e,p+1),o.fromBufferAttribute(e,p+2),u.subVectors(o,r),f.subVectors(s,r),u.cross(f),n.setXYZ(p+0,u.x,u.y,u.z),n.setXYZ(p+1,u.x,u.y,u.z),n.setXYZ(p+2,u.x,u.y,u.z);this.normalizeNormals(),n.needsUpdate=!0}}normalizeNormals(){let t=this.attributes.normal;for(let e=0,n=t.count;e<n;e++)Ye.fromBufferAttribute(t,e),Ye.normalize(),t.setXYZ(e,Ye.x,Ye.y,Ye.z)}toNonIndexed(){function t(a,l){let c=a.array,u=a.itemSize,f=a.normalized,p=new c.constructor(l.length*u),x=0,y=0;for(let M=0,g=l.length;M<g;M++){a.isInterleavedBufferAttribute?x=l[M]*a.data.stride+a.offset:x=l[M]*u;for(let d=0;d<u;d++)p[y++]=c[x++]}return new rn(p,u,f)}if(this.index===null)return console.warn("THREE.BufferGeometry.toNonIndexed(): BufferGeometry is already non-indexed."),this;let e=new i,n=this.index.array,s=this.attributes;for(let a in s){let l=s[a],c=t(l,n);e.setAttribute(a,c)}let r=this.morphAttributes;for(let a in r){let l=[],c=r[a];for(let u=0,f=c.length;u<f;u++){let p=c[u],x=t(p,n);l.push(x)}e.morphAttributes[a]=l}e.morphTargetsRelative=this.morphTargetsRelative;let o=this.groups;for(let a=0,l=o.length;a<l;a++){let c=o[a];e.addGroup(c.start,c.count,c.materialIndex)}return e}toJSON(){let t={metadata:{version:4.6,type:"BufferGeometry",generator:"BufferGeometry.toJSON"}};if(t.uuid=this.uuid,t.type=this.type,this.name!==""&&(t.name=this.name),Object.keys(this.userData).length>0&&(t.userData=this.userData),this.parameters!==void 0){let l=this.parameters;for(let c in l)l[c]!==void 0&&(t[c]=l[c]);return t}t.data={attributes:{}};let e=this.index;e!==null&&(t.data.index={type:e.array.constructor.name,array:Array.prototype.slice.call(e.array)});let n=this.attributes;for(let l in n){let c=n[l];t.data.attributes[l]=c.toJSON(t.data)}let s={},r=!1;for(let l in this.morphAttributes){let c=this.morphAttributes[l],u=[];for(let f=0,p=c.length;f<p;f++){let x=c[f];u.push(x.toJSON(t.data))}u.length>0&&(s[l]=u,r=!0)}r&&(t.data.morphAttributes=s,t.data.morphTargetsRelative=this.morphTargetsRelative);let o=this.groups;o.length>0&&(t.data.groups=JSON.parse(JSON.stringify(o)));let a=this.boundingSphere;return a!==null&&(t.data.boundingSphere={center:a.center.toArray(),radius:a.radius}),t}clone(){return new this.constructor().copy(this)}copy(t){this.index=null,this.attributes={},this.morphAttributes={},this.groups=[],this.boundingBox=null,this.boundingSphere=null;let e={};this.name=t.name;let n=t.index;n!==null&&this.setIndex(n.clone(e));let s=t.attributes;for(let c in s){let u=s[c];this.setAttribute(c,u.clone(e))}let r=t.morphAttributes;for(let c in r){let u=[],f=r[c];for(let p=0,x=f.length;p<x;p++)u.push(f[p].clone(e));this.morphAttributes[c]=u}this.morphTargetsRelative=t.morphTargetsRelative;let o=t.groups;for(let c=0,u=o.length;c<u;c++){let f=o[c];this.addGroup(f.start,f.count,f.materialIndex)}let a=t.boundingBox;a!==null&&(this.boundingBox=a.clone());let l=t.boundingSphere;return l!==null&&(this.boundingSphere=l.clone()),this.drawRange.start=t.drawRange.start,this.drawRange.count=t.drawRange.count,this.userData=t.userData,this}dispose(){this.dispatchEvent({type:"dispose"})}},sh=new ve,Fi=new Xi,Xr=new Si,rh=new B,gs=new B,xs=new B,_s=new B,Do=new B,Yr=new B,qr=new Lt,Zr=new Lt,Jr=new Lt,ah=new B,oh=new B,lh=new B,jr=new B,$r=new B,He=class extends an{constructor(t=new hn,e=new xn){super(),this.isMesh=!0,this.type="Mesh",this.geometry=t,this.material=e,this.updateMorphTargets()}copy(t,e){return super.copy(t,e),t.morphTargetInfluences!==void 0&&(this.morphTargetInfluences=t.morphTargetInfluences.slice()),t.morphTargetDictionary!==void 0&&(this.morphTargetDictionary=Object.assign({},t.morphTargetDictionary)),this.material=Array.isArray(t.material)?t.material.slice():t.material,this.geometry=t.geometry,this}updateMorphTargets(){let e=this.geometry.morphAttributes,n=Object.keys(e);if(n.length>0){let s=e[n[0]];if(s!==void 0){this.morphTargetInfluences=[],this.morphTargetDictionary={};for(let r=0,o=s.length;r<o;r++){let a=s[r].name||String(r);this.morphTargetInfluences.push(0),this.morphTargetDictionary[a]=r}}}}getVertexPosition(t,e){let n=this.geometry,s=n.attributes.position,r=n.morphAttributes.position,o=n.morphTargetsRelative;e.fromBufferAttribute(s,t);let a=this.morphTargetInfluences;if(r&&a){Yr.set(0,0,0);for(let l=0,c=r.length;l<c;l++){let u=a[l],f=r[l];u!==0&&(Do.fromBufferAttribute(f,t),o?Yr.addScaledVector(Do,u):Yr.addScaledVector(Do.sub(e),u))}e.add(Yr)}return e}raycast(t,e){let n=this.geometry,s=this.material,r=this.matrixWorld;s!==void 0&&(n.boundingSphere===null&&n.computeBoundingSphere(),Xr.copy(n.boundingSphere),Xr.applyMatrix4(r),Fi.copy(t.ray).recast(t.near),!(Xr.containsPoint(Fi.origin)===!1&&(Fi.intersectSphere(Xr,rh)===null||Fi.origin.distanceToSquared(rh)>(t.far-t.near)**2))&&(sh.copy(r).invert(),Fi.copy(t.ray).applyMatrix4(sh),!(n.boundingBox!==null&&Fi.intersectsBox(n.boundingBox)===!1)&&this._computeIntersections(t,e,Fi)))}_computeIntersections(t,e,n){let s,r=this.geometry,o=this.material,a=r.index,l=r.attributes.position,c=r.attributes.uv,u=r.attributes.uv1,f=r.attributes.normal,p=r.groups,x=r.drawRange;if(a!==null)if(Array.isArray(o))for(let y=0,M=p.length;y<M;y++){let g=p[y],d=o[g.materialIndex],C=Math.max(g.start,x.start),E=Math.min(a.count,Math.min(g.start+g.count,x.start+x.count));for(let D=C,z=E;D<z;D+=3){let U=a.getX(D),L=a.getX(D+1),Q=a.getX(D+2);s=Kr(this,d,t,n,c,u,f,U,L,Q),s&&(s.faceIndex=Math.floor(D/3),s.face.materialIndex=g.materialIndex,e.push(s))}}else{let y=Math.max(0,x.start),M=Math.min(a.count,x.start+x.count);for(let g=y,d=M;g<d;g+=3){let C=a.getX(g),E=a.getX(g+1),D=a.getX(g+2);s=Kr(this,o,t,n,c,u,f,C,E,D),s&&(s.faceIndex=Math.floor(g/3),e.push(s))}}else if(l!==void 0)if(Array.isArray(o))for(let y=0,M=p.length;y<M;y++){let g=p[y],d=o[g.materialIndex],C=Math.max(g.start,x.start),E=Math.min(l.count,Math.min(g.start+g.count,x.start+x.count));for(let D=C,z=E;D<z;D+=3){let U=D,L=D+1,Q=D+2;s=Kr(this,d,t,n,c,u,f,U,L,Q),s&&(s.faceIndex=Math.floor(D/3),s.face.materialIndex=g.materialIndex,e.push(s))}}else{let y=Math.max(0,x.start),M=Math.min(l.count,x.start+x.count);for(let g=y,d=M;g<d;g+=3){let C=g,E=g+1,D=g+2;s=Kr(this,o,t,n,c,u,f,C,E,D),s&&(s.faceIndex=Math.floor(g/3),e.push(s))}}}};function nf(i,t,e,n,s,r,o,a){let l;if(t.side===sn?l=n.intersectTriangle(o,r,s,!0,a):l=n.intersectTriangle(s,r,o,t.side===Mi,a),l===null)return null;$r.copy(a),$r.applyMatrix4(i.matrixWorld);let c=e.ray.origin.distanceTo($r);return c<e.near||c>e.far?null:{distance:c,point:$r.clone(),object:i}}function Kr(i,t,e,n,s,r,o,a,l,c){i.getVertexPosition(a,gs),i.getVertexPosition(l,xs),i.getVertexPosition(c,_s);let u=nf(i,t,e,n,gs,xs,_s,jr);if(u){s&&(qr.fromBufferAttribute(s,a),Zr.fromBufferAttribute(s,l),Jr.fromBufferAttribute(s,c),u.uv=ws.getInterpolation(jr,gs,xs,_s,qr,Zr,Jr,new Lt)),r&&(qr.fromBufferAttribute(r,a),Zr.fromBufferAttribute(r,l),Jr.fromBufferAttribute(r,c),u.uv1=ws.getInterpolation(jr,gs,xs,_s,qr,Zr,Jr,new Lt),u.uv2=u.uv1),o&&(ah.fromBufferAttribute(o,a),oh.fromBufferAttribute(o,l),lh.fromBufferAttribute(o,c),u.normal=ws.getInterpolation(jr,gs,xs,_s,ah,oh,lh,new B),u.normal.dot(n.direction)>0&&u.normal.multiplyScalar(-1));let f={a,b:l,c,normal:new B,materialIndex:0};ws.getNormal(gs,xs,_s,f.normal),u.face=f}return u}var Yi=class i extends hn{constructor(t=1,e=1,n=1,s=1,r=1,o=1){super(),this.type="BoxGeometry",this.parameters={width:t,height:e,depth:n,widthSegments:s,heightSegments:r,depthSegments:o};let a=this;s=Math.floor(s),r=Math.floor(r),o=Math.floor(o);let l=[],c=[],u=[],f=[],p=0,x=0;y("z","y","x",-1,-1,n,e,t,o,r,0),y("z","y","x",1,-1,n,e,-t,o,r,1),y("x","z","y",1,1,t,n,e,s,o,2),y("x","z","y",1,-1,t,n,-e,s,o,3),y("x","y","z",1,-1,t,e,n,s,r,4),y("x","y","z",-1,-1,t,e,-n,s,r,5),this.setIndex(l),this.setAttribute("position",new Ze(c,3)),this.setAttribute("normal",new Ze(u,3)),this.setAttribute("uv",new Ze(f,2));function y(M,g,d,C,E,D,z,U,L,Q,S){let R=D/L,V=z/Q,nt=D/2,ft=z/2,I=U/2,k=L+1,$=Q+1,Z=0,j=0,K=new B;for(let st=0;st<$;st++){let it=st*V-ft;for(let vt=0;vt<k;vt++){let q=vt*R-nt;K[M]=q*C,K[g]=it*E,K[d]=I,c.push(K.x,K.y,K.z),K[M]=0,K[g]=0,K[d]=U>0?1:-1,u.push(K.x,K.y,K.z),f.push(vt/L),f.push(1-st/Q),Z+=1}}for(let st=0;st<Q;st++)for(let it=0;it<L;it++){let vt=p+it+k*st,q=p+it+k*(st+1),ct=p+(it+1)+k*(st+1),yt=p+(it+1)+k*st;l.push(vt,q,yt),l.push(q,ct,yt),j+=6}a.addGroup(x,j,S),x+=j,p+=Z}}copy(t){return super.copy(t),this.parameters=Object.assign({},t.parameters),this}static fromJSON(t){return new i(t.width,t.height,t.depth,t.widthSegments,t.heightSegments,t.depthSegments)}};function Ds(i){let t={};for(let e in i){t[e]={};for(let n in i[e]){let s=i[e][n];s&&(s.isColor||s.isMatrix3||s.isMatrix4||s.isVector2||s.isVector3||s.isVector4||s.isTexture||s.isQuaternion)?s.isRenderTargetTexture?(console.warn("UniformsUtils: Textures of render targets cannot be cloned via cloneUniforms() or mergeUniforms()."),t[e][n]=null):t[e][n]=s.clone():Array.isArray(s)?t[e][n]=s.slice():t[e][n]=s}}return t}function cn(i){let t={};for(let e=0;e<i.length;e++){let n=Ds(i[e]);for(let s in n)t[s]=n[s]}return t}function sf(i){let t=[];for(let e=0;e<i.length;e++)t.push(i[e].clone());return t}function eu(i){return i.getRenderTarget()===null?i.outputColorSpace:fe.workingColorSpace}var Ei={clone:Ds,merge:cn},rf=`void main() {
	gl_Position = projectionMatrix * modelViewMatrix * vec4( position, 1.0 );
}`,af=`void main() {
	gl_FragColor = vec4( 1.0, 0.0, 0.0, 1.0 );
}`,Ne=class extends wi{constructor(t){super(),this.isShaderMaterial=!0,this.type="ShaderMaterial",this.defines={},this.uniforms={},this.uniformsGroups=[],this.vertexShader=rf,this.fragmentShader=af,this.linewidth=1,this.wireframe=!1,this.wireframeLinewidth=1,this.fog=!1,this.lights=!1,this.clipping=!1,this.forceSinglePass=!0,this.extensions={derivatives:!1,fragDepth:!1,drawBuffers:!1,shaderTextureLOD:!1,clipCullDistance:!1},this.defaultAttributeValues={color:[1,1,1],uv:[0,0],uv1:[0,0]},this.index0AttributeName=void 0,this.uniformsNeedUpdate=!1,this.glslVersion=null,t!==void 0&&this.setValues(t)}copy(t){return super.copy(t),this.fragmentShader=t.fragmentShader,this.vertexShader=t.vertexShader,this.uniforms=Ds(t.uniforms),this.uniformsGroups=sf(t.uniformsGroups),this.defines=Object.assign({},t.defines),this.wireframe=t.wireframe,this.wireframeLinewidth=t.wireframeLinewidth,this.fog=t.fog,this.lights=t.lights,this.clipping=t.clipping,this.extensions=Object.assign({},t.extensions),this.glslVersion=t.glslVersion,this}toJSON(t){let e=super.toJSON(t);e.glslVersion=this.glslVersion,e.uniforms={};for(let s in this.uniforms){let o=this.uniforms[s].value;o&&o.isTexture?e.uniforms[s]={type:"t",value:o.toJSON(t).uuid}:o&&o.isColor?e.uniforms[s]={type:"c",value:o.getHex()}:o&&o.isVector2?e.uniforms[s]={type:"v2",value:o.toArray()}:o&&o.isVector3?e.uniforms[s]={type:"v3",value:o.toArray()}:o&&o.isVector4?e.uniforms[s]={type:"v4",value:o.toArray()}:o&&o.isMatrix3?e.uniforms[s]={type:"m3",value:o.toArray()}:o&&o.isMatrix4?e.uniforms[s]={type:"m4",value:o.toArray()}:e.uniforms[s]={value:o}}Object.keys(this.defines).length>0&&(e.defines=this.defines),e.vertexShader=this.vertexShader,e.fragmentShader=this.fragmentShader,e.lights=this.lights,e.clipping=this.clipping;let n={};for(let s in this.extensions)this.extensions[s]===!0&&(n[s]=!0);return Object.keys(n).length>0&&(e.extensions=n),e}},ba=class extends an{constructor(){super(),this.isCamera=!0,this.type="Camera",this.matrixWorldInverse=new ve,this.projectionMatrix=new ve,this.projectionMatrixInverse=new ve,this.coordinateSystem=ii}copy(t,e){return super.copy(t,e),this.matrixWorldInverse.copy(t.matrixWorldInverse),this.projectionMatrix.copy(t.projectionMatrix),this.projectionMatrixInverse.copy(t.projectionMatrixInverse),this.coordinateSystem=t.coordinateSystem,this}getWorldDirection(t){return super.getWorldDirection(t).negate()}updateMatrixWorld(t){super.updateMatrixWorld(t),this.matrixWorldInverse.copy(this.matrixWorld).invert()}updateWorldMatrix(t,e){super.updateWorldMatrix(t,e),this.matrixWorldInverse.copy(this.matrixWorld).invert()}clone(){return new this.constructor().copy(this)}},nn=class extends ba{constructor(t=50,e=1,n=.1,s=2e3){super(),this.isPerspectiveCamera=!0,this.type="PerspectiveCamera",this.fov=t,this.zoom=1,this.near=n,this.far=s,this.focus=10,this.aspect=e,this.view=null,this.filmGauge=35,this.filmOffset=0,this.updateProjectionMatrix()}copy(t,e){return super.copy(t,e),this.fov=t.fov,this.zoom=t.zoom,this.near=t.near,this.far=t.far,this.focus=t.focus,this.aspect=t.aspect,this.view=t.view===null?null:Object.assign({},t.view),this.filmGauge=t.filmGauge,this.filmOffset=t.filmOffset,this}setFocalLength(t){let e=.5*this.getFilmHeight()/t;this.fov=dr*2*Math.atan(e),this.updateProjectionMatrix()}getFocalLength(){let t=Math.tan(ar*.5*this.fov);return .5*this.getFilmHeight()/t}getEffectiveFOV(){return dr*2*Math.atan(Math.tan(ar*.5*this.fov)/this.zoom)}getFilmWidth(){return this.filmGauge*Math.min(this.aspect,1)}getFilmHeight(){return this.filmGauge/Math.max(this.aspect,1)}setViewOffset(t,e,n,s,r,o){this.aspect=t/e,this.view===null&&(this.view={enabled:!0,fullWidth:1,fullHeight:1,offsetX:0,offsetY:0,width:1,height:1}),this.view.enabled=!0,this.view.fullWidth=t,this.view.fullHeight=e,this.view.offsetX=n,this.view.offsetY=s,this.view.width=r,this.view.height=o,this.updateProjectionMatrix()}clearViewOffset(){this.view!==null&&(this.view.enabled=!1),this.updateProjectionMatrix()}updateProjectionMatrix(){let t=this.near,e=t*Math.tan(ar*.5*this.fov)/this.zoom,n=2*e,s=this.aspect*n,r=-.5*s,o=this.view;if(this.view!==null&&this.view.enabled){let l=o.fullWidth,c=o.fullHeight;r+=o.offsetX*s/l,e-=o.offsetY*n/c,s*=o.width/l,n*=o.height/c}let a=this.filmOffset;a!==0&&(r+=t*a/this.getFilmWidth()),this.projectionMatrix.makePerspective(r,r+s,e,e-n,t,this.far,this.coordinateSystem),this.projectionMatrixInverse.copy(this.projectionMatrix).invert()}toJSON(t){let e=super.toJSON(t);return e.object.fov=this.fov,e.object.zoom=this.zoom,e.object.near=this.near,e.object.far=this.far,e.object.focus=this.focus,e.object.aspect=this.aspect,this.view!==null&&(e.object.view=Object.assign({},this.view)),e.object.filmGauge=this.filmGauge,e.object.filmOffset=this.filmOffset,e}},vs=-90,ys=1,$o=class extends an{constructor(t,e,n){super(),this.type="CubeCamera",this.renderTarget=n,this.coordinateSystem=null,this.activeMipmapLevel=0;let s=new nn(vs,ys,t,e);s.layers=this.layers,this.add(s);let r=new nn(vs,ys,t,e);r.layers=this.layers,this.add(r);let o=new nn(vs,ys,t,e);o.layers=this.layers,this.add(o);let a=new nn(vs,ys,t,e);a.layers=this.layers,this.add(a);let l=new nn(vs,ys,t,e);l.layers=this.layers,this.add(l);let c=new nn(vs,ys,t,e);c.layers=this.layers,this.add(c)}updateCoordinateSystem(){let t=this.coordinateSystem,e=this.children.concat(),[n,s,r,o,a,l]=e;for(let c of e)this.remove(c);if(t===ii)n.up.set(0,1,0),n.lookAt(1,0,0),s.up.set(0,1,0),s.lookAt(-1,0,0),r.up.set(0,0,-1),r.lookAt(0,1,0),o.up.set(0,0,1),o.lookAt(0,-1,0),a.up.set(0,1,0),a.lookAt(0,0,1),l.up.set(0,1,0),l.lookAt(0,0,-1);else if(t===da)n.up.set(0,-1,0),n.lookAt(-1,0,0),s.up.set(0,-1,0),s.lookAt(1,0,0),r.up.set(0,0,1),r.lookAt(0,1,0),o.up.set(0,0,-1),o.lookAt(0,-1,0),a.up.set(0,-1,0),a.lookAt(0,0,1),l.up.set(0,-1,0),l.lookAt(0,0,-1);else throw new Error("THREE.CubeCamera.updateCoordinateSystem(): Invalid coordinate system: "+t);for(let c of e)this.add(c),c.updateMatrixWorld()}update(t,e){this.parent===null&&this.updateMatrixWorld();let{renderTarget:n,activeMipmapLevel:s}=this;this.coordinateSystem!==t.coordinateSystem&&(this.coordinateSystem=t.coordinateSystem,this.updateCoordinateSystem());let[r,o,a,l,c,u]=this.children,f=t.getRenderTarget(),p=t.getActiveCubeFace(),x=t.getActiveMipmapLevel(),y=t.xr.enabled;t.xr.enabled=!1;let M=n.texture.generateMipmaps;n.texture.generateMipmaps=!1,t.setRenderTarget(n,0,s),t.render(e,r),t.setRenderTarget(n,1,s),t.render(e,o),t.setRenderTarget(n,2,s),t.render(e,a),t.setRenderTarget(n,3,s),t.render(e,l),t.setRenderTarget(n,4,s),t.render(e,c),n.texture.generateMipmaps=M,t.setRenderTarget(n,5,s),t.render(e,u),t.setRenderTarget(f,p,x),t.xr.enabled=y,n.texture.needsPMREMUpdate=!0}},Ma=class extends Sn{constructor(t,e,n,s,r,o,a,l,c,u){t=t!==void 0?t:[],e=e!==void 0?e:Ps,super(t,e,n,s,r,o,a,l,c,u),this.isCubeTexture=!0,this.flipY=!1}get images(){return this.image}set images(t){this.image=t}},Ko=class extends Ke{constructor(t=1,e={}){super(t,t,e),this.isWebGLCubeRenderTarget=!0;let n={width:t,height:t,depth:1},s=[n,n,n,n,n,n];e.encoding!==void 0&&(lr("THREE.WebGLCubeRenderTarget: option.encoding has been replaced by option.colorSpace."),e.colorSpace=e.encoding===Wi?Ce:Mn),this.texture=new Ma(s,e.mapping,e.wrapS,e.wrapT,e.magFilter,e.minFilter,e.format,e.type,e.anisotropy,e.colorSpace),this.texture.isRenderTargetTexture=!0,this.texture.generateMipmaps=e.generateMipmaps!==void 0?e.generateMipmaps:!1,this.texture.minFilter=e.minFilter!==void 0?e.minFilter:bn}fromEquirectangularTexture(t,e){this.texture.type=e.type,this.texture.colorSpace=e.colorSpace,this.texture.generateMipmaps=e.generateMipmaps,this.texture.minFilter=e.minFilter,this.texture.magFilter=e.magFilter;let n={uniforms:{tEquirect:{value:null}},vertexShader:`

				varying vec3 vWorldDirection;

				vec3 transformDirection( in vec3 dir, in mat4 matrix ) {

					return normalize( ( matrix * vec4( dir, 0.0 ) ).xyz );

				}

				void main() {

					vWorldDirection = transformDirection( position, modelMatrix );

					#include <begin_vertex>
					#include <project_vertex>

				}
			`,fragmentShader:`

				uniform sampler2D tEquirect;

				varying vec3 vWorldDirection;

				#include <common>

				void main() {

					vec3 direction = normalize( vWorldDirection );

					vec2 sampleUV = equirectUv( direction );

					gl_FragColor = texture2D( tEquirect, sampleUV );

				}
			`},s=new Yi(5,5,5),r=new Ne({name:"CubemapFromEquirect",uniforms:Ds(n.uniforms),vertexShader:n.vertexShader,fragmentShader:n.fragmentShader,side:sn,blending:Yn});r.uniforms.tEquirect.value=e;let o=new He(s,r),a=e.minFilter;return e.minFilter===ur&&(e.minFilter=bn),new $o(1,10,this).update(t,o),e.minFilter=a,o.geometry.dispose(),o.material.dispose(),this}clear(t,e,n,s){let r=t.getRenderTarget();for(let o=0;o<6;o++)t.setRenderTarget(this,o),t.clear(e,n,s);t.setRenderTarget(r)}},Uo=new B,of=new B,lf=new oe,In=class{constructor(t=new B(1,0,0),e=0){this.isPlane=!0,this.normal=t,this.constant=e}set(t,e){return this.normal.copy(t),this.constant=e,this}setComponents(t,e,n,s){return this.normal.set(t,e,n),this.constant=s,this}setFromNormalAndCoplanarPoint(t,e){return this.normal.copy(t),this.constant=-e.dot(this.normal),this}setFromCoplanarPoints(t,e,n){let s=Uo.subVectors(n,e).cross(of.subVectors(t,e)).normalize();return this.setFromNormalAndCoplanarPoint(s,t),this}copy(t){return this.normal.copy(t.normal),this.constant=t.constant,this}normalize(){let t=1/this.normal.length();return this.normal.multiplyScalar(t),this.constant*=t,this}negate(){return this.constant*=-1,this.normal.negate(),this}distanceToPoint(t){return this.normal.dot(t)+this.constant}distanceToSphere(t){return this.distanceToPoint(t.center)-t.radius}projectPoint(t,e){return e.copy(t).addScaledVector(this.normal,-this.distanceToPoint(t))}intersectLine(t,e){let n=t.delta(Uo),s=this.normal.dot(n);if(s===0)return this.distanceToPoint(t.start)===0?e.copy(t.start):null;let r=-(t.start.dot(this.normal)+this.constant)/s;return r<0||r>1?null:e.copy(t.start).addScaledVector(n,r)}intersectsLine(t){let e=this.distanceToPoint(t.start),n=this.distanceToPoint(t.end);return e<0&&n>0||n<0&&e>0}intersectsBox(t){return t.intersectsPlane(this)}intersectsSphere(t){return t.intersectsPlane(this)}coplanarPoint(t){return t.copy(this.normal).multiplyScalar(-this.constant)}applyMatrix4(t,e){let n=e||lf.getNormalMatrix(t),s=this.coplanarPoint(Uo).applyMatrix4(t),r=this.normal.applyMatrix3(n).normalize();return this.constant=-s.dot(r),this}translate(t){return this.constant-=t.dot(this.normal),this}equals(t){return t.normal.equals(this.normal)&&t.constant===this.constant}clone(){return new this.constructor().copy(this)}},Bi=new Si,Qr=new B,pr=class{constructor(t=new In,e=new In,n=new In,s=new In,r=new In,o=new In){this.planes=[t,e,n,s,r,o]}set(t,e,n,s,r,o){let a=this.planes;return a[0].copy(t),a[1].copy(e),a[2].copy(n),a[3].copy(s),a[4].copy(r),a[5].copy(o),this}copy(t){let e=this.planes;for(let n=0;n<6;n++)e[n].copy(t.planes[n]);return this}setFromProjectionMatrix(t,e=ii){let n=this.planes,s=t.elements,r=s[0],o=s[1],a=s[2],l=s[3],c=s[4],u=s[5],f=s[6],p=s[7],x=s[8],y=s[9],M=s[10],g=s[11],d=s[12],C=s[13],E=s[14],D=s[15];if(n[0].setComponents(l-r,p-c,g-x,D-d).normalize(),n[1].setComponents(l+r,p+c,g+x,D+d).normalize(),n[2].setComponents(l+o,p+u,g+y,D+C).normalize(),n[3].setComponents(l-o,p-u,g-y,D-C).normalize(),n[4].setComponents(l-a,p-f,g-M,D-E).normalize(),e===ii)n[5].setComponents(l+a,p+f,g+M,D+E).normalize();else if(e===da)n[5].setComponents(a,f,M,E).normalize();else throw new Error("THREE.Frustum.setFromProjectionMatrix(): Invalid coordinate system: "+e);return this}intersectsObject(t){if(t.boundingSphere!==void 0)t.boundingSphere===null&&t.computeBoundingSphere(),Bi.copy(t.boundingSphere).applyMatrix4(t.matrixWorld);else{let e=t.geometry;e.boundingSphere===null&&e.computeBoundingSphere(),Bi.copy(e.boundingSphere).applyMatrix4(t.matrixWorld)}return this.intersectsSphere(Bi)}intersectsSprite(t){return Bi.center.set(0,0,0),Bi.radius=.7071067811865476,Bi.applyMatrix4(t.matrixWorld),this.intersectsSphere(Bi)}intersectsSphere(t){let e=this.planes,n=t.center,s=-t.radius;for(let r=0;r<6;r++)if(e[r].distanceToPoint(n)<s)return!1;return!0}intersectsBox(t){let e=this.planes;for(let n=0;n<6;n++){let s=e[n];if(Qr.x=s.normal.x>0?t.max.x:t.min.x,Qr.y=s.normal.y>0?t.max.y:t.min.y,Qr.z=s.normal.z>0?t.max.z:t.min.z,s.distanceToPoint(Qr)<0)return!1}return!0}containsPoint(t){let e=this.planes;for(let n=0;n<6;n++)if(e[n].distanceToPoint(t)<0)return!1;return!0}clone(){return new this.constructor().copy(this)}};function nu(){let i=null,t=!1,e=null,n=null;function s(r,o){e(r,o),n=i.requestAnimationFrame(s)}return{start:function(){t!==!0&&e!==null&&(n=i.requestAnimationFrame(s),t=!0)},stop:function(){i.cancelAnimationFrame(n),t=!1},setAnimationLoop:function(r){e=r},setContext:function(r){i=r}}}function cf(i,t){let e=t.isWebGL2,n=new WeakMap;function s(c,u){let f=c.array,p=c.usage,x=f.byteLength,y=i.createBuffer();i.bindBuffer(u,y),i.bufferData(u,f,p),c.onUploadCallback();let M;if(f instanceof Float32Array)M=i.FLOAT;else if(f instanceof Uint16Array)if(c.isFloat16BufferAttribute)if(e)M=i.HALF_FLOAT;else throw new Error("THREE.WebGLAttributes: Usage of Float16BufferAttribute requires WebGL2.");else M=i.UNSIGNED_SHORT;else if(f instanceof Int16Array)M=i.SHORT;else if(f instanceof Uint32Array)M=i.UNSIGNED_INT;else if(f instanceof Int32Array)M=i.INT;else if(f instanceof Int8Array)M=i.BYTE;else if(f instanceof Uint8Array)M=i.UNSIGNED_BYTE;else if(f instanceof Uint8ClampedArray)M=i.UNSIGNED_BYTE;else throw new Error("THREE.WebGLAttributes: Unsupported buffer data format: "+f);return{buffer:y,type:M,bytesPerElement:f.BYTES_PER_ELEMENT,version:c.version,size:x}}function r(c,u,f){let p=u.array,x=u._updateRange,y=u.updateRanges;if(i.bindBuffer(f,c),x.count===-1&&y.length===0&&i.bufferSubData(f,0,p),y.length!==0){for(let M=0,g=y.length;M<g;M++){let d=y[M];e?i.bufferSubData(f,d.start*p.BYTES_PER_ELEMENT,p,d.start,d.count):i.bufferSubData(f,d.start*p.BYTES_PER_ELEMENT,p.subarray(d.start,d.start+d.count))}u.clearUpdateRanges()}x.count!==-1&&(e?i.bufferSubData(f,x.offset*p.BYTES_PER_ELEMENT,p,x.offset,x.count):i.bufferSubData(f,x.offset*p.BYTES_PER_ELEMENT,p.subarray(x.offset,x.offset+x.count)),x.count=-1),u.onUploadCallback()}function o(c){return c.isInterleavedBufferAttribute&&(c=c.data),n.get(c)}function a(c){c.isInterleavedBufferAttribute&&(c=c.data);let u=n.get(c);u&&(i.deleteBuffer(u.buffer),n.delete(c))}function l(c,u){if(c.isGLBufferAttribute){let p=n.get(c);(!p||p.version<c.version)&&n.set(c,{buffer:c.buffer,type:c.type,bytesPerElement:c.elementSize,version:c.version});return}c.isInterleavedBufferAttribute&&(c=c.data);let f=n.get(c);if(f===void 0)n.set(c,s(c,u));else if(f.version<c.version){if(f.size!==c.array.byteLength)throw new Error("THREE.WebGLAttributes: The size of the buffer attribute's array buffer does not match the original size. Resizing buffer attributes is not supported.");r(f.buffer,c,u),f.version=c.version}}return{get:o,remove:a,update:l}}var mr=class i extends hn{constructor(t=1,e=1,n=1,s=1){super(),this.type="PlaneGeometry",this.parameters={width:t,height:e,widthSegments:n,heightSegments:s};let r=t/2,o=e/2,a=Math.floor(n),l=Math.floor(s),c=a+1,u=l+1,f=t/a,p=e/l,x=[],y=[],M=[],g=[];for(let d=0;d<u;d++){let C=d*p-o;for(let E=0;E<c;E++){let D=E*f-r;y.push(D,-C,0),M.push(0,0,1),g.push(E/a),g.push(1-d/l)}}for(let d=0;d<l;d++)for(let C=0;C<a;C++){let E=C+c*d,D=C+c*(d+1),z=C+1+c*(d+1),U=C+1+c*d;x.push(E,D,U),x.push(D,z,U)}this.setIndex(x),this.setAttribute("position",new Ze(y,3)),this.setAttribute("normal",new Ze(M,3)),this.setAttribute("uv",new Ze(g,2))}copy(t){return super.copy(t),this.parameters=Object.assign({},t.parameters),this}static fromJSON(t){return new i(t.width,t.height,t.widthSegments,t.heightSegments)}},hf=`#ifdef USE_ALPHAHASH
	if ( diffuseColor.a < getAlphaHashThreshold( vPosition ) ) discard;
#endif`,uf=`#ifdef USE_ALPHAHASH
	const float ALPHA_HASH_SCALE = 0.05;
	float hash2D( vec2 value ) {
		return fract( 1.0e4 * sin( 17.0 * value.x + 0.1 * value.y ) * ( 0.1 + abs( sin( 13.0 * value.y + value.x ) ) ) );
	}
	float hash3D( vec3 value ) {
		return hash2D( vec2( hash2D( value.xy ), value.z ) );
	}
	float getAlphaHashThreshold( vec3 position ) {
		float maxDeriv = max(
			length( dFdx( position.xyz ) ),
			length( dFdy( position.xyz ) )
		);
		float pixScale = 1.0 / ( ALPHA_HASH_SCALE * maxDeriv );
		vec2 pixScales = vec2(
			exp2( floor( log2( pixScale ) ) ),
			exp2( ceil( log2( pixScale ) ) )
		);
		vec2 alpha = vec2(
			hash3D( floor( pixScales.x * position.xyz ) ),
			hash3D( floor( pixScales.y * position.xyz ) )
		);
		float lerpFactor = fract( log2( pixScale ) );
		float x = ( 1.0 - lerpFactor ) * alpha.x + lerpFactor * alpha.y;
		float a = min( lerpFactor, 1.0 - lerpFactor );
		vec3 cases = vec3(
			x * x / ( 2.0 * a * ( 1.0 - a ) ),
			( x - 0.5 * a ) / ( 1.0 - a ),
			1.0 - ( ( 1.0 - x ) * ( 1.0 - x ) / ( 2.0 * a * ( 1.0 - a ) ) )
		);
		float threshold = ( x < ( 1.0 - a ) )
			? ( ( x < a ) ? cases.x : cases.y )
			: cases.z;
		return clamp( threshold , 1.0e-6, 1.0 );
	}
#endif`,df=`#ifdef USE_ALPHAMAP
	diffuseColor.a *= texture2D( alphaMap, vAlphaMapUv ).g;
#endif`,ff=`#ifdef USE_ALPHAMAP
	uniform sampler2D alphaMap;
#endif`,pf=`#ifdef USE_ALPHATEST
	if ( diffuseColor.a < alphaTest ) discard;
#endif`,mf=`#ifdef USE_ALPHATEST
	uniform float alphaTest;
#endif`,gf=`#ifdef USE_AOMAP
	float ambientOcclusion = ( texture2D( aoMap, vAoMapUv ).r - 1.0 ) * aoMapIntensity + 1.0;
	reflectedLight.indirectDiffuse *= ambientOcclusion;
	#if defined( USE_CLEARCOAT ) 
		clearcoatSpecularIndirect *= ambientOcclusion;
	#endif
	#if defined( USE_SHEEN ) 
		sheenSpecularIndirect *= ambientOcclusion;
	#endif
	#if defined( USE_ENVMAP ) && defined( STANDARD )
		float dotNV = saturate( dot( geometryNormal, geometryViewDir ) );
		reflectedLight.indirectSpecular *= computeSpecularOcclusion( dotNV, ambientOcclusion, material.roughness );
	#endif
#endif`,xf=`#ifdef USE_AOMAP
	uniform sampler2D aoMap;
	uniform float aoMapIntensity;
#endif`,_f=`#ifdef USE_BATCHING
	attribute float batchId;
	uniform highp sampler2D batchingTexture;
	mat4 getBatchingMatrix( const in float i ) {
		int size = textureSize( batchingTexture, 0 ).x;
		int j = int( i ) * 4;
		int x = j % size;
		int y = j / size;
		vec4 v1 = texelFetch( batchingTexture, ivec2( x, y ), 0 );
		vec4 v2 = texelFetch( batchingTexture, ivec2( x + 1, y ), 0 );
		vec4 v3 = texelFetch( batchingTexture, ivec2( x + 2, y ), 0 );
		vec4 v4 = texelFetch( batchingTexture, ivec2( x + 3, y ), 0 );
		return mat4( v1, v2, v3, v4 );
	}
#endif`,vf=`#ifdef USE_BATCHING
	mat4 batchingMatrix = getBatchingMatrix( batchId );
#endif`,yf=`vec3 transformed = vec3( position );
#ifdef USE_ALPHAHASH
	vPosition = vec3( position );
#endif`,bf=`vec3 objectNormal = vec3( normal );
#ifdef USE_TANGENT
	vec3 objectTangent = vec3( tangent.xyz );
#endif`,Mf=`float G_BlinnPhong_Implicit( ) {
	return 0.25;
}
float D_BlinnPhong( const in float shininess, const in float dotNH ) {
	return RECIPROCAL_PI * ( shininess * 0.5 + 1.0 ) * pow( dotNH, shininess );
}
vec3 BRDF_BlinnPhong( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, const in vec3 specularColor, const in float shininess ) {
	vec3 halfDir = normalize( lightDir + viewDir );
	float dotNH = saturate( dot( normal, halfDir ) );
	float dotVH = saturate( dot( viewDir, halfDir ) );
	vec3 F = F_Schlick( specularColor, 1.0, dotVH );
	float G = G_BlinnPhong_Implicit( );
	float D = D_BlinnPhong( shininess, dotNH );
	return F * ( G * D );
} // validated`,Sf=`#ifdef USE_IRIDESCENCE
	const mat3 XYZ_TO_REC709 = mat3(
		 3.2404542, -0.9692660,  0.0556434,
		-1.5371385,  1.8760108, -0.2040259,
		-0.4985314,  0.0415560,  1.0572252
	);
	vec3 Fresnel0ToIor( vec3 fresnel0 ) {
		vec3 sqrtF0 = sqrt( fresnel0 );
		return ( vec3( 1.0 ) + sqrtF0 ) / ( vec3( 1.0 ) - sqrtF0 );
	}
	vec3 IorToFresnel0( vec3 transmittedIor, float incidentIor ) {
		return pow2( ( transmittedIor - vec3( incidentIor ) ) / ( transmittedIor + vec3( incidentIor ) ) );
	}
	float IorToFresnel0( float transmittedIor, float incidentIor ) {
		return pow2( ( transmittedIor - incidentIor ) / ( transmittedIor + incidentIor ));
	}
	vec3 evalSensitivity( float OPD, vec3 shift ) {
		float phase = 2.0 * PI * OPD * 1.0e-9;
		vec3 val = vec3( 5.4856e-13, 4.4201e-13, 5.2481e-13 );
		vec3 pos = vec3( 1.6810e+06, 1.7953e+06, 2.2084e+06 );
		vec3 var = vec3( 4.3278e+09, 9.3046e+09, 6.6121e+09 );
		vec3 xyz = val * sqrt( 2.0 * PI * var ) * cos( pos * phase + shift ) * exp( - pow2( phase ) * var );
		xyz.x += 9.7470e-14 * sqrt( 2.0 * PI * 4.5282e+09 ) * cos( 2.2399e+06 * phase + shift[ 0 ] ) * exp( - 4.5282e+09 * pow2( phase ) );
		xyz /= 1.0685e-7;
		vec3 rgb = XYZ_TO_REC709 * xyz;
		return rgb;
	}
	vec3 evalIridescence( float outsideIOR, float eta2, float cosTheta1, float thinFilmThickness, vec3 baseF0 ) {
		vec3 I;
		float iridescenceIOR = mix( outsideIOR, eta2, smoothstep( 0.0, 0.03, thinFilmThickness ) );
		float sinTheta2Sq = pow2( outsideIOR / iridescenceIOR ) * ( 1.0 - pow2( cosTheta1 ) );
		float cosTheta2Sq = 1.0 - sinTheta2Sq;
		if ( cosTheta2Sq < 0.0 ) {
			return vec3( 1.0 );
		}
		float cosTheta2 = sqrt( cosTheta2Sq );
		float R0 = IorToFresnel0( iridescenceIOR, outsideIOR );
		float R12 = F_Schlick( R0, 1.0, cosTheta1 );
		float T121 = 1.0 - R12;
		float phi12 = 0.0;
		if ( iridescenceIOR < outsideIOR ) phi12 = PI;
		float phi21 = PI - phi12;
		vec3 baseIOR = Fresnel0ToIor( clamp( baseF0, 0.0, 0.9999 ) );		vec3 R1 = IorToFresnel0( baseIOR, iridescenceIOR );
		vec3 R23 = F_Schlick( R1, 1.0, cosTheta2 );
		vec3 phi23 = vec3( 0.0 );
		if ( baseIOR[ 0 ] < iridescenceIOR ) phi23[ 0 ] = PI;
		if ( baseIOR[ 1 ] < iridescenceIOR ) phi23[ 1 ] = PI;
		if ( baseIOR[ 2 ] < iridescenceIOR ) phi23[ 2 ] = PI;
		float OPD = 2.0 * iridescenceIOR * thinFilmThickness * cosTheta2;
		vec3 phi = vec3( phi21 ) + phi23;
		vec3 R123 = clamp( R12 * R23, 1e-5, 0.9999 );
		vec3 r123 = sqrt( R123 );
		vec3 Rs = pow2( T121 ) * R23 / ( vec3( 1.0 ) - R123 );
		vec3 C0 = R12 + Rs;
		I = C0;
		vec3 Cm = Rs - T121;
		for ( int m = 1; m <= 2; ++ m ) {
			Cm *= r123;
			vec3 Sm = 2.0 * evalSensitivity( float( m ) * OPD, float( m ) * phi );
			I += Cm * Sm;
		}
		return max( I, vec3( 0.0 ) );
	}
#endif`,wf=`#ifdef USE_BUMPMAP
	uniform sampler2D bumpMap;
	uniform float bumpScale;
	vec2 dHdxy_fwd() {
		vec2 dSTdx = dFdx( vBumpMapUv );
		vec2 dSTdy = dFdy( vBumpMapUv );
		float Hll = bumpScale * texture2D( bumpMap, vBumpMapUv ).x;
		float dBx = bumpScale * texture2D( bumpMap, vBumpMapUv + dSTdx ).x - Hll;
		float dBy = bumpScale * texture2D( bumpMap, vBumpMapUv + dSTdy ).x - Hll;
		return vec2( dBx, dBy );
	}
	vec3 perturbNormalArb( vec3 surf_pos, vec3 surf_norm, vec2 dHdxy, float faceDirection ) {
		vec3 vSigmaX = normalize( dFdx( surf_pos.xyz ) );
		vec3 vSigmaY = normalize( dFdy( surf_pos.xyz ) );
		vec3 vN = surf_norm;
		vec3 R1 = cross( vSigmaY, vN );
		vec3 R2 = cross( vN, vSigmaX );
		float fDet = dot( vSigmaX, R1 ) * faceDirection;
		vec3 vGrad = sign( fDet ) * ( dHdxy.x * R1 + dHdxy.y * R2 );
		return normalize( abs( fDet ) * surf_norm - vGrad );
	}
#endif`,Ef=`#if NUM_CLIPPING_PLANES > 0
	vec4 plane;
	#pragma unroll_loop_start
	for ( int i = 0; i < UNION_CLIPPING_PLANES; i ++ ) {
		plane = clippingPlanes[ i ];
		if ( dot( vClipPosition, plane.xyz ) > plane.w ) discard;
	}
	#pragma unroll_loop_end
	#if UNION_CLIPPING_PLANES < NUM_CLIPPING_PLANES
		bool clipped = true;
		#pragma unroll_loop_start
		for ( int i = UNION_CLIPPING_PLANES; i < NUM_CLIPPING_PLANES; i ++ ) {
			plane = clippingPlanes[ i ];
			clipped = ( dot( vClipPosition, plane.xyz ) > plane.w ) && clipped;
		}
		#pragma unroll_loop_end
		if ( clipped ) discard;
	#endif
#endif`,Tf=`#if NUM_CLIPPING_PLANES > 0
	varying vec3 vClipPosition;
	uniform vec4 clippingPlanes[ NUM_CLIPPING_PLANES ];
#endif`,Af=`#if NUM_CLIPPING_PLANES > 0
	varying vec3 vClipPosition;
#endif`,Cf=`#if NUM_CLIPPING_PLANES > 0
	vClipPosition = - mvPosition.xyz;
#endif`,Rf=`#if defined( USE_COLOR_ALPHA )
	diffuseColor *= vColor;
#elif defined( USE_COLOR )
	diffuseColor.rgb *= vColor;
#endif`,Pf=`#if defined( USE_COLOR_ALPHA )
	varying vec4 vColor;
#elif defined( USE_COLOR )
	varying vec3 vColor;
#endif`,Lf=`#if defined( USE_COLOR_ALPHA )
	varying vec4 vColor;
#elif defined( USE_COLOR ) || defined( USE_INSTANCING_COLOR )
	varying vec3 vColor;
#endif`,If=`#if defined( USE_COLOR_ALPHA )
	vColor = vec4( 1.0 );
#elif defined( USE_COLOR ) || defined( USE_INSTANCING_COLOR )
	vColor = vec3( 1.0 );
#endif
#ifdef USE_COLOR
	vColor *= color;
#endif
#ifdef USE_INSTANCING_COLOR
	vColor.xyz *= instanceColor.xyz;
#endif`,Df=`#define PI 3.141592653589793
#define PI2 6.283185307179586
#define PI_HALF 1.5707963267948966
#define RECIPROCAL_PI 0.3183098861837907
#define RECIPROCAL_PI2 0.15915494309189535
#define EPSILON 1e-6
#ifndef saturate
#define saturate( a ) clamp( a, 0.0, 1.0 )
#endif
#define whiteComplement( a ) ( 1.0 - saturate( a ) )
float pow2( const in float x ) { return x*x; }
vec3 pow2( const in vec3 x ) { return x*x; }
float pow3( const in float x ) { return x*x*x; }
float pow4( const in float x ) { float x2 = x*x; return x2*x2; }
float max3( const in vec3 v ) { return max( max( v.x, v.y ), v.z ); }
float average( const in vec3 v ) { return dot( v, vec3( 0.3333333 ) ); }
highp float rand( const in vec2 uv ) {
	const highp float a = 12.9898, b = 78.233, c = 43758.5453;
	highp float dt = dot( uv.xy, vec2( a,b ) ), sn = mod( dt, PI );
	return fract( sin( sn ) * c );
}
#ifdef HIGH_PRECISION
	float precisionSafeLength( vec3 v ) { return length( v ); }
#else
	float precisionSafeLength( vec3 v ) {
		float maxComponent = max3( abs( v ) );
		return length( v / maxComponent ) * maxComponent;
	}
#endif
struct IncidentLight {
	vec3 color;
	vec3 direction;
	bool visible;
};
struct ReflectedLight {
	vec3 directDiffuse;
	vec3 directSpecular;
	vec3 indirectDiffuse;
	vec3 indirectSpecular;
};
#ifdef USE_ALPHAHASH
	varying vec3 vPosition;
#endif
vec3 transformDirection( in vec3 dir, in mat4 matrix ) {
	return normalize( ( matrix * vec4( dir, 0.0 ) ).xyz );
}
vec3 inverseTransformDirection( in vec3 dir, in mat4 matrix ) {
	return normalize( ( vec4( dir, 0.0 ) * matrix ).xyz );
}
mat3 transposeMat3( const in mat3 m ) {
	mat3 tmp;
	tmp[ 0 ] = vec3( m[ 0 ].x, m[ 1 ].x, m[ 2 ].x );
	tmp[ 1 ] = vec3( m[ 0 ].y, m[ 1 ].y, m[ 2 ].y );
	tmp[ 2 ] = vec3( m[ 0 ].z, m[ 1 ].z, m[ 2 ].z );
	return tmp;
}
float luminance( const in vec3 rgb ) {
	const vec3 weights = vec3( 0.2126729, 0.7151522, 0.0721750 );
	return dot( weights, rgb );
}
bool isPerspectiveMatrix( mat4 m ) {
	return m[ 2 ][ 3 ] == - 1.0;
}
vec2 equirectUv( in vec3 dir ) {
	float u = atan( dir.z, dir.x ) * RECIPROCAL_PI2 + 0.5;
	float v = asin( clamp( dir.y, - 1.0, 1.0 ) ) * RECIPROCAL_PI + 0.5;
	return vec2( u, v );
}
vec3 BRDF_Lambert( const in vec3 diffuseColor ) {
	return RECIPROCAL_PI * diffuseColor;
}
vec3 F_Schlick( const in vec3 f0, const in float f90, const in float dotVH ) {
	float fresnel = exp2( ( - 5.55473 * dotVH - 6.98316 ) * dotVH );
	return f0 * ( 1.0 - fresnel ) + ( f90 * fresnel );
}
float F_Schlick( const in float f0, const in float f90, const in float dotVH ) {
	float fresnel = exp2( ( - 5.55473 * dotVH - 6.98316 ) * dotVH );
	return f0 * ( 1.0 - fresnel ) + ( f90 * fresnel );
} // validated`,Uf=`#ifdef ENVMAP_TYPE_CUBE_UV
	#define cubeUV_minMipLevel 4.0
	#define cubeUV_minTileSize 16.0
	float getFace( vec3 direction ) {
		vec3 absDirection = abs( direction );
		float face = - 1.0;
		if ( absDirection.x > absDirection.z ) {
			if ( absDirection.x > absDirection.y )
				face = direction.x > 0.0 ? 0.0 : 3.0;
			else
				face = direction.y > 0.0 ? 1.0 : 4.0;
		} else {
			if ( absDirection.z > absDirection.y )
				face = direction.z > 0.0 ? 2.0 : 5.0;
			else
				face = direction.y > 0.0 ? 1.0 : 4.0;
		}
		return face;
	}
	vec2 getUV( vec3 direction, float face ) {
		vec2 uv;
		if ( face == 0.0 ) {
			uv = vec2( direction.z, direction.y ) / abs( direction.x );
		} else if ( face == 1.0 ) {
			uv = vec2( - direction.x, - direction.z ) / abs( direction.y );
		} else if ( face == 2.0 ) {
			uv = vec2( - direction.x, direction.y ) / abs( direction.z );
		} else if ( face == 3.0 ) {
			uv = vec2( - direction.z, direction.y ) / abs( direction.x );
		} else if ( face == 4.0 ) {
			uv = vec2( - direction.x, direction.z ) / abs( direction.y );
		} else {
			uv = vec2( direction.x, direction.y ) / abs( direction.z );
		}
		return 0.5 * ( uv + 1.0 );
	}
	vec3 bilinearCubeUV( sampler2D envMap, vec3 direction, float mipInt ) {
		float face = getFace( direction );
		float filterInt = max( cubeUV_minMipLevel - mipInt, 0.0 );
		mipInt = max( mipInt, cubeUV_minMipLevel );
		float faceSize = exp2( mipInt );
		highp vec2 uv = getUV( direction, face ) * ( faceSize - 2.0 ) + 1.0;
		if ( face > 2.0 ) {
			uv.y += faceSize;
			face -= 3.0;
		}
		uv.x += face * faceSize;
		uv.x += filterInt * 3.0 * cubeUV_minTileSize;
		uv.y += 4.0 * ( exp2( CUBEUV_MAX_MIP ) - faceSize );
		uv.x *= CUBEUV_TEXEL_WIDTH;
		uv.y *= CUBEUV_TEXEL_HEIGHT;
		#ifdef texture2DGradEXT
			return texture2DGradEXT( envMap, uv, vec2( 0.0 ), vec2( 0.0 ) ).rgb;
		#else
			return texture2D( envMap, uv ).rgb;
		#endif
	}
	#define cubeUV_r0 1.0
	#define cubeUV_m0 - 2.0
	#define cubeUV_r1 0.8
	#define cubeUV_m1 - 1.0
	#define cubeUV_r4 0.4
	#define cubeUV_m4 2.0
	#define cubeUV_r5 0.305
	#define cubeUV_m5 3.0
	#define cubeUV_r6 0.21
	#define cubeUV_m6 4.0
	float roughnessToMip( float roughness ) {
		float mip = 0.0;
		if ( roughness >= cubeUV_r1 ) {
			mip = ( cubeUV_r0 - roughness ) * ( cubeUV_m1 - cubeUV_m0 ) / ( cubeUV_r0 - cubeUV_r1 ) + cubeUV_m0;
		} else if ( roughness >= cubeUV_r4 ) {
			mip = ( cubeUV_r1 - roughness ) * ( cubeUV_m4 - cubeUV_m1 ) / ( cubeUV_r1 - cubeUV_r4 ) + cubeUV_m1;
		} else if ( roughness >= cubeUV_r5 ) {
			mip = ( cubeUV_r4 - roughness ) * ( cubeUV_m5 - cubeUV_m4 ) / ( cubeUV_r4 - cubeUV_r5 ) + cubeUV_m4;
		} else if ( roughness >= cubeUV_r6 ) {
			mip = ( cubeUV_r5 - roughness ) * ( cubeUV_m6 - cubeUV_m5 ) / ( cubeUV_r5 - cubeUV_r6 ) + cubeUV_m5;
		} else {
			mip = - 2.0 * log2( 1.16 * roughness );		}
		return mip;
	}
	vec4 textureCubeUV( sampler2D envMap, vec3 sampleDir, float roughness ) {
		float mip = clamp( roughnessToMip( roughness ), cubeUV_m0, CUBEUV_MAX_MIP );
		float mipF = fract( mip );
		float mipInt = floor( mip );
		vec3 color0 = bilinearCubeUV( envMap, sampleDir, mipInt );
		if ( mipF == 0.0 ) {
			return vec4( color0, 1.0 );
		} else {
			vec3 color1 = bilinearCubeUV( envMap, sampleDir, mipInt + 1.0 );
			return vec4( mix( color0, color1, mipF ), 1.0 );
		}
	}
#endif`,Nf=`vec3 transformedNormal = objectNormal;
#ifdef USE_TANGENT
	vec3 transformedTangent = objectTangent;
#endif
#ifdef USE_BATCHING
	mat3 bm = mat3( batchingMatrix );
	transformedNormal /= vec3( dot( bm[ 0 ], bm[ 0 ] ), dot( bm[ 1 ], bm[ 1 ] ), dot( bm[ 2 ], bm[ 2 ] ) );
	transformedNormal = bm * transformedNormal;
	#ifdef USE_TANGENT
		transformedTangent = bm * transformedTangent;
	#endif
#endif
#ifdef USE_INSTANCING
	mat3 im = mat3( instanceMatrix );
	transformedNormal /= vec3( dot( im[ 0 ], im[ 0 ] ), dot( im[ 1 ], im[ 1 ] ), dot( im[ 2 ], im[ 2 ] ) );
	transformedNormal = im * transformedNormal;
	#ifdef USE_TANGENT
		transformedTangent = im * transformedTangent;
	#endif
#endif
transformedNormal = normalMatrix * transformedNormal;
#ifdef FLIP_SIDED
	transformedNormal = - transformedNormal;
#endif
#ifdef USE_TANGENT
	transformedTangent = ( modelViewMatrix * vec4( transformedTangent, 0.0 ) ).xyz;
	#ifdef FLIP_SIDED
		transformedTangent = - transformedTangent;
	#endif
#endif`,Of=`#ifdef USE_DISPLACEMENTMAP
	uniform sampler2D displacementMap;
	uniform float displacementScale;
	uniform float displacementBias;
#endif`,Ff=`#ifdef USE_DISPLACEMENTMAP
	transformed += normalize( objectNormal ) * ( texture2D( displacementMap, vDisplacementMapUv ).x * displacementScale + displacementBias );
#endif`,Bf=`#ifdef USE_EMISSIVEMAP
	vec4 emissiveColor = texture2D( emissiveMap, vEmissiveMapUv );
	totalEmissiveRadiance *= emissiveColor.rgb;
#endif`,zf=`#ifdef USE_EMISSIVEMAP
	uniform sampler2D emissiveMap;
#endif`,kf="gl_FragColor = linearToOutputTexel( gl_FragColor );",Hf=`
const mat3 LINEAR_SRGB_TO_LINEAR_DISPLAY_P3 = mat3(
	vec3( 0.8224621, 0.177538, 0.0 ),
	vec3( 0.0331941, 0.9668058, 0.0 ),
	vec3( 0.0170827, 0.0723974, 0.9105199 )
);
const mat3 LINEAR_DISPLAY_P3_TO_LINEAR_SRGB = mat3(
	vec3( 1.2249401, - 0.2249404, 0.0 ),
	vec3( - 0.0420569, 1.0420571, 0.0 ),
	vec3( - 0.0196376, - 0.0786361, 1.0982735 )
);
vec4 LinearSRGBToLinearDisplayP3( in vec4 value ) {
	return vec4( value.rgb * LINEAR_SRGB_TO_LINEAR_DISPLAY_P3, value.a );
}
vec4 LinearDisplayP3ToLinearSRGB( in vec4 value ) {
	return vec4( value.rgb * LINEAR_DISPLAY_P3_TO_LINEAR_SRGB, value.a );
}
vec4 LinearTransferOETF( in vec4 value ) {
	return value;
}
vec4 sRGBTransferOETF( in vec4 value ) {
	return vec4( mix( pow( value.rgb, vec3( 0.41666 ) ) * 1.055 - vec3( 0.055 ), value.rgb * 12.92, vec3( lessThanEqual( value.rgb, vec3( 0.0031308 ) ) ) ), value.a );
}
vec4 LinearToLinear( in vec4 value ) {
	return value;
}
vec4 LinearTosRGB( in vec4 value ) {
	return sRGBTransferOETF( value );
}`,Vf=`#ifdef USE_ENVMAP
	#ifdef ENV_WORLDPOS
		vec3 cameraToFrag;
		if ( isOrthographic ) {
			cameraToFrag = normalize( vec3( - viewMatrix[ 0 ][ 2 ], - viewMatrix[ 1 ][ 2 ], - viewMatrix[ 2 ][ 2 ] ) );
		} else {
			cameraToFrag = normalize( vWorldPosition - cameraPosition );
		}
		vec3 worldNormal = inverseTransformDirection( normal, viewMatrix );
		#ifdef ENVMAP_MODE_REFLECTION
			vec3 reflectVec = reflect( cameraToFrag, worldNormal );
		#else
			vec3 reflectVec = refract( cameraToFrag, worldNormal, refractionRatio );
		#endif
	#else
		vec3 reflectVec = vReflect;
	#endif
	#ifdef ENVMAP_TYPE_CUBE
		vec4 envColor = textureCube( envMap, vec3( flipEnvMap * reflectVec.x, reflectVec.yz ) );
	#else
		vec4 envColor = vec4( 0.0 );
	#endif
	#ifdef ENVMAP_BLENDING_MULTIPLY
		outgoingLight = mix( outgoingLight, outgoingLight * envColor.xyz, specularStrength * reflectivity );
	#elif defined( ENVMAP_BLENDING_MIX )
		outgoingLight = mix( outgoingLight, envColor.xyz, specularStrength * reflectivity );
	#elif defined( ENVMAP_BLENDING_ADD )
		outgoingLight += envColor.xyz * specularStrength * reflectivity;
	#endif
#endif`,Gf=`#ifdef USE_ENVMAP
	uniform float envMapIntensity;
	uniform float flipEnvMap;
	#ifdef ENVMAP_TYPE_CUBE
		uniform samplerCube envMap;
	#else
		uniform sampler2D envMap;
	#endif
	
#endif`,Wf=`#ifdef USE_ENVMAP
	uniform float reflectivity;
	#if defined( USE_BUMPMAP ) || defined( USE_NORMALMAP ) || defined( PHONG ) || defined( LAMBERT )
		#define ENV_WORLDPOS
	#endif
	#ifdef ENV_WORLDPOS
		varying vec3 vWorldPosition;
		uniform float refractionRatio;
	#else
		varying vec3 vReflect;
	#endif
#endif`,Xf=`#ifdef USE_ENVMAP
	#if defined( USE_BUMPMAP ) || defined( USE_NORMALMAP ) || defined( PHONG ) || defined( LAMBERT )
		#define ENV_WORLDPOS
	#endif
	#ifdef ENV_WORLDPOS
		
		varying vec3 vWorldPosition;
	#else
		varying vec3 vReflect;
		uniform float refractionRatio;
	#endif
#endif`,Yf=`#ifdef USE_ENVMAP
	#ifdef ENV_WORLDPOS
		vWorldPosition = worldPosition.xyz;
	#else
		vec3 cameraToVertex;
		if ( isOrthographic ) {
			cameraToVertex = normalize( vec3( - viewMatrix[ 0 ][ 2 ], - viewMatrix[ 1 ][ 2 ], - viewMatrix[ 2 ][ 2 ] ) );
		} else {
			cameraToVertex = normalize( worldPosition.xyz - cameraPosition );
		}
		vec3 worldNormal = inverseTransformDirection( transformedNormal, viewMatrix );
		#ifdef ENVMAP_MODE_REFLECTION
			vReflect = reflect( cameraToVertex, worldNormal );
		#else
			vReflect = refract( cameraToVertex, worldNormal, refractionRatio );
		#endif
	#endif
#endif`,qf=`#ifdef USE_FOG
	vFogDepth = - mvPosition.z;
#endif`,Zf=`#ifdef USE_FOG
	varying float vFogDepth;
#endif`,Jf=`#ifdef USE_FOG
	#ifdef FOG_EXP2
		float fogFactor = 1.0 - exp( - fogDensity * fogDensity * vFogDepth * vFogDepth );
	#else
		float fogFactor = smoothstep( fogNear, fogFar, vFogDepth );
	#endif
	gl_FragColor.rgb = mix( gl_FragColor.rgb, fogColor, fogFactor );
#endif`,jf=`#ifdef USE_FOG
	uniform vec3 fogColor;
	varying float vFogDepth;
	#ifdef FOG_EXP2
		uniform float fogDensity;
	#else
		uniform float fogNear;
		uniform float fogFar;
	#endif
#endif`,$f=`#ifdef USE_GRADIENTMAP
	uniform sampler2D gradientMap;
#endif
vec3 getGradientIrradiance( vec3 normal, vec3 lightDirection ) {
	float dotNL = dot( normal, lightDirection );
	vec2 coord = vec2( dotNL * 0.5 + 0.5, 0.0 );
	#ifdef USE_GRADIENTMAP
		return vec3( texture2D( gradientMap, coord ).r );
	#else
		vec2 fw = fwidth( coord ) * 0.5;
		return mix( vec3( 0.7 ), vec3( 1.0 ), smoothstep( 0.7 - fw.x, 0.7 + fw.x, coord.x ) );
	#endif
}`,Kf=`#ifdef USE_LIGHTMAP
	vec4 lightMapTexel = texture2D( lightMap, vLightMapUv );
	vec3 lightMapIrradiance = lightMapTexel.rgb * lightMapIntensity;
	reflectedLight.indirectDiffuse += lightMapIrradiance;
#endif`,Qf=`#ifdef USE_LIGHTMAP
	uniform sampler2D lightMap;
	uniform float lightMapIntensity;
#endif`,tp=`LambertMaterial material;
material.diffuseColor = diffuseColor.rgb;
material.specularStrength = specularStrength;`,ep=`varying vec3 vViewPosition;
struct LambertMaterial {
	vec3 diffuseColor;
	float specularStrength;
};
void RE_Direct_Lambert( const in IncidentLight directLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in LambertMaterial material, inout ReflectedLight reflectedLight ) {
	float dotNL = saturate( dot( geometryNormal, directLight.direction ) );
	vec3 irradiance = dotNL * directLight.color;
	reflectedLight.directDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
void RE_IndirectDiffuse_Lambert( const in vec3 irradiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in LambertMaterial material, inout ReflectedLight reflectedLight ) {
	reflectedLight.indirectDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
#define RE_Direct				RE_Direct_Lambert
#define RE_IndirectDiffuse		RE_IndirectDiffuse_Lambert`,np=`uniform bool receiveShadow;
uniform vec3 ambientLightColor;
#if defined( USE_LIGHT_PROBES )
	uniform vec3 lightProbe[ 9 ];
#endif
vec3 shGetIrradianceAt( in vec3 normal, in vec3 shCoefficients[ 9 ] ) {
	float x = normal.x, y = normal.y, z = normal.z;
	vec3 result = shCoefficients[ 0 ] * 0.886227;
	result += shCoefficients[ 1 ] * 2.0 * 0.511664 * y;
	result += shCoefficients[ 2 ] * 2.0 * 0.511664 * z;
	result += shCoefficients[ 3 ] * 2.0 * 0.511664 * x;
	result += shCoefficients[ 4 ] * 2.0 * 0.429043 * x * y;
	result += shCoefficients[ 5 ] * 2.0 * 0.429043 * y * z;
	result += shCoefficients[ 6 ] * ( 0.743125 * z * z - 0.247708 );
	result += shCoefficients[ 7 ] * 2.0 * 0.429043 * x * z;
	result += shCoefficients[ 8 ] * 0.429043 * ( x * x - y * y );
	return result;
}
vec3 getLightProbeIrradiance( const in vec3 lightProbe[ 9 ], const in vec3 normal ) {
	vec3 worldNormal = inverseTransformDirection( normal, viewMatrix );
	vec3 irradiance = shGetIrradianceAt( worldNormal, lightProbe );
	return irradiance;
}
vec3 getAmbientLightIrradiance( const in vec3 ambientLightColor ) {
	vec3 irradiance = ambientLightColor;
	return irradiance;
}
float getDistanceAttenuation( const in float lightDistance, const in float cutoffDistance, const in float decayExponent ) {
	#if defined ( LEGACY_LIGHTS )
		if ( cutoffDistance > 0.0 && decayExponent > 0.0 ) {
			return pow( saturate( - lightDistance / cutoffDistance + 1.0 ), decayExponent );
		}
		return 1.0;
	#else
		float distanceFalloff = 1.0 / max( pow( lightDistance, decayExponent ), 0.01 );
		if ( cutoffDistance > 0.0 ) {
			distanceFalloff *= pow2( saturate( 1.0 - pow4( lightDistance / cutoffDistance ) ) );
		}
		return distanceFalloff;
	#endif
}
float getSpotAttenuation( const in float coneCosine, const in float penumbraCosine, const in float angleCosine ) {
	return smoothstep( coneCosine, penumbraCosine, angleCosine );
}
#if NUM_DIR_LIGHTS > 0
	struct DirectionalLight {
		vec3 direction;
		vec3 color;
	};
	uniform DirectionalLight directionalLights[ NUM_DIR_LIGHTS ];
	void getDirectionalLightInfo( const in DirectionalLight directionalLight, out IncidentLight light ) {
		light.color = directionalLight.color;
		light.direction = directionalLight.direction;
		light.visible = true;
	}
#endif
#if NUM_POINT_LIGHTS > 0
	struct PointLight {
		vec3 position;
		vec3 color;
		float distance;
		float decay;
	};
	uniform PointLight pointLights[ NUM_POINT_LIGHTS ];
	void getPointLightInfo( const in PointLight pointLight, const in vec3 geometryPosition, out IncidentLight light ) {
		vec3 lVector = pointLight.position - geometryPosition;
		light.direction = normalize( lVector );
		float lightDistance = length( lVector );
		light.color = pointLight.color;
		light.color *= getDistanceAttenuation( lightDistance, pointLight.distance, pointLight.decay );
		light.visible = ( light.color != vec3( 0.0 ) );
	}
#endif
#if NUM_SPOT_LIGHTS > 0
	struct SpotLight {
		vec3 position;
		vec3 direction;
		vec3 color;
		float distance;
		float decay;
		float coneCos;
		float penumbraCos;
	};
	uniform SpotLight spotLights[ NUM_SPOT_LIGHTS ];
	void getSpotLightInfo( const in SpotLight spotLight, const in vec3 geometryPosition, out IncidentLight light ) {
		vec3 lVector = spotLight.position - geometryPosition;
		light.direction = normalize( lVector );
		float angleCos = dot( light.direction, spotLight.direction );
		float spotAttenuation = getSpotAttenuation( spotLight.coneCos, spotLight.penumbraCos, angleCos );
		if ( spotAttenuation > 0.0 ) {
			float lightDistance = length( lVector );
			light.color = spotLight.color * spotAttenuation;
			light.color *= getDistanceAttenuation( lightDistance, spotLight.distance, spotLight.decay );
			light.visible = ( light.color != vec3( 0.0 ) );
		} else {
			light.color = vec3( 0.0 );
			light.visible = false;
		}
	}
#endif
#if NUM_RECT_AREA_LIGHTS > 0
	struct RectAreaLight {
		vec3 color;
		vec3 position;
		vec3 halfWidth;
		vec3 halfHeight;
	};
	uniform sampler2D ltc_1;	uniform sampler2D ltc_2;
	uniform RectAreaLight rectAreaLights[ NUM_RECT_AREA_LIGHTS ];
#endif
#if NUM_HEMI_LIGHTS > 0
	struct HemisphereLight {
		vec3 direction;
		vec3 skyColor;
		vec3 groundColor;
	};
	uniform HemisphereLight hemisphereLights[ NUM_HEMI_LIGHTS ];
	vec3 getHemisphereLightIrradiance( const in HemisphereLight hemiLight, const in vec3 normal ) {
		float dotNL = dot( normal, hemiLight.direction );
		float hemiDiffuseWeight = 0.5 * dotNL + 0.5;
		vec3 irradiance = mix( hemiLight.groundColor, hemiLight.skyColor, hemiDiffuseWeight );
		return irradiance;
	}
#endif`,ip=`#ifdef USE_ENVMAP
	vec3 getIBLIrradiance( const in vec3 normal ) {
		#ifdef ENVMAP_TYPE_CUBE_UV
			vec3 worldNormal = inverseTransformDirection( normal, viewMatrix );
			vec4 envMapColor = textureCubeUV( envMap, worldNormal, 1.0 );
			return PI * envMapColor.rgb * envMapIntensity;
		#else
			return vec3( 0.0 );
		#endif
	}
	vec3 getIBLRadiance( const in vec3 viewDir, const in vec3 normal, const in float roughness ) {
		#ifdef ENVMAP_TYPE_CUBE_UV
			vec3 reflectVec = reflect( - viewDir, normal );
			reflectVec = normalize( mix( reflectVec, normal, roughness * roughness) );
			reflectVec = inverseTransformDirection( reflectVec, viewMatrix );
			vec4 envMapColor = textureCubeUV( envMap, reflectVec, roughness );
			return envMapColor.rgb * envMapIntensity;
		#else
			return vec3( 0.0 );
		#endif
	}
	#ifdef USE_ANISOTROPY
		vec3 getIBLAnisotropyRadiance( const in vec3 viewDir, const in vec3 normal, const in float roughness, const in vec3 bitangent, const in float anisotropy ) {
			#ifdef ENVMAP_TYPE_CUBE_UV
				vec3 bentNormal = cross( bitangent, viewDir );
				bentNormal = normalize( cross( bentNormal, bitangent ) );
				bentNormal = normalize( mix( bentNormal, normal, pow2( pow2( 1.0 - anisotropy * ( 1.0 - roughness ) ) ) ) );
				return getIBLRadiance( viewDir, bentNormal, roughness );
			#else
				return vec3( 0.0 );
			#endif
		}
	#endif
#endif`,sp=`ToonMaterial material;
material.diffuseColor = diffuseColor.rgb;`,rp=`varying vec3 vViewPosition;
struct ToonMaterial {
	vec3 diffuseColor;
};
void RE_Direct_Toon( const in IncidentLight directLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in ToonMaterial material, inout ReflectedLight reflectedLight ) {
	vec3 irradiance = getGradientIrradiance( geometryNormal, directLight.direction ) * directLight.color;
	reflectedLight.directDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
void RE_IndirectDiffuse_Toon( const in vec3 irradiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in ToonMaterial material, inout ReflectedLight reflectedLight ) {
	reflectedLight.indirectDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
#define RE_Direct				RE_Direct_Toon
#define RE_IndirectDiffuse		RE_IndirectDiffuse_Toon`,ap=`BlinnPhongMaterial material;
material.diffuseColor = diffuseColor.rgb;
material.specularColor = specular;
material.specularShininess = shininess;
material.specularStrength = specularStrength;`,op=`varying vec3 vViewPosition;
struct BlinnPhongMaterial {
	vec3 diffuseColor;
	vec3 specularColor;
	float specularShininess;
	float specularStrength;
};
void RE_Direct_BlinnPhong( const in IncidentLight directLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in BlinnPhongMaterial material, inout ReflectedLight reflectedLight ) {
	float dotNL = saturate( dot( geometryNormal, directLight.direction ) );
	vec3 irradiance = dotNL * directLight.color;
	reflectedLight.directDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
	reflectedLight.directSpecular += irradiance * BRDF_BlinnPhong( directLight.direction, geometryViewDir, geometryNormal, material.specularColor, material.specularShininess ) * material.specularStrength;
}
void RE_IndirectDiffuse_BlinnPhong( const in vec3 irradiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in BlinnPhongMaterial material, inout ReflectedLight reflectedLight ) {
	reflectedLight.indirectDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
#define RE_Direct				RE_Direct_BlinnPhong
#define RE_IndirectDiffuse		RE_IndirectDiffuse_BlinnPhong`,lp=`PhysicalMaterial material;
material.diffuseColor = diffuseColor.rgb * ( 1.0 - metalnessFactor );
vec3 dxy = max( abs( dFdx( nonPerturbedNormal ) ), abs( dFdy( nonPerturbedNormal ) ) );
float geometryRoughness = max( max( dxy.x, dxy.y ), dxy.z );
material.roughness = max( roughnessFactor, 0.0525 );material.roughness += geometryRoughness;
material.roughness = min( material.roughness, 1.0 );
#ifdef IOR
	material.ior = ior;
	#ifdef USE_SPECULAR
		float specularIntensityFactor = specularIntensity;
		vec3 specularColorFactor = specularColor;
		#ifdef USE_SPECULAR_COLORMAP
			specularColorFactor *= texture2D( specularColorMap, vSpecularColorMapUv ).rgb;
		#endif
		#ifdef USE_SPECULAR_INTENSITYMAP
			specularIntensityFactor *= texture2D( specularIntensityMap, vSpecularIntensityMapUv ).a;
		#endif
		material.specularF90 = mix( specularIntensityFactor, 1.0, metalnessFactor );
	#else
		float specularIntensityFactor = 1.0;
		vec3 specularColorFactor = vec3( 1.0 );
		material.specularF90 = 1.0;
	#endif
	material.specularColor = mix( min( pow2( ( material.ior - 1.0 ) / ( material.ior + 1.0 ) ) * specularColorFactor, vec3( 1.0 ) ) * specularIntensityFactor, diffuseColor.rgb, metalnessFactor );
#else
	material.specularColor = mix( vec3( 0.04 ), diffuseColor.rgb, metalnessFactor );
	material.specularF90 = 1.0;
#endif
#ifdef USE_CLEARCOAT
	material.clearcoat = clearcoat;
	material.clearcoatRoughness = clearcoatRoughness;
	material.clearcoatF0 = vec3( 0.04 );
	material.clearcoatF90 = 1.0;
	#ifdef USE_CLEARCOATMAP
		material.clearcoat *= texture2D( clearcoatMap, vClearcoatMapUv ).x;
	#endif
	#ifdef USE_CLEARCOAT_ROUGHNESSMAP
		material.clearcoatRoughness *= texture2D( clearcoatRoughnessMap, vClearcoatRoughnessMapUv ).y;
	#endif
	material.clearcoat = saturate( material.clearcoat );	material.clearcoatRoughness = max( material.clearcoatRoughness, 0.0525 );
	material.clearcoatRoughness += geometryRoughness;
	material.clearcoatRoughness = min( material.clearcoatRoughness, 1.0 );
#endif
#ifdef USE_IRIDESCENCE
	material.iridescence = iridescence;
	material.iridescenceIOR = iridescenceIOR;
	#ifdef USE_IRIDESCENCEMAP
		material.iridescence *= texture2D( iridescenceMap, vIridescenceMapUv ).r;
	#endif
	#ifdef USE_IRIDESCENCE_THICKNESSMAP
		material.iridescenceThickness = (iridescenceThicknessMaximum - iridescenceThicknessMinimum) * texture2D( iridescenceThicknessMap, vIridescenceThicknessMapUv ).g + iridescenceThicknessMinimum;
	#else
		material.iridescenceThickness = iridescenceThicknessMaximum;
	#endif
#endif
#ifdef USE_SHEEN
	material.sheenColor = sheenColor;
	#ifdef USE_SHEEN_COLORMAP
		material.sheenColor *= texture2D( sheenColorMap, vSheenColorMapUv ).rgb;
	#endif
	material.sheenRoughness = clamp( sheenRoughness, 0.07, 1.0 );
	#ifdef USE_SHEEN_ROUGHNESSMAP
		material.sheenRoughness *= texture2D( sheenRoughnessMap, vSheenRoughnessMapUv ).a;
	#endif
#endif
#ifdef USE_ANISOTROPY
	#ifdef USE_ANISOTROPYMAP
		mat2 anisotropyMat = mat2( anisotropyVector.x, anisotropyVector.y, - anisotropyVector.y, anisotropyVector.x );
		vec3 anisotropyPolar = texture2D( anisotropyMap, vAnisotropyMapUv ).rgb;
		vec2 anisotropyV = anisotropyMat * normalize( 2.0 * anisotropyPolar.rg - vec2( 1.0 ) ) * anisotropyPolar.b;
	#else
		vec2 anisotropyV = anisotropyVector;
	#endif
	material.anisotropy = length( anisotropyV );
	if( material.anisotropy == 0.0 ) {
		anisotropyV = vec2( 1.0, 0.0 );
	} else {
		anisotropyV /= material.anisotropy;
		material.anisotropy = saturate( material.anisotropy );
	}
	material.alphaT = mix( pow2( material.roughness ), 1.0, pow2( material.anisotropy ) );
	material.anisotropyT = tbn[ 0 ] * anisotropyV.x + tbn[ 1 ] * anisotropyV.y;
	material.anisotropyB = tbn[ 1 ] * anisotropyV.x - tbn[ 0 ] * anisotropyV.y;
#endif`,cp=`struct PhysicalMaterial {
	vec3 diffuseColor;
	float roughness;
	vec3 specularColor;
	float specularF90;
	#ifdef USE_CLEARCOAT
		float clearcoat;
		float clearcoatRoughness;
		vec3 clearcoatF0;
		float clearcoatF90;
	#endif
	#ifdef USE_IRIDESCENCE
		float iridescence;
		float iridescenceIOR;
		float iridescenceThickness;
		vec3 iridescenceFresnel;
		vec3 iridescenceF0;
	#endif
	#ifdef USE_SHEEN
		vec3 sheenColor;
		float sheenRoughness;
	#endif
	#ifdef IOR
		float ior;
	#endif
	#ifdef USE_TRANSMISSION
		float transmission;
		float transmissionAlpha;
		float thickness;
		float attenuationDistance;
		vec3 attenuationColor;
	#endif
	#ifdef USE_ANISOTROPY
		float anisotropy;
		float alphaT;
		vec3 anisotropyT;
		vec3 anisotropyB;
	#endif
};
vec3 clearcoatSpecularDirect = vec3( 0.0 );
vec3 clearcoatSpecularIndirect = vec3( 0.0 );
vec3 sheenSpecularDirect = vec3( 0.0 );
vec3 sheenSpecularIndirect = vec3(0.0 );
vec3 Schlick_to_F0( const in vec3 f, const in float f90, const in float dotVH ) {
    float x = clamp( 1.0 - dotVH, 0.0, 1.0 );
    float x2 = x * x;
    float x5 = clamp( x * x2 * x2, 0.0, 0.9999 );
    return ( f - vec3( f90 ) * x5 ) / ( 1.0 - x5 );
}
float V_GGX_SmithCorrelated( const in float alpha, const in float dotNL, const in float dotNV ) {
	float a2 = pow2( alpha );
	float gv = dotNL * sqrt( a2 + ( 1.0 - a2 ) * pow2( dotNV ) );
	float gl = dotNV * sqrt( a2 + ( 1.0 - a2 ) * pow2( dotNL ) );
	return 0.5 / max( gv + gl, EPSILON );
}
float D_GGX( const in float alpha, const in float dotNH ) {
	float a2 = pow2( alpha );
	float denom = pow2( dotNH ) * ( a2 - 1.0 ) + 1.0;
	return RECIPROCAL_PI * a2 / pow2( denom );
}
#ifdef USE_ANISOTROPY
	float V_GGX_SmithCorrelated_Anisotropic( const in float alphaT, const in float alphaB, const in float dotTV, const in float dotBV, const in float dotTL, const in float dotBL, const in float dotNV, const in float dotNL ) {
		float gv = dotNL * length( vec3( alphaT * dotTV, alphaB * dotBV, dotNV ) );
		float gl = dotNV * length( vec3( alphaT * dotTL, alphaB * dotBL, dotNL ) );
		float v = 0.5 / ( gv + gl );
		return saturate(v);
	}
	float D_GGX_Anisotropic( const in float alphaT, const in float alphaB, const in float dotNH, const in float dotTH, const in float dotBH ) {
		float a2 = alphaT * alphaB;
		highp vec3 v = vec3( alphaB * dotTH, alphaT * dotBH, a2 * dotNH );
		highp float v2 = dot( v, v );
		float w2 = a2 / v2;
		return RECIPROCAL_PI * a2 * pow2 ( w2 );
	}
#endif
#ifdef USE_CLEARCOAT
	vec3 BRDF_GGX_Clearcoat( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, const in PhysicalMaterial material) {
		vec3 f0 = material.clearcoatF0;
		float f90 = material.clearcoatF90;
		float roughness = material.clearcoatRoughness;
		float alpha = pow2( roughness );
		vec3 halfDir = normalize( lightDir + viewDir );
		float dotNL = saturate( dot( normal, lightDir ) );
		float dotNV = saturate( dot( normal, viewDir ) );
		float dotNH = saturate( dot( normal, halfDir ) );
		float dotVH = saturate( dot( viewDir, halfDir ) );
		vec3 F = F_Schlick( f0, f90, dotVH );
		float V = V_GGX_SmithCorrelated( alpha, dotNL, dotNV );
		float D = D_GGX( alpha, dotNH );
		return F * ( V * D );
	}
#endif
vec3 BRDF_GGX( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, const in PhysicalMaterial material ) {
	vec3 f0 = material.specularColor;
	float f90 = material.specularF90;
	float roughness = material.roughness;
	float alpha = pow2( roughness );
	vec3 halfDir = normalize( lightDir + viewDir );
	float dotNL = saturate( dot( normal, lightDir ) );
	float dotNV = saturate( dot( normal, viewDir ) );
	float dotNH = saturate( dot( normal, halfDir ) );
	float dotVH = saturate( dot( viewDir, halfDir ) );
	vec3 F = F_Schlick( f0, f90, dotVH );
	#ifdef USE_IRIDESCENCE
		F = mix( F, material.iridescenceFresnel, material.iridescence );
	#endif
	#ifdef USE_ANISOTROPY
		float dotTL = dot( material.anisotropyT, lightDir );
		float dotTV = dot( material.anisotropyT, viewDir );
		float dotTH = dot( material.anisotropyT, halfDir );
		float dotBL = dot( material.anisotropyB, lightDir );
		float dotBV = dot( material.anisotropyB, viewDir );
		float dotBH = dot( material.anisotropyB, halfDir );
		float V = V_GGX_SmithCorrelated_Anisotropic( material.alphaT, alpha, dotTV, dotBV, dotTL, dotBL, dotNV, dotNL );
		float D = D_GGX_Anisotropic( material.alphaT, alpha, dotNH, dotTH, dotBH );
	#else
		float V = V_GGX_SmithCorrelated( alpha, dotNL, dotNV );
		float D = D_GGX( alpha, dotNH );
	#endif
	return F * ( V * D );
}
vec2 LTC_Uv( const in vec3 N, const in vec3 V, const in float roughness ) {
	const float LUT_SIZE = 64.0;
	const float LUT_SCALE = ( LUT_SIZE - 1.0 ) / LUT_SIZE;
	const float LUT_BIAS = 0.5 / LUT_SIZE;
	float dotNV = saturate( dot( N, V ) );
	vec2 uv = vec2( roughness, sqrt( 1.0 - dotNV ) );
	uv = uv * LUT_SCALE + LUT_BIAS;
	return uv;
}
float LTC_ClippedSphereFormFactor( const in vec3 f ) {
	float l = length( f );
	return max( ( l * l + f.z ) / ( l + 1.0 ), 0.0 );
}
vec3 LTC_EdgeVectorFormFactor( const in vec3 v1, const in vec3 v2 ) {
	float x = dot( v1, v2 );
	float y = abs( x );
	float a = 0.8543985 + ( 0.4965155 + 0.0145206 * y ) * y;
	float b = 3.4175940 + ( 4.1616724 + y ) * y;
	float v = a / b;
	float theta_sintheta = ( x > 0.0 ) ? v : 0.5 * inversesqrt( max( 1.0 - x * x, 1e-7 ) ) - v;
	return cross( v1, v2 ) * theta_sintheta;
}
vec3 LTC_Evaluate( const in vec3 N, const in vec3 V, const in vec3 P, const in mat3 mInv, const in vec3 rectCoords[ 4 ] ) {
	vec3 v1 = rectCoords[ 1 ] - rectCoords[ 0 ];
	vec3 v2 = rectCoords[ 3 ] - rectCoords[ 0 ];
	vec3 lightNormal = cross( v1, v2 );
	if( dot( lightNormal, P - rectCoords[ 0 ] ) < 0.0 ) return vec3( 0.0 );
	vec3 T1, T2;
	T1 = normalize( V - N * dot( V, N ) );
	T2 = - cross( N, T1 );
	mat3 mat = mInv * transposeMat3( mat3( T1, T2, N ) );
	vec3 coords[ 4 ];
	coords[ 0 ] = mat * ( rectCoords[ 0 ] - P );
	coords[ 1 ] = mat * ( rectCoords[ 1 ] - P );
	coords[ 2 ] = mat * ( rectCoords[ 2 ] - P );
	coords[ 3 ] = mat * ( rectCoords[ 3 ] - P );
	coords[ 0 ] = normalize( coords[ 0 ] );
	coords[ 1 ] = normalize( coords[ 1 ] );
	coords[ 2 ] = normalize( coords[ 2 ] );
	coords[ 3 ] = normalize( coords[ 3 ] );
	vec3 vectorFormFactor = vec3( 0.0 );
	vectorFormFactor += LTC_EdgeVectorFormFactor( coords[ 0 ], coords[ 1 ] );
	vectorFormFactor += LTC_EdgeVectorFormFactor( coords[ 1 ], coords[ 2 ] );
	vectorFormFactor += LTC_EdgeVectorFormFactor( coords[ 2 ], coords[ 3 ] );
	vectorFormFactor += LTC_EdgeVectorFormFactor( coords[ 3 ], coords[ 0 ] );
	float result = LTC_ClippedSphereFormFactor( vectorFormFactor );
	return vec3( result );
}
#if defined( USE_SHEEN )
float D_Charlie( float roughness, float dotNH ) {
	float alpha = pow2( roughness );
	float invAlpha = 1.0 / alpha;
	float cos2h = dotNH * dotNH;
	float sin2h = max( 1.0 - cos2h, 0.0078125 );
	return ( 2.0 + invAlpha ) * pow( sin2h, invAlpha * 0.5 ) / ( 2.0 * PI );
}
float V_Neubelt( float dotNV, float dotNL ) {
	return saturate( 1.0 / ( 4.0 * ( dotNL + dotNV - dotNL * dotNV ) ) );
}
vec3 BRDF_Sheen( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, vec3 sheenColor, const in float sheenRoughness ) {
	vec3 halfDir = normalize( lightDir + viewDir );
	float dotNL = saturate( dot( normal, lightDir ) );
	float dotNV = saturate( dot( normal, viewDir ) );
	float dotNH = saturate( dot( normal, halfDir ) );
	float D = D_Charlie( sheenRoughness, dotNH );
	float V = V_Neubelt( dotNV, dotNL );
	return sheenColor * ( D * V );
}
#endif
float IBLSheenBRDF( const in vec3 normal, const in vec3 viewDir, const in float roughness ) {
	float dotNV = saturate( dot( normal, viewDir ) );
	float r2 = roughness * roughness;
	float a = roughness < 0.25 ? -339.2 * r2 + 161.4 * roughness - 25.9 : -8.48 * r2 + 14.3 * roughness - 9.95;
	float b = roughness < 0.25 ? 44.0 * r2 - 23.7 * roughness + 3.26 : 1.97 * r2 - 3.27 * roughness + 0.72;
	float DG = exp( a * dotNV + b ) + ( roughness < 0.25 ? 0.0 : 0.1 * ( roughness - 0.25 ) );
	return saturate( DG * RECIPROCAL_PI );
}
vec2 DFGApprox( const in vec3 normal, const in vec3 viewDir, const in float roughness ) {
	float dotNV = saturate( dot( normal, viewDir ) );
	const vec4 c0 = vec4( - 1, - 0.0275, - 0.572, 0.022 );
	const vec4 c1 = vec4( 1, 0.0425, 1.04, - 0.04 );
	vec4 r = roughness * c0 + c1;
	float a004 = min( r.x * r.x, exp2( - 9.28 * dotNV ) ) * r.x + r.y;
	vec2 fab = vec2( - 1.04, 1.04 ) * a004 + r.zw;
	return fab;
}
vec3 EnvironmentBRDF( const in vec3 normal, const in vec3 viewDir, const in vec3 specularColor, const in float specularF90, const in float roughness ) {
	vec2 fab = DFGApprox( normal, viewDir, roughness );
	return specularColor * fab.x + specularF90 * fab.y;
}
#ifdef USE_IRIDESCENCE
void computeMultiscatteringIridescence( const in vec3 normal, const in vec3 viewDir, const in vec3 specularColor, const in float specularF90, const in float iridescence, const in vec3 iridescenceF0, const in float roughness, inout vec3 singleScatter, inout vec3 multiScatter ) {
#else
void computeMultiscattering( const in vec3 normal, const in vec3 viewDir, const in vec3 specularColor, const in float specularF90, const in float roughness, inout vec3 singleScatter, inout vec3 multiScatter ) {
#endif
	vec2 fab = DFGApprox( normal, viewDir, roughness );
	#ifdef USE_IRIDESCENCE
		vec3 Fr = mix( specularColor, iridescenceF0, iridescence );
	#else
		vec3 Fr = specularColor;
	#endif
	vec3 FssEss = Fr * fab.x + specularF90 * fab.y;
	float Ess = fab.x + fab.y;
	float Ems = 1.0 - Ess;
	vec3 Favg = Fr + ( 1.0 - Fr ) * 0.047619;	vec3 Fms = FssEss * Favg / ( 1.0 - Ems * Favg );
	singleScatter += FssEss;
	multiScatter += Fms * Ems;
}
#if NUM_RECT_AREA_LIGHTS > 0
	void RE_Direct_RectArea_Physical( const in RectAreaLight rectAreaLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in PhysicalMaterial material, inout ReflectedLight reflectedLight ) {
		vec3 normal = geometryNormal;
		vec3 viewDir = geometryViewDir;
		vec3 position = geometryPosition;
		vec3 lightPos = rectAreaLight.position;
		vec3 halfWidth = rectAreaLight.halfWidth;
		vec3 halfHeight = rectAreaLight.halfHeight;
		vec3 lightColor = rectAreaLight.color;
		float roughness = material.roughness;
		vec3 rectCoords[ 4 ];
		rectCoords[ 0 ] = lightPos + halfWidth - halfHeight;		rectCoords[ 1 ] = lightPos - halfWidth - halfHeight;
		rectCoords[ 2 ] = lightPos - halfWidth + halfHeight;
		rectCoords[ 3 ] = lightPos + halfWidth + halfHeight;
		vec2 uv = LTC_Uv( normal, viewDir, roughness );
		vec4 t1 = texture2D( ltc_1, uv );
		vec4 t2 = texture2D( ltc_2, uv );
		mat3 mInv = mat3(
			vec3( t1.x, 0, t1.y ),
			vec3(    0, 1,    0 ),
			vec3( t1.z, 0, t1.w )
		);
		vec3 fresnel = ( material.specularColor * t2.x + ( vec3( 1.0 ) - material.specularColor ) * t2.y );
		reflectedLight.directSpecular += lightColor * fresnel * LTC_Evaluate( normal, viewDir, position, mInv, rectCoords );
		reflectedLight.directDiffuse += lightColor * material.diffuseColor * LTC_Evaluate( normal, viewDir, position, mat3( 1.0 ), rectCoords );
	}
#endif
void RE_Direct_Physical( const in IncidentLight directLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in PhysicalMaterial material, inout ReflectedLight reflectedLight ) {
	float dotNL = saturate( dot( geometryNormal, directLight.direction ) );
	vec3 irradiance = dotNL * directLight.color;
	#ifdef USE_CLEARCOAT
		float dotNLcc = saturate( dot( geometryClearcoatNormal, directLight.direction ) );
		vec3 ccIrradiance = dotNLcc * directLight.color;
		clearcoatSpecularDirect += ccIrradiance * BRDF_GGX_Clearcoat( directLight.direction, geometryViewDir, geometryClearcoatNormal, material );
	#endif
	#ifdef USE_SHEEN
		sheenSpecularDirect += irradiance * BRDF_Sheen( directLight.direction, geometryViewDir, geometryNormal, material.sheenColor, material.sheenRoughness );
	#endif
	reflectedLight.directSpecular += irradiance * BRDF_GGX( directLight.direction, geometryViewDir, geometryNormal, material );
	reflectedLight.directDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
void RE_IndirectDiffuse_Physical( const in vec3 irradiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in PhysicalMaterial material, inout ReflectedLight reflectedLight ) {
	reflectedLight.indirectDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
void RE_IndirectSpecular_Physical( const in vec3 radiance, const in vec3 irradiance, const in vec3 clearcoatRadiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in PhysicalMaterial material, inout ReflectedLight reflectedLight) {
	#ifdef USE_CLEARCOAT
		clearcoatSpecularIndirect += clearcoatRadiance * EnvironmentBRDF( geometryClearcoatNormal, geometryViewDir, material.clearcoatF0, material.clearcoatF90, material.clearcoatRoughness );
	#endif
	#ifdef USE_SHEEN
		sheenSpecularIndirect += irradiance * material.sheenColor * IBLSheenBRDF( geometryNormal, geometryViewDir, material.sheenRoughness );
	#endif
	vec3 singleScattering = vec3( 0.0 );
	vec3 multiScattering = vec3( 0.0 );
	vec3 cosineWeightedIrradiance = irradiance * RECIPROCAL_PI;
	#ifdef USE_IRIDESCENCE
		computeMultiscatteringIridescence( geometryNormal, geometryViewDir, material.specularColor, material.specularF90, material.iridescence, material.iridescenceFresnel, material.roughness, singleScattering, multiScattering );
	#else
		computeMultiscattering( geometryNormal, geometryViewDir, material.specularColor, material.specularF90, material.roughness, singleScattering, multiScattering );
	#endif
	vec3 totalScattering = singleScattering + multiScattering;
	vec3 diffuse = material.diffuseColor * ( 1.0 - max( max( totalScattering.r, totalScattering.g ), totalScattering.b ) );
	reflectedLight.indirectSpecular += radiance * singleScattering;
	reflectedLight.indirectSpecular += multiScattering * cosineWeightedIrradiance;
	reflectedLight.indirectDiffuse += diffuse * cosineWeightedIrradiance;
}
#define RE_Direct				RE_Direct_Physical
#define RE_Direct_RectArea		RE_Direct_RectArea_Physical
#define RE_IndirectDiffuse		RE_IndirectDiffuse_Physical
#define RE_IndirectSpecular		RE_IndirectSpecular_Physical
float computeSpecularOcclusion( const in float dotNV, const in float ambientOcclusion, const in float roughness ) {
	return saturate( pow( dotNV + ambientOcclusion, exp2( - 16.0 * roughness - 1.0 ) ) - 1.0 + ambientOcclusion );
}`,hp=`
vec3 geometryPosition = - vViewPosition;
vec3 geometryNormal = normal;
vec3 geometryViewDir = ( isOrthographic ) ? vec3( 0, 0, 1 ) : normalize( vViewPosition );
vec3 geometryClearcoatNormal = vec3( 0.0 );
#ifdef USE_CLEARCOAT
	geometryClearcoatNormal = clearcoatNormal;
#endif
#ifdef USE_IRIDESCENCE
	float dotNVi = saturate( dot( normal, geometryViewDir ) );
	if ( material.iridescenceThickness == 0.0 ) {
		material.iridescence = 0.0;
	} else {
		material.iridescence = saturate( material.iridescence );
	}
	if ( material.iridescence > 0.0 ) {
		material.iridescenceFresnel = evalIridescence( 1.0, material.iridescenceIOR, dotNVi, material.iridescenceThickness, material.specularColor );
		material.iridescenceF0 = Schlick_to_F0( material.iridescenceFresnel, 1.0, dotNVi );
	}
#endif
IncidentLight directLight;
#if ( NUM_POINT_LIGHTS > 0 ) && defined( RE_Direct )
	PointLight pointLight;
	#if defined( USE_SHADOWMAP ) && NUM_POINT_LIGHT_SHADOWS > 0
	PointLightShadow pointLightShadow;
	#endif
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_POINT_LIGHTS; i ++ ) {
		pointLight = pointLights[ i ];
		getPointLightInfo( pointLight, geometryPosition, directLight );
		#if defined( USE_SHADOWMAP ) && ( UNROLLED_LOOP_INDEX < NUM_POINT_LIGHT_SHADOWS )
		pointLightShadow = pointLightShadows[ i ];
		directLight.color *= ( directLight.visible && receiveShadow ) ? getPointShadow( pointShadowMap[ i ], pointLightShadow.shadowMapSize, pointLightShadow.shadowBias, pointLightShadow.shadowRadius, vPointShadowCoord[ i ], pointLightShadow.shadowCameraNear, pointLightShadow.shadowCameraFar ) : 1.0;
		#endif
		RE_Direct( directLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
	}
	#pragma unroll_loop_end
#endif
#if ( NUM_SPOT_LIGHTS > 0 ) && defined( RE_Direct )
	SpotLight spotLight;
	vec4 spotColor;
	vec3 spotLightCoord;
	bool inSpotLightMap;
	#if defined( USE_SHADOWMAP ) && NUM_SPOT_LIGHT_SHADOWS > 0
	SpotLightShadow spotLightShadow;
	#endif
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_SPOT_LIGHTS; i ++ ) {
		spotLight = spotLights[ i ];
		getSpotLightInfo( spotLight, geometryPosition, directLight );
		#if ( UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS_WITH_MAPS )
		#define SPOT_LIGHT_MAP_INDEX UNROLLED_LOOP_INDEX
		#elif ( UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS )
		#define SPOT_LIGHT_MAP_INDEX NUM_SPOT_LIGHT_MAPS
		#else
		#define SPOT_LIGHT_MAP_INDEX ( UNROLLED_LOOP_INDEX - NUM_SPOT_LIGHT_SHADOWS + NUM_SPOT_LIGHT_SHADOWS_WITH_MAPS )
		#endif
		#if ( SPOT_LIGHT_MAP_INDEX < NUM_SPOT_LIGHT_MAPS )
			spotLightCoord = vSpotLightCoord[ i ].xyz / vSpotLightCoord[ i ].w;
			inSpotLightMap = all( lessThan( abs( spotLightCoord * 2. - 1. ), vec3( 1.0 ) ) );
			spotColor = texture2D( spotLightMap[ SPOT_LIGHT_MAP_INDEX ], spotLightCoord.xy );
			directLight.color = inSpotLightMap ? directLight.color * spotColor.rgb : directLight.color;
		#endif
		#undef SPOT_LIGHT_MAP_INDEX
		#if defined( USE_SHADOWMAP ) && ( UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS )
		spotLightShadow = spotLightShadows[ i ];
		directLight.color *= ( directLight.visible && receiveShadow ) ? getShadow( spotShadowMap[ i ], spotLightShadow.shadowMapSize, spotLightShadow.shadowBias, spotLightShadow.shadowRadius, vSpotLightCoord[ i ] ) : 1.0;
		#endif
		RE_Direct( directLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
	}
	#pragma unroll_loop_end
#endif
#if ( NUM_DIR_LIGHTS > 0 ) && defined( RE_Direct )
	DirectionalLight directionalLight;
	#if defined( USE_SHADOWMAP ) && NUM_DIR_LIGHT_SHADOWS > 0
	DirectionalLightShadow directionalLightShadow;
	#endif
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_DIR_LIGHTS; i ++ ) {
		directionalLight = directionalLights[ i ];
		getDirectionalLightInfo( directionalLight, directLight );
		#if defined( USE_SHADOWMAP ) && ( UNROLLED_LOOP_INDEX < NUM_DIR_LIGHT_SHADOWS )
		directionalLightShadow = directionalLightShadows[ i ];
		directLight.color *= ( directLight.visible && receiveShadow ) ? getShadow( directionalShadowMap[ i ], directionalLightShadow.shadowMapSize, directionalLightShadow.shadowBias, directionalLightShadow.shadowRadius, vDirectionalShadowCoord[ i ] ) : 1.0;
		#endif
		RE_Direct( directLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
	}
	#pragma unroll_loop_end
#endif
#if ( NUM_RECT_AREA_LIGHTS > 0 ) && defined( RE_Direct_RectArea )
	RectAreaLight rectAreaLight;
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_RECT_AREA_LIGHTS; i ++ ) {
		rectAreaLight = rectAreaLights[ i ];
		RE_Direct_RectArea( rectAreaLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
	}
	#pragma unroll_loop_end
#endif
#if defined( RE_IndirectDiffuse )
	vec3 iblIrradiance = vec3( 0.0 );
	vec3 irradiance = getAmbientLightIrradiance( ambientLightColor );
	#if defined( USE_LIGHT_PROBES )
		irradiance += getLightProbeIrradiance( lightProbe, geometryNormal );
	#endif
	#if ( NUM_HEMI_LIGHTS > 0 )
		#pragma unroll_loop_start
		for ( int i = 0; i < NUM_HEMI_LIGHTS; i ++ ) {
			irradiance += getHemisphereLightIrradiance( hemisphereLights[ i ], geometryNormal );
		}
		#pragma unroll_loop_end
	#endif
#endif
#if defined( RE_IndirectSpecular )
	vec3 radiance = vec3( 0.0 );
	vec3 clearcoatRadiance = vec3( 0.0 );
#endif`,up=`#if defined( RE_IndirectDiffuse )
	#ifdef USE_LIGHTMAP
		vec4 lightMapTexel = texture2D( lightMap, vLightMapUv );
		vec3 lightMapIrradiance = lightMapTexel.rgb * lightMapIntensity;
		irradiance += lightMapIrradiance;
	#endif
	#if defined( USE_ENVMAP ) && defined( STANDARD ) && defined( ENVMAP_TYPE_CUBE_UV )
		iblIrradiance += getIBLIrradiance( geometryNormal );
	#endif
#endif
#if defined( USE_ENVMAP ) && defined( RE_IndirectSpecular )
	#ifdef USE_ANISOTROPY
		radiance += getIBLAnisotropyRadiance( geometryViewDir, geometryNormal, material.roughness, material.anisotropyB, material.anisotropy );
	#else
		radiance += getIBLRadiance( geometryViewDir, geometryNormal, material.roughness );
	#endif
	#ifdef USE_CLEARCOAT
		clearcoatRadiance += getIBLRadiance( geometryViewDir, geometryClearcoatNormal, material.clearcoatRoughness );
	#endif
#endif`,dp=`#if defined( RE_IndirectDiffuse )
	RE_IndirectDiffuse( irradiance, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
#endif
#if defined( RE_IndirectSpecular )
	RE_IndirectSpecular( radiance, iblIrradiance, clearcoatRadiance, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
#endif`,fp=`#if defined( USE_LOGDEPTHBUF ) && defined( USE_LOGDEPTHBUF_EXT )
	gl_FragDepthEXT = vIsPerspective == 0.0 ? gl_FragCoord.z : log2( vFragDepth ) * logDepthBufFC * 0.5;
#endif`,pp=`#if defined( USE_LOGDEPTHBUF ) && defined( USE_LOGDEPTHBUF_EXT )
	uniform float logDepthBufFC;
	varying float vFragDepth;
	varying float vIsPerspective;
#endif`,mp=`#ifdef USE_LOGDEPTHBUF
	#ifdef USE_LOGDEPTHBUF_EXT
		varying float vFragDepth;
		varying float vIsPerspective;
	#else
		uniform float logDepthBufFC;
	#endif
#endif`,gp=`#ifdef USE_LOGDEPTHBUF
	#ifdef USE_LOGDEPTHBUF_EXT
		vFragDepth = 1.0 + gl_Position.w;
		vIsPerspective = float( isPerspectiveMatrix( projectionMatrix ) );
	#else
		if ( isPerspectiveMatrix( projectionMatrix ) ) {
			gl_Position.z = log2( max( EPSILON, gl_Position.w + 1.0 ) ) * logDepthBufFC - 1.0;
			gl_Position.z *= gl_Position.w;
		}
	#endif
#endif`,xp=`#ifdef USE_MAP
	vec4 sampledDiffuseColor = texture2D( map, vMapUv );
	#ifdef DECODE_VIDEO_TEXTURE
		sampledDiffuseColor = vec4( mix( pow( sampledDiffuseColor.rgb * 0.9478672986 + vec3( 0.0521327014 ), vec3( 2.4 ) ), sampledDiffuseColor.rgb * 0.0773993808, vec3( lessThanEqual( sampledDiffuseColor.rgb, vec3( 0.04045 ) ) ) ), sampledDiffuseColor.w );
	
	#endif
	diffuseColor *= sampledDiffuseColor;
#endif`,_p=`#ifdef USE_MAP
	uniform sampler2D map;
#endif`,vp=`#if defined( USE_MAP ) || defined( USE_ALPHAMAP )
	#if defined( USE_POINTS_UV )
		vec2 uv = vUv;
	#else
		vec2 uv = ( uvTransform * vec3( gl_PointCoord.x, 1.0 - gl_PointCoord.y, 1 ) ).xy;
	#endif
#endif
#ifdef USE_MAP
	diffuseColor *= texture2D( map, uv );
#endif
#ifdef USE_ALPHAMAP
	diffuseColor.a *= texture2D( alphaMap, uv ).g;
#endif`,yp=`#if defined( USE_POINTS_UV )
	varying vec2 vUv;
#else
	#if defined( USE_MAP ) || defined( USE_ALPHAMAP )
		uniform mat3 uvTransform;
	#endif
#endif
#ifdef USE_MAP
	uniform sampler2D map;
#endif
#ifdef USE_ALPHAMAP
	uniform sampler2D alphaMap;
#endif`,bp=`float metalnessFactor = metalness;
#ifdef USE_METALNESSMAP
	vec4 texelMetalness = texture2D( metalnessMap, vMetalnessMapUv );
	metalnessFactor *= texelMetalness.b;
#endif`,Mp=`#ifdef USE_METALNESSMAP
	uniform sampler2D metalnessMap;
#endif`,Sp=`#if defined( USE_MORPHCOLORS ) && defined( MORPHTARGETS_TEXTURE )
	vColor *= morphTargetBaseInfluence;
	for ( int i = 0; i < MORPHTARGETS_COUNT; i ++ ) {
		#if defined( USE_COLOR_ALPHA )
			if ( morphTargetInfluences[ i ] != 0.0 ) vColor += getMorph( gl_VertexID, i, 2 ) * morphTargetInfluences[ i ];
		#elif defined( USE_COLOR )
			if ( morphTargetInfluences[ i ] != 0.0 ) vColor += getMorph( gl_VertexID, i, 2 ).rgb * morphTargetInfluences[ i ];
		#endif
	}
#endif`,wp=`#ifdef USE_MORPHNORMALS
	objectNormal *= morphTargetBaseInfluence;
	#ifdef MORPHTARGETS_TEXTURE
		for ( int i = 0; i < MORPHTARGETS_COUNT; i ++ ) {
			if ( morphTargetInfluences[ i ] != 0.0 ) objectNormal += getMorph( gl_VertexID, i, 1 ).xyz * morphTargetInfluences[ i ];
		}
	#else
		objectNormal += morphNormal0 * morphTargetInfluences[ 0 ];
		objectNormal += morphNormal1 * morphTargetInfluences[ 1 ];
		objectNormal += morphNormal2 * morphTargetInfluences[ 2 ];
		objectNormal += morphNormal3 * morphTargetInfluences[ 3 ];
	#endif
#endif`,Ep=`#ifdef USE_MORPHTARGETS
	uniform float morphTargetBaseInfluence;
	#ifdef MORPHTARGETS_TEXTURE
		uniform float morphTargetInfluences[ MORPHTARGETS_COUNT ];
		uniform sampler2DArray morphTargetsTexture;
		uniform ivec2 morphTargetsTextureSize;
		vec4 getMorph( const in int vertexIndex, const in int morphTargetIndex, const in int offset ) {
			int texelIndex = vertexIndex * MORPHTARGETS_TEXTURE_STRIDE + offset;
			int y = texelIndex / morphTargetsTextureSize.x;
			int x = texelIndex - y * morphTargetsTextureSize.x;
			ivec3 morphUV = ivec3( x, y, morphTargetIndex );
			return texelFetch( morphTargetsTexture, morphUV, 0 );
		}
	#else
		#ifndef USE_MORPHNORMALS
			uniform float morphTargetInfluences[ 8 ];
		#else
			uniform float morphTargetInfluences[ 4 ];
		#endif
	#endif
#endif`,Tp=`#ifdef USE_MORPHTARGETS
	transformed *= morphTargetBaseInfluence;
	#ifdef MORPHTARGETS_TEXTURE
		for ( int i = 0; i < MORPHTARGETS_COUNT; i ++ ) {
			if ( morphTargetInfluences[ i ] != 0.0 ) transformed += getMorph( gl_VertexID, i, 0 ).xyz * morphTargetInfluences[ i ];
		}
	#else
		transformed += morphTarget0 * morphTargetInfluences[ 0 ];
		transformed += morphTarget1 * morphTargetInfluences[ 1 ];
		transformed += morphTarget2 * morphTargetInfluences[ 2 ];
		transformed += morphTarget3 * morphTargetInfluences[ 3 ];
		#ifndef USE_MORPHNORMALS
			transformed += morphTarget4 * morphTargetInfluences[ 4 ];
			transformed += morphTarget5 * morphTargetInfluences[ 5 ];
			transformed += morphTarget6 * morphTargetInfluences[ 6 ];
			transformed += morphTarget7 * morphTargetInfluences[ 7 ];
		#endif
	#endif
#endif`,Ap=`float faceDirection = gl_FrontFacing ? 1.0 : - 1.0;
#ifdef FLAT_SHADED
	vec3 fdx = dFdx( vViewPosition );
	vec3 fdy = dFdy( vViewPosition );
	vec3 normal = normalize( cross( fdx, fdy ) );
#else
	vec3 normal = normalize( vNormal );
	#ifdef DOUBLE_SIDED
		normal *= faceDirection;
	#endif
#endif
#if defined( USE_NORMALMAP_TANGENTSPACE ) || defined( USE_CLEARCOAT_NORMALMAP ) || defined( USE_ANISOTROPY )
	#ifdef USE_TANGENT
		mat3 tbn = mat3( normalize( vTangent ), normalize( vBitangent ), normal );
	#else
		mat3 tbn = getTangentFrame( - vViewPosition, normal,
		#if defined( USE_NORMALMAP )
			vNormalMapUv
		#elif defined( USE_CLEARCOAT_NORMALMAP )
			vClearcoatNormalMapUv
		#else
			vUv
		#endif
		);
	#endif
	#if defined( DOUBLE_SIDED ) && ! defined( FLAT_SHADED )
		tbn[0] *= faceDirection;
		tbn[1] *= faceDirection;
	#endif
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	#ifdef USE_TANGENT
		mat3 tbn2 = mat3( normalize( vTangent ), normalize( vBitangent ), normal );
	#else
		mat3 tbn2 = getTangentFrame( - vViewPosition, normal, vClearcoatNormalMapUv );
	#endif
	#if defined( DOUBLE_SIDED ) && ! defined( FLAT_SHADED )
		tbn2[0] *= faceDirection;
		tbn2[1] *= faceDirection;
	#endif
#endif
vec3 nonPerturbedNormal = normal;`,Cp=`#ifdef USE_NORMALMAP_OBJECTSPACE
	normal = texture2D( normalMap, vNormalMapUv ).xyz * 2.0 - 1.0;
	#ifdef FLIP_SIDED
		normal = - normal;
	#endif
	#ifdef DOUBLE_SIDED
		normal = normal * faceDirection;
	#endif
	normal = normalize( normalMatrix * normal );
#elif defined( USE_NORMALMAP_TANGENTSPACE )
	vec3 mapN = texture2D( normalMap, vNormalMapUv ).xyz * 2.0 - 1.0;
	mapN.xy *= normalScale;
	normal = normalize( tbn * mapN );
#elif defined( USE_BUMPMAP )
	normal = perturbNormalArb( - vViewPosition, normal, dHdxy_fwd(), faceDirection );
#endif`,Rp=`#ifndef FLAT_SHADED
	varying vec3 vNormal;
	#ifdef USE_TANGENT
		varying vec3 vTangent;
		varying vec3 vBitangent;
	#endif
#endif`,Pp=`#ifndef FLAT_SHADED
	varying vec3 vNormal;
	#ifdef USE_TANGENT
		varying vec3 vTangent;
		varying vec3 vBitangent;
	#endif
#endif`,Lp=`#ifndef FLAT_SHADED
	vNormal = normalize( transformedNormal );
	#ifdef USE_TANGENT
		vTangent = normalize( transformedTangent );
		vBitangent = normalize( cross( vNormal, vTangent ) * tangent.w );
	#endif
#endif`,Ip=`#ifdef USE_NORMALMAP
	uniform sampler2D normalMap;
	uniform vec2 normalScale;
#endif
#ifdef USE_NORMALMAP_OBJECTSPACE
	uniform mat3 normalMatrix;
#endif
#if ! defined ( USE_TANGENT ) && ( defined ( USE_NORMALMAP_TANGENTSPACE ) || defined ( USE_CLEARCOAT_NORMALMAP ) || defined( USE_ANISOTROPY ) )
	mat3 getTangentFrame( vec3 eye_pos, vec3 surf_norm, vec2 uv ) {
		vec3 q0 = dFdx( eye_pos.xyz );
		vec3 q1 = dFdy( eye_pos.xyz );
		vec2 st0 = dFdx( uv.st );
		vec2 st1 = dFdy( uv.st );
		vec3 N = surf_norm;
		vec3 q1perp = cross( q1, N );
		vec3 q0perp = cross( N, q0 );
		vec3 T = q1perp * st0.x + q0perp * st1.x;
		vec3 B = q1perp * st0.y + q0perp * st1.y;
		float det = max( dot( T, T ), dot( B, B ) );
		float scale = ( det == 0.0 ) ? 0.0 : inversesqrt( det );
		return mat3( T * scale, B * scale, N );
	}
#endif`,Dp=`#ifdef USE_CLEARCOAT
	vec3 clearcoatNormal = nonPerturbedNormal;
#endif`,Up=`#ifdef USE_CLEARCOAT_NORMALMAP
	vec3 clearcoatMapN = texture2D( clearcoatNormalMap, vClearcoatNormalMapUv ).xyz * 2.0 - 1.0;
	clearcoatMapN.xy *= clearcoatNormalScale;
	clearcoatNormal = normalize( tbn2 * clearcoatMapN );
#endif`,Np=`#ifdef USE_CLEARCOATMAP
	uniform sampler2D clearcoatMap;
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	uniform sampler2D clearcoatNormalMap;
	uniform vec2 clearcoatNormalScale;
#endif
#ifdef USE_CLEARCOAT_ROUGHNESSMAP
	uniform sampler2D clearcoatRoughnessMap;
#endif`,Op=`#ifdef USE_IRIDESCENCEMAP
	uniform sampler2D iridescenceMap;
#endif
#ifdef USE_IRIDESCENCE_THICKNESSMAP
	uniform sampler2D iridescenceThicknessMap;
#endif`,Fp=`#ifdef OPAQUE
diffuseColor.a = 1.0;
#endif
#ifdef USE_TRANSMISSION
diffuseColor.a *= material.transmissionAlpha;
#endif
gl_FragColor = vec4( outgoingLight, diffuseColor.a );`,Bp=`vec3 packNormalToRGB( const in vec3 normal ) {
	return normalize( normal ) * 0.5 + 0.5;
}
vec3 unpackRGBToNormal( const in vec3 rgb ) {
	return 2.0 * rgb.xyz - 1.0;
}
const float PackUpscale = 256. / 255.;const float UnpackDownscale = 255. / 256.;
const vec3 PackFactors = vec3( 256. * 256. * 256., 256. * 256., 256. );
const vec4 UnpackFactors = UnpackDownscale / vec4( PackFactors, 1. );
const float ShiftRight8 = 1. / 256.;
vec4 packDepthToRGBA( const in float v ) {
	vec4 r = vec4( fract( v * PackFactors ), v );
	r.yzw -= r.xyz * ShiftRight8;	return r * PackUpscale;
}
float unpackRGBAToDepth( const in vec4 v ) {
	return dot( v, UnpackFactors );
}
vec2 packDepthToRG( in highp float v ) {
	return packDepthToRGBA( v ).yx;
}
float unpackRGToDepth( const in highp vec2 v ) {
	return unpackRGBAToDepth( vec4( v.xy, 0.0, 0.0 ) );
}
vec4 pack2HalfToRGBA( vec2 v ) {
	vec4 r = vec4( v.x, fract( v.x * 255.0 ), v.y, fract( v.y * 255.0 ) );
	return vec4( r.x - r.y / 255.0, r.y, r.z - r.w / 255.0, r.w );
}
vec2 unpackRGBATo2Half( vec4 v ) {
	return vec2( v.x + ( v.y / 255.0 ), v.z + ( v.w / 255.0 ) );
}
float viewZToOrthographicDepth( const in float viewZ, const in float near, const in float far ) {
	return ( viewZ + near ) / ( near - far );
}
float orthographicDepthToViewZ( const in float depth, const in float near, const in float far ) {
	return depth * ( near - far ) - near;
}
float viewZToPerspectiveDepth( const in float viewZ, const in float near, const in float far ) {
	return ( ( near + viewZ ) * far ) / ( ( far - near ) * viewZ );
}
float perspectiveDepthToViewZ( const in float depth, const in float near, const in float far ) {
	return ( near * far ) / ( ( far - near ) * depth - far );
}`,zp=`#ifdef PREMULTIPLIED_ALPHA
	gl_FragColor.rgb *= gl_FragColor.a;
#endif`,kp=`vec4 mvPosition = vec4( transformed, 1.0 );
#ifdef USE_BATCHING
	mvPosition = batchingMatrix * mvPosition;
#endif
#ifdef USE_INSTANCING
	mvPosition = instanceMatrix * mvPosition;
#endif
mvPosition = modelViewMatrix * mvPosition;
gl_Position = projectionMatrix * mvPosition;`,Hp=`#ifdef DITHERING
	gl_FragColor.rgb = dithering( gl_FragColor.rgb );
#endif`,Vp=`#ifdef DITHERING
	vec3 dithering( vec3 color ) {
		float grid_position = rand( gl_FragCoord.xy );
		vec3 dither_shift_RGB = vec3( 0.25 / 255.0, -0.25 / 255.0, 0.25 / 255.0 );
		dither_shift_RGB = mix( 2.0 * dither_shift_RGB, -2.0 * dither_shift_RGB, grid_position );
		return color + dither_shift_RGB;
	}
#endif`,Gp=`float roughnessFactor = roughness;
#ifdef USE_ROUGHNESSMAP
	vec4 texelRoughness = texture2D( roughnessMap, vRoughnessMapUv );
	roughnessFactor *= texelRoughness.g;
#endif`,Wp=`#ifdef USE_ROUGHNESSMAP
	uniform sampler2D roughnessMap;
#endif`,Xp=`#if NUM_SPOT_LIGHT_COORDS > 0
	varying vec4 vSpotLightCoord[ NUM_SPOT_LIGHT_COORDS ];
#endif
#if NUM_SPOT_LIGHT_MAPS > 0
	uniform sampler2D spotLightMap[ NUM_SPOT_LIGHT_MAPS ];
#endif
#ifdef USE_SHADOWMAP
	#if NUM_DIR_LIGHT_SHADOWS > 0
		uniform sampler2D directionalShadowMap[ NUM_DIR_LIGHT_SHADOWS ];
		varying vec4 vDirectionalShadowCoord[ NUM_DIR_LIGHT_SHADOWS ];
		struct DirectionalLightShadow {
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};
		uniform DirectionalLightShadow directionalLightShadows[ NUM_DIR_LIGHT_SHADOWS ];
	#endif
	#if NUM_SPOT_LIGHT_SHADOWS > 0
		uniform sampler2D spotShadowMap[ NUM_SPOT_LIGHT_SHADOWS ];
		struct SpotLightShadow {
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};
		uniform SpotLightShadow spotLightShadows[ NUM_SPOT_LIGHT_SHADOWS ];
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0
		uniform sampler2D pointShadowMap[ NUM_POINT_LIGHT_SHADOWS ];
		varying vec4 vPointShadowCoord[ NUM_POINT_LIGHT_SHADOWS ];
		struct PointLightShadow {
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
			float shadowCameraNear;
			float shadowCameraFar;
		};
		uniform PointLightShadow pointLightShadows[ NUM_POINT_LIGHT_SHADOWS ];
	#endif
	float texture2DCompare( sampler2D depths, vec2 uv, float compare ) {
		return step( compare, unpackRGBAToDepth( texture2D( depths, uv ) ) );
	}
	vec2 texture2DDistribution( sampler2D shadow, vec2 uv ) {
		return unpackRGBATo2Half( texture2D( shadow, uv ) );
	}
	float VSMShadow (sampler2D shadow, vec2 uv, float compare ){
		float occlusion = 1.0;
		vec2 distribution = texture2DDistribution( shadow, uv );
		float hard_shadow = step( compare , distribution.x );
		if (hard_shadow != 1.0 ) {
			float distance = compare - distribution.x ;
			float variance = max( 0.00000, distribution.y * distribution.y );
			float softness_probability = variance / (variance + distance * distance );			softness_probability = clamp( ( softness_probability - 0.3 ) / ( 0.95 - 0.3 ), 0.0, 1.0 );			occlusion = clamp( max( hard_shadow, softness_probability ), 0.0, 1.0 );
		}
		return occlusion;
	}
	float getShadow( sampler2D shadowMap, vec2 shadowMapSize, float shadowBias, float shadowRadius, vec4 shadowCoord ) {
		float shadow = 1.0;
		shadowCoord.xyz /= shadowCoord.w;
		shadowCoord.z += shadowBias;
		bool inFrustum = shadowCoord.x >= 0.0 && shadowCoord.x <= 1.0 && shadowCoord.y >= 0.0 && shadowCoord.y <= 1.0;
		bool frustumTest = inFrustum && shadowCoord.z <= 1.0;
		if ( frustumTest ) {
		#if defined( SHADOWMAP_TYPE_PCF )
			vec2 texelSize = vec2( 1.0 ) / shadowMapSize;
			float dx0 = - texelSize.x * shadowRadius;
			float dy0 = - texelSize.y * shadowRadius;
			float dx1 = + texelSize.x * shadowRadius;
			float dy1 = + texelSize.y * shadowRadius;
			float dx2 = dx0 / 2.0;
			float dy2 = dy0 / 2.0;
			float dx3 = dx1 / 2.0;
			float dy3 = dy1 / 2.0;
			shadow = (
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx0, dy0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( 0.0, dy0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx1, dy0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx2, dy2 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( 0.0, dy2 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx3, dy2 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx0, 0.0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx2, 0.0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy, shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx3, 0.0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx1, 0.0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx2, dy3 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( 0.0, dy3 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx3, dy3 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx0, dy1 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( 0.0, dy1 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx1, dy1 ), shadowCoord.z )
			) * ( 1.0 / 17.0 );
		#elif defined( SHADOWMAP_TYPE_PCF_SOFT )
			vec2 texelSize = vec2( 1.0 ) / shadowMapSize;
			float dx = texelSize.x;
			float dy = texelSize.y;
			vec2 uv = shadowCoord.xy;
			vec2 f = fract( uv * shadowMapSize + 0.5 );
			uv -= f * texelSize;
			shadow = (
				texture2DCompare( shadowMap, uv, shadowCoord.z ) +
				texture2DCompare( shadowMap, uv + vec2( dx, 0.0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, uv + vec2( 0.0, dy ), shadowCoord.z ) +
				texture2DCompare( shadowMap, uv + texelSize, shadowCoord.z ) +
				mix( texture2DCompare( shadowMap, uv + vec2( -dx, 0.0 ), shadowCoord.z ),
					 texture2DCompare( shadowMap, uv + vec2( 2.0 * dx, 0.0 ), shadowCoord.z ),
					 f.x ) +
				mix( texture2DCompare( shadowMap, uv + vec2( -dx, dy ), shadowCoord.z ),
					 texture2DCompare( shadowMap, uv + vec2( 2.0 * dx, dy ), shadowCoord.z ),
					 f.x ) +
				mix( texture2DCompare( shadowMap, uv + vec2( 0.0, -dy ), shadowCoord.z ),
					 texture2DCompare( shadowMap, uv + vec2( 0.0, 2.0 * dy ), shadowCoord.z ),
					 f.y ) +
				mix( texture2DCompare( shadowMap, uv + vec2( dx, -dy ), shadowCoord.z ),
					 texture2DCompare( shadowMap, uv + vec2( dx, 2.0 * dy ), shadowCoord.z ),
					 f.y ) +
				mix( mix( texture2DCompare( shadowMap, uv + vec2( -dx, -dy ), shadowCoord.z ),
						  texture2DCompare( shadowMap, uv + vec2( 2.0 * dx, -dy ), shadowCoord.z ),
						  f.x ),
					 mix( texture2DCompare( shadowMap, uv + vec2( -dx, 2.0 * dy ), shadowCoord.z ),
						  texture2DCompare( shadowMap, uv + vec2( 2.0 * dx, 2.0 * dy ), shadowCoord.z ),
						  f.x ),
					 f.y )
			) * ( 1.0 / 9.0 );
		#elif defined( SHADOWMAP_TYPE_VSM )
			shadow = VSMShadow( shadowMap, shadowCoord.xy, shadowCoord.z );
		#else
			shadow = texture2DCompare( shadowMap, shadowCoord.xy, shadowCoord.z );
		#endif
		}
		return shadow;
	}
	vec2 cubeToUV( vec3 v, float texelSizeY ) {
		vec3 absV = abs( v );
		float scaleToCube = 1.0 / max( absV.x, max( absV.y, absV.z ) );
		absV *= scaleToCube;
		v *= scaleToCube * ( 1.0 - 2.0 * texelSizeY );
		vec2 planar = v.xy;
		float almostATexel = 1.5 * texelSizeY;
		float almostOne = 1.0 - almostATexel;
		if ( absV.z >= almostOne ) {
			if ( v.z > 0.0 )
				planar.x = 4.0 - v.x;
		} else if ( absV.x >= almostOne ) {
			float signX = sign( v.x );
			planar.x = v.z * signX + 2.0 * signX;
		} else if ( absV.y >= almostOne ) {
			float signY = sign( v.y );
			planar.x = v.x + 2.0 * signY + 2.0;
			planar.y = v.z * signY - 2.0;
		}
		return vec2( 0.125, 0.25 ) * planar + vec2( 0.375, 0.75 );
	}
	float getPointShadow( sampler2D shadowMap, vec2 shadowMapSize, float shadowBias, float shadowRadius, vec4 shadowCoord, float shadowCameraNear, float shadowCameraFar ) {
		vec2 texelSize = vec2( 1.0 ) / ( shadowMapSize * vec2( 4.0, 2.0 ) );
		vec3 lightToPosition = shadowCoord.xyz;
		float dp = ( length( lightToPosition ) - shadowCameraNear ) / ( shadowCameraFar - shadowCameraNear );		dp += shadowBias;
		vec3 bd3D = normalize( lightToPosition );
		#if defined( SHADOWMAP_TYPE_PCF ) || defined( SHADOWMAP_TYPE_PCF_SOFT ) || defined( SHADOWMAP_TYPE_VSM )
			vec2 offset = vec2( - 1, 1 ) * shadowRadius * texelSize.y;
			return (
				texture2DCompare( shadowMap, cubeToUV( bd3D + offset.xyy, texelSize.y ), dp ) +
				texture2DCompare( shadowMap, cubeToUV( bd3D + offset.yyy, texelSize.y ), dp ) +
				texture2DCompare( shadowMap, cubeToUV( bd3D + offset.xyx, texelSize.y ), dp ) +
				texture2DCompare( shadowMap, cubeToUV( bd3D + offset.yyx, texelSize.y ), dp ) +
				texture2DCompare( shadowMap, cubeToUV( bd3D, texelSize.y ), dp ) +
				texture2DCompare( shadowMap, cubeToUV( bd3D + offset.xxy, texelSize.y ), dp ) +
				texture2DCompare( shadowMap, cubeToUV( bd3D + offset.yxy, texelSize.y ), dp ) +
				texture2DCompare( shadowMap, cubeToUV( bd3D + offset.xxx, texelSize.y ), dp ) +
				texture2DCompare( shadowMap, cubeToUV( bd3D + offset.yxx, texelSize.y ), dp )
			) * ( 1.0 / 9.0 );
		#else
			return texture2DCompare( shadowMap, cubeToUV( bd3D, texelSize.y ), dp );
		#endif
	}
#endif`,Yp=`#if NUM_SPOT_LIGHT_COORDS > 0
	uniform mat4 spotLightMatrix[ NUM_SPOT_LIGHT_COORDS ];
	varying vec4 vSpotLightCoord[ NUM_SPOT_LIGHT_COORDS ];
#endif
#ifdef USE_SHADOWMAP
	#if NUM_DIR_LIGHT_SHADOWS > 0
		uniform mat4 directionalShadowMatrix[ NUM_DIR_LIGHT_SHADOWS ];
		varying vec4 vDirectionalShadowCoord[ NUM_DIR_LIGHT_SHADOWS ];
		struct DirectionalLightShadow {
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};
		uniform DirectionalLightShadow directionalLightShadows[ NUM_DIR_LIGHT_SHADOWS ];
	#endif
	#if NUM_SPOT_LIGHT_SHADOWS > 0
		struct SpotLightShadow {
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};
		uniform SpotLightShadow spotLightShadows[ NUM_SPOT_LIGHT_SHADOWS ];
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0
		uniform mat4 pointShadowMatrix[ NUM_POINT_LIGHT_SHADOWS ];
		varying vec4 vPointShadowCoord[ NUM_POINT_LIGHT_SHADOWS ];
		struct PointLightShadow {
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
			float shadowCameraNear;
			float shadowCameraFar;
		};
		uniform PointLightShadow pointLightShadows[ NUM_POINT_LIGHT_SHADOWS ];
	#endif
#endif`,qp=`#if ( defined( USE_SHADOWMAP ) && ( NUM_DIR_LIGHT_SHADOWS > 0 || NUM_POINT_LIGHT_SHADOWS > 0 ) ) || ( NUM_SPOT_LIGHT_COORDS > 0 )
	vec3 shadowWorldNormal = inverseTransformDirection( transformedNormal, viewMatrix );
	vec4 shadowWorldPosition;
#endif
#if defined( USE_SHADOWMAP )
	#if NUM_DIR_LIGHT_SHADOWS > 0
		#pragma unroll_loop_start
		for ( int i = 0; i < NUM_DIR_LIGHT_SHADOWS; i ++ ) {
			shadowWorldPosition = worldPosition + vec4( shadowWorldNormal * directionalLightShadows[ i ].shadowNormalBias, 0 );
			vDirectionalShadowCoord[ i ] = directionalShadowMatrix[ i ] * shadowWorldPosition;
		}
		#pragma unroll_loop_end
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0
		#pragma unroll_loop_start
		for ( int i = 0; i < NUM_POINT_LIGHT_SHADOWS; i ++ ) {
			shadowWorldPosition = worldPosition + vec4( shadowWorldNormal * pointLightShadows[ i ].shadowNormalBias, 0 );
			vPointShadowCoord[ i ] = pointShadowMatrix[ i ] * shadowWorldPosition;
		}
		#pragma unroll_loop_end
	#endif
#endif
#if NUM_SPOT_LIGHT_COORDS > 0
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_SPOT_LIGHT_COORDS; i ++ ) {
		shadowWorldPosition = worldPosition;
		#if ( defined( USE_SHADOWMAP ) && UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS )
			shadowWorldPosition.xyz += shadowWorldNormal * spotLightShadows[ i ].shadowNormalBias;
		#endif
		vSpotLightCoord[ i ] = spotLightMatrix[ i ] * shadowWorldPosition;
	}
	#pragma unroll_loop_end
#endif`,Zp=`float getShadowMask() {
	float shadow = 1.0;
	#ifdef USE_SHADOWMAP
	#if NUM_DIR_LIGHT_SHADOWS > 0
	DirectionalLightShadow directionalLight;
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_DIR_LIGHT_SHADOWS; i ++ ) {
		directionalLight = directionalLightShadows[ i ];
		shadow *= receiveShadow ? getShadow( directionalShadowMap[ i ], directionalLight.shadowMapSize, directionalLight.shadowBias, directionalLight.shadowRadius, vDirectionalShadowCoord[ i ] ) : 1.0;
	}
	#pragma unroll_loop_end
	#endif
	#if NUM_SPOT_LIGHT_SHADOWS > 0
	SpotLightShadow spotLight;
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_SPOT_LIGHT_SHADOWS; i ++ ) {
		spotLight = spotLightShadows[ i ];
		shadow *= receiveShadow ? getShadow( spotShadowMap[ i ], spotLight.shadowMapSize, spotLight.shadowBias, spotLight.shadowRadius, vSpotLightCoord[ i ] ) : 1.0;
	}
	#pragma unroll_loop_end
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0
	PointLightShadow pointLight;
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_POINT_LIGHT_SHADOWS; i ++ ) {
		pointLight = pointLightShadows[ i ];
		shadow *= receiveShadow ? getPointShadow( pointShadowMap[ i ], pointLight.shadowMapSize, pointLight.shadowBias, pointLight.shadowRadius, vPointShadowCoord[ i ], pointLight.shadowCameraNear, pointLight.shadowCameraFar ) : 1.0;
	}
	#pragma unroll_loop_end
	#endif
	#endif
	return shadow;
}`,Jp=`#ifdef USE_SKINNING
	mat4 boneMatX = getBoneMatrix( skinIndex.x );
	mat4 boneMatY = getBoneMatrix( skinIndex.y );
	mat4 boneMatZ = getBoneMatrix( skinIndex.z );
	mat4 boneMatW = getBoneMatrix( skinIndex.w );
#endif`,jp=`#ifdef USE_SKINNING
	uniform mat4 bindMatrix;
	uniform mat4 bindMatrixInverse;
	uniform highp sampler2D boneTexture;
	mat4 getBoneMatrix( const in float i ) {
		int size = textureSize( boneTexture, 0 ).x;
		int j = int( i ) * 4;
		int x = j % size;
		int y = j / size;
		vec4 v1 = texelFetch( boneTexture, ivec2( x, y ), 0 );
		vec4 v2 = texelFetch( boneTexture, ivec2( x + 1, y ), 0 );
		vec4 v3 = texelFetch( boneTexture, ivec2( x + 2, y ), 0 );
		vec4 v4 = texelFetch( boneTexture, ivec2( x + 3, y ), 0 );
		return mat4( v1, v2, v3, v4 );
	}
#endif`,$p=`#ifdef USE_SKINNING
	vec4 skinVertex = bindMatrix * vec4( transformed, 1.0 );
	vec4 skinned = vec4( 0.0 );
	skinned += boneMatX * skinVertex * skinWeight.x;
	skinned += boneMatY * skinVertex * skinWeight.y;
	skinned += boneMatZ * skinVertex * skinWeight.z;
	skinned += boneMatW * skinVertex * skinWeight.w;
	transformed = ( bindMatrixInverse * skinned ).xyz;
#endif`,Kp=`#ifdef USE_SKINNING
	mat4 skinMatrix = mat4( 0.0 );
	skinMatrix += skinWeight.x * boneMatX;
	skinMatrix += skinWeight.y * boneMatY;
	skinMatrix += skinWeight.z * boneMatZ;
	skinMatrix += skinWeight.w * boneMatW;
	skinMatrix = bindMatrixInverse * skinMatrix * bindMatrix;
	objectNormal = vec4( skinMatrix * vec4( objectNormal, 0.0 ) ).xyz;
	#ifdef USE_TANGENT
		objectTangent = vec4( skinMatrix * vec4( objectTangent, 0.0 ) ).xyz;
	#endif
#endif`,Qp=`float specularStrength;
#ifdef USE_SPECULARMAP
	vec4 texelSpecular = texture2D( specularMap, vSpecularMapUv );
	specularStrength = texelSpecular.r;
#else
	specularStrength = 1.0;
#endif`,tm=`#ifdef USE_SPECULARMAP
	uniform sampler2D specularMap;
#endif`,em=`#if defined( TONE_MAPPING )
	gl_FragColor.rgb = toneMapping( gl_FragColor.rgb );
#endif`,nm=`#ifndef saturate
#define saturate( a ) clamp( a, 0.0, 1.0 )
#endif
uniform float toneMappingExposure;
vec3 LinearToneMapping( vec3 color ) {
	return saturate( toneMappingExposure * color );
}
vec3 ReinhardToneMapping( vec3 color ) {
	color *= toneMappingExposure;
	return saturate( color / ( vec3( 1.0 ) + color ) );
}
vec3 OptimizedCineonToneMapping( vec3 color ) {
	color *= toneMappingExposure;
	color = max( vec3( 0.0 ), color - 0.004 );
	return pow( ( color * ( 6.2 * color + 0.5 ) ) / ( color * ( 6.2 * color + 1.7 ) + 0.06 ), vec3( 2.2 ) );
}
vec3 RRTAndODTFit( vec3 v ) {
	vec3 a = v * ( v + 0.0245786 ) - 0.000090537;
	vec3 b = v * ( 0.983729 * v + 0.4329510 ) + 0.238081;
	return a / b;
}
vec3 ACESFilmicToneMapping( vec3 color ) {
	const mat3 ACESInputMat = mat3(
		vec3( 0.59719, 0.07600, 0.02840 ),		vec3( 0.35458, 0.90834, 0.13383 ),
		vec3( 0.04823, 0.01566, 0.83777 )
	);
	const mat3 ACESOutputMat = mat3(
		vec3(  1.60475, -0.10208, -0.00327 ),		vec3( -0.53108,  1.10813, -0.07276 ),
		vec3( -0.07367, -0.00605,  1.07602 )
	);
	color *= toneMappingExposure / 0.6;
	color = ACESInputMat * color;
	color = RRTAndODTFit( color );
	color = ACESOutputMat * color;
	return saturate( color );
}
const mat3 LINEAR_REC2020_TO_LINEAR_SRGB = mat3(
	vec3( 1.6605, - 0.1246, - 0.0182 ),
	vec3( - 0.5876, 1.1329, - 0.1006 ),
	vec3( - 0.0728, - 0.0083, 1.1187 )
);
const mat3 LINEAR_SRGB_TO_LINEAR_REC2020 = mat3(
	vec3( 0.6274, 0.0691, 0.0164 ),
	vec3( 0.3293, 0.9195, 0.0880 ),
	vec3( 0.0433, 0.0113, 0.8956 )
);
vec3 agxDefaultContrastApprox( vec3 x ) {
	vec3 x2 = x * x;
	vec3 x4 = x2 * x2;
	return + 15.5 * x4 * x2
		- 40.14 * x4 * x
		+ 31.96 * x4
		- 6.868 * x2 * x
		+ 0.4298 * x2
		+ 0.1191 * x
		- 0.00232;
}
vec3 AgXToneMapping( vec3 color ) {
	const mat3 AgXInsetMatrix = mat3(
		vec3( 0.856627153315983, 0.137318972929847, 0.11189821299995 ),
		vec3( 0.0951212405381588, 0.761241990602591, 0.0767994186031903 ),
		vec3( 0.0482516061458583, 0.101439036467562, 0.811302368396859 )
	);
	const mat3 AgXOutsetMatrix = mat3(
		vec3( 1.1271005818144368, - 0.1413297634984383, - 0.14132976349843826 ),
		vec3( - 0.11060664309660323, 1.157823702216272, - 0.11060664309660294 ),
		vec3( - 0.016493938717834573, - 0.016493938717834257, 1.2519364065950405 )
	);
	const float AgxMinEv = - 12.47393;	const float AgxMaxEv = 4.026069;
	color = LINEAR_SRGB_TO_LINEAR_REC2020 * color;
	color *= toneMappingExposure;
	color = AgXInsetMatrix * color;
	color = max( color, 1e-10 );	color = log2( color );
	color = ( color - AgxMinEv ) / ( AgxMaxEv - AgxMinEv );
	color = clamp( color, 0.0, 1.0 );
	color = agxDefaultContrastApprox( color );
	color = AgXOutsetMatrix * color;
	color = pow( max( vec3( 0.0 ), color ), vec3( 2.2 ) );
	color = LINEAR_REC2020_TO_LINEAR_SRGB * color;
	return color;
}
vec3 CustomToneMapping( vec3 color ) { return color; }`,im=`#ifdef USE_TRANSMISSION
	material.transmission = transmission;
	material.transmissionAlpha = 1.0;
	material.thickness = thickness;
	material.attenuationDistance = attenuationDistance;
	material.attenuationColor = attenuationColor;
	#ifdef USE_TRANSMISSIONMAP
		material.transmission *= texture2D( transmissionMap, vTransmissionMapUv ).r;
	#endif
	#ifdef USE_THICKNESSMAP
		material.thickness *= texture2D( thicknessMap, vThicknessMapUv ).g;
	#endif
	vec3 pos = vWorldPosition;
	vec3 v = normalize( cameraPosition - pos );
	vec3 n = inverseTransformDirection( normal, viewMatrix );
	vec4 transmitted = getIBLVolumeRefraction(
		n, v, material.roughness, material.diffuseColor, material.specularColor, material.specularF90,
		pos, modelMatrix, viewMatrix, projectionMatrix, material.ior, material.thickness,
		material.attenuationColor, material.attenuationDistance );
	material.transmissionAlpha = mix( material.transmissionAlpha, transmitted.a, material.transmission );
	totalDiffuse = mix( totalDiffuse, transmitted.rgb, material.transmission );
#endif`,sm=`#ifdef USE_TRANSMISSION
	uniform float transmission;
	uniform float thickness;
	uniform float attenuationDistance;
	uniform vec3 attenuationColor;
	#ifdef USE_TRANSMISSIONMAP
		uniform sampler2D transmissionMap;
	#endif
	#ifdef USE_THICKNESSMAP
		uniform sampler2D thicknessMap;
	#endif
	uniform vec2 transmissionSamplerSize;
	uniform sampler2D transmissionSamplerMap;
	uniform mat4 modelMatrix;
	uniform mat4 projectionMatrix;
	varying vec3 vWorldPosition;
	float w0( float a ) {
		return ( 1.0 / 6.0 ) * ( a * ( a * ( - a + 3.0 ) - 3.0 ) + 1.0 );
	}
	float w1( float a ) {
		return ( 1.0 / 6.0 ) * ( a *  a * ( 3.0 * a - 6.0 ) + 4.0 );
	}
	float w2( float a ){
		return ( 1.0 / 6.0 ) * ( a * ( a * ( - 3.0 * a + 3.0 ) + 3.0 ) + 1.0 );
	}
	float w3( float a ) {
		return ( 1.0 / 6.0 ) * ( a * a * a );
	}
	float g0( float a ) {
		return w0( a ) + w1( a );
	}
	float g1( float a ) {
		return w2( a ) + w3( a );
	}
	float h0( float a ) {
		return - 1.0 + w1( a ) / ( w0( a ) + w1( a ) );
	}
	float h1( float a ) {
		return 1.0 + w3( a ) / ( w2( a ) + w3( a ) );
	}
	vec4 bicubic( sampler2D tex, vec2 uv, vec4 texelSize, float lod ) {
		uv = uv * texelSize.zw + 0.5;
		vec2 iuv = floor( uv );
		vec2 fuv = fract( uv );
		float g0x = g0( fuv.x );
		float g1x = g1( fuv.x );
		float h0x = h0( fuv.x );
		float h1x = h1( fuv.x );
		float h0y = h0( fuv.y );
		float h1y = h1( fuv.y );
		vec2 p0 = ( vec2( iuv.x + h0x, iuv.y + h0y ) - 0.5 ) * texelSize.xy;
		vec2 p1 = ( vec2( iuv.x + h1x, iuv.y + h0y ) - 0.5 ) * texelSize.xy;
		vec2 p2 = ( vec2( iuv.x + h0x, iuv.y + h1y ) - 0.5 ) * texelSize.xy;
		vec2 p3 = ( vec2( iuv.x + h1x, iuv.y + h1y ) - 0.5 ) * texelSize.xy;
		return g0( fuv.y ) * ( g0x * textureLod( tex, p0, lod ) + g1x * textureLod( tex, p1, lod ) ) +
			g1( fuv.y ) * ( g0x * textureLod( tex, p2, lod ) + g1x * textureLod( tex, p3, lod ) );
	}
	vec4 textureBicubic( sampler2D sampler, vec2 uv, float lod ) {
		vec2 fLodSize = vec2( textureSize( sampler, int( lod ) ) );
		vec2 cLodSize = vec2( textureSize( sampler, int( lod + 1.0 ) ) );
		vec2 fLodSizeInv = 1.0 / fLodSize;
		vec2 cLodSizeInv = 1.0 / cLodSize;
		vec4 fSample = bicubic( sampler, uv, vec4( fLodSizeInv, fLodSize ), floor( lod ) );
		vec4 cSample = bicubic( sampler, uv, vec4( cLodSizeInv, cLodSize ), ceil( lod ) );
		return mix( fSample, cSample, fract( lod ) );
	}
	vec3 getVolumeTransmissionRay( const in vec3 n, const in vec3 v, const in float thickness, const in float ior, const in mat4 modelMatrix ) {
		vec3 refractionVector = refract( - v, normalize( n ), 1.0 / ior );
		vec3 modelScale;
		modelScale.x = length( vec3( modelMatrix[ 0 ].xyz ) );
		modelScale.y = length( vec3( modelMatrix[ 1 ].xyz ) );
		modelScale.z = length( vec3( modelMatrix[ 2 ].xyz ) );
		return normalize( refractionVector ) * thickness * modelScale;
	}
	float applyIorToRoughness( const in float roughness, const in float ior ) {
		return roughness * clamp( ior * 2.0 - 2.0, 0.0, 1.0 );
	}
	vec4 getTransmissionSample( const in vec2 fragCoord, const in float roughness, const in float ior ) {
		float lod = log2( transmissionSamplerSize.x ) * applyIorToRoughness( roughness, ior );
		return textureBicubic( transmissionSamplerMap, fragCoord.xy, lod );
	}
	vec3 volumeAttenuation( const in float transmissionDistance, const in vec3 attenuationColor, const in float attenuationDistance ) {
		if ( isinf( attenuationDistance ) ) {
			return vec3( 1.0 );
		} else {
			vec3 attenuationCoefficient = -log( attenuationColor ) / attenuationDistance;
			vec3 transmittance = exp( - attenuationCoefficient * transmissionDistance );			return transmittance;
		}
	}
	vec4 getIBLVolumeRefraction( const in vec3 n, const in vec3 v, const in float roughness, const in vec3 diffuseColor,
		const in vec3 specularColor, const in float specularF90, const in vec3 position, const in mat4 modelMatrix,
		const in mat4 viewMatrix, const in mat4 projMatrix, const in float ior, const in float thickness,
		const in vec3 attenuationColor, const in float attenuationDistance ) {
		vec3 transmissionRay = getVolumeTransmissionRay( n, v, thickness, ior, modelMatrix );
		vec3 refractedRayExit = position + transmissionRay;
		vec4 ndcPos = projMatrix * viewMatrix * vec4( refractedRayExit, 1.0 );
		vec2 refractionCoords = ndcPos.xy / ndcPos.w;
		refractionCoords += 1.0;
		refractionCoords /= 2.0;
		vec4 transmittedLight = getTransmissionSample( refractionCoords, roughness, ior );
		vec3 transmittance = diffuseColor * volumeAttenuation( length( transmissionRay ), attenuationColor, attenuationDistance );
		vec3 attenuatedColor = transmittance * transmittedLight.rgb;
		vec3 F = EnvironmentBRDF( n, v, specularColor, specularF90, roughness );
		float transmittanceFactor = ( transmittance.r + transmittance.g + transmittance.b ) / 3.0;
		return vec4( ( 1.0 - F ) * attenuatedColor, 1.0 - ( 1.0 - transmittedLight.a ) * transmittanceFactor );
	}
#endif`,rm=`#if defined( USE_UV ) || defined( USE_ANISOTROPY )
	varying vec2 vUv;
#endif
#ifdef USE_MAP
	varying vec2 vMapUv;
#endif
#ifdef USE_ALPHAMAP
	varying vec2 vAlphaMapUv;
#endif
#ifdef USE_LIGHTMAP
	varying vec2 vLightMapUv;
#endif
#ifdef USE_AOMAP
	varying vec2 vAoMapUv;
#endif
#ifdef USE_BUMPMAP
	varying vec2 vBumpMapUv;
#endif
#ifdef USE_NORMALMAP
	varying vec2 vNormalMapUv;
#endif
#ifdef USE_EMISSIVEMAP
	varying vec2 vEmissiveMapUv;
#endif
#ifdef USE_METALNESSMAP
	varying vec2 vMetalnessMapUv;
#endif
#ifdef USE_ROUGHNESSMAP
	varying vec2 vRoughnessMapUv;
#endif
#ifdef USE_ANISOTROPYMAP
	varying vec2 vAnisotropyMapUv;
#endif
#ifdef USE_CLEARCOATMAP
	varying vec2 vClearcoatMapUv;
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	varying vec2 vClearcoatNormalMapUv;
#endif
#ifdef USE_CLEARCOAT_ROUGHNESSMAP
	varying vec2 vClearcoatRoughnessMapUv;
#endif
#ifdef USE_IRIDESCENCEMAP
	varying vec2 vIridescenceMapUv;
#endif
#ifdef USE_IRIDESCENCE_THICKNESSMAP
	varying vec2 vIridescenceThicknessMapUv;
#endif
#ifdef USE_SHEEN_COLORMAP
	varying vec2 vSheenColorMapUv;
#endif
#ifdef USE_SHEEN_ROUGHNESSMAP
	varying vec2 vSheenRoughnessMapUv;
#endif
#ifdef USE_SPECULARMAP
	varying vec2 vSpecularMapUv;
#endif
#ifdef USE_SPECULAR_COLORMAP
	varying vec2 vSpecularColorMapUv;
#endif
#ifdef USE_SPECULAR_INTENSITYMAP
	varying vec2 vSpecularIntensityMapUv;
#endif
#ifdef USE_TRANSMISSIONMAP
	uniform mat3 transmissionMapTransform;
	varying vec2 vTransmissionMapUv;
#endif
#ifdef USE_THICKNESSMAP
	uniform mat3 thicknessMapTransform;
	varying vec2 vThicknessMapUv;
#endif`,am=`#if defined( USE_UV ) || defined( USE_ANISOTROPY )
	varying vec2 vUv;
#endif
#ifdef USE_MAP
	uniform mat3 mapTransform;
	varying vec2 vMapUv;
#endif
#ifdef USE_ALPHAMAP
	uniform mat3 alphaMapTransform;
	varying vec2 vAlphaMapUv;
#endif
#ifdef USE_LIGHTMAP
	uniform mat3 lightMapTransform;
	varying vec2 vLightMapUv;
#endif
#ifdef USE_AOMAP
	uniform mat3 aoMapTransform;
	varying vec2 vAoMapUv;
#endif
#ifdef USE_BUMPMAP
	uniform mat3 bumpMapTransform;
	varying vec2 vBumpMapUv;
#endif
#ifdef USE_NORMALMAP
	uniform mat3 normalMapTransform;
	varying vec2 vNormalMapUv;
#endif
#ifdef USE_DISPLACEMENTMAP
	uniform mat3 displacementMapTransform;
	varying vec2 vDisplacementMapUv;
#endif
#ifdef USE_EMISSIVEMAP
	uniform mat3 emissiveMapTransform;
	varying vec2 vEmissiveMapUv;
#endif
#ifdef USE_METALNESSMAP
	uniform mat3 metalnessMapTransform;
	varying vec2 vMetalnessMapUv;
#endif
#ifdef USE_ROUGHNESSMAP
	uniform mat3 roughnessMapTransform;
	varying vec2 vRoughnessMapUv;
#endif
#ifdef USE_ANISOTROPYMAP
	uniform mat3 anisotropyMapTransform;
	varying vec2 vAnisotropyMapUv;
#endif
#ifdef USE_CLEARCOATMAP
	uniform mat3 clearcoatMapTransform;
	varying vec2 vClearcoatMapUv;
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	uniform mat3 clearcoatNormalMapTransform;
	varying vec2 vClearcoatNormalMapUv;
#endif
#ifdef USE_CLEARCOAT_ROUGHNESSMAP
	uniform mat3 clearcoatRoughnessMapTransform;
	varying vec2 vClearcoatRoughnessMapUv;
#endif
#ifdef USE_SHEEN_COLORMAP
	uniform mat3 sheenColorMapTransform;
	varying vec2 vSheenColorMapUv;
#endif
#ifdef USE_SHEEN_ROUGHNESSMAP
	uniform mat3 sheenRoughnessMapTransform;
	varying vec2 vSheenRoughnessMapUv;
#endif
#ifdef USE_IRIDESCENCEMAP
	uniform mat3 iridescenceMapTransform;
	varying vec2 vIridescenceMapUv;
#endif
#ifdef USE_IRIDESCENCE_THICKNESSMAP
	uniform mat3 iridescenceThicknessMapTransform;
	varying vec2 vIridescenceThicknessMapUv;
#endif
#ifdef USE_SPECULARMAP
	uniform mat3 specularMapTransform;
	varying vec2 vSpecularMapUv;
#endif
#ifdef USE_SPECULAR_COLORMAP
	uniform mat3 specularColorMapTransform;
	varying vec2 vSpecularColorMapUv;
#endif
#ifdef USE_SPECULAR_INTENSITYMAP
	uniform mat3 specularIntensityMapTransform;
	varying vec2 vSpecularIntensityMapUv;
#endif
#ifdef USE_TRANSMISSIONMAP
	uniform mat3 transmissionMapTransform;
	varying vec2 vTransmissionMapUv;
#endif
#ifdef USE_THICKNESSMAP
	uniform mat3 thicknessMapTransform;
	varying vec2 vThicknessMapUv;
#endif`,om=`#if defined( USE_UV ) || defined( USE_ANISOTROPY )
	vUv = vec3( uv, 1 ).xy;
#endif
#ifdef USE_MAP
	vMapUv = ( mapTransform * vec3( MAP_UV, 1 ) ).xy;
#endif
#ifdef USE_ALPHAMAP
	vAlphaMapUv = ( alphaMapTransform * vec3( ALPHAMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_LIGHTMAP
	vLightMapUv = ( lightMapTransform * vec3( LIGHTMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_AOMAP
	vAoMapUv = ( aoMapTransform * vec3( AOMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_BUMPMAP
	vBumpMapUv = ( bumpMapTransform * vec3( BUMPMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_NORMALMAP
	vNormalMapUv = ( normalMapTransform * vec3( NORMALMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_DISPLACEMENTMAP
	vDisplacementMapUv = ( displacementMapTransform * vec3( DISPLACEMENTMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_EMISSIVEMAP
	vEmissiveMapUv = ( emissiveMapTransform * vec3( EMISSIVEMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_METALNESSMAP
	vMetalnessMapUv = ( metalnessMapTransform * vec3( METALNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_ROUGHNESSMAP
	vRoughnessMapUv = ( roughnessMapTransform * vec3( ROUGHNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_ANISOTROPYMAP
	vAnisotropyMapUv = ( anisotropyMapTransform * vec3( ANISOTROPYMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_CLEARCOATMAP
	vClearcoatMapUv = ( clearcoatMapTransform * vec3( CLEARCOATMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	vClearcoatNormalMapUv = ( clearcoatNormalMapTransform * vec3( CLEARCOAT_NORMALMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_CLEARCOAT_ROUGHNESSMAP
	vClearcoatRoughnessMapUv = ( clearcoatRoughnessMapTransform * vec3( CLEARCOAT_ROUGHNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_IRIDESCENCEMAP
	vIridescenceMapUv = ( iridescenceMapTransform * vec3( IRIDESCENCEMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_IRIDESCENCE_THICKNESSMAP
	vIridescenceThicknessMapUv = ( iridescenceThicknessMapTransform * vec3( IRIDESCENCE_THICKNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SHEEN_COLORMAP
	vSheenColorMapUv = ( sheenColorMapTransform * vec3( SHEEN_COLORMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SHEEN_ROUGHNESSMAP
	vSheenRoughnessMapUv = ( sheenRoughnessMapTransform * vec3( SHEEN_ROUGHNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SPECULARMAP
	vSpecularMapUv = ( specularMapTransform * vec3( SPECULARMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SPECULAR_COLORMAP
	vSpecularColorMapUv = ( specularColorMapTransform * vec3( SPECULAR_COLORMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SPECULAR_INTENSITYMAP
	vSpecularIntensityMapUv = ( specularIntensityMapTransform * vec3( SPECULAR_INTENSITYMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_TRANSMISSIONMAP
	vTransmissionMapUv = ( transmissionMapTransform * vec3( TRANSMISSIONMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_THICKNESSMAP
	vThicknessMapUv = ( thicknessMapTransform * vec3( THICKNESSMAP_UV, 1 ) ).xy;
#endif`,lm=`#if defined( USE_ENVMAP ) || defined( DISTANCE ) || defined ( USE_SHADOWMAP ) || defined ( USE_TRANSMISSION ) || NUM_SPOT_LIGHT_COORDS > 0
	vec4 worldPosition = vec4( transformed, 1.0 );
	#ifdef USE_BATCHING
		worldPosition = batchingMatrix * worldPosition;
	#endif
	#ifdef USE_INSTANCING
		worldPosition = instanceMatrix * worldPosition;
	#endif
	worldPosition = modelMatrix * worldPosition;
#endif`,cm=`varying vec2 vUv;
uniform mat3 uvTransform;
void main() {
	vUv = ( uvTransform * vec3( uv, 1 ) ).xy;
	gl_Position = vec4( position.xy, 1.0, 1.0 );
}`,hm=`uniform sampler2D t2D;
uniform float backgroundIntensity;
varying vec2 vUv;
void main() {
	vec4 texColor = texture2D( t2D, vUv );
	#ifdef DECODE_VIDEO_TEXTURE
		texColor = vec4( mix( pow( texColor.rgb * 0.9478672986 + vec3( 0.0521327014 ), vec3( 2.4 ) ), texColor.rgb * 0.0773993808, vec3( lessThanEqual( texColor.rgb, vec3( 0.04045 ) ) ) ), texColor.w );
	#endif
	texColor.rgb *= backgroundIntensity;
	gl_FragColor = texColor;
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
}`,um=`varying vec3 vWorldDirection;
#include <common>
void main() {
	vWorldDirection = transformDirection( position, modelMatrix );
	#include <begin_vertex>
	#include <project_vertex>
	gl_Position.z = gl_Position.w;
}`,dm=`#ifdef ENVMAP_TYPE_CUBE
	uniform samplerCube envMap;
#elif defined( ENVMAP_TYPE_CUBE_UV )
	uniform sampler2D envMap;
#endif
uniform float flipEnvMap;
uniform float backgroundBlurriness;
uniform float backgroundIntensity;
varying vec3 vWorldDirection;
#include <cube_uv_reflection_fragment>
void main() {
	#ifdef ENVMAP_TYPE_CUBE
		vec4 texColor = textureCube( envMap, vec3( flipEnvMap * vWorldDirection.x, vWorldDirection.yz ) );
	#elif defined( ENVMAP_TYPE_CUBE_UV )
		vec4 texColor = textureCubeUV( envMap, vWorldDirection, backgroundBlurriness );
	#else
		vec4 texColor = vec4( 0.0, 0.0, 0.0, 1.0 );
	#endif
	texColor.rgb *= backgroundIntensity;
	gl_FragColor = texColor;
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
}`,fm=`varying vec3 vWorldDirection;
#include <common>
void main() {
	vWorldDirection = transformDirection( position, modelMatrix );
	#include <begin_vertex>
	#include <project_vertex>
	gl_Position.z = gl_Position.w;
}`,pm=`uniform samplerCube tCube;
uniform float tFlip;
uniform float opacity;
varying vec3 vWorldDirection;
void main() {
	vec4 texColor = textureCube( tCube, vec3( tFlip * vWorldDirection.x, vWorldDirection.yz ) );
	gl_FragColor = texColor;
	gl_FragColor.a *= opacity;
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
}`,mm=`#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
varying vec2 vHighPrecisionZW;
void main() {
	#include <uv_vertex>
	#include <batching_vertex>
	#include <skinbase_vertex>
	#ifdef USE_DISPLACEMENTMAP
		#include <beginnormal_vertex>
		#include <morphnormal_vertex>
		#include <skinnormal_vertex>
	#endif
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vHighPrecisionZW = gl_Position.zw;
}`,gm=`#if DEPTH_PACKING == 3200
	uniform float opacity;
#endif
#include <common>
#include <packing>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
varying vec2 vHighPrecisionZW;
void main() {
	#include <clipping_planes_fragment>
	vec4 diffuseColor = vec4( 1.0 );
	#if DEPTH_PACKING == 3200
		diffuseColor.a = opacity;
	#endif
	#include <map_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <logdepthbuf_fragment>
	float fragCoordZ = 0.5 * vHighPrecisionZW[0] / vHighPrecisionZW[1] + 0.5;
	#if DEPTH_PACKING == 3200
		gl_FragColor = vec4( vec3( 1.0 - fragCoordZ ), opacity );
	#elif DEPTH_PACKING == 3201
		gl_FragColor = packDepthToRGBA( fragCoordZ );
	#endif
}`,xm=`#define DISTANCE
varying vec3 vWorldPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <batching_vertex>
	#include <skinbase_vertex>
	#ifdef USE_DISPLACEMENTMAP
		#include <beginnormal_vertex>
		#include <morphnormal_vertex>
		#include <skinnormal_vertex>
	#endif
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <worldpos_vertex>
	#include <clipping_planes_vertex>
	vWorldPosition = worldPosition.xyz;
}`,_m=`#define DISTANCE
uniform vec3 referencePosition;
uniform float nearDistance;
uniform float farDistance;
varying vec3 vWorldPosition;
#include <common>
#include <packing>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <clipping_planes_pars_fragment>
void main () {
	#include <clipping_planes_fragment>
	vec4 diffuseColor = vec4( 1.0 );
	#include <map_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	float dist = length( vWorldPosition - referencePosition );
	dist = ( dist - nearDistance ) / ( farDistance - nearDistance );
	dist = saturate( dist );
	gl_FragColor = packDepthToRGBA( dist );
}`,vm=`varying vec3 vWorldDirection;
#include <common>
void main() {
	vWorldDirection = transformDirection( position, modelMatrix );
	#include <begin_vertex>
	#include <project_vertex>
}`,ym=`uniform sampler2D tEquirect;
varying vec3 vWorldDirection;
#include <common>
void main() {
	vec3 direction = normalize( vWorldDirection );
	vec2 sampleUV = equirectUv( direction );
	gl_FragColor = texture2D( tEquirect, sampleUV );
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
}`,bm=`uniform float scale;
attribute float lineDistance;
varying float vLineDistance;
#include <common>
#include <uv_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <morphtarget_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	vLineDistance = scale * lineDistance;
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphcolor_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <fog_vertex>
}`,Mm=`uniform vec3 diffuse;
uniform float opacity;
uniform float dashSize;
uniform float totalSize;
varying float vLineDistance;
#include <common>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <fog_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	#include <clipping_planes_fragment>
	if ( mod( vLineDistance, totalSize ) > dashSize ) {
		discard;
	}
	vec3 outgoingLight = vec3( 0.0 );
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	outgoingLight = diffuseColor.rgb;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
}`,Sm=`#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <envmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#if defined ( USE_ENVMAP ) || defined ( USE_SKINNING )
		#include <beginnormal_vertex>
		#include <morphnormal_vertex>
		#include <skinbase_vertex>
		#include <skinnormal_vertex>
		#include <defaultnormal_vertex>
	#endif
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <worldpos_vertex>
	#include <envmap_vertex>
	#include <fog_vertex>
}`,wm=`uniform vec3 diffuse;
uniform float opacity;
#ifndef FLAT_SHADED
	varying vec3 vNormal;
#endif
#include <common>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <envmap_common_pars_fragment>
#include <envmap_pars_fragment>
#include <fog_pars_fragment>
#include <specularmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	#include <clipping_planes_fragment>
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <specularmap_fragment>
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	#ifdef USE_LIGHTMAP
		vec4 lightMapTexel = texture2D( lightMap, vLightMapUv );
		reflectedLight.indirectDiffuse += lightMapTexel.rgb * lightMapIntensity * RECIPROCAL_PI;
	#else
		reflectedLight.indirectDiffuse += vec3( 1.0 );
	#endif
	#include <aomap_fragment>
	reflectedLight.indirectDiffuse *= diffuseColor.rgb;
	vec3 outgoingLight = reflectedLight.indirectDiffuse;
	#include <envmap_fragment>
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,Em=`#define LAMBERT
varying vec3 vViewPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <envmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <shadowmap_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vViewPosition = - mvPosition.xyz;
	#include <worldpos_vertex>
	#include <envmap_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
}`,Tm=`#define LAMBERT
uniform vec3 diffuse;
uniform vec3 emissive;
uniform float opacity;
#include <common>
#include <packing>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <emissivemap_pars_fragment>
#include <envmap_common_pars_fragment>
#include <envmap_pars_fragment>
#include <fog_pars_fragment>
#include <bsdfs>
#include <lights_pars_begin>
#include <normal_pars_fragment>
#include <lights_lambert_pars_fragment>
#include <shadowmap_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <specularmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	#include <clipping_planes_fragment>
	vec4 diffuseColor = vec4( diffuse, opacity );
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	vec3 totalEmissiveRadiance = emissive;
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <specularmap_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	#include <emissivemap_fragment>
	#include <lights_lambert_fragment>
	#include <lights_fragment_begin>
	#include <lights_fragment_maps>
	#include <lights_fragment_end>
	#include <aomap_fragment>
	vec3 outgoingLight = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse + totalEmissiveRadiance;
	#include <envmap_fragment>
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,Am=`#define MATCAP
varying vec3 vViewPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <color_pars_vertex>
#include <displacementmap_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <fog_vertex>
	vViewPosition = - mvPosition.xyz;
}`,Cm=`#define MATCAP
uniform vec3 diffuse;
uniform float opacity;
uniform sampler2D matcap;
varying vec3 vViewPosition;
#include <common>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <fog_pars_fragment>
#include <normal_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	#include <clipping_planes_fragment>
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	vec3 viewDir = normalize( vViewPosition );
	vec3 x = normalize( vec3( viewDir.z, 0.0, - viewDir.x ) );
	vec3 y = cross( viewDir, x );
	vec2 uv = vec2( dot( x, normal ), dot( y, normal ) ) * 0.495 + 0.5;
	#ifdef USE_MATCAP
		vec4 matcapColor = texture2D( matcap, uv );
	#else
		vec4 matcapColor = vec4( vec3( mix( 0.2, 0.8, uv.y ) ), 1.0 );
	#endif
	vec3 outgoingLight = diffuseColor.rgb * matcapColor.rgb;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,Rm=`#define NORMAL
#if defined( FLAT_SHADED ) || defined( USE_BUMPMAP ) || defined( USE_NORMALMAP_TANGENTSPACE )
	varying vec3 vViewPosition;
#endif
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
#if defined( FLAT_SHADED ) || defined( USE_BUMPMAP ) || defined( USE_NORMALMAP_TANGENTSPACE )
	vViewPosition = - mvPosition.xyz;
#endif
}`,Pm=`#define NORMAL
uniform float opacity;
#if defined( FLAT_SHADED ) || defined( USE_BUMPMAP ) || defined( USE_NORMALMAP_TANGENTSPACE )
	varying vec3 vViewPosition;
#endif
#include <packing>
#include <uv_pars_fragment>
#include <normal_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	#include <clipping_planes_fragment>
	#include <logdepthbuf_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	gl_FragColor = vec4( packNormalToRGB( normal ), opacity );
	#ifdef OPAQUE
		gl_FragColor.a = 1.0;
	#endif
}`,Lm=`#define PHONG
varying vec3 vViewPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <envmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <shadowmap_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vViewPosition = - mvPosition.xyz;
	#include <worldpos_vertex>
	#include <envmap_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
}`,Im=`#define PHONG
uniform vec3 diffuse;
uniform vec3 emissive;
uniform vec3 specular;
uniform float shininess;
uniform float opacity;
#include <common>
#include <packing>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <emissivemap_pars_fragment>
#include <envmap_common_pars_fragment>
#include <envmap_pars_fragment>
#include <fog_pars_fragment>
#include <bsdfs>
#include <lights_pars_begin>
#include <normal_pars_fragment>
#include <lights_phong_pars_fragment>
#include <shadowmap_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <specularmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	#include <clipping_planes_fragment>
	vec4 diffuseColor = vec4( diffuse, opacity );
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	vec3 totalEmissiveRadiance = emissive;
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <specularmap_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	#include <emissivemap_fragment>
	#include <lights_phong_fragment>
	#include <lights_fragment_begin>
	#include <lights_fragment_maps>
	#include <lights_fragment_end>
	#include <aomap_fragment>
	vec3 outgoingLight = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse + reflectedLight.directSpecular + reflectedLight.indirectSpecular + totalEmissiveRadiance;
	#include <envmap_fragment>
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,Dm=`#define STANDARD
varying vec3 vViewPosition;
#ifdef USE_TRANSMISSION
	varying vec3 vWorldPosition;
#endif
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <shadowmap_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vViewPosition = - mvPosition.xyz;
	#include <worldpos_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
#ifdef USE_TRANSMISSION
	vWorldPosition = worldPosition.xyz;
#endif
}`,Um=`#define STANDARD
#ifdef PHYSICAL
	#define IOR
	#define USE_SPECULAR
#endif
uniform vec3 diffuse;
uniform vec3 emissive;
uniform float roughness;
uniform float metalness;
uniform float opacity;
#ifdef IOR
	uniform float ior;
#endif
#ifdef USE_SPECULAR
	uniform float specularIntensity;
	uniform vec3 specularColor;
	#ifdef USE_SPECULAR_COLORMAP
		uniform sampler2D specularColorMap;
	#endif
	#ifdef USE_SPECULAR_INTENSITYMAP
		uniform sampler2D specularIntensityMap;
	#endif
#endif
#ifdef USE_CLEARCOAT
	uniform float clearcoat;
	uniform float clearcoatRoughness;
#endif
#ifdef USE_IRIDESCENCE
	uniform float iridescence;
	uniform float iridescenceIOR;
	uniform float iridescenceThicknessMinimum;
	uniform float iridescenceThicknessMaximum;
#endif
#ifdef USE_SHEEN
	uniform vec3 sheenColor;
	uniform float sheenRoughness;
	#ifdef USE_SHEEN_COLORMAP
		uniform sampler2D sheenColorMap;
	#endif
	#ifdef USE_SHEEN_ROUGHNESSMAP
		uniform sampler2D sheenRoughnessMap;
	#endif
#endif
#ifdef USE_ANISOTROPY
	uniform vec2 anisotropyVector;
	#ifdef USE_ANISOTROPYMAP
		uniform sampler2D anisotropyMap;
	#endif
#endif
varying vec3 vViewPosition;
#include <common>
#include <packing>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <emissivemap_pars_fragment>
#include <iridescence_fragment>
#include <cube_uv_reflection_fragment>
#include <envmap_common_pars_fragment>
#include <envmap_physical_pars_fragment>
#include <fog_pars_fragment>
#include <lights_pars_begin>
#include <normal_pars_fragment>
#include <lights_physical_pars_fragment>
#include <transmission_pars_fragment>
#include <shadowmap_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <clearcoat_pars_fragment>
#include <iridescence_pars_fragment>
#include <roughnessmap_pars_fragment>
#include <metalnessmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	#include <clipping_planes_fragment>
	vec4 diffuseColor = vec4( diffuse, opacity );
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	vec3 totalEmissiveRadiance = emissive;
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <roughnessmap_fragment>
	#include <metalnessmap_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	#include <clearcoat_normal_fragment_begin>
	#include <clearcoat_normal_fragment_maps>
	#include <emissivemap_fragment>
	#include <lights_physical_fragment>
	#include <lights_fragment_begin>
	#include <lights_fragment_maps>
	#include <lights_fragment_end>
	#include <aomap_fragment>
	vec3 totalDiffuse = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse;
	vec3 totalSpecular = reflectedLight.directSpecular + reflectedLight.indirectSpecular;
	#include <transmission_fragment>
	vec3 outgoingLight = totalDiffuse + totalSpecular + totalEmissiveRadiance;
	#ifdef USE_SHEEN
		float sheenEnergyComp = 1.0 - 0.157 * max3( material.sheenColor );
		outgoingLight = outgoingLight * sheenEnergyComp + sheenSpecularDirect + sheenSpecularIndirect;
	#endif
	#ifdef USE_CLEARCOAT
		float dotNVcc = saturate( dot( geometryClearcoatNormal, geometryViewDir ) );
		vec3 Fcc = F_Schlick( material.clearcoatF0, material.clearcoatF90, dotNVcc );
		outgoingLight = outgoingLight * ( 1.0 - material.clearcoat * Fcc ) + ( clearcoatSpecularDirect + clearcoatSpecularIndirect ) * material.clearcoat;
	#endif
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,Nm=`#define TOON
varying vec3 vViewPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <shadowmap_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vViewPosition = - mvPosition.xyz;
	#include <worldpos_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
}`,Om=`#define TOON
uniform vec3 diffuse;
uniform vec3 emissive;
uniform float opacity;
#include <common>
#include <packing>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <emissivemap_pars_fragment>
#include <gradientmap_pars_fragment>
#include <fog_pars_fragment>
#include <bsdfs>
#include <lights_pars_begin>
#include <normal_pars_fragment>
#include <lights_toon_pars_fragment>
#include <shadowmap_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	#include <clipping_planes_fragment>
	vec4 diffuseColor = vec4( diffuse, opacity );
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	vec3 totalEmissiveRadiance = emissive;
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	#include <emissivemap_fragment>
	#include <lights_toon_fragment>
	#include <lights_fragment_begin>
	#include <lights_fragment_maps>
	#include <lights_fragment_end>
	#include <aomap_fragment>
	vec3 outgoingLight = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse + totalEmissiveRadiance;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,Fm=`uniform float size;
uniform float scale;
#include <common>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <morphtarget_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
#ifdef USE_POINTS_UV
	varying vec2 vUv;
	uniform mat3 uvTransform;
#endif
void main() {
	#ifdef USE_POINTS_UV
		vUv = ( uvTransform * vec3( uv, 1 ) ).xy;
	#endif
	#include <color_vertex>
	#include <morphcolor_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <project_vertex>
	gl_PointSize = size;
	#ifdef USE_SIZEATTENUATION
		bool isPerspective = isPerspectiveMatrix( projectionMatrix );
		if ( isPerspective ) gl_PointSize *= ( scale / - mvPosition.z );
	#endif
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <worldpos_vertex>
	#include <fog_vertex>
}`,Bm=`uniform vec3 diffuse;
uniform float opacity;
#include <common>
#include <color_pars_fragment>
#include <map_particle_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <fog_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	#include <clipping_planes_fragment>
	vec3 outgoingLight = vec3( 0.0 );
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <logdepthbuf_fragment>
	#include <map_particle_fragment>
	#include <color_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	outgoingLight = diffuseColor.rgb;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
}`,zm=`#include <common>
#include <batching_pars_vertex>
#include <fog_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <shadowmap_pars_vertex>
void main() {
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <worldpos_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
}`,km=`uniform vec3 color;
uniform float opacity;
#include <common>
#include <packing>
#include <fog_pars_fragment>
#include <bsdfs>
#include <lights_pars_begin>
#include <logdepthbuf_pars_fragment>
#include <shadowmap_pars_fragment>
#include <shadowmask_pars_fragment>
void main() {
	#include <logdepthbuf_fragment>
	gl_FragColor = vec4( color, opacity * ( 1.0 - getShadowMask() ) );
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
}`,Hm=`uniform float rotation;
uniform vec2 center;
#include <common>
#include <uv_pars_vertex>
#include <fog_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	vec4 mvPosition = modelViewMatrix * vec4( 0.0, 0.0, 0.0, 1.0 );
	vec2 scale;
	scale.x = length( vec3( modelMatrix[ 0 ].x, modelMatrix[ 0 ].y, modelMatrix[ 0 ].z ) );
	scale.y = length( vec3( modelMatrix[ 1 ].x, modelMatrix[ 1 ].y, modelMatrix[ 1 ].z ) );
	#ifndef USE_SIZEATTENUATION
		bool isPerspective = isPerspectiveMatrix( projectionMatrix );
		if ( isPerspective ) scale *= - mvPosition.z;
	#endif
	vec2 alignedPosition = ( position.xy - ( center - vec2( 0.5 ) ) ) * scale;
	vec2 rotatedPosition;
	rotatedPosition.x = cos( rotation ) * alignedPosition.x - sin( rotation ) * alignedPosition.y;
	rotatedPosition.y = sin( rotation ) * alignedPosition.x + cos( rotation ) * alignedPosition.y;
	mvPosition.xy += rotatedPosition;
	gl_Position = projectionMatrix * mvPosition;
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <fog_vertex>
}`,Vm=`uniform vec3 diffuse;
uniform float opacity;
#include <common>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <fog_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	#include <clipping_planes_fragment>
	vec3 outgoingLight = vec3( 0.0 );
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	outgoingLight = diffuseColor.rgb;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
}`,ne={alphahash_fragment:hf,alphahash_pars_fragment:uf,alphamap_fragment:df,alphamap_pars_fragment:ff,alphatest_fragment:pf,alphatest_pars_fragment:mf,aomap_fragment:gf,aomap_pars_fragment:xf,batching_pars_vertex:_f,batching_vertex:vf,begin_vertex:yf,beginnormal_vertex:bf,bsdfs:Mf,iridescence_fragment:Sf,bumpmap_pars_fragment:wf,clipping_planes_fragment:Ef,clipping_planes_pars_fragment:Tf,clipping_planes_pars_vertex:Af,clipping_planes_vertex:Cf,color_fragment:Rf,color_pars_fragment:Pf,color_pars_vertex:Lf,color_vertex:If,common:Df,cube_uv_reflection_fragment:Uf,defaultnormal_vertex:Nf,displacementmap_pars_vertex:Of,displacementmap_vertex:Ff,emissivemap_fragment:Bf,emissivemap_pars_fragment:zf,colorspace_fragment:kf,colorspace_pars_fragment:Hf,envmap_fragment:Vf,envmap_common_pars_fragment:Gf,envmap_pars_fragment:Wf,envmap_pars_vertex:Xf,envmap_physical_pars_fragment:ip,envmap_vertex:Yf,fog_vertex:qf,fog_pars_vertex:Zf,fog_fragment:Jf,fog_pars_fragment:jf,gradientmap_pars_fragment:$f,lightmap_fragment:Kf,lightmap_pars_fragment:Qf,lights_lambert_fragment:tp,lights_lambert_pars_fragment:ep,lights_pars_begin:np,lights_toon_fragment:sp,lights_toon_pars_fragment:rp,lights_phong_fragment:ap,lights_phong_pars_fragment:op,lights_physical_fragment:lp,lights_physical_pars_fragment:cp,lights_fragment_begin:hp,lights_fragment_maps:up,lights_fragment_end:dp,logdepthbuf_fragment:fp,logdepthbuf_pars_fragment:pp,logdepthbuf_pars_vertex:mp,logdepthbuf_vertex:gp,map_fragment:xp,map_pars_fragment:_p,map_particle_fragment:vp,map_particle_pars_fragment:yp,metalnessmap_fragment:bp,metalnessmap_pars_fragment:Mp,morphcolor_vertex:Sp,morphnormal_vertex:wp,morphtarget_pars_vertex:Ep,morphtarget_vertex:Tp,normal_fragment_begin:Ap,normal_fragment_maps:Cp,normal_pars_fragment:Rp,normal_pars_vertex:Pp,normal_vertex:Lp,normalmap_pars_fragment:Ip,clearcoat_normal_fragment_begin:Dp,clearcoat_normal_fragment_maps:Up,clearcoat_pars_fragment:Np,iridescence_pars_fragment:Op,opaque_fragment:Fp,packing:Bp,premultiplied_alpha_fragment:zp,project_vertex:kp,dithering_fragment:Hp,dithering_pars_fragment:Vp,roughnessmap_fragment:Gp,roughnessmap_pars_fragment:Wp,shadowmap_pars_fragment:Xp,shadowmap_pars_vertex:Yp,shadowmap_vertex:qp,shadowmask_pars_fragment:Zp,skinbase_vertex:Jp,skinning_pars_vertex:jp,skinning_vertex:$p,skinnormal_vertex:Kp,specularmap_fragment:Qp,specularmap_pars_fragment:tm,tonemapping_fragment:em,tonemapping_pars_fragment:nm,transmission_fragment:im,transmission_pars_fragment:sm,uv_pars_fragment:rm,uv_pars_vertex:am,uv_vertex:om,worldpos_vertex:lm,background_vert:cm,background_frag:hm,backgroundCube_vert:um,backgroundCube_frag:dm,cube_vert:fm,cube_frag:pm,depth_vert:mm,depth_frag:gm,distanceRGBA_vert:xm,distanceRGBA_frag:_m,equirect_vert:vm,equirect_frag:ym,linedashed_vert:bm,linedashed_frag:Mm,meshbasic_vert:Sm,meshbasic_frag:wm,meshlambert_vert:Em,meshlambert_frag:Tm,meshmatcap_vert:Am,meshmatcap_frag:Cm,meshnormal_vert:Rm,meshnormal_frag:Pm,meshphong_vert:Lm,meshphong_frag:Im,meshphysical_vert:Dm,meshphysical_frag:Um,meshtoon_vert:Nm,meshtoon_frag:Om,points_vert:Fm,points_frag:Bm,shadow_vert:zm,shadow_frag:km,sprite_vert:Hm,sprite_frag:Vm},Mt={common:{diffuse:{value:new qt(16777215)},opacity:{value:1},map:{value:null},mapTransform:{value:new oe},alphaMap:{value:null},alphaMapTransform:{value:new oe},alphaTest:{value:0}},specularmap:{specularMap:{value:null},specularMapTransform:{value:new oe}},envmap:{envMap:{value:null},flipEnvMap:{value:-1},reflectivity:{value:1},ior:{value:1.5},refractionRatio:{value:.98}},aomap:{aoMap:{value:null},aoMapIntensity:{value:1},aoMapTransform:{value:new oe}},lightmap:{lightMap:{value:null},lightMapIntensity:{value:1},lightMapTransform:{value:new oe}},bumpmap:{bumpMap:{value:null},bumpMapTransform:{value:new oe},bumpScale:{value:1}},normalmap:{normalMap:{value:null},normalMapTransform:{value:new oe},normalScale:{value:new Lt(1,1)}},displacementmap:{displacementMap:{value:null},displacementMapTransform:{value:new oe},displacementScale:{value:1},displacementBias:{value:0}},emissivemap:{emissiveMap:{value:null},emissiveMapTransform:{value:new oe}},metalnessmap:{metalnessMap:{value:null},metalnessMapTransform:{value:new oe}},roughnessmap:{roughnessMap:{value:null},roughnessMapTransform:{value:new oe}},gradientmap:{gradientMap:{value:null}},fog:{fogDensity:{value:25e-5},fogNear:{value:1},fogFar:{value:2e3},fogColor:{value:new qt(16777215)}},lights:{ambientLightColor:{value:[]},lightProbe:{value:[]},directionalLights:{value:[],properties:{direction:{},color:{}}},directionalLightShadows:{value:[],properties:{shadowBias:{},shadowNormalBias:{},shadowRadius:{},shadowMapSize:{}}},directionalShadowMap:{value:[]},directionalShadowMatrix:{value:[]},spotLights:{value:[],properties:{color:{},position:{},direction:{},distance:{},coneCos:{},penumbraCos:{},decay:{}}},spotLightShadows:{value:[],properties:{shadowBias:{},shadowNormalBias:{},shadowRadius:{},shadowMapSize:{}}},spotLightMap:{value:[]},spotShadowMap:{value:[]},spotLightMatrix:{value:[]},pointLights:{value:[],properties:{color:{},position:{},decay:{},distance:{}}},pointLightShadows:{value:[],properties:{shadowBias:{},shadowNormalBias:{},shadowRadius:{},shadowMapSize:{},shadowCameraNear:{},shadowCameraFar:{}}},pointShadowMap:{value:[]},pointShadowMatrix:{value:[]},hemisphereLights:{value:[],properties:{direction:{},skyColor:{},groundColor:{}}},rectAreaLights:{value:[],properties:{color:{},position:{},width:{},height:{}}},ltc_1:{value:null},ltc_2:{value:null}},points:{diffuse:{value:new qt(16777215)},opacity:{value:1},size:{value:1},scale:{value:1},map:{value:null},alphaMap:{value:null},alphaMapTransform:{value:new oe},alphaTest:{value:0},uvTransform:{value:new oe}},sprite:{diffuse:{value:new qt(16777215)},opacity:{value:1},center:{value:new Lt(.5,.5)},rotation:{value:0},map:{value:null},mapTransform:{value:new oe},alphaMap:{value:null},alphaMapTransform:{value:new oe},alphaTest:{value:0}}},Xn={basic:{uniforms:cn([Mt.common,Mt.specularmap,Mt.envmap,Mt.aomap,Mt.lightmap,Mt.fog]),vertexShader:ne.meshbasic_vert,fragmentShader:ne.meshbasic_frag},lambert:{uniforms:cn([Mt.common,Mt.specularmap,Mt.envmap,Mt.aomap,Mt.lightmap,Mt.emissivemap,Mt.bumpmap,Mt.normalmap,Mt.displacementmap,Mt.fog,Mt.lights,{emissive:{value:new qt(0)}}]),vertexShader:ne.meshlambert_vert,fragmentShader:ne.meshlambert_frag},phong:{uniforms:cn([Mt.common,Mt.specularmap,Mt.envmap,Mt.aomap,Mt.lightmap,Mt.emissivemap,Mt.bumpmap,Mt.normalmap,Mt.displacementmap,Mt.fog,Mt.lights,{emissive:{value:new qt(0)},specular:{value:new qt(1118481)},shininess:{value:30}}]),vertexShader:ne.meshphong_vert,fragmentShader:ne.meshphong_frag},standard:{uniforms:cn([Mt.common,Mt.envmap,Mt.aomap,Mt.lightmap,Mt.emissivemap,Mt.bumpmap,Mt.normalmap,Mt.displacementmap,Mt.roughnessmap,Mt.metalnessmap,Mt.fog,Mt.lights,{emissive:{value:new qt(0)},roughness:{value:1},metalness:{value:0},envMapIntensity:{value:1}}]),vertexShader:ne.meshphysical_vert,fragmentShader:ne.meshphysical_frag},toon:{uniforms:cn([Mt.common,Mt.aomap,Mt.lightmap,Mt.emissivemap,Mt.bumpmap,Mt.normalmap,Mt.displacementmap,Mt.gradientmap,Mt.fog,Mt.lights,{emissive:{value:new qt(0)}}]),vertexShader:ne.meshtoon_vert,fragmentShader:ne.meshtoon_frag},matcap:{uniforms:cn([Mt.common,Mt.bumpmap,Mt.normalmap,Mt.displacementmap,Mt.fog,{matcap:{value:null}}]),vertexShader:ne.meshmatcap_vert,fragmentShader:ne.meshmatcap_frag},points:{uniforms:cn([Mt.points,Mt.fog]),vertexShader:ne.points_vert,fragmentShader:ne.points_frag},dashed:{uniforms:cn([Mt.common,Mt.fog,{scale:{value:1},dashSize:{value:1},totalSize:{value:2}}]),vertexShader:ne.linedashed_vert,fragmentShader:ne.linedashed_frag},depth:{uniforms:cn([Mt.common,Mt.displacementmap]),vertexShader:ne.depth_vert,fragmentShader:ne.depth_frag},normal:{uniforms:cn([Mt.common,Mt.bumpmap,Mt.normalmap,Mt.displacementmap,{opacity:{value:1}}]),vertexShader:ne.meshnormal_vert,fragmentShader:ne.meshnormal_frag},sprite:{uniforms:cn([Mt.sprite,Mt.fog]),vertexShader:ne.sprite_vert,fragmentShader:ne.sprite_frag},background:{uniforms:{uvTransform:{value:new oe},t2D:{value:null},backgroundIntensity:{value:1}},vertexShader:ne.background_vert,fragmentShader:ne.background_frag},backgroundCube:{uniforms:{envMap:{value:null},flipEnvMap:{value:-1},backgroundBlurriness:{value:0},backgroundIntensity:{value:1}},vertexShader:ne.backgroundCube_vert,fragmentShader:ne.backgroundCube_frag},cube:{uniforms:{tCube:{value:null},tFlip:{value:-1},opacity:{value:1}},vertexShader:ne.cube_vert,fragmentShader:ne.cube_frag},equirect:{uniforms:{tEquirect:{value:null}},vertexShader:ne.equirect_vert,fragmentShader:ne.equirect_frag},distanceRGBA:{uniforms:cn([Mt.common,Mt.displacementmap,{referencePosition:{value:new B},nearDistance:{value:1},farDistance:{value:1e3}}]),vertexShader:ne.distanceRGBA_vert,fragmentShader:ne.distanceRGBA_frag},shadow:{uniforms:cn([Mt.lights,Mt.fog,{color:{value:new qt(0)},opacity:{value:1}}]),vertexShader:ne.shadow_vert,fragmentShader:ne.shadow_frag}};Xn.physical={uniforms:cn([Xn.standard.uniforms,{clearcoat:{value:0},clearcoatMap:{value:null},clearcoatMapTransform:{value:new oe},clearcoatNormalMap:{value:null},clearcoatNormalMapTransform:{value:new oe},clearcoatNormalScale:{value:new Lt(1,1)},clearcoatRoughness:{value:0},clearcoatRoughnessMap:{value:null},clearcoatRoughnessMapTransform:{value:new oe},iridescence:{value:0},iridescenceMap:{value:null},iridescenceMapTransform:{value:new oe},iridescenceIOR:{value:1.3},iridescenceThicknessMinimum:{value:100},iridescenceThicknessMaximum:{value:400},iridescenceThicknessMap:{value:null},iridescenceThicknessMapTransform:{value:new oe},sheen:{value:0},sheenColor:{value:new qt(0)},sheenColorMap:{value:null},sheenColorMapTransform:{value:new oe},sheenRoughness:{value:1},sheenRoughnessMap:{value:null},sheenRoughnessMapTransform:{value:new oe},transmission:{value:0},transmissionMap:{value:null},transmissionMapTransform:{value:new oe},transmissionSamplerSize:{value:new Lt},transmissionSamplerMap:{value:null},thickness:{value:0},thicknessMap:{value:null},thicknessMapTransform:{value:new oe},attenuationDistance:{value:0},attenuationColor:{value:new qt(0)},specularColor:{value:new qt(1,1,1)},specularColorMap:{value:null},specularColorMapTransform:{value:new oe},specularIntensity:{value:1},specularIntensityMap:{value:null},specularIntensityMapTransform:{value:new oe},anisotropyVector:{value:new Lt},anisotropyMap:{value:null},anisotropyMapTransform:{value:new oe}}]),vertexShader:ne.meshphysical_vert,fragmentShader:ne.meshphysical_frag};var ta={r:0,b:0,g:0};function Gm(i,t,e,n,s,r,o){let a=new qt(0),l=r===!0?0:1,c,u,f=null,p=0,x=null;function y(g,d){let C=!1,E=d.isScene===!0?d.background:null;E&&E.isTexture&&(E=(d.backgroundBlurriness>0?e:t).get(E)),E===null?M(a,l):E&&E.isColor&&(M(E,1),C=!0);let D=i.xr.getEnvironmentBlendMode();D==="additive"?n.buffers.color.setClear(0,0,0,1,o):D==="alpha-blend"&&n.buffers.color.setClear(0,0,0,0,o),(i.autoClear||C)&&i.clear(i.autoClearColor,i.autoClearDepth,i.autoClearStencil),E&&(E.isCubeTexture||E.mapping===Fa)?(u===void 0&&(u=new He(new Yi(1,1,1),new Ne({name:"BackgroundCubeMaterial",uniforms:Ds(Xn.backgroundCube.uniforms),vertexShader:Xn.backgroundCube.vertexShader,fragmentShader:Xn.backgroundCube.fragmentShader,side:sn,depthTest:!1,depthWrite:!1,fog:!1})),u.geometry.deleteAttribute("normal"),u.geometry.deleteAttribute("uv"),u.onBeforeRender=function(z,U,L){this.matrixWorld.copyPosition(L.matrixWorld)},Object.defineProperty(u.material,"envMap",{get:function(){return this.uniforms.envMap.value}}),s.update(u)),u.material.uniforms.envMap.value=E,u.material.uniforms.flipEnvMap.value=E.isCubeTexture&&E.isRenderTargetTexture===!1?-1:1,u.material.uniforms.backgroundBlurriness.value=d.backgroundBlurriness,u.material.uniforms.backgroundIntensity.value=d.backgroundIntensity,u.material.toneMapped=fe.getTransfer(E.colorSpace)!==xe,(f!==E||p!==E.version||x!==i.toneMapping)&&(u.material.needsUpdate=!0,f=E,p=E.version,x=i.toneMapping),u.layers.enableAll(),g.unshift(u,u.geometry,u.material,0,0,null)):E&&E.isTexture&&(c===void 0&&(c=new He(new mr(2,2),new Ne({name:"BackgroundMaterial",uniforms:Ds(Xn.background.uniforms),vertexShader:Xn.background.vertexShader,fragmentShader:Xn.background.fragmentShader,side:Mi,depthTest:!1,depthWrite:!1,fog:!1})),c.geometry.deleteAttribute("normal"),Object.defineProperty(c.material,"map",{get:function(){return this.uniforms.t2D.value}}),s.update(c)),c.material.uniforms.t2D.value=E,c.material.uniforms.backgroundIntensity.value=d.backgroundIntensity,c.material.toneMapped=fe.getTransfer(E.colorSpace)!==xe,E.matrixAutoUpdate===!0&&E.updateMatrix(),c.material.uniforms.uvTransform.value.copy(E.matrix),(f!==E||p!==E.version||x!==i.toneMapping)&&(c.material.needsUpdate=!0,f=E,p=E.version,x=i.toneMapping),c.layers.enableAll(),g.unshift(c,c.geometry,c.material,0,0,null))}function M(g,d){g.getRGB(ta,eu(i)),n.buffers.color.setClear(ta.r,ta.g,ta.b,d,o)}return{getClearColor:function(){return a},setClearColor:function(g,d=1){a.set(g),l=d,M(a,l)},getClearAlpha:function(){return l},setClearAlpha:function(g){l=g,M(a,l)},render:y}}function Wm(i,t,e,n){let s=i.getParameter(i.MAX_VERTEX_ATTRIBS),r=n.isWebGL2?null:t.get("OES_vertex_array_object"),o=n.isWebGL2||r!==null,a={},l=g(null),c=l,u=!1;function f(I,k,$,Z,j){let K=!1;if(o){let st=M(Z,$,k);c!==st&&(c=st,x(c.object)),K=d(I,Z,$,j),K&&C(I,Z,$,j)}else{let st=k.wireframe===!0;(c.geometry!==Z.id||c.program!==$.id||c.wireframe!==st)&&(c.geometry=Z.id,c.program=$.id,c.wireframe=st,K=!0)}j!==null&&e.update(j,i.ELEMENT_ARRAY_BUFFER),(K||u)&&(u=!1,Q(I,k,$,Z),j!==null&&i.bindBuffer(i.ELEMENT_ARRAY_BUFFER,e.get(j).buffer))}function p(){return n.isWebGL2?i.createVertexArray():r.createVertexArrayOES()}function x(I){return n.isWebGL2?i.bindVertexArray(I):r.bindVertexArrayOES(I)}function y(I){return n.isWebGL2?i.deleteVertexArray(I):r.deleteVertexArrayOES(I)}function M(I,k,$){let Z=$.wireframe===!0,j=a[I.id];j===void 0&&(j={},a[I.id]=j);let K=j[k.id];K===void 0&&(K={},j[k.id]=K);let st=K[Z];return st===void 0&&(st=g(p()),K[Z]=st),st}function g(I){let k=[],$=[],Z=[];for(let j=0;j<s;j++)k[j]=0,$[j]=0,Z[j]=0;return{geometry:null,program:null,wireframe:!1,newAttributes:k,enabledAttributes:$,attributeDivisors:Z,object:I,attributes:{},index:null}}function d(I,k,$,Z){let j=c.attributes,K=k.attributes,st=0,it=$.getAttributes();for(let vt in it)if(it[vt].location>=0){let ct=j[vt],yt=K[vt];if(yt===void 0&&(vt==="instanceMatrix"&&I.instanceMatrix&&(yt=I.instanceMatrix),vt==="instanceColor"&&I.instanceColor&&(yt=I.instanceColor)),ct===void 0||ct.attribute!==yt||yt&&ct.data!==yt.data)return!0;st++}return c.attributesNum!==st||c.index!==Z}function C(I,k,$,Z){let j={},K=k.attributes,st=0,it=$.getAttributes();for(let vt in it)if(it[vt].location>=0){let ct=K[vt];ct===void 0&&(vt==="instanceMatrix"&&I.instanceMatrix&&(ct=I.instanceMatrix),vt==="instanceColor"&&I.instanceColor&&(ct=I.instanceColor));let yt={};yt.attribute=ct,ct&&ct.data&&(yt.data=ct.data),j[vt]=yt,st++}c.attributes=j,c.attributesNum=st,c.index=Z}function E(){let I=c.newAttributes;for(let k=0,$=I.length;k<$;k++)I[k]=0}function D(I){z(I,0)}function z(I,k){let $=c.newAttributes,Z=c.enabledAttributes,j=c.attributeDivisors;$[I]=1,Z[I]===0&&(i.enableVertexAttribArray(I),Z[I]=1),j[I]!==k&&((n.isWebGL2?i:t.get("ANGLE_instanced_arrays"))[n.isWebGL2?"vertexAttribDivisor":"vertexAttribDivisorANGLE"](I,k),j[I]=k)}function U(){let I=c.newAttributes,k=c.enabledAttributes;for(let $=0,Z=k.length;$<Z;$++)k[$]!==I[$]&&(i.disableVertexAttribArray($),k[$]=0)}function L(I,k,$,Z,j,K,st){st===!0?i.vertexAttribIPointer(I,k,$,j,K):i.vertexAttribPointer(I,k,$,Z,j,K)}function Q(I,k,$,Z){if(n.isWebGL2===!1&&(I.isInstancedMesh||Z.isInstancedBufferGeometry)&&t.get("ANGLE_instanced_arrays")===null)return;E();let j=Z.attributes,K=$.getAttributes(),st=k.defaultAttributeValues;for(let it in K){let vt=K[it];if(vt.location>=0){let q=j[it];if(q===void 0&&(it==="instanceMatrix"&&I.instanceMatrix&&(q=I.instanceMatrix),it==="instanceColor"&&I.instanceColor&&(q=I.instanceColor)),q!==void 0){let ct=q.normalized,yt=q.itemSize,It=e.get(q);if(It===void 0)continue;let Ot=It.buffer,Pt=It.type,Dt=It.bytesPerElement,At=n.isWebGL2===!0&&(Pt===i.INT||Pt===i.UNSIGNED_INT||q.gpuType===Vh);if(q.isInterleavedBufferAttribute){let kt=q.data,G=kt.stride,Re=q.offset;if(kt.isInstancedInterleavedBuffer){for(let Ut=0;Ut<vt.locationSize;Ut++)z(vt.location+Ut,kt.meshPerAttribute);I.isInstancedMesh!==!0&&Z._maxInstanceCount===void 0&&(Z._maxInstanceCount=kt.meshPerAttribute*kt.count)}else for(let Ut=0;Ut<vt.locationSize;Ut++)D(vt.location+Ut);i.bindBuffer(i.ARRAY_BUFFER,Ot);for(let Ut=0;Ut<vt.locationSize;Ut++)L(vt.location+Ut,yt/vt.locationSize,Pt,ct,G*Dt,(Re+yt/vt.locationSize*Ut)*Dt,At)}else{if(q.isInstancedBufferAttribute){for(let kt=0;kt<vt.locationSize;kt++)z(vt.location+kt,q.meshPerAttribute);I.isInstancedMesh!==!0&&Z._maxInstanceCount===void 0&&(Z._maxInstanceCount=q.meshPerAttribute*q.count)}else for(let kt=0;kt<vt.locationSize;kt++)D(vt.location+kt);i.bindBuffer(i.ARRAY_BUFFER,Ot);for(let kt=0;kt<vt.locationSize;kt++)L(vt.location+kt,yt/vt.locationSize,Pt,ct,yt*Dt,yt/vt.locationSize*kt*Dt,At)}}else if(st!==void 0){let ct=st[it];if(ct!==void 0)switch(ct.length){case 2:i.vertexAttrib2fv(vt.location,ct);break;case 3:i.vertexAttrib3fv(vt.location,ct);break;case 4:i.vertexAttrib4fv(vt.location,ct);break;default:i.vertexAttrib1fv(vt.location,ct)}}}}U()}function S(){nt();for(let I in a){let k=a[I];for(let $ in k){let Z=k[$];for(let j in Z)y(Z[j].object),delete Z[j];delete k[$]}delete a[I]}}function R(I){if(a[I.id]===void 0)return;let k=a[I.id];for(let $ in k){let Z=k[$];for(let j in Z)y(Z[j].object),delete Z[j];delete k[$]}delete a[I.id]}function V(I){for(let k in a){let $=a[k];if($[I.id]===void 0)continue;let Z=$[I.id];for(let j in Z)y(Z[j].object),delete Z[j];delete $[I.id]}}function nt(){ft(),u=!0,c!==l&&(c=l,x(c.object))}function ft(){l.geometry=null,l.program=null,l.wireframe=!1}return{setup:f,reset:nt,resetDefaultState:ft,dispose:S,releaseStatesOfGeometry:R,releaseStatesOfProgram:V,initAttributes:E,enableAttribute:D,disableUnusedAttributes:U}}function Xm(i,t,e,n){let s=n.isWebGL2,r;function o(u){r=u}function a(u,f){i.drawArrays(r,u,f),e.update(f,r,1)}function l(u,f,p){if(p===0)return;let x,y;if(s)x=i,y="drawArraysInstanced";else if(x=t.get("ANGLE_instanced_arrays"),y="drawArraysInstancedANGLE",x===null){console.error("THREE.WebGLBufferRenderer: using THREE.InstancedBufferGeometry but hardware does not support extension ANGLE_instanced_arrays.");return}x[y](r,u,f,p),e.update(f,r,p)}function c(u,f,p){if(p===0)return;let x=t.get("WEBGL_multi_draw");if(x===null)for(let y=0;y<p;y++)this.render(u[y],f[y]);else{x.multiDrawArraysWEBGL(r,u,0,f,0,p);let y=0;for(let M=0;M<p;M++)y+=f[M];e.update(y,r,1)}}this.setMode=o,this.render=a,this.renderInstances=l,this.renderMultiDraw=c}function Ym(i,t,e){let n;function s(){if(n!==void 0)return n;if(t.has("EXT_texture_filter_anisotropic")===!0){let L=t.get("EXT_texture_filter_anisotropic");n=i.getParameter(L.MAX_TEXTURE_MAX_ANISOTROPY_EXT)}else n=0;return n}function r(L){if(L==="highp"){if(i.getShaderPrecisionFormat(i.VERTEX_SHADER,i.HIGH_FLOAT).precision>0&&i.getShaderPrecisionFormat(i.FRAGMENT_SHADER,i.HIGH_FLOAT).precision>0)return"highp";L="mediump"}return L==="mediump"&&i.getShaderPrecisionFormat(i.VERTEX_SHADER,i.MEDIUM_FLOAT).precision>0&&i.getShaderPrecisionFormat(i.FRAGMENT_SHADER,i.MEDIUM_FLOAT).precision>0?"mediump":"lowp"}let o=typeof WebGL2RenderingContext<"u"&&i.constructor.name==="WebGL2RenderingContext",a=e.precision!==void 0?e.precision:"highp",l=r(a);l!==a&&(console.warn("THREE.WebGLRenderer:",a,"not supported, using",l,"instead."),a=l);let c=o||t.has("WEBGL_draw_buffers"),u=e.logarithmicDepthBuffer===!0,f=i.getParameter(i.MAX_TEXTURE_IMAGE_UNITS),p=i.getParameter(i.MAX_VERTEX_TEXTURE_IMAGE_UNITS),x=i.getParameter(i.MAX_TEXTURE_SIZE),y=i.getParameter(i.MAX_CUBE_MAP_TEXTURE_SIZE),M=i.getParameter(i.MAX_VERTEX_ATTRIBS),g=i.getParameter(i.MAX_VERTEX_UNIFORM_VECTORS),d=i.getParameter(i.MAX_VARYING_VECTORS),C=i.getParameter(i.MAX_FRAGMENT_UNIFORM_VECTORS),E=p>0,D=o||t.has("OES_texture_float"),z=E&&D,U=o?i.getParameter(i.MAX_SAMPLES):0;return{isWebGL2:o,drawBuffers:c,getMaxAnisotropy:s,getMaxPrecision:r,precision:a,logarithmicDepthBuffer:u,maxTextures:f,maxVertexTextures:p,maxTextureSize:x,maxCubemapSize:y,maxAttributes:M,maxVertexUniforms:g,maxVaryings:d,maxFragmentUniforms:C,vertexTextures:E,floatFragmentTextures:D,floatVertexTextures:z,maxSamples:U}}function qm(i){let t=this,e=null,n=0,s=!1,r=!1,o=new In,a=new oe,l={value:null,needsUpdate:!1};this.uniform=l,this.numPlanes=0,this.numIntersection=0,this.init=function(f,p){let x=f.length!==0||p||n!==0||s;return s=p,n=f.length,x},this.beginShadows=function(){r=!0,u(null)},this.endShadows=function(){r=!1},this.setGlobalState=function(f,p){e=u(f,p,0)},this.setState=function(f,p,x){let y=f.clippingPlanes,M=f.clipIntersection,g=f.clipShadows,d=i.get(f);if(!s||y===null||y.length===0||r&&!g)r?u(null):c();else{let C=r?0:n,E=C*4,D=d.clippingState||null;l.value=D,D=u(y,p,E,x);for(let z=0;z!==E;++z)D[z]=e[z];d.clippingState=D,this.numIntersection=M?this.numPlanes:0,this.numPlanes+=C}};function c(){l.value!==e&&(l.value=e,l.needsUpdate=n>0),t.numPlanes=n,t.numIntersection=0}function u(f,p,x,y){let M=f!==null?f.length:0,g=null;if(M!==0){if(g=l.value,y!==!0||g===null){let d=x+M*4,C=p.matrixWorldInverse;a.getNormalMatrix(C),(g===null||g.length<d)&&(g=new Float32Array(d));for(let E=0,D=x;E!==M;++E,D+=4)o.copy(f[E]).applyMatrix4(C,a),o.normal.toArray(g,D),g[D+3]=o.constant}l.value=g,l.needsUpdate=!0}return t.numPlanes=M,t.numIntersection=0,g}}function Zm(i){let t=new WeakMap;function e(o,a){return a===Wo?o.mapping=Ps:a===Xo&&(o.mapping=Ls),o}function n(o){if(o&&o.isTexture){let a=o.mapping;if(a===Wo||a===Xo)if(t.has(o)){let l=t.get(o).texture;return e(l,o.mapping)}else{let l=o.image;if(l&&l.height>0){let c=new Ko(l.height/2);return c.fromEquirectangularTexture(i,o),t.set(o,c),o.addEventListener("dispose",s),e(c.texture,o.mapping)}else return null}}return o}function s(o){let a=o.target;a.removeEventListener("dispose",s);let l=t.get(a);l!==void 0&&(t.delete(a),l.dispose())}function r(){t=new WeakMap}return{get:n,dispose:r}}var Us=class extends ba{constructor(t=-1,e=1,n=1,s=-1,r=.1,o=2e3){super(),this.isOrthographicCamera=!0,this.type="OrthographicCamera",this.zoom=1,this.view=null,this.left=t,this.right=e,this.top=n,this.bottom=s,this.near=r,this.far=o,this.updateProjectionMatrix()}copy(t,e){return super.copy(t,e),this.left=t.left,this.right=t.right,this.top=t.top,this.bottom=t.bottom,this.near=t.near,this.far=t.far,this.zoom=t.zoom,this.view=t.view===null?null:Object.assign({},t.view),this}setViewOffset(t,e,n,s,r,o){this.view===null&&(this.view={enabled:!0,fullWidth:1,fullHeight:1,offsetX:0,offsetY:0,width:1,height:1}),this.view.enabled=!0,this.view.fullWidth=t,this.view.fullHeight=e,this.view.offsetX=n,this.view.offsetY=s,this.view.width=r,this.view.height=o,this.updateProjectionMatrix()}clearViewOffset(){this.view!==null&&(this.view.enabled=!1),this.updateProjectionMatrix()}updateProjectionMatrix(){let t=(this.right-this.left)/(2*this.zoom),e=(this.top-this.bottom)/(2*this.zoom),n=(this.right+this.left)/2,s=(this.top+this.bottom)/2,r=n-t,o=n+t,a=s+e,l=s-e;if(this.view!==null&&this.view.enabled){let c=(this.right-this.left)/this.view.fullWidth/this.zoom,u=(this.top-this.bottom)/this.view.fullHeight/this.zoom;r+=c*this.view.offsetX,o=r+c*this.view.width,a-=u*this.view.offsetY,l=a-u*this.view.height}this.projectionMatrix.makeOrthographic(r,o,a,l,this.near,this.far,this.coordinateSystem),this.projectionMatrixInverse.copy(this.projectionMatrix).invert()}toJSON(t){let e=super.toJSON(t);return e.object.zoom=this.zoom,e.object.left=this.left,e.object.right=this.right,e.object.top=this.top,e.object.bottom=this.bottom,e.object.near=this.near,e.object.far=this.far,this.view!==null&&(e.object.view=Object.assign({},this.view)),e}},Es=4,ch=[.125,.215,.35,.446,.526,.582],Hi=20,No=new Us,hh=new qt,Oo=null,Fo=0,Bo=0,zi=(1+Math.sqrt(5))/2,bs=1/zi,uh=[new B(1,1,1),new B(-1,1,1),new B(1,1,-1),new B(-1,1,-1),new B(0,zi,bs),new B(0,zi,-bs),new B(bs,0,zi),new B(-bs,0,zi),new B(zi,bs,0),new B(-zi,bs,0)],Sa=class{constructor(t){this._renderer=t,this._pingPongRenderTarget=null,this._lodMax=0,this._cubeSize=0,this._lodPlanes=[],this._sizeLods=[],this._sigmas=[],this._blurMaterial=null,this._cubemapMaterial=null,this._equirectMaterial=null,this._compileMaterial(this._blurMaterial)}fromScene(t,e=0,n=.1,s=100){Oo=this._renderer.getRenderTarget(),Fo=this._renderer.getActiveCubeFace(),Bo=this._renderer.getActiveMipmapLevel(),this._setSize(256);let r=this._allocateTargets();return r.depthBuffer=!0,this._sceneToCubeUV(t,n,s,r),e>0&&this._blur(r,0,0,e),this._applyPMREM(r),this._cleanup(r),r}fromEquirectangular(t,e=null){return this._fromTexture(t,e)}fromCubemap(t,e=null){return this._fromTexture(t,e)}compileCubemapShader(){this._cubemapMaterial===null&&(this._cubemapMaterial=ph(),this._compileMaterial(this._cubemapMaterial))}compileEquirectangularShader(){this._equirectMaterial===null&&(this._equirectMaterial=fh(),this._compileMaterial(this._equirectMaterial))}dispose(){this._dispose(),this._cubemapMaterial!==null&&this._cubemapMaterial.dispose(),this._equirectMaterial!==null&&this._equirectMaterial.dispose()}_setSize(t){this._lodMax=Math.floor(Math.log2(t)),this._cubeSize=Math.pow(2,this._lodMax)}_dispose(){this._blurMaterial!==null&&this._blurMaterial.dispose(),this._pingPongRenderTarget!==null&&this._pingPongRenderTarget.dispose();for(let t=0;t<this._lodPlanes.length;t++)this._lodPlanes[t].dispose()}_cleanup(t){this._renderer.setRenderTarget(Oo,Fo,Bo),t.scissorTest=!1,ea(t,0,0,t.width,t.height)}_fromTexture(t,e){t.mapping===Ps||t.mapping===Ls?this._setSize(t.image.length===0?16:t.image[0].width||t.image[0].image.width):this._setSize(t.image.width/4),Oo=this._renderer.getRenderTarget(),Fo=this._renderer.getActiveCubeFace(),Bo=this._renderer.getActiveMipmapLevel();let n=e||this._allocateTargets();return this._textureToCubeUV(t,n),this._applyPMREM(n),this._cleanup(n),n}_allocateTargets(){let t=3*Math.max(this._cubeSize,112),e=4*this._cubeSize,n={magFilter:bn,minFilter:bn,generateMipmaps:!1,type:gn,format:Nn,colorSpace:ri,depthBuffer:!1},s=dh(t,e,n);if(this._pingPongRenderTarget===null||this._pingPongRenderTarget.width!==t||this._pingPongRenderTarget.height!==e){this._pingPongRenderTarget!==null&&this._dispose(),this._pingPongRenderTarget=dh(t,e,n);let{_lodMax:r}=this;({sizeLods:this._sizeLods,lodPlanes:this._lodPlanes,sigmas:this._sigmas}=Jm(r)),this._blurMaterial=jm(r,t,e)}return s}_compileMaterial(t){let e=new He(this._lodPlanes[0],t);this._renderer.compile(e,No)}_sceneToCubeUV(t,e,n,s){let a=new nn(90,1,e,n),l=[1,-1,1,1,1,1],c=[1,1,1,-1,-1,-1],u=this._renderer,f=u.autoClear,p=u.toneMapping;u.getClearColor(hh),u.toneMapping=yi,u.autoClear=!1;let x=new xn({name:"PMREM.Background",side:sn,depthWrite:!1,depthTest:!1}),y=new He(new Yi,x),M=!1,g=t.background;g?g.isColor&&(x.color.copy(g),t.background=null,M=!0):(x.color.copy(hh),M=!0);for(let d=0;d<6;d++){let C=d%3;C===0?(a.up.set(0,l[d],0),a.lookAt(c[d],0,0)):C===1?(a.up.set(0,0,l[d]),a.lookAt(0,c[d],0)):(a.up.set(0,l[d],0),a.lookAt(0,0,c[d]));let E=this._cubeSize;ea(s,C*E,d>2?E:0,E,E),u.setRenderTarget(s),M&&u.render(y,a),u.render(t,a)}y.geometry.dispose(),y.material.dispose(),u.toneMapping=p,u.autoClear=f,t.background=g}_textureToCubeUV(t,e){let n=this._renderer,s=t.mapping===Ps||t.mapping===Ls;s?(this._cubemapMaterial===null&&(this._cubemapMaterial=ph()),this._cubemapMaterial.uniforms.flipEnvMap.value=t.isRenderTargetTexture===!1?-1:1):this._equirectMaterial===null&&(this._equirectMaterial=fh());let r=s?this._cubemapMaterial:this._equirectMaterial,o=new He(this._lodPlanes[0],r),a=r.uniforms;a.envMap.value=t;let l=this._cubeSize;ea(e,0,0,3*l,2*l),n.setRenderTarget(e),n.render(o,No)}_applyPMREM(t){let e=this._renderer,n=e.autoClear;e.autoClear=!1;for(let s=1;s<this._lodPlanes.length;s++){let r=Math.sqrt(this._sigmas[s]*this._sigmas[s]-this._sigmas[s-1]*this._sigmas[s-1]),o=uh[(s-1)%uh.length];this._blur(t,s-1,s,r,o)}e.autoClear=n}_blur(t,e,n,s,r){let o=this._pingPongRenderTarget;this._halfBlur(t,o,e,n,s,"latitudinal",r),this._halfBlur(o,t,n,n,s,"longitudinal",r)}_halfBlur(t,e,n,s,r,o,a){let l=this._renderer,c=this._blurMaterial;o!=="latitudinal"&&o!=="longitudinal"&&console.error("blur direction must be either latitudinal or longitudinal!");let u=3,f=new He(this._lodPlanes[s],c),p=c.uniforms,x=this._sizeLods[n]-1,y=isFinite(r)?Math.PI/(2*x):2*Math.PI/(2*Hi-1),M=r/y,g=isFinite(r)?1+Math.floor(u*M):Hi;g>Hi&&console.warn(`sigmaRadians, ${r}, is too large and will clip, as it requested ${g} samples when the maximum is set to ${Hi}`);let d=[],C=0;for(let L=0;L<Hi;++L){let Q=L/M,S=Math.exp(-Q*Q/2);d.push(S),L===0?C+=S:L<g&&(C+=2*S)}for(let L=0;L<d.length;L++)d[L]=d[L]/C;p.envMap.value=t.texture,p.samples.value=g,p.weights.value=d,p.latitudinal.value=o==="latitudinal",a&&(p.poleAxis.value=a);let{_lodMax:E}=this;p.dTheta.value=y,p.mipInt.value=E-n;let D=this._sizeLods[s],z=3*D*(s>E-Es?s-E+Es:0),U=4*(this._cubeSize-D);ea(e,z,U,3*D,2*D),l.setRenderTarget(e),l.render(f,No)}};function Jm(i){let t=[],e=[],n=[],s=i,r=i-Es+1+ch.length;for(let o=0;o<r;o++){let a=Math.pow(2,s);e.push(a);let l=1/a;o>i-Es?l=ch[o-i+Es-1]:o===0&&(l=0),n.push(l);let c=1/(a-2),u=-c,f=1+c,p=[u,u,f,u,f,f,u,u,f,f,u,f],x=6,y=6,M=3,g=2,d=1,C=new Float32Array(M*y*x),E=new Float32Array(g*y*x),D=new Float32Array(d*y*x);for(let U=0;U<x;U++){let L=U%3*2/3-1,Q=U>2?0:-1,S=[L,Q,0,L+2/3,Q,0,L+2/3,Q+1,0,L,Q,0,L+2/3,Q+1,0,L,Q+1,0];C.set(S,M*y*U),E.set(p,g*y*U);let R=[U,U,U,U,U,U];D.set(R,d*y*U)}let z=new hn;z.setAttribute("position",new rn(C,M)),z.setAttribute("uv",new rn(E,g)),z.setAttribute("faceIndex",new rn(D,d)),t.push(z),s>Es&&s--}return{lodPlanes:t,sizeLods:e,sigmas:n}}function dh(i,t,e){let n=new Ke(i,t,e);return n.texture.mapping=Fa,n.texture.name="PMREM.cubeUv",n.scissorTest=!0,n}function ea(i,t,e,n,s){i.viewport.set(t,e,n,s),i.scissor.set(t,e,n,s)}function jm(i,t,e){let n=new Float32Array(Hi),s=new B(0,1,0);return new Ne({name:"SphericalGaussianBlur",defines:{n:Hi,CUBEUV_TEXEL_WIDTH:1/t,CUBEUV_TEXEL_HEIGHT:1/e,CUBEUV_MAX_MIP:`${i}.0`},uniforms:{envMap:{value:null},samples:{value:1},weights:{value:n},latitudinal:{value:!1},dTheta:{value:0},mipInt:{value:0},poleAxis:{value:s}},vertexShader:Il(),fragmentShader:`

			precision mediump float;
			precision mediump int;

			varying vec3 vOutputDirection;

			uniform sampler2D envMap;
			uniform int samples;
			uniform float weights[ n ];
			uniform bool latitudinal;
			uniform float dTheta;
			uniform float mipInt;
			uniform vec3 poleAxis;

			#define ENVMAP_TYPE_CUBE_UV
			#include <cube_uv_reflection_fragment>

			vec3 getSample( float theta, vec3 axis ) {

				float cosTheta = cos( theta );
				// Rodrigues' axis-angle rotation
				vec3 sampleDirection = vOutputDirection * cosTheta
					+ cross( axis, vOutputDirection ) * sin( theta )
					+ axis * dot( axis, vOutputDirection ) * ( 1.0 - cosTheta );

				return bilinearCubeUV( envMap, sampleDirection, mipInt );

			}

			void main() {

				vec3 axis = latitudinal ? poleAxis : cross( poleAxis, vOutputDirection );

				if ( all( equal( axis, vec3( 0.0 ) ) ) ) {

					axis = vec3( vOutputDirection.z, 0.0, - vOutputDirection.x );

				}

				axis = normalize( axis );

				gl_FragColor = vec4( 0.0, 0.0, 0.0, 1.0 );
				gl_FragColor.rgb += weights[ 0 ] * getSample( 0.0, axis );

				for ( int i = 1; i < n; i++ ) {

					if ( i >= samples ) {

						break;

					}

					float theta = dTheta * float( i );
					gl_FragColor.rgb += weights[ i ] * getSample( -1.0 * theta, axis );
					gl_FragColor.rgb += weights[ i ] * getSample( theta, axis );

				}

			}
		`,blending:Yn,depthTest:!1,depthWrite:!1})}function fh(){return new Ne({name:"EquirectangularToCubeUV",uniforms:{envMap:{value:null}},vertexShader:Il(),fragmentShader:`

			precision mediump float;
			precision mediump int;

			varying vec3 vOutputDirection;

			uniform sampler2D envMap;

			#include <common>

			void main() {

				vec3 outputDirection = normalize( vOutputDirection );
				vec2 uv = equirectUv( outputDirection );

				gl_FragColor = vec4( texture2D ( envMap, uv ).rgb, 1.0 );

			}
		`,blending:Yn,depthTest:!1,depthWrite:!1})}function ph(){return new Ne({name:"CubemapToCubeUV",uniforms:{envMap:{value:null},flipEnvMap:{value:-1}},vertexShader:Il(),fragmentShader:`

			precision mediump float;
			precision mediump int;

			uniform float flipEnvMap;

			varying vec3 vOutputDirection;

			uniform samplerCube envMap;

			void main() {

				gl_FragColor = textureCube( envMap, vec3( flipEnvMap * vOutputDirection.x, vOutputDirection.yz ) );

			}
		`,blending:Yn,depthTest:!1,depthWrite:!1})}function Il(){return`

		precision mediump float;
		precision mediump int;

		attribute float faceIndex;

		varying vec3 vOutputDirection;

		// RH coordinate system; PMREM face-indexing convention
		vec3 getDirection( vec2 uv, float face ) {

			uv = 2.0 * uv - 1.0;

			vec3 direction = vec3( uv, 1.0 );

			if ( face == 0.0 ) {

				direction = direction.zyx; // ( 1, v, u ) pos x

			} else if ( face == 1.0 ) {

				direction = direction.xzy;
				direction.xz *= -1.0; // ( -u, 1, -v ) pos y

			} else if ( face == 2.0 ) {

				direction.x *= -1.0; // ( -u, v, 1 ) pos z

			} else if ( face == 3.0 ) {

				direction = direction.zyx;
				direction.xz *= -1.0; // ( -1, v, -u ) neg x

			} else if ( face == 4.0 ) {

				direction = direction.xzy;
				direction.xy *= -1.0; // ( -u, -1, v ) neg y

			} else if ( face == 5.0 ) {

				direction.z *= -1.0; // ( u, v, -1 ) neg z

			}

			return direction;

		}

		void main() {

			vOutputDirection = getDirection( uv, faceIndex );
			gl_Position = vec4( position, 1.0 );

		}
	`}function $m(i){let t=new WeakMap,e=null;function n(a){if(a&&a.isTexture){let l=a.mapping,c=l===Wo||l===Xo,u=l===Ps||l===Ls;if(c||u)if(a.isRenderTargetTexture&&a.needsPMREMUpdate===!0){a.needsPMREMUpdate=!1;let f=t.get(a);return e===null&&(e=new Sa(i)),f=c?e.fromEquirectangular(a,f):e.fromCubemap(a,f),t.set(a,f),f.texture}else{if(t.has(a))return t.get(a).texture;{let f=a.image;if(c&&f&&f.height>0||u&&f&&s(f)){e===null&&(e=new Sa(i));let p=c?e.fromEquirectangular(a):e.fromCubemap(a);return t.set(a,p),a.addEventListener("dispose",r),p.texture}else return null}}}return a}function s(a){let l=0,c=6;for(let u=0;u<c;u++)a[u]!==void 0&&l++;return l===c}function r(a){let l=a.target;l.removeEventListener("dispose",r);let c=t.get(l);c!==void 0&&(t.delete(l),c.dispose())}function o(){t=new WeakMap,e!==null&&(e.dispose(),e=null)}return{get:n,dispose:o}}function Km(i){let t={};function e(n){if(t[n]!==void 0)return t[n];let s;switch(n){case"WEBGL_depth_texture":s=i.getExtension("WEBGL_depth_texture")||i.getExtension("MOZ_WEBGL_depth_texture")||i.getExtension("WEBKIT_WEBGL_depth_texture");break;case"EXT_texture_filter_anisotropic":s=i.getExtension("EXT_texture_filter_anisotropic")||i.getExtension("MOZ_EXT_texture_filter_anisotropic")||i.getExtension("WEBKIT_EXT_texture_filter_anisotropic");break;case"WEBGL_compressed_texture_s3tc":s=i.getExtension("WEBGL_compressed_texture_s3tc")||i.getExtension("MOZ_WEBGL_compressed_texture_s3tc")||i.getExtension("WEBKIT_WEBGL_compressed_texture_s3tc");break;case"WEBGL_compressed_texture_pvrtc":s=i.getExtension("WEBGL_compressed_texture_pvrtc")||i.getExtension("WEBKIT_WEBGL_compressed_texture_pvrtc");break;default:s=i.getExtension(n)}return t[n]=s,s}return{has:function(n){return e(n)!==null},init:function(n){n.isWebGL2?(e("EXT_color_buffer_float"),e("WEBGL_clip_cull_distance")):(e("WEBGL_depth_texture"),e("OES_texture_float"),e("OES_texture_half_float"),e("OES_texture_half_float_linear"),e("OES_standard_derivatives"),e("OES_element_index_uint"),e("OES_vertex_array_object"),e("ANGLE_instanced_arrays")),e("OES_texture_float_linear"),e("EXT_color_buffer_half_float"),e("WEBGL_multisampled_render_to_texture")},get:function(n){let s=e(n);return s===null&&console.warn("THREE.WebGLRenderer: "+n+" extension not supported."),s}}}function Qm(i,t,e,n){let s={},r=new WeakMap;function o(f){let p=f.target;p.index!==null&&t.remove(p.index);for(let y in p.attributes)t.remove(p.attributes[y]);for(let y in p.morphAttributes){let M=p.morphAttributes[y];for(let g=0,d=M.length;g<d;g++)t.remove(M[g])}p.removeEventListener("dispose",o),delete s[p.id];let x=r.get(p);x&&(t.remove(x),r.delete(p)),n.releaseStatesOfGeometry(p),p.isInstancedBufferGeometry===!0&&delete p._maxInstanceCount,e.memory.geometries--}function a(f,p){return s[p.id]===!0||(p.addEventListener("dispose",o),s[p.id]=!0,e.memory.geometries++),p}function l(f){let p=f.attributes;for(let y in p)t.update(p[y],i.ARRAY_BUFFER);let x=f.morphAttributes;for(let y in x){let M=x[y];for(let g=0,d=M.length;g<d;g++)t.update(M[g],i.ARRAY_BUFFER)}}function c(f){let p=[],x=f.index,y=f.attributes.position,M=0;if(x!==null){let C=x.array;M=x.version;for(let E=0,D=C.length;E<D;E+=3){let z=C[E+0],U=C[E+1],L=C[E+2];p.push(z,U,U,L,L,z)}}else if(y!==void 0){let C=y.array;M=y.version;for(let E=0,D=C.length/3-1;E<D;E+=3){let z=E+0,U=E+1,L=E+2;p.push(z,U,U,L,L,z)}}else return;let g=new(Qh(p)?ya:va)(p,1);g.version=M;let d=r.get(f);d&&t.remove(d),r.set(f,g)}function u(f){let p=r.get(f);if(p){let x=f.index;x!==null&&p.version<x.version&&c(f)}else c(f);return r.get(f)}return{get:a,update:l,getWireframeAttribute:u}}function tg(i,t,e,n){let s=n.isWebGL2,r;function o(x){r=x}let a,l;function c(x){a=x.type,l=x.bytesPerElement}function u(x,y){i.drawElements(r,y,a,x*l),e.update(y,r,1)}function f(x,y,M){if(M===0)return;let g,d;if(s)g=i,d="drawElementsInstanced";else if(g=t.get("ANGLE_instanced_arrays"),d="drawElementsInstancedANGLE",g===null){console.error("THREE.WebGLIndexedBufferRenderer: using THREE.InstancedBufferGeometry but hardware does not support extension ANGLE_instanced_arrays.");return}g[d](r,y,a,x*l,M),e.update(y,r,M)}function p(x,y,M){if(M===0)return;let g=t.get("WEBGL_multi_draw");if(g===null)for(let d=0;d<M;d++)this.render(x[d]/l,y[d]);else{g.multiDrawElementsWEBGL(r,y,0,a,x,0,M);let d=0;for(let C=0;C<M;C++)d+=y[C];e.update(d,r,1)}}this.setMode=o,this.setIndex=c,this.render=u,this.renderInstances=f,this.renderMultiDraw=p}function eg(i){let t={geometries:0,textures:0},e={frame:0,calls:0,triangles:0,points:0,lines:0};function n(r,o,a){switch(e.calls++,o){case i.TRIANGLES:e.triangles+=a*(r/3);break;case i.LINES:e.lines+=a*(r/2);break;case i.LINE_STRIP:e.lines+=a*(r-1);break;case i.LINE_LOOP:e.lines+=a*r;break;case i.POINTS:e.points+=a*r;break;default:console.error("THREE.WebGLInfo: Unknown draw mode:",o);break}}function s(){e.calls=0,e.triangles=0,e.points=0,e.lines=0}return{memory:t,render:e,programs:null,autoReset:!0,reset:s,update:n}}function ng(i,t){return i[0]-t[0]}function ig(i,t){return Math.abs(t[1])-Math.abs(i[1])}function sg(i,t,e){let n={},s=new Float32Array(8),r=new WeakMap,o=new Ee,a=[];for(let c=0;c<8;c++)a[c]=[c,0];function l(c,u,f){let p=c.morphTargetInfluences;if(t.isWebGL2===!0){let x=u.morphAttributes.position||u.morphAttributes.normal||u.morphAttributes.color,y=x!==void 0?x.length:0,M=r.get(u);if(M===void 0||M.count!==y){let I=function(){nt.dispose(),r.delete(u),u.removeEventListener("dispose",I)};M!==void 0&&M.texture.dispose();let C=u.morphAttributes.position!==void 0,E=u.morphAttributes.normal!==void 0,D=u.morphAttributes.color!==void 0,z=u.morphAttributes.position||[],U=u.morphAttributes.normal||[],L=u.morphAttributes.color||[],Q=0;C===!0&&(Q=1),E===!0&&(Q=2),D===!0&&(Q=3);let S=u.attributes.position.count*Q,R=1;S>t.maxTextureSize&&(R=Math.ceil(S/t.maxTextureSize),S=t.maxTextureSize);let V=new Float32Array(S*R*4*y),nt=new xa(V,S,R,y);nt.type=_i,nt.needsUpdate=!0;let ft=Q*4;for(let k=0;k<y;k++){let $=z[k],Z=U[k],j=L[k],K=S*R*4*k;for(let st=0;st<$.count;st++){let it=st*ft;C===!0&&(o.fromBufferAttribute($,st),V[K+it+0]=o.x,V[K+it+1]=o.y,V[K+it+2]=o.z,V[K+it+3]=0),E===!0&&(o.fromBufferAttribute(Z,st),V[K+it+4]=o.x,V[K+it+5]=o.y,V[K+it+6]=o.z,V[K+it+7]=0),D===!0&&(o.fromBufferAttribute(j,st),V[K+it+8]=o.x,V[K+it+9]=o.y,V[K+it+10]=o.z,V[K+it+11]=j.itemSize===4?o.w:1)}}M={count:y,texture:nt,size:new Lt(S,R)},r.set(u,M),u.addEventListener("dispose",I)}let g=0;for(let C=0;C<p.length;C++)g+=p[C];let d=u.morphTargetsRelative?1:1-g;f.getUniforms().setValue(i,"morphTargetBaseInfluence",d),f.getUniforms().setValue(i,"morphTargetInfluences",p),f.getUniforms().setValue(i,"morphTargetsTexture",M.texture,e),f.getUniforms().setValue(i,"morphTargetsTextureSize",M.size)}else{let x=p===void 0?0:p.length,y=n[u.id];if(y===void 0||y.length!==x){y=[];for(let E=0;E<x;E++)y[E]=[E,0];n[u.id]=y}for(let E=0;E<x;E++){let D=y[E];D[0]=E,D[1]=p[E]}y.sort(ig);for(let E=0;E<8;E++)E<x&&y[E][1]?(a[E][0]=y[E][0],a[E][1]=y[E][1]):(a[E][0]=Number.MAX_SAFE_INTEGER,a[E][1]=0);a.sort(ng);let M=u.morphAttributes.position,g=u.morphAttributes.normal,d=0;for(let E=0;E<8;E++){let D=a[E],z=D[0],U=D[1];z!==Number.MAX_SAFE_INTEGER&&U?(M&&u.getAttribute("morphTarget"+E)!==M[z]&&u.setAttribute("morphTarget"+E,M[z]),g&&u.getAttribute("morphNormal"+E)!==g[z]&&u.setAttribute("morphNormal"+E,g[z]),s[E]=U,d+=U):(M&&u.hasAttribute("morphTarget"+E)===!0&&u.deleteAttribute("morphTarget"+E),g&&u.hasAttribute("morphNormal"+E)===!0&&u.deleteAttribute("morphNormal"+E),s[E]=0)}let C=u.morphTargetsRelative?1:1-d;f.getUniforms().setValue(i,"morphTargetBaseInfluence",C),f.getUniforms().setValue(i,"morphTargetInfluences",s)}}return{update:l}}function rg(i,t,e,n){let s=new WeakMap;function r(l){let c=n.render.frame,u=l.geometry,f=t.get(l,u);if(s.get(f)!==c&&(t.update(f),s.set(f,c)),l.isInstancedMesh&&(l.hasEventListener("dispose",a)===!1&&l.addEventListener("dispose",a),s.get(l)!==c&&(e.update(l.instanceMatrix,i.ARRAY_BUFFER),l.instanceColor!==null&&e.update(l.instanceColor,i.ARRAY_BUFFER),s.set(l,c))),l.isSkinnedMesh){let p=l.skeleton;s.get(p)!==c&&(p.update(),s.set(p,c))}return f}function o(){s=new WeakMap}function a(l){let c=l.target;c.removeEventListener("dispose",a),e.remove(c.instanceMatrix),c.instanceColor!==null&&e.remove(c.instanceColor)}return{update:r,dispose:o}}var wa=class extends Sn{constructor(t,e,n,s,r,o,a,l,c,u){if(u=u!==void 0?u:Gi,u!==Gi&&u!==Is)throw new Error("DepthTexture format must be either THREE.DepthFormat or THREE.DepthStencilFormat");n===void 0&&u===Gi&&(n=xi),n===void 0&&u===Is&&(n=Vi),super(null,s,r,o,a,l,u,n,c),this.isDepthTexture=!0,this.image={width:t,height:e},this.magFilter=a!==void 0?a:qe,this.minFilter=l!==void 0?l:qe,this.flipY=!1,this.generateMipmaps=!1,this.compareFunction=null}copy(t){return super.copy(t),this.compareFunction=t.compareFunction,this}toJSON(t){let e=super.toJSON(t);return this.compareFunction!==null&&(e.compareFunction=this.compareFunction),e}},iu=new Sn,su=new wa(1,1);su.compareFunction=$h;var ru=new xa,au=new jo,ou=new Ma,mh=[],gh=[],xh=new Float32Array(16),_h=new Float32Array(9),vh=new Float32Array(4);function zs(i,t,e){let n=i[0];if(n<=0||n>0)return i;let s=t*e,r=mh[s];if(r===void 0&&(r=new Float32Array(s),mh[s]=r),t!==0){n.toArray(r,0);for(let o=1,a=0;o!==t;++o)a+=e,i[o].toArray(r,a)}return r}function Ve(i,t){if(i.length!==t.length)return!1;for(let e=0,n=i.length;e<n;e++)if(i[e]!==t[e])return!1;return!0}function Ge(i,t){for(let e=0,n=t.length;e<n;e++)i[e]=t[e]}function za(i,t){let e=gh[t];e===void 0&&(e=new Int32Array(t),gh[t]=e);for(let n=0;n!==t;++n)e[n]=i.allocateTextureUnit();return e}function ag(i,t){let e=this.cache;e[0]!==t&&(i.uniform1f(this.addr,t),e[0]=t)}function og(i,t){let e=this.cache;if(t.x!==void 0)(e[0]!==t.x||e[1]!==t.y)&&(i.uniform2f(this.addr,t.x,t.y),e[0]=t.x,e[1]=t.y);else{if(Ve(e,t))return;i.uniform2fv(this.addr,t),Ge(e,t)}}function lg(i,t){let e=this.cache;if(t.x!==void 0)(e[0]!==t.x||e[1]!==t.y||e[2]!==t.z)&&(i.uniform3f(this.addr,t.x,t.y,t.z),e[0]=t.x,e[1]=t.y,e[2]=t.z);else if(t.r!==void 0)(e[0]!==t.r||e[1]!==t.g||e[2]!==t.b)&&(i.uniform3f(this.addr,t.r,t.g,t.b),e[0]=t.r,e[1]=t.g,e[2]=t.b);else{if(Ve(e,t))return;i.uniform3fv(this.addr,t),Ge(e,t)}}function cg(i,t){let e=this.cache;if(t.x!==void 0)(e[0]!==t.x||e[1]!==t.y||e[2]!==t.z||e[3]!==t.w)&&(i.uniform4f(this.addr,t.x,t.y,t.z,t.w),e[0]=t.x,e[1]=t.y,e[2]=t.z,e[3]=t.w);else{if(Ve(e,t))return;i.uniform4fv(this.addr,t),Ge(e,t)}}function hg(i,t){let e=this.cache,n=t.elements;if(n===void 0){if(Ve(e,t))return;i.uniformMatrix2fv(this.addr,!1,t),Ge(e,t)}else{if(Ve(e,n))return;vh.set(n),i.uniformMatrix2fv(this.addr,!1,vh),Ge(e,n)}}function ug(i,t){let e=this.cache,n=t.elements;if(n===void 0){if(Ve(e,t))return;i.uniformMatrix3fv(this.addr,!1,t),Ge(e,t)}else{if(Ve(e,n))return;_h.set(n),i.uniformMatrix3fv(this.addr,!1,_h),Ge(e,n)}}function dg(i,t){let e=this.cache,n=t.elements;if(n===void 0){if(Ve(e,t))return;i.uniformMatrix4fv(this.addr,!1,t),Ge(e,t)}else{if(Ve(e,n))return;xh.set(n),i.uniformMatrix4fv(this.addr,!1,xh),Ge(e,n)}}function fg(i,t){let e=this.cache;e[0]!==t&&(i.uniform1i(this.addr,t),e[0]=t)}function pg(i,t){let e=this.cache;if(t.x!==void 0)(e[0]!==t.x||e[1]!==t.y)&&(i.uniform2i(this.addr,t.x,t.y),e[0]=t.x,e[1]=t.y);else{if(Ve(e,t))return;i.uniform2iv(this.addr,t),Ge(e,t)}}function mg(i,t){let e=this.cache;if(t.x!==void 0)(e[0]!==t.x||e[1]!==t.y||e[2]!==t.z)&&(i.uniform3i(this.addr,t.x,t.y,t.z),e[0]=t.x,e[1]=t.y,e[2]=t.z);else{if(Ve(e,t))return;i.uniform3iv(this.addr,t),Ge(e,t)}}function gg(i,t){let e=this.cache;if(t.x!==void 0)(e[0]!==t.x||e[1]!==t.y||e[2]!==t.z||e[3]!==t.w)&&(i.uniform4i(this.addr,t.x,t.y,t.z,t.w),e[0]=t.x,e[1]=t.y,e[2]=t.z,e[3]=t.w);else{if(Ve(e,t))return;i.uniform4iv(this.addr,t),Ge(e,t)}}function xg(i,t){let e=this.cache;e[0]!==t&&(i.uniform1ui(this.addr,t),e[0]=t)}function _g(i,t){let e=this.cache;if(t.x!==void 0)(e[0]!==t.x||e[1]!==t.y)&&(i.uniform2ui(this.addr,t.x,t.y),e[0]=t.x,e[1]=t.y);else{if(Ve(e,t))return;i.uniform2uiv(this.addr,t),Ge(e,t)}}function vg(i,t){let e=this.cache;if(t.x!==void 0)(e[0]!==t.x||e[1]!==t.y||e[2]!==t.z)&&(i.uniform3ui(this.addr,t.x,t.y,t.z),e[0]=t.x,e[1]=t.y,e[2]=t.z);else{if(Ve(e,t))return;i.uniform3uiv(this.addr,t),Ge(e,t)}}function yg(i,t){let e=this.cache;if(t.x!==void 0)(e[0]!==t.x||e[1]!==t.y||e[2]!==t.z||e[3]!==t.w)&&(i.uniform4ui(this.addr,t.x,t.y,t.z,t.w),e[0]=t.x,e[1]=t.y,e[2]=t.z,e[3]=t.w);else{if(Ve(e,t))return;i.uniform4uiv(this.addr,t),Ge(e,t)}}function bg(i,t,e){let n=this.cache,s=e.allocateTextureUnit();n[0]!==s&&(i.uniform1i(this.addr,s),n[0]=s);let r=this.type===i.SAMPLER_2D_SHADOW?su:iu;e.setTexture2D(t||r,s)}function Mg(i,t,e){let n=this.cache,s=e.allocateTextureUnit();n[0]!==s&&(i.uniform1i(this.addr,s),n[0]=s),e.setTexture3D(t||au,s)}function Sg(i,t,e){let n=this.cache,s=e.allocateTextureUnit();n[0]!==s&&(i.uniform1i(this.addr,s),n[0]=s),e.setTextureCube(t||ou,s)}function wg(i,t,e){let n=this.cache,s=e.allocateTextureUnit();n[0]!==s&&(i.uniform1i(this.addr,s),n[0]=s),e.setTexture2DArray(t||ru,s)}function Eg(i){switch(i){case 5126:return ag;case 35664:return og;case 35665:return lg;case 35666:return cg;case 35674:return hg;case 35675:return ug;case 35676:return dg;case 5124:case 35670:return fg;case 35667:case 35671:return pg;case 35668:case 35672:return mg;case 35669:case 35673:return gg;case 5125:return xg;case 36294:return _g;case 36295:return vg;case 36296:return yg;case 35678:case 36198:case 36298:case 36306:case 35682:return bg;case 35679:case 36299:case 36307:return Mg;case 35680:case 36300:case 36308:case 36293:return Sg;case 36289:case 36303:case 36311:case 36292:return wg}}function Tg(i,t){i.uniform1fv(this.addr,t)}function Ag(i,t){let e=zs(t,this.size,2);i.uniform2fv(this.addr,e)}function Cg(i,t){let e=zs(t,this.size,3);i.uniform3fv(this.addr,e)}function Rg(i,t){let e=zs(t,this.size,4);i.uniform4fv(this.addr,e)}function Pg(i,t){let e=zs(t,this.size,4);i.uniformMatrix2fv(this.addr,!1,e)}function Lg(i,t){let e=zs(t,this.size,9);i.uniformMatrix3fv(this.addr,!1,e)}function Ig(i,t){let e=zs(t,this.size,16);i.uniformMatrix4fv(this.addr,!1,e)}function Dg(i,t){i.uniform1iv(this.addr,t)}function Ug(i,t){i.uniform2iv(this.addr,t)}function Ng(i,t){i.uniform3iv(this.addr,t)}function Og(i,t){i.uniform4iv(this.addr,t)}function Fg(i,t){i.uniform1uiv(this.addr,t)}function Bg(i,t){i.uniform2uiv(this.addr,t)}function zg(i,t){i.uniform3uiv(this.addr,t)}function kg(i,t){i.uniform4uiv(this.addr,t)}function Hg(i,t,e){let n=this.cache,s=t.length,r=za(e,s);Ve(n,r)||(i.uniform1iv(this.addr,r),Ge(n,r));for(let o=0;o!==s;++o)e.setTexture2D(t[o]||iu,r[o])}function Vg(i,t,e){let n=this.cache,s=t.length,r=za(e,s);Ve(n,r)||(i.uniform1iv(this.addr,r),Ge(n,r));for(let o=0;o!==s;++o)e.setTexture3D(t[o]||au,r[o])}function Gg(i,t,e){let n=this.cache,s=t.length,r=za(e,s);Ve(n,r)||(i.uniform1iv(this.addr,r),Ge(n,r));for(let o=0;o!==s;++o)e.setTextureCube(t[o]||ou,r[o])}function Wg(i,t,e){let n=this.cache,s=t.length,r=za(e,s);Ve(n,r)||(i.uniform1iv(this.addr,r),Ge(n,r));for(let o=0;o!==s;++o)e.setTexture2DArray(t[o]||ru,r[o])}function Xg(i){switch(i){case 5126:return Tg;case 35664:return Ag;case 35665:return Cg;case 35666:return Rg;case 35674:return Pg;case 35675:return Lg;case 35676:return Ig;case 5124:case 35670:return Dg;case 35667:case 35671:return Ug;case 35668:case 35672:return Ng;case 35669:case 35673:return Og;case 5125:return Fg;case 36294:return Bg;case 36295:return zg;case 36296:return kg;case 35678:case 36198:case 36298:case 36306:case 35682:return Hg;case 35679:case 36299:case 36307:return Vg;case 35680:case 36300:case 36308:case 36293:return Gg;case 36289:case 36303:case 36311:case 36292:return Wg}}var Qo=class{constructor(t,e,n){this.id=t,this.addr=n,this.cache=[],this.type=e.type,this.setValue=Eg(e.type)}},tl=class{constructor(t,e,n){this.id=t,this.addr=n,this.cache=[],this.type=e.type,this.size=e.size,this.setValue=Xg(e.type)}},el=class{constructor(t){this.id=t,this.seq=[],this.map={}}setValue(t,e,n){let s=this.seq;for(let r=0,o=s.length;r!==o;++r){let a=s[r];a.setValue(t,e[a.id],n)}}},zo=/(\w+)(\])?(\[|\.)?/g;function yh(i,t){i.seq.push(t),i.map[t.id]=t}function Yg(i,t,e){let n=i.name,s=n.length;for(zo.lastIndex=0;;){let r=zo.exec(n),o=zo.lastIndex,a=r[1],l=r[2]==="]",c=r[3];if(l&&(a=a|0),c===void 0||c==="["&&o+2===s){yh(e,c===void 0?new Qo(a,i,t):new tl(a,i,t));break}else{let f=e.map[a];f===void 0&&(f=new el(a),yh(e,f)),e=f}}}var Cs=class{constructor(t,e){this.seq=[],this.map={};let n=t.getProgramParameter(e,t.ACTIVE_UNIFORMS);for(let s=0;s<n;++s){let r=t.getActiveUniform(e,s),o=t.getUniformLocation(e,r.name);Yg(r,o,this)}}setValue(t,e,n,s){let r=this.map[e];r!==void 0&&r.setValue(t,n,s)}setOptional(t,e,n){let s=e[n];s!==void 0&&this.setValue(t,n,s)}static upload(t,e,n,s){for(let r=0,o=e.length;r!==o;++r){let a=e[r],l=n[a.id];l.needsUpdate!==!1&&a.setValue(t,l.value,s)}}static seqWithValue(t,e){let n=[];for(let s=0,r=t.length;s!==r;++s){let o=t[s];o.id in e&&n.push(o)}return n}};function bh(i,t,e){let n=i.createShader(t);return i.shaderSource(n,e),i.compileShader(n),n}var qg=37297,Zg=0;function Jg(i,t){let e=i.split(`
`),n=[],s=Math.max(t-6,0),r=Math.min(t+6,e.length);for(let o=s;o<r;o++){let a=o+1;n.push(`${a===t?">":" "} ${a}: ${e[o]}`)}return n.join(`
`)}function jg(i){let t=fe.getPrimaries(fe.workingColorSpace),e=fe.getPrimaries(i),n;switch(t===e?n="":t===ua&&e===ha?n="LinearDisplayP3ToLinearSRGB":t===ha&&e===ua&&(n="LinearSRGBToLinearDisplayP3"),i){case ri:case Ba:return[n,"LinearTransferOETF"];case Ce:case Pl:return[n,"sRGBTransferOETF"];default:return console.warn("THREE.WebGLProgram: Unsupported color space:",i),[n,"LinearTransferOETF"]}}function Mh(i,t,e){let n=i.getShaderParameter(t,i.COMPILE_STATUS),s=i.getShaderInfoLog(t).trim();if(n&&s==="")return"";let r=/ERROR: 0:(\d+)/.exec(s);if(r){let o=parseInt(r[1]);return e.toUpperCase()+`

`+s+`

`+Jg(i.getShaderSource(t),o)}else return s}function $g(i,t){let e=jg(t);return`vec4 ${i}( vec4 value ) { return ${e[0]}( ${e[1]}( value ) ); }`}function Kg(i,t){let e;switch(t){case El:e="Linear";break;case Tl:e="Reinhard";break;case Al:e="OptimizedCineon";break;case Sr:e="ACESFilmic";break;case Cl:e="AgX";break;case ld:e="Custom";break;default:console.warn("THREE.WebGLProgram: Unsupported toneMapping:",t),e="Linear"}return"vec3 "+i+"( vec3 color ) { return "+e+"ToneMapping( color ); }"}function Qg(i){return[i.extensionDerivatives||i.envMapCubeUVHeight||i.bumpMap||i.normalMapTangentSpace||i.clearcoatNormalMap||i.flatShading||i.shaderID==="physical"?"#extension GL_OES_standard_derivatives : enable":"",(i.extensionFragDepth||i.logarithmicDepthBuffer)&&i.rendererExtensionFragDepth?"#extension GL_EXT_frag_depth : enable":"",i.extensionDrawBuffers&&i.rendererExtensionDrawBuffers?"#extension GL_EXT_draw_buffers : require":"",(i.extensionShaderTextureLOD||i.envMap||i.transmission)&&i.rendererExtensionShaderTextureLod?"#extension GL_EXT_shader_texture_lod : enable":""].filter(Ts).join(`
`)}function t0(i){return[i.extensionClipCullDistance?"#extension GL_ANGLE_clip_cull_distance : require":""].filter(Ts).join(`
`)}function e0(i){let t=[];for(let e in i){let n=i[e];n!==!1&&t.push("#define "+e+" "+n)}return t.join(`
`)}function n0(i,t){let e={},n=i.getProgramParameter(t,i.ACTIVE_ATTRIBUTES);for(let s=0;s<n;s++){let r=i.getActiveAttrib(t,s),o=r.name,a=1;r.type===i.FLOAT_MAT2&&(a=2),r.type===i.FLOAT_MAT3&&(a=3),r.type===i.FLOAT_MAT4&&(a=4),e[o]={type:r.type,location:i.getAttribLocation(t,o),locationSize:a}}return e}function Ts(i){return i!==""}function Sh(i,t){let e=t.numSpotLightShadows+t.numSpotLightMaps-t.numSpotLightShadowsWithMaps;return i.replace(/NUM_DIR_LIGHTS/g,t.numDirLights).replace(/NUM_SPOT_LIGHTS/g,t.numSpotLights).replace(/NUM_SPOT_LIGHT_MAPS/g,t.numSpotLightMaps).replace(/NUM_SPOT_LIGHT_COORDS/g,e).replace(/NUM_RECT_AREA_LIGHTS/g,t.numRectAreaLights).replace(/NUM_POINT_LIGHTS/g,t.numPointLights).replace(/NUM_HEMI_LIGHTS/g,t.numHemiLights).replace(/NUM_DIR_LIGHT_SHADOWS/g,t.numDirLightShadows).replace(/NUM_SPOT_LIGHT_SHADOWS_WITH_MAPS/g,t.numSpotLightShadowsWithMaps).replace(/NUM_SPOT_LIGHT_SHADOWS/g,t.numSpotLightShadows).replace(/NUM_POINT_LIGHT_SHADOWS/g,t.numPointLightShadows)}function wh(i,t){return i.replace(/NUM_CLIPPING_PLANES/g,t.numClippingPlanes).replace(/UNION_CLIPPING_PLANES/g,t.numClippingPlanes-t.numClipIntersection)}var i0=/^[ \t]*#include +<([\w\d./]+)>/gm;function nl(i){return i.replace(i0,r0)}var s0=new Map([["encodings_fragment","colorspace_fragment"],["encodings_pars_fragment","colorspace_pars_fragment"],["output_fragment","opaque_fragment"]]);function r0(i,t){let e=ne[t];if(e===void 0){let n=s0.get(t);if(n!==void 0)e=ne[n],console.warn('THREE.WebGLRenderer: Shader chunk "%s" has been deprecated. Use "%s" instead.',t,n);else throw new Error("Can not resolve #include <"+t+">")}return nl(e)}var a0=/#pragma unroll_loop_start\s+for\s*\(\s*int\s+i\s*=\s*(\d+)\s*;\s*i\s*<\s*(\d+)\s*;\s*i\s*\+\+\s*\)\s*{([\s\S]+?)}\s+#pragma unroll_loop_end/g;function Eh(i){return i.replace(a0,o0)}function o0(i,t,e,n){let s="";for(let r=parseInt(t);r<parseInt(e);r++)s+=n.replace(/\[\s*i\s*\]/g,"[ "+r+" ]").replace(/UNROLLED_LOOP_INDEX/g,r);return s}function Th(i){let t="precision "+i.precision+` float;
precision `+i.precision+" int;";return i.precision==="highp"?t+=`
#define HIGH_PRECISION`:i.precision==="mediump"?t+=`
#define MEDIUM_PRECISION`:i.precision==="lowp"&&(t+=`
#define LOW_PRECISION`),t}function l0(i){let t="SHADOWMAP_TYPE_BASIC";return i.shadowMapType===zh?t="SHADOWMAP_TYPE_PCF":i.shadowMapType===wl?t="SHADOWMAP_TYPE_PCF_SOFT":i.shadowMapType===ni&&(t="SHADOWMAP_TYPE_VSM"),t}function c0(i){let t="ENVMAP_TYPE_CUBE";if(i.envMap)switch(i.envMapMode){case Ps:case Ls:t="ENVMAP_TYPE_CUBE";break;case Fa:t="ENVMAP_TYPE_CUBE_UV";break}return t}function h0(i){let t="ENVMAP_MODE_REFLECTION";return i.envMap&&i.envMapMode===Ls&&(t="ENVMAP_MODE_REFRACTION"),t}function u0(i){let t="ENVMAP_BLENDING_NONE";if(i.envMap)switch(i.combine){case kh:t="ENVMAP_BLENDING_MULTIPLY";break;case ad:t="ENVMAP_BLENDING_MIX";break;case od:t="ENVMAP_BLENDING_ADD";break}return t}function d0(i){let t=i.envMapCubeUVHeight;if(t===null)return null;let e=Math.log2(t)-2,n=1/t;return{texelWidth:1/(3*Math.max(Math.pow(2,e),112)),texelHeight:n,maxMip:e}}function f0(i,t,e,n){let s=i.getContext(),r=e.defines,o=e.vertexShader,a=e.fragmentShader,l=l0(e),c=c0(e),u=h0(e),f=u0(e),p=d0(e),x=e.isWebGL2?"":Qg(e),y=t0(e),M=e0(r),g=s.createProgram(),d,C,E=e.glslVersion?"#version "+e.glslVersion+`
`:"";e.isRawShaderMaterial?(d=["#define SHADER_TYPE "+e.shaderType,"#define SHADER_NAME "+e.shaderName,M].filter(Ts).join(`
`),d.length>0&&(d+=`
`),C=[x,"#define SHADER_TYPE "+e.shaderType,"#define SHADER_NAME "+e.shaderName,M].filter(Ts).join(`
`),C.length>0&&(C+=`
`)):(d=[Th(e),"#define SHADER_TYPE "+e.shaderType,"#define SHADER_NAME "+e.shaderName,M,e.extensionClipCullDistance?"#define USE_CLIP_DISTANCE":"",e.batching?"#define USE_BATCHING":"",e.instancing?"#define USE_INSTANCING":"",e.instancingColor?"#define USE_INSTANCING_COLOR":"",e.useFog&&e.fog?"#define USE_FOG":"",e.useFog&&e.fogExp2?"#define FOG_EXP2":"",e.map?"#define USE_MAP":"",e.envMap?"#define USE_ENVMAP":"",e.envMap?"#define "+u:"",e.lightMap?"#define USE_LIGHTMAP":"",e.aoMap?"#define USE_AOMAP":"",e.bumpMap?"#define USE_BUMPMAP":"",e.normalMap?"#define USE_NORMALMAP":"",e.normalMapObjectSpace?"#define USE_NORMALMAP_OBJECTSPACE":"",e.normalMapTangentSpace?"#define USE_NORMALMAP_TANGENTSPACE":"",e.displacementMap?"#define USE_DISPLACEMENTMAP":"",e.emissiveMap?"#define USE_EMISSIVEMAP":"",e.anisotropy?"#define USE_ANISOTROPY":"",e.anisotropyMap?"#define USE_ANISOTROPYMAP":"",e.clearcoatMap?"#define USE_CLEARCOATMAP":"",e.clearcoatRoughnessMap?"#define USE_CLEARCOAT_ROUGHNESSMAP":"",e.clearcoatNormalMap?"#define USE_CLEARCOAT_NORMALMAP":"",e.iridescenceMap?"#define USE_IRIDESCENCEMAP":"",e.iridescenceThicknessMap?"#define USE_IRIDESCENCE_THICKNESSMAP":"",e.specularMap?"#define USE_SPECULARMAP":"",e.specularColorMap?"#define USE_SPECULAR_COLORMAP":"",e.specularIntensityMap?"#define USE_SPECULAR_INTENSITYMAP":"",e.roughnessMap?"#define USE_ROUGHNESSMAP":"",e.metalnessMap?"#define USE_METALNESSMAP":"",e.alphaMap?"#define USE_ALPHAMAP":"",e.alphaHash?"#define USE_ALPHAHASH":"",e.transmission?"#define USE_TRANSMISSION":"",e.transmissionMap?"#define USE_TRANSMISSIONMAP":"",e.thicknessMap?"#define USE_THICKNESSMAP":"",e.sheenColorMap?"#define USE_SHEEN_COLORMAP":"",e.sheenRoughnessMap?"#define USE_SHEEN_ROUGHNESSMAP":"",e.mapUv?"#define MAP_UV "+e.mapUv:"",e.alphaMapUv?"#define ALPHAMAP_UV "+e.alphaMapUv:"",e.lightMapUv?"#define LIGHTMAP_UV "+e.lightMapUv:"",e.aoMapUv?"#define AOMAP_UV "+e.aoMapUv:"",e.emissiveMapUv?"#define EMISSIVEMAP_UV "+e.emissiveMapUv:"",e.bumpMapUv?"#define BUMPMAP_UV "+e.bumpMapUv:"",e.normalMapUv?"#define NORMALMAP_UV "+e.normalMapUv:"",e.displacementMapUv?"#define DISPLACEMENTMAP_UV "+e.displacementMapUv:"",e.metalnessMapUv?"#define METALNESSMAP_UV "+e.metalnessMapUv:"",e.roughnessMapUv?"#define ROUGHNESSMAP_UV "+e.roughnessMapUv:"",e.anisotropyMapUv?"#define ANISOTROPYMAP_UV "+e.anisotropyMapUv:"",e.clearcoatMapUv?"#define CLEARCOATMAP_UV "+e.clearcoatMapUv:"",e.clearcoatNormalMapUv?"#define CLEARCOAT_NORMALMAP_UV "+e.clearcoatNormalMapUv:"",e.clearcoatRoughnessMapUv?"#define CLEARCOAT_ROUGHNESSMAP_UV "+e.clearcoatRoughnessMapUv:"",e.iridescenceMapUv?"#define IRIDESCENCEMAP_UV "+e.iridescenceMapUv:"",e.iridescenceThicknessMapUv?"#define IRIDESCENCE_THICKNESSMAP_UV "+e.iridescenceThicknessMapUv:"",e.sheenColorMapUv?"#define SHEEN_COLORMAP_UV "+e.sheenColorMapUv:"",e.sheenRoughnessMapUv?"#define SHEEN_ROUGHNESSMAP_UV "+e.sheenRoughnessMapUv:"",e.specularMapUv?"#define SPECULARMAP_UV "+e.specularMapUv:"",e.specularColorMapUv?"#define SPECULAR_COLORMAP_UV "+e.specularColorMapUv:"",e.specularIntensityMapUv?"#define SPECULAR_INTENSITYMAP_UV "+e.specularIntensityMapUv:"",e.transmissionMapUv?"#define TRANSMISSIONMAP_UV "+e.transmissionMapUv:"",e.thicknessMapUv?"#define THICKNESSMAP_UV "+e.thicknessMapUv:"",e.vertexTangents&&e.flatShading===!1?"#define USE_TANGENT":"",e.vertexColors?"#define USE_COLOR":"",e.vertexAlphas?"#define USE_COLOR_ALPHA":"",e.vertexUv1s?"#define USE_UV1":"",e.vertexUv2s?"#define USE_UV2":"",e.vertexUv3s?"#define USE_UV3":"",e.pointsUvs?"#define USE_POINTS_UV":"",e.flatShading?"#define FLAT_SHADED":"",e.skinning?"#define USE_SKINNING":"",e.morphTargets?"#define USE_MORPHTARGETS":"",e.morphNormals&&e.flatShading===!1?"#define USE_MORPHNORMALS":"",e.morphColors&&e.isWebGL2?"#define USE_MORPHCOLORS":"",e.morphTargetsCount>0&&e.isWebGL2?"#define MORPHTARGETS_TEXTURE":"",e.morphTargetsCount>0&&e.isWebGL2?"#define MORPHTARGETS_TEXTURE_STRIDE "+e.morphTextureStride:"",e.morphTargetsCount>0&&e.isWebGL2?"#define MORPHTARGETS_COUNT "+e.morphTargetsCount:"",e.doubleSided?"#define DOUBLE_SIDED":"",e.flipSided?"#define FLIP_SIDED":"",e.shadowMapEnabled?"#define USE_SHADOWMAP":"",e.shadowMapEnabled?"#define "+l:"",e.sizeAttenuation?"#define USE_SIZEATTENUATION":"",e.numLightProbes>0?"#define USE_LIGHT_PROBES":"",e.useLegacyLights?"#define LEGACY_LIGHTS":"",e.logarithmicDepthBuffer?"#define USE_LOGDEPTHBUF":"",e.logarithmicDepthBuffer&&e.rendererExtensionFragDepth?"#define USE_LOGDEPTHBUF_EXT":"","uniform mat4 modelMatrix;","uniform mat4 modelViewMatrix;","uniform mat4 projectionMatrix;","uniform mat4 viewMatrix;","uniform mat3 normalMatrix;","uniform vec3 cameraPosition;","uniform bool isOrthographic;","#ifdef USE_INSTANCING","	attribute mat4 instanceMatrix;","#endif","#ifdef USE_INSTANCING_COLOR","	attribute vec3 instanceColor;","#endif","attribute vec3 position;","attribute vec3 normal;","attribute vec2 uv;","#ifdef USE_UV1","	attribute vec2 uv1;","#endif","#ifdef USE_UV2","	attribute vec2 uv2;","#endif","#ifdef USE_UV3","	attribute vec2 uv3;","#endif","#ifdef USE_TANGENT","	attribute vec4 tangent;","#endif","#if defined( USE_COLOR_ALPHA )","	attribute vec4 color;","#elif defined( USE_COLOR )","	attribute vec3 color;","#endif","#if ( defined( USE_MORPHTARGETS ) && ! defined( MORPHTARGETS_TEXTURE ) )","	attribute vec3 morphTarget0;","	attribute vec3 morphTarget1;","	attribute vec3 morphTarget2;","	attribute vec3 morphTarget3;","	#ifdef USE_MORPHNORMALS","		attribute vec3 morphNormal0;","		attribute vec3 morphNormal1;","		attribute vec3 morphNormal2;","		attribute vec3 morphNormal3;","	#else","		attribute vec3 morphTarget4;","		attribute vec3 morphTarget5;","		attribute vec3 morphTarget6;","		attribute vec3 morphTarget7;","	#endif","#endif","#ifdef USE_SKINNING","	attribute vec4 skinIndex;","	attribute vec4 skinWeight;","#endif",`
`].filter(Ts).join(`
`),C=[x,Th(e),"#define SHADER_TYPE "+e.shaderType,"#define SHADER_NAME "+e.shaderName,M,e.useFog&&e.fog?"#define USE_FOG":"",e.useFog&&e.fogExp2?"#define FOG_EXP2":"",e.map?"#define USE_MAP":"",e.matcap?"#define USE_MATCAP":"",e.envMap?"#define USE_ENVMAP":"",e.envMap?"#define "+c:"",e.envMap?"#define "+u:"",e.envMap?"#define "+f:"",p?"#define CUBEUV_TEXEL_WIDTH "+p.texelWidth:"",p?"#define CUBEUV_TEXEL_HEIGHT "+p.texelHeight:"",p?"#define CUBEUV_MAX_MIP "+p.maxMip+".0":"",e.lightMap?"#define USE_LIGHTMAP":"",e.aoMap?"#define USE_AOMAP":"",e.bumpMap?"#define USE_BUMPMAP":"",e.normalMap?"#define USE_NORMALMAP":"",e.normalMapObjectSpace?"#define USE_NORMALMAP_OBJECTSPACE":"",e.normalMapTangentSpace?"#define USE_NORMALMAP_TANGENTSPACE":"",e.emissiveMap?"#define USE_EMISSIVEMAP":"",e.anisotropy?"#define USE_ANISOTROPY":"",e.anisotropyMap?"#define USE_ANISOTROPYMAP":"",e.clearcoat?"#define USE_CLEARCOAT":"",e.clearcoatMap?"#define USE_CLEARCOATMAP":"",e.clearcoatRoughnessMap?"#define USE_CLEARCOAT_ROUGHNESSMAP":"",e.clearcoatNormalMap?"#define USE_CLEARCOAT_NORMALMAP":"",e.iridescence?"#define USE_IRIDESCENCE":"",e.iridescenceMap?"#define USE_IRIDESCENCEMAP":"",e.iridescenceThicknessMap?"#define USE_IRIDESCENCE_THICKNESSMAP":"",e.specularMap?"#define USE_SPECULARMAP":"",e.specularColorMap?"#define USE_SPECULAR_COLORMAP":"",e.specularIntensityMap?"#define USE_SPECULAR_INTENSITYMAP":"",e.roughnessMap?"#define USE_ROUGHNESSMAP":"",e.metalnessMap?"#define USE_METALNESSMAP":"",e.alphaMap?"#define USE_ALPHAMAP":"",e.alphaTest?"#define USE_ALPHATEST":"",e.alphaHash?"#define USE_ALPHAHASH":"",e.sheen?"#define USE_SHEEN":"",e.sheenColorMap?"#define USE_SHEEN_COLORMAP":"",e.sheenRoughnessMap?"#define USE_SHEEN_ROUGHNESSMAP":"",e.transmission?"#define USE_TRANSMISSION":"",e.transmissionMap?"#define USE_TRANSMISSIONMAP":"",e.thicknessMap?"#define USE_THICKNESSMAP":"",e.vertexTangents&&e.flatShading===!1?"#define USE_TANGENT":"",e.vertexColors||e.instancingColor?"#define USE_COLOR":"",e.vertexAlphas?"#define USE_COLOR_ALPHA":"",e.vertexUv1s?"#define USE_UV1":"",e.vertexUv2s?"#define USE_UV2":"",e.vertexUv3s?"#define USE_UV3":"",e.pointsUvs?"#define USE_POINTS_UV":"",e.gradientMap?"#define USE_GRADIENTMAP":"",e.flatShading?"#define FLAT_SHADED":"",e.doubleSided?"#define DOUBLE_SIDED":"",e.flipSided?"#define FLIP_SIDED":"",e.shadowMapEnabled?"#define USE_SHADOWMAP":"",e.shadowMapEnabled?"#define "+l:"",e.premultipliedAlpha?"#define PREMULTIPLIED_ALPHA":"",e.numLightProbes>0?"#define USE_LIGHT_PROBES":"",e.useLegacyLights?"#define LEGACY_LIGHTS":"",e.decodeVideoTexture?"#define DECODE_VIDEO_TEXTURE":"",e.logarithmicDepthBuffer?"#define USE_LOGDEPTHBUF":"",e.logarithmicDepthBuffer&&e.rendererExtensionFragDepth?"#define USE_LOGDEPTHBUF_EXT":"","uniform mat4 viewMatrix;","uniform vec3 cameraPosition;","uniform bool isOrthographic;",e.toneMapping!==yi?"#define TONE_MAPPING":"",e.toneMapping!==yi?ne.tonemapping_pars_fragment:"",e.toneMapping!==yi?Kg("toneMapping",e.toneMapping):"",e.dithering?"#define DITHERING":"",e.opaque?"#define OPAQUE":"",ne.colorspace_pars_fragment,$g("linearToOutputTexel",e.outputColorSpace),e.useDepthPacking?"#define DEPTH_PACKING "+e.depthPacking:"",`
`].filter(Ts).join(`
`)),o=nl(o),o=Sh(o,e),o=wh(o,e),a=nl(a),a=Sh(a,e),a=wh(a,e),o=Eh(o),a=Eh(a),e.isWebGL2&&e.isRawShaderMaterial!==!0&&(E=`#version 300 es
`,d=[y,"precision mediump sampler2DArray;","#define attribute in","#define varying out","#define texture2D texture"].join(`
`)+`
`+d,C=["precision mediump sampler2DArray;","#define varying in",e.glslVersion===Xc?"":"layout(location = 0) out highp vec4 pc_fragColor;",e.glslVersion===Xc?"":"#define gl_FragColor pc_fragColor","#define gl_FragDepthEXT gl_FragDepth","#define texture2D texture","#define textureCube texture","#define texture2DProj textureProj","#define texture2DLodEXT textureLod","#define texture2DProjLodEXT textureProjLod","#define textureCubeLodEXT textureLod","#define texture2DGradEXT textureGrad","#define texture2DProjGradEXT textureProjGrad","#define textureCubeGradEXT textureGrad"].join(`
`)+`
`+C);let D=E+d+o,z=E+C+a,U=bh(s,s.VERTEX_SHADER,D),L=bh(s,s.FRAGMENT_SHADER,z);s.attachShader(g,U),s.attachShader(g,L),e.index0AttributeName!==void 0?s.bindAttribLocation(g,0,e.index0AttributeName):e.morphTargets===!0&&s.bindAttribLocation(g,0,"position"),s.linkProgram(g);function Q(nt){if(i.debug.checkShaderErrors){let ft=s.getProgramInfoLog(g).trim(),I=s.getShaderInfoLog(U).trim(),k=s.getShaderInfoLog(L).trim(),$=!0,Z=!0;if(s.getProgramParameter(g,s.LINK_STATUS)===!1)if($=!1,typeof i.debug.onShaderError=="function")i.debug.onShaderError(s,g,U,L);else{let j=Mh(s,U,"vertex"),K=Mh(s,L,"fragment");console.error("THREE.WebGLProgram: Shader Error "+s.getError()+" - VALIDATE_STATUS "+s.getProgramParameter(g,s.VALIDATE_STATUS)+`

Program Info Log: `+ft+`
`+j+`
`+K)}else ft!==""?console.warn("THREE.WebGLProgram: Program Info Log:",ft):(I===""||k==="")&&(Z=!1);Z&&(nt.diagnostics={runnable:$,programLog:ft,vertexShader:{log:I,prefix:d},fragmentShader:{log:k,prefix:C}})}s.deleteShader(U),s.deleteShader(L),S=new Cs(s,g),R=n0(s,g)}let S;this.getUniforms=function(){return S===void 0&&Q(this),S};let R;this.getAttributes=function(){return R===void 0&&Q(this),R};let V=e.rendererExtensionParallelShaderCompile===!1;return this.isReady=function(){return V===!1&&(V=s.getProgramParameter(g,qg)),V},this.destroy=function(){n.releaseStatesOfProgram(this),s.deleteProgram(g),this.program=void 0},this.type=e.shaderType,this.name=e.shaderName,this.id=Zg++,this.cacheKey=t,this.usedTimes=1,this.program=g,this.vertexShader=U,this.fragmentShader=L,this}var p0=0,il=class{constructor(){this.shaderCache=new Map,this.materialCache=new Map}update(t){let e=t.vertexShader,n=t.fragmentShader,s=this._getShaderStage(e),r=this._getShaderStage(n),o=this._getShaderCacheForMaterial(t);return o.has(s)===!1&&(o.add(s),s.usedTimes++),o.has(r)===!1&&(o.add(r),r.usedTimes++),this}remove(t){let e=this.materialCache.get(t);for(let n of e)n.usedTimes--,n.usedTimes===0&&this.shaderCache.delete(n.code);return this.materialCache.delete(t),this}getVertexShaderID(t){return this._getShaderStage(t.vertexShader).id}getFragmentShaderID(t){return this._getShaderStage(t.fragmentShader).id}dispose(){this.shaderCache.clear(),this.materialCache.clear()}_getShaderCacheForMaterial(t){let e=this.materialCache,n=e.get(t);return n===void 0&&(n=new Set,e.set(t,n)),n}_getShaderStage(t){let e=this.shaderCache,n=e.get(t);return n===void 0&&(n=new sl(t),e.set(t,n)),n}},sl=class{constructor(t){this.id=p0++,this.code=t,this.usedTimes=0}};function m0(i,t,e,n,s,r,o){let a=new fr,l=new il,c=[],u=s.isWebGL2,f=s.logarithmicDepthBuffer,p=s.vertexTextures,x=s.precision,y={MeshDepthMaterial:"depth",MeshDistanceMaterial:"distanceRGBA",MeshNormalMaterial:"normal",MeshBasicMaterial:"basic",MeshLambertMaterial:"lambert",MeshPhongMaterial:"phong",MeshToonMaterial:"toon",MeshStandardMaterial:"physical",MeshPhysicalMaterial:"physical",MeshMatcapMaterial:"matcap",LineBasicMaterial:"basic",LineDashedMaterial:"dashed",PointsMaterial:"points",ShadowMaterial:"shadow",SpriteMaterial:"sprite"};function M(S){return S===0?"uv":`uv${S}`}function g(S,R,V,nt,ft){let I=nt.fog,k=ft.geometry,$=S.isMeshStandardMaterial?nt.environment:null,Z=(S.isMeshStandardMaterial?e:t).get(S.envMap||$),j=Z&&Z.mapping===Fa?Z.image.height:null,K=y[S.type];S.precision!==null&&(x=s.getMaxPrecision(S.precision),x!==S.precision&&console.warn("THREE.WebGLProgram.getParameters:",S.precision,"not supported, using",x,"instead."));let st=k.morphAttributes.position||k.morphAttributes.normal||k.morphAttributes.color,it=st!==void 0?st.length:0,vt=0;k.morphAttributes.position!==void 0&&(vt=1),k.morphAttributes.normal!==void 0&&(vt=2),k.morphAttributes.color!==void 0&&(vt=3);let q,ct,yt,It;if(K){let ge=Xn[K];q=ge.vertexShader,ct=ge.fragmentShader}else q=S.vertexShader,ct=S.fragmentShader,l.update(S),yt=l.getVertexShaderID(S),It=l.getFragmentShaderID(S);let Ot=i.getRenderTarget(),Pt=ft.isInstancedMesh===!0,Dt=ft.isBatchedMesh===!0,At=!!S.map,kt=!!S.matcap,G=!!Z,Re=!!S.aoMap,Ut=!!S.lightMap,Gt=!!S.bumpMap,Rt=!!S.normalMap,me=!!S.displacementMap,$t=!!S.emissiveMap,A=!!S.metalnessMap,b=!!S.roughnessMap,W=S.anisotropy>0,dt=S.clearcoat>0,ht=S.iridescence>0,rt=S.sheen>0,Tt=S.transmission>0,St=W&&!!S.anisotropyMap,ut=dt&&!!S.clearcoatMap,Ft=dt&&!!S.clearcoatNormalMap,Yt=dt&&!!S.clearcoatRoughnessMap,lt=ht&&!!S.iridescenceMap,ae=ht&&!!S.iridescenceThicknessMap,P=rt&&!!S.sheenColorMap,at=rt&&!!S.sheenRoughnessMap,mt=!!S.specularMap,pt=!!S.specularColorMap,Nt=!!S.specularIntensityMap,ee=Tt&&!!S.transmissionMap,ie=Tt&&!!S.thicknessMap,Qt=!!S.gradientMap,_t=!!S.alphaMap,O=S.alphaTest>0,gt=!!S.alphaHash,xt=!!S.extensions,Ht=!!k.attributes.uv1,Bt=!!k.attributes.uv2,he=!!k.attributes.uv3,se=yi;return S.toneMapped&&(Ot===null||Ot.isXRRenderTarget===!0)&&(se=i.toneMapping),{isWebGL2:u,shaderID:K,shaderType:S.type,shaderName:S.name,vertexShader:q,fragmentShader:ct,defines:S.defines,customVertexShaderID:yt,customFragmentShaderID:It,isRawShaderMaterial:S.isRawShaderMaterial===!0,glslVersion:S.glslVersion,precision:x,batching:Dt,instancing:Pt,instancingColor:Pt&&ft.instanceColor!==null,supportsVertexTextures:p,outputColorSpace:Ot===null?i.outputColorSpace:Ot.isXRRenderTarget===!0?Ot.texture.colorSpace:ri,map:At,matcap:kt,envMap:G,envMapMode:G&&Z.mapping,envMapCubeUVHeight:j,aoMap:Re,lightMap:Ut,bumpMap:Gt,normalMap:Rt,displacementMap:p&&me,emissiveMap:$t,normalMapObjectSpace:Rt&&S.normalMapType===yd,normalMapTangentSpace:Rt&&S.normalMapType===jh,metalnessMap:A,roughnessMap:b,anisotropy:W,anisotropyMap:St,clearcoat:dt,clearcoatMap:ut,clearcoatNormalMap:Ft,clearcoatRoughnessMap:Yt,iridescence:ht,iridescenceMap:lt,iridescenceThicknessMap:ae,sheen:rt,sheenColorMap:P,sheenRoughnessMap:at,specularMap:mt,specularColorMap:pt,specularIntensityMap:Nt,transmission:Tt,transmissionMap:ee,thicknessMap:ie,gradientMap:Qt,opaque:S.transparent===!1&&S.blending===si,alphaMap:_t,alphaTest:O,alphaHash:gt,combine:S.combine,mapUv:At&&M(S.map.channel),aoMapUv:Re&&M(S.aoMap.channel),lightMapUv:Ut&&M(S.lightMap.channel),bumpMapUv:Gt&&M(S.bumpMap.channel),normalMapUv:Rt&&M(S.normalMap.channel),displacementMapUv:me&&M(S.displacementMap.channel),emissiveMapUv:$t&&M(S.emissiveMap.channel),metalnessMapUv:A&&M(S.metalnessMap.channel),roughnessMapUv:b&&M(S.roughnessMap.channel),anisotropyMapUv:St&&M(S.anisotropyMap.channel),clearcoatMapUv:ut&&M(S.clearcoatMap.channel),clearcoatNormalMapUv:Ft&&M(S.clearcoatNormalMap.channel),clearcoatRoughnessMapUv:Yt&&M(S.clearcoatRoughnessMap.channel),iridescenceMapUv:lt&&M(S.iridescenceMap.channel),iridescenceThicknessMapUv:ae&&M(S.iridescenceThicknessMap.channel),sheenColorMapUv:P&&M(S.sheenColorMap.channel),sheenRoughnessMapUv:at&&M(S.sheenRoughnessMap.channel),specularMapUv:mt&&M(S.specularMap.channel),specularColorMapUv:pt&&M(S.specularColorMap.channel),specularIntensityMapUv:Nt&&M(S.specularIntensityMap.channel),transmissionMapUv:ee&&M(S.transmissionMap.channel),thicknessMapUv:ie&&M(S.thicknessMap.channel),alphaMapUv:_t&&M(S.alphaMap.channel),vertexTangents:!!k.attributes.tangent&&(Rt||W),vertexColors:S.vertexColors,vertexAlphas:S.vertexColors===!0&&!!k.attributes.color&&k.attributes.color.itemSize===4,vertexUv1s:Ht,vertexUv2s:Bt,vertexUv3s:he,pointsUvs:ft.isPoints===!0&&!!k.attributes.uv&&(At||_t),fog:!!I,useFog:S.fog===!0,fogExp2:I&&I.isFogExp2,flatShading:S.flatShading===!0,sizeAttenuation:S.sizeAttenuation===!0,logarithmicDepthBuffer:f,skinning:ft.isSkinnedMesh===!0,morphTargets:k.morphAttributes.position!==void 0,morphNormals:k.morphAttributes.normal!==void 0,morphColors:k.morphAttributes.color!==void 0,morphTargetsCount:it,morphTextureStride:vt,numDirLights:R.directional.length,numPointLights:R.point.length,numSpotLights:R.spot.length,numSpotLightMaps:R.spotLightMap.length,numRectAreaLights:R.rectArea.length,numHemiLights:R.hemi.length,numDirLightShadows:R.directionalShadowMap.length,numPointLightShadows:R.pointShadowMap.length,numSpotLightShadows:R.spotShadowMap.length,numSpotLightShadowsWithMaps:R.numSpotLightShadowsWithMaps,numLightProbes:R.numLightProbes,numClippingPlanes:o.numPlanes,numClipIntersection:o.numIntersection,dithering:S.dithering,shadowMapEnabled:i.shadowMap.enabled&&V.length>0,shadowMapType:i.shadowMap.type,toneMapping:se,useLegacyLights:i._useLegacyLights,decodeVideoTexture:At&&S.map.isVideoTexture===!0&&fe.getTransfer(S.map.colorSpace)===xe,premultipliedAlpha:S.premultipliedAlpha,doubleSided:S.side===Dn,flipSided:S.side===sn,useDepthPacking:S.depthPacking>=0,depthPacking:S.depthPacking||0,index0AttributeName:S.index0AttributeName,extensionDerivatives:xt&&S.extensions.derivatives===!0,extensionFragDepth:xt&&S.extensions.fragDepth===!0,extensionDrawBuffers:xt&&S.extensions.drawBuffers===!0,extensionShaderTextureLOD:xt&&S.extensions.shaderTextureLOD===!0,extensionClipCullDistance:xt&&S.extensions.clipCullDistance&&n.has("WEBGL_clip_cull_distance"),rendererExtensionFragDepth:u||n.has("EXT_frag_depth"),rendererExtensionDrawBuffers:u||n.has("WEBGL_draw_buffers"),rendererExtensionShaderTextureLod:u||n.has("EXT_shader_texture_lod"),rendererExtensionParallelShaderCompile:n.has("KHR_parallel_shader_compile"),customProgramCacheKey:S.customProgramCacheKey()}}function d(S){let R=[];if(S.shaderID?R.push(S.shaderID):(R.push(S.customVertexShaderID),R.push(S.customFragmentShaderID)),S.defines!==void 0)for(let V in S.defines)R.push(V),R.push(S.defines[V]);return S.isRawShaderMaterial===!1&&(C(R,S),E(R,S),R.push(i.outputColorSpace)),R.push(S.customProgramCacheKey),R.join()}function C(S,R){S.push(R.precision),S.push(R.outputColorSpace),S.push(R.envMapMode),S.push(R.envMapCubeUVHeight),S.push(R.mapUv),S.push(R.alphaMapUv),S.push(R.lightMapUv),S.push(R.aoMapUv),S.push(R.bumpMapUv),S.push(R.normalMapUv),S.push(R.displacementMapUv),S.push(R.emissiveMapUv),S.push(R.metalnessMapUv),S.push(R.roughnessMapUv),S.push(R.anisotropyMapUv),S.push(R.clearcoatMapUv),S.push(R.clearcoatNormalMapUv),S.push(R.clearcoatRoughnessMapUv),S.push(R.iridescenceMapUv),S.push(R.iridescenceThicknessMapUv),S.push(R.sheenColorMapUv),S.push(R.sheenRoughnessMapUv),S.push(R.specularMapUv),S.push(R.specularColorMapUv),S.push(R.specularIntensityMapUv),S.push(R.transmissionMapUv),S.push(R.thicknessMapUv),S.push(R.combine),S.push(R.fogExp2),S.push(R.sizeAttenuation),S.push(R.morphTargetsCount),S.push(R.morphAttributeCount),S.push(R.numDirLights),S.push(R.numPointLights),S.push(R.numSpotLights),S.push(R.numSpotLightMaps),S.push(R.numHemiLights),S.push(R.numRectAreaLights),S.push(R.numDirLightShadows),S.push(R.numPointLightShadows),S.push(R.numSpotLightShadows),S.push(R.numSpotLightShadowsWithMaps),S.push(R.numLightProbes),S.push(R.shadowMapType),S.push(R.toneMapping),S.push(R.numClippingPlanes),S.push(R.numClipIntersection),S.push(R.depthPacking)}function E(S,R){a.disableAll(),R.isWebGL2&&a.enable(0),R.supportsVertexTextures&&a.enable(1),R.instancing&&a.enable(2),R.instancingColor&&a.enable(3),R.matcap&&a.enable(4),R.envMap&&a.enable(5),R.normalMapObjectSpace&&a.enable(6),R.normalMapTangentSpace&&a.enable(7),R.clearcoat&&a.enable(8),R.iridescence&&a.enable(9),R.alphaTest&&a.enable(10),R.vertexColors&&a.enable(11),R.vertexAlphas&&a.enable(12),R.vertexUv1s&&a.enable(13),R.vertexUv2s&&a.enable(14),R.vertexUv3s&&a.enable(15),R.vertexTangents&&a.enable(16),R.anisotropy&&a.enable(17),R.alphaHash&&a.enable(18),R.batching&&a.enable(19),S.push(a.mask),a.disableAll(),R.fog&&a.enable(0),R.useFog&&a.enable(1),R.flatShading&&a.enable(2),R.logarithmicDepthBuffer&&a.enable(3),R.skinning&&a.enable(4),R.morphTargets&&a.enable(5),R.morphNormals&&a.enable(6),R.morphColors&&a.enable(7),R.premultipliedAlpha&&a.enable(8),R.shadowMapEnabled&&a.enable(9),R.useLegacyLights&&a.enable(10),R.doubleSided&&a.enable(11),R.flipSided&&a.enable(12),R.useDepthPacking&&a.enable(13),R.dithering&&a.enable(14),R.transmission&&a.enable(15),R.sheen&&a.enable(16),R.opaque&&a.enable(17),R.pointsUvs&&a.enable(18),R.decodeVideoTexture&&a.enable(19),S.push(a.mask)}function D(S){let R=y[S.type],V;if(R){let nt=Xn[R];V=Ei.clone(nt.uniforms)}else V=S.uniforms;return V}function z(S,R){let V;for(let nt=0,ft=c.length;nt<ft;nt++){let I=c[nt];if(I.cacheKey===R){V=I,++V.usedTimes;break}}return V===void 0&&(V=new f0(i,R,S,r),c.push(V)),V}function U(S){if(--S.usedTimes===0){let R=c.indexOf(S);c[R]=c[c.length-1],c.pop(),S.destroy()}}function L(S){l.remove(S)}function Q(){l.dispose()}return{getParameters:g,getProgramCacheKey:d,getUniforms:D,acquireProgram:z,releaseProgram:U,releaseShaderCache:L,programs:c,dispose:Q}}function g0(){let i=new WeakMap;function t(r){let o=i.get(r);return o===void 0&&(o={},i.set(r,o)),o}function e(r){i.delete(r)}function n(r,o,a){i.get(r)[o]=a}function s(){i=new WeakMap}return{get:t,remove:e,update:n,dispose:s}}function x0(i,t){return i.groupOrder!==t.groupOrder?i.groupOrder-t.groupOrder:i.renderOrder!==t.renderOrder?i.renderOrder-t.renderOrder:i.material.id!==t.material.id?i.material.id-t.material.id:i.z!==t.z?i.z-t.z:i.id-t.id}function Ah(i,t){return i.groupOrder!==t.groupOrder?i.groupOrder-t.groupOrder:i.renderOrder!==t.renderOrder?i.renderOrder-t.renderOrder:i.z!==t.z?t.z-i.z:i.id-t.id}function Ch(){let i=[],t=0,e=[],n=[],s=[];function r(){t=0,e.length=0,n.length=0,s.length=0}function o(f,p,x,y,M,g){let d=i[t];return d===void 0?(d={id:f.id,object:f,geometry:p,material:x,groupOrder:y,renderOrder:f.renderOrder,z:M,group:g},i[t]=d):(d.id=f.id,d.object=f,d.geometry=p,d.material=x,d.groupOrder=y,d.renderOrder=f.renderOrder,d.z=M,d.group=g),t++,d}function a(f,p,x,y,M,g){let d=o(f,p,x,y,M,g);x.transmission>0?n.push(d):x.transparent===!0?s.push(d):e.push(d)}function l(f,p,x,y,M,g){let d=o(f,p,x,y,M,g);x.transmission>0?n.unshift(d):x.transparent===!0?s.unshift(d):e.unshift(d)}function c(f,p){e.length>1&&e.sort(f||x0),n.length>1&&n.sort(p||Ah),s.length>1&&s.sort(p||Ah)}function u(){for(let f=t,p=i.length;f<p;f++){let x=i[f];if(x.id===null)break;x.id=null,x.object=null,x.geometry=null,x.material=null,x.group=null}}return{opaque:e,transmissive:n,transparent:s,init:r,push:a,unshift:l,finish:u,sort:c}}function _0(){let i=new WeakMap;function t(n,s){let r=i.get(n),o;return r===void 0?(o=new Ch,i.set(n,[o])):s>=r.length?(o=new Ch,r.push(o)):o=r[s],o}function e(){i=new WeakMap}return{get:t,dispose:e}}function v0(){let i={};return{get:function(t){if(i[t.id]!==void 0)return i[t.id];let e;switch(t.type){case"DirectionalLight":e={direction:new B,color:new qt};break;case"SpotLight":e={position:new B,direction:new B,color:new qt,distance:0,coneCos:0,penumbraCos:0,decay:0};break;case"PointLight":e={position:new B,color:new qt,distance:0,decay:0};break;case"HemisphereLight":e={direction:new B,skyColor:new qt,groundColor:new qt};break;case"RectAreaLight":e={color:new qt,position:new B,halfWidth:new B,halfHeight:new B};break}return i[t.id]=e,e}}}function y0(){let i={};return{get:function(t){if(i[t.id]!==void 0)return i[t.id];let e;switch(t.type){case"DirectionalLight":e={shadowBias:0,shadowNormalBias:0,shadowRadius:1,shadowMapSize:new Lt};break;case"SpotLight":e={shadowBias:0,shadowNormalBias:0,shadowRadius:1,shadowMapSize:new Lt};break;case"PointLight":e={shadowBias:0,shadowNormalBias:0,shadowRadius:1,shadowMapSize:new Lt,shadowCameraNear:1,shadowCameraFar:1e3};break}return i[t.id]=e,e}}}var b0=0;function M0(i,t){return(t.castShadow?2:0)-(i.castShadow?2:0)+(t.map?1:0)-(i.map?1:0)}function S0(i,t){let e=new v0,n=y0(),s={version:0,hash:{directionalLength:-1,pointLength:-1,spotLength:-1,rectAreaLength:-1,hemiLength:-1,numDirectionalShadows:-1,numPointShadows:-1,numSpotShadows:-1,numSpotMaps:-1,numLightProbes:-1},ambient:[0,0,0],probe:[],directional:[],directionalShadow:[],directionalShadowMap:[],directionalShadowMatrix:[],spot:[],spotLightMap:[],spotShadow:[],spotShadowMap:[],spotLightMatrix:[],rectArea:[],rectAreaLTC1:null,rectAreaLTC2:null,point:[],pointShadow:[],pointShadowMap:[],pointShadowMatrix:[],hemi:[],numSpotLightShadowsWithMaps:0,numLightProbes:0};for(let u=0;u<9;u++)s.probe.push(new B);let r=new B,o=new ve,a=new ve;function l(u,f){let p=0,x=0,y=0;for(let nt=0;nt<9;nt++)s.probe[nt].set(0,0,0);let M=0,g=0,d=0,C=0,E=0,D=0,z=0,U=0,L=0,Q=0,S=0;u.sort(M0);let R=f===!0?Math.PI:1;for(let nt=0,ft=u.length;nt<ft;nt++){let I=u[nt],k=I.color,$=I.intensity,Z=I.distance,j=I.shadow&&I.shadow.map?I.shadow.map.texture:null;if(I.isAmbientLight)p+=k.r*$*R,x+=k.g*$*R,y+=k.b*$*R;else if(I.isLightProbe){for(let K=0;K<9;K++)s.probe[K].addScaledVector(I.sh.coefficients[K],$);S++}else if(I.isDirectionalLight){let K=e.get(I);if(K.color.copy(I.color).multiplyScalar(I.intensity*R),I.castShadow){let st=I.shadow,it=n.get(I);it.shadowBias=st.bias,it.shadowNormalBias=st.normalBias,it.shadowRadius=st.radius,it.shadowMapSize=st.mapSize,s.directionalShadow[M]=it,s.directionalShadowMap[M]=j,s.directionalShadowMatrix[M]=I.shadow.matrix,D++}s.directional[M]=K,M++}else if(I.isSpotLight){let K=e.get(I);K.position.setFromMatrixPosition(I.matrixWorld),K.color.copy(k).multiplyScalar($*R),K.distance=Z,K.coneCos=Math.cos(I.angle),K.penumbraCos=Math.cos(I.angle*(1-I.penumbra)),K.decay=I.decay,s.spot[d]=K;let st=I.shadow;if(I.map&&(s.spotLightMap[L]=I.map,L++,st.updateMatrices(I),I.castShadow&&Q++),s.spotLightMatrix[d]=st.matrix,I.castShadow){let it=n.get(I);it.shadowBias=st.bias,it.shadowNormalBias=st.normalBias,it.shadowRadius=st.radius,it.shadowMapSize=st.mapSize,s.spotShadow[d]=it,s.spotShadowMap[d]=j,U++}d++}else if(I.isRectAreaLight){let K=e.get(I);K.color.copy(k).multiplyScalar($),K.halfWidth.set(I.width*.5,0,0),K.halfHeight.set(0,I.height*.5,0),s.rectArea[C]=K,C++}else if(I.isPointLight){let K=e.get(I);if(K.color.copy(I.color).multiplyScalar(I.intensity*R),K.distance=I.distance,K.decay=I.decay,I.castShadow){let st=I.shadow,it=n.get(I);it.shadowBias=st.bias,it.shadowNormalBias=st.normalBias,it.shadowRadius=st.radius,it.shadowMapSize=st.mapSize,it.shadowCameraNear=st.camera.near,it.shadowCameraFar=st.camera.far,s.pointShadow[g]=it,s.pointShadowMap[g]=j,s.pointShadowMatrix[g]=I.shadow.matrix,z++}s.point[g]=K,g++}else if(I.isHemisphereLight){let K=e.get(I);K.skyColor.copy(I.color).multiplyScalar($*R),K.groundColor.copy(I.groundColor).multiplyScalar($*R),s.hemi[E]=K,E++}}C>0&&(t.isWebGL2?i.has("OES_texture_float_linear")===!0?(s.rectAreaLTC1=Mt.LTC_FLOAT_1,s.rectAreaLTC2=Mt.LTC_FLOAT_2):(s.rectAreaLTC1=Mt.LTC_HALF_1,s.rectAreaLTC2=Mt.LTC_HALF_2):i.has("OES_texture_float_linear")===!0?(s.rectAreaLTC1=Mt.LTC_FLOAT_1,s.rectAreaLTC2=Mt.LTC_FLOAT_2):i.has("OES_texture_half_float_linear")===!0?(s.rectAreaLTC1=Mt.LTC_HALF_1,s.rectAreaLTC2=Mt.LTC_HALF_2):console.error("THREE.WebGLRenderer: Unable to use RectAreaLight. Missing WebGL extensions.")),s.ambient[0]=p,s.ambient[1]=x,s.ambient[2]=y;let V=s.hash;(V.directionalLength!==M||V.pointLength!==g||V.spotLength!==d||V.rectAreaLength!==C||V.hemiLength!==E||V.numDirectionalShadows!==D||V.numPointShadows!==z||V.numSpotShadows!==U||V.numSpotMaps!==L||V.numLightProbes!==S)&&(s.directional.length=M,s.spot.length=d,s.rectArea.length=C,s.point.length=g,s.hemi.length=E,s.directionalShadow.length=D,s.directionalShadowMap.length=D,s.pointShadow.length=z,s.pointShadowMap.length=z,s.spotShadow.length=U,s.spotShadowMap.length=U,s.directionalShadowMatrix.length=D,s.pointShadowMatrix.length=z,s.spotLightMatrix.length=U+L-Q,s.spotLightMap.length=L,s.numSpotLightShadowsWithMaps=Q,s.numLightProbes=S,V.directionalLength=M,V.pointLength=g,V.spotLength=d,V.rectAreaLength=C,V.hemiLength=E,V.numDirectionalShadows=D,V.numPointShadows=z,V.numSpotShadows=U,V.numSpotMaps=L,V.numLightProbes=S,s.version=b0++)}function c(u,f){let p=0,x=0,y=0,M=0,g=0,d=f.matrixWorldInverse;for(let C=0,E=u.length;C<E;C++){let D=u[C];if(D.isDirectionalLight){let z=s.directional[p];z.direction.setFromMatrixPosition(D.matrixWorld),r.setFromMatrixPosition(D.target.matrixWorld),z.direction.sub(r),z.direction.transformDirection(d),p++}else if(D.isSpotLight){let z=s.spot[y];z.position.setFromMatrixPosition(D.matrixWorld),z.position.applyMatrix4(d),z.direction.setFromMatrixPosition(D.matrixWorld),r.setFromMatrixPosition(D.target.matrixWorld),z.direction.sub(r),z.direction.transformDirection(d),y++}else if(D.isRectAreaLight){let z=s.rectArea[M];z.position.setFromMatrixPosition(D.matrixWorld),z.position.applyMatrix4(d),a.identity(),o.copy(D.matrixWorld),o.premultiply(d),a.extractRotation(o),z.halfWidth.set(D.width*.5,0,0),z.halfHeight.set(0,D.height*.5,0),z.halfWidth.applyMatrix4(a),z.halfHeight.applyMatrix4(a),M++}else if(D.isPointLight){let z=s.point[x];z.position.setFromMatrixPosition(D.matrixWorld),z.position.applyMatrix4(d),x++}else if(D.isHemisphereLight){let z=s.hemi[g];z.direction.setFromMatrixPosition(D.matrixWorld),z.direction.transformDirection(d),g++}}}return{setup:l,setupView:c,state:s}}function Rh(i,t){let e=new S0(i,t),n=[],s=[];function r(){n.length=0,s.length=0}function o(f){n.push(f)}function a(f){s.push(f)}function l(f){e.setup(n,f)}function c(f){e.setupView(n,f)}return{init:r,state:{lightsArray:n,shadowsArray:s,lights:e},setupLights:l,setupLightsView:c,pushLight:o,pushShadow:a}}function w0(i,t){let e=new WeakMap;function n(r,o=0){let a=e.get(r),l;return a===void 0?(l=new Rh(i,t),e.set(r,[l])):o>=a.length?(l=new Rh(i,t),a.push(l)):l=a[o],l}function s(){e=new WeakMap}return{get:n,dispose:s}}var rl=class extends wi{constructor(t){super(),this.isMeshDepthMaterial=!0,this.type="MeshDepthMaterial",this.depthPacking=_d,this.map=null,this.alphaMap=null,this.displacementMap=null,this.displacementScale=1,this.displacementBias=0,this.wireframe=!1,this.wireframeLinewidth=1,this.setValues(t)}copy(t){return super.copy(t),this.depthPacking=t.depthPacking,this.map=t.map,this.alphaMap=t.alphaMap,this.displacementMap=t.displacementMap,this.displacementScale=t.displacementScale,this.displacementBias=t.displacementBias,this.wireframe=t.wireframe,this.wireframeLinewidth=t.wireframeLinewidth,this}},al=class extends wi{constructor(t){super(),this.isMeshDistanceMaterial=!0,this.type="MeshDistanceMaterial",this.map=null,this.alphaMap=null,this.displacementMap=null,this.displacementScale=1,this.displacementBias=0,this.setValues(t)}copy(t){return super.copy(t),this.map=t.map,this.alphaMap=t.alphaMap,this.displacementMap=t.displacementMap,this.displacementScale=t.displacementScale,this.displacementBias=t.displacementBias,this}},E0=`void main() {
	gl_Position = vec4( position, 1.0 );
}`,T0=`uniform sampler2D shadow_pass;
uniform vec2 resolution;
uniform float radius;
#include <packing>
void main() {
	const float samples = float( VSM_SAMPLES );
	float mean = 0.0;
	float squared_mean = 0.0;
	float uvStride = samples <= 1.0 ? 0.0 : 2.0 / ( samples - 1.0 );
	float uvStart = samples <= 1.0 ? 0.0 : - 1.0;
	for ( float i = 0.0; i < samples; i ++ ) {
		float uvOffset = uvStart + i * uvStride;
		#ifdef HORIZONTAL_PASS
			vec2 distribution = unpackRGBATo2Half( texture2D( shadow_pass, ( gl_FragCoord.xy + vec2( uvOffset, 0.0 ) * radius ) / resolution ) );
			mean += distribution.x;
			squared_mean += distribution.y * distribution.y + distribution.x * distribution.x;
		#else
			float depth = unpackRGBAToDepth( texture2D( shadow_pass, ( gl_FragCoord.xy + vec2( 0.0, uvOffset ) * radius ) / resolution ) );
			mean += depth;
			squared_mean += depth * depth;
		#endif
	}
	mean = mean / samples;
	squared_mean = squared_mean / samples;
	float std_dev = sqrt( squared_mean - mean * mean );
	gl_FragColor = pack2HalfToRGBA( vec2( mean, std_dev ) );
}`;function A0(i,t,e){let n=new pr,s=new Lt,r=new Lt,o=new Ee,a=new rl({depthPacking:vd}),l=new al,c={},u=e.maxTextureSize,f={[Mi]:sn,[sn]:Mi,[Dn]:Dn},p=new Ne({defines:{VSM_SAMPLES:8},uniforms:{shadow_pass:{value:null},resolution:{value:new Lt},radius:{value:4}},vertexShader:E0,fragmentShader:T0}),x=p.clone();x.defines.HORIZONTAL_PASS=1;let y=new hn;y.setAttribute("position",new rn(new Float32Array([-1,-1,.5,3,-1,.5,-1,3,.5]),3));let M=new He(y,p),g=this;this.enabled=!1,this.autoUpdate=!0,this.needsUpdate=!1,this.type=zh;let d=this.type;this.render=function(U,L,Q){if(g.enabled===!1||g.autoUpdate===!1&&g.needsUpdate===!1||U.length===0)return;let S=i.getRenderTarget(),R=i.getActiveCubeFace(),V=i.getActiveMipmapLevel(),nt=i.state;nt.setBlending(Yn),nt.buffers.color.setClear(1,1,1,1),nt.buffers.depth.setTest(!0),nt.setScissorTest(!1);let ft=d!==ni&&this.type===ni,I=d===ni&&this.type!==ni;for(let k=0,$=U.length;k<$;k++){let Z=U[k],j=Z.shadow;if(j===void 0){console.warn("THREE.WebGLShadowMap:",Z,"has no shadow.");continue}if(j.autoUpdate===!1&&j.needsUpdate===!1)continue;s.copy(j.mapSize);let K=j.getFrameExtents();if(s.multiply(K),r.copy(j.mapSize),(s.x>u||s.y>u)&&(s.x>u&&(r.x=Math.floor(u/K.x),s.x=r.x*K.x,j.mapSize.x=r.x),s.y>u&&(r.y=Math.floor(u/K.y),s.y=r.y*K.y,j.mapSize.y=r.y)),j.map===null||ft===!0||I===!0){let it=this.type!==ni?{minFilter:qe,magFilter:qe}:{};j.map!==null&&j.map.dispose(),j.map=new Ke(s.x,s.y,it),j.map.texture.name=Z.name+".shadowMap",j.camera.updateProjectionMatrix()}i.setRenderTarget(j.map),i.clear();let st=j.getViewportCount();for(let it=0;it<st;it++){let vt=j.getViewport(it);o.set(r.x*vt.x,r.y*vt.y,r.x*vt.z,r.y*vt.w),nt.viewport(o),j.updateMatrices(Z,it),n=j.getFrustum(),D(L,Q,j.camera,Z,this.type)}j.isPointLightShadow!==!0&&this.type===ni&&C(j,Q),j.needsUpdate=!1}d=this.type,g.needsUpdate=!1,i.setRenderTarget(S,R,V)};function C(U,L){let Q=t.update(M);p.defines.VSM_SAMPLES!==U.blurSamples&&(p.defines.VSM_SAMPLES=U.blurSamples,x.defines.VSM_SAMPLES=U.blurSamples,p.needsUpdate=!0,x.needsUpdate=!0),U.mapPass===null&&(U.mapPass=new Ke(s.x,s.y)),p.uniforms.shadow_pass.value=U.map.texture,p.uniforms.resolution.value=U.mapSize,p.uniforms.radius.value=U.radius,i.setRenderTarget(U.mapPass),i.clear(),i.renderBufferDirect(L,null,Q,p,M,null),x.uniforms.shadow_pass.value=U.mapPass.texture,x.uniforms.resolution.value=U.mapSize,x.uniforms.radius.value=U.radius,i.setRenderTarget(U.map),i.clear(),i.renderBufferDirect(L,null,Q,x,M,null)}function E(U,L,Q,S){let R=null,V=Q.isPointLight===!0?U.customDistanceMaterial:U.customDepthMaterial;if(V!==void 0)R=V;else if(R=Q.isPointLight===!0?l:a,i.localClippingEnabled&&L.clipShadows===!0&&Array.isArray(L.clippingPlanes)&&L.clippingPlanes.length!==0||L.displacementMap&&L.displacementScale!==0||L.alphaMap&&L.alphaTest>0||L.map&&L.alphaTest>0){let nt=R.uuid,ft=L.uuid,I=c[nt];I===void 0&&(I={},c[nt]=I);let k=I[ft];k===void 0&&(k=R.clone(),I[ft]=k,L.addEventListener("dispose",z)),R=k}if(R.visible=L.visible,R.wireframe=L.wireframe,S===ni?R.side=L.shadowSide!==null?L.shadowSide:L.side:R.side=L.shadowSide!==null?L.shadowSide:f[L.side],R.alphaMap=L.alphaMap,R.alphaTest=L.alphaTest,R.map=L.map,R.clipShadows=L.clipShadows,R.clippingPlanes=L.clippingPlanes,R.clipIntersection=L.clipIntersection,R.displacementMap=L.displacementMap,R.displacementScale=L.displacementScale,R.displacementBias=L.displacementBias,R.wireframeLinewidth=L.wireframeLinewidth,R.linewidth=L.linewidth,Q.isPointLight===!0&&R.isMeshDistanceMaterial===!0){let nt=i.properties.get(R);nt.light=Q}return R}function D(U,L,Q,S,R){if(U.visible===!1)return;if(U.layers.test(L.layers)&&(U.isMesh||U.isLine||U.isPoints)&&(U.castShadow||U.receiveShadow&&R===ni)&&(!U.frustumCulled||n.intersectsObject(U))){U.modelViewMatrix.multiplyMatrices(Q.matrixWorldInverse,U.matrixWorld);let ft=t.update(U),I=U.material;if(Array.isArray(I)){let k=ft.groups;for(let $=0,Z=k.length;$<Z;$++){let j=k[$],K=I[j.materialIndex];if(K&&K.visible){let st=E(U,K,S,R);U.onBeforeShadow(i,U,L,Q,ft,st,j),i.renderBufferDirect(Q,null,ft,st,U,j),U.onAfterShadow(i,U,L,Q,ft,st,j)}}}else if(I.visible){let k=E(U,I,S,R);U.onBeforeShadow(i,U,L,Q,ft,k,null),i.renderBufferDirect(Q,null,ft,k,U,null),U.onAfterShadow(i,U,L,Q,ft,k,null)}}let nt=U.children;for(let ft=0,I=nt.length;ft<I;ft++)D(nt[ft],L,Q,S,R)}function z(U){U.target.removeEventListener("dispose",z);for(let Q in c){let S=c[Q],R=U.target.uuid;R in S&&(S[R].dispose(),delete S[R])}}}function C0(i,t,e){let n=e.isWebGL2;function s(){let O=!1,gt=new Ee,xt=null,Ht=new Ee(0,0,0,0);return{setMask:function(Bt){xt!==Bt&&!O&&(i.colorMask(Bt,Bt,Bt,Bt),xt=Bt)},setLocked:function(Bt){O=Bt},setClear:function(Bt,he,se,Oe,ge){ge===!0&&(Bt*=Oe,he*=Oe,se*=Oe),gt.set(Bt,he,se,Oe),Ht.equals(gt)===!1&&(i.clearColor(Bt,he,se,Oe),Ht.copy(gt))},reset:function(){O=!1,xt=null,Ht.set(-1,0,0,0)}}}function r(){let O=!1,gt=null,xt=null,Ht=null;return{setTest:function(Bt){Bt?Dt(i.DEPTH_TEST):At(i.DEPTH_TEST)},setMask:function(Bt){gt!==Bt&&!O&&(i.depthMask(Bt),gt=Bt)},setFunc:function(Bt){if(xt!==Bt){switch(Bt){case Qu:i.depthFunc(i.NEVER);break;case td:i.depthFunc(i.ALWAYS);break;case ed:i.depthFunc(i.LESS);break;case aa:i.depthFunc(i.LEQUAL);break;case nd:i.depthFunc(i.EQUAL);break;case id:i.depthFunc(i.GEQUAL);break;case sd:i.depthFunc(i.GREATER);break;case rd:i.depthFunc(i.NOTEQUAL);break;default:i.depthFunc(i.LEQUAL)}xt=Bt}},setLocked:function(Bt){O=Bt},setClear:function(Bt){Ht!==Bt&&(i.clearDepth(Bt),Ht=Bt)},reset:function(){O=!1,gt=null,xt=null,Ht=null}}}function o(){let O=!1,gt=null,xt=null,Ht=null,Bt=null,he=null,se=null,Oe=null,ge=null;return{setTest:function(pe){O||(pe?Dt(i.STENCIL_TEST):At(i.STENCIL_TEST))},setMask:function(pe){gt!==pe&&!O&&(i.stencilMask(pe),gt=pe)},setFunc:function(pe,Fe,vn){(xt!==pe||Ht!==Fe||Bt!==vn)&&(i.stencilFunc(pe,Fe,vn),xt=pe,Ht=Fe,Bt=vn)},setOp:function(pe,Fe,vn){(he!==pe||se!==Fe||Oe!==vn)&&(i.stencilOp(pe,Fe,vn),he=pe,se=Fe,Oe=vn)},setLocked:function(pe){O=pe},setClear:function(pe){ge!==pe&&(i.clearStencil(pe),ge=pe)},reset:function(){O=!1,gt=null,xt=null,Ht=null,Bt=null,he=null,se=null,Oe=null,ge=null}}}let a=new s,l=new r,c=new o,u=new WeakMap,f=new WeakMap,p={},x={},y=new WeakMap,M=[],g=null,d=!1,C=null,E=null,D=null,z=null,U=null,L=null,Q=null,S=new qt(0,0,0),R=0,V=!1,nt=null,ft=null,I=null,k=null,$=null,Z=i.getParameter(i.MAX_COMBINED_TEXTURE_IMAGE_UNITS),j=!1,K=0,st=i.getParameter(i.VERSION);st.indexOf("WebGL")!==-1?(K=parseFloat(/^WebGL (\d)/.exec(st)[1]),j=K>=1):st.indexOf("OpenGL ES")!==-1&&(K=parseFloat(/^OpenGL ES (\d)/.exec(st)[1]),j=K>=2);let it=null,vt={},q=i.getParameter(i.SCISSOR_BOX),ct=i.getParameter(i.VIEWPORT),yt=new Ee().fromArray(q),It=new Ee().fromArray(ct);function Ot(O,gt,xt,Ht){let Bt=new Uint8Array(4),he=i.createTexture();i.bindTexture(O,he),i.texParameteri(O,i.TEXTURE_MIN_FILTER,i.NEAREST),i.texParameteri(O,i.TEXTURE_MAG_FILTER,i.NEAREST);for(let se=0;se<xt;se++)n&&(O===i.TEXTURE_3D||O===i.TEXTURE_2D_ARRAY)?i.texImage3D(gt,0,i.RGBA,1,1,Ht,0,i.RGBA,i.UNSIGNED_BYTE,Bt):i.texImage2D(gt+se,0,i.RGBA,1,1,0,i.RGBA,i.UNSIGNED_BYTE,Bt);return he}let Pt={};Pt[i.TEXTURE_2D]=Ot(i.TEXTURE_2D,i.TEXTURE_2D,1),Pt[i.TEXTURE_CUBE_MAP]=Ot(i.TEXTURE_CUBE_MAP,i.TEXTURE_CUBE_MAP_POSITIVE_X,6),n&&(Pt[i.TEXTURE_2D_ARRAY]=Ot(i.TEXTURE_2D_ARRAY,i.TEXTURE_2D_ARRAY,1,1),Pt[i.TEXTURE_3D]=Ot(i.TEXTURE_3D,i.TEXTURE_3D,1,1)),a.setClear(0,0,0,1),l.setClear(1),c.setClear(0),Dt(i.DEPTH_TEST),l.setFunc(aa),$t(!1),A(cc),Dt(i.CULL_FACE),Rt(Yn);function Dt(O){p[O]!==!0&&(i.enable(O),p[O]=!0)}function At(O){p[O]!==!1&&(i.disable(O),p[O]=!1)}function kt(O,gt){return x[O]!==gt?(i.bindFramebuffer(O,gt),x[O]=gt,n&&(O===i.DRAW_FRAMEBUFFER&&(x[i.FRAMEBUFFER]=gt),O===i.FRAMEBUFFER&&(x[i.DRAW_FRAMEBUFFER]=gt)),!0):!1}function G(O,gt){let xt=M,Ht=!1;if(O)if(xt=y.get(gt),xt===void 0&&(xt=[],y.set(gt,xt)),O.isWebGLMultipleRenderTargets){let Bt=O.texture;if(xt.length!==Bt.length||xt[0]!==i.COLOR_ATTACHMENT0){for(let he=0,se=Bt.length;he<se;he++)xt[he]=i.COLOR_ATTACHMENT0+he;xt.length=Bt.length,Ht=!0}}else xt[0]!==i.COLOR_ATTACHMENT0&&(xt[0]=i.COLOR_ATTACHMENT0,Ht=!0);else xt[0]!==i.BACK&&(xt[0]=i.BACK,Ht=!0);Ht&&(e.isWebGL2?i.drawBuffers(xt):t.get("WEBGL_draw_buffers").drawBuffersWEBGL(xt))}function Re(O){return g!==O?(i.useProgram(O),g=O,!0):!1}let Ut={[ki]:i.FUNC_ADD,[Bu]:i.FUNC_SUBTRACT,[zu]:i.FUNC_REVERSE_SUBTRACT};if(n)Ut[dc]=i.MIN,Ut[fc]=i.MAX;else{let O=t.get("EXT_blend_minmax");O!==null&&(Ut[dc]=O.MIN_EXT,Ut[fc]=O.MAX_EXT)}let Gt={[ku]:i.ZERO,[Hu]:i.ONE,[Vu]:i.SRC_COLOR,[Vo]:i.SRC_ALPHA,[Zu]:i.SRC_ALPHA_SATURATE,[Yu]:i.DST_COLOR,[Wu]:i.DST_ALPHA,[Gu]:i.ONE_MINUS_SRC_COLOR,[Go]:i.ONE_MINUS_SRC_ALPHA,[qu]:i.ONE_MINUS_DST_COLOR,[Xu]:i.ONE_MINUS_DST_ALPHA,[Ju]:i.CONSTANT_COLOR,[ju]:i.ONE_MINUS_CONSTANT_COLOR,[$u]:i.CONSTANT_ALPHA,[Ku]:i.ONE_MINUS_CONSTANT_ALPHA};function Rt(O,gt,xt,Ht,Bt,he,se,Oe,ge,pe){if(O===Yn){d===!0&&(At(i.BLEND),d=!1);return}if(d===!1&&(Dt(i.BLEND),d=!0),O!==Fu){if(O!==C||pe!==V){if((E!==ki||U!==ki)&&(i.blendEquation(i.FUNC_ADD),E=ki,U=ki),pe)switch(O){case si:i.blendFuncSeparate(i.ONE,i.ONE_MINUS_SRC_ALPHA,i.ONE,i.ONE_MINUS_SRC_ALPHA);break;case Rs:i.blendFunc(i.ONE,i.ONE);break;case hc:i.blendFuncSeparate(i.ZERO,i.ONE_MINUS_SRC_COLOR,i.ZERO,i.ONE);break;case uc:i.blendFuncSeparate(i.ZERO,i.SRC_COLOR,i.ZERO,i.SRC_ALPHA);break;default:console.error("THREE.WebGLState: Invalid blending: ",O);break}else switch(O){case si:i.blendFuncSeparate(i.SRC_ALPHA,i.ONE_MINUS_SRC_ALPHA,i.ONE,i.ONE_MINUS_SRC_ALPHA);break;case Rs:i.blendFunc(i.SRC_ALPHA,i.ONE);break;case hc:i.blendFuncSeparate(i.ZERO,i.ONE_MINUS_SRC_COLOR,i.ZERO,i.ONE);break;case uc:i.blendFunc(i.ZERO,i.SRC_COLOR);break;default:console.error("THREE.WebGLState: Invalid blending: ",O);break}D=null,z=null,L=null,Q=null,S.set(0,0,0),R=0,C=O,V=pe}return}Bt=Bt||gt,he=he||xt,se=se||Ht,(gt!==E||Bt!==U)&&(i.blendEquationSeparate(Ut[gt],Ut[Bt]),E=gt,U=Bt),(xt!==D||Ht!==z||he!==L||se!==Q)&&(i.blendFuncSeparate(Gt[xt],Gt[Ht],Gt[he],Gt[se]),D=xt,z=Ht,L=he,Q=se),(Oe.equals(S)===!1||ge!==R)&&(i.blendColor(Oe.r,Oe.g,Oe.b,ge),S.copy(Oe),R=ge),C=O,V=!1}function me(O,gt){O.side===Dn?At(i.CULL_FACE):Dt(i.CULL_FACE);let xt=O.side===sn;gt&&(xt=!xt),$t(xt),O.blending===si&&O.transparent===!1?Rt(Yn):Rt(O.blending,O.blendEquation,O.blendSrc,O.blendDst,O.blendEquationAlpha,O.blendSrcAlpha,O.blendDstAlpha,O.blendColor,O.blendAlpha,O.premultipliedAlpha),l.setFunc(O.depthFunc),l.setTest(O.depthTest),l.setMask(O.depthWrite),a.setMask(O.colorWrite);let Ht=O.stencilWrite;c.setTest(Ht),Ht&&(c.setMask(O.stencilWriteMask),c.setFunc(O.stencilFunc,O.stencilRef,O.stencilFuncMask),c.setOp(O.stencilFail,O.stencilZFail,O.stencilZPass)),W(O.polygonOffset,O.polygonOffsetFactor,O.polygonOffsetUnits),O.alphaToCoverage===!0?Dt(i.SAMPLE_ALPHA_TO_COVERAGE):At(i.SAMPLE_ALPHA_TO_COVERAGE)}function $t(O){nt!==O&&(O?i.frontFace(i.CW):i.frontFace(i.CCW),nt=O)}function A(O){O!==Nu?(Dt(i.CULL_FACE),O!==ft&&(O===cc?i.cullFace(i.BACK):O===Ou?i.cullFace(i.FRONT):i.cullFace(i.FRONT_AND_BACK))):At(i.CULL_FACE),ft=O}function b(O){O!==I&&(j&&i.lineWidth(O),I=O)}function W(O,gt,xt){O?(Dt(i.POLYGON_OFFSET_FILL),(k!==gt||$!==xt)&&(i.polygonOffset(gt,xt),k=gt,$=xt)):At(i.POLYGON_OFFSET_FILL)}function dt(O){O?Dt(i.SCISSOR_TEST):At(i.SCISSOR_TEST)}function ht(O){O===void 0&&(O=i.TEXTURE0+Z-1),it!==O&&(i.activeTexture(O),it=O)}function rt(O,gt,xt){xt===void 0&&(it===null?xt=i.TEXTURE0+Z-1:xt=it);let Ht=vt[xt];Ht===void 0&&(Ht={type:void 0,texture:void 0},vt[xt]=Ht),(Ht.type!==O||Ht.texture!==gt)&&(it!==xt&&(i.activeTexture(xt),it=xt),i.bindTexture(O,gt||Pt[O]),Ht.type=O,Ht.texture=gt)}function Tt(){let O=vt[it];O!==void 0&&O.type!==void 0&&(i.bindTexture(O.type,null),O.type=void 0,O.texture=void 0)}function St(){try{i.compressedTexImage2D.apply(i,arguments)}catch(O){console.error("THREE.WebGLState:",O)}}function ut(){try{i.compressedTexImage3D.apply(i,arguments)}catch(O){console.error("THREE.WebGLState:",O)}}function Ft(){try{i.texSubImage2D.apply(i,arguments)}catch(O){console.error("THREE.WebGLState:",O)}}function Yt(){try{i.texSubImage3D.apply(i,arguments)}catch(O){console.error("THREE.WebGLState:",O)}}function lt(){try{i.compressedTexSubImage2D.apply(i,arguments)}catch(O){console.error("THREE.WebGLState:",O)}}function ae(){try{i.compressedTexSubImage3D.apply(i,arguments)}catch(O){console.error("THREE.WebGLState:",O)}}function P(){try{i.texStorage2D.apply(i,arguments)}catch(O){console.error("THREE.WebGLState:",O)}}function at(){try{i.texStorage3D.apply(i,arguments)}catch(O){console.error("THREE.WebGLState:",O)}}function mt(){try{i.texImage2D.apply(i,arguments)}catch(O){console.error("THREE.WebGLState:",O)}}function pt(){try{i.texImage3D.apply(i,arguments)}catch(O){console.error("THREE.WebGLState:",O)}}function Nt(O){yt.equals(O)===!1&&(i.scissor(O.x,O.y,O.z,O.w),yt.copy(O))}function ee(O){It.equals(O)===!1&&(i.viewport(O.x,O.y,O.z,O.w),It.copy(O))}function ie(O,gt){let xt=f.get(gt);xt===void 0&&(xt=new WeakMap,f.set(gt,xt));let Ht=xt.get(O);Ht===void 0&&(Ht=i.getUniformBlockIndex(gt,O.name),xt.set(O,Ht))}function Qt(O,gt){let Ht=f.get(gt).get(O);u.get(gt)!==Ht&&(i.uniformBlockBinding(gt,Ht,O.__bindingPointIndex),u.set(gt,Ht))}function _t(){i.disable(i.BLEND),i.disable(i.CULL_FACE),i.disable(i.DEPTH_TEST),i.disable(i.POLYGON_OFFSET_FILL),i.disable(i.SCISSOR_TEST),i.disable(i.STENCIL_TEST),i.disable(i.SAMPLE_ALPHA_TO_COVERAGE),i.blendEquation(i.FUNC_ADD),i.blendFunc(i.ONE,i.ZERO),i.blendFuncSeparate(i.ONE,i.ZERO,i.ONE,i.ZERO),i.blendColor(0,0,0,0),i.colorMask(!0,!0,!0,!0),i.clearColor(0,0,0,0),i.depthMask(!0),i.depthFunc(i.LESS),i.clearDepth(1),i.stencilMask(4294967295),i.stencilFunc(i.ALWAYS,0,4294967295),i.stencilOp(i.KEEP,i.KEEP,i.KEEP),i.clearStencil(0),i.cullFace(i.BACK),i.frontFace(i.CCW),i.polygonOffset(0,0),i.activeTexture(i.TEXTURE0),i.bindFramebuffer(i.FRAMEBUFFER,null),n===!0&&(i.bindFramebuffer(i.DRAW_FRAMEBUFFER,null),i.bindFramebuffer(i.READ_FRAMEBUFFER,null)),i.useProgram(null),i.lineWidth(1),i.scissor(0,0,i.canvas.width,i.canvas.height),i.viewport(0,0,i.canvas.width,i.canvas.height),p={},it=null,vt={},x={},y=new WeakMap,M=[],g=null,d=!1,C=null,E=null,D=null,z=null,U=null,L=null,Q=null,S=new qt(0,0,0),R=0,V=!1,nt=null,ft=null,I=null,k=null,$=null,yt.set(0,0,i.canvas.width,i.canvas.height),It.set(0,0,i.canvas.width,i.canvas.height),a.reset(),l.reset(),c.reset()}return{buffers:{color:a,depth:l,stencil:c},enable:Dt,disable:At,bindFramebuffer:kt,drawBuffers:G,useProgram:Re,setBlending:Rt,setMaterial:me,setFlipSided:$t,setCullFace:A,setLineWidth:b,setPolygonOffset:W,setScissorTest:dt,activeTexture:ht,bindTexture:rt,unbindTexture:Tt,compressedTexImage2D:St,compressedTexImage3D:ut,texImage2D:mt,texImage3D:pt,updateUBOMapping:ie,uniformBlockBinding:Qt,texStorage2D:P,texStorage3D:at,texSubImage2D:Ft,texSubImage3D:Yt,compressedTexSubImage2D:lt,compressedTexSubImage3D:ae,scissor:Nt,viewport:ee,reset:_t}}function R0(i,t,e,n,s,r,o){let a=s.isWebGL2,l=t.has("WEBGL_multisampled_render_to_texture")?t.get("WEBGL_multisampled_render_to_texture"):null,c=typeof navigator>"u"?!1:/OculusBrowser/g.test(navigator.userAgent),u=new WeakMap,f,p=new WeakMap,x=!1;try{x=typeof OffscreenCanvas<"u"&&new OffscreenCanvas(1,1).getContext("2d")!==null}catch{}function y(A,b){return x?new OffscreenCanvas(A,b):pa("canvas")}function M(A,b,W,dt){let ht=1;if((A.width>dt||A.height>dt)&&(ht=dt/Math.max(A.width,A.height)),ht<1||b===!0)if(typeof HTMLImageElement<"u"&&A instanceof HTMLImageElement||typeof HTMLCanvasElement<"u"&&A instanceof HTMLCanvasElement||typeof ImageBitmap<"u"&&A instanceof ImageBitmap){let rt=b?fa:Math.floor,Tt=rt(ht*A.width),St=rt(ht*A.height);f===void 0&&(f=y(Tt,St));let ut=W?y(Tt,St):f;return ut.width=Tt,ut.height=St,ut.getContext("2d").drawImage(A,0,0,Tt,St),console.warn("THREE.WebGLRenderer: Texture has been resized from ("+A.width+"x"+A.height+") to ("+Tt+"x"+St+")."),ut}else return"data"in A&&console.warn("THREE.WebGLRenderer: Image in DataTexture is too big ("+A.width+"x"+A.height+")."),A;return A}function g(A){return Zo(A.width)&&Zo(A.height)}function d(A){return a?!1:A.wrapS!==Un||A.wrapT!==Un||A.minFilter!==qe&&A.minFilter!==bn}function C(A,b){return A.generateMipmaps&&b&&A.minFilter!==qe&&A.minFilter!==bn}function E(A){i.generateMipmap(A)}function D(A,b,W,dt,ht=!1){if(a===!1)return b;if(A!==null){if(i[A]!==void 0)return i[A];console.warn("THREE.WebGLRenderer: Attempt to use non-existing WebGL internal format '"+A+"'")}let rt=b;if(b===i.RED&&(W===i.FLOAT&&(rt=i.R32F),W===i.HALF_FLOAT&&(rt=i.R16F),W===i.UNSIGNED_BYTE&&(rt=i.R8)),b===i.RED_INTEGER&&(W===i.UNSIGNED_BYTE&&(rt=i.R8UI),W===i.UNSIGNED_SHORT&&(rt=i.R16UI),W===i.UNSIGNED_INT&&(rt=i.R32UI),W===i.BYTE&&(rt=i.R8I),W===i.SHORT&&(rt=i.R16I),W===i.INT&&(rt=i.R32I)),b===i.RG&&(W===i.FLOAT&&(rt=i.RG32F),W===i.HALF_FLOAT&&(rt=i.RG16F),W===i.UNSIGNED_BYTE&&(rt=i.RG8)),b===i.RGBA){let Tt=ht?ca:fe.getTransfer(dt);W===i.FLOAT&&(rt=i.RGBA32F),W===i.HALF_FLOAT&&(rt=i.RGBA16F),W===i.UNSIGNED_BYTE&&(rt=Tt===xe?i.SRGB8_ALPHA8:i.RGBA8),W===i.UNSIGNED_SHORT_4_4_4_4&&(rt=i.RGBA4),W===i.UNSIGNED_SHORT_5_5_5_1&&(rt=i.RGB5_A1)}return(rt===i.R16F||rt===i.R32F||rt===i.RG16F||rt===i.RG32F||rt===i.RGBA16F||rt===i.RGBA32F)&&t.get("EXT_color_buffer_float"),rt}function z(A,b,W){return C(A,W)===!0||A.isFramebufferTexture&&A.minFilter!==qe&&A.minFilter!==bn?Math.log2(Math.max(b.width,b.height))+1:A.mipmaps!==void 0&&A.mipmaps.length>0?A.mipmaps.length:A.isCompressedTexture&&Array.isArray(A.image)?b.mipmaps.length:1}function U(A){return A===qe||A===pc||A===ho?i.NEAREST:i.LINEAR}function L(A){let b=A.target;b.removeEventListener("dispose",L),S(b),b.isVideoTexture&&u.delete(b)}function Q(A){let b=A.target;b.removeEventListener("dispose",Q),V(b)}function S(A){let b=n.get(A);if(b.__webglInit===void 0)return;let W=A.source,dt=p.get(W);if(dt){let ht=dt[b.__cacheKey];ht.usedTimes--,ht.usedTimes===0&&R(A),Object.keys(dt).length===0&&p.delete(W)}n.remove(A)}function R(A){let b=n.get(A);i.deleteTexture(b.__webglTexture);let W=A.source,dt=p.get(W);delete dt[b.__cacheKey],o.memory.textures--}function V(A){let b=A.texture,W=n.get(A),dt=n.get(b);if(dt.__webglTexture!==void 0&&(i.deleteTexture(dt.__webglTexture),o.memory.textures--),A.depthTexture&&A.depthTexture.dispose(),A.isWebGLCubeRenderTarget)for(let ht=0;ht<6;ht++){if(Array.isArray(W.__webglFramebuffer[ht]))for(let rt=0;rt<W.__webglFramebuffer[ht].length;rt++)i.deleteFramebuffer(W.__webglFramebuffer[ht][rt]);else i.deleteFramebuffer(W.__webglFramebuffer[ht]);W.__webglDepthbuffer&&i.deleteRenderbuffer(W.__webglDepthbuffer[ht])}else{if(Array.isArray(W.__webglFramebuffer))for(let ht=0;ht<W.__webglFramebuffer.length;ht++)i.deleteFramebuffer(W.__webglFramebuffer[ht]);else i.deleteFramebuffer(W.__webglFramebuffer);if(W.__webglDepthbuffer&&i.deleteRenderbuffer(W.__webglDepthbuffer),W.__webglMultisampledFramebuffer&&i.deleteFramebuffer(W.__webglMultisampledFramebuffer),W.__webglColorRenderbuffer)for(let ht=0;ht<W.__webglColorRenderbuffer.length;ht++)W.__webglColorRenderbuffer[ht]&&i.deleteRenderbuffer(W.__webglColorRenderbuffer[ht]);W.__webglDepthRenderbuffer&&i.deleteRenderbuffer(W.__webglDepthRenderbuffer)}if(A.isWebGLMultipleRenderTargets)for(let ht=0,rt=b.length;ht<rt;ht++){let Tt=n.get(b[ht]);Tt.__webglTexture&&(i.deleteTexture(Tt.__webglTexture),o.memory.textures--),n.remove(b[ht])}n.remove(b),n.remove(A)}let nt=0;function ft(){nt=0}function I(){let A=nt;return A>=s.maxTextures&&console.warn("THREE.WebGLTextures: Trying to use "+A+" texture units while this GPU supports only "+s.maxTextures),nt+=1,A}function k(A){let b=[];return b.push(A.wrapS),b.push(A.wrapT),b.push(A.wrapR||0),b.push(A.magFilter),b.push(A.minFilter),b.push(A.anisotropy),b.push(A.internalFormat),b.push(A.format),b.push(A.type),b.push(A.generateMipmaps),b.push(A.premultiplyAlpha),b.push(A.flipY),b.push(A.unpackAlignment),b.push(A.colorSpace),b.join()}function $(A,b){let W=n.get(A);if(A.isVideoTexture&&me(A),A.isRenderTargetTexture===!1&&A.version>0&&W.__version!==A.version){let dt=A.image;if(dt===null)console.warn("THREE.WebGLRenderer: Texture marked for update but no image data found.");else if(dt.complete===!1)console.warn("THREE.WebGLRenderer: Texture marked for update but image is incomplete");else{yt(W,A,b);return}}e.bindTexture(i.TEXTURE_2D,W.__webglTexture,i.TEXTURE0+b)}function Z(A,b){let W=n.get(A);if(A.version>0&&W.__version!==A.version){yt(W,A,b);return}e.bindTexture(i.TEXTURE_2D_ARRAY,W.__webglTexture,i.TEXTURE0+b)}function j(A,b){let W=n.get(A);if(A.version>0&&W.__version!==A.version){yt(W,A,b);return}e.bindTexture(i.TEXTURE_3D,W.__webglTexture,i.TEXTURE0+b)}function K(A,b){let W=n.get(A);if(A.version>0&&W.__version!==A.version){It(W,A,b);return}e.bindTexture(i.TEXTURE_CUBE_MAP,W.__webglTexture,i.TEXTURE0+b)}let st={[hr]:i.REPEAT,[Un]:i.CLAMP_TO_EDGE,[Yo]:i.MIRRORED_REPEAT},it={[qe]:i.NEAREST,[pc]:i.NEAREST_MIPMAP_NEAREST,[ho]:i.NEAREST_MIPMAP_LINEAR,[bn]:i.LINEAR,[cd]:i.LINEAR_MIPMAP_NEAREST,[ur]:i.LINEAR_MIPMAP_LINEAR},vt={[bd]:i.NEVER,[Ad]:i.ALWAYS,[Md]:i.LESS,[$h]:i.LEQUAL,[Sd]:i.EQUAL,[Td]:i.GEQUAL,[wd]:i.GREATER,[Ed]:i.NOTEQUAL};function q(A,b,W){if(W?(i.texParameteri(A,i.TEXTURE_WRAP_S,st[b.wrapS]),i.texParameteri(A,i.TEXTURE_WRAP_T,st[b.wrapT]),(A===i.TEXTURE_3D||A===i.TEXTURE_2D_ARRAY)&&i.texParameteri(A,i.TEXTURE_WRAP_R,st[b.wrapR]),i.texParameteri(A,i.TEXTURE_MAG_FILTER,it[b.magFilter]),i.texParameteri(A,i.TEXTURE_MIN_FILTER,it[b.minFilter])):(i.texParameteri(A,i.TEXTURE_WRAP_S,i.CLAMP_TO_EDGE),i.texParameteri(A,i.TEXTURE_WRAP_T,i.CLAMP_TO_EDGE),(A===i.TEXTURE_3D||A===i.TEXTURE_2D_ARRAY)&&i.texParameteri(A,i.TEXTURE_WRAP_R,i.CLAMP_TO_EDGE),(b.wrapS!==Un||b.wrapT!==Un)&&console.warn("THREE.WebGLRenderer: Texture is not power of two. Texture.wrapS and Texture.wrapT should be set to THREE.ClampToEdgeWrapping."),i.texParameteri(A,i.TEXTURE_MAG_FILTER,U(b.magFilter)),i.texParameteri(A,i.TEXTURE_MIN_FILTER,U(b.minFilter)),b.minFilter!==qe&&b.minFilter!==bn&&console.warn("THREE.WebGLRenderer: Texture is not power of two. Texture.minFilter should be set to THREE.NearestFilter or THREE.LinearFilter.")),b.compareFunction&&(i.texParameteri(A,i.TEXTURE_COMPARE_MODE,i.COMPARE_REF_TO_TEXTURE),i.texParameteri(A,i.TEXTURE_COMPARE_FUNC,vt[b.compareFunction])),t.has("EXT_texture_filter_anisotropic")===!0){let dt=t.get("EXT_texture_filter_anisotropic");if(b.magFilter===qe||b.minFilter!==ho&&b.minFilter!==ur||b.type===_i&&t.has("OES_texture_float_linear")===!1||a===!1&&b.type===gn&&t.has("OES_texture_half_float_linear")===!1)return;(b.anisotropy>1||n.get(b).__currentAnisotropy)&&(i.texParameterf(A,dt.TEXTURE_MAX_ANISOTROPY_EXT,Math.min(b.anisotropy,s.getMaxAnisotropy())),n.get(b).__currentAnisotropy=b.anisotropy)}}function ct(A,b){let W=!1;A.__webglInit===void 0&&(A.__webglInit=!0,b.addEventListener("dispose",L));let dt=b.source,ht=p.get(dt);ht===void 0&&(ht={},p.set(dt,ht));let rt=k(b);if(rt!==A.__cacheKey){ht[rt]===void 0&&(ht[rt]={texture:i.createTexture(),usedTimes:0},o.memory.textures++,W=!0),ht[rt].usedTimes++;let Tt=ht[A.__cacheKey];Tt!==void 0&&(ht[A.__cacheKey].usedTimes--,Tt.usedTimes===0&&R(b)),A.__cacheKey=rt,A.__webglTexture=ht[rt].texture}return W}function yt(A,b,W){let dt=i.TEXTURE_2D;(b.isDataArrayTexture||b.isCompressedArrayTexture)&&(dt=i.TEXTURE_2D_ARRAY),b.isData3DTexture&&(dt=i.TEXTURE_3D);let ht=ct(A,b),rt=b.source;e.bindTexture(dt,A.__webglTexture,i.TEXTURE0+W);let Tt=n.get(rt);if(rt.version!==Tt.__version||ht===!0){e.activeTexture(i.TEXTURE0+W);let St=fe.getPrimaries(fe.workingColorSpace),ut=b.colorSpace===Mn?null:fe.getPrimaries(b.colorSpace),Ft=b.colorSpace===Mn||St===ut?i.NONE:i.BROWSER_DEFAULT_WEBGL;i.pixelStorei(i.UNPACK_FLIP_Y_WEBGL,b.flipY),i.pixelStorei(i.UNPACK_PREMULTIPLY_ALPHA_WEBGL,b.premultiplyAlpha),i.pixelStorei(i.UNPACK_ALIGNMENT,b.unpackAlignment),i.pixelStorei(i.UNPACK_COLORSPACE_CONVERSION_WEBGL,Ft);let Yt=d(b)&&g(b.image)===!1,lt=M(b.image,Yt,!1,s.maxTextureSize);lt=$t(b,lt);let ae=g(lt)||a,P=r.convert(b.format,b.colorSpace),at=r.convert(b.type),mt=D(b.internalFormat,P,at,b.colorSpace,b.isVideoTexture);q(dt,b,ae);let pt,Nt=b.mipmaps,ee=a&&b.isVideoTexture!==!0&&mt!==Zh,ie=Tt.__version===void 0||ht===!0,Qt=z(b,lt,ae);if(b.isDepthTexture)mt=i.DEPTH_COMPONENT,a?b.type===_i?mt=i.DEPTH_COMPONENT32F:b.type===xi?mt=i.DEPTH_COMPONENT24:b.type===Vi?mt=i.DEPTH24_STENCIL8:mt=i.DEPTH_COMPONENT16:b.type===_i&&console.error("WebGLRenderer: Floating point depth texture requires WebGL2."),b.format===Gi&&mt===i.DEPTH_COMPONENT&&b.type!==Rl&&b.type!==xi&&(console.warn("THREE.WebGLRenderer: Use UnsignedShortType or UnsignedIntType for DepthFormat DepthTexture."),b.type=xi,at=r.convert(b.type)),b.format===Is&&mt===i.DEPTH_COMPONENT&&(mt=i.DEPTH_STENCIL,b.type!==Vi&&(console.warn("THREE.WebGLRenderer: Use UnsignedInt248Type for DepthStencilFormat DepthTexture."),b.type=Vi,at=r.convert(b.type))),ie&&(ee?e.texStorage2D(i.TEXTURE_2D,1,mt,lt.width,lt.height):e.texImage2D(i.TEXTURE_2D,0,mt,lt.width,lt.height,0,P,at,null));else if(b.isDataTexture)if(Nt.length>0&&ae){ee&&ie&&e.texStorage2D(i.TEXTURE_2D,Qt,mt,Nt[0].width,Nt[0].height);for(let _t=0,O=Nt.length;_t<O;_t++)pt=Nt[_t],ee?e.texSubImage2D(i.TEXTURE_2D,_t,0,0,pt.width,pt.height,P,at,pt.data):e.texImage2D(i.TEXTURE_2D,_t,mt,pt.width,pt.height,0,P,at,pt.data);b.generateMipmaps=!1}else ee?(ie&&e.texStorage2D(i.TEXTURE_2D,Qt,mt,lt.width,lt.height),e.texSubImage2D(i.TEXTURE_2D,0,0,0,lt.width,lt.height,P,at,lt.data)):e.texImage2D(i.TEXTURE_2D,0,mt,lt.width,lt.height,0,P,at,lt.data);else if(b.isCompressedTexture)if(b.isCompressedArrayTexture){ee&&ie&&e.texStorage3D(i.TEXTURE_2D_ARRAY,Qt,mt,Nt[0].width,Nt[0].height,lt.depth);for(let _t=0,O=Nt.length;_t<O;_t++)pt=Nt[_t],b.format!==Nn?P!==null?ee?e.compressedTexSubImage3D(i.TEXTURE_2D_ARRAY,_t,0,0,0,pt.width,pt.height,lt.depth,P,pt.data,0,0):e.compressedTexImage3D(i.TEXTURE_2D_ARRAY,_t,mt,pt.width,pt.height,lt.depth,0,pt.data,0,0):console.warn("THREE.WebGLRenderer: Attempt to load unsupported compressed texture format in .uploadTexture()"):ee?e.texSubImage3D(i.TEXTURE_2D_ARRAY,_t,0,0,0,pt.width,pt.height,lt.depth,P,at,pt.data):e.texImage3D(i.TEXTURE_2D_ARRAY,_t,mt,pt.width,pt.height,lt.depth,0,P,at,pt.data)}else{ee&&ie&&e.texStorage2D(i.TEXTURE_2D,Qt,mt,Nt[0].width,Nt[0].height);for(let _t=0,O=Nt.length;_t<O;_t++)pt=Nt[_t],b.format!==Nn?P!==null?ee?e.compressedTexSubImage2D(i.TEXTURE_2D,_t,0,0,pt.width,pt.height,P,pt.data):e.compressedTexImage2D(i.TEXTURE_2D,_t,mt,pt.width,pt.height,0,pt.data):console.warn("THREE.WebGLRenderer: Attempt to load unsupported compressed texture format in .uploadTexture()"):ee?e.texSubImage2D(i.TEXTURE_2D,_t,0,0,pt.width,pt.height,P,at,pt.data):e.texImage2D(i.TEXTURE_2D,_t,mt,pt.width,pt.height,0,P,at,pt.data)}else if(b.isDataArrayTexture)ee?(ie&&e.texStorage3D(i.TEXTURE_2D_ARRAY,Qt,mt,lt.width,lt.height,lt.depth),e.texSubImage3D(i.TEXTURE_2D_ARRAY,0,0,0,0,lt.width,lt.height,lt.depth,P,at,lt.data)):e.texImage3D(i.TEXTURE_2D_ARRAY,0,mt,lt.width,lt.height,lt.depth,0,P,at,lt.data);else if(b.isData3DTexture)ee?(ie&&e.texStorage3D(i.TEXTURE_3D,Qt,mt,lt.width,lt.height,lt.depth),e.texSubImage3D(i.TEXTURE_3D,0,0,0,0,lt.width,lt.height,lt.depth,P,at,lt.data)):e.texImage3D(i.TEXTURE_3D,0,mt,lt.width,lt.height,lt.depth,0,P,at,lt.data);else if(b.isFramebufferTexture){if(ie)if(ee)e.texStorage2D(i.TEXTURE_2D,Qt,mt,lt.width,lt.height);else{let _t=lt.width,O=lt.height;for(let gt=0;gt<Qt;gt++)e.texImage2D(i.TEXTURE_2D,gt,mt,_t,O,0,P,at,null),_t>>=1,O>>=1}}else if(Nt.length>0&&ae){ee&&ie&&e.texStorage2D(i.TEXTURE_2D,Qt,mt,Nt[0].width,Nt[0].height);for(let _t=0,O=Nt.length;_t<O;_t++)pt=Nt[_t],ee?e.texSubImage2D(i.TEXTURE_2D,_t,0,0,P,at,pt):e.texImage2D(i.TEXTURE_2D,_t,mt,P,at,pt);b.generateMipmaps=!1}else ee?(ie&&e.texStorage2D(i.TEXTURE_2D,Qt,mt,lt.width,lt.height),e.texSubImage2D(i.TEXTURE_2D,0,0,0,P,at,lt)):e.texImage2D(i.TEXTURE_2D,0,mt,P,at,lt);C(b,ae)&&E(dt),Tt.__version=rt.version,b.onUpdate&&b.onUpdate(b)}A.__version=b.version}function It(A,b,W){if(b.image.length!==6)return;let dt=ct(A,b),ht=b.source;e.bindTexture(i.TEXTURE_CUBE_MAP,A.__webglTexture,i.TEXTURE0+W);let rt=n.get(ht);if(ht.version!==rt.__version||dt===!0){e.activeTexture(i.TEXTURE0+W);let Tt=fe.getPrimaries(fe.workingColorSpace),St=b.colorSpace===Mn?null:fe.getPrimaries(b.colorSpace),ut=b.colorSpace===Mn||Tt===St?i.NONE:i.BROWSER_DEFAULT_WEBGL;i.pixelStorei(i.UNPACK_FLIP_Y_WEBGL,b.flipY),i.pixelStorei(i.UNPACK_PREMULTIPLY_ALPHA_WEBGL,b.premultiplyAlpha),i.pixelStorei(i.UNPACK_ALIGNMENT,b.unpackAlignment),i.pixelStorei(i.UNPACK_COLORSPACE_CONVERSION_WEBGL,ut);let Ft=b.isCompressedTexture||b.image[0].isCompressedTexture,Yt=b.image[0]&&b.image[0].isDataTexture,lt=[];for(let _t=0;_t<6;_t++)!Ft&&!Yt?lt[_t]=M(b.image[_t],!1,!0,s.maxCubemapSize):lt[_t]=Yt?b.image[_t].image:b.image[_t],lt[_t]=$t(b,lt[_t]);let ae=lt[0],P=g(ae)||a,at=r.convert(b.format,b.colorSpace),mt=r.convert(b.type),pt=D(b.internalFormat,at,mt,b.colorSpace),Nt=a&&b.isVideoTexture!==!0,ee=rt.__version===void 0||dt===!0,ie=z(b,ae,P);q(i.TEXTURE_CUBE_MAP,b,P);let Qt;if(Ft){Nt&&ee&&e.texStorage2D(i.TEXTURE_CUBE_MAP,ie,pt,ae.width,ae.height);for(let _t=0;_t<6;_t++){Qt=lt[_t].mipmaps;for(let O=0;O<Qt.length;O++){let gt=Qt[O];b.format!==Nn?at!==null?Nt?e.compressedTexSubImage2D(i.TEXTURE_CUBE_MAP_POSITIVE_X+_t,O,0,0,gt.width,gt.height,at,gt.data):e.compressedTexImage2D(i.TEXTURE_CUBE_MAP_POSITIVE_X+_t,O,pt,gt.width,gt.height,0,gt.data):console.warn("THREE.WebGLRenderer: Attempt to load unsupported compressed texture format in .setTextureCube()"):Nt?e.texSubImage2D(i.TEXTURE_CUBE_MAP_POSITIVE_X+_t,O,0,0,gt.width,gt.height,at,mt,gt.data):e.texImage2D(i.TEXTURE_CUBE_MAP_POSITIVE_X+_t,O,pt,gt.width,gt.height,0,at,mt,gt.data)}}}else{Qt=b.mipmaps,Nt&&ee&&(Qt.length>0&&ie++,e.texStorage2D(i.TEXTURE_CUBE_MAP,ie,pt,lt[0].width,lt[0].height));for(let _t=0;_t<6;_t++)if(Yt){Nt?e.texSubImage2D(i.TEXTURE_CUBE_MAP_POSITIVE_X+_t,0,0,0,lt[_t].width,lt[_t].height,at,mt,lt[_t].data):e.texImage2D(i.TEXTURE_CUBE_MAP_POSITIVE_X+_t,0,pt,lt[_t].width,lt[_t].height,0,at,mt,lt[_t].data);for(let O=0;O<Qt.length;O++){let xt=Qt[O].image[_t].image;Nt?e.texSubImage2D(i.TEXTURE_CUBE_MAP_POSITIVE_X+_t,O+1,0,0,xt.width,xt.height,at,mt,xt.data):e.texImage2D(i.TEXTURE_CUBE_MAP_POSITIVE_X+_t,O+1,pt,xt.width,xt.height,0,at,mt,xt.data)}}else{Nt?e.texSubImage2D(i.TEXTURE_CUBE_MAP_POSITIVE_X+_t,0,0,0,at,mt,lt[_t]):e.texImage2D(i.TEXTURE_CUBE_MAP_POSITIVE_X+_t,0,pt,at,mt,lt[_t]);for(let O=0;O<Qt.length;O++){let gt=Qt[O];Nt?e.texSubImage2D(i.TEXTURE_CUBE_MAP_POSITIVE_X+_t,O+1,0,0,at,mt,gt.image[_t]):e.texImage2D(i.TEXTURE_CUBE_MAP_POSITIVE_X+_t,O+1,pt,at,mt,gt.image[_t])}}}C(b,P)&&E(i.TEXTURE_CUBE_MAP),rt.__version=ht.version,b.onUpdate&&b.onUpdate(b)}A.__version=b.version}function Ot(A,b,W,dt,ht,rt){let Tt=r.convert(W.format,W.colorSpace),St=r.convert(W.type),ut=D(W.internalFormat,Tt,St,W.colorSpace);if(!n.get(b).__hasExternalTextures){let Yt=Math.max(1,b.width>>rt),lt=Math.max(1,b.height>>rt);ht===i.TEXTURE_3D||ht===i.TEXTURE_2D_ARRAY?e.texImage3D(ht,rt,ut,Yt,lt,b.depth,0,Tt,St,null):e.texImage2D(ht,rt,ut,Yt,lt,0,Tt,St,null)}e.bindFramebuffer(i.FRAMEBUFFER,A),Rt(b)?l.framebufferTexture2DMultisampleEXT(i.FRAMEBUFFER,dt,ht,n.get(W).__webglTexture,0,Gt(b)):(ht===i.TEXTURE_2D||ht>=i.TEXTURE_CUBE_MAP_POSITIVE_X&&ht<=i.TEXTURE_CUBE_MAP_NEGATIVE_Z)&&i.framebufferTexture2D(i.FRAMEBUFFER,dt,ht,n.get(W).__webglTexture,rt),e.bindFramebuffer(i.FRAMEBUFFER,null)}function Pt(A,b,W){if(i.bindRenderbuffer(i.RENDERBUFFER,A),b.depthBuffer&&!b.stencilBuffer){let dt=a===!0?i.DEPTH_COMPONENT24:i.DEPTH_COMPONENT16;if(W||Rt(b)){let ht=b.depthTexture;ht&&ht.isDepthTexture&&(ht.type===_i?dt=i.DEPTH_COMPONENT32F:ht.type===xi&&(dt=i.DEPTH_COMPONENT24));let rt=Gt(b);Rt(b)?l.renderbufferStorageMultisampleEXT(i.RENDERBUFFER,rt,dt,b.width,b.height):i.renderbufferStorageMultisample(i.RENDERBUFFER,rt,dt,b.width,b.height)}else i.renderbufferStorage(i.RENDERBUFFER,dt,b.width,b.height);i.framebufferRenderbuffer(i.FRAMEBUFFER,i.DEPTH_ATTACHMENT,i.RENDERBUFFER,A)}else if(b.depthBuffer&&b.stencilBuffer){let dt=Gt(b);W&&Rt(b)===!1?i.renderbufferStorageMultisample(i.RENDERBUFFER,dt,i.DEPTH24_STENCIL8,b.width,b.height):Rt(b)?l.renderbufferStorageMultisampleEXT(i.RENDERBUFFER,dt,i.DEPTH24_STENCIL8,b.width,b.height):i.renderbufferStorage(i.RENDERBUFFER,i.DEPTH_STENCIL,b.width,b.height),i.framebufferRenderbuffer(i.FRAMEBUFFER,i.DEPTH_STENCIL_ATTACHMENT,i.RENDERBUFFER,A)}else{let dt=b.isWebGLMultipleRenderTargets===!0?b.texture:[b.texture];for(let ht=0;ht<dt.length;ht++){let rt=dt[ht],Tt=r.convert(rt.format,rt.colorSpace),St=r.convert(rt.type),ut=D(rt.internalFormat,Tt,St,rt.colorSpace),Ft=Gt(b);W&&Rt(b)===!1?i.renderbufferStorageMultisample(i.RENDERBUFFER,Ft,ut,b.width,b.height):Rt(b)?l.renderbufferStorageMultisampleEXT(i.RENDERBUFFER,Ft,ut,b.width,b.height):i.renderbufferStorage(i.RENDERBUFFER,ut,b.width,b.height)}}i.bindRenderbuffer(i.RENDERBUFFER,null)}function Dt(A,b){if(b&&b.isWebGLCubeRenderTarget)throw new Error("Depth Texture with cube render targets is not supported");if(e.bindFramebuffer(i.FRAMEBUFFER,A),!(b.depthTexture&&b.depthTexture.isDepthTexture))throw new Error("renderTarget.depthTexture must be an instance of THREE.DepthTexture");(!n.get(b.depthTexture).__webglTexture||b.depthTexture.image.width!==b.width||b.depthTexture.image.height!==b.height)&&(b.depthTexture.image.width=b.width,b.depthTexture.image.height=b.height,b.depthTexture.needsUpdate=!0),$(b.depthTexture,0);let dt=n.get(b.depthTexture).__webglTexture,ht=Gt(b);if(b.depthTexture.format===Gi)Rt(b)?l.framebufferTexture2DMultisampleEXT(i.FRAMEBUFFER,i.DEPTH_ATTACHMENT,i.TEXTURE_2D,dt,0,ht):i.framebufferTexture2D(i.FRAMEBUFFER,i.DEPTH_ATTACHMENT,i.TEXTURE_2D,dt,0);else if(b.depthTexture.format===Is)Rt(b)?l.framebufferTexture2DMultisampleEXT(i.FRAMEBUFFER,i.DEPTH_STENCIL_ATTACHMENT,i.TEXTURE_2D,dt,0,ht):i.framebufferTexture2D(i.FRAMEBUFFER,i.DEPTH_STENCIL_ATTACHMENT,i.TEXTURE_2D,dt,0);else throw new Error("Unknown depthTexture format")}function At(A){let b=n.get(A),W=A.isWebGLCubeRenderTarget===!0;if(A.depthTexture&&!b.__autoAllocateDepthBuffer){if(W)throw new Error("target.depthTexture not supported in Cube render targets");Dt(b.__webglFramebuffer,A)}else if(W){b.__webglDepthbuffer=[];for(let dt=0;dt<6;dt++)e.bindFramebuffer(i.FRAMEBUFFER,b.__webglFramebuffer[dt]),b.__webglDepthbuffer[dt]=i.createRenderbuffer(),Pt(b.__webglDepthbuffer[dt],A,!1)}else e.bindFramebuffer(i.FRAMEBUFFER,b.__webglFramebuffer),b.__webglDepthbuffer=i.createRenderbuffer(),Pt(b.__webglDepthbuffer,A,!1);e.bindFramebuffer(i.FRAMEBUFFER,null)}function kt(A,b,W){let dt=n.get(A);b!==void 0&&Ot(dt.__webglFramebuffer,A,A.texture,i.COLOR_ATTACHMENT0,i.TEXTURE_2D,0),W!==void 0&&At(A)}function G(A){let b=A.texture,W=n.get(A),dt=n.get(b);A.addEventListener("dispose",Q),A.isWebGLMultipleRenderTargets!==!0&&(dt.__webglTexture===void 0&&(dt.__webglTexture=i.createTexture()),dt.__version=b.version,o.memory.textures++);let ht=A.isWebGLCubeRenderTarget===!0,rt=A.isWebGLMultipleRenderTargets===!0,Tt=g(A)||a;if(ht){W.__webglFramebuffer=[];for(let St=0;St<6;St++)if(a&&b.mipmaps&&b.mipmaps.length>0){W.__webglFramebuffer[St]=[];for(let ut=0;ut<b.mipmaps.length;ut++)W.__webglFramebuffer[St][ut]=i.createFramebuffer()}else W.__webglFramebuffer[St]=i.createFramebuffer()}else{if(a&&b.mipmaps&&b.mipmaps.length>0){W.__webglFramebuffer=[];for(let St=0;St<b.mipmaps.length;St++)W.__webglFramebuffer[St]=i.createFramebuffer()}else W.__webglFramebuffer=i.createFramebuffer();if(rt)if(s.drawBuffers){let St=A.texture;for(let ut=0,Ft=St.length;ut<Ft;ut++){let Yt=n.get(St[ut]);Yt.__webglTexture===void 0&&(Yt.__webglTexture=i.createTexture(),o.memory.textures++)}}else console.warn("THREE.WebGLRenderer: WebGLMultipleRenderTargets can only be used with WebGL2 or WEBGL_draw_buffers extension.");if(a&&A.samples>0&&Rt(A)===!1){let St=rt?b:[b];W.__webglMultisampledFramebuffer=i.createFramebuffer(),W.__webglColorRenderbuffer=[],e.bindFramebuffer(i.FRAMEBUFFER,W.__webglMultisampledFramebuffer);for(let ut=0;ut<St.length;ut++){let Ft=St[ut];W.__webglColorRenderbuffer[ut]=i.createRenderbuffer(),i.bindRenderbuffer(i.RENDERBUFFER,W.__webglColorRenderbuffer[ut]);let Yt=r.convert(Ft.format,Ft.colorSpace),lt=r.convert(Ft.type),ae=D(Ft.internalFormat,Yt,lt,Ft.colorSpace,A.isXRRenderTarget===!0),P=Gt(A);i.renderbufferStorageMultisample(i.RENDERBUFFER,P,ae,A.width,A.height),i.framebufferRenderbuffer(i.FRAMEBUFFER,i.COLOR_ATTACHMENT0+ut,i.RENDERBUFFER,W.__webglColorRenderbuffer[ut])}i.bindRenderbuffer(i.RENDERBUFFER,null),A.depthBuffer&&(W.__webglDepthRenderbuffer=i.createRenderbuffer(),Pt(W.__webglDepthRenderbuffer,A,!0)),e.bindFramebuffer(i.FRAMEBUFFER,null)}}if(ht){e.bindTexture(i.TEXTURE_CUBE_MAP,dt.__webglTexture),q(i.TEXTURE_CUBE_MAP,b,Tt);for(let St=0;St<6;St++)if(a&&b.mipmaps&&b.mipmaps.length>0)for(let ut=0;ut<b.mipmaps.length;ut++)Ot(W.__webglFramebuffer[St][ut],A,b,i.COLOR_ATTACHMENT0,i.TEXTURE_CUBE_MAP_POSITIVE_X+St,ut);else Ot(W.__webglFramebuffer[St],A,b,i.COLOR_ATTACHMENT0,i.TEXTURE_CUBE_MAP_POSITIVE_X+St,0);C(b,Tt)&&E(i.TEXTURE_CUBE_MAP),e.unbindTexture()}else if(rt){let St=A.texture;for(let ut=0,Ft=St.length;ut<Ft;ut++){let Yt=St[ut],lt=n.get(Yt);e.bindTexture(i.TEXTURE_2D,lt.__webglTexture),q(i.TEXTURE_2D,Yt,Tt),Ot(W.__webglFramebuffer,A,Yt,i.COLOR_ATTACHMENT0+ut,i.TEXTURE_2D,0),C(Yt,Tt)&&E(i.TEXTURE_2D)}e.unbindTexture()}else{let St=i.TEXTURE_2D;if((A.isWebGL3DRenderTarget||A.isWebGLArrayRenderTarget)&&(a?St=A.isWebGL3DRenderTarget?i.TEXTURE_3D:i.TEXTURE_2D_ARRAY:console.error("THREE.WebGLTextures: THREE.Data3DTexture and THREE.DataArrayTexture only supported with WebGL2.")),e.bindTexture(St,dt.__webglTexture),q(St,b,Tt),a&&b.mipmaps&&b.mipmaps.length>0)for(let ut=0;ut<b.mipmaps.length;ut++)Ot(W.__webglFramebuffer[ut],A,b,i.COLOR_ATTACHMENT0,St,ut);else Ot(W.__webglFramebuffer,A,b,i.COLOR_ATTACHMENT0,St,0);C(b,Tt)&&E(St),e.unbindTexture()}A.depthBuffer&&At(A)}function Re(A){let b=g(A)||a,W=A.isWebGLMultipleRenderTargets===!0?A.texture:[A.texture];for(let dt=0,ht=W.length;dt<ht;dt++){let rt=W[dt];if(C(rt,b)){let Tt=A.isWebGLCubeRenderTarget?i.TEXTURE_CUBE_MAP:i.TEXTURE_2D,St=n.get(rt).__webglTexture;e.bindTexture(Tt,St),E(Tt),e.unbindTexture()}}}function Ut(A){if(a&&A.samples>0&&Rt(A)===!1){let b=A.isWebGLMultipleRenderTargets?A.texture:[A.texture],W=A.width,dt=A.height,ht=i.COLOR_BUFFER_BIT,rt=[],Tt=A.stencilBuffer?i.DEPTH_STENCIL_ATTACHMENT:i.DEPTH_ATTACHMENT,St=n.get(A),ut=A.isWebGLMultipleRenderTargets===!0;if(ut)for(let Ft=0;Ft<b.length;Ft++)e.bindFramebuffer(i.FRAMEBUFFER,St.__webglMultisampledFramebuffer),i.framebufferRenderbuffer(i.FRAMEBUFFER,i.COLOR_ATTACHMENT0+Ft,i.RENDERBUFFER,null),e.bindFramebuffer(i.FRAMEBUFFER,St.__webglFramebuffer),i.framebufferTexture2D(i.DRAW_FRAMEBUFFER,i.COLOR_ATTACHMENT0+Ft,i.TEXTURE_2D,null,0);e.bindFramebuffer(i.READ_FRAMEBUFFER,St.__webglMultisampledFramebuffer),e.bindFramebuffer(i.DRAW_FRAMEBUFFER,St.__webglFramebuffer);for(let Ft=0;Ft<b.length;Ft++){rt.push(i.COLOR_ATTACHMENT0+Ft),A.depthBuffer&&rt.push(Tt);let Yt=St.__ignoreDepthValues!==void 0?St.__ignoreDepthValues:!1;if(Yt===!1&&(A.depthBuffer&&(ht|=i.DEPTH_BUFFER_BIT),A.stencilBuffer&&(ht|=i.STENCIL_BUFFER_BIT)),ut&&i.framebufferRenderbuffer(i.READ_FRAMEBUFFER,i.COLOR_ATTACHMENT0,i.RENDERBUFFER,St.__webglColorRenderbuffer[Ft]),Yt===!0&&(i.invalidateFramebuffer(i.READ_FRAMEBUFFER,[Tt]),i.invalidateFramebuffer(i.DRAW_FRAMEBUFFER,[Tt])),ut){let lt=n.get(b[Ft]).__webglTexture;i.framebufferTexture2D(i.DRAW_FRAMEBUFFER,i.COLOR_ATTACHMENT0,i.TEXTURE_2D,lt,0)}i.blitFramebuffer(0,0,W,dt,0,0,W,dt,ht,i.NEAREST),c&&i.invalidateFramebuffer(i.READ_FRAMEBUFFER,rt)}if(e.bindFramebuffer(i.READ_FRAMEBUFFER,null),e.bindFramebuffer(i.DRAW_FRAMEBUFFER,null),ut)for(let Ft=0;Ft<b.length;Ft++){e.bindFramebuffer(i.FRAMEBUFFER,St.__webglMultisampledFramebuffer),i.framebufferRenderbuffer(i.FRAMEBUFFER,i.COLOR_ATTACHMENT0+Ft,i.RENDERBUFFER,St.__webglColorRenderbuffer[Ft]);let Yt=n.get(b[Ft]).__webglTexture;e.bindFramebuffer(i.FRAMEBUFFER,St.__webglFramebuffer),i.framebufferTexture2D(i.DRAW_FRAMEBUFFER,i.COLOR_ATTACHMENT0+Ft,i.TEXTURE_2D,Yt,0)}e.bindFramebuffer(i.DRAW_FRAMEBUFFER,St.__webglMultisampledFramebuffer)}}function Gt(A){return Math.min(s.maxSamples,A.samples)}function Rt(A){let b=n.get(A);return a&&A.samples>0&&t.has("WEBGL_multisampled_render_to_texture")===!0&&b.__useRenderToTexture!==!1}function me(A){let b=o.render.frame;u.get(A)!==b&&(u.set(A,b),A.update())}function $t(A,b){let W=A.colorSpace,dt=A.format,ht=A.type;return A.isCompressedTexture===!0||A.isVideoTexture===!0||A.format===qo||W!==ri&&W!==Mn&&(fe.getTransfer(W)===xe?a===!1?t.has("EXT_sRGB")===!0&&dt===Nn?(A.format=qo,A.minFilter=bn,A.generateMipmaps=!1):b=ma.sRGBToLinear(b):(dt!==Nn||ht!==bi)&&console.warn("THREE.WebGLTextures: sRGB encoded textures have to use RGBAFormat and UnsignedByteType."):console.error("THREE.WebGLTextures: Unsupported texture color space:",W)),b}this.allocateTextureUnit=I,this.resetTextureUnits=ft,this.setTexture2D=$,this.setTexture2DArray=Z,this.setTexture3D=j,this.setTextureCube=K,this.rebindTextures=kt,this.setupRenderTarget=G,this.updateRenderTargetMipmap=Re,this.updateMultisampleRenderTarget=Ut,this.setupDepthRenderbuffer=At,this.setupFrameBufferTexture=Ot,this.useMultisampledRTT=Rt}function P0(i,t,e){let n=e.isWebGL2;function s(r,o=Mn){let a,l=fe.getTransfer(o);if(r===bi)return i.UNSIGNED_BYTE;if(r===Gh)return i.UNSIGNED_SHORT_4_4_4_4;if(r===Wh)return i.UNSIGNED_SHORT_5_5_5_1;if(r===hd)return i.BYTE;if(r===ud)return i.SHORT;if(r===Rl)return i.UNSIGNED_SHORT;if(r===Vh)return i.INT;if(r===xi)return i.UNSIGNED_INT;if(r===_i)return i.FLOAT;if(r===gn)return n?i.HALF_FLOAT:(a=t.get("OES_texture_half_float"),a!==null?a.HALF_FLOAT_OES:null);if(r===dd)return i.ALPHA;if(r===Nn)return i.RGBA;if(r===fd)return i.LUMINANCE;if(r===pd)return i.LUMINANCE_ALPHA;if(r===Gi)return i.DEPTH_COMPONENT;if(r===Is)return i.DEPTH_STENCIL;if(r===qo)return a=t.get("EXT_sRGB"),a!==null?a.SRGB_ALPHA_EXT:null;if(r===md)return i.RED;if(r===Xh)return i.RED_INTEGER;if(r===gd)return i.RG;if(r===Yh)return i.RG_INTEGER;if(r===qh)return i.RGBA_INTEGER;if(r===uo||r===fo||r===po||r===mo)if(l===xe)if(a=t.get("WEBGL_compressed_texture_s3tc_srgb"),a!==null){if(r===uo)return a.COMPRESSED_SRGB_S3TC_DXT1_EXT;if(r===fo)return a.COMPRESSED_SRGB_ALPHA_S3TC_DXT1_EXT;if(r===po)return a.COMPRESSED_SRGB_ALPHA_S3TC_DXT3_EXT;if(r===mo)return a.COMPRESSED_SRGB_ALPHA_S3TC_DXT5_EXT}else return null;else if(a=t.get("WEBGL_compressed_texture_s3tc"),a!==null){if(r===uo)return a.COMPRESSED_RGB_S3TC_DXT1_EXT;if(r===fo)return a.COMPRESSED_RGBA_S3TC_DXT1_EXT;if(r===po)return a.COMPRESSED_RGBA_S3TC_DXT3_EXT;if(r===mo)return a.COMPRESSED_RGBA_S3TC_DXT5_EXT}else return null;if(r===mc||r===gc||r===xc||r===_c)if(a=t.get("WEBGL_compressed_texture_pvrtc"),a!==null){if(r===mc)return a.COMPRESSED_RGB_PVRTC_4BPPV1_IMG;if(r===gc)return a.COMPRESSED_RGB_PVRTC_2BPPV1_IMG;if(r===xc)return a.COMPRESSED_RGBA_PVRTC_4BPPV1_IMG;if(r===_c)return a.COMPRESSED_RGBA_PVRTC_2BPPV1_IMG}else return null;if(r===Zh)return a=t.get("WEBGL_compressed_texture_etc1"),a!==null?a.COMPRESSED_RGB_ETC1_WEBGL:null;if(r===vc||r===yc)if(a=t.get("WEBGL_compressed_texture_etc"),a!==null){if(r===vc)return l===xe?a.COMPRESSED_SRGB8_ETC2:a.COMPRESSED_RGB8_ETC2;if(r===yc)return l===xe?a.COMPRESSED_SRGB8_ALPHA8_ETC2_EAC:a.COMPRESSED_RGBA8_ETC2_EAC}else return null;if(r===bc||r===Mc||r===Sc||r===wc||r===Ec||r===Tc||r===Ac||r===Cc||r===Rc||r===Pc||r===Lc||r===Ic||r===Dc||r===Uc)if(a=t.get("WEBGL_compressed_texture_astc"),a!==null){if(r===bc)return l===xe?a.COMPRESSED_SRGB8_ALPHA8_ASTC_4x4_KHR:a.COMPRESSED_RGBA_ASTC_4x4_KHR;if(r===Mc)return l===xe?a.COMPRESSED_SRGB8_ALPHA8_ASTC_5x4_KHR:a.COMPRESSED_RGBA_ASTC_5x4_KHR;if(r===Sc)return l===xe?a.COMPRESSED_SRGB8_ALPHA8_ASTC_5x5_KHR:a.COMPRESSED_RGBA_ASTC_5x5_KHR;if(r===wc)return l===xe?a.COMPRESSED_SRGB8_ALPHA8_ASTC_6x5_KHR:a.COMPRESSED_RGBA_ASTC_6x5_KHR;if(r===Ec)return l===xe?a.COMPRESSED_SRGB8_ALPHA8_ASTC_6x6_KHR:a.COMPRESSED_RGBA_ASTC_6x6_KHR;if(r===Tc)return l===xe?a.COMPRESSED_SRGB8_ALPHA8_ASTC_8x5_KHR:a.COMPRESSED_RGBA_ASTC_8x5_KHR;if(r===Ac)return l===xe?a.COMPRESSED_SRGB8_ALPHA8_ASTC_8x6_KHR:a.COMPRESSED_RGBA_ASTC_8x6_KHR;if(r===Cc)return l===xe?a.COMPRESSED_SRGB8_ALPHA8_ASTC_8x8_KHR:a.COMPRESSED_RGBA_ASTC_8x8_KHR;if(r===Rc)return l===xe?a.COMPRESSED_SRGB8_ALPHA8_ASTC_10x5_KHR:a.COMPRESSED_RGBA_ASTC_10x5_KHR;if(r===Pc)return l===xe?a.COMPRESSED_SRGB8_ALPHA8_ASTC_10x6_KHR:a.COMPRESSED_RGBA_ASTC_10x6_KHR;if(r===Lc)return l===xe?a.COMPRESSED_SRGB8_ALPHA8_ASTC_10x8_KHR:a.COMPRESSED_RGBA_ASTC_10x8_KHR;if(r===Ic)return l===xe?a.COMPRESSED_SRGB8_ALPHA8_ASTC_10x10_KHR:a.COMPRESSED_RGBA_ASTC_10x10_KHR;if(r===Dc)return l===xe?a.COMPRESSED_SRGB8_ALPHA8_ASTC_12x10_KHR:a.COMPRESSED_RGBA_ASTC_12x10_KHR;if(r===Uc)return l===xe?a.COMPRESSED_SRGB8_ALPHA8_ASTC_12x12_KHR:a.COMPRESSED_RGBA_ASTC_12x12_KHR}else return null;if(r===go||r===Nc||r===Oc)if(a=t.get("EXT_texture_compression_bptc"),a!==null){if(r===go)return l===xe?a.COMPRESSED_SRGB_ALPHA_BPTC_UNORM_EXT:a.COMPRESSED_RGBA_BPTC_UNORM_EXT;if(r===Nc)return a.COMPRESSED_RGB_BPTC_SIGNED_FLOAT_EXT;if(r===Oc)return a.COMPRESSED_RGB_BPTC_UNSIGNED_FLOAT_EXT}else return null;if(r===xd||r===Fc||r===Bc||r===zc)if(a=t.get("EXT_texture_compression_rgtc"),a!==null){if(r===go)return a.COMPRESSED_RED_RGTC1_EXT;if(r===Fc)return a.COMPRESSED_SIGNED_RED_RGTC1_EXT;if(r===Bc)return a.COMPRESSED_RED_GREEN_RGTC2_EXT;if(r===zc)return a.COMPRESSED_SIGNED_RED_GREEN_RGTC2_EXT}else return null;return r===Vi?n?i.UNSIGNED_INT_24_8:(a=t.get("WEBGL_depth_texture"),a!==null?a.UNSIGNED_INT_24_8_WEBGL:null):i[r]!==void 0?i[r]:null}return{convert:s}}var ol=class extends nn{constructor(t=[]){super(),this.isArrayCamera=!0,this.cameras=t}},vi=class extends an{constructor(){super(),this.isGroup=!0,this.type="Group"}},L0={type:"move"},cr=class{constructor(){this._targetRay=null,this._grip=null,this._hand=null}getHandSpace(){return this._hand===null&&(this._hand=new vi,this._hand.matrixAutoUpdate=!1,this._hand.visible=!1,this._hand.joints={},this._hand.inputState={pinching:!1}),this._hand}getTargetRaySpace(){return this._targetRay===null&&(this._targetRay=new vi,this._targetRay.matrixAutoUpdate=!1,this._targetRay.visible=!1,this._targetRay.hasLinearVelocity=!1,this._targetRay.linearVelocity=new B,this._targetRay.hasAngularVelocity=!1,this._targetRay.angularVelocity=new B),this._targetRay}getGripSpace(){return this._grip===null&&(this._grip=new vi,this._grip.matrixAutoUpdate=!1,this._grip.visible=!1,this._grip.hasLinearVelocity=!1,this._grip.linearVelocity=new B,this._grip.hasAngularVelocity=!1,this._grip.angularVelocity=new B),this._grip}dispatchEvent(t){return this._targetRay!==null&&this._targetRay.dispatchEvent(t),this._grip!==null&&this._grip.dispatchEvent(t),this._hand!==null&&this._hand.dispatchEvent(t),this}connect(t){if(t&&t.hand){let e=this._hand;if(e)for(let n of t.hand.values())this._getHandJoint(e,n)}return this.dispatchEvent({type:"connected",data:t}),this}disconnect(t){return this.dispatchEvent({type:"disconnected",data:t}),this._targetRay!==null&&(this._targetRay.visible=!1),this._grip!==null&&(this._grip.visible=!1),this._hand!==null&&(this._hand.visible=!1),this}update(t,e,n){let s=null,r=null,o=null,a=this._targetRay,l=this._grip,c=this._hand;if(t&&e.session.visibilityState!=="visible-blurred"){if(c&&t.hand){o=!0;for(let M of t.hand.values()){let g=e.getJointPose(M,n),d=this._getHandJoint(c,M);g!==null&&(d.matrix.fromArray(g.transform.matrix),d.matrix.decompose(d.position,d.rotation,d.scale),d.matrixWorldNeedsUpdate=!0,d.jointRadius=g.radius),d.visible=g!==null}let u=c.joints["index-finger-tip"],f=c.joints["thumb-tip"],p=u.position.distanceTo(f.position),x=.02,y=.005;c.inputState.pinching&&p>x+y?(c.inputState.pinching=!1,this.dispatchEvent({type:"pinchend",handedness:t.handedness,target:this})):!c.inputState.pinching&&p<=x-y&&(c.inputState.pinching=!0,this.dispatchEvent({type:"pinchstart",handedness:t.handedness,target:this}))}else l!==null&&t.gripSpace&&(r=e.getPose(t.gripSpace,n),r!==null&&(l.matrix.fromArray(r.transform.matrix),l.matrix.decompose(l.position,l.rotation,l.scale),l.matrixWorldNeedsUpdate=!0,r.linearVelocity?(l.hasLinearVelocity=!0,l.linearVelocity.copy(r.linearVelocity)):l.hasLinearVelocity=!1,r.angularVelocity?(l.hasAngularVelocity=!0,l.angularVelocity.copy(r.angularVelocity)):l.hasAngularVelocity=!1));a!==null&&(s=e.getPose(t.targetRaySpace,n),s===null&&r!==null&&(s=r),s!==null&&(a.matrix.fromArray(s.transform.matrix),a.matrix.decompose(a.position,a.rotation,a.scale),a.matrixWorldNeedsUpdate=!0,s.linearVelocity?(a.hasLinearVelocity=!0,a.linearVelocity.copy(s.linearVelocity)):a.hasLinearVelocity=!1,s.angularVelocity?(a.hasAngularVelocity=!0,a.angularVelocity.copy(s.angularVelocity)):a.hasAngularVelocity=!1,this.dispatchEvent(L0)))}return a!==null&&(a.visible=s!==null),l!==null&&(l.visible=r!==null),c!==null&&(c.visible=o!==null),this}_getHandJoint(t,e){if(t.joints[e.jointName]===void 0){let n=new vi;n.matrixAutoUpdate=!1,n.visible=!1,t.joints[e.jointName]=n,t.add(n)}return t.joints[e.jointName]}},ll=class extends qn{constructor(t,e){super();let n=this,s=null,r=1,o=null,a="local-floor",l=1,c=null,u=null,f=null,p=null,x=null,y=null,M=e.getContextAttributes(),g=null,d=null,C=[],E=[],D=new Lt,z=null,U=new nn;U.layers.enable(1),U.viewport=new Ee;let L=new nn;L.layers.enable(2),L.viewport=new Ee;let Q=[U,L],S=new ol;S.layers.enable(1),S.layers.enable(2);let R=null,V=null;this.cameraAutoUpdate=!0,this.enabled=!1,this.isPresenting=!1,this.getController=function(q){let ct=C[q];return ct===void 0&&(ct=new cr,C[q]=ct),ct.getTargetRaySpace()},this.getControllerGrip=function(q){let ct=C[q];return ct===void 0&&(ct=new cr,C[q]=ct),ct.getGripSpace()},this.getHand=function(q){let ct=C[q];return ct===void 0&&(ct=new cr,C[q]=ct),ct.getHandSpace()};function nt(q){let ct=E.indexOf(q.inputSource);if(ct===-1)return;let yt=C[ct];yt!==void 0&&(yt.update(q.inputSource,q.frame,c||o),yt.dispatchEvent({type:q.type,data:q.inputSource}))}function ft(){s.removeEventListener("select",nt),s.removeEventListener("selectstart",nt),s.removeEventListener("selectend",nt),s.removeEventListener("squeeze",nt),s.removeEventListener("squeezestart",nt),s.removeEventListener("squeezeend",nt),s.removeEventListener("end",ft),s.removeEventListener("inputsourceschange",I);for(let q=0;q<C.length;q++){let ct=E[q];ct!==null&&(E[q]=null,C[q].disconnect(ct))}R=null,V=null,t.setRenderTarget(g),x=null,p=null,f=null,s=null,d=null,vt.stop(),n.isPresenting=!1,t.setPixelRatio(z),t.setSize(D.width,D.height,!1),n.dispatchEvent({type:"sessionend"})}this.setFramebufferScaleFactor=function(q){r=q,n.isPresenting===!0&&console.warn("THREE.WebXRManager: Cannot change framebuffer scale while presenting.")},this.setReferenceSpaceType=function(q){a=q,n.isPresenting===!0&&console.warn("THREE.WebXRManager: Cannot change reference space type while presenting.")},this.getReferenceSpace=function(){return c||o},this.setReferenceSpace=function(q){c=q},this.getBaseLayer=function(){return p!==null?p:x},this.getBinding=function(){return f},this.getFrame=function(){return y},this.getSession=function(){return s},this.setSession=async function(q){if(s=q,s!==null){if(g=t.getRenderTarget(),s.addEventListener("select",nt),s.addEventListener("selectstart",nt),s.addEventListener("selectend",nt),s.addEventListener("squeeze",nt),s.addEventListener("squeezestart",nt),s.addEventListener("squeezeend",nt),s.addEventListener("end",ft),s.addEventListener("inputsourceschange",I),M.xrCompatible!==!0&&await e.makeXRCompatible(),z=t.getPixelRatio(),t.getSize(D),s.renderState.layers===void 0||t.capabilities.isWebGL2===!1){let ct={antialias:s.renderState.layers===void 0?M.antialias:!0,alpha:!0,depth:M.depth,stencil:M.stencil,framebufferScaleFactor:r};x=new XRWebGLLayer(s,e,ct),s.updateRenderState({baseLayer:x}),t.setPixelRatio(1),t.setSize(x.framebufferWidth,x.framebufferHeight,!1),d=new Ke(x.framebufferWidth,x.framebufferHeight,{format:Nn,type:bi,colorSpace:t.outputColorSpace,stencilBuffer:M.stencil})}else{let ct=null,yt=null,It=null;M.depth&&(It=M.stencil?e.DEPTH24_STENCIL8:e.DEPTH_COMPONENT24,ct=M.stencil?Is:Gi,yt=M.stencil?Vi:xi);let Ot={colorFormat:e.RGBA8,depthFormat:It,scaleFactor:r};f=new XRWebGLBinding(s,e),p=f.createProjectionLayer(Ot),s.updateRenderState({layers:[p]}),t.setPixelRatio(1),t.setSize(p.textureWidth,p.textureHeight,!1),d=new Ke(p.textureWidth,p.textureHeight,{format:Nn,type:bi,depthTexture:new wa(p.textureWidth,p.textureHeight,yt,void 0,void 0,void 0,void 0,void 0,void 0,ct),stencilBuffer:M.stencil,colorSpace:t.outputColorSpace,samples:M.antialias?4:0});let Pt=t.properties.get(d);Pt.__ignoreDepthValues=p.ignoreDepthValues}d.isXRRenderTarget=!0,this.setFoveation(l),c=null,o=await s.requestReferenceSpace(a),vt.setContext(s),vt.start(),n.isPresenting=!0,n.dispatchEvent({type:"sessionstart"})}},this.getEnvironmentBlendMode=function(){if(s!==null)return s.environmentBlendMode};function I(q){for(let ct=0;ct<q.removed.length;ct++){let yt=q.removed[ct],It=E.indexOf(yt);It>=0&&(E[It]=null,C[It].disconnect(yt))}for(let ct=0;ct<q.added.length;ct++){let yt=q.added[ct],It=E.indexOf(yt);if(It===-1){for(let Pt=0;Pt<C.length;Pt++)if(Pt>=E.length){E.push(yt),It=Pt;break}else if(E[Pt]===null){E[Pt]=yt,It=Pt;break}if(It===-1)break}let Ot=C[It];Ot&&Ot.connect(yt)}}let k=new B,$=new B;function Z(q,ct,yt){k.setFromMatrixPosition(ct.matrixWorld),$.setFromMatrixPosition(yt.matrixWorld);let It=k.distanceTo($),Ot=ct.projectionMatrix.elements,Pt=yt.projectionMatrix.elements,Dt=Ot[14]/(Ot[10]-1),At=Ot[14]/(Ot[10]+1),kt=(Ot[9]+1)/Ot[5],G=(Ot[9]-1)/Ot[5],Re=(Ot[8]-1)/Ot[0],Ut=(Pt[8]+1)/Pt[0],Gt=Dt*Re,Rt=Dt*Ut,me=It/(-Re+Ut),$t=me*-Re;ct.matrixWorld.decompose(q.position,q.quaternion,q.scale),q.translateX($t),q.translateZ(me),q.matrixWorld.compose(q.position,q.quaternion,q.scale),q.matrixWorldInverse.copy(q.matrixWorld).invert();let A=Dt+me,b=At+me,W=Gt-$t,dt=Rt+(It-$t),ht=kt*At/b*A,rt=G*At/b*A;q.projectionMatrix.makePerspective(W,dt,ht,rt,A,b),q.projectionMatrixInverse.copy(q.projectionMatrix).invert()}function j(q,ct){ct===null?q.matrixWorld.copy(q.matrix):q.matrixWorld.multiplyMatrices(ct.matrixWorld,q.matrix),q.matrixWorldInverse.copy(q.matrixWorld).invert()}this.updateCamera=function(q){if(s===null)return;S.near=L.near=U.near=q.near,S.far=L.far=U.far=q.far,(R!==S.near||V!==S.far)&&(s.updateRenderState({depthNear:S.near,depthFar:S.far}),R=S.near,V=S.far);let ct=q.parent,yt=S.cameras;j(S,ct);for(let It=0;It<yt.length;It++)j(yt[It],ct);yt.length===2?Z(S,U,L):S.projectionMatrix.copy(U.projectionMatrix),K(q,S,ct)};function K(q,ct,yt){yt===null?q.matrix.copy(ct.matrixWorld):(q.matrix.copy(yt.matrixWorld),q.matrix.invert(),q.matrix.multiply(ct.matrixWorld)),q.matrix.decompose(q.position,q.quaternion,q.scale),q.updateMatrixWorld(!0),q.projectionMatrix.copy(ct.projectionMatrix),q.projectionMatrixInverse.copy(ct.projectionMatrixInverse),q.isPerspectiveCamera&&(q.fov=dr*2*Math.atan(1/q.projectionMatrix.elements[5]),q.zoom=1)}this.getCamera=function(){return S},this.getFoveation=function(){if(!(p===null&&x===null))return l},this.setFoveation=function(q){l=q,p!==null&&(p.fixedFoveation=q),x!==null&&x.fixedFoveation!==void 0&&(x.fixedFoveation=q)};let st=null;function it(q,ct){if(u=ct.getViewerPose(c||o),y=ct,u!==null){let yt=u.views;x!==null&&(t.setRenderTargetFramebuffer(d,x.framebuffer),t.setRenderTarget(d));let It=!1;yt.length!==S.cameras.length&&(S.cameras.length=0,It=!0);for(let Ot=0;Ot<yt.length;Ot++){let Pt=yt[Ot],Dt=null;if(x!==null)Dt=x.getViewport(Pt);else{let kt=f.getViewSubImage(p,Pt);Dt=kt.viewport,Ot===0&&(t.setRenderTargetTextures(d,kt.colorTexture,p.ignoreDepthValues?void 0:kt.depthStencilTexture),t.setRenderTarget(d))}let At=Q[Ot];At===void 0&&(At=new nn,At.layers.enable(Ot),At.viewport=new Ee,Q[Ot]=At),At.matrix.fromArray(Pt.transform.matrix),At.matrix.decompose(At.position,At.quaternion,At.scale),At.projectionMatrix.fromArray(Pt.projectionMatrix),At.projectionMatrixInverse.copy(At.projectionMatrix).invert(),At.viewport.set(Dt.x,Dt.y,Dt.width,Dt.height),Ot===0&&(S.matrix.copy(At.matrix),S.matrix.decompose(S.position,S.quaternion,S.scale)),It===!0&&S.cameras.push(At)}}for(let yt=0;yt<C.length;yt++){let It=E[yt],Ot=C[yt];It!==null&&Ot!==void 0&&Ot.update(It,ct,c||o)}st&&st(q,ct),ct.detectedPlanes&&n.dispatchEvent({type:"planesdetected",data:ct}),y=null}let vt=new nu;vt.setAnimationLoop(it),this.setAnimationLoop=function(q){st=q},this.dispose=function(){}}};function I0(i,t){function e(g,d){g.matrixAutoUpdate===!0&&g.updateMatrix(),d.value.copy(g.matrix)}function n(g,d){d.color.getRGB(g.fogColor.value,eu(i)),d.isFog?(g.fogNear.value=d.near,g.fogFar.value=d.far):d.isFogExp2&&(g.fogDensity.value=d.density)}function s(g,d,C,E,D){d.isMeshBasicMaterial||d.isMeshLambertMaterial?r(g,d):d.isMeshToonMaterial?(r(g,d),f(g,d)):d.isMeshPhongMaterial?(r(g,d),u(g,d)):d.isMeshStandardMaterial?(r(g,d),p(g,d),d.isMeshPhysicalMaterial&&x(g,d,D)):d.isMeshMatcapMaterial?(r(g,d),y(g,d)):d.isMeshDepthMaterial?r(g,d):d.isMeshDistanceMaterial?(r(g,d),M(g,d)):d.isMeshNormalMaterial?r(g,d):d.isLineBasicMaterial?(o(g,d),d.isLineDashedMaterial&&a(g,d)):d.isPointsMaterial?l(g,d,C,E):d.isSpriteMaterial?c(g,d):d.isShadowMaterial?(g.color.value.copy(d.color),g.opacity.value=d.opacity):d.isShaderMaterial&&(d.uniformsNeedUpdate=!1)}function r(g,d){g.opacity.value=d.opacity,d.color&&g.diffuse.value.copy(d.color),d.emissive&&g.emissive.value.copy(d.emissive).multiplyScalar(d.emissiveIntensity),d.map&&(g.map.value=d.map,e(d.map,g.mapTransform)),d.alphaMap&&(g.alphaMap.value=d.alphaMap,e(d.alphaMap,g.alphaMapTransform)),d.bumpMap&&(g.bumpMap.value=d.bumpMap,e(d.bumpMap,g.bumpMapTransform),g.bumpScale.value=d.bumpScale,d.side===sn&&(g.bumpScale.value*=-1)),d.normalMap&&(g.normalMap.value=d.normalMap,e(d.normalMap,g.normalMapTransform),g.normalScale.value.copy(d.normalScale),d.side===sn&&g.normalScale.value.negate()),d.displacementMap&&(g.displacementMap.value=d.displacementMap,e(d.displacementMap,g.displacementMapTransform),g.displacementScale.value=d.displacementScale,g.displacementBias.value=d.displacementBias),d.emissiveMap&&(g.emissiveMap.value=d.emissiveMap,e(d.emissiveMap,g.emissiveMapTransform)),d.specularMap&&(g.specularMap.value=d.specularMap,e(d.specularMap,g.specularMapTransform)),d.alphaTest>0&&(g.alphaTest.value=d.alphaTest);let C=t.get(d).envMap;if(C&&(g.envMap.value=C,g.flipEnvMap.value=C.isCubeTexture&&C.isRenderTargetTexture===!1?-1:1,g.reflectivity.value=d.reflectivity,g.ior.value=d.ior,g.refractionRatio.value=d.refractionRatio),d.lightMap){g.lightMap.value=d.lightMap;let E=i._useLegacyLights===!0?Math.PI:1;g.lightMapIntensity.value=d.lightMapIntensity*E,e(d.lightMap,g.lightMapTransform)}d.aoMap&&(g.aoMap.value=d.aoMap,g.aoMapIntensity.value=d.aoMapIntensity,e(d.aoMap,g.aoMapTransform))}function o(g,d){g.diffuse.value.copy(d.color),g.opacity.value=d.opacity,d.map&&(g.map.value=d.map,e(d.map,g.mapTransform))}function a(g,d){g.dashSize.value=d.dashSize,g.totalSize.value=d.dashSize+d.gapSize,g.scale.value=d.scale}function l(g,d,C,E){g.diffuse.value.copy(d.color),g.opacity.value=d.opacity,g.size.value=d.size*C,g.scale.value=E*.5,d.map&&(g.map.value=d.map,e(d.map,g.uvTransform)),d.alphaMap&&(g.alphaMap.value=d.alphaMap,e(d.alphaMap,g.alphaMapTransform)),d.alphaTest>0&&(g.alphaTest.value=d.alphaTest)}function c(g,d){g.diffuse.value.copy(d.color),g.opacity.value=d.opacity,g.rotation.value=d.rotation,d.map&&(g.map.value=d.map,e(d.map,g.mapTransform)),d.alphaMap&&(g.alphaMap.value=d.alphaMap,e(d.alphaMap,g.alphaMapTransform)),d.alphaTest>0&&(g.alphaTest.value=d.alphaTest)}function u(g,d){g.specular.value.copy(d.specular),g.shininess.value=Math.max(d.shininess,1e-4)}function f(g,d){d.gradientMap&&(g.gradientMap.value=d.gradientMap)}function p(g,d){g.metalness.value=d.metalness,d.metalnessMap&&(g.metalnessMap.value=d.metalnessMap,e(d.metalnessMap,g.metalnessMapTransform)),g.roughness.value=d.roughness,d.roughnessMap&&(g.roughnessMap.value=d.roughnessMap,e(d.roughnessMap,g.roughnessMapTransform)),t.get(d).envMap&&(g.envMapIntensity.value=d.envMapIntensity)}function x(g,d,C){g.ior.value=d.ior,d.sheen>0&&(g.sheenColor.value.copy(d.sheenColor).multiplyScalar(d.sheen),g.sheenRoughness.value=d.sheenRoughness,d.sheenColorMap&&(g.sheenColorMap.value=d.sheenColorMap,e(d.sheenColorMap,g.sheenColorMapTransform)),d.sheenRoughnessMap&&(g.sheenRoughnessMap.value=d.sheenRoughnessMap,e(d.sheenRoughnessMap,g.sheenRoughnessMapTransform))),d.clearcoat>0&&(g.clearcoat.value=d.clearcoat,g.clearcoatRoughness.value=d.clearcoatRoughness,d.clearcoatMap&&(g.clearcoatMap.value=d.clearcoatMap,e(d.clearcoatMap,g.clearcoatMapTransform)),d.clearcoatRoughnessMap&&(g.clearcoatRoughnessMap.value=d.clearcoatRoughnessMap,e(d.clearcoatRoughnessMap,g.clearcoatRoughnessMapTransform)),d.clearcoatNormalMap&&(g.clearcoatNormalMap.value=d.clearcoatNormalMap,e(d.clearcoatNormalMap,g.clearcoatNormalMapTransform),g.clearcoatNormalScale.value.copy(d.clearcoatNormalScale),d.side===sn&&g.clearcoatNormalScale.value.negate())),d.iridescence>0&&(g.iridescence.value=d.iridescence,g.iridescenceIOR.value=d.iridescenceIOR,g.iridescenceThicknessMinimum.value=d.iridescenceThicknessRange[0],g.iridescenceThicknessMaximum.value=d.iridescenceThicknessRange[1],d.iridescenceMap&&(g.iridescenceMap.value=d.iridescenceMap,e(d.iridescenceMap,g.iridescenceMapTransform)),d.iridescenceThicknessMap&&(g.iridescenceThicknessMap.value=d.iridescenceThicknessMap,e(d.iridescenceThicknessMap,g.iridescenceThicknessMapTransform))),d.transmission>0&&(g.transmission.value=d.transmission,g.transmissionSamplerMap.value=C.texture,g.transmissionSamplerSize.value.set(C.width,C.height),d.transmissionMap&&(g.transmissionMap.value=d.transmissionMap,e(d.transmissionMap,g.transmissionMapTransform)),g.thickness.value=d.thickness,d.thicknessMap&&(g.thicknessMap.value=d.thicknessMap,e(d.thicknessMap,g.thicknessMapTransform)),g.attenuationDistance.value=d.attenuationDistance,g.attenuationColor.value.copy(d.attenuationColor)),d.anisotropy>0&&(g.anisotropyVector.value.set(d.anisotropy*Math.cos(d.anisotropyRotation),d.anisotropy*Math.sin(d.anisotropyRotation)),d.anisotropyMap&&(g.anisotropyMap.value=d.anisotropyMap,e(d.anisotropyMap,g.anisotropyMapTransform))),g.specularIntensity.value=d.specularIntensity,g.specularColor.value.copy(d.specularColor),d.specularColorMap&&(g.specularColorMap.value=d.specularColorMap,e(d.specularColorMap,g.specularColorMapTransform)),d.specularIntensityMap&&(g.specularIntensityMap.value=d.specularIntensityMap,e(d.specularIntensityMap,g.specularIntensityMapTransform))}function y(g,d){d.matcap&&(g.matcap.value=d.matcap)}function M(g,d){let C=t.get(d).light;g.referencePosition.value.setFromMatrixPosition(C.matrixWorld),g.nearDistance.value=C.shadow.camera.near,g.farDistance.value=C.shadow.camera.far}return{refreshFogUniforms:n,refreshMaterialUniforms:s}}function D0(i,t,e,n){let s={},r={},o=[],a=e.isWebGL2?i.getParameter(i.MAX_UNIFORM_BUFFER_BINDINGS):0;function l(C,E){let D=E.program;n.uniformBlockBinding(C,D)}function c(C,E){let D=s[C.id];D===void 0&&(y(C),D=u(C),s[C.id]=D,C.addEventListener("dispose",g));let z=E.program;n.updateUBOMapping(C,z);let U=t.render.frame;r[C.id]!==U&&(p(C),r[C.id]=U)}function u(C){let E=f();C.__bindingPointIndex=E;let D=i.createBuffer(),z=C.__size,U=C.usage;return i.bindBuffer(i.UNIFORM_BUFFER,D),i.bufferData(i.UNIFORM_BUFFER,z,U),i.bindBuffer(i.UNIFORM_BUFFER,null),i.bindBufferBase(i.UNIFORM_BUFFER,E,D),D}function f(){for(let C=0;C<a;C++)if(o.indexOf(C)===-1)return o.push(C),C;return console.error("THREE.WebGLRenderer: Maximum number of simultaneously usable uniforms groups reached."),0}function p(C){let E=s[C.id],D=C.uniforms,z=C.__cache;i.bindBuffer(i.UNIFORM_BUFFER,E);for(let U=0,L=D.length;U<L;U++){let Q=Array.isArray(D[U])?D[U]:[D[U]];for(let S=0,R=Q.length;S<R;S++){let V=Q[S];if(x(V,U,S,z)===!0){let nt=V.__offset,ft=Array.isArray(V.value)?V.value:[V.value],I=0;for(let k=0;k<ft.length;k++){let $=ft[k],Z=M($);typeof $=="number"||typeof $=="boolean"?(V.__data[0]=$,i.bufferSubData(i.UNIFORM_BUFFER,nt+I,V.__data)):$.isMatrix3?(V.__data[0]=$.elements[0],V.__data[1]=$.elements[1],V.__data[2]=$.elements[2],V.__data[3]=0,V.__data[4]=$.elements[3],V.__data[5]=$.elements[4],V.__data[6]=$.elements[5],V.__data[7]=0,V.__data[8]=$.elements[6],V.__data[9]=$.elements[7],V.__data[10]=$.elements[8],V.__data[11]=0):($.toArray(V.__data,I),I+=Z.storage/Float32Array.BYTES_PER_ELEMENT)}i.bufferSubData(i.UNIFORM_BUFFER,nt,V.__data)}}}i.bindBuffer(i.UNIFORM_BUFFER,null)}function x(C,E,D,z){let U=C.value,L=E+"_"+D;if(z[L]===void 0)return typeof U=="number"||typeof U=="boolean"?z[L]=U:z[L]=U.clone(),!0;{let Q=z[L];if(typeof U=="number"||typeof U=="boolean"){if(Q!==U)return z[L]=U,!0}else if(Q.equals(U)===!1)return Q.copy(U),!0}return!1}function y(C){let E=C.uniforms,D=0,z=16;for(let L=0,Q=E.length;L<Q;L++){let S=Array.isArray(E[L])?E[L]:[E[L]];for(let R=0,V=S.length;R<V;R++){let nt=S[R],ft=Array.isArray(nt.value)?nt.value:[nt.value];for(let I=0,k=ft.length;I<k;I++){let $=ft[I],Z=M($),j=D%z;j!==0&&z-j<Z.boundary&&(D+=z-j),nt.__data=new Float32Array(Z.storage/Float32Array.BYTES_PER_ELEMENT),nt.__offset=D,D+=Z.storage}}}let U=D%z;return U>0&&(D+=z-U),C.__size=D,C.__cache={},this}function M(C){let E={boundary:0,storage:0};return typeof C=="number"||typeof C=="boolean"?(E.boundary=4,E.storage=4):C.isVector2?(E.boundary=8,E.storage=8):C.isVector3||C.isColor?(E.boundary=16,E.storage=12):C.isVector4?(E.boundary=16,E.storage=16):C.isMatrix3?(E.boundary=48,E.storage=48):C.isMatrix4?(E.boundary=64,E.storage=64):C.isTexture?console.warn("THREE.WebGLRenderer: Texture samplers can not be part of an uniforms group."):console.warn("THREE.WebGLRenderer: Unsupported uniform value type.",C),E}function g(C){let E=C.target;E.removeEventListener("dispose",g);let D=o.indexOf(E.__bindingPointIndex);o.splice(D,1),i.deleteBuffer(s[E.id]),delete s[E.id],delete r[E.id]}function d(){for(let C in s)i.deleteBuffer(s[C]);o=[],s={},r={}}return{bind:l,update:c,dispose:d}}var gr=class{constructor(t={}){let{canvas:e=Vd(),context:n=null,depth:s=!0,stencil:r=!0,alpha:o=!1,antialias:a=!1,premultipliedAlpha:l=!0,preserveDrawingBuffer:c=!1,powerPreference:u="default",failIfMajorPerformanceCaveat:f=!1}=t;this.isWebGLRenderer=!0;let p;n!==null?p=n.getContextAttributes().alpha:p=o;let x=new Uint32Array(4),y=new Int32Array(4),M=null,g=null,d=[],C=[];this.domElement=e,this.debug={checkShaderErrors:!0,onShaderError:null},this.autoClear=!0,this.autoClearColor=!0,this.autoClearDepth=!0,this.autoClearStencil=!0,this.sortObjects=!0,this.clippingPlanes=[],this.localClippingEnabled=!1,this._outputColorSpace=Ce,this._useLegacyLights=!1,this.toneMapping=yi,this.toneMappingExposure=1;let E=this,D=!1,z=0,U=0,L=null,Q=-1,S=null,R=new Ee,V=new Ee,nt=null,ft=new qt(0),I=0,k=e.width,$=e.height,Z=1,j=null,K=null,st=new Ee(0,0,k,$),it=new Ee(0,0,k,$),vt=!1,q=new pr,ct=!1,yt=!1,It=null,Ot=new ve,Pt=new Lt,Dt=new B,At={background:null,fog:null,environment:null,overrideMaterial:null,isScene:!0};function kt(){return L===null?Z:1}let G=n;function Re(T,H){for(let X=0;X<T.length;X++){let J=T[X],Y=e.getContext(J,H);if(Y!==null)return Y}return null}try{let T={alpha:!0,depth:s,stencil:r,antialias:a,premultipliedAlpha:l,preserveDrawingBuffer:c,powerPreference:u,failIfMajorPerformanceCaveat:f};if("setAttribute"in e&&e.setAttribute("data-engine","three.js r160"),e.addEventListener("webglcontextlost",_t,!1),e.addEventListener("webglcontextrestored",O,!1),e.addEventListener("webglcontextcreationerror",gt,!1),G===null){let H=["webgl2","webgl","experimental-webgl"];if(E.isWebGL1Renderer===!0&&H.shift(),G=Re(H,T),G===null)throw Re(H)?new Error("Error creating WebGL context with your selected attributes."):new Error("Error creating WebGL context.")}typeof WebGLRenderingContext<"u"&&G instanceof WebGLRenderingContext&&console.warn("THREE.WebGLRenderer: WebGL 1 support was deprecated in r153 and will be removed in r163."),G.getShaderPrecisionFormat===void 0&&(G.getShaderPrecisionFormat=function(){return{rangeMin:1,rangeMax:1,precision:1}})}catch(T){throw console.error("THREE.WebGLRenderer: "+T.message),T}let Ut,Gt,Rt,me,$t,A,b,W,dt,ht,rt,Tt,St,ut,Ft,Yt,lt,ae,P,at,mt,pt,Nt,ee;function ie(){Ut=new Km(G),Gt=new Ym(G,Ut,t),Ut.init(Gt),pt=new P0(G,Ut,Gt),Rt=new C0(G,Ut,Gt),me=new eg(G),$t=new g0,A=new R0(G,Ut,Rt,$t,Gt,pt,me),b=new Zm(E),W=new $m(E),dt=new cf(G,Gt),Nt=new Wm(G,Ut,dt,Gt),ht=new Qm(G,dt,me,Nt),rt=new rg(G,ht,dt,me),P=new sg(G,Gt,A),Yt=new qm($t),Tt=new m0(E,b,W,Ut,Gt,Nt,Yt),St=new I0(E,$t),ut=new _0,Ft=new w0(Ut,Gt),ae=new Gm(E,b,W,Rt,rt,p,l),lt=new A0(E,rt,Gt),ee=new D0(G,me,Gt,Rt),at=new Xm(G,Ut,me,Gt),mt=new tg(G,Ut,me,Gt),me.programs=Tt.programs,E.capabilities=Gt,E.extensions=Ut,E.properties=$t,E.renderLists=ut,E.shadowMap=lt,E.state=Rt,E.info=me}ie();let Qt=new ll(E,G);this.xr=Qt,this.getContext=function(){return G},this.getContextAttributes=function(){return G.getContextAttributes()},this.forceContextLoss=function(){let T=Ut.get("WEBGL_lose_context");T&&T.loseContext()},this.forceContextRestore=function(){let T=Ut.get("WEBGL_lose_context");T&&T.restoreContext()},this.getPixelRatio=function(){return Z},this.setPixelRatio=function(T){T!==void 0&&(Z=T,this.setSize(k,$,!1))},this.getSize=function(T){return T.set(k,$)},this.setSize=function(T,H,X=!0){if(Qt.isPresenting){console.warn("THREE.WebGLRenderer: Can't change size while VR device is presenting.");return}k=T,$=H,e.width=Math.floor(T*Z),e.height=Math.floor(H*Z),X===!0&&(e.style.width=T+"px",e.style.height=H+"px"),this.setViewport(0,0,T,H)},this.getDrawingBufferSize=function(T){return T.set(k*Z,$*Z).floor()},this.setDrawingBufferSize=function(T,H,X){k=T,$=H,Z=X,e.width=Math.floor(T*X),e.height=Math.floor(H*X),this.setViewport(0,0,T,H)},this.getCurrentViewport=function(T){return T.copy(R)},this.getViewport=function(T){return T.copy(st)},this.setViewport=function(T,H,X,J){T.isVector4?st.set(T.x,T.y,T.z,T.w):st.set(T,H,X,J),Rt.viewport(R.copy(st).multiplyScalar(Z).floor())},this.getScissor=function(T){return T.copy(it)},this.setScissor=function(T,H,X,J){T.isVector4?it.set(T.x,T.y,T.z,T.w):it.set(T,H,X,J),Rt.scissor(V.copy(it).multiplyScalar(Z).floor())},this.getScissorTest=function(){return vt},this.setScissorTest=function(T){Rt.setScissorTest(vt=T)},this.setOpaqueSort=function(T){j=T},this.setTransparentSort=function(T){K=T},this.getClearColor=function(T){return T.copy(ae.getClearColor())},this.setClearColor=function(){ae.setClearColor.apply(ae,arguments)},this.getClearAlpha=function(){return ae.getClearAlpha()},this.setClearAlpha=function(){ae.setClearAlpha.apply(ae,arguments)},this.clear=function(T=!0,H=!0,X=!0){let J=0;if(T){let Y=!1;if(L!==null){let Et=L.texture.format;Y=Et===qh||Et===Yh||Et===Xh}if(Y){let Et=L.texture.type,zt=Et===bi||Et===xi||Et===Rl||Et===Vi||Et===Gh||Et===Wh,Xt=ae.getClearColor(),Zt=ae.getClearAlpha(),Vt=Xt.r,Wt=Xt.g,Jt=Xt.b;zt?(x[0]=Vt,x[1]=Wt,x[2]=Jt,x[3]=Zt,G.clearBufferuiv(G.COLOR,0,x)):(y[0]=Vt,y[1]=Wt,y[2]=Jt,y[3]=Zt,G.clearBufferiv(G.COLOR,0,y))}else J|=G.COLOR_BUFFER_BIT}H&&(J|=G.DEPTH_BUFFER_BIT),X&&(J|=G.STENCIL_BUFFER_BIT,this.state.buffers.stencil.setMask(4294967295)),G.clear(J)},this.clearColor=function(){this.clear(!0,!1,!1)},this.clearDepth=function(){this.clear(!1,!0,!1)},this.clearStencil=function(){this.clear(!1,!1,!0)},this.dispose=function(){e.removeEventListener("webglcontextlost",_t,!1),e.removeEventListener("webglcontextrestored",O,!1),e.removeEventListener("webglcontextcreationerror",gt,!1),ut.dispose(),Ft.dispose(),$t.dispose(),b.dispose(),W.dispose(),rt.dispose(),Nt.dispose(),ee.dispose(),Tt.dispose(),Qt.dispose(),Qt.removeEventListener("sessionstart",ge),Qt.removeEventListener("sessionend",pe),It&&(It.dispose(),It=null),Fe.stop()};function _t(T){T.preventDefault(),console.log("THREE.WebGLRenderer: Context Lost."),D=!0}function O(){console.log("THREE.WebGLRenderer: Context Restored."),D=!1;let T=me.autoReset,H=lt.enabled,X=lt.autoUpdate,J=lt.needsUpdate,Y=lt.type;ie(),me.autoReset=T,lt.enabled=H,lt.autoUpdate=X,lt.needsUpdate=J,lt.type=Y}function gt(T){console.error("THREE.WebGLRenderer: A WebGL context could not be created. Reason: ",T.statusMessage)}function xt(T){let H=T.target;H.removeEventListener("dispose",xt),Ht(H)}function Ht(T){Bt(T),$t.remove(T)}function Bt(T){let H=$t.get(T).programs;H!==void 0&&(H.forEach(function(X){Tt.releaseProgram(X)}),T.isShaderMaterial&&Tt.releaseShaderCache(T))}this.renderBufferDirect=function(T,H,X,J,Y,Et){H===null&&(H=At);let zt=Y.isMesh&&Y.matrixWorld.determinant()<0,Xt=qa(T,H,X,J,Y);Rt.setMaterial(J,zt);let Zt=X.index,Vt=1;if(J.wireframe===!0){if(Zt=ht.getWireframeAttribute(X),Zt===void 0)return;Vt=2}let Wt=X.drawRange,Jt=X.attributes.position,de=Wt.start*Vt,Pe=(Wt.start+Wt.count)*Vt;Et!==null&&(de=Math.max(de,Et.start*Vt),Pe=Math.min(Pe,(Et.start+Et.count)*Vt)),Zt!==null?(de=Math.max(de,0),Pe=Math.min(Pe,Zt.count)):Jt!=null&&(de=Math.max(de,0),Pe=Math.min(Pe,Jt.count));let ye=Pe-de;if(ye<0||ye===1/0)return;Nt.setup(Y,J,Xt,X,Zt);let wn,_e=at;if(Zt!==null&&(wn=dt.get(Zt),_e=mt,_e.setIndex(wn)),Y.isMesh)J.wireframe===!0?(Rt.setLineWidth(J.wireframeLinewidth*kt()),_e.setMode(G.LINES)):_e.setMode(G.TRIANGLES);else if(Y.isLine){let Kt=J.linewidth;Kt===void 0&&(Kt=1),Rt.setLineWidth(Kt*kt()),Y.isLineSegments?_e.setMode(G.LINES):Y.isLineLoop?_e.setMode(G.LINE_LOOP):_e.setMode(G.LINE_STRIP)}else Y.isPoints?_e.setMode(G.POINTS):Y.isSprite&&_e.setMode(G.TRIANGLES);if(Y.isBatchedMesh)_e.renderMultiDraw(Y._multiDrawStarts,Y._multiDrawCounts,Y._multiDrawCount);else if(Y.isInstancedMesh)_e.renderInstances(de,ye,Y.count);else if(X.isInstancedBufferGeometry){let Kt=X._maxInstanceCount!==void 0?X._maxInstanceCount:1/0,fn=Math.min(X.instanceCount,Kt);_e.renderInstances(de,ye,fn)}else _e.render(de,ye)};function he(T,H,X){T.transparent===!0&&T.side===Dn&&T.forceSinglePass===!1?(T.side=sn,T.needsUpdate=!0,Bn(T,H,X),T.side=Mi,T.needsUpdate=!0,Bn(T,H,X),T.side=Dn):Bn(T,H,X)}this.compile=function(T,H,X=null){X===null&&(X=T),g=Ft.get(X),g.init(),C.push(g),X.traverseVisible(function(Y){Y.isLight&&Y.layers.test(H.layers)&&(g.pushLight(Y),Y.castShadow&&g.pushShadow(Y))}),T!==X&&T.traverseVisible(function(Y){Y.isLight&&Y.layers.test(H.layers)&&(g.pushLight(Y),Y.castShadow&&g.pushShadow(Y))}),g.setupLights(E._useLegacyLights);let J=new Set;return T.traverse(function(Y){let Et=Y.material;if(Et)if(Array.isArray(Et))for(let zt=0;zt<Et.length;zt++){let Xt=Et[zt];he(Xt,X,Y),J.add(Xt)}else he(Et,X,Y),J.add(Et)}),C.pop(),g=null,J},this.compileAsync=function(T,H,X=null){let J=this.compile(T,H,X);return new Promise(Y=>{function Et(){if(J.forEach(function(zt){$t.get(zt).currentProgram.isReady()&&J.delete(zt)}),J.size===0){Y(T);return}setTimeout(Et,10)}Ut.get("KHR_parallel_shader_compile")!==null?Et():setTimeout(Et,10)})};let se=null;function Oe(T){se&&se(T)}function ge(){Fe.stop()}function pe(){Fe.start()}let Fe=new nu;Fe.setAnimationLoop(Oe),typeof self<"u"&&Fe.setContext(self),this.setAnimationLoop=function(T){se=T,Qt.setAnimationLoop(T),T===null?Fe.stop():Fe.start()},Qt.addEventListener("sessionstart",ge),Qt.addEventListener("sessionend",pe),this.render=function(T,H){if(H!==void 0&&H.isCamera!==!0){console.error("THREE.WebGLRenderer.render: camera is not an instance of THREE.Camera.");return}if(D===!0)return;T.matrixWorldAutoUpdate===!0&&T.updateMatrixWorld(),H.parent===null&&H.matrixWorldAutoUpdate===!0&&H.updateMatrixWorld(),Qt.enabled===!0&&Qt.isPresenting===!0&&(Qt.cameraAutoUpdate===!0&&Qt.updateCamera(H),H=Qt.getCamera()),T.isScene===!0&&T.onBeforeRender(E,T,H,L),g=Ft.get(T,C.length),g.init(),C.push(g),Ot.multiplyMatrices(H.projectionMatrix,H.matrixWorldInverse),q.setFromProjectionMatrix(Ot),yt=this.localClippingEnabled,ct=Yt.init(this.clippingPlanes,yt),M=ut.get(T,d.length),M.init(),d.push(M),vn(T,H,0,E.sortObjects),M.finish(),E.sortObjects===!0&&M.sort(j,K),this.info.render.frame++,ct===!0&&Yt.beginShadows();let X=g.state.shadowsArray;if(lt.render(X,T,H),ct===!0&&Yt.endShadows(),this.info.autoReset===!0&&this.info.reset(),ae.render(M,T),g.setupLights(E._useLegacyLights),H.isArrayCamera){let J=H.cameras;for(let Y=0,Et=J.length;Y<Et;Y++){let zt=J[Y];Ai(M,T,zt,zt.viewport)}}else Ai(M,T,H);L!==null&&(A.updateMultisampleRenderTarget(L),A.updateRenderTargetMipmap(L)),T.isScene===!0&&T.onAfterRender(E,T,H),Nt.resetDefaultState(),Q=-1,S=null,C.pop(),C.length>0?g=C[C.length-1]:g=null,d.pop(),d.length>0?M=d[d.length-1]:M=null};function vn(T,H,X,J){if(T.visible===!1)return;if(T.layers.test(H.layers)){if(T.isGroup)X=T.renderOrder;else if(T.isLOD)T.autoUpdate===!0&&T.update(H);else if(T.isLight)g.pushLight(T),T.castShadow&&g.pushShadow(T);else if(T.isSprite){if(!T.frustumCulled||q.intersectsSprite(T)){J&&Dt.setFromMatrixPosition(T.matrixWorld).applyMatrix4(Ot);let zt=rt.update(T),Xt=T.material;Xt.visible&&M.push(T,zt,Xt,X,Dt.z,null)}}else if((T.isMesh||T.isLine||T.isPoints)&&(!T.frustumCulled||q.intersectsObject(T))){let zt=rt.update(T),Xt=T.material;if(J&&(T.boundingSphere!==void 0?(T.boundingSphere===null&&T.computeBoundingSphere(),Dt.copy(T.boundingSphere.center)):(zt.boundingSphere===null&&zt.computeBoundingSphere(),Dt.copy(zt.boundingSphere.center)),Dt.applyMatrix4(T.matrixWorld).applyMatrix4(Ot)),Array.isArray(Xt)){let Zt=zt.groups;for(let Vt=0,Wt=Zt.length;Vt<Wt;Vt++){let Jt=Zt[Vt],de=Xt[Jt.materialIndex];de&&de.visible&&M.push(T,zt,de,X,Dt.z,Jt)}}else Xt.visible&&M.push(T,zt,Xt,X,Dt.z,null)}}let Et=T.children;for(let zt=0,Xt=Et.length;zt<Xt;zt++)vn(Et[zt],H,X,J)}function Ai(T,H,X,J){let Y=T.opaque,Et=T.transmissive,zt=T.transparent;g.setupLightsView(X),ct===!0&&Yt.setGlobalState(E.clippingPlanes,X),Et.length>0&&Ci(Y,Et,H,X),J&&Rt.viewport(R.copy(J)),Y.length>0&&Zn(Y,H,X),Et.length>0&&Zn(Et,H,X),zt.length>0&&Zn(zt,H,X),Rt.buffers.depth.setTest(!0),Rt.buffers.depth.setMask(!0),Rt.buffers.color.setMask(!0),Rt.setPolygonOffset(!1)}function Ci(T,H,X,J){if((X.isScene===!0?X.overrideMaterial:null)!==null)return;let Et=Gt.isWebGL2;It===null&&(It=new Ke(1,1,{generateMipmaps:!0,type:Ut.has("EXT_color_buffer_half_float")?gn:bi,minFilter:ur,samples:Et?4:0})),E.getDrawingBufferSize(Pt),Et?It.setSize(Pt.x,Pt.y):It.setSize(fa(Pt.x),fa(Pt.y));let zt=E.getRenderTarget();E.setRenderTarget(It),E.getClearColor(ft),I=E.getClearAlpha(),I<1&&E.setClearColor(16777215,.5),E.clear();let Xt=E.toneMapping;E.toneMapping=yi,Zn(T,X,J),A.updateMultisampleRenderTarget(It),A.updateRenderTargetMipmap(It);let Zt=!1;for(let Vt=0,Wt=H.length;Vt<Wt;Vt++){let Jt=H[Vt],de=Jt.object,Pe=Jt.geometry,ye=Jt.material,wn=Jt.group;if(ye.side===Dn&&de.layers.test(J.layers)){let _e=ye.side;ye.side=sn,ye.needsUpdate=!0,Ri(de,X,J,Pe,ye,wn),ye.side=_e,ye.needsUpdate=!0,Zt=!0}}Zt===!0&&(A.updateMultisampleRenderTarget(It),A.updateRenderTargetMipmap(It)),E.setRenderTarget(zt),E.setClearColor(ft,I),E.toneMapping=Xt}function Zn(T,H,X){let J=H.isScene===!0?H.overrideMaterial:null;for(let Y=0,Et=T.length;Y<Et;Y++){let zt=T[Y],Xt=zt.object,Zt=zt.geometry,Vt=J===null?zt.material:J,Wt=zt.group;Xt.layers.test(X.layers)&&Ri(Xt,H,X,Zt,Vt,Wt)}}function Ri(T,H,X,J,Y,Et){T.onBeforeRender(E,H,X,J,Y,Et),T.modelViewMatrix.multiplyMatrices(X.matrixWorldInverse,T.matrixWorld),T.normalMatrix.getNormalMatrix(T.modelViewMatrix),Y.onBeforeRender(E,H,X,J,T,Et),Y.transparent===!0&&Y.side===Dn&&Y.forceSinglePass===!1?(Y.side=sn,Y.needsUpdate=!0,E.renderBufferDirect(X,H,J,Y,T,Et),Y.side=Mi,Y.needsUpdate=!0,E.renderBufferDirect(X,H,J,Y,T,Et),Y.side=Dn):E.renderBufferDirect(X,H,J,Y,T,Et),T.onAfterRender(E,H,X,J,Y,Et)}function Bn(T,H,X){H.isScene!==!0&&(H=At);let J=$t.get(T),Y=g.state.lights,Et=g.state.shadowsArray,zt=Y.state.version,Xt=Tt.getParameters(T,Y.state,Et,H,X),Zt=Tt.getProgramCacheKey(Xt),Vt=J.programs;J.environment=T.isMeshStandardMaterial?H.environment:null,J.fog=H.fog,J.envMap=(T.isMeshStandardMaterial?W:b).get(T.envMap||J.environment),Vt===void 0&&(T.addEventListener("dispose",xt),Vt=new Map,J.programs=Vt);let Wt=Vt.get(Zt);if(Wt!==void 0){if(J.currentProgram===Wt&&J.lightsStateVersion===zt)return Er(T,Xt),Wt}else Xt.uniforms=Tt.getUniforms(T),T.onBuild(X,Xt,E),T.onBeforeCompile(Xt,E),Wt=Tt.acquireProgram(Xt,Zt),Vt.set(Zt,Wt),J.uniforms=Xt.uniforms;let Jt=J.uniforms;return(!T.isShaderMaterial&&!T.isRawShaderMaterial||T.clipping===!0)&&(Jt.clippingPlanes=Yt.uniform),Er(T,Xt),J.needsLights=$i(T),J.lightsStateVersion=zt,J.needsLights&&(Jt.ambientLightColor.value=Y.state.ambient,Jt.lightProbe.value=Y.state.probe,Jt.directionalLights.value=Y.state.directional,Jt.directionalLightShadows.value=Y.state.directionalShadow,Jt.spotLights.value=Y.state.spot,Jt.spotLightShadows.value=Y.state.spotShadow,Jt.rectAreaLights.value=Y.state.rectArea,Jt.ltc_1.value=Y.state.rectAreaLTC1,Jt.ltc_2.value=Y.state.rectAreaLTC2,Jt.pointLights.value=Y.state.point,Jt.pointLightShadows.value=Y.state.pointShadow,Jt.hemisphereLights.value=Y.state.hemi,Jt.directionalShadowMap.value=Y.state.directionalShadowMap,Jt.directionalShadowMatrix.value=Y.state.directionalShadowMatrix,Jt.spotShadowMap.value=Y.state.spotShadowMap,Jt.spotLightMatrix.value=Y.state.spotLightMatrix,Jt.spotLightMap.value=Y.state.spotLightMap,Jt.pointShadowMap.value=Y.state.pointShadowMap,Jt.pointShadowMatrix.value=Y.state.pointShadowMatrix),J.currentProgram=Wt,J.uniformsList=null,Wt}function Vs(T){if(T.uniformsList===null){let H=T.currentProgram.getUniforms();T.uniformsList=Cs.seqWithValue(H.seq,T.uniforms)}return T.uniformsList}function Er(T,H){let X=$t.get(T);X.outputColorSpace=H.outputColorSpace,X.batching=H.batching,X.instancing=H.instancing,X.instancingColor=H.instancingColor,X.skinning=H.skinning,X.morphTargets=H.morphTargets,X.morphNormals=H.morphNormals,X.morphColors=H.morphColors,X.morphTargetsCount=H.morphTargetsCount,X.numClippingPlanes=H.numClippingPlanes,X.numIntersection=H.numClipIntersection,X.vertexAlphas=H.vertexAlphas,X.vertexTangents=H.vertexTangents,X.toneMapping=H.toneMapping}function qa(T,H,X,J,Y){H.isScene!==!0&&(H=At),A.resetTextureUnits();let Et=H.fog,zt=J.isMeshStandardMaterial?H.environment:null,Xt=L===null?E.outputColorSpace:L.isXRRenderTarget===!0?L.texture.colorSpace:ri,Zt=(J.isMeshStandardMaterial?W:b).get(J.envMap||zt),Vt=J.vertexColors===!0&&!!X.attributes.color&&X.attributes.color.itemSize===4,Wt=!!X.attributes.tangent&&(!!J.normalMap||J.anisotropy>0),Jt=!!X.morphAttributes.position,de=!!X.morphAttributes.normal,Pe=!!X.morphAttributes.color,ye=yi;J.toneMapped&&(L===null||L.isXRRenderTarget===!0)&&(ye=E.toneMapping);let wn=X.morphAttributes.position||X.morphAttributes.normal||X.morphAttributes.color,_e=wn!==void 0?wn.length:0,Kt=$t.get(J),fn=g.state.lights;if(ct===!0&&(yt===!0||T!==S)){let Je=T===S&&J.id===Q;Yt.setState(J,T,Je)}let be=!1;J.version===Kt.__version?(Kt.needsLights&&Kt.lightsStateVersion!==fn.state.version||Kt.outputColorSpace!==Xt||Y.isBatchedMesh&&Kt.batching===!1||!Y.isBatchedMesh&&Kt.batching===!0||Y.isInstancedMesh&&Kt.instancing===!1||!Y.isInstancedMesh&&Kt.instancing===!0||Y.isSkinnedMesh&&Kt.skinning===!1||!Y.isSkinnedMesh&&Kt.skinning===!0||Y.isInstancedMesh&&Kt.instancingColor===!0&&Y.instanceColor===null||Y.isInstancedMesh&&Kt.instancingColor===!1&&Y.instanceColor!==null||Kt.envMap!==Zt||J.fog===!0&&Kt.fog!==Et||Kt.numClippingPlanes!==void 0&&(Kt.numClippingPlanes!==Yt.numPlanes||Kt.numIntersection!==Yt.numIntersection)||Kt.vertexAlphas!==Vt||Kt.vertexTangents!==Wt||Kt.morphTargets!==Jt||Kt.morphNormals!==de||Kt.morphColors!==Pe||Kt.toneMapping!==ye||Gt.isWebGL2===!0&&Kt.morphTargetsCount!==_e)&&(be=!0):(be=!0,Kt.__version=J.version);let zn=Kt.currentProgram;be===!0&&(zn=Bn(J,H,Y));let Gs=!1,Pi=!1,Ws=!1,We=zn.getUniforms(),kn=Kt.uniforms;if(Rt.useProgram(zn.program)&&(Gs=!0,Pi=!0,Ws=!0),J.id!==Q&&(Q=J.id,Pi=!0),Gs||S!==T){We.setValue(G,"projectionMatrix",T.projectionMatrix),We.setValue(G,"viewMatrix",T.matrixWorldInverse);let Je=We.map.cameraPosition;Je!==void 0&&Je.setValue(G,Dt.setFromMatrixPosition(T.matrixWorld)),Gt.logarithmicDepthBuffer&&We.setValue(G,"logDepthBufFC",2/(Math.log(T.far+1)/Math.LN2)),(J.isMeshPhongMaterial||J.isMeshToonMaterial||J.isMeshLambertMaterial||J.isMeshBasicMaterial||J.isMeshStandardMaterial||J.isShaderMaterial)&&We.setValue(G,"isOrthographic",T.isOrthographicCamera===!0),S!==T&&(S=T,Pi=!0,Ws=!0)}if(Y.isSkinnedMesh){We.setOptional(G,Y,"bindMatrix"),We.setOptional(G,Y,"bindMatrixInverse");let Je=Y.skeleton;Je&&(Gt.floatVertexTextures?(Je.boneTexture===null&&Je.computeBoneTexture(),We.setValue(G,"boneTexture",Je.boneTexture,A)):console.warn("THREE.WebGLRenderer: SkinnedMesh can only be used with WebGL 2. With WebGL 1 OES_texture_float and vertex textures support is required."))}Y.isBatchedMesh&&(We.setOptional(G,Y,"batchingTexture"),We.setValue(G,"batchingTexture",Y._matricesTexture,A));let Jn=X.morphAttributes;if((Jn.position!==void 0||Jn.normal!==void 0||Jn.color!==void 0&&Gt.isWebGL2===!0)&&P.update(Y,X,zn),(Pi||Kt.receiveShadow!==Y.receiveShadow)&&(Kt.receiveShadow=Y.receiveShadow,We.setValue(G,"receiveShadow",Y.receiveShadow)),J.isMeshGouraudMaterial&&J.envMap!==null&&(kn.envMap.value=Zt,kn.flipEnvMap.value=Zt.isCubeTexture&&Zt.isRenderTargetTexture===!1?-1:1),Pi&&(We.setValue(G,"toneMappingExposure",E.toneMappingExposure),Kt.needsLights&&Za(kn,Ws),Et&&J.fog===!0&&St.refreshFogUniforms(kn,Et),St.refreshMaterialUniforms(kn,J,Z,$,It),Cs.upload(G,Vs(Kt),kn,A)),J.isShaderMaterial&&J.uniformsNeedUpdate===!0&&(Cs.upload(G,Vs(Kt),kn,A),J.uniformsNeedUpdate=!1),J.isSpriteMaterial&&We.setValue(G,"center",Y.center),We.setValue(G,"modelViewMatrix",Y.modelViewMatrix),We.setValue(G,"normalMatrix",Y.normalMatrix),We.setValue(G,"modelMatrix",Y.matrixWorld),J.isShaderMaterial||J.isRawShaderMaterial){let Je=J.uniformsGroups;for(let Xs=0,Ys=Je.length;Xs<Ys;Xs++)if(Gt.isWebGL2){let Tr=Je[Xs];ee.update(Tr,zn),ee.bind(Tr,zn)}else console.warn("THREE.WebGLRenderer: Uniform Buffer Objects can only be used with WebGL 2.")}return zn}function Za(T,H){T.ambientLightColor.needsUpdate=H,T.lightProbe.needsUpdate=H,T.directionalLights.needsUpdate=H,T.directionalLightShadows.needsUpdate=H,T.pointLights.needsUpdate=H,T.pointLightShadows.needsUpdate=H,T.spotLights.needsUpdate=H,T.spotLightShadows.needsUpdate=H,T.rectAreaLights.needsUpdate=H,T.hemisphereLights.needsUpdate=H}function $i(T){return T.isMeshLambertMaterial||T.isMeshToonMaterial||T.isMeshPhongMaterial||T.isMeshStandardMaterial||T.isShadowMaterial||T.isShaderMaterial&&T.lights===!0}this.getActiveCubeFace=function(){return z},this.getActiveMipmapLevel=function(){return U},this.getRenderTarget=function(){return L},this.setRenderTargetTextures=function(T,H,X){$t.get(T.texture).__webglTexture=H,$t.get(T.depthTexture).__webglTexture=X;let J=$t.get(T);J.__hasExternalTextures=!0,J.__hasExternalTextures&&(J.__autoAllocateDepthBuffer=X===void 0,J.__autoAllocateDepthBuffer||Ut.has("WEBGL_multisampled_render_to_texture")===!0&&(console.warn("THREE.WebGLRenderer: Render-to-texture extension was disabled because an external texture was provided"),J.__useRenderToTexture=!1))},this.setRenderTargetFramebuffer=function(T,H){let X=$t.get(T);X.__webglFramebuffer=H,X.__useDefaultFramebuffer=H===void 0},this.setRenderTarget=function(T,H=0,X=0){L=T,z=H,U=X;let J=!0,Y=null,Et=!1,zt=!1;if(T){let Zt=$t.get(T);Zt.__useDefaultFramebuffer!==void 0?(Rt.bindFramebuffer(G.FRAMEBUFFER,null),J=!1):Zt.__webglFramebuffer===void 0?A.setupRenderTarget(T):Zt.__hasExternalTextures&&A.rebindTextures(T,$t.get(T.texture).__webglTexture,$t.get(T.depthTexture).__webglTexture);let Vt=T.texture;(Vt.isData3DTexture||Vt.isDataArrayTexture||Vt.isCompressedArrayTexture)&&(zt=!0);let Wt=$t.get(T).__webglFramebuffer;T.isWebGLCubeRenderTarget?(Array.isArray(Wt[H])?Y=Wt[H][X]:Y=Wt[H],Et=!0):Gt.isWebGL2&&T.samples>0&&A.useMultisampledRTT(T)===!1?Y=$t.get(T).__webglMultisampledFramebuffer:Array.isArray(Wt)?Y=Wt[X]:Y=Wt,R.copy(T.viewport),V.copy(T.scissor),nt=T.scissorTest}else R.copy(st).multiplyScalar(Z).floor(),V.copy(it).multiplyScalar(Z).floor(),nt=vt;if(Rt.bindFramebuffer(G.FRAMEBUFFER,Y)&&Gt.drawBuffers&&J&&Rt.drawBuffers(T,Y),Rt.viewport(R),Rt.scissor(V),Rt.setScissorTest(nt),Et){let Zt=$t.get(T.texture);G.framebufferTexture2D(G.FRAMEBUFFER,G.COLOR_ATTACHMENT0,G.TEXTURE_CUBE_MAP_POSITIVE_X+H,Zt.__webglTexture,X)}else if(zt){let Zt=$t.get(T.texture),Vt=H||0;G.framebufferTextureLayer(G.FRAMEBUFFER,G.COLOR_ATTACHMENT0,Zt.__webglTexture,X||0,Vt)}Q=-1},this.readRenderTargetPixels=function(T,H,X,J,Y,Et,zt){if(!(T&&T.isWebGLRenderTarget)){console.error("THREE.WebGLRenderer.readRenderTargetPixels: renderTarget is not THREE.WebGLRenderTarget.");return}let Xt=$t.get(T).__webglFramebuffer;if(T.isWebGLCubeRenderTarget&&zt!==void 0&&(Xt=Xt[zt]),Xt){Rt.bindFramebuffer(G.FRAMEBUFFER,Xt);try{let Zt=T.texture,Vt=Zt.format,Wt=Zt.type;if(Vt!==Nn&&pt.convert(Vt)!==G.getParameter(G.IMPLEMENTATION_COLOR_READ_FORMAT)){console.error("THREE.WebGLRenderer.readRenderTargetPixels: renderTarget is not in RGBA or implementation defined format.");return}let Jt=Wt===gn&&(Ut.has("EXT_color_buffer_half_float")||Gt.isWebGL2&&Ut.has("EXT_color_buffer_float"));if(Wt!==bi&&pt.convert(Wt)!==G.getParameter(G.IMPLEMENTATION_COLOR_READ_TYPE)&&!(Wt===_i&&(Gt.isWebGL2||Ut.has("OES_texture_float")||Ut.has("WEBGL_color_buffer_float")))&&!Jt){console.error("THREE.WebGLRenderer.readRenderTargetPixels: renderTarget is not in UnsignedByteType or implementation defined type.");return}H>=0&&H<=T.width-J&&X>=0&&X<=T.height-Y&&G.readPixels(H,X,J,Y,pt.convert(Vt),pt.convert(Wt),Et)}finally{let Zt=L!==null?$t.get(L).__webglFramebuffer:null;Rt.bindFramebuffer(G.FRAMEBUFFER,Zt)}}},this.copyFramebufferToTexture=function(T,H,X=0){let J=Math.pow(2,-X),Y=Math.floor(H.image.width*J),Et=Math.floor(H.image.height*J);A.setTexture2D(H,0),G.copyTexSubImage2D(G.TEXTURE_2D,X,0,0,T.x,T.y,Y,Et),Rt.unbindTexture()},this.copyTextureToTexture=function(T,H,X,J=0){let Y=H.image.width,Et=H.image.height,zt=pt.convert(X.format),Xt=pt.convert(X.type);A.setTexture2D(X,0),G.pixelStorei(G.UNPACK_FLIP_Y_WEBGL,X.flipY),G.pixelStorei(G.UNPACK_PREMULTIPLY_ALPHA_WEBGL,X.premultiplyAlpha),G.pixelStorei(G.UNPACK_ALIGNMENT,X.unpackAlignment),H.isDataTexture?G.texSubImage2D(G.TEXTURE_2D,J,T.x,T.y,Y,Et,zt,Xt,H.image.data):H.isCompressedTexture?G.compressedTexSubImage2D(G.TEXTURE_2D,J,T.x,T.y,H.mipmaps[0].width,H.mipmaps[0].height,zt,H.mipmaps[0].data):G.texSubImage2D(G.TEXTURE_2D,J,T.x,T.y,zt,Xt,H.image),J===0&&X.generateMipmaps&&G.generateMipmap(G.TEXTURE_2D),Rt.unbindTexture()},this.copyTextureToTexture3D=function(T,H,X,J,Y=0){if(E.isWebGL1Renderer){console.warn("THREE.WebGLRenderer.copyTextureToTexture3D: can only be used with WebGL2.");return}let Et=T.max.x-T.min.x+1,zt=T.max.y-T.min.y+1,Xt=T.max.z-T.min.z+1,Zt=pt.convert(J.format),Vt=pt.convert(J.type),Wt;if(J.isData3DTexture)A.setTexture3D(J,0),Wt=G.TEXTURE_3D;else if(J.isDataArrayTexture||J.isCompressedArrayTexture)A.setTexture2DArray(J,0),Wt=G.TEXTURE_2D_ARRAY;else{console.warn("THREE.WebGLRenderer.copyTextureToTexture3D: only supports THREE.DataTexture3D and THREE.DataTexture2DArray.");return}G.pixelStorei(G.UNPACK_FLIP_Y_WEBGL,J.flipY),G.pixelStorei(G.UNPACK_PREMULTIPLY_ALPHA_WEBGL,J.premultiplyAlpha),G.pixelStorei(G.UNPACK_ALIGNMENT,J.unpackAlignment);let Jt=G.getParameter(G.UNPACK_ROW_LENGTH),de=G.getParameter(G.UNPACK_IMAGE_HEIGHT),Pe=G.getParameter(G.UNPACK_SKIP_PIXELS),ye=G.getParameter(G.UNPACK_SKIP_ROWS),wn=G.getParameter(G.UNPACK_SKIP_IMAGES),_e=X.isCompressedTexture?X.mipmaps[Y]:X.image;G.pixelStorei(G.UNPACK_ROW_LENGTH,_e.width),G.pixelStorei(G.UNPACK_IMAGE_HEIGHT,_e.height),G.pixelStorei(G.UNPACK_SKIP_PIXELS,T.min.x),G.pixelStorei(G.UNPACK_SKIP_ROWS,T.min.y),G.pixelStorei(G.UNPACK_SKIP_IMAGES,T.min.z),X.isDataTexture||X.isData3DTexture?G.texSubImage3D(Wt,Y,H.x,H.y,H.z,Et,zt,Xt,Zt,Vt,_e.data):X.isCompressedArrayTexture?(console.warn("THREE.WebGLRenderer.copyTextureToTexture3D: untested support for compressed srcTexture."),G.compressedTexSubImage3D(Wt,Y,H.x,H.y,H.z,Et,zt,Xt,Zt,_e.data)):G.texSubImage3D(Wt,Y,H.x,H.y,H.z,Et,zt,Xt,Zt,Vt,_e),G.pixelStorei(G.UNPACK_ROW_LENGTH,Jt),G.pixelStorei(G.UNPACK_IMAGE_HEIGHT,de),G.pixelStorei(G.UNPACK_SKIP_PIXELS,Pe),G.pixelStorei(G.UNPACK_SKIP_ROWS,ye),G.pixelStorei(G.UNPACK_SKIP_IMAGES,wn),Y===0&&J.generateMipmaps&&G.generateMipmap(Wt),Rt.unbindTexture()},this.initTexture=function(T){T.isCubeTexture?A.setTextureCube(T,0):T.isData3DTexture?A.setTexture3D(T,0):T.isDataArrayTexture||T.isCompressedArrayTexture?A.setTexture2DArray(T,0):A.setTexture2D(T,0),Rt.unbindTexture()},this.resetState=function(){z=0,U=0,L=null,Rt.reset(),Nt.reset()},typeof __THREE_DEVTOOLS__<"u"&&__THREE_DEVTOOLS__.dispatchEvent(new CustomEvent("observe",{detail:this}))}get coordinateSystem(){return ii}get outputColorSpace(){return this._outputColorSpace}set outputColorSpace(t){this._outputColorSpace=t;let e=this.getContext();e.drawingBufferColorSpace=t===Pl?"display-p3":"srgb",e.unpackColorSpace=fe.workingColorSpace===Ba?"display-p3":"srgb"}get outputEncoding(){return console.warn("THREE.WebGLRenderer: Property .outputEncoding has been removed. Use .outputColorSpace instead."),this.outputColorSpace===Ce?Wi:Jh}set outputEncoding(t){console.warn("THREE.WebGLRenderer: Property .outputEncoding has been removed. Use .outputColorSpace instead."),this.outputColorSpace=t===Wi?Ce:ri}get useLegacyLights(){return console.warn("THREE.WebGLRenderer: The property .useLegacyLights has been deprecated. Migrate your lighting according to the following guide: https://discourse.threejs.org/t/updates-to-lighting-in-three-js-r155/53733."),this._useLegacyLights}set useLegacyLights(t){console.warn("THREE.WebGLRenderer: The property .useLegacyLights has been deprecated. Migrate your lighting according to the following guide: https://discourse.threejs.org/t/updates-to-lighting-in-three-js-r155/53733."),this._useLegacyLights=t}},cl=class extends gr{};cl.prototype.isWebGL1Renderer=!0;var Ea=class i{constructor(t,e=25e-5){this.isFogExp2=!0,this.name="",this.color=new qt(t),this.density=e}clone(){return new i(this.color,this.density)}toJSON(){return{type:"FogExp2",name:this.name,color:this.color.getHex(),density:this.density}}};var Ta=class extends an{constructor(){super(),this.isScene=!0,this.type="Scene",this.background=null,this.environment=null,this.fog=null,this.backgroundBlurriness=0,this.backgroundIntensity=1,this.overrideMaterial=null,typeof __THREE_DEVTOOLS__<"u"&&__THREE_DEVTOOLS__.dispatchEvent(new CustomEvent("observe",{detail:this}))}copy(t,e){return super.copy(t,e),t.background!==null&&(this.background=t.background.clone()),t.environment!==null&&(this.environment=t.environment.clone()),t.fog!==null&&(this.fog=t.fog.clone()),this.backgroundBlurriness=t.backgroundBlurriness,this.backgroundIntensity=t.backgroundIntensity,t.overrideMaterial!==null&&(this.overrideMaterial=t.overrideMaterial.clone()),this.matrixAutoUpdate=t.matrixAutoUpdate,this}toJSON(t){let e=super.toJSON(t);return this.fog!==null&&(e.object.fog=this.fog.toJSON()),this.backgroundBlurriness>0&&(e.object.backgroundBlurriness=this.backgroundBlurriness),this.backgroundIntensity!==1&&(e.object.backgroundIntensity=this.backgroundIntensity),e}};var Aa=class extends rn{constructor(t,e,n,s=1){super(t,e,n),this.isInstancedBufferAttribute=!0,this.meshPerAttribute=s}copy(t){return super.copy(t),this.meshPerAttribute=t.meshPerAttribute,this}toJSON(){let t=super.toJSON();return t.meshPerAttribute=this.meshPerAttribute,t.isInstancedBufferAttribute=!0,t}},Ms=new ve,Ph=new ve,na=[],Lh=new ai,U0=new ve,ir=new He,sr=new Si,Ca=class extends He{constructor(t,e,n){super(t,e),this.isInstancedMesh=!0,this.instanceMatrix=new Aa(new Float32Array(n*16),16),this.instanceColor=null,this.count=n,this.boundingBox=null,this.boundingSphere=null;for(let s=0;s<n;s++)this.setMatrixAt(s,U0)}computeBoundingBox(){let t=this.geometry,e=this.count;this.boundingBox===null&&(this.boundingBox=new ai),t.boundingBox===null&&t.computeBoundingBox(),this.boundingBox.makeEmpty();for(let n=0;n<e;n++)this.getMatrixAt(n,Ms),Lh.copy(t.boundingBox).applyMatrix4(Ms),this.boundingBox.union(Lh)}computeBoundingSphere(){let t=this.geometry,e=this.count;this.boundingSphere===null&&(this.boundingSphere=new Si),t.boundingSphere===null&&t.computeBoundingSphere(),this.boundingSphere.makeEmpty();for(let n=0;n<e;n++)this.getMatrixAt(n,Ms),sr.copy(t.boundingSphere).applyMatrix4(Ms),this.boundingSphere.union(sr)}copy(t,e){return super.copy(t,e),this.instanceMatrix.copy(t.instanceMatrix),t.instanceColor!==null&&(this.instanceColor=t.instanceColor.clone()),this.count=t.count,t.boundingBox!==null&&(this.boundingBox=t.boundingBox.clone()),t.boundingSphere!==null&&(this.boundingSphere=t.boundingSphere.clone()),this}getColorAt(t,e){e.fromArray(this.instanceColor.array,t*3)}getMatrixAt(t,e){e.fromArray(this.instanceMatrix.array,t*16)}raycast(t,e){let n=this.matrixWorld,s=this.count;if(ir.geometry=this.geometry,ir.material=this.material,ir.material!==void 0&&(this.boundingSphere===null&&this.computeBoundingSphere(),sr.copy(this.boundingSphere),sr.applyMatrix4(n),t.ray.intersectsSphere(sr)!==!1))for(let r=0;r<s;r++){this.getMatrixAt(r,Ms),Ph.multiplyMatrices(n,Ms),ir.matrixWorld=Ph,ir.raycast(t,na);for(let o=0,a=na.length;o<a;o++){let l=na[o];l.instanceId=r,l.object=this,e.push(l)}na.length=0}}setColorAt(t,e){this.instanceColor===null&&(this.instanceColor=new Aa(new Float32Array(this.instanceMatrix.count*3),3)),e.toArray(this.instanceColor.array,t*3)}setMatrixAt(t,e){e.toArray(this.instanceMatrix.array,t*16)}updateMorphTargets(){}dispose(){this.dispatchEvent({type:"dispose"})}};var Ns=class extends wi{constructor(t){super(),this.isPointsMaterial=!0,this.type="PointsMaterial",this.color=new qt(16777215),this.map=null,this.alphaMap=null,this.size=1,this.sizeAttenuation=!0,this.fog=!0,this.setValues(t)}copy(t){return super.copy(t),this.color.copy(t.color),this.map=t.map,this.alphaMap=t.alphaMap,this.size=t.size,this.sizeAttenuation=t.sizeAttenuation,this.fog=t.fog,this}},Ih=new ve,hl=new Xi,ia=new Si,sa=new B,xr=class extends an{constructor(t=new hn,e=new Ns){super(),this.isPoints=!0,this.type="Points",this.geometry=t,this.material=e,this.updateMorphTargets()}copy(t,e){return super.copy(t,e),this.material=Array.isArray(t.material)?t.material.slice():t.material,this.geometry=t.geometry,this}raycast(t,e){let n=this.geometry,s=this.matrixWorld,r=t.params.Points.threshold,o=n.drawRange;if(n.boundingSphere===null&&n.computeBoundingSphere(),ia.copy(n.boundingSphere),ia.applyMatrix4(s),ia.radius+=r,t.ray.intersectsSphere(ia)===!1)return;Ih.copy(s).invert(),hl.copy(t.ray).applyMatrix4(Ih);let a=r/((this.scale.x+this.scale.y+this.scale.z)/3),l=a*a,c=n.index,f=n.attributes.position;if(c!==null){let p=Math.max(0,o.start),x=Math.min(c.count,o.start+o.count);for(let y=p,M=x;y<M;y++){let g=c.getX(y);sa.fromBufferAttribute(f,g),Dh(sa,g,l,s,t,e,this)}}else{let p=Math.max(0,o.start),x=Math.min(f.count,o.start+o.count);for(let y=p,M=x;y<M;y++)sa.fromBufferAttribute(f,y),Dh(sa,y,l,s,t,e,this)}}updateMorphTargets(){let e=this.geometry.morphAttributes,n=Object.keys(e);if(n.length>0){let s=e[n[0]];if(s!==void 0){this.morphTargetInfluences=[],this.morphTargetDictionary={};for(let r=0,o=s.length;r<o;r++){let a=s[r].name||String(r);this.morphTargetInfluences.push(0),this.morphTargetDictionary[a]=r}}}}};function Dh(i,t,e,n,s,r,o){let a=hl.distanceSqToPoint(i);if(a<e){let l=new B;hl.closestPointToPoint(i,l),l.applyMatrix4(n);let c=s.ray.origin.distanceTo(l);if(c<s.near||c>s.far)return;r.push({distance:c,distanceToRay:Math.sqrt(a),point:l,index:t,face:null,object:o})}}var Os=class extends Sn{constructor(t,e,n,s,r,o,a,l,c){super(t,e,n,s,r,o,a,l,c),this.isCanvasTexture=!0,this.needsUpdate=!0}};var _r=class i extends hn{constructor(t=1,e=32,n=0,s=Math.PI*2){super(),this.type="CircleGeometry",this.parameters={radius:t,segments:e,thetaStart:n,thetaLength:s},e=Math.max(3,e);let r=[],o=[],a=[],l=[],c=new B,u=new Lt;o.push(0,0,0),a.push(0,0,1),l.push(.5,.5);for(let f=0,p=3;f<=e;f++,p+=3){let x=n+f/e*s;c.x=t*Math.cos(x),c.y=t*Math.sin(x),o.push(c.x,c.y,c.z),a.push(0,0,1),u.x=(o[p]/t+1)/2,u.y=(o[p+1]/t+1)/2,l.push(u.x,u.y)}for(let f=1;f<=e;f++)r.push(f,f+1,0);this.setIndex(r),this.setAttribute("position",new Ze(o,3)),this.setAttribute("normal",new Ze(a,3)),this.setAttribute("uv",new Ze(l,2))}copy(t){return super.copy(t),this.parameters=Object.assign({},t.parameters),this}static fromJSON(t){return new i(t.radius,t.segments,t.thetaStart,t.thetaLength)}};var Ra=class i extends hn{constructor(t=1,e=32,n=16,s=0,r=Math.PI*2,o=0,a=Math.PI){super(),this.type="SphereGeometry",this.parameters={radius:t,widthSegments:e,heightSegments:n,phiStart:s,phiLength:r,thetaStart:o,thetaLength:a},e=Math.max(3,Math.floor(e)),n=Math.max(2,Math.floor(n));let l=Math.min(o+a,Math.PI),c=0,u=[],f=new B,p=new B,x=[],y=[],M=[],g=[];for(let d=0;d<=n;d++){let C=[],E=d/n,D=0;d===0&&o===0?D=.5/e:d===n&&l===Math.PI&&(D=-.5/e);for(let z=0;z<=e;z++){let U=z/e;f.x=-t*Math.cos(s+U*r)*Math.sin(o+E*a),f.y=t*Math.cos(o+E*a),f.z=t*Math.sin(s+U*r)*Math.sin(o+E*a),y.push(f.x,f.y,f.z),p.copy(f).normalize(),M.push(p.x,p.y,p.z),g.push(U+D,1-E),C.push(c++)}u.push(C)}for(let d=0;d<n;d++)for(let C=0;C<e;C++){let E=u[d][C+1],D=u[d][C],z=u[d+1][C],U=u[d+1][C+1];(d!==0||o>0)&&x.push(E,D,U),(d!==n-1||l<Math.PI)&&x.push(D,z,U)}this.setIndex(x),this.setAttribute("position",new Ze(y,3)),this.setAttribute("normal",new Ze(M,3)),this.setAttribute("uv",new Ze(g,2))}copy(t){return super.copy(t),this.parameters=Object.assign({},t.parameters),this}static fromJSON(t){return new i(t.radius,t.widthSegments,t.heightSegments,t.phiStart,t.phiLength,t.thetaStart,t.thetaLength)}};var Pa=class extends Ne{constructor(t){super(t),this.isRawShaderMaterial=!0,this.type="RawShaderMaterial"}},vr=class extends wi{constructor(t){super(),this.isMeshStandardMaterial=!0,this.defines={STANDARD:""},this.type="MeshStandardMaterial",this.color=new qt(16777215),this.roughness=1,this.metalness=0,this.map=null,this.lightMap=null,this.lightMapIntensity=1,this.aoMap=null,this.aoMapIntensity=1,this.emissive=new qt(0),this.emissiveIntensity=1,this.emissiveMap=null,this.bumpMap=null,this.bumpScale=1,this.normalMap=null,this.normalMapType=jh,this.normalScale=new Lt(1,1),this.displacementMap=null,this.displacementScale=1,this.displacementBias=0,this.roughnessMap=null,this.metalnessMap=null,this.alphaMap=null,this.envMap=null,this.envMapIntensity=1,this.wireframe=!1,this.wireframeLinewidth=1,this.wireframeLinecap="round",this.wireframeLinejoin="round",this.flatShading=!1,this.fog=!0,this.setValues(t)}copy(t){return super.copy(t),this.defines={STANDARD:""},this.color.copy(t.color),this.roughness=t.roughness,this.metalness=t.metalness,this.map=t.map,this.lightMap=t.lightMap,this.lightMapIntensity=t.lightMapIntensity,this.aoMap=t.aoMap,this.aoMapIntensity=t.aoMapIntensity,this.emissive.copy(t.emissive),this.emissiveMap=t.emissiveMap,this.emissiveIntensity=t.emissiveIntensity,this.bumpMap=t.bumpMap,this.bumpScale=t.bumpScale,this.normalMap=t.normalMap,this.normalMapType=t.normalMapType,this.normalScale.copy(t.normalScale),this.displacementMap=t.displacementMap,this.displacementScale=t.displacementScale,this.displacementBias=t.displacementBias,this.roughnessMap=t.roughnessMap,this.metalnessMap=t.metalnessMap,this.alphaMap=t.alphaMap,this.envMap=t.envMap,this.envMapIntensity=t.envMapIntensity,this.wireframe=t.wireframe,this.wireframeLinewidth=t.wireframeLinewidth,this.wireframeLinecap=t.wireframeLinecap,this.wireframeLinejoin=t.wireframeLinejoin,this.flatShading=t.flatShading,this.fog=t.fog,this}};function ra(i,t,e){return!i||!e&&i.constructor===t?i:typeof t.BYTES_PER_ELEMENT=="number"?new t(i):Array.prototype.slice.call(i)}function N0(i){return ArrayBuffer.isView(i)&&!(i instanceof DataView)}var Fs=class{constructor(t,e,n,s){this.parameterPositions=t,this._cachedIndex=0,this.resultBuffer=s!==void 0?s:new e.constructor(n),this.sampleValues=e,this.valueSize=n,this.settings=null,this.DefaultSettings_={}}evaluate(t){let e=this.parameterPositions,n=this._cachedIndex,s=e[n],r=e[n-1];n:{t:{let o;e:{i:if(!(t<s)){for(let a=n+2;;){if(s===void 0){if(t<r)break i;return n=e.length,this._cachedIndex=n,this.copySampleValue_(n-1)}if(n===a)break;if(r=s,s=e[++n],t<s)break t}o=e.length;break e}if(!(t>=r)){let a=e[1];t<a&&(n=2,r=a);for(let l=n-2;;){if(r===void 0)return this._cachedIndex=0,this.copySampleValue_(0);if(n===l)break;if(s=r,r=e[--n-1],t>=r)break t}o=n,n=0;break e}break n}for(;n<o;){let a=n+o>>>1;t<e[a]?o=a:n=a+1}if(s=e[n],r=e[n-1],r===void 0)return this._cachedIndex=0,this.copySampleValue_(0);if(s===void 0)return n=e.length,this._cachedIndex=n,this.copySampleValue_(n-1)}this._cachedIndex=n,this.intervalChanged_(n,r,s)}return this.interpolate_(n,r,t,s)}getSettings_(){return this.settings||this.DefaultSettings_}copySampleValue_(t){let e=this.resultBuffer,n=this.sampleValues,s=this.valueSize,r=t*s;for(let o=0;o!==s;++o)e[o]=n[r+o];return e}interpolate_(){throw new Error("call to abstract method")}intervalChanged_(){}},ul=class extends Fs{constructor(t,e,n,s){super(t,e,n,s),this._weightPrev=-0,this._offsetPrev=-0,this._weightNext=-0,this._offsetNext=-0,this.DefaultSettings_={endingStart:kc,endingEnd:kc}}intervalChanged_(t,e,n){let s=this.parameterPositions,r=t-2,o=t+1,a=s[r],l=s[o];if(a===void 0)switch(this.getSettings_().endingStart){case Hc:r=t,a=2*e-n;break;case Vc:r=s.length-2,a=e+s[r]-s[r+1];break;default:r=t,a=n}if(l===void 0)switch(this.getSettings_().endingEnd){case Hc:o=t,l=2*n-e;break;case Vc:o=1,l=n+s[1]-s[0];break;default:o=t-1,l=e}let c=(n-e)*.5,u=this.valueSize;this._weightPrev=c/(e-a),this._weightNext=c/(l-n),this._offsetPrev=r*u,this._offsetNext=o*u}interpolate_(t,e,n,s){let r=this.resultBuffer,o=this.sampleValues,a=this.valueSize,l=t*a,c=l-a,u=this._offsetPrev,f=this._offsetNext,p=this._weightPrev,x=this._weightNext,y=(n-e)/(s-e),M=y*y,g=M*y,d=-p*g+2*p*M-p*y,C=(1+p)*g+(-1.5-2*p)*M+(-.5+p)*y+1,E=(-1-x)*g+(1.5+x)*M+.5*y,D=x*g-x*M;for(let z=0;z!==a;++z)r[z]=d*o[u+z]+C*o[c+z]+E*o[l+z]+D*o[f+z];return r}},dl=class extends Fs{constructor(t,e,n,s){super(t,e,n,s)}interpolate_(t,e,n,s){let r=this.resultBuffer,o=this.sampleValues,a=this.valueSize,l=t*a,c=l-a,u=(n-e)/(s-e),f=1-u;for(let p=0;p!==a;++p)r[p]=o[c+p]*f+o[l+p]*u;return r}},fl=class extends Fs{constructor(t,e,n,s){super(t,e,n,s)}interpolate_(t){return this.copySampleValue_(t-1)}},Fn=class{constructor(t,e,n,s){if(t===void 0)throw new Error("THREE.KeyframeTrack: track name is undefined");if(e===void 0||e.length===0)throw new Error("THREE.KeyframeTrack: no keyframes in track named "+t);this.name=t,this.times=ra(e,this.TimeBufferType),this.values=ra(n,this.ValueBufferType),this.setInterpolation(s||this.DefaultInterpolation)}static toJSON(t){let e=t.constructor,n;if(e.toJSON!==this.toJSON)n=e.toJSON(t);else{n={name:t.name,times:ra(t.times,Array),values:ra(t.values,Array)};let s=t.getInterpolation();s!==t.DefaultInterpolation&&(n.interpolation=s)}return n.type=t.ValueTypeName,n}InterpolantFactoryMethodDiscrete(t){return new fl(this.times,this.values,this.getValueSize(),t)}InterpolantFactoryMethodLinear(t){return new dl(this.times,this.values,this.getValueSize(),t)}InterpolantFactoryMethodSmooth(t){return new ul(this.times,this.values,this.getValueSize(),t)}setInterpolation(t){let e;switch(t){case oa:e=this.InterpolantFactoryMethodDiscrete;break;case la:e=this.InterpolantFactoryMethodLinear;break;case xo:e=this.InterpolantFactoryMethodSmooth;break}if(e===void 0){let n="unsupported interpolation for "+this.ValueTypeName+" keyframe track named "+this.name;if(this.createInterpolant===void 0)if(t!==this.DefaultInterpolation)this.setInterpolation(this.DefaultInterpolation);else throw new Error(n);return console.warn("THREE.KeyframeTrack:",n),this}return this.createInterpolant=e,this}getInterpolation(){switch(this.createInterpolant){case this.InterpolantFactoryMethodDiscrete:return oa;case this.InterpolantFactoryMethodLinear:return la;case this.InterpolantFactoryMethodSmooth:return xo}}getValueSize(){return this.values.length/this.times.length}shift(t){if(t!==0){let e=this.times;for(let n=0,s=e.length;n!==s;++n)e[n]+=t}return this}scale(t){if(t!==1){let e=this.times;for(let n=0,s=e.length;n!==s;++n)e[n]*=t}return this}trim(t,e){let n=this.times,s=n.length,r=0,o=s-1;for(;r!==s&&n[r]<t;)++r;for(;o!==-1&&n[o]>e;)--o;if(++o,r!==0||o!==s){r>=o&&(o=Math.max(o,1),r=o-1);let a=this.getValueSize();this.times=n.slice(r,o),this.values=this.values.slice(r*a,o*a)}return this}validate(){let t=!0,e=this.getValueSize();e-Math.floor(e)!==0&&(console.error("THREE.KeyframeTrack: Invalid value size in track.",this),t=!1);let n=this.times,s=this.values,r=n.length;r===0&&(console.error("THREE.KeyframeTrack: Track is empty.",this),t=!1);let o=null;for(let a=0;a!==r;a++){let l=n[a];if(typeof l=="number"&&isNaN(l)){console.error("THREE.KeyframeTrack: Time is not a valid number.",this,a,l),t=!1;break}if(o!==null&&o>l){console.error("THREE.KeyframeTrack: Out of order keys.",this,a,l,o),t=!1;break}o=l}if(s!==void 0&&N0(s))for(let a=0,l=s.length;a!==l;++a){let c=s[a];if(isNaN(c)){console.error("THREE.KeyframeTrack: Value is not a valid number.",this,a,c),t=!1;break}}return t}optimize(){let t=this.times.slice(),e=this.values.slice(),n=this.getValueSize(),s=this.getInterpolation()===xo,r=t.length-1,o=1;for(let a=1;a<r;++a){let l=!1,c=t[a],u=t[a+1];if(c!==u&&(a!==1||c!==t[0]))if(s)l=!0;else{let f=a*n,p=f-n,x=f+n;for(let y=0;y!==n;++y){let M=e[f+y];if(M!==e[p+y]||M!==e[x+y]){l=!0;break}}}if(l){if(a!==o){t[o]=t[a];let f=a*n,p=o*n;for(let x=0;x!==n;++x)e[p+x]=e[f+x]}++o}}if(r>0){t[o]=t[r];for(let a=r*n,l=o*n,c=0;c!==n;++c)e[l+c]=e[a+c];++o}return o!==t.length?(this.times=t.slice(0,o),this.values=e.slice(0,o*n)):(this.times=t,this.values=e),this}clone(){let t=this.times.slice(),e=this.values.slice(),n=this.constructor,s=new n(this.name,t,e);return s.createInterpolant=this.createInterpolant,s}};Fn.prototype.TimeBufferType=Float32Array;Fn.prototype.ValueBufferType=Float32Array;Fn.prototype.DefaultInterpolation=la;var qi=class extends Fn{};qi.prototype.ValueTypeName="bool";qi.prototype.ValueBufferType=Array;qi.prototype.DefaultInterpolation=oa;qi.prototype.InterpolantFactoryMethodLinear=void 0;qi.prototype.InterpolantFactoryMethodSmooth=void 0;var pl=class extends Fn{};pl.prototype.ValueTypeName="color";var ml=class extends Fn{};ml.prototype.ValueTypeName="number";var gl=class extends Fs{constructor(t,e,n,s){super(t,e,n,s)}interpolate_(t,e,n,s){let r=this.resultBuffer,o=this.sampleValues,a=this.valueSize,l=(n-e)/(s-e),c=t*a;for(let u=c+a;c!==u;c+=4)On.slerpFlat(r,0,o,c-a,o,c,l);return r}},yr=class extends Fn{InterpolantFactoryMethodLinear(t){return new gl(this.times,this.values,this.getValueSize(),t)}};yr.prototype.ValueTypeName="quaternion";yr.prototype.DefaultInterpolation=la;yr.prototype.InterpolantFactoryMethodSmooth=void 0;var Zi=class extends Fn{};Zi.prototype.ValueTypeName="string";Zi.prototype.ValueBufferType=Array;Zi.prototype.DefaultInterpolation=oa;Zi.prototype.InterpolantFactoryMethodLinear=void 0;Zi.prototype.InterpolantFactoryMethodSmooth=void 0;var xl=class extends Fn{};xl.prototype.ValueTypeName="vector";var _l=class{constructor(t,e,n){let s=this,r=!1,o=0,a=0,l,c=[];this.onStart=void 0,this.onLoad=t,this.onProgress=e,this.onError=n,this.itemStart=function(u){a++,r===!1&&s.onStart!==void 0&&s.onStart(u,o,a),r=!0},this.itemEnd=function(u){o++,s.onProgress!==void 0&&s.onProgress(u,o,a),o===a&&(r=!1,s.onLoad!==void 0&&s.onLoad())},this.itemError=function(u){s.onError!==void 0&&s.onError(u)},this.resolveURL=function(u){return l?l(u):u},this.setURLModifier=function(u){return l=u,this},this.addHandler=function(u,f){return c.push(u,f),this},this.removeHandler=function(u){let f=c.indexOf(u);return f!==-1&&c.splice(f,2),this},this.getHandler=function(u){for(let f=0,p=c.length;f<p;f+=2){let x=c[f],y=c[f+1];if(x.global&&(x.lastIndex=0),x.test(u))return y}return null}}},O0=new _l,vl=class{constructor(t){this.manager=t!==void 0?t:O0,this.crossOrigin="anonymous",this.withCredentials=!1,this.path="",this.resourcePath="",this.requestHeader={}}load(){}loadAsync(t,e){let n=this;return new Promise(function(s,r){n.load(t,s,e,r)})}parse(){}setCrossOrigin(t){return this.crossOrigin=t,this}setWithCredentials(t){return this.withCredentials=t,this}setPath(t){return this.path=t,this}setResourcePath(t){return this.resourcePath=t,this}setRequestHeader(t){return this.requestHeader=t,this}};vl.DEFAULT_MATERIAL_NAME="__DEFAULT";var br=class extends an{constructor(t,e=1){super(),this.isLight=!0,this.type="Light",this.color=new qt(t),this.intensity=e}dispose(){}copy(t,e){return super.copy(t,e),this.color.copy(t.color),this.intensity=t.intensity,this}toJSON(t){let e=super.toJSON(t);return e.object.color=this.color.getHex(),e.object.intensity=this.intensity,this.groundColor!==void 0&&(e.object.groundColor=this.groundColor.getHex()),this.distance!==void 0&&(e.object.distance=this.distance),this.angle!==void 0&&(e.object.angle=this.angle),this.decay!==void 0&&(e.object.decay=this.decay),this.penumbra!==void 0&&(e.object.penumbra=this.penumbra),this.shadow!==void 0&&(e.object.shadow=this.shadow.toJSON()),e}},La=class extends br{constructor(t,e,n){super(t,n),this.isHemisphereLight=!0,this.type="HemisphereLight",this.position.copy(an.DEFAULT_UP),this.updateMatrix(),this.groundColor=new qt(e)}copy(t,e){return super.copy(t,e),this.groundColor.copy(t.groundColor),this}},ko=new ve,Uh=new B,Nh=new B,Ia=class{constructor(t){this.camera=t,this.bias=0,this.normalBias=0,this.radius=1,this.blurSamples=8,this.mapSize=new Lt(512,512),this.map=null,this.mapPass=null,this.matrix=new ve,this.autoUpdate=!0,this.needsUpdate=!1,this._frustum=new pr,this._frameExtents=new Lt(1,1),this._viewportCount=1,this._viewports=[new Ee(0,0,1,1)]}getViewportCount(){return this._viewportCount}getFrustum(){return this._frustum}updateMatrices(t){let e=this.camera,n=this.matrix;Uh.setFromMatrixPosition(t.matrixWorld),e.position.copy(Uh),Nh.setFromMatrixPosition(t.target.matrixWorld),e.lookAt(Nh),e.updateMatrixWorld(),ko.multiplyMatrices(e.projectionMatrix,e.matrixWorldInverse),this._frustum.setFromProjectionMatrix(ko),n.set(.5,0,0,.5,0,.5,0,.5,0,0,.5,.5,0,0,0,1),n.multiply(ko)}getViewport(t){return this._viewports[t]}getFrameExtents(){return this._frameExtents}dispose(){this.map&&this.map.dispose(),this.mapPass&&this.mapPass.dispose()}copy(t){return this.camera=t.camera.clone(),this.bias=t.bias,this.radius=t.radius,this.mapSize.copy(t.mapSize),this}clone(){return new this.constructor().copy(this)}toJSON(){let t={};return this.bias!==0&&(t.bias=this.bias),this.normalBias!==0&&(t.normalBias=this.normalBias),this.radius!==1&&(t.radius=this.radius),(this.mapSize.x!==512||this.mapSize.y!==512)&&(t.mapSize=this.mapSize.toArray()),t.camera=this.camera.toJSON(!1).object,delete t.camera.matrix,t}};var Oh=new ve,rr=new B,Ho=new B,yl=class extends Ia{constructor(){super(new nn(90,1,.5,500)),this.isPointLightShadow=!0,this._frameExtents=new Lt(4,2),this._viewportCount=6,this._viewports=[new Ee(2,1,1,1),new Ee(0,1,1,1),new Ee(3,1,1,1),new Ee(1,1,1,1),new Ee(3,0,1,1),new Ee(1,0,1,1)],this._cubeDirections=[new B(1,0,0),new B(-1,0,0),new B(0,0,1),new B(0,0,-1),new B(0,1,0),new B(0,-1,0)],this._cubeUps=[new B(0,1,0),new B(0,1,0),new B(0,1,0),new B(0,1,0),new B(0,0,1),new B(0,0,-1)]}updateMatrices(t,e=0){let n=this.camera,s=this.matrix,r=t.distance||n.far;r!==n.far&&(n.far=r,n.updateProjectionMatrix()),rr.setFromMatrixPosition(t.matrixWorld),n.position.copy(rr),Ho.copy(n.position),Ho.add(this._cubeDirections[e]),n.up.copy(this._cubeUps[e]),n.lookAt(Ho),n.updateMatrixWorld(),s.makeTranslation(-rr.x,-rr.y,-rr.z),Oh.multiplyMatrices(n.projectionMatrix,n.matrixWorldInverse),this._frustum.setFromProjectionMatrix(Oh)}},Da=class extends br{constructor(t,e,n=0,s=2){super(t,e),this.isPointLight=!0,this.type="PointLight",this.distance=n,this.decay=s,this.shadow=new yl}get power(){return this.intensity*4*Math.PI}set power(t){this.intensity=t/(4*Math.PI)}dispose(){this.shadow.dispose()}copy(t,e){return super.copy(t,e),this.distance=t.distance,this.decay=t.decay,this.shadow=t.shadow.clone(),this}},bl=class extends Ia{constructor(){super(new Us(-5,5,5,-5,.5,500)),this.isDirectionalLightShadow=!0}},Ua=class extends br{constructor(t,e){super(t,e),this.isDirectionalLight=!0,this.type="DirectionalLight",this.position.copy(an.DEFAULT_UP),this.updateMatrix(),this.target=new an,this.shadow=new bl}dispose(){this.shadow.dispose()}copy(t){return super.copy(t),this.target=t.target.clone(),this.shadow=t.shadow.clone(),this}};var Na=class{constructor(t=!0){this.autoStart=t,this.startTime=0,this.oldTime=0,this.elapsedTime=0,this.running=!1}start(){this.startTime=Fh(),this.oldTime=this.startTime,this.elapsedTime=0,this.running=!0}stop(){this.getElapsedTime(),this.running=!1,this.autoStart=!1}getElapsedTime(){return this.getDelta(),this.elapsedTime}getDelta(){let t=0;if(this.autoStart&&!this.running)return this.start(),0;if(this.running){let e=Fh();t=(e-this.oldTime)/1e3,this.oldTime=e,this.elapsedTime+=t}return t}};function Fh(){return(typeof performance>"u"?Date:performance).now()}var Dl="\\[\\]\\.:\\/",F0=new RegExp("["+Dl+"]","g"),Ul="[^"+Dl+"]",B0="[^"+Dl.replace("\\.","")+"]",z0=/((?:WC+[\/:])*)/.source.replace("WC",Ul),k0=/(WCOD+)?/.source.replace("WCOD",B0),H0=/(?:\.(WC+)(?:\[(.+)\])?)?/.source.replace("WC",Ul),V0=/\.(WC+)(?:\[(.+)\])?/.source.replace("WC",Ul),G0=new RegExp("^"+z0+k0+H0+V0+"$"),W0=["material","materials","bones","map"],Ml=class{constructor(t,e,n){let s=n||we.parseTrackName(e);this._targetGroup=t,this._bindings=t.subscribe_(e,s)}getValue(t,e){this.bind();let n=this._targetGroup.nCachedObjects_,s=this._bindings[n];s!==void 0&&s.getValue(t,e)}setValue(t,e){let n=this._bindings;for(let s=this._targetGroup.nCachedObjects_,r=n.length;s!==r;++s)n[s].setValue(t,e)}bind(){let t=this._bindings;for(let e=this._targetGroup.nCachedObjects_,n=t.length;e!==n;++e)t[e].bind()}unbind(){let t=this._bindings;for(let e=this._targetGroup.nCachedObjects_,n=t.length;e!==n;++e)t[e].unbind()}},we=class i{constructor(t,e,n){this.path=e,this.parsedPath=n||i.parseTrackName(e),this.node=i.findNode(t,this.parsedPath.nodeName),this.rootNode=t,this.getValue=this._getValue_unbound,this.setValue=this._setValue_unbound}static create(t,e,n){return t&&t.isAnimationObjectGroup?new i.Composite(t,e,n):new i(t,e,n)}static sanitizeNodeName(t){return t.replace(/\s/g,"_").replace(F0,"")}static parseTrackName(t){let e=G0.exec(t);if(e===null)throw new Error("PropertyBinding: Cannot parse trackName: "+t);let n={nodeName:e[2],objectName:e[3],objectIndex:e[4],propertyName:e[5],propertyIndex:e[6]},s=n.nodeName&&n.nodeName.lastIndexOf(".");if(s!==void 0&&s!==-1){let r=n.nodeName.substring(s+1);W0.indexOf(r)!==-1&&(n.nodeName=n.nodeName.substring(0,s),n.objectName=r)}if(n.propertyName===null||n.propertyName.length===0)throw new Error("PropertyBinding: can not parse propertyName from trackName: "+t);return n}static findNode(t,e){if(e===void 0||e===""||e==="."||e===-1||e===t.name||e===t.uuid)return t;if(t.skeleton){let n=t.skeleton.getBoneByName(e);if(n!==void 0)return n}if(t.children){let n=function(r){for(let o=0;o<r.length;o++){let a=r[o];if(a.name===e||a.uuid===e)return a;let l=n(a.children);if(l)return l}return null},s=n(t.children);if(s)return s}return null}_getValue_unavailable(){}_setValue_unavailable(){}_getValue_direct(t,e){t[e]=this.targetObject[this.propertyName]}_getValue_array(t,e){let n=this.resolvedProperty;for(let s=0,r=n.length;s!==r;++s)t[e++]=n[s]}_getValue_arrayElement(t,e){t[e]=this.resolvedProperty[this.propertyIndex]}_getValue_toArray(t,e){this.resolvedProperty.toArray(t,e)}_setValue_direct(t,e){this.targetObject[this.propertyName]=t[e]}_setValue_direct_setNeedsUpdate(t,e){this.targetObject[this.propertyName]=t[e],this.targetObject.needsUpdate=!0}_setValue_direct_setMatrixWorldNeedsUpdate(t,e){this.targetObject[this.propertyName]=t[e],this.targetObject.matrixWorldNeedsUpdate=!0}_setValue_array(t,e){let n=this.resolvedProperty;for(let s=0,r=n.length;s!==r;++s)n[s]=t[e++]}_setValue_array_setNeedsUpdate(t,e){let n=this.resolvedProperty;for(let s=0,r=n.length;s!==r;++s)n[s]=t[e++];this.targetObject.needsUpdate=!0}_setValue_array_setMatrixWorldNeedsUpdate(t,e){let n=this.resolvedProperty;for(let s=0,r=n.length;s!==r;++s)n[s]=t[e++];this.targetObject.matrixWorldNeedsUpdate=!0}_setValue_arrayElement(t,e){this.resolvedProperty[this.propertyIndex]=t[e]}_setValue_arrayElement_setNeedsUpdate(t,e){this.resolvedProperty[this.propertyIndex]=t[e],this.targetObject.needsUpdate=!0}_setValue_arrayElement_setMatrixWorldNeedsUpdate(t,e){this.resolvedProperty[this.propertyIndex]=t[e],this.targetObject.matrixWorldNeedsUpdate=!0}_setValue_fromArray(t,e){this.resolvedProperty.fromArray(t,e)}_setValue_fromArray_setNeedsUpdate(t,e){this.resolvedProperty.fromArray(t,e),this.targetObject.needsUpdate=!0}_setValue_fromArray_setMatrixWorldNeedsUpdate(t,e){this.resolvedProperty.fromArray(t,e),this.targetObject.matrixWorldNeedsUpdate=!0}_getValue_unbound(t,e){this.bind(),this.getValue(t,e)}_setValue_unbound(t,e){this.bind(),this.setValue(t,e)}bind(){let t=this.node,e=this.parsedPath,n=e.objectName,s=e.propertyName,r=e.propertyIndex;if(t||(t=i.findNode(this.rootNode,e.nodeName),this.node=t),this.getValue=this._getValue_unavailable,this.setValue=this._setValue_unavailable,!t){console.warn("THREE.PropertyBinding: No target node found for track: "+this.path+".");return}if(n){let c=e.objectIndex;switch(n){case"materials":if(!t.material){console.error("THREE.PropertyBinding: Can not bind to material as node does not have a material.",this);return}if(!t.material.materials){console.error("THREE.PropertyBinding: Can not bind to material.materials as node.material does not have a materials array.",this);return}t=t.material.materials;break;case"bones":if(!t.skeleton){console.error("THREE.PropertyBinding: Can not bind to bones as node does not have a skeleton.",this);return}t=t.skeleton.bones;for(let u=0;u<t.length;u++)if(t[u].name===c){c=u;break}break;case"map":if("map"in t){t=t.map;break}if(!t.material){console.error("THREE.PropertyBinding: Can not bind to material as node does not have a material.",this);return}if(!t.material.map){console.error("THREE.PropertyBinding: Can not bind to material.map as node.material does not have a map.",this);return}t=t.material.map;break;default:if(t[n]===void 0){console.error("THREE.PropertyBinding: Can not bind to objectName of node undefined.",this);return}t=t[n]}if(c!==void 0){if(t[c]===void 0){console.error("THREE.PropertyBinding: Trying to bind to objectIndex of objectName, but is undefined.",this,t);return}t=t[c]}}let o=t[s];if(o===void 0){let c=e.nodeName;console.error("THREE.PropertyBinding: Trying to update property for track: "+c+"."+s+" but it wasn't found.",t);return}let a=this.Versioning.None;this.targetObject=t,t.needsUpdate!==void 0?a=this.Versioning.NeedsUpdate:t.matrixWorldNeedsUpdate!==void 0&&(a=this.Versioning.MatrixWorldNeedsUpdate);let l=this.BindingType.Direct;if(r!==void 0){if(s==="morphTargetInfluences"){if(!t.geometry){console.error("THREE.PropertyBinding: Can not bind to morphTargetInfluences because node does not have a geometry.",this);return}if(!t.geometry.morphAttributes){console.error("THREE.PropertyBinding: Can not bind to morphTargetInfluences because node does not have a geometry.morphAttributes.",this);return}t.morphTargetDictionary[r]!==void 0&&(r=t.morphTargetDictionary[r])}l=this.BindingType.ArrayElement,this.resolvedProperty=o,this.propertyIndex=r}else o.fromArray!==void 0&&o.toArray!==void 0?(l=this.BindingType.HasFromToArray,this.resolvedProperty=o):Array.isArray(o)?(l=this.BindingType.EntireArray,this.resolvedProperty=o):this.propertyName=s;this.getValue=this.GetterByBindingType[l],this.setValue=this.SetterByBindingTypeAndVersioning[l][a]}unbind(){this.node=null,this.getValue=this._getValue_unbound,this.setValue=this._setValue_unbound}};we.Composite=Ml;we.prototype.BindingType={Direct:0,EntireArray:1,ArrayElement:2,HasFromToArray:3};we.prototype.Versioning={None:0,NeedsUpdate:1,MatrixWorldNeedsUpdate:2};we.prototype.GetterByBindingType=[we.prototype._getValue_direct,we.prototype._getValue_array,we.prototype._getValue_arrayElement,we.prototype._getValue_toArray];we.prototype.SetterByBindingTypeAndVersioning=[[we.prototype._setValue_direct,we.prototype._setValue_direct_setNeedsUpdate,we.prototype._setValue_direct_setMatrixWorldNeedsUpdate],[we.prototype._setValue_array,we.prototype._setValue_array_setNeedsUpdate,we.prototype._setValue_array_setMatrixWorldNeedsUpdate],[we.prototype._setValue_arrayElement,we.prototype._setValue_arrayElement_setNeedsUpdate,we.prototype._setValue_arrayElement_setMatrixWorldNeedsUpdate],[we.prototype._setValue_fromArray,we.prototype._setValue_fromArray_setNeedsUpdate,we.prototype._setValue_fromArray_setMatrixWorldNeedsUpdate]];var K0=new Float32Array(1);var Oa=class{constructor(t,e,n=0,s=1/0){this.ray=new Xi(t,e),this.near=n,this.far=s,this.camera=null,this.layers=new fr,this.params={Mesh:{},Line:{threshold:1},LOD:{},Points:{threshold:1},Sprite:{}}}set(t,e){this.ray.set(t,e)}setFromCamera(t,e){e.isPerspectiveCamera?(this.ray.origin.setFromMatrixPosition(e.matrixWorld),this.ray.direction.set(t.x,t.y,.5).unproject(e).sub(this.ray.origin).normalize(),this.camera=e):e.isOrthographicCamera?(this.ray.origin.set(t.x,t.y,(e.near+e.far)/(e.near-e.far)).unproject(e),this.ray.direction.set(0,0,-1).transformDirection(e.matrixWorld),this.camera=e):console.error("THREE.Raycaster: Unsupported camera type: "+e.type)}intersectObject(t,e=!0,n=[]){return Sl(t,this,n,e),n.sort(Bh),n}intersectObjects(t,e=!0,n=[]){for(let s=0,r=t.length;s<r;s++)Sl(t[s],this,n,e);return n.sort(Bh),n}};function Bh(i,t){return i.distance-t.distance}function Sl(i,t,e,n){if(i.layers.test(t.layers)&&i.raycast(t,e),n===!0){let s=i.children;for(let r=0,o=s.length;r<o;r++)Sl(s[r],t,e,!0)}}var Mr=class{constructor(t=1,e=0,n=0){return this.radius=t,this.phi=e,this.theta=n,this}set(t,e,n){return this.radius=t,this.phi=e,this.theta=n,this}copy(t){return this.radius=t.radius,this.phi=t.phi,this.theta=t.theta,this}makeSafe(){return this.phi=Math.max(1e-6,Math.min(Math.PI-1e-6,this.phi)),this}setFromVector3(t){return this.setFromCartesianCoords(t.x,t.y,t.z)}setFromCartesianCoords(t,e,n){return this.radius=Math.sqrt(t*t+e*e+n*n),this.radius===0?(this.theta=0,this.phi=0):(this.theta=Math.atan2(t,n),this.phi=Math.acos(en(e/this.radius,-1,1))),this}clone(){return new this.constructor().copy(this)}};typeof __THREE_DEVTOOLS__<"u"&&__THREE_DEVTOOLS__.dispatchEvent(new CustomEvent("register",{detail:{revision:"160"}}));typeof window<"u"&&(window.__THREE__?console.warn("WARNING: Multiple instances of Three.js being imported."):window.__THREE__="160");var lu={type:"change"},Nl={type:"start"},cu={type:"end"},ka=new Xi,hu=new In,Y0=Math.cos(70*Kh.DEG2RAD),Ha=class extends qn{constructor(t,e){super(),this.object=t,this.domElement=e,this.domElement.style.touchAction="none",this.enabled=!0,this.target=new B,this.cursor=new B,this.minDistance=0,this.maxDistance=1/0,this.minZoom=0,this.maxZoom=1/0,this.minTargetRadius=0,this.maxTargetRadius=1/0,this.minPolarAngle=0,this.maxPolarAngle=Math.PI,this.minAzimuthAngle=-1/0,this.maxAzimuthAngle=1/0,this.enableDamping=!1,this.dampingFactor=.05,this.enableZoom=!0,this.zoomSpeed=1,this.enableRotate=!0,this.rotateSpeed=1,this.enablePan=!0,this.panSpeed=1,this.screenSpacePanning=!0,this.keyPanSpeed=7,this.zoomToCursor=!1,this.autoRotate=!1,this.autoRotateSpeed=2,this.keys={LEFT:"ArrowLeft",UP:"ArrowUp",RIGHT:"ArrowRight",BOTTOM:"ArrowDown"},this.mouseButtons={LEFT:Ji.ROTATE,MIDDLE:Ji.DOLLY,RIGHT:Ji.PAN},this.touches={ONE:ji.ROTATE,TWO:ji.DOLLY_PAN},this.target0=this.target.clone(),this.position0=this.object.position.clone(),this.zoom0=this.object.zoom,this._domElementKeyEvents=null,this.getPolarAngle=function(){return a.phi},this.getAzimuthalAngle=function(){return a.theta},this.getDistance=function(){return this.object.position.distanceTo(this.target)},this.listenToKeyEvents=function(P){P.addEventListener("keydown",rt),this._domElementKeyEvents=P},this.stopListenToKeyEvents=function(){this._domElementKeyEvents.removeEventListener("keydown",rt),this._domElementKeyEvents=null},this.saveState=function(){n.target0.copy(n.target),n.position0.copy(n.object.position),n.zoom0=n.object.zoom},this.reset=function(){n.target.copy(n.target0),n.object.position.copy(n.position0),n.object.zoom=n.zoom0,n.object.updateProjectionMatrix(),n.dispatchEvent(lu),n.update(),r=s.NONE},this.update=(function(){let P=new B,at=new On().setFromUnitVectors(t.up,new B(0,1,0)),mt=at.clone().invert(),pt=new B,Nt=new On,ee=new B,ie=2*Math.PI;return function(_t=null){let O=n.object.position;P.copy(O).sub(n.target),P.applyQuaternion(at),a.setFromVector3(P),n.autoRotate&&r===s.NONE&&V(S(_t)),n.enableDamping?(a.theta+=l.theta*n.dampingFactor,a.phi+=l.phi*n.dampingFactor):(a.theta+=l.theta,a.phi+=l.phi);let gt=n.minAzimuthAngle,xt=n.maxAzimuthAngle;isFinite(gt)&&isFinite(xt)&&(gt<-Math.PI?gt+=ie:gt>Math.PI&&(gt-=ie),xt<-Math.PI?xt+=ie:xt>Math.PI&&(xt-=ie),gt<=xt?a.theta=Math.max(gt,Math.min(xt,a.theta)):a.theta=a.theta>(gt+xt)/2?Math.max(gt,a.theta):Math.min(xt,a.theta)),a.phi=Math.max(n.minPolarAngle,Math.min(n.maxPolarAngle,a.phi)),a.makeSafe(),n.enableDamping===!0?n.target.addScaledVector(u,n.dampingFactor):n.target.add(u),n.target.sub(n.cursor),n.target.clampLength(n.minTargetRadius,n.maxTargetRadius),n.target.add(n.cursor),n.zoomToCursor&&U||n.object.isOrthographicCamera?a.radius=K(a.radius):a.radius=K(a.radius*c),P.setFromSpherical(a),P.applyQuaternion(mt),O.copy(n.target).add(P),n.object.lookAt(n.target),n.enableDamping===!0?(l.theta*=1-n.dampingFactor,l.phi*=1-n.dampingFactor,u.multiplyScalar(1-n.dampingFactor)):(l.set(0,0,0),u.set(0,0,0));let Ht=!1;if(n.zoomToCursor&&U){let Bt=null;if(n.object.isPerspectiveCamera){let he=P.length();Bt=K(he*c);let se=he-Bt;n.object.position.addScaledVector(D,se),n.object.updateMatrixWorld()}else if(n.object.isOrthographicCamera){let he=new B(z.x,z.y,0);he.unproject(n.object),n.object.zoom=Math.max(n.minZoom,Math.min(n.maxZoom,n.object.zoom/c)),n.object.updateProjectionMatrix(),Ht=!0;let se=new B(z.x,z.y,0);se.unproject(n.object),n.object.position.sub(se).add(he),n.object.updateMatrixWorld(),Bt=P.length()}else console.warn("WARNING: OrbitControls.js encountered an unknown camera type - zoom to cursor disabled."),n.zoomToCursor=!1;Bt!==null&&(this.screenSpacePanning?n.target.set(0,0,-1).transformDirection(n.object.matrix).multiplyScalar(Bt).add(n.object.position):(ka.origin.copy(n.object.position),ka.direction.set(0,0,-1).transformDirection(n.object.matrix),Math.abs(n.object.up.dot(ka.direction))<Y0?t.lookAt(n.target):(hu.setFromNormalAndCoplanarPoint(n.object.up,n.target),ka.intersectPlane(hu,n.target))))}else n.object.isOrthographicCamera&&(n.object.zoom=Math.max(n.minZoom,Math.min(n.maxZoom,n.object.zoom/c)),n.object.updateProjectionMatrix(),Ht=!0);return c=1,U=!1,Ht||pt.distanceToSquared(n.object.position)>o||8*(1-Nt.dot(n.object.quaternion))>o||ee.distanceToSquared(n.target)>0?(n.dispatchEvent(lu),pt.copy(n.object.position),Nt.copy(n.object.quaternion),ee.copy(n.target),!0):!1}})(),this.dispose=function(){n.domElement.removeEventListener("contextmenu",ut),n.domElement.removeEventListener("pointerdown",$t),n.domElement.removeEventListener("pointercancel",b),n.domElement.removeEventListener("wheel",ht),n.domElement.removeEventListener("pointermove",A),n.domElement.removeEventListener("pointerup",b),n._domElementKeyEvents!==null&&(n._domElementKeyEvents.removeEventListener("keydown",rt),n._domElementKeyEvents=null)};let n=this,s={NONE:-1,ROTATE:0,DOLLY:1,PAN:2,TOUCH_ROTATE:3,TOUCH_PAN:4,TOUCH_DOLLY_PAN:5,TOUCH_DOLLY_ROTATE:6},r=s.NONE,o=1e-6,a=new Mr,l=new Mr,c=1,u=new B,f=new Lt,p=new Lt,x=new Lt,y=new Lt,M=new Lt,g=new Lt,d=new Lt,C=new Lt,E=new Lt,D=new B,z=new Lt,U=!1,L=[],Q={};function S(P){return P!==null?2*Math.PI/60*n.autoRotateSpeed*P:2*Math.PI/60/60*n.autoRotateSpeed}function R(P){let at=Math.abs(P)/(100*(window.devicePixelRatio|0));return Math.pow(.95,n.zoomSpeed*at)}function V(P){l.theta-=P}function nt(P){l.phi-=P}let ft=(function(){let P=new B;return function(mt,pt){P.setFromMatrixColumn(pt,0),P.multiplyScalar(-mt),u.add(P)}})(),I=(function(){let P=new B;return function(mt,pt){n.screenSpacePanning===!0?P.setFromMatrixColumn(pt,1):(P.setFromMatrixColumn(pt,0),P.crossVectors(n.object.up,P)),P.multiplyScalar(mt),u.add(P)}})(),k=(function(){let P=new B;return function(mt,pt){let Nt=n.domElement;if(n.object.isPerspectiveCamera){let ee=n.object.position;P.copy(ee).sub(n.target);let ie=P.length();ie*=Math.tan(n.object.fov/2*Math.PI/180),ft(2*mt*ie/Nt.clientHeight,n.object.matrix),I(2*pt*ie/Nt.clientHeight,n.object.matrix)}else n.object.isOrthographicCamera?(ft(mt*(n.object.right-n.object.left)/n.object.zoom/Nt.clientWidth,n.object.matrix),I(pt*(n.object.top-n.object.bottom)/n.object.zoom/Nt.clientHeight,n.object.matrix)):(console.warn("WARNING: OrbitControls.js encountered an unknown camera type - pan disabled."),n.enablePan=!1)}})();function $(P){n.object.isPerspectiveCamera||n.object.isOrthographicCamera?c/=P:(console.warn("WARNING: OrbitControls.js encountered an unknown camera type - dolly/zoom disabled."),n.enableZoom=!1)}function Z(P){n.object.isPerspectiveCamera||n.object.isOrthographicCamera?c*=P:(console.warn("WARNING: OrbitControls.js encountered an unknown camera type - dolly/zoom disabled."),n.enableZoom=!1)}function j(P,at){if(!n.zoomToCursor)return;U=!0;let mt=n.domElement.getBoundingClientRect(),pt=P-mt.left,Nt=at-mt.top,ee=mt.width,ie=mt.height;z.x=pt/ee*2-1,z.y=-(Nt/ie)*2+1,D.set(z.x,z.y,1).unproject(n.object).sub(n.object.position).normalize()}function K(P){return Math.max(n.minDistance,Math.min(n.maxDistance,P))}function st(P){f.set(P.clientX,P.clientY)}function it(P){j(P.clientX,P.clientX),d.set(P.clientX,P.clientY)}function vt(P){y.set(P.clientX,P.clientY)}function q(P){p.set(P.clientX,P.clientY),x.subVectors(p,f).multiplyScalar(n.rotateSpeed);let at=n.domElement;V(2*Math.PI*x.x/at.clientHeight),nt(2*Math.PI*x.y/at.clientHeight),f.copy(p),n.update()}function ct(P){C.set(P.clientX,P.clientY),E.subVectors(C,d),E.y>0?$(R(E.y)):E.y<0&&Z(R(E.y)),d.copy(C),n.update()}function yt(P){M.set(P.clientX,P.clientY),g.subVectors(M,y).multiplyScalar(n.panSpeed),k(g.x,g.y),y.copy(M),n.update()}function It(P){j(P.clientX,P.clientY),P.deltaY<0?Z(R(P.deltaY)):P.deltaY>0&&$(R(P.deltaY)),n.update()}function Ot(P){let at=!1;switch(P.code){case n.keys.UP:P.ctrlKey||P.metaKey||P.shiftKey?nt(2*Math.PI*n.rotateSpeed/n.domElement.clientHeight):k(0,n.keyPanSpeed),at=!0;break;case n.keys.BOTTOM:P.ctrlKey||P.metaKey||P.shiftKey?nt(-2*Math.PI*n.rotateSpeed/n.domElement.clientHeight):k(0,-n.keyPanSpeed),at=!0;break;case n.keys.LEFT:P.ctrlKey||P.metaKey||P.shiftKey?V(2*Math.PI*n.rotateSpeed/n.domElement.clientHeight):k(n.keyPanSpeed,0),at=!0;break;case n.keys.RIGHT:P.ctrlKey||P.metaKey||P.shiftKey?V(-2*Math.PI*n.rotateSpeed/n.domElement.clientHeight):k(-n.keyPanSpeed,0),at=!0;break}at&&(P.preventDefault(),n.update())}function Pt(P){if(L.length===1)f.set(P.pageX,P.pageY);else{let at=ae(P),mt=.5*(P.pageX+at.x),pt=.5*(P.pageY+at.y);f.set(mt,pt)}}function Dt(P){if(L.length===1)y.set(P.pageX,P.pageY);else{let at=ae(P),mt=.5*(P.pageX+at.x),pt=.5*(P.pageY+at.y);y.set(mt,pt)}}function At(P){let at=ae(P),mt=P.pageX-at.x,pt=P.pageY-at.y,Nt=Math.sqrt(mt*mt+pt*pt);d.set(0,Nt)}function kt(P){n.enableZoom&&At(P),n.enablePan&&Dt(P)}function G(P){n.enableZoom&&At(P),n.enableRotate&&Pt(P)}function Re(P){if(L.length==1)p.set(P.pageX,P.pageY);else{let mt=ae(P),pt=.5*(P.pageX+mt.x),Nt=.5*(P.pageY+mt.y);p.set(pt,Nt)}x.subVectors(p,f).multiplyScalar(n.rotateSpeed);let at=n.domElement;V(2*Math.PI*x.x/at.clientHeight),nt(2*Math.PI*x.y/at.clientHeight),f.copy(p)}function Ut(P){if(L.length===1)M.set(P.pageX,P.pageY);else{let at=ae(P),mt=.5*(P.pageX+at.x),pt=.5*(P.pageY+at.y);M.set(mt,pt)}g.subVectors(M,y).multiplyScalar(n.panSpeed),k(g.x,g.y),y.copy(M)}function Gt(P){let at=ae(P),mt=P.pageX-at.x,pt=P.pageY-at.y,Nt=Math.sqrt(mt*mt+pt*pt);C.set(0,Nt),E.set(0,Math.pow(C.y/d.y,n.zoomSpeed)),$(E.y),d.copy(C);let ee=(P.pageX+at.x)*.5,ie=(P.pageY+at.y)*.5;j(ee,ie)}function Rt(P){n.enableZoom&&Gt(P),n.enablePan&&Ut(P)}function me(P){n.enableZoom&&Gt(P),n.enableRotate&&Re(P)}function $t(P){n.enabled!==!1&&(L.length===0&&(n.domElement.setPointerCapture(P.pointerId),n.domElement.addEventListener("pointermove",A),n.domElement.addEventListener("pointerup",b)),Ft(P),P.pointerType==="touch"?Tt(P):W(P))}function A(P){n.enabled!==!1&&(P.pointerType==="touch"?St(P):dt(P))}function b(P){Yt(P),L.length===0&&(n.domElement.releasePointerCapture(P.pointerId),n.domElement.removeEventListener("pointermove",A),n.domElement.removeEventListener("pointerup",b)),n.dispatchEvent(cu),r=s.NONE}function W(P){let at;switch(P.button){case 0:at=n.mouseButtons.LEFT;break;case 1:at=n.mouseButtons.MIDDLE;break;case 2:at=n.mouseButtons.RIGHT;break;default:at=-1}switch(at){case Ji.DOLLY:if(n.enableZoom===!1)return;it(P),r=s.DOLLY;break;case Ji.ROTATE:if(P.ctrlKey||P.metaKey||P.shiftKey){if(n.enablePan===!1)return;vt(P),r=s.PAN}else{if(n.enableRotate===!1)return;st(P),r=s.ROTATE}break;case Ji.PAN:if(P.ctrlKey||P.metaKey||P.shiftKey){if(n.enableRotate===!1)return;st(P),r=s.ROTATE}else{if(n.enablePan===!1)return;vt(P),r=s.PAN}break;default:r=s.NONE}r!==s.NONE&&n.dispatchEvent(Nl)}function dt(P){switch(r){case s.ROTATE:if(n.enableRotate===!1)return;q(P);break;case s.DOLLY:if(n.enableZoom===!1)return;ct(P);break;case s.PAN:if(n.enablePan===!1)return;yt(P);break}}function ht(P){n.enabled===!1||n.enableZoom===!1||r!==s.NONE||(P.preventDefault(),n.dispatchEvent(Nl),It(P),n.dispatchEvent(cu))}function rt(P){n.enabled===!1||n.enablePan===!1||Ot(P)}function Tt(P){switch(lt(P),L.length){case 1:switch(n.touches.ONE){case ji.ROTATE:if(n.enableRotate===!1)return;Pt(P),r=s.TOUCH_ROTATE;break;case ji.PAN:if(n.enablePan===!1)return;Dt(P),r=s.TOUCH_PAN;break;default:r=s.NONE}break;case 2:switch(n.touches.TWO){case ji.DOLLY_PAN:if(n.enableZoom===!1&&n.enablePan===!1)return;kt(P),r=s.TOUCH_DOLLY_PAN;break;case ji.DOLLY_ROTATE:if(n.enableZoom===!1&&n.enableRotate===!1)return;G(P),r=s.TOUCH_DOLLY_ROTATE;break;default:r=s.NONE}break;default:r=s.NONE}r!==s.NONE&&n.dispatchEvent(Nl)}function St(P){switch(lt(P),r){case s.TOUCH_ROTATE:if(n.enableRotate===!1)return;Re(P),n.update();break;case s.TOUCH_PAN:if(n.enablePan===!1)return;Ut(P),n.update();break;case s.TOUCH_DOLLY_PAN:if(n.enableZoom===!1&&n.enablePan===!1)return;Rt(P),n.update();break;case s.TOUCH_DOLLY_ROTATE:if(n.enableZoom===!1&&n.enableRotate===!1)return;me(P),n.update();break;default:r=s.NONE}}function ut(P){n.enabled!==!1&&P.preventDefault()}function Ft(P){L.push(P.pointerId)}function Yt(P){delete Q[P.pointerId];for(let at=0;at<L.length;at++)if(L[at]==P.pointerId){L.splice(at,1);return}}function lt(P){let at=Q[P.pointerId];at===void 0&&(at=new Lt,Q[P.pointerId]=at),at.set(P.pageX,P.pageY)}function ae(P){let at=P.pointerId===L[0]?L[1]:L[0];return Q[at]}n.domElement.addEventListener("contextmenu",ut),n.domElement.addEventListener("pointerdown",$t),n.domElement.addEventListener("pointercancel",b),n.domElement.addEventListener("wheel",ht,{passive:!1}),this.update()}};var Va={name:"CopyShader",uniforms:{tDiffuse:{value:null},opacity:{value:1}},vertexShader:`

		varying vec2 vUv;

		void main() {

			vUv = uv;
			gl_Position = projectionMatrix * modelViewMatrix * vec4( position, 1.0 );

		}`,fragmentShader:`

		uniform float opacity;

		uniform sampler2D tDiffuse;

		varying vec2 vUv;

		void main() {

			vec4 texel = texture2D( tDiffuse, vUv );
			gl_FragColor = opacity * texel;


		}`};var _n=class{constructor(){this.isPass=!0,this.enabled=!0,this.needsSwap=!0,this.clear=!1,this.renderToScreen=!1}setSize(){}render(){console.error("THREE.Pass: .render() must be implemented in derived pass.")}dispose(){}},q0=new Us(-1,1,1,-1,0,1),Ol=class extends hn{constructor(){super(),this.setAttribute("position",new Ze([-1,3,0,-1,-1,0,3,-1,0],3)),this.setAttribute("uv",new Ze([0,2,0,0,2,0],2))}},Z0=new Ol,Ti=class{constructor(t){this._mesh=new He(Z0,t)}dispose(){this._mesh.geometry.dispose()}render(t){t.render(this._mesh,q0)}get material(){return this._mesh.material}set material(t){this._mesh.material=t}};var ks=class extends _n{constructor(t,e){super(),this.textureID=e!==void 0?e:"tDiffuse",t instanceof Ne?(this.uniforms=t.uniforms,this.material=t):t&&(this.uniforms=Ei.clone(t.uniforms),this.material=new Ne({name:t.name!==void 0?t.name:"unspecified",defines:Object.assign({},t.defines),uniforms:this.uniforms,vertexShader:t.vertexShader,fragmentShader:t.fragmentShader})),this.fsQuad=new Ti(this.material)}render(t,e,n){this.uniforms[this.textureID]&&(this.uniforms[this.textureID].value=n.texture),this.fsQuad.material=this.material,this.renderToScreen?(t.setRenderTarget(null),this.fsQuad.render(t)):(t.setRenderTarget(e),this.clear&&t.clear(t.autoClearColor,t.autoClearDepth,t.autoClearStencil),this.fsQuad.render(t))}dispose(){this.material.dispose(),this.fsQuad.dispose()}};var wr=class extends _n{constructor(t,e){super(),this.scene=t,this.camera=e,this.clear=!0,this.needsSwap=!1,this.inverse=!1}render(t,e,n){let s=t.getContext(),r=t.state;r.buffers.color.setMask(!1),r.buffers.depth.setMask(!1),r.buffers.color.setLocked(!0),r.buffers.depth.setLocked(!0);let o,a;this.inverse?(o=0,a=1):(o=1,a=0),r.buffers.stencil.setTest(!0),r.buffers.stencil.setOp(s.REPLACE,s.REPLACE,s.REPLACE),r.buffers.stencil.setFunc(s.ALWAYS,o,4294967295),r.buffers.stencil.setClear(a),r.buffers.stencil.setLocked(!0),t.setRenderTarget(n),this.clear&&t.clear(),t.render(this.scene,this.camera),t.setRenderTarget(e),this.clear&&t.clear(),t.render(this.scene,this.camera),r.buffers.color.setLocked(!1),r.buffers.depth.setLocked(!1),r.buffers.color.setMask(!0),r.buffers.depth.setMask(!0),r.buffers.stencil.setLocked(!1),r.buffers.stencil.setFunc(s.EQUAL,1,4294967295),r.buffers.stencil.setOp(s.KEEP,s.KEEP,s.KEEP),r.buffers.stencil.setLocked(!0)}},Ga=class extends _n{constructor(){super(),this.needsSwap=!1}render(t){t.state.buffers.stencil.setLocked(!1),t.state.buffers.stencil.setTest(!1)}};var Wa=class{constructor(t,e){if(this.renderer=t,this._pixelRatio=t.getPixelRatio(),e===void 0){let n=t.getSize(new Lt);this._width=n.width,this._height=n.height,e=new Ke(this._width*this._pixelRatio,this._height*this._pixelRatio,{type:gn}),e.texture.name="EffectComposer.rt1"}else this._width=e.width,this._height=e.height;this.renderTarget1=e,this.renderTarget2=e.clone(),this.renderTarget2.texture.name="EffectComposer.rt2",this.writeBuffer=this.renderTarget1,this.readBuffer=this.renderTarget2,this.renderToScreen=!0,this.passes=[],this.copyPass=new ks(Va),this.copyPass.material.blending=Yn,this.clock=new Na}swapBuffers(){let t=this.readBuffer;this.readBuffer=this.writeBuffer,this.writeBuffer=t}addPass(t){this.passes.push(t),t.setSize(this._width*this._pixelRatio,this._height*this._pixelRatio)}insertPass(t,e){this.passes.splice(e,0,t),t.setSize(this._width*this._pixelRatio,this._height*this._pixelRatio)}removePass(t){let e=this.passes.indexOf(t);e!==-1&&this.passes.splice(e,1)}isLastEnabledPass(t){for(let e=t+1;e<this.passes.length;e++)if(this.passes[e].enabled)return!1;return!0}render(t){t===void 0&&(t=this.clock.getDelta());let e=this.renderer.getRenderTarget(),n=!1;for(let s=0,r=this.passes.length;s<r;s++){let o=this.passes[s];if(o.enabled!==!1){if(o.renderToScreen=this.renderToScreen&&this.isLastEnabledPass(s),o.render(this.renderer,this.writeBuffer,this.readBuffer,t,n),o.needsSwap){if(n){let a=this.renderer.getContext(),l=this.renderer.state.buffers.stencil;l.setFunc(a.NOTEQUAL,1,4294967295),this.copyPass.render(this.renderer,this.writeBuffer,this.readBuffer,t),l.setFunc(a.EQUAL,1,4294967295)}this.swapBuffers()}wr!==void 0&&(o instanceof wr?n=!0:o instanceof Ga&&(n=!1))}}this.renderer.setRenderTarget(e)}reset(t){if(t===void 0){let e=this.renderer.getSize(new Lt);this._pixelRatio=this.renderer.getPixelRatio(),this._width=e.width,this._height=e.height,t=this.renderTarget1.clone(),t.setSize(this._width*this._pixelRatio,this._height*this._pixelRatio)}this.renderTarget1.dispose(),this.renderTarget2.dispose(),this.renderTarget1=t,this.renderTarget2=t.clone(),this.writeBuffer=this.renderTarget1,this.readBuffer=this.renderTarget2}setSize(t,e){this._width=t,this._height=e;let n=this._width*this._pixelRatio,s=this._height*this._pixelRatio;this.renderTarget1.setSize(n,s),this.renderTarget2.setSize(n,s);for(let r=0;r<this.passes.length;r++)this.passes[r].setSize(n,s)}setPixelRatio(t){this._pixelRatio=t,this.setSize(this._width,this._height)}dispose(){this.renderTarget1.dispose(),this.renderTarget2.dispose(),this.copyPass.dispose()}};var Xa=class extends _n{constructor(t,e,n=null,s=null,r=null){super(),this.scene=t,this.camera=e,this.overrideMaterial=n,this.clearColor=s,this.clearAlpha=r,this.clear=!0,this.clearDepth=!1,this.needsSwap=!1,this._oldClearColor=new qt}render(t,e,n){let s=t.autoClear;t.autoClear=!1;let r,o;this.overrideMaterial!==null&&(o=this.scene.overrideMaterial,this.scene.overrideMaterial=this.overrideMaterial),this.clearColor!==null&&(t.getClearColor(this._oldClearColor),t.setClearColor(this.clearColor)),this.clearAlpha!==null&&(r=t.getClearAlpha(),t.setClearAlpha(this.clearAlpha)),this.clearDepth==!0&&t.clearDepth(),t.setRenderTarget(this.renderToScreen?null:n),this.clear===!0&&t.clear(t.autoClearColor,t.autoClearDepth,t.autoClearStencil),t.render(this.scene,this.camera),this.clearColor!==null&&t.setClearColor(this._oldClearColor),this.clearAlpha!==null&&t.setClearAlpha(r),this.overrideMaterial!==null&&(this.scene.overrideMaterial=o),t.autoClear=s}};var uu={name:"LuminosityHighPassShader",shaderID:"luminosityHighPass",uniforms:{tDiffuse:{value:null},luminosityThreshold:{value:1},smoothWidth:{value:1},defaultColor:{value:new qt(0)},defaultOpacity:{value:0}},vertexShader:`

		varying vec2 vUv;

		void main() {

			vUv = uv;

			gl_Position = projectionMatrix * modelViewMatrix * vec4( position, 1.0 );

		}`,fragmentShader:`

		uniform sampler2D tDiffuse;
		uniform vec3 defaultColor;
		uniform float defaultOpacity;
		uniform float luminosityThreshold;
		uniform float smoothWidth;

		varying vec2 vUv;

		void main() {

			vec4 texel = texture2D( tDiffuse, vUv );

			vec3 luma = vec3( 0.299, 0.587, 0.114 );

			float v = dot( texel.xyz, luma );

			vec4 outputColor = vec4( defaultColor.rgb, defaultOpacity );

			float alpha = smoothstep( luminosityThreshold, luminosityThreshold + smoothWidth, v );

			gl_FragColor = mix( outputColor, texel, alpha );

		}`};var Hs=class i extends _n{constructor(t,e,n,s){super(),this.strength=e!==void 0?e:1,this.radius=n,this.threshold=s,this.resolution=t!==void 0?new Lt(t.x,t.y):new Lt(256,256),this.clearColor=new qt(0,0,0),this.renderTargetsHorizontal=[],this.renderTargetsVertical=[],this.nMips=5;let r=Math.round(this.resolution.x/2),o=Math.round(this.resolution.y/2);this.renderTargetBright=new Ke(r,o,{type:gn}),this.renderTargetBright.texture.name="UnrealBloomPass.bright",this.renderTargetBright.texture.generateMipmaps=!1;for(let f=0;f<this.nMips;f++){let p=new Ke(r,o,{type:gn});p.texture.name="UnrealBloomPass.h"+f,p.texture.generateMipmaps=!1,this.renderTargetsHorizontal.push(p);let x=new Ke(r,o,{type:gn});x.texture.name="UnrealBloomPass.v"+f,x.texture.generateMipmaps=!1,this.renderTargetsVertical.push(x),r=Math.round(r/2),o=Math.round(o/2)}let a=uu;this.highPassUniforms=Ei.clone(a.uniforms),this.highPassUniforms.luminosityThreshold.value=s,this.highPassUniforms.smoothWidth.value=.01,this.materialHighPassFilter=new Ne({uniforms:this.highPassUniforms,vertexShader:a.vertexShader,fragmentShader:a.fragmentShader}),this.separableBlurMaterials=[];let l=[3,5,7,9,11];r=Math.round(this.resolution.x/2),o=Math.round(this.resolution.y/2);for(let f=0;f<this.nMips;f++)this.separableBlurMaterials.push(this.getSeperableBlurMaterial(l[f])),this.separableBlurMaterials[f].uniforms.invSize.value=new Lt(1/r,1/o),r=Math.round(r/2),o=Math.round(o/2);this.compositeMaterial=this.getCompositeMaterial(this.nMips),this.compositeMaterial.uniforms.blurTexture1.value=this.renderTargetsVertical[0].texture,this.compositeMaterial.uniforms.blurTexture2.value=this.renderTargetsVertical[1].texture,this.compositeMaterial.uniforms.blurTexture3.value=this.renderTargetsVertical[2].texture,this.compositeMaterial.uniforms.blurTexture4.value=this.renderTargetsVertical[3].texture,this.compositeMaterial.uniforms.blurTexture5.value=this.renderTargetsVertical[4].texture,this.compositeMaterial.uniforms.bloomStrength.value=e,this.compositeMaterial.uniforms.bloomRadius.value=.1;let c=[1,.8,.6,.4,.2];this.compositeMaterial.uniforms.bloomFactors.value=c,this.bloomTintColors=[new B(1,1,1),new B(1,1,1),new B(1,1,1),new B(1,1,1),new B(1,1,1)],this.compositeMaterial.uniforms.bloomTintColors.value=this.bloomTintColors;let u=Va;this.copyUniforms=Ei.clone(u.uniforms),this.blendMaterial=new Ne({uniforms:this.copyUniforms,vertexShader:u.vertexShader,fragmentShader:u.fragmentShader,blending:Rs,depthTest:!1,depthWrite:!1,transparent:!0}),this.enabled=!0,this.needsSwap=!1,this._oldClearColor=new qt,this.oldClearAlpha=1,this.basic=new xn,this.fsQuad=new Ti(null)}dispose(){for(let t=0;t<this.renderTargetsHorizontal.length;t++)this.renderTargetsHorizontal[t].dispose();for(let t=0;t<this.renderTargetsVertical.length;t++)this.renderTargetsVertical[t].dispose();this.renderTargetBright.dispose();for(let t=0;t<this.separableBlurMaterials.length;t++)this.separableBlurMaterials[t].dispose();this.compositeMaterial.dispose(),this.blendMaterial.dispose(),this.basic.dispose(),this.fsQuad.dispose()}setSize(t,e){let n=Math.round(t/2),s=Math.round(e/2);this.renderTargetBright.setSize(n,s);for(let r=0;r<this.nMips;r++)this.renderTargetsHorizontal[r].setSize(n,s),this.renderTargetsVertical[r].setSize(n,s),this.separableBlurMaterials[r].uniforms.invSize.value=new Lt(1/n,1/s),n=Math.round(n/2),s=Math.round(s/2)}render(t,e,n,s,r){t.getClearColor(this._oldClearColor),this.oldClearAlpha=t.getClearAlpha();let o=t.autoClear;t.autoClear=!1,t.setClearColor(this.clearColor,0),r&&t.state.buffers.stencil.setTest(!1),this.renderToScreen&&(this.fsQuad.material=this.basic,this.basic.map=n.texture,t.setRenderTarget(null),t.clear(),this.fsQuad.render(t)),this.highPassUniforms.tDiffuse.value=n.texture,this.highPassUniforms.luminosityThreshold.value=this.threshold,this.fsQuad.material=this.materialHighPassFilter,t.setRenderTarget(this.renderTargetBright),t.clear(),this.fsQuad.render(t);let a=this.renderTargetBright;for(let l=0;l<this.nMips;l++)this.fsQuad.material=this.separableBlurMaterials[l],this.separableBlurMaterials[l].uniforms.colorTexture.value=a.texture,this.separableBlurMaterials[l].uniforms.direction.value=i.BlurDirectionX,t.setRenderTarget(this.renderTargetsHorizontal[l]),t.clear(),this.fsQuad.render(t),this.separableBlurMaterials[l].uniforms.colorTexture.value=this.renderTargetsHorizontal[l].texture,this.separableBlurMaterials[l].uniforms.direction.value=i.BlurDirectionY,t.setRenderTarget(this.renderTargetsVertical[l]),t.clear(),this.fsQuad.render(t),a=this.renderTargetsVertical[l];this.fsQuad.material=this.compositeMaterial,this.compositeMaterial.uniforms.bloomStrength.value=this.strength,this.compositeMaterial.uniforms.bloomRadius.value=this.radius,this.compositeMaterial.uniforms.bloomTintColors.value=this.bloomTintColors,t.setRenderTarget(this.renderTargetsHorizontal[0]),t.clear(),this.fsQuad.render(t),this.fsQuad.material=this.blendMaterial,this.copyUniforms.tDiffuse.value=this.renderTargetsHorizontal[0].texture,r&&t.state.buffers.stencil.setTest(!0),this.renderToScreen?(t.setRenderTarget(null),this.fsQuad.render(t)):(t.setRenderTarget(n),this.fsQuad.render(t)),t.setClearColor(this._oldClearColor,this.oldClearAlpha),t.autoClear=o}getSeperableBlurMaterial(t){let e=[];for(let n=0;n<t;n++)e.push(.39894*Math.exp(-.5*n*n/(t*t))/t);return new Ne({defines:{KERNEL_RADIUS:t},uniforms:{colorTexture:{value:null},invSize:{value:new Lt(.5,.5)},direction:{value:new Lt(.5,.5)},gaussianCoefficients:{value:e}},vertexShader:`varying vec2 vUv;
				void main() {
					vUv = uv;
					gl_Position = projectionMatrix * modelViewMatrix * vec4( position, 1.0 );
				}`,fragmentShader:`#include <common>
				varying vec2 vUv;
				uniform sampler2D colorTexture;
				uniform vec2 invSize;
				uniform vec2 direction;
				uniform float gaussianCoefficients[KERNEL_RADIUS];

				void main() {
					float weightSum = gaussianCoefficients[0];
					vec3 diffuseSum = texture2D( colorTexture, vUv ).rgb * weightSum;
					for( int i = 1; i < KERNEL_RADIUS; i ++ ) {
						float x = float(i);
						float w = gaussianCoefficients[i];
						vec2 uvOffset = direction * invSize * x;
						vec3 sample1 = texture2D( colorTexture, vUv + uvOffset ).rgb;
						vec3 sample2 = texture2D( colorTexture, vUv - uvOffset ).rgb;
						diffuseSum += (sample1 + sample2) * w;
						weightSum += 2.0 * w;
					}
					gl_FragColor = vec4(diffuseSum/weightSum, 1.0);
				}`})}getCompositeMaterial(t){return new Ne({defines:{NUM_MIPS:t},uniforms:{blurTexture1:{value:null},blurTexture2:{value:null},blurTexture3:{value:null},blurTexture4:{value:null},blurTexture5:{value:null},bloomStrength:{value:1},bloomFactors:{value:null},bloomTintColors:{value:null},bloomRadius:{value:0}},vertexShader:`varying vec2 vUv;
				void main() {
					vUv = uv;
					gl_Position = projectionMatrix * modelViewMatrix * vec4( position, 1.0 );
				}`,fragmentShader:`varying vec2 vUv;
				uniform sampler2D blurTexture1;
				uniform sampler2D blurTexture2;
				uniform sampler2D blurTexture3;
				uniform sampler2D blurTexture4;
				uniform sampler2D blurTexture5;
				uniform float bloomStrength;
				uniform float bloomRadius;
				uniform float bloomFactors[NUM_MIPS];
				uniform vec3 bloomTintColors[NUM_MIPS];

				float lerpBloomFactor(const in float factor) {
					float mirrorFactor = 1.2 - factor;
					return mix(factor, mirrorFactor, bloomRadius);
				}

				void main() {
					gl_FragColor = bloomStrength * ( lerpBloomFactor(bloomFactors[0]) * vec4(bloomTintColors[0], 1.0) * texture2D(blurTexture1, vUv) +
						lerpBloomFactor(bloomFactors[1]) * vec4(bloomTintColors[1], 1.0) * texture2D(blurTexture2, vUv) +
						lerpBloomFactor(bloomFactors[2]) * vec4(bloomTintColors[2], 1.0) * texture2D(blurTexture3, vUv) +
						lerpBloomFactor(bloomFactors[3]) * vec4(bloomTintColors[3], 1.0) * texture2D(blurTexture4, vUv) +
						lerpBloomFactor(bloomFactors[4]) * vec4(bloomTintColors[4], 1.0) * texture2D(blurTexture5, vUv) );
				}`})}};Hs.BlurDirectionX=new Lt(1,0);Hs.BlurDirectionY=new Lt(0,1);var du={name:"VignetteShader",uniforms:{tDiffuse:{value:null},offset:{value:1},darkness:{value:1}},vertexShader:`

		varying vec2 vUv;

		void main() {

			vUv = uv;
			gl_Position = projectionMatrix * modelViewMatrix * vec4( position, 1.0 );

		}`,fragmentShader:`

		uniform float offset;
		uniform float darkness;

		uniform sampler2D tDiffuse;

		varying vec2 vUv;

		void main() {

			// Eskil's vignette

			vec4 texel = texture2D( tDiffuse, vUv );
			vec2 uv = ( vUv - vec2( 0.5 ) ) * vec2( offset );
			gl_FragColor = vec4( mix( texel.rgb, vec3( 1.0 - darkness ), dot( uv, uv ) ), texel.a );

		}`};var fu={name:"OutputShader",uniforms:{tDiffuse:{value:null},toneMappingExposure:{value:1}},vertexShader:`
		precision highp float;

		uniform mat4 modelViewMatrix;
		uniform mat4 projectionMatrix;

		attribute vec3 position;
		attribute vec2 uv;

		varying vec2 vUv;

		void main() {

			vUv = uv;
			gl_Position = projectionMatrix * modelViewMatrix * vec4( position, 1.0 );

		}`,fragmentShader:`
	
		precision highp float;

		uniform sampler2D tDiffuse;

		#include <tonemapping_pars_fragment>
		#include <colorspace_pars_fragment>

		varying vec2 vUv;

		void main() {

			gl_FragColor = texture2D( tDiffuse, vUv );

			// tone mapping

			#ifdef LINEAR_TONE_MAPPING

				gl_FragColor.rgb = LinearToneMapping( gl_FragColor.rgb );

			#elif defined( REINHARD_TONE_MAPPING )

				gl_FragColor.rgb = ReinhardToneMapping( gl_FragColor.rgb );

			#elif defined( CINEON_TONE_MAPPING )

				gl_FragColor.rgb = OptimizedCineonToneMapping( gl_FragColor.rgb );

			#elif defined( ACES_FILMIC_TONE_MAPPING )

				gl_FragColor.rgb = ACESFilmicToneMapping( gl_FragColor.rgb );

			#elif defined( AGX_TONE_MAPPING )

				gl_FragColor.rgb = AgXToneMapping( gl_FragColor.rgb );

			#endif

			// color space

			#ifdef SRGB_TRANSFER

				gl_FragColor = sRGBTransferOETF( gl_FragColor );

			#endif

		}`};var Ya=class extends _n{constructor(){super();let t=fu;this.uniforms=Ei.clone(t.uniforms),this.material=new Pa({name:t.name,uniforms:this.uniforms,vertexShader:t.vertexShader,fragmentShader:t.fragmentShader}),this.fsQuad=new Ti(this.material),this._outputColorSpace=null,this._toneMapping=null}render(t,e,n){this.uniforms.tDiffuse.value=n.texture,this.uniforms.toneMappingExposure.value=t.toneMappingExposure,(this._outputColorSpace!==t.outputColorSpace||this._toneMapping!==t.toneMapping)&&(this._outputColorSpace=t.outputColorSpace,this._toneMapping=t.toneMapping,this.material.defines={},fe.getTransfer(this._outputColorSpace)===xe&&(this.material.defines.SRGB_TRANSFER=""),this._toneMapping===El?this.material.defines.LINEAR_TONE_MAPPING="":this._toneMapping===Tl?this.material.defines.REINHARD_TONE_MAPPING="":this._toneMapping===Al?this.material.defines.CINEON_TONE_MAPPING="":this._toneMapping===Sr?this.material.defines.ACES_FILMIC_TONE_MAPPING="":this._toneMapping===Cl&&(this.material.defines.AGX_TONE_MAPPING=""),this.material.needsUpdate=!0),this.renderToScreen===!0?(t.setRenderTarget(null),this.fsQuad.render(t)):(t.setRenderTarget(e),this.clear&&t.clear(t.autoClearColor,t.autoClearDepth,t.autoClearStencil),this.fsQuad.render(t))}dispose(){this.material.dispose(),this.fsQuad.dispose()}};var J0=`.pw { position: relative; width: 100%; height: 100%; overflow: hidden; background: #2a1d4a; color: #fff; font-family: "Malgun Gothic", "Apple SD Gothic Neo", sans-serif; }

  .pw { --bg: rgba(36,22,60,.82); --bd: rgba(255,255,255,.35); --ac: #ffaa64; }
  
  canvas.gl { display: block; }
  button { font: inherit; color: inherit; cursor: pointer; }
  #rail { position: absolute; left: 0; top: 0; bottom: 0; width: 56px; background: rgba(28,16,48,.88); border-right: 2px solid var(--bd); display: flex; flex-direction: column; align-items: center; padding-top: 10px; gap: 6px; z-index: 5; }
  #rail .logo { font-weight: 800; font-size: 11px; letter-spacing: .05em; margin-bottom: 8px; opacity: .85; text-align: center; line-height: 1.1; }
  #rail button { width: 44px; height: 48px; background: transparent; border: 2px solid transparent; font-size: 20px; display: flex; flex-direction: column; align-items: center; justify-content: center; gap: 1px; }
  #rail button span { font-size: 10px; font-weight: 700; opacity: .85; }
  #rail button:hover { background: rgba(255,255,255,.08); }
  #rail button.on { background: rgba(255,170,100,.9); border-color: #fff; color: #3a1f4a; }
  #panel { position: absolute; left: 56px; top: 0; bottom: 0; width: 340px; background: var(--bg); border-right: 2px solid var(--bd); backdrop-filter: blur(6px); transform: translateX(-110%); transition: transform .22s; z-index: 4; overflow-y: auto; padding: 14px 16px 30px; box-sizing: border-box; }
  #panel.open { transform: none; }
  #panel h2 { margin: 0 0 12px; font-size: 16px; letter-spacing: .04em; }
  #panel h3 { margin: 16px 0 6px; font-size: 12px; opacity: .8; font-weight: 700; }
  .sec { display: none; } .sec.on { display: block; }
  .row { display: flex; flex-wrap: wrap; gap: 5px; align-items: center; }
  .chip { background: rgba(255,255,255,.08); border: 2px solid var(--bd); padding: 4px 9px; font-size: 12px; font-weight: 700; }
  .chip.on { background: var(--ac); color: #3a1f4a; border-color: #fff; }
  .chip.dis { opacity: .35; pointer-events: none; }
  .sw { width: 22px; height: 22px; border: 2px solid rgba(255,255,255,.4); padding: 0; }
  .sw.on { border-color: #fff; outline: 2px solid var(--ac); }
  input[type=color] { width: 28px; height: 26px; padding: 0; border: 2px solid var(--bd); background: none; }
  input[type=text], select { background: rgba(0,0,0,.3); color: #fff; border: 2px solid var(--bd); padding: 5px 8px; font: inherit; font-size: 13px; width: 100%; box-sizing: border-box; }
  .btn { background: var(--ac); color: #3a1f4a; border: 2px solid #fff; padding: 7px 14px; font-weight: 800; font-size: 13px; }
  .btn.sub { background: rgba(255,255,255,.1); color: #fff; border-color: var(--bd); }
  .btn.danger { background: #c4402e; color: #fff; }
  #previews { display: flex; gap: 8px; justify-content: center; background: rgba(0,0,0,.28); border: 2px solid var(--bd); padding: 10px 6px 6px; margin-bottom: 10px; }
  #previews div { text-align: center; font-size: 10px; opacity: .85; } #previews canvas { image-rendering: pixelated; display: block; margin: 0 auto 2px; }
  .card { display: flex; align-items: center; gap: 10px; background: rgba(255,255,255,.07); border: 2px solid var(--bd); padding: 6px 8px; margin-bottom: 7px; cursor: pointer; }
  .card.sel { border-color: var(--ac); background: rgba(255,170,100,.15); }
  .card canvas { image-rendering: pixelated; width: 36px; height: 44px; } .card .t { flex: 1; font-size: 13px; font-weight: 700; } .card .t small { display: block; font-weight: 400; font-size: 11px; opacity: .8; }
  .card button { padding: 3px 7px; font-size: 11px; background: rgba(255,255,255,.1); border: 2px solid var(--bd); }
  label.tg { display: flex; justify-content: space-between; align-items: center; font-size: 13px; padding: 6px 0; } label.tg input { width: 18px; height: 18px; }
  input[type=range] { width: 100%; }
  #toast { position: absolute; left: 50%; bottom: 24px; transform: translateX(-50%); background: var(--bg); border: 2px solid var(--bd); padding: 8px 16px; font-size: 13px; opacity: 0; transition: opacity .25s; z-index: 6; pointer-events: none; }
  #bubbles { position: absolute; inset: 0; pointer-events: none; overflow: hidden; }
  .bubble { position: absolute; transform: translate(-50%, -100%); background: #fff; color: #2b1d33; font-size: 12px; font-weight: 700; padding: 3px 7px; border: 2px solid #2b1d33; box-shadow: 0 2px 0 rgba(0,0,0,.25); white-space: nowrap; opacity: 0; transition: opacity .25s; }
  .bubble::after { content: ""; position: absolute; left: 50%; bottom: -7px; margin-left: -4px; border: 4px solid transparent; border-top-color: #2b1d33; }
  .bubble.show { opacity: 1; } .pw.nobubble .bubble { display: none; }
  .name { position: absolute; transform: translate(-50%, 0); font-size: 11px; font-weight: 700; text-shadow: 0 1px 0 #2b1d33, 0 0 4px #2b1d33; opacity: 0; transition: opacity .2s; white-space: nowrap; }
  .name.show { opacity: .95; }
  #roomtags .rt { position: absolute; transform: translate(-50%, -50%); font-size: 12px; font-weight: 800; letter-spacing: .12em; padding: 2px 8px; background: rgba(28,16,48,.55); border: 2px solid rgba(255,255,255,.3); opacity: .85; pointer-events: none; }
  .pw.noroomtag #roomtags { display: none; }
`,j0=`<div class="pw"><canvas id="gl" class="gl"></canvas>
<div id="bubbles"></div><div id="roomtags" style="position:absolute;inset:0;pointer-events:none"></div>

<div id="rail">
  <div class="logo">PIXEL<br>HOUSE</div>
  <button data-p="cast">👥<span>친구들</span></button>
  <button data-p="create">✨<span>캐릭터</span></button>
  <button data-p="scene">🎬<span>장면</span></button>
  <button data-p="settings">⚙️<span>설정</span></button>
</div>

<div id="panel">
  <div class="sec" id="s-cast">
    <h2>👥 친구들</h2>
    <div id="castList"></div>
    <button class="btn" id="newChar" style="width:100%;margin-top:6px">＋ 새 캐릭터 만들기</button>
  </div>

  <div class="sec" id="s-create">
    <h2 id="createTitle">✨ 캐릭터 만들기</h2>
    <div id="previews"><div><canvas id="pv0"></canvas>앞</div><div><canvas id="pv1"></canvas>걷기</div><div><canvas id="pv2"></canvas>뒤</div></div>
    <input type="text" id="cName" maxlength="8" placeholder="이름 (최대 8자)">
    <h3>헤어스타일</h3><div class="row" id="o-hairStyle"></div>
    <h3>머리 색</h3><div class="row" id="o-hair"></div>
    <h3>눈 색</h3><div class="row" id="o-eye"></div>
    <h3>피부색</h3><div class="row" id="o-skin"></div>
    <h3>상의</h3><div class="row" id="o-top"></div>
    <h3>상의 색</h3><div class="row" id="o-topC"></div>
    <h3>하의 <small id="dressNote" style="opacity:.7"></small></h3><div class="row" id="o-bottom"></div>
    <h3>하의 색</h3><div class="row" id="o-botC"></div>
    <h3>모자</h3><div class="row" id="o-hat"></div>
    <h3>모자 색</h3><div class="row" id="o-hatC"></div>
    <div class="row" style="margin-top:18px">
      <button class="btn" id="cSave">집에 추가하기</button>
      <button class="btn sub" id="cRand">🎲 랜덤</button>
      <button class="btn sub" id="cCancel">취소</button>
    </div>
  </div>

  <div class="sec" id="s-scene">
    <h2>🎬 장면 테스트</h2>
    <h3>누구에게?</h3><select id="sceneWho"></select>
    <h3>이동</h3><div class="row" id="sceneGo"></div>
    <h3>장소 (선택)</h3><select id="scenePlace"></select>
    <h3>행동</h3><div class="row" id="sceneAct"></div>
    <h3>이야기 읽기 테스트</h3>
    <textarea id="storyIn" rows="4" placeholder="예) 모리는 소파에 앉아 TV를 봤다. 별이는 졸려서 침대로 갔다." style="width:100%;box-sizing:border-box;background:rgba(0,0,0,.3);color:#fff;border:2px solid var(--bd);padding:6px 8px;font:inherit;font-size:13px;resize:vertical"></textarea>
    <div class="row" style="margin-top:6px"><button class="btn" id="storyGo">읽고 반응하기</button><button class="btn sub" id="storyEx">예시 넣기</button></div>
    <div id="storyOut" style="margin-top:8px;font-size:12px;line-height:1.55"></div>
    <p style="font-size:11px;opacity:.7;margin-top:16px;line-height:1.5">나중에 마리나라 확장에서 <code>postMessage({type:'scene', who:'모리', action:'sleep'})</code> 로 같은 명령을 보낼 수 있게 해 둔 자리예요.</p>
  </div>

  <div class="sec" id="s-settings">
    <h2>⚙️ 설정</h2>
    <h3>시간대</h3><div class="row" id="setTod"></div>
    <h3>표시</h3>
    <label class="tg">말풍선<input type="checkbox" id="setBubble" checked></label>
    <label class="tg">방 이름표<input type="checkbox" id="setRoomTag" checked></label>
    <label class="tg">이름표 항상 보기<input type="checkbox" id="setNames"></label>
    <label class="tg">빛 번짐(블룸)<input type="checkbox" id="setBloom" checked></label>
    <h3>움직임</h3>
    <label class="tg">스스로 움직이기<input type="checkbox" id="setAuto" checked></label>
    <label class="tg">카메라 천천히 회전<input type="checkbox" id="setRotate"></label>
    <div style="font-size:12px;margin-top:8px">걷는 속도 <span id="spdVal">1.0</span>×</div><input type="range" id="setSpeed" min="0.5" max="2.5" step="0.1" value="1">
    <h3>데이터</h3>
    <div class="row"><button class="btn sub" id="resetCast">기본 캐릭터로 되돌리기</button></div>
  </div>
</div>
<div id="toast"></div></div>`;function pu(i,t={}){let e=i.shadowRoot||i.attachShadow({mode:"open"});e.innerHTML=`<style>${J0}</style>${j0}`;let n=e.querySelector(".pw"),s=h=>e.querySelector(h),r=h=>e.querySelectorAll(h),o=()=>n.clientWidth||800,a=()=>n.clientHeight||450,l=!0,c=.5;function u(h){return()=>{h|=0,h=h+1831565813|0;let m=Math.imul(h^h>>>15,1|h);return m=m+Math.imul(m^m>>>7,61|m)^m,((m^m>>>14)>>>0)/4294967296}}let f=u(21),p=(h,m=Math.random)=>h[Math.floor(m()*h.length)];function x(h,m,_=0){let w=Math.imul(h|0,374761393)^Math.imul(m|0,668265263)^Math.imul((_|0)+1,2147483647);return w=Math.imul(w^w>>>13,1274126177),((w^w>>>16)>>>0)/4294967296}function y(h,m,_=0){let w=Math.floor(h),v=Math.floor(m),F=h-w,et=m-v,tt=F*F*(3-2*F),ot=et*et*(3-2*et),wt=x(w,v,_),N=x(w+1,v,_),bt=x(w,v+1,_),te=x(w+1,v+1,_);return wt+(N-wt)*tt+(bt-wt)*ot+(wt-N-bt+te)*tt*ot}let M=new qt,g=new qt;function d(h,m,_){return M.setHex(h),g.setHex(m),M.lerp(g,_).getHex()}let C=h=>new qt(h),E=(h,m,_)=>new B(h,m,_),D=h=>typeof h=="number"?"#"+h.toString(16).padStart(6,"0"):h,z=(h,m)=>{let _=Math.min(255,(h>>16&255)*m)|0,w=Math.min(255,(h>>8&255)*m)|0,v=Math.min(255,(h&255)*m)|0;return"#"+(1<<24|_<<16|w<<8|v).toString(16).slice(1)},U={get(h,m){try{let _=localStorage.getItem(h);return _?JSON.parse(_):m}catch{return m}},set(h,m){try{localStorage.setItem(h,JSON.stringify(m))}catch{}}};class L{constructor(m=c){this.size=m,this.d=[]}add(m,_,w,v,F=1){this.d.push([m,_,w,v,F])}box(m,_,w,v,F,et,tt){for(let ot=m;ot<=v;ot++)for(let wt=_;wt<=F;wt++)for(let N=w;N<=et;N++)this.add(ot,wt,N,typeof tt=="function"?tt(ot,wt,N):tt)}build(m,{shadow:_=!0,jit:w=.04}={}){let v=this.d.length,F=this.size,et=new Ca(new Yi(F,F,F),m,Math.max(v,1)),tt=new ve,ot=new qt;for(let wt=0;wt<v;wt++){let[N,bt,te,re,jt]=this.d[wt];tt.makeScale(jt,jt,jt),tt.setPosition(N*F,te*F,bt*F),et.setMatrixAt(wt,tt),ot.setHex(re),w&&ot.offsetHSL(0,0,(x(N*7+3,bt*13+1,Math.floor(te*4))-.5)*w*2),et.setColorAt(wt,ot)}return et.count=v,et.castShadow=et.receiveShadow=_,et.frustumCulled=!1,et}}let Q=new gr({canvas:s("#gl"),antialias:!1,preserveDrawingBuffer:!0});Q.setPixelRatio(Math.min(devicePixelRatio,2)),Q.setSize(o(),a()),Q.outputColorSpace=Ce,Q.toneMapping=Sr,Q.shadowMap.enabled=!0,Q.shadowMap.type=wl;let S=new Ta;S.fog=new Ea(9263784,.008);let R=new nn(36,o()/a(),.5,1800);R.position.set(0,19,31);let V=new Ha(R,Q.domElement);V.target.set(0,1.5,.5),V.enableDamping=!0,V.dampingFactor=.07,V.enablePan=!1,V.minDistance=9,V.maxDistance=58,V.minPolarAngle=.35,V.maxPolarAngle=1.3,V.minAzimuthAngle=-.85,V.maxAzimuthAngle=.85,V.autoRotateSpeed=.5;let nt={dusk:{top:C(3811960),mid:C(13593234),hor:C(16296044),fog:C(9263784),keyCol:C(16756856),keyInt:2.6,hSky:C(11571416),hGnd:C(5914728),hInt:.8,den:.0085,stars:.3,glow:1,win:C(16756848),lamp:.75,bloom:.45,expo:1.15,tint:C(16772834),sun:E(-.9,.16,-.4),disc:C(16763024),discK:1,key:E(-.3,.8,.5)},night:{top:C(461350),mid:C(1777510),hor:C(4012680),fog:C(1907538),keyCol:C(9086719),keyInt:.7,hSky:C(4870816),hGnd:C(2366528),hInt:.85,den:.0105,stars:1,glow:1.9,win:C(1976934),lamp:1.5,bloom:.75,expo:1.3,tint:C(12633328),sun:E(.55,.45,-.7),disc:C(12570879),discK:.65,key:E(.35,.8,.5)},day:{top:C(4032224),mid:C(9227762),hor:C(15267071),fog:C(11852016),keyCol:C(16773336),keyInt:3.2,hSky:C(13626111),hGnd:C(9079400),hInt:1.3,den:.006,stars:0,glow:.5,win:C(14676735),lamp:.12,bloom:.15,expo:1.1,tint:C(16777215),sun:E(-.5,.65,-.5),disc:C(16774344),discK:1,key:E(-.3,.9,.5)}},ft=h=>{let m={};for(let _ in h)m[_]=h[_].clone?h[_].clone():h[_];return m},I=ft(nt.dusk),k=Object.assign({mode:"dusk",bubble:!0,roomtag:!0,names:!1,bloom:!0,auto:!0,rotate:!1,speed:1},U.get("house.settings.v1",{})),$=k.mode;Object.assign(I,ft(nt[$]));function Z(h,m){let _=nt[$],w=m?1:1-Math.exp(-h*2.2);for(let v in I){let F=I[v],et=_[v];typeof F=="number"?I[v]=F+(et-F)*w:F.lerp(et,w)}}let j=new Ne({side:sn,depthWrite:!1,fog:!1,uniforms:{top:{value:I.top},mid:{value:I.mid},hor:{value:I.hor},sunDir:{value:I.sun},disc:{value:I.disc},discK:{value:1}},vertexShader:"varying vec3 vD; void main(){ vD = position; gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0); }",fragmentShader:`uniform vec3 top, mid, hor, sunDir, disc; uniform float discK; varying vec3 vD;
    void main(){ vec3 d = normalize(vD); float h = d.y;
      vec3 c = mix(hor, mid, smoothstep(-0.02, 0.2, h)); c = mix(c, top, smoothstep(0.12, 0.7, h));
      float s = max(dot(d, normalize(sunDir)), 0.0);
      c += disc * (pow(s, 14.0) * 0.5 + pow(s, 160.0) * 0.5) * discK;
      c += disc * smoothstep(0.9988, 0.9992, s) * 2.5 * discK;
      gl_FragColor = vec4(c, 1.0); }`});S.add(new He(new Ra(1e3,32,16),j));let K=new hn;{let m=new Float32Array(4500);for(let _=0;_<1500;_++){let w=f(),v=f()*.97+.03,F=w*Math.PI*2,et=Math.sqrt(1-v*v);m.set([Math.cos(F)*et*900,v*900,Math.sin(F)*et*900],_*3)}K.setAttribute("position",new rn(m,3))}let st=new Ns({color:14673663,size:2.2,sizeAttenuation:!1,transparent:!0,opacity:.3,depthWrite:!1,fog:!1});S.add(new xr(K,st));let it=(()=>{let h=document.createElement("canvas");h.width=h.height=256;let m=h.getContext("2d");m.fillStyle="#e6e6e6",m.fillRect(0,0,256,256);let _=u(5);for(let v=0;v<260;v++){let F=_()*256,et=_()*256,tt=14+_()*40,ot=_()<.5?255:196;for(let wt of[-256,0,256])for(let N of[-256,0,256]){let bt=m.createRadialGradient(F+wt,et+N,0,F+wt,et+N,tt);bt.addColorStop(0,`rgba(${ot},${ot},${ot},.22)`),bt.addColorStop(1,`rgba(${ot},${ot},${ot},0)`),m.fillStyle=bt,m.fillRect(F+wt-tt,et+N-tt,tt*2,tt*2)}}let w=new Os(h);return w.wrapS=w.wrapT=hr,w.repeat.set(22,22),w.colorSpace=Ce,w})(),vt=new xn({map:it,color:10121400}),q=new He(new _r(1300,48),vt);q.rotation.x=-Math.PI/2,q.position.y=-26,S.add(q);let ct=[];{let h=new vr({roughness:1,metalness:0});for(let m=0;m<30;m++){let _=f()*Math.PI*2,w=30+f()*120,v=5+f()*7,F=new L(1.5),et=v*(1+f()*.6),tt=v*(.8+f()*.5);for(let wt=0;wt<5;wt++){let N=1-wt*.19,bt=(f()-.5)*2,te=(f()-.5)*2;for(let re=-Math.ceil(et);re<=Math.ceil(et);re++)for(let jt=-Math.ceil(tt);jt<=Math.ceil(tt);jt++)Math.hypot((re-bt)/(et*N),(jt-te)/(tt*N))+y(re*.4+m,jt*.4,2)*.25>1||F.add(re,jt,wt,d(12166116,15853311,wt/4*.8+x(re,jt,m)*.2))}let ot=F.build(h,{shadow:!1,jit:.02});ot.position.set(Math.cos(_)*w,-25+f()*9,Math.sin(_)*w),S.add(ot),ct.push({m:ot,sp:.1+f()*.25})}}let yt=new Ua(16756856,2.6);yt.castShadow=!0,yt.shadow.mapSize.set(2048,2048),Object.assign(yt.shadow.camera,{left:-20,right:20,top:14,bottom:-14,near:1,far:100}),yt.shadow.normalBias=.03,yt.shadow.bias=-4e-4,S.add(yt,yt.target);let It=new La(11571416,5914728,1.15);S.add(It);let Ot=[[-5,3.6,-4],[7,3.6,-4.5],[-6,3.6,4],[7,3.6,4]].map(h=>{let m=new Da(16763024,8,14,1.7);return m.position.set(...h),S.add(m),m}),Pt=-24,Dt=23,At=-16,kt=15,G=9,Re=3,Ut=4,Gt=0,Rt=(h,m)=>m<Gt?h<Ut?"kitchen":"bedroom":h<Ut?"living":"bath",me={kitchen:"주방",bedroom:"안방",living:"거실",bath:"화장실"},$t={kitchen:15916196,bedroom:14468332,living:15257524,bath:12904178},A=9067062,b=new vr({roughness:.9,metalness:0}),W=new xn({color:16777215}),dt=new xn({color:16777215}),ht=new xn({color:16777215}),rt=(h,m)=>h*1e3+m,Tt=new Set,St=new Set,ut=[],Ft=new vi;S.add(Ft);let Yt=new L,lt=new L,ae=new L,P=(h,m,_)=>h>=m&&h<=_;function at(h,m){for(let v of ge)if(v.type==="rug"){let F={i0:v.i,i1:v.i+v.p.w-1,j0:v.j,j1:v.j+v.p.d-1};if(P(h,F.i0,F.i1)&&P(m,F.j0,F.j1))return h===F.i0||h===F.i1||m===F.j0||m===F.j1?v.p.b:(h+m)%4===0?d(v.p.a,v.p.b,.2):v.p.a}let _=Rt(h,m);if(_==="kitchen")return h+m&1?15920350:14734522;if(_==="bath")return h+m&1?16055295:12574958;let w=m&1?13146720:12291156;return x(h>>3,m,4)<.18?d(w,15253640,.5):w}let mt=null;function pt(){let h=new L;for(let m=Pt-1;m<=Dt+1;m++)for(let _=At-1;_<=kt+1;_++)h.add(m,_,0,at(m,_));for(let m=1;m<=7;m++){let _=[0,0,1,3,6,9,12,15][m],w=[0,9067062,6965854,5786224,4734050,3812946,3023940,2366520][m];for(let v=Pt-2+_;v<=Dt+2-_;v++)for(let F=At-2+_;F<=kt+2-_*.7;F++)h.add(v,Math.round(F),-m,x(v,F,m)<.15?d(w,16777215,.08):w)}mt&&(Ft.remove(mt),mt.geometry.dispose(),mt.dispose()),mt=h.build(b,{jit:.035}),Ft.add(mt)}let Nt=[{ax:"j",pos:At-1,a0:-10,a1:-5,k0:5,k1:8},{ax:"j",pos:At-1,a0:14,a1:19,k0:4,k1:8},{ax:"i",pos:Pt-1,a0:2,a1:4,k0:4,k1:8},{ax:"i",pos:Pt-1,a0:12,a1:14,k0:4,k1:8},{ax:"i",pos:Dt+1,a0:-13,a1:-10,k0:4,k1:7},{ax:"i",pos:Dt+1,a0:8,a1:10,k0:5,k1:7}];function ee(h,m,_){for(let w of Nt){let v=w.ax==="j"?h:m;if((w.ax==="j"?m:h)!==w.pos||!P(v,w.a0,w.a1)||!P(_,w.k0,w.k1))continue;let et=v===w.a0||v===w.a1||_===w.k0||_===w.k1,tt=v===Math.floor((w.a0+w.a1)/2)||_===Math.floor((w.k0+w.k1)/2);return et||tt&&w.a1-w.a0>2?"frame":"glass"}return null}function ie(h,m,_,w){let v=ee(h,m,_);if(v==="glass"){ae.add(h,m,_,16777215);return}if(v==="frame"){Yt.add(h,m,_,16051420);return}let F=$t[w];_===1?F=d(F,A,.55):_===G?F=16051420:w==="bath"&&_<=3?F=h+m+_&1?16055295:14216950:(_+(h|0)+m)%5===0&&x(h,m,_)<.2&&(F=d(F,16777215,.12)),Yt.add(h,m,_,F)}for(let h=Pt-1;h<=Dt+1;h++)for(let m=1;m<=G;m++)ie(h,At-1,m,h<Ut?"kitchen":"bedroom");for(let h=At;h<=kt;h++)for(let m=1;m<=G;m++)ie(Pt-1,h,m,h<Gt?"kitchen":"living"),ie(Dt+1,h,m,h<Gt?"bedroom":"bath");for(let h=At-1;h<=kt;h++)Tt.add(rt(Pt-1,h)),Tt.add(rt(Dt+1,h));for(let h=Pt-1;h<=Dt+1;h++)Tt.add(rt(h,At-1));let Qt=[[-9,-6],[6,9]],_t=[[-18,-6],[12,15]],O=h=>Qt.some(([m,_])=>P(h,m,_)),gt=h=>_t.some(([m,_])=>P(h,m,_)),xt=h=>Qt.some(([m,_])=>h===m-1||h===_+1),Ht=h=>_t.some(([m,_])=>h===m-1||h===_+1);function Bt(h,m,_){let w=_?6:Re;for(let v=1;v<=w;v++)Yt.add(h,m,v,_?v===6?12861486:A:v===Re?14207152:v===1?12098168:15853784)}for(let h=At;h<=kt;h++)O(h)||(Bt(Ut,h,xt(h)),Tt.add(rt(Ut,h)));for(let h=Pt;h<=Dt;h++)h!==Ut&&!gt(h)&&(Bt(h,Gt,Ht(h)),Tt.add(rt(h,Gt)));for(let h=Pt-1;h<=Dt+1;h++){let m=P(h,-9,-6);for(let _=1;_<=(m&&(h===-9||h===-6)?6:1);_++)Yt.add(h,kt+1,_,m&&_===6?12861486:A);P(h,-8,-7)||Tt.add(rt(h,kt+1))}for(let h=-9;h<=-6;h++)Yt.add(h,kt+1,6,12861486);lt.add(-10,kt+1,4,16762976,.8),lt.add(-5,kt+1,4,16762976,.8);let he=[14172206,4890840,16046170,6995818,10124008,15769792,15764010],se={counter:{name:"조리대",size:h=>[h.w||4,2],build({P:h,w:m,p:_}){for(let w=0;w<m;w++)for(let v=0;v<2;v++){let F=w%3===0&&v===1?9724470:11829836;h(w,v,1,F),h(w,v,2,F),h(w,v,3,15854560)}for(let w of _.items||[])h(w.x,w.z,w.k,w.col,w.sc)}},sink:{name:"싱크대",size:()=>[3,2],build({P:h}){for(let m=0;m<3;m++)for(let _=0;_<2;_++)h(m,_,1,11829836),h(m,_,2,11829836),h(m,_,3,8046832);h(1,0,4,9079446,.35),h(1,0,4.45,9079446,.35)},slots:()=>[{kind:"cook",walk:[1,2],at:[1,2],face:[0,-1],pose:"stand",txt:"설거지 중",say:["쓱싹쓱싹","♪"]}]},stove:{name:"가스레인지",size:()=>[3,2],build({P:h,G:m}){for(let _=0;_<3;_++)for(let w=0;w<2;w++)h(_,w,1,6974070),h(_,w,2,6974070),h(_,w,3,2763312);m(1,1,3.75,16747056,.5),h(2,1,4,10132136,.9),h(2,1,4.55,8026760,.5)},slots:()=>[{kind:"cook",walk:[1,2],at:[1,2],face:[0,-1],pose:"stand",txt:"요리 중",say:["보글보글","맛있겠다","간 맞추는 중"],steam:!0}],emit:()=>[{type:"steam",x:2,z:1,k:5}]},upper_cabinet:{name:"벽 찬장",size:h=>[h.w||4,1],noBlock:!0,build({P:h,w:m}){for(let _=0;_<m;_++)for(let w=6;w<=8;w++)h(_,0,w,w===6&&_%3===0?6963752:9067066);for(let _=1;_<m;_+=3)h(_,1,7,15255672,.3)}},fridge:{name:"냉장고",size:()=>[2,2],build({P:h,box:m}){m(0,0,1,1,1,7,(_,w,v)=>v===5?12107976:15265522),h(1,2,3,9079446,.4),h(1,2,6,9079446,.4)}},table:{name:"식탁",size:h=>[h.w||6,h.d||4],build({P:h,w:m,d:_}){for(let w=0;w<m;w++)for(let v=0;v<_;v++)h(w,v,2,13145948);for(let[w,v]of[[0,0],[m-1,0],[0,_-1],[m-1,_-1]])h(w,v,1,9067062);h(3,1,3,16053496,.6),h(3,1,3.45,15764010,.4),h(2,2,3.3,14172206,.35),h(4,2,3.3,16046170,.35)}},chair:{name:"의자",size:()=>[1,2],build({P:h,p:m}){h(0,0,1,12077624),h(0,0,2,12077624),(m.backH||3)>=3&&h(0,0,3,12077624),h(0,1,1,14180426)},slots:h=>[{kind:"eat",walk:[h.p.side||-1,1],at:[0,1],face:[0,1],pose:"sit",y:.75,txt:"식사 중",say:["냠냠","맛있다!","잘 먹겠습니다","한 입 더!"]}]},bed:{name:"침대",size:()=>[8,6],build({P:h,box:m}){m(0,0,1,0,5,2,9067062),m(7,0,1,7,5,5,9067062);for(let _=1;_<=6;_++)for(let w=0;w<6;w++)h(_,w,1,9067062),h(_,w,2,_>=5?16315628:(_+w)%2?15239848:15769784);h(6,1,2.75,16777215,.6),h(6,4,2.75,16777215,.6),h(2,4,2.9,12092492,.6),h(2,4,3.3,12092492,.4)},slots:()=>[{kind:"sleep",walk:[3,6],at:[4,3],face:[1,0],pose:"lie",y:1.25,txt:"자는 중",say:["zzz","zZ…","쿨쿨"]}]},nightstand:{name:"협탁",size:()=>[2,2],build({P:h,G:m,box:_}){_(0,0,1,1,1,2,10512444),h(1,0,3,16051420,.5),m(1,0,3.75,16767120,.7)}},wardrobe:{name:"옷장",size:()=>[4,2],build({P:h,box:m}){m(0,0,1,3,1,8,(_,w)=>_===1&&w===1?6963752:9067066),h(1,2,4,15255672,.3),h(2,2,4,15255672,.3)},slots:()=>[{kind:"dress",walk:[1,2],at:[1,2],face:[0,-1],pose:"stand",txt:"옷 고르는 중",say:["뭐 입지?","이거 어때?"]}]},dresser:{name:"화장대",size:()=>[3,2],build({P:h,box:m}){m(0,0,1,2,1,3,11829836);for(let _=0;_<3;_++)for(let w=5;w<=7;w++)h(_,0,w,_===0||_===2||w===5||w===7?9067062:13167864)}},curtain:{name:"커튼",size:()=>[1,1],noBlock:!0,build({P:h}){for(let m=4;m<=8;m++)h(0,0,m,11565272)}},plant:{name:"화분",size:()=>[3,3],build({P:h,p:m}){h(1,1,1,12869678),h(1,1,2,12869678,.9);for(let _=-1;_<=1;_++)for(let w=-1;w<=1;w++)for(let v=0;v<=2;v++)Math.abs(_)+Math.abs(w)+(v?0:1)<=2&&x(_+(m.seed||0),w,v)<.85&&h(1+_,1+w,3+v,x(_+9,w,v)<.5?5216826:7321162)}},bathtub:{name:"욕조",size:()=>[8,5],build({P:h}){for(let m=0;m<8;m++)for(let _=0;_<5;_++){let w=m===0||_===0||_===4||m===7;h(m,_,1,w?16053496:(m+_)%3?8048880:10150136),w&&h(m,_,2,16053496)}for(let[m,_]of[[2.2,1],[4.2,3],[6.2,1],[3.2,3],[5.2,2]])h(m,_,1.7,16777215,.5);h(1,1,1.75,16767050,.45),h(0,2,3,10132136,.4),h(0,2,3.6,10132136,.4),h(1,2,3.6,10132136,.4)},slots:()=>[{kind:"bath",walk:[3,5],at:[3,2],face:[0,1],pose:"bath",y:.95,txt:"목욕 중",say:["으아~ 시원해","♪","거품 거품"]}],emit:()=>[{type:"bubbles",x:4,z:2,k:2}]},toilet:{name:"변기",size:()=>[2,3],build({box:h}){h(0,0,1,1,0,4,16053496),h(0,1,1,1,2,2,16053496),h(0,2,3,1,2,3,15263984)}},vanity:{name:"세면대",size:()=>[4,2],build({P:h,box:m}){m(0,0,1,3,1,3,13152400),m(1,0,3,2,1,3,13627647);for(let _=0;_<4;_++)for(let w=5;w<=8;w++)h(_,-1,w,_===0||_===3||w===5||w===8?9067062:13627647)},slots:()=>[{kind:"wash",walk:[1,2],at:[1,2],face:[0,-1],pose:"stand",txt:"세수 중",say:["쓱쓱","양치 중…"]}]},washer:{name:"세탁기",size:()=>[3,3],build({box:h}){h(0,0,1,2,2,4,(m,_,w)=>m===1&&_===2&&w>=2&&w<=3?6990040:16053496)},slots:()=>[{kind:"wash",walk:[1,-1],at:[1,-1],face:[0,1],pose:"stand",txt:"빨래 중",say:["뽀송뽀송","돌아간다~"]}]},basket:{name:"빨래바구니",size:()=>[2,2],build({P:h,box:m}){m(0,0,1,1,1,2,11829836),h(0,0,3,15226698,.5),h(1,0,3,4890840,.5)}},tv_unit:{name:"TV장",size:h=>[h.w||7,1],build({P:h,T:m,w:_}){for(let w=0;w<_;w++)h(w,0,1,9067066),h(w,0,2,9067066);for(let w=1;w<_-1;w++)for(let v=3;v<=6;v++)w>=2&&w<=_-3&&v>=4&&v<=5?m(w,0,v,16777215):h(w,0,v,2236970);for(let w=2;w<=_-3;w++)for(let v=7;v<=8;v++)h(w,0,v,(w+v)%2?15769664:w===3?6994136:14180426)}},sofa:{name:"소파",size:()=>[11,4],build({P:h}){for(let m=0;m<4;m++)for(let _ of[0,10])for(let w=1;w<=3;w++)h(_,m,w,12077624);for(let m=1;m<=9;m++){for(let _=1;_<=3;_++)h(m,_,1,14180426),h(m,_,2,m%3===1&&_>=2?12865596:15235682);for(let _=1;_<=3;_++)h(m,0,_,_===3?12865596:14180426)}},slots:()=>[[3,["재밌다","ㅋㅋㅋ","다음 화!"]],[5,["어, 저거다","헉"]],[7,["과자 먹고 싶다","♪"]]].map(([h,m])=>({kind:"tv",walk:[h,4],at:[h,2],face:[0,1],pose:"sit",y:1.25,txt:"TV 보는 중",say:m}))},coffee_table:{name:"테이블",size:()=>[3,5],build({P:h}){for(let m=0;m<3;m++)for(let _=0;_<5;_++)h(m,_,2,10514496);for(let[m,_]of[[0,0],[2,0],[0,4],[2,4]])h(m,_,1,8014380);h(1,2,3,14172206,.55),h(0,1,3,16051420,.4)}},floor_lamp:{name:"스탠드",size:()=>[1,1],build({P:h,G:m}){for(let _=1;_<=6;_++)h(0,0,_,4864560);m(0,0,7,16767120,1.1)}},bookshelf:{name:"책장",size:()=>[4,2],build({box:h}){h(0,0,1,3,1,7,(m,_,w)=>w%2===1||_===0||x(m,w,6)<.12?9067066:he[Math.floor(x(m,w,7)*he.length)])},slots:()=>[{kind:"read",walk:[1,2],at:[1,2],face:[0,-1],pose:"stand",txt:"책 고르는 중",say:["이 책 재밌나?","흠…"]}]},armchair:{name:"안락의자",size:()=>[3,4],build({box:h}){h(0,0,1,2,0,2,3836096),h(0,1,1,2,3,1,4890840),h(0,1,2,2,3,2,5945576)},slots:()=>[{kind:"read",walk:[1,4],at:[1,2],face:[0,1],pose:"sit",y:1.25,txt:"책 읽는 중",say:["…","한 장만 더"]}]},rug:{name:"러그",size:h=>[h.w,h.d],noBlock:!0,floor:!0}},Oe=Object.keys(se),ge=[{type:"counter",i:-23,j:-16,p:{w:2}},{type:"sink",i:-21,j:-16},{type:"counter",i:-18,j:-16,p:{w:2,items:[{x:0,z:1,k:3.7,col:16051420,sc:.35}]}},{type:"stove",i:-16,j:-16},{type:"counter",i:-13,j:-16,p:{w:10,items:[{x:7,z:1,k:4,col:14172206,sc:.8},{x:4,z:1,k:3.75,col:15764010,sc:.45},{x:5,z:1,k:3.75,col:14172206,sc:.4}]}},{type:"upper_cabinet",i:-23,j:-16,p:{w:12}},{type:"fridge",i:-24,j:-13,rot:3},{type:"table",i:-12,j:-9,p:{w:6,d:4}},{type:"chair",i:-11,j:-11,rot:0,p:{backH:3,side:-1}},{type:"chair",i:-8,j:-11,rot:0,p:{backH:3,side:1}},{type:"chair",i:-11,j:-5,rot:2,p:{backH:2,side:1}},{type:"chair",i:-8,j:-5,rot:2,p:{backH:2,side:-1}},{type:"plant",i:-3,j:-15},{type:"rug",i:-13,j:-11,p:{w:8,d:8,a:15235162,b:12865596}},{type:"bed",i:16,j:-12},{type:"nightstand",i:22,j:-14},{type:"nightstand",i:22,j:-6},{type:"wardrobe",i:5,j:-16},{type:"dresser",i:10,j:-16},{type:"curtain",i:13,j:-16},{type:"curtain",i:20,j:-16},{type:"plant",i:5,j:-4,p:{seed:3}},{type:"rug",i:9,j:-11,p:{w:8,d:8,a:15771840,b:14188700}},{type:"bathtub",i:16,j:1},{type:"toilet",i:21,j:9,rot:1},{type:"vanity",i:21,j:12,rot:1},{type:"washer",i:6,j:13},{type:"basket",i:11,j:14},{type:"rug",i:17,j:7,p:{w:5,d:3,a:9097448,b:5941448}},{type:"tv_unit",i:-24,j:5,rot:3,p:{w:7}},{type:"sofa",i:-16,j:3,rot:1},{type:"coffee_table",i:-20,j:6},{type:"floor_lamp",i:-11,j:14},{type:"bookshelf",i:0,j:1},{type:"armchair",i:-6,j:11,rot:1},{type:"plant",i:1,j:12,p:{seed:7}},{type:"rug",i:-22,j:3,p:{w:12,d:11,a:3840676,b:2781050}},{type:"rug",i:-9,j:13,p:{w:4,d:3,a:8018492,b:5914408}}];ge.forEach((h,m)=>{h.id=h.id||h.type+"-"+m,h.rot=h.rot||0,h.p=h.p||{}});function pe(h,m,_){let w=(h.rot||0)&3;return{W:w&1?_:m,D:w&1?m:_,pt:(v,F)=>w===0?[v,F]:w===1?[_-1-F,v]:w===2?[m-1-v,_-1-F]:[F,m-1-v],fc:(v,F)=>w===0?[v,F]:w===1?[-F,v]:w===2?[-v,-F]:[F,-v]}}let Fe=h=>{let m=se[h.type],[_,w]=m.size(h.p),v=pe(h,_,w);return{i0:h.i,j0:h.j,i1:h.i+v.W-1,j1:h.j+v.D-1}};function vn(){let h=[{kind:"out",walk:[-8,15],at:[-8,15],face:[0,1],pose:"stand",txt:"외출 중",say:["다녀올게!","금방 올게~"],arch:!0}];for(let m of Nt){let _=Math.floor((m.a0+m.a1)/2),w,v,F;if(m.ax==="j")w=_,v=m.pos+2,F=[0,-1];else{let et=m.pos===Pt-1;w=et?m.pos+2:m.pos-2,v=_,F=[et?-1:1,0]}!St.has(rt(w,v))&&P(w,Pt,Dt)&&P(v,At,kt)&&h.push({kind:"view",walk:[w,v],at:[w,v],face:F,pose:"stand",txt:"창밖 구경 중",say:["노을 예쁘다","구름이다","저 구름 봐!","…"],arch:!0})}return h}let Ai=[],Ci=null,Zn=null,Ri=null;function Bn(){let h=new L,m=new L,_=new L;St=new Set(Tt),Ai.length=0;let w=[];for(let v of ge){let F=se[v.type];if(!F)continue;let[et,tt]=F.size(v.p),ot=pe(v,et,tt),wt=(le,Ae)=>{let[ze,je]=ot.pt(le,Ae);return[v.i+ze,v.j+je]},N=le=>(Ae,ze,je,ue,ke=1)=>{let[Ct,Te]=wt(Ae,ze);le.add(Ct,Te,je,ue,ke)},bt=N(h),te=N(m),re=N(_),Le={P:bt,G:te,T:re,box:(le,Ae,ze,je,ue,ke,Ct)=>{for(let Te=le;Te<=je;Te++)for(let Wn=Ae;Wn<=ue;Wn++)for(let un=ze;un<=ke;un++)bt(Te,Wn,un,typeof Ct=="function"?Ct(Te,Wn,un):Ct)},w:et,d:tt,p:v.p};if(F.build&&F.build(Le),!F.noBlock)for(let le=0;le<et;le++)for(let Ae=0;Ae<tt;Ae++)St.add(rt(...wt(le,Ae)));if(F.slots)for(let le of F.slots(Le)){let Ae=ot.fc(...le.face);w.push({...le,walk:wt(...le.walk),at:wt(...le.at),face:Ae,owner:v.id})}if(F.emit)for(let le of F.emit(Le)){let[Ae,ze]=ot.pt(le.x,le.z);Ai.push({type:le.type,x:(v.i+Ae)*c,z:(v.j+ze)*c,y:le.k*c,owner:v.id})}}if(fn=w.concat(vn()),Ci){Ft.remove(Ci,Zn,Ri);for(let v of[Ci,Zn,Ri])v.geometry.dispose(),v.dispose()}Ci=h.build(b,{jit:.04}),Zn=m.build(W,{shadow:!1,jit:0}),Ri=_.build(ht,{shadow:!1,jit:0}),Ft.add(Ci,Zn,Ri),pt(),wn();for(let v of ut)if(ts(v),v.plan=null,v.path=null,v.state="idle",v.timer=.4,!de(...Qi(v))){let[F,et]=Qi(v),tt=Pe.reduce((ot,wt)=>Math.hypot(wt[0]-F,wt[1]-et)<Math.hypot(ot[0]-F,ot[1]-et)?wt:ot,Pe[0]);v.pos.set(tt[0]*c,0,tt[1]*c)}}function Vs(h,m){let _=Fe(h),w=se[h.type];if(!(P(_.i0,Pt,Dt)&&P(_.i1,Pt,Dt)&&P(_.j0,At,kt)&&P(_.j1,At,kt)))return!1;if(w.noBlock)return!0;for(let v=_.i0;v<=_.i1;v++)for(let F=_.j0;F<=_.j1;F++)if(Tt.has(rt(v,F)))return!1;for(let v of ge){if(v.id===m||v===h||se[v.type].noBlock)continue;let F=Fe(v);if(_.i0<=F.i1&&_.i1>=F.i0&&_.j0<=F.j1&&_.j1>=F.j0)return!1}return!0}function Er(h,m,_,w){let v=ge.find(et=>et.id===h);if(!v)return!1;let F={...v,i:m,j:_,rot:w??v.rot};return Vs(F,h)?(Object.assign(v,{i:m,j:_,rot:F.rot}),Bn(),!0):!1}function qa(h,m,_,w=0,v={}){let F={id:h+"-"+Math.random().toString(36).slice(2,6),type:h,i:m,j:_,rot:w,p:v};return!se[h]||!Vs(F)?null:(ge.push(F),Bn(),F.id)}function Za(h){let m=ge.findIndex(_=>_.id===h);return m<0?!1:(ge.splice(m,1),Bn(),!0)}Ft.add(Yt.build(b,{jit:.025})),Ft.add(ae.build(dt,{shadow:!1,jit:0})),Ft.add(lt.build(W,{shadow:!1,jit:0}));let $i={kitchen:[-13,-8],bedroom:[14,-9],living:[-10,8],bath:[14,8]},T={};for(let h in $i){let m=document.createElement("div");m.className="rt",m.textContent=me[h],s("#roomtags").appendChild(m),T[h]=m}let H=(()=>{let h=document.createElement("canvas");h.width=h.height=64;let m=h.getContext("2d"),_=m.createRadialGradient(32,32,0,32,32,32);_.addColorStop(0,"rgba(255,255,255,1)"),_.addColorStop(.35,"rgba(255,255,255,.55)"),_.addColorStop(1,"rgba(255,255,255,0)"),m.fillStyle=_,m.fillRect(0,0,64,64);let w=new Os(h);return w.colorSpace=Ce,w})();function X(h,m,_,w,v=1){let F=new hn;F.setAttribute("position",new rn(new Float32Array(h*3),3));let et=new xr(F,new Ns({map:H,size:m,color:_,transparent:!0,opacity:v,blending:w,depthWrite:!1}));return et.frustumCulled=!1,S.add(et),et}let J=X(18,.8,16777215,si,.35),Y=Array.from({length:18},()=>({t:Math.random()*3})),Et=X(50,.14,16773320,Rs,.6),zt=Array.from({length:50},()=>({x:(Math.random()-.5)*22,y:.8+Math.random()*3,z:(Math.random()-.5)*14,ph:Math.random()*6,sp:.2+Math.random()*.4})),Xt=X(10,.3,16777215,si,.7),Zt=Array.from({length:10},()=>({t:Math.random()*4})),Vt=30,Wt=64,Jt=new Uint8Array(Wt*Wt),de=(h,m)=>h+Vt>=0&&m+Vt>=0&&h+Vt<Wt&&m+Vt<Wt&&Jt[(h+Vt)*Wt+m+Vt]===1,Pe=[],ye={kitchen:[],bedroom:[],living:[],bath:[]};function wn(){Jt.fill(0),Pe.length=0;for(let h in ye)ye[h].length=0;for(let h=Pt;h<=Dt;h++)for(let m=At;m<=kt;m++)St.has(rt(h,m))||(Jt[(h+Vt)*Wt+m+Vt]=1);for(let h of[-8,-7])Jt[(h+Vt)*Wt+kt+1+Vt]=1;for(let h=Pt;h<=Dt;h++)for(let m=At;m<=kt;m++)de(h,m)&&(Pe.push([h,m]),ye[Rt(h,m)].push([h,m]))}function _e(h,m,_,w){if(!de(_,w)||!de(h,m))return null;let v=(wt,N)=>(wt+Vt)*Wt+N+Vt,F=new Map([[v(h,m),0]]),et=new Map,tt=new Set,ot=[[0,h,m]];for(;ot.length;){let wt=0;for(let re=1;re<ot.length;re++)ot[re][0]<ot[wt][0]&&(wt=re);let[,N,bt]=ot.splice(wt,1)[0],te=v(N,bt);if(!tt.has(te)){if(tt.add(te),N===_&&bt===w){let re=[[N,bt]],jt=te;for(;et.has(jt);){let Le=et.get(jt);re.push([Le[0],Le[1]]),jt=v(Le[0],Le[1])}return re.reverse()}for(let re=-1;re<=1;re++)for(let jt=-1;jt<=1;jt++){if(!re&&!jt)continue;let Le=N+re,le=bt+jt;if(!de(Le,le)||re&&jt&&(!de(N+re,bt)||!de(N,bt+jt)))continue;let Ae=F.get(te)+(re&&jt?1.414:1),ze=v(Le,le);if(F.has(ze)&&F.get(ze)<=Ae)continue;F.set(ze,Ae),et.set(ze,[N,bt]);let je=Math.abs(_-Le),ue=Math.abs(w-le);ot.push([Ae+(je+ue)+(1.414-2)*Math.min(je,ue),Le,le])}}}return null}let Kt=.25,fn=[];Bn();let be=["cook","eat","sleep","view","dress","bath","wash","tv","read","out"],zn={sleep:"잠자기",tv:"TV 보기",cook:"요리",eat:"식사",bath:"목욕",wash:"씻기·빨래",read:"독서",view:"창밖 구경",dress:"옷 고르기",out:"외출",chat:"대화",intimate:"19♥"},Gs={kitchen:"주방",living:"거실",bedroom:"안방",bath:"화장실"},Pi={sleep:["잠","자다","침대","꿈","sleep"],tv:["tv","티비","텔레비전","소파"],cook:["요리","부엌","주방","cook"],eat:["식사","밥","먹","eat"],bath:["목욕","욕조","bath"],wash:["씻","세수","양치","빨래"],read:["책","독서"],view:["창밖","창문"],out:["외출","나가","산책"],chat:["대화","수다","이야기"]},Ws=[["sleep",["잠","자러","자고","자는","잔다","잤","졸","침대에 누","눕","꿈나라","취침","낮잠","sleep"]],["tv",["tv","티비","텔레비전","시청","드라마","영화"]],["cook",["요리","조리","끓","볶","설거지","cook"]],["eat",["식사","밥","먹","식탁","간식","점심","저녁을","아침을"]],["bath",["목욕","샤워","욕조","bath"]],["wash",["세수","양치","씻","빨래","세탁"]],["read",["독서","책을","책장","읽"]],["dress",["갈아입","옷장","옷을"]],["view",["창밖","창문","노을","구경"]],["out",["외출","나갔","나가","산책","집을 나","장보"]],["chat",["대화","수다","얘기","말을 걸","이야기를 나","속삭"]]],We=["섹스","성관계","정사","잠자리를","몸을 섞","애무","알몸","나체","옷을 벗","벗겼","절정","삽입","쾌감","오르가","sex","nsfw","naked","orgasm","moan"],kn=[["table",["식탁","밥상"]],["bed",["침대","이불"]],["sofa",["소파"]],["bathtub",["욕조","욕탕"]],["vanity",["세면대"]],["washer",["세탁기"]],["sink",["싱크대"]],["stove",["가스레인지","레인지"]],["bookshelf",["책장","서재"]],["armchair",["안락의자"]],["wardrobe",["옷장"]],["door",["현관","문 앞"]],["window",["창가","창문"]],["living",["거실"]],["kitchen",["주방","부엌"]],["bedroom",["안방","침실"]],["bath",["화장실","욕실"]]],Jn={table:{furn:["table"],kinds:["eat"]},bed:{furn:["bed"],kinds:["sleep"]},sofa:{furn:["sofa"],kinds:["tv"]},bathtub:{furn:["bathtub"],kinds:["bath"]},vanity:{furn:["vanity"],kinds:["wash"]},washer:{furn:["washer"],kinds:["wash"]},sink:{furn:["sink"],kinds:["cook"]},stove:{furn:["stove"],kinds:["cook"]},bookshelf:{furn:["bookshelf"],kinds:["read"]},armchair:{furn:["armchair"],kinds:["read"]},wardrobe:{furn:["wardrobe"],kinds:["dress"]},door:{kinds:["out"]},window:{kinds:["view"]},living:{room:"living"},kitchen:{room:"kitchen"},bedroom:{room:"bedroom"},bath:{room:"bath"}},Je={table:"식탁",bed:"침대",sofa:"소파",bathtub:"욕조",vanity:"세면대",washer:"세탁기",sink:"싱크대",stove:"가스레인지",bookshelf:"책장",armchair:"안락의자",wardrobe:"옷장",door:"현관",window:"창가",living:"거실",kitchen:"주방",bedroom:"안방",bath:"화장실"},Xs=h=>{let m=String(h).toLowerCase();for(let[_,w]of kn)if(w.some(v=>m.includes(v)))return _;return null},Ys=h=>!!(Jn[h]&&Jn[h].room),Tr=h=>ge.find(m=>m.id===h);function mu(h){let m=Jn[h];if(!m)return[];if(m.room)return fn.filter(w=>Rt(w.at[0],w.at[1])===m.room);let _=[];return m.furn&&(_=fn.filter(w=>{let v=w.owner&&Tr(w.owner);return v&&m.furn.includes(v.type)})),!_.length&&m.kinds&&(_=fn.filter(w=>m.kinds.includes(w.kind))),_}function Fl(h){let m=Jn[h];if(!m)return[];if(m.room)return ye[m.room].slice();if(h==="door")return[[-8,15],[-7,15],[-9,14],[-8,14],[-7,14]].filter(([w,v])=>de(w,v));if(h==="window")return fn.filter(w=>w.kind==="view").map(w=>w.at);let _=[];for(let w of ge)if(m.furn&&m.furn.includes(w.type)){let v=Fe(w),F=(v.i0+v.i1)/2,et=(v.j0+v.j1)/2;for(let tt=v.i0-1;tt<=v.i1+1;tt++)for(let ot=v.j0-1;ot<=v.j1+1;ot++)(tt<v.i0||tt>v.i1||ot<v.j0||ot>v.j1)&&de(tt,ot)&&_.push([tt,ot,Math.hypot(tt-F,ot-et)])}return _.sort((w,v)=>w[2]-v[2]),_.map(w=>[w[0],w[1]])}function Bl(h,m){if(!h||h.length<2)return null;let _=m?h[Math.floor(Math.random()*h.length)]:h[Math.floor(Math.random()*Math.min(h.length,4))],w=h.find(v=>v!==_&&Math.hypot(v[0]-_[0],v[1]-_[1])<=1.5)||h.find(v=>v!==_);return w?[_,w]:null}function zl(h){let m=[];for(let _ of String(h).matchAll(/[^.!?\n]+[.!?]?/g)){let w=_[0].trim();if(!w)continue;let v=w.toLowerCase(),F=null,et=null,tt=We.find(bt=>v.includes(bt));if(tt&&(F="intimate",et=tt),!F)for(let[bt,te]of Ws){let re=te.find(jt=>v.includes(jt));if(re){F=bt,et=re;break}}let ot=null,wt=null;for(let[bt,te]of kn){let re=te.find(jt=>v.includes(jt));if(re){ot=bt,wt=re;break}}if(!F&&ot){let bt=Jn[ot];F=bt.room?"goto_"+bt.room:bt.kinds[0],et=wt}let N=ut.filter(bt=>w.includes(bt.def.name)).map(bt=>bt.def.name);m.push({sentence:w,who:N.length?N:["*"],action:F,keyword:et,place:ot,placeKeyword:wt})}return m}function Ja(h){let m=zl(h);for(let _ of m)if(_.action)if(_.action==="intimate")_.who[0]!=="*"&&es(_.who[0],"intimate",_.who[1],_.place);else if(_.action==="chat"&&_.who.length>=2)es(_.who[0],"chat",_.who[1],_.place);else for(let w of _.who)es(w,_.action,void 0,_.place);return m}let gu=h=>h.startsWith("goto_")?Gs[h.slice(5)]+"(으)로 이동":zn[h]||h,Ie=18,Be=22,Ki=.088,ja=[43,29,51];function xu(h,m,_,w,v,F){let et=document.createElement("canvas");et.width=Ie,et.height=Be;let tt=et.getContext("2d"),ot=v===1||v===2?1:0,wt=v===3,N=(ce,Se,Xe,on,Cn,ui=1)=>{tt.fillStyle=D(Cn),tt.fillRect(1+ce,1+Se+(ui?ot:0),Xe,on)},{skin:bt,hair:te,eye:re,top:jt,topC:Le,bottom:le,botC:Ae,hat:ze,hatC:je,hairStyle:ue}=F,ke=z(bt,.88),Ct=D(te),Te=z(te,.75),Wn=z(te,1.25),un=D(Le),$e=z(Le,.78),dn=D(Ae),Lr=z(Ae,.75),Ir="#3a2a30",ao="#2a1d2a",oo=D(re),$s=z(je,.78),Du=z(je,1.15),rc="#c85a64",ci="#f06a9a",hi=jt==="dress",ac=jt==="hood"||jt==="shirt",oc=ce=>v===1&&ce==="l"||v===2&&ce==="r"?1:0,lo=(ce,Se,Xe,on)=>{le==="pants"&&!hi?N(ce,15,Se,4-Xe,on?Lr:dn,0):le==="shorts"&&!hi?(N(ce,15,Se,2,on?Lr:dn,0),N(ce,17,Se,2-Xe,bt,0)):N(ce,15,Se,4-Xe,bt,0),N(ce,19-Xe,Se,1,Ir,0)},co=ce=>{ze==="cap"?(N(5,2,6,2,je),N(6,1,4,1,je),ce==="f"?N(4,4,8,1,$s):ce==="s"?N(9,4,3,1,$s):N(5,4,6,1,$s)):ze==="straw"&&(N(6,1,4,2,je),N(6,2,4,1,$s),N(3,3,10,1,Du),ce!=="b"&&N(4,4,8,1,$s))};if(w<2){if(wt){let Cn=(le==="pants"||le==="shorts")&&!hi?dn:D(bt);N(5,15,6,1,Cn,0),N(7,16,2,1,Cn,0),N(5,16,2,1,Ir,0),N(9,16,2,1,Ir,0)}else lo(5,3,oc("l"),!1),lo(8,3,oc("r"),!0);let ce=v===1?1:v===2?-1:0,Se=ce>0?1:0,Xe=ce<0?1:0,on=(Cn,ui,lc)=>{ac?(N(Cn,10+ui,1,3,lc),N(Cn,13+ui,1,1,bt)):(N(Cn,10+ui,1,2,lc),N(Cn,12+ui,1,2,bt))};on(3,Se,un),on(12,Xe,$e),N(4,9,8,6,un),N(10,10,2,5,$e),hi?(N(3,15,10,2,un),N(3,16,10,1,$e)):le==="skirt"?(N(4,14,8,1,dn),N(3,15,10,2,dn),N(3,16,10,1,Lr)):N(4,14,8,1,dn),w===0?((jt==="tee"||hi)&&N(7,9,2,1,bt),jt==="hood"&&(N(5,9,6,1,$e),N(7,10,1,2,"#f4f0e8"),N(9,10,1,2,"#f4f0e8"),N(6,12,4,2,$e)),jt==="shirt"&&(N(6,9,4,1,"#f4f4f8"),N(8,11,1,1,"#f4f4f8"),N(8,13,1,1,"#f4f4f8")),hi&&N(7,10,2,1,$e)):jt==="hood"&&N(5,9,6,2,$e),N(5,3,6,6,bt),w===0&&(N(6,6,1,1,ao),N(6,7,1,1,oo),N(9,6,1,1,ao),N(9,7,1,1,oo),N(5,7,1,1,"#f09a9a"),N(10,7,1,1,"#f09a9a"),N(8,8,1,1,rc)),w===0?(ue!=="spiky"&&(N(6,2,4,1,Ct),N(5,3,6,1,Ct)),(ue==="short"||ue==="pony"||ue==="twin"||ue==="bun")&&(N(5,4,2,1,Ct),N(9,4,2,1,Ct),N(5,5,1,1,Ct),N(10,5,1,1,Ct),N(7,4,1,1,Ct)),ue==="bob"&&(N(5,4,6,1,Ct),N(4,3,1,6,Ct),N(11,3,1,6,Ct),N(5,5,1,3,Ct),N(10,5,1,3,Ct),N(7,3,2,1,Wn)),ue==="long"&&(N(5,4,2,1,Ct),N(9,4,2,1,Ct),N(5,5,1,4,Ct),N(10,5,1,4,Ct),N(4,9,2,5,Ct),N(10,9,2,5,Ct),N(4,13,2,1,Te),N(10,13,2,1,Te)),ue==="twin"&&(N(3,5,2,5,Ct),N(11,5,2,5,Ct),N(3,5,2,1,ci),N(11,5,2,1,ci),N(3,9,2,1,Te),N(11,9,2,1,Te)),ue==="spiky"&&(N(5,2,6,2,Ct),N(5,1,1,1,Ct),N(7,0,1,2,Ct),N(9,1,1,1,Ct),N(10,0,1,1,Ct),N(5,4,1,2,Ct),N(10,4,1,2,Ct),N(7,4,1,1,Ct)),ue==="bun"&&N(7,0,2,2,Ct),ue==="pony"&&N(11,3,1,2,ci),co("f")):(N(5,2,6,6,Ct),N(5,8,6,1,Te),ue==="long"&&(N(5,8,6,5,Ct),N(5,12,6,1,Te)),ue==="bob"&&(N(4,2,8,7,Ct),N(4,8,8,1,Te)),ue==="twin"&&(N(4,2,8,6,Ct),N(3,5,2,5,Ct),N(11,5,2,5,Ct),N(3,5,2,1,ci),N(11,5,2,1,ci)),ue==="pony"&&(N(7,5,2,1,ci),N(7,6,2,6,Ct),N(7,12,2,1,Te)),ue==="spiky"&&(N(5,1,1,1,Ct),N(7,0,1,2,Ct),N(9,1,1,1,Ct),N(10,0,1,1,Ct)),ue==="bun"&&N(7,0,2,2,Ct),co("b"))}else{let ce=v===1?1:v===2?-1:0,Se=v===0?[[6,0,!0],[8,0,!1]]:v===1?[[4,1,!0],[9,0,!1]]:[[9,1,!0],[4,0,!1]];if(wt){let on=(le==="pants"||le==="shorts")&&!hi?dn:D(bt);N(6,15,5,2,on,0),N(11,15,2,2,Ir,0)}else for(let[on,Cn,ui]of Se)lo(on,2,Cn,ui);N(5,9,6,6,un),N(5,9,1,6,$e),hi?(N(4,15,8,2,un),N(4,16,8,1,$e)):le==="skirt"?(N(5,14,6,1,dn),N(4,15,8,2,dn),N(4,16,8,1,Lr)):N(5,14,6,1,dn);let Xe=7+ce;if(ac?(N(Xe,10,2,3,$e),N(Xe,13,2,1,bt)):(N(Xe,10,2,2,$e),N(Xe,12,2,2,bt)),ue==="long"&&(N(4,3,3,10,Ct),N(4,12,3,1,Te)),N(5,3,6,6,bt),N(9,6,1,1,ao),N(9,7,1,1,oo),N(10,7,1,1,ke),N(9,8,1,1,rc),ue!=="spiky"&&(N(5,2,6,2,Ct),N(5,3,4,3,Ct),N(5,6,2,2,Te),N(9,4,1,1,Ct)),ue==="bob"&&(N(4,3,4,6,Ct),N(4,8,4,1,Te)),ue==="twin"&&(N(4,5,2,5,Ct),N(4,5,2,1,ci)),ue==="pony"){let on=v?2:3;N(on,4,2,1,ci),N(on,5,2,6,Ct),N(on,10,2,1,Te)}ue==="spiky"&&(N(5,2,6,2,Ct),N(5,3,4,3,Ct),N(5,1,1,1,Ct),N(7,0,1,2,Ct),N(9,1,1,1,Ct),N(5,6,2,2,Te)),ue==="bun"&&N(4,1,3,2,Ct),co("s")}let Uu=tt.getImageData(0,0,Ie,Be),Dr=Uu.data,rs=new Uint8ClampedArray(Dr),Ks=(ce,Se)=>ce<0||Se<0||ce>=Ie||Se>=Be?0:Dr[(Se*Ie+ce)*4+3];for(let ce=0;ce<Be;ce++)for(let Se=0;Se<Ie;Se++)if(!Ks(Se,ce)&&(Ks(Se-1,ce)||Ks(Se+1,ce)||Ks(Se,ce-1)||Ks(Se,ce+1))){let Xe=(ce*Ie+Se)*4;rs[Xe]=ja[0],rs[Xe+1]=ja[1],rs[Xe+2]=ja[2],rs[Xe+3]=255}for(let ce=3;ce<Dr.length;ce+=4)Dr[ce]&&(rs[ce]=255);tt.putImageData(new ImageData(rs,Ie,Be),0,0),h.drawImage(et,m,_)}function $a(h){let m=document.createElement("canvas");m.width=Ie*4,m.height=Be*3;let _=m.getContext("2d");for(let w=0;w<3;w++)for(let v=0;v<4;v++)xu(_,v*Ie,w*Be,w,v,h);return m}function kl(h){let m=new Os($a(h));return m.magFilter=qe,m.minFilter=qe,m.generateMipmaps=!1,m.colorSpace=Ce,m.repeat.set(1/4,1/3),m}let En={hairStyle:[["short","짧은머리"],["bob","단발"],["long","긴머리"],["twin","양갈래"],["pony","포니테일"],["spiky","뾰족머리"],["bun","올림머리"]],top:[["tee","티셔츠"],["hood","후드티"],["shirt","셔츠"],["dress","원피스"]],bottom:[["pants","긴바지"],["shorts","반바지"],["skirt","치마"]],hat:[["none","없음"],["cap","캡모자"],["straw","밀짚모자"]]},Me={hair:[2499120,5913128,9067066,15253594,12865582,15235752,5929696,10124008,15262960,4173962],eye:[2759978,6963752,3832536,4173962,10115808,15226698,15251514,8030872],skin:[16769224,16176048,15185039,13209190,9263676,5913130],cloth:[15226698,15764042,16046170,6995818,5947568,4890840,10124008,15769792,16052456,3885690,4864602,2499120]},Hl=[{id:"c1",name:"모리",skin:16176048,hair:5913128,eye:6963752,hairStyle:"short",top:"hood",topC:15226698,bottom:"pants",botC:3885690,hat:"none",hatC:16046170},{id:"c2",name:"별이",skin:16769224,hair:15235752,eye:10115808,hairStyle:"twin",top:"dress",topC:16046170,bottom:"skirt",botC:6965898,hat:"none",hatC:16046170},{id:"c3",name:"하루",skin:15185039,hair:2499120,eye:3832536,hairStyle:"spiky",top:"tee",topC:4890840,bottom:"shorts",botC:4864602,hat:"cap",hatC:15226698},{id:"c4",name:"루나",skin:16176048,hair:5929696,eye:4173962,hairStyle:"long",top:"shirt",topC:16052456,bottom:"skirt",botC:3885690,hat:"none",hatC:16046170}],Hn=U.get("house.cast.v1",null)||Hl.map(h=>({...h})),Vl=s("#bubbles"),_u=.3,vu=new mr(1,1).translate(0,.5,0),yu=new _r(.34,14).rotateX(-Math.PI/2),Ka={chat:["안녕!","오늘 뭐 했어?","♪","배고파…","후후","♥","이리 와봐!","같이 TV 볼래?"],wander:["♪","흠~","…!","뭐 하지?"]},Ar={idle:"멍하니 있는 중",chat:"수다 떠는 중",wander:"집 안을 거니는 중"},Gl=()=>"c"+Math.random().toString(36).slice(2,8);function Cr(h,m){let _=kl(h),w=new xn({map:_,alphaTest:.5,color:16777215,side:Dn}),v=new He(vu,w);v.rotation.order="YXZ",v.scale.set(Ie*Ki,Be*Ki,1),S.add(v);let F=new He(yu,new xn({color:0,transparent:!0,opacity:.3,depthWrite:!1,polygonOffset:!0,polygonOffsetFactor:-2}));S.add(F);let et=document.createElement("div");et.className="bubble",Vl.appendChild(et);let tt=document.createElement("div");tt.className="name",tt.textContent=h.name,Vl.appendChild(tt);let[ot,wt]=m||p(Pe),N={def:h,sp:v,sh:F,tex:_,mat:w,el:et,nm:tt,pos:new B(ot*c,0,wt*c),path:null,pi:0,state:"idle",timer:.5+Math.random()*2,kind:"wander",spot:null,pose:"stand",spotY:Kt,face:new Lt(0,1),phase:Math.random()*5,say:"",sayT:0,chatCd:3+Math.random()*6,speed:1.2+Math.random()*.3,hidden:!1,act:Ar.idle,forced:!1};return v.userData.char=N,ut.push(N),N}function Qa(h){S.remove(h.sp),S.remove(h.sh),h.el.remove(),h.nm.remove(),h.tex.dispose(),ut.splice(ut.indexOf(h),1),An===h&&(An=null)}function bu(h){h.tex.dispose(),h.tex=kl(h.def),h.mat.map=h.tex,h.mat.needsUpdate=!0,h.nm.textContent=h.def.name}let Wl=h=>Math.round(h/c),Qi=h=>[Wl(h.pos.x),Wl(h.pos.z)];function ts(h){h.spot&&(h.pose!=="stand"||h.hidden)&&h.pos.set(h.spot.walk[0]*c,0,h.spot.walk[1]*c),h.pose="stand",h.hidden=!1,h.spot=null}function Xl(h,m){return ut.some(_=>_!==m&&(_.spot===h||_.plan&&_.plan.spot===h))}function Yl(h,m,_=!1){ts(h);let[w,v]=Qi(h),F=_e(w,v,m.walk[0],m.walk[1]);return F?(h.plan={spot:m},h.path=F,h.pi=1,h.state=(F.length<2,"walk"),h.kind=m.kind,h.act=m.txt,h.forced=_,F.length<2&&(h.path=[F[0],F[0]],h.pi=1),!0):(h.state="idle",h.timer=1,!1)}function qs(h,m,_,w=Ar.wander,v=!1){ts(h);let[F,et]=Qi(h),tt=_e(F,et,m,_);return!tt||tt.length<2?(h.state="idle",h.timer=.6,!1):(h.plan={spot:null},h.path=tt,h.pi=1,h.state="walk",h.kind="wander",h.act=w,h.forced=v,!0)}function Mu(h){let m={dusk:{tv:3,cook:2,eat:2,read:1.2,view:1.2,wash:1,bath:1,sleep:.4,dress:.6,wander:1.5,out:.5},night:{tv:2,cook:.4,eat:.4,read:1,view:.6,wash:1.5,bath:1.5,sleep:5,dress:.6,wander:.5,out:.1},day:{tv:1.5,cook:2.5,eat:2.5,read:1.5,view:1.5,wash:1,bath:.5,sleep:.3,dress:.8,wander:2,out:1.5}}[$],_=0;for(let et in m)_+=m[et];let w=Math.random()*_,v="wander";for(let et in m)if(w-=m[et],w<=0){v=et;break}if(v==="wander"){let[et,tt]=Qi(h),ot=Pe.filter(([bt,te])=>Math.hypot(bt-et,te-tt)>4&&Math.hypot(bt-et,te-tt)<14),[wt,N]=p(ot.length?ot:Pe);qs(h,wt,N);return}let F=fn.filter(et=>et.kind===v&&!Xl(et,h));if(!F.length){h.state="idle",h.timer=1.5;return}Yl(h,p(F))}function ql(h,m,_){let w=m-h.pos.x,v=_-h.pos.z,F=Math.hypot(w,v)||1;h.face.set(w/F,v/F)}function Li(h,m){h.say=p(m),h.sayT=2.8}function to(h){let m=h.plan&&h.plan.spot;h.state="act",h.path=null,m?(h.spot=m,h.pose=m.pose,h.spotY=m.y??Kt,h.pos.set(m.at[0]*c,0,m.at[1]*c),h.face.set(m.face[0],m.face[1]),m.kind==="out"?(h.hidden=!0,h.timer=10+Math.random()*14):h.timer=m.kind==="sleep"?22+Math.random()*20:m.kind==="bath"?14+Math.random()*10:10+Math.random()*14,Math.random()<.85&&Li(h,m.say)):h.kind==="intimate"?(h.timer=20+Math.random()*8,h.say="19♥",h.sayT=h.timer,h.act="둘만의 시간 (19♥)",h.partner&&ql(h,h.partner.pos.x,h.partner.pos.z)):(h.timer=.8+Math.random()*2,Math.random()<.3&&Li(h,Ka.wander))}function Zl(h,m){for(let[_,w]of[[h,m],[m,h]])ts(_),_.state="chat",_.path=null,_.timer=4+Math.random()*2,_.chatCd=16+Math.random()*10,_.act=Ar.chat,_.forced=!1,ql(_,w.pos.x,w.pos.z);Li(h,Ka.chat),m.sayT=-1.2}let Vn=new B,Zs=new B,Tn=new B,Su=new B(0,1,0);function Jl(h,m){R.getWorldDirection(Vn),Vn.y=0,Vn.normalize(),Zs.crossVectors(Vn,Su).normalize();let _=Math.atan2(-Vn.x,-Vn.z),w=(Math.PI/2-V.getPolarAngle())*_u;for(let v of ut){v.chatCd-=m,v.sayT-=m;let F=!1;if(v.state==="idle")v.timer-=m,v.timer<=0&&k.auto&&Mu(v);else if(v.state==="walk"){let ke=v.path[v.pi],Ct=ke[0]*c,Te=ke[1]*c,Wn=Ct-v.pos.x,un=Te-v.pos.z,$e=Math.hypot(Wn,un),dn=v.speed*k.speed*m;$e<=dn?(v.pos.x=Ct,v.pos.z=Te,v.pi++,v.pi>=v.path.length&&to(v)):(v.pos.x+=Wn/$e*dn,v.pos.z+=un/$e*dn,v.face.set(Wn/$e,un/$e),F=!0)}else if(v.state==="act")if(v.timer-=m,v.timer<=0){let ke=v.hidden;ts(v),v.state="idle",v.timer=.3+Math.random()*1.5,v.act=Ar.idle,v.forced=!1,ke&&Li(v,["다녀왔어!","밖에 좋더라"])}else v.spot&&v.spot.kind!=="sleep"&&Math.random()<m*.1&&Li(v,v.spot.say);else v.state==="chat"&&(v.timer-=m,v.timer<=0?(v.state="idle",v.timer=.3):v.sayT<=0&&Li(v,Ka.chat));if((v.state==="walk"||v.state==="idle")&&v.chatCd<=0&&!v.hidden&&k.auto){for(let ke of ut)if(!(ke===v||ke.hidden||ke.state!=="walk"&&ke.state!=="idle"||ke.chatCd>0)&&Math.hypot(ke.pos.x-v.pos.x,ke.pos.z-v.pos.z)<1.1){Zl(v,ke);break}}v.state==="walk"&&v.kind==="chat"&&v.partner&&Math.hypot(v.partner.pos.x-v.pos.x,v.partner.pos.z-v.pos.z)<1.4&&!v.partner.hidden&&(Zl(v,v.partner),v.partner=null),v.phase+=F?m*v.speed*k.speed*4.2:0;let et=F?Math.floor(v.phase)%2===0?1:2:0,tt=v.face.x*Vn.x+v.face.y*Vn.z,ot=v.face.x*Zs.x+v.face.y*Zs.z,wt,N=1,bt=et;Math.abs(ot)>Math.abs(tt)?(wt=2,N=ot>=0?1:-1):wt=tt>0?1:0;let te=1,re=0,jt=Kt,Le=!1;v.pose==="sit"?(te=.82,jt=v.spotY,bt=3):v.pose==="bath"?(te=.55,jt=v.spotY,bt=0,wt=0,N=1):v.pose==="lie"&&(Le=!0,re=-Math.PI/2,jt=v.spotY+.28,bt=0,wt=0,N=1);let le=v.tex,Ae=1-(wt+1)/3;le.repeat.set(N/4,te/3),le.offset.x=(N>0?bt:bt+1)/4,le.offset.y=Ae+(1-te)/3;let ze=Be*Ki*te;v.sp.scale.set(Ie*Ki,ze,1),v.mat.color.copy(I.tint),v.sp.rotation.set(-w,_,re);let je=-Vn.x*.12,ue=-Vn.z*.12;Le?v.sp.position.set(v.pos.x-Zs.x*ze/2+je,jt,v.pos.z-Zs.z*ze/2+ue):v.sp.position.set(v.pos.x+je,jt-(te<1?0:Ki),v.pos.z+ue),v.sp.visible=!v.hidden,v.sh.position.set(v.pos.x,Kt+.03,v.pos.z),v.sh.visible=!v.hidden&&v.pose==="stand",v.topY=Le?jt+.7:jt+Be*Ki*te+.1}}function eo(h){return!h||h==="*"||h==="all"?ut.slice():ut.filter(m=>m.def.name===h||m.def.id===h)}function es(h,m,_,w){let v=eo(h);if(!v.length)return!1;for(let F of v)if(m==="chat"){let et=_&&eo(_)[0]||ut.filter(bt=>bt!==F&&!bt.hidden).sort((bt,te)=>Math.hypot(bt.pos.x-F.pos.x,bt.pos.z-F.pos.z)-Math.hypot(te.pos.x-F.pos.x,te.pos.z-F.pos.z))[0];if(!et)continue;ts(et),et.state="idle",et.timer=3;let[tt,ot]=Qi(et),wt=[[1,0],[-1,0],[0,1],[0,-1],[1,1],[-1,-1]].map(([bt,te])=>[tt+bt,ot+te]).filter(([bt,te])=>de(bt,te)),N=w?Bl(Fl(w),Ys(w)):null;if(N)for(let[bt,te,re]of[[F,N[0],et],[et,N[1],F]]){let jt=qs(bt,te[0],te[1],Je[w]+"에서 대화하러 가는 중",!0);bt.kind="chat",bt.partner=re,bt.chatCd=0,jt||(bt.plan={spot:null},to(bt))}else wt.length&&qs(F,...wt[0],"대화하러 가는 중",!0)&&(F.kind="chat",F.partner=et,F.chatCd=0,et.chatCd=0)}else if(m==="intimate"){if(F.kind==="intimate"&&F.state!=="idle")continue;let et=_&&eo(_)[0]||ut.filter(ot=>ot!==F&&!ot.hidden).sort((ot,wt)=>Math.hypot(ot.pos.x-F.pos.x,ot.pos.z-F.pos.z)-Math.hypot(wt.pos.x-F.pos.x,wt.pos.z-F.pos.z))[0];if(!et||et===F)continue;let tt=w?Bl(Fl(w),Ys(w)):null;if(!tt){let ot=fn.find(N=>N.kind==="sleep"),wt=ot?ot.walk:[0,3];tt=[[0,0],[1,0],[-1,0],[0,1],[0,-1],[1,1],[-1,1]].map(([N,bt])=>[wt[0]+N,wt[1]+bt]).filter(([N,bt])=>de(N,bt))}if(tt.length<2)continue;for(let[ot,wt,N]of[[F,tt[0],et],[et,tt[1],F]]){let bt=qs(ot,wt[0],wt[1],"둘만의 시간 (19♥)",!0);ot.kind="intimate",ot.partner=N,ot.chatCd=90,bt||(ot.plan={spot:null},to(ot))}}else if(m.startsWith("goto_")){let et=m.slice(5),tt=ye[et];if(!tt)continue;let[ot,wt]=p(tt);qs(F,ot,wt,me[et]+"(으)로 이동 중",!0)}else if(be.includes(m)){let et=fn.filter(ot=>ot.kind===m);if(w){let ot=mu(w),wt=et.filter(N=>ot.includes(N));wt.length&&(et=wt)}let tt=et.filter(ot=>!Xl(ot,F));Yl(F,p(tt.length?tt:et),!0)}return!0}let jl=h=>{let m=h.data;m&&m.type==="scene"&&typeof m.action=="string"?es(m.who,m.action,m.partner,m.place):m&&m.type==="story"&&typeof m.text=="string"&&Ja(m.text)};window.addEventListener("message",jl);let $0=null,An=null;function wu(){let h=o(),m=a();for(let _ of ut){Tn.set(_.pos.x,_.topY??2.2,_.pos.z).project(R);let w=!_.hidden&&Tn.z<1&&Math.abs(Tn.x)<1.1&&Math.abs(Tn.y)<1.1,v=(Tn.x*.5+.5)*h,F=(-Tn.y*.5+.5)*m;_.el.style.left=v+"px",_.el.style.top=F-2+"px",_.el.textContent!==_.say&&(_.el.textContent=_.say),_.el.classList.toggle("show",w&&_.sayT>0),_.nm.style.left=v+"px",_.nm.style.top=F+2+"px",_.nm.classList.toggle("show",w&&(k.names||_===An))}if(k.roomtag)for(let _ in $i)Tn.set($i[_][0]*c,.4,$i[_][1]*c).project(R),T[_].style.left=(Tn.x*.5+.5)*h+"px",T[_].style.top=(-Tn.y*.5+.5)*m+"px"}let $l=new Oa,Kl=new Lt,Rr=null;Q.domElement.addEventListener("pointerdown",h=>{Rr=[h.clientX,h.clientY]}),Q.domElement.addEventListener("pointerup",h=>{if(!Rr||Math.hypot(h.clientX-Rr[0],h.clientY-Rr[1])>5)return;let m=Q.domElement.getBoundingClientRect();Kl.set((h.clientX-m.left)/m.width*2-1,-((h.clientY-m.top)/m.height)*2+1),$l.setFromCamera(Kl,R);let _=$l.intersectObjects(ut.filter(w=>!w.hidden).map(w=>w.sp),!1)[0];An=_?_.object.userData.char:null,Di()});function oi(h){let m=s("#toast");m.textContent=h,m.style.opacity=1,clearTimeout(oi.h),oi.h=setTimeout(()=>m.style.opacity=0,1800)}let li=null;function Ii(h){li===h&&(h=null),li=h,s("#panel").classList.toggle("open",!!h),r("#rail button").forEach(m=>m.classList.toggle("on",m.dataset.p===h||h==="create"&&m.dataset.p==="create")),r(".sec").forEach(m=>m.classList.toggle("on",m.id==="s-"+h)),h==="cast"&&Di(),h==="create"&&(Gn||io(null)),h==="scene"&&js()}r("#rail button").forEach(h=>h.addEventListener("click",()=>{h.dataset.p==="create"&&(Gn=Gn),Ii(h.dataset.p)}));function Eu(h){let m=document.createElement("canvas");m.width=Ie,m.height=Be;let _=m.getContext("2d");return _.imageSmoothingEnabled=!1,_.drawImage($a(h),0,0,Ie,Be,0,0,Ie,Be),m}function Di(){let h=s("#castList");h.innerHTML="",ut.forEach(m=>{let _=document.createElement("div");_.className="card"+(m===An?" sel":""),_.appendChild(Eu(m.def));let w=document.createElement("div");w.className="t",w.innerHTML=`${m.def.name}<small>${m.act}</small>`,_.appendChild(w);let v=document.createElement("button");v.textContent="수정",v.onclick=et=>{et.stopPropagation(),io(m),Ii("create"),li==="create"||Ii("create")},_.appendChild(v);let F=document.createElement("button");F.textContent="삭제",F.onclick=et=>{if(et.stopPropagation(),ut.length<=1)return oi("최소 1명은 있어야 해요");Qa(m),Hn=ut.map(tt=>tt.def),U.set("house.cast.v1",Hn),Di(),js()},_.appendChild(F),_.onclick=()=>{An=An===m?null:m,Di()},h.appendChild(_)}),s("#newChar").style.display=ut.length>=8?"none":""}let Tu=setInterval(()=>{li==="cast"&&Di()},1500);s("#newChar").onclick=()=>{io(null),li=null,Ii("create")};let De=null,Gn=null,no=!0,Ql=null,tc={};function Au(h){let m=s("#o-"+h);m.innerHTML="",En[h].forEach(([_,w])=>{let v=document.createElement("button");v.className="chip",v.textContent=w,v.dataset.v=_,v.onclick=()=>{De[h]=_,Js()},m.appendChild(v)})}function ns(h,m){let _=s("#o-"+h);_.innerHTML="",m.forEach(v=>{let F=document.createElement("button");F.className="sw",F.style.background=D(v),F.dataset.v=v,F.onclick=()=>{De[h]=v,Js()},_.appendChild(F)});let w=document.createElement("input");w.type="color",w.oninput=()=>{De[h]=parseInt(w.value.slice(1),16),Js(!0)},_.appendChild(w),tc[h]=w}["hairStyle","top","bottom","hat"].forEach(Au),ns("hair",Me.hair),ns("eye",Me.eye),ns("skin",Me.skin),ns("topC",Me.cloth),ns("botC",Me.cloth),ns("hatC",Me.cloth);function Js(h){for(let _ of["hairStyle","top","bottom","hat"])r("#o-"+_+" .chip").forEach(w=>w.classList.toggle("on",w.dataset.v===De[_]));for(let _ of["hair","eye","skin","topC","botC","hatC"])r("#o-"+_+" .sw").forEach(w=>w.classList.toggle("on",+w.dataset.v===De[_])),h||(tc[_].value=D(De[_]));let m=De.top==="dress";s("#o-bottom").classList.toggle("dis",m),s("#o-botC").classList.toggle("dis",m),s("#dressNote").textContent=m?"(원피스는 하의가 없어요)":"",r("#o-bottom .chip").forEach(_=>_.classList.toggle("dis",m)),s("#o-hatC").style.opacity=De.hat==="none"?.35:1,no=!0}function io(h){Gn=h,De=h?{...h.def}:{id:Gl(),name:"",skin:p(Me.skin),hair:p(Me.hair),eye:p(Me.eye),hairStyle:p(En.hairStyle)[0],top:p(En.top)[0],topC:p(Me.cloth),bottom:p(En.bottom)[0],botC:p(Me.cloth),hat:"none",hatC:p(Me.cloth)},s("#cName").value=De.name,s("#createTitle").textContent=h?"✏️ 캐릭터 수정":"✨ 캐릭터 만들기",s("#cSave").textContent=h?"저장하기":"집에 추가하기",Js()}s("#cName").oninput=h=>{De.name=h.target.value},s("#cRand").onclick=()=>{let h=De.name;De={id:De.id,name:h,skin:p(Me.skin),hair:p(Me.hair),eye:p(Me.eye),hairStyle:p(En.hairStyle)[0],top:p(En.top)[0],topC:p(Me.cloth),bottom:p(En.bottom)[0],botC:p(Me.cloth),hat:Math.random()<.25?p(En.hat.slice(1))[0]:"none",hatC:p(Me.cloth)},Js()},s("#cCancel").onclick=()=>{Gn=null,li="create",Ii("create")},s("#cSave").onclick=()=>{let h=(De.name||"").trim();if(!h)return oi("이름을 입력해 주세요");if(ut.some(m=>m!==Gn&&m.def.name===h))return oi("같은 이름이 이미 있어요");if(De.name=h,Gn)Gn.def={...De},bu(Gn),oi(h+" 저장했어요");else{if(ut.length>=8)return oi("최대 8명까지예요");let m=Cr({...De},[-7,14]);m.state="idle",m.timer=.4,Li(m,["안녕! 잘 부탁해","여기가 우리 집이구나!"]),oi(h+" 입주 완료!")}Hn=ut.map(m=>m.def),U.set("house.cast.v1",Hn),Gn=null,li="create",Ii("cast"),js()};let Cu=[0,1,2].map(h=>{let m=s("#pv"+h);return m.width=Ie*5,m.height=Be*5,m.getContext("2d")});function ec(h){if(!l||(requestAnimationFrame(ec),li!=="create"||!De))return;no&&(Ql=$a(De),no=!1),[[0,0],[Math.floor(h/200)%2+1,2],[0,1]].forEach(([_,w],v)=>{let F=Cu[v];F.imageSmoothingEnabled=!1,F.clearRect(0,0,Ie*5,Be*5),F.fillStyle="rgba(255,255,255,.07)",F.fillRect(0,0,Ie*5,Be*5),F.drawImage(Ql,_*Ie,w*Be,Ie,Be,0,0,Ie*5,Be*5)})}requestAnimationFrame(ec);function js(){let h=s("#sceneWho"),m=h.value;h.innerHTML='<option value="*">모두</option>'+ut.map(v=>`<option value="${v.def.id}">${v.def.name}</option>`).join(""),[...h.options].some(v=>v.value===m)&&(h.value=m);let _=s("#scenePlace");_.options.length||(_.innerHTML='<option value="">장소 지정 안 함</option>'+Object.keys(Je).map(v=>'<option value="'+v+'">'+Je[v]+"</option>").join(""));let w=(v,F,et)=>{v.innerHTML="";for(let tt in F){let ot=document.createElement("button");ot.className="chip",ot.textContent=F[tt],ot.onclick=()=>es(h.value,et+tt,void 0,et==="goto_"?void 0:_.value||void 0),v.appendChild(ot)}};w(s("#sceneGo"),Gs,"goto_"),w(s("#sceneAct"),zn,"")}s("#storyEx").onclick=()=>{s("#storyIn").value=ut.slice(0,3).map((h,m)=>[h.def.name+"는 소파에 앉아 TV를 봤다.",h.def.name+"는 졸려서 침대로 가서 잠들었다.",h.def.name+"는 주방에서 요리를 시작했다."][m]).join(`
`)},s("#storyGo").onclick=()=>{let h=Ja(s("#storyIn").value),m=s("#storyOut");if(m.innerHTML="",!h.length){m.textContent="읽을 문장이 없어요.";return}for(let _ of h){let w=document.createElement("div");w.style.cssText="padding:4px 0;border-top:1px solid rgba(255,255,255,.15)",w.textContent=_.action?`✔ "${_.sentence}" → ${_.who.join(", ")==="*"?"모두":_.who.join(", ")}: ${gu(_.action)} (키워드 '${_.keyword}'${_.place?", 장소 "+Je[_.place]:""})`:`— "${_.sentence}" → 반응 없음`,m.appendChild(w)}};function Ru(h){if(h=String(h||"").trim().slice(0,16),!h||ut.some(_=>_.def.name===h)||ut.length>=8)return!1;let m={id:Gl(),name:h,skin:p(Me.skin),hair:p(Me.hair),eye:p(Me.eye),hairStyle:p(En.hairStyle)[0],top:p(En.top)[0],topC:p(Me.cloth),bottom:p(En.bottom)[0],botC:p(Me.cloth),hat:"none",hatC:p(Me.cloth)};return Cr(m,[-7,14]),Hn=ut.map(_=>_.def),U.set("house.cast.v1",Hn),Di(),js(),!0}function Pr(){n.classList.toggle("nobubble",!k.bubble),n.classList.toggle("noroomtag",!k.roomtag),so.enabled=k.bloom,V.autoRotate=k.rotate,s("#spdVal").textContent=(+k.speed).toFixed(1),r("#setTod .chip").forEach(h=>h.classList.toggle("on",h.dataset.m===$)),U.set("house.settings.v1",{...k,mode:$})}{let h=s("#setTod");[["dusk","🌇 노을"],["night","🌙 밤"],["day","☀️ 낮"]].forEach(([m,_])=>{let w=document.createElement("button");w.className="chip",w.dataset.m=m,w.textContent=_,w.onclick=()=>{$=m,Pr()},h.appendChild(w)})}let Ui=(h,m,_)=>{let w=s(h);w.type==="checkbox"?w.checked=!!k[m]:w.value=k[m],w.oninput=()=>{k[m]=w.type==="checkbox"?w.checked:+w.value,Pr()}};Ui("#setBubble","bubble"),Ui("#setRoomTag","roomtag"),Ui("#setNames","names"),Ui("#setBloom","bloom"),Ui("#setAuto","auto"),Ui("#setRotate","rotate"),Ui("#setSpeed","speed"),s("#resetCast").onclick=()=>{confirm("캐릭터를 기본 4명으로 되돌릴까요?")&&([...ut].forEach(Qa),Hn=Hl.map(h=>({...h})),U.set("house.cast.v1",Hn),Hn.forEach(h=>Cr({...h})),Di(),js())};let Pu=new Ke(o()*Q.getPixelRatio(),a()*Q.getPixelRatio(),{type:gn,samples:4}),is=new Wa(Q,Pu);is.addPass(new Xa(S,R));let so=new Hs(new Lt(o(),a()),.45,.55,.62);is.addPass(so);let ro=new ks(du);ro.uniforms.offset.value=1,ro.uniforms.darkness.value=1,is.addPass(ro),is.addPass(new Ya),Hn.forEach(h=>Cr({...h})),Pr();function Lu(){j.uniforms.discK.value=I.discK,S.fog.color.copy(I.fog),S.fog.density=I.den,yt.color.copy(I.keyCol),yt.intensity=I.keyInt,yt.position.copy(I.key).normalize().multiplyScalar(50),yt.target.position.set(0,0,0),It.color.copy(I.hSky),It.groundColor.copy(I.hGnd),It.intensity=I.hInt,W.color.setScalar(I.glow),dt.color.copy(I.win),st.opacity=I.stars,so.strength=I.bloom,Q.toneMappingExposure=I.expo,vt.color.copy(I.fog).multiplyScalar(1.12).lerp(I.hor,.08);for(let h of Ot)h.intensity=9*I.lamp}let nc=performance.now()/1e3,jn=0;function Iu(){let h=performance.now()/1e3,m=Math.min(.05,h-nc);nc=h,jn+=m,Z(m),Lu();let _=ut.some(tt=>tt.spot&&tt.spot.kind==="tv"&&tt.state==="act");ht.color.set(_?d(5943551,16765088,(Math.sin(jn*3)*.5+.5)*(Math.sin(jn*1.3)*.5+.5)):1315868).multiplyScalar(_?1.2+I.glow*.3:1),ct.forEach(tt=>{tt.m.position.x+=tt.sp*m,tt.m.position.x>160&&(tt.m.position.x=-160)});let w=J.geometry.attributes.position,v=Ai.find(tt=>tt.type==="steam"),F=!!v&&ut.some(tt=>tt.spot&&tt.spot.steam&&tt.state==="act");Y.forEach((tt,ot)=>{tt.t+=m*(F?.6:0),tt.t>3&&(tt.t=0),w.setXYZ(ot,v?v.x+Math.sin(tt.t*2+ot)*.2:0,F?v.y+tt.t*.6:-50,v?v.z+Math.cos(tt.t+ot)*.15:0)}),w.needsUpdate=!0,w=Et.geometry.attributes.position,zt.forEach((tt,ot)=>w.setXYZ(ot,tt.x+Math.sin(jn*tt.sp+tt.ph)*.8,tt.y+Math.sin(jn*tt.sp*1.4+tt.ph)*.4,tt.z+Math.cos(jn*tt.sp*.7+tt.ph)*.6)),w.needsUpdate=!0;let et=Ai.find(tt=>tt.type==="bubbles");w=Xt.geometry.attributes.position,Zt.forEach((tt,ot)=>{tt.t=(tt.t+m*.5)%2,w.setXYZ(ot,et?et.x+Math.sin(ot*5+tt.t)*1.4+ot%3*.3-.4:0,et?et.y-.8+tt.t*.3:-50,et?et.z+ot%4*.25-.3:0)}),w.needsUpdate=!0,Jl(jn,m),wu(),An&&!An.hidden?V.target.lerp(Tn.set(An.pos.x,1.2,An.pos.z),.05):V.target.lerp(Tn.set(0,1.5,.5),.04),V.update(),is.render()}Q.setAnimationLoop(Iu);let ic=()=>{!o()||!a()||(Q.setSize(o(),a()),is.setSize(o(),a()),R.aspect=o()/a(),R.updateProjectionMatrix())},sc=new ResizeObserver(ic);sc.observe(n);let ss={addByName:Ru,placeOf:Xs,placeIsRoom:Ys,do:es,chars:ut,setMode:h=>{$=h,Z(0,!0),Pr()},KEYWORDS:Pi,interpret:zl,applyStory:Ja,tick:(h,m=.05)=>{for(let _=0;_<h/m;_++)jn+=m,Jl(jn,m);return ut.map(_=>_.def.name+":"+_.state+":"+_.kind+":"+_.pos.x.toFixed(1)+","+_.pos.z.toFixed(1)).join(" ")},camera:R,controls:V,showPanel:Ii,layout:ge,catalog:se,rebuild:Bn,move:Er,add:qa,remove:Za,spots:()=>fn};return ss.destroy=()=>{l=!1,Q.setAnimationLoop(null),sc.disconnect(),clearInterval(Tu),window.removeEventListener("message",jl);for(let h of[...ut])Qa(h);Q.dispose(),e.innerHTML="",t.global&&window[t.global]===ss&&delete window[t.global]},ss.resize=ic,t.global&&(window[t.global]=ss),requestAnimationFrame(()=>requestAnimationFrame(()=>{ss.ready=!0,window.__ready=!0})),ss}(function(){if(window.__pixelWorldExt)try{window.__pixelWorldExt.destroy()}catch{}let i="pixelworld.ext.v1",e=Object.assign({field:"자세,행동,posture,pose,action,activity",chatId:"",poll:!0,sec:3,autoAdd:!0,w:760,h:480},(()=>{try{return JSON.parse(localStorage.getItem(i))||{}}catch{return{}}})()),n=()=>{try{localStorage.setItem(i,JSON.stringify(e))}catch{}},s=(...S)=>{try{(window.marinara&&window.marinara.log?window.marinara.log.info:console.log)("[pixel-world]",...S)}catch{console.log("[pixel-world]",...S)}},r=document.createElement("div");r.id="pixel-world-ext",r.style.cssText=`position:fixed;right:16px;bottom:16px;width:${e.w}px;height:${e.h}px;min-width:380px;min-height:280px;max-width:98vw;max-height:96vh;z-index:2147483000;display:flex;flex-direction:column;background:#2a1d4a;border:2px solid #fff;box-shadow:0 6px 24px rgba(0,0,0,.55);resize:both;overflow:hidden;font:12px sans-serif;color:#fff;box-sizing:border-box`;let o="cursor:pointer;background:rgba(255,255,255,.12);color:#fff;border:1px solid rgba(255,255,255,.4);padding:1px 7px;font:inherit";r.innerHTML=`
    <div id="pw-head" style="display:flex;align-items:center;gap:6px;padding:4px 8px;background:#3a2a5e;cursor:move;user-select:none;flex:none">
      <b>Pixel World</b><span id="pw-dot" style="opacity:.8;flex:1;overflow:hidden;text-overflow:ellipsis;white-space:nowrap">트래커 대기 중…</span>
      <button id="pw-set" style="${o}" title="트래커 연결 설정">⚙</button>
      <button id="pw-full" style="${o}" title="크게/작게">⛶</button>
      <button id="pw-min" style="${o}" title="접기">–</button>
      <button id="pw-x" style="${o}" title="닫기">✕</button>
    </div>
    <div id="pw-cfg" style="display:none;padding:8px;background:#33244f;border-bottom:1px solid rgba(255,255,255,.25);flex:none;line-height:1.9">
      <label>읽을 트래커 필드 이름 (콤마로 여러 개) <input id="pw-field" style="width:100%;box-sizing:border-box"></label>
      <label>채팅 ID (비우면 자동) <input id="pw-chat" style="width:100%;box-sizing:border-box" placeholder="자동"></label>
      <label><input type="checkbox" id="pw-poll"> 트래커 자동으로 읽기</label> &nbsp;
      <label>주기 <input id="pw-sec" type="number" min="1" max="30" style="width:48px"> 초</label> &nbsp;
      <label><input type="checkbox" id="pw-add"> 섬에 없는 이름은 자동 추가</label>
      <div><button id="pw-now" style="${o}">지금 읽기</button></div>
    </div>
    <div id="pw-island" style="flex:1;min-height:0;position:relative"></div>
    <div id="pw-log" style="flex:none;padding:3px 8px;background:#33244f;font-size:11px;opacity:.9;max-height:54px;overflow:auto"></div>`,document.body.appendChild(r);let a=S=>r.querySelector(S),l=pu(a("#pw-island"),{global:"pixelWorld"}),c=[],u=S=>{c.unshift(`${new Date().toLocaleTimeString()} ${S}`),c.length=Math.min(c.length,4),a("#pw-log").innerHTML=c.map(R=>`<div>${R.replace(/</g,"&lt;")}</div>`).join("")},f=S=>{a("#pw-dot").textContent=S};a("#pw-head").addEventListener("mousedown",S=>{if(S.target.tagName==="BUTTON")return;let R=r.getBoundingClientRect(),V=S.clientX-R.left,nt=S.clientY-R.top;r.style.left=R.left+"px",r.style.top=R.top+"px",r.style.right="auto",r.style.bottom="auto";let ft=k=>{r.style.left=Math.max(0,Math.min(innerWidth-80,k.clientX-V))+"px",r.style.top=Math.max(0,Math.min(innerHeight-30,k.clientY-nt))+"px"},I=()=>{removeEventListener("mousemove",ft),removeEventListener("mouseup",I)};addEventListener("mousemove",ft),addEventListener("mouseup",I)});let p=!1,x=null,y=!1;a("#pw-full").onclick=()=>{p=!p,p?(x=r.style.cssText,r.style.cssText+=";left:24px;top:24px;right:24px;bottom:24px;width:auto;height:auto;resize:none"):r.style.cssText=x,l.resize()},a("#pw-min").onclick=()=>{y=!y,a("#pw-island").style.display=y?"none":"",a("#pw-log").style.display=y?"none":"",r.style.height=y?"auto":e.h+"px",r.style.minHeight=y?"0":"280px",r.style.resize=y?"none":"both"},a("#pw-set").onclick=()=>{let S=a("#pw-cfg");S.style.display=S.style.display==="none"?"block":"none"},a("#pw-x").onclick=()=>Q(),a("#pw-field").value=e.field,a("#pw-chat").value=e.chatId,a("#pw-poll").checked=e.poll,a("#pw-sec").value=e.sec,a("#pw-add").checked=e.autoAdd;let M=()=>{e.field=a("#pw-field").value,e.chatId=a("#pw-chat").value.trim(),e.poll=a("#pw-poll").checked,e.sec=Math.max(1,+a("#pw-sec").value||3),e.autoAdd=a("#pw-add").checked,n(),L()};for(let S of["#pw-field","#pw-chat","#pw-poll","#pw-sec","#pw-add"])a(S).addEventListener("change",M);a("#pw-now").onclick=()=>{C.clear(),U(!0)};let g=new Set("·:：/|()[]-–—,".split("")),d=S=>S.split("").map(R=>g.has(R)?" ":R).join("").split(" ").filter(Boolean).join(" ").slice(0,16),C=new Map,E=!1,D=null;async function z(){if(e.chatId)return e.chatId;try{let ft=window.marinara&&window.marinara.context&&window.marinara.context.get&&window.marinara.context.get();if(ft&&ft.chatId)return ft.chatId}catch{}let S=location.href.match(/[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}/i);if(S)return S[0];let R=await fetch("/api/chats",{credentials:"same-origin"});if(!R.ok)throw new Error("채팅 목록 "+R.status);let V=await R.json(),nt=Array.isArray(V)?V:V.chats||V.items||[];return nt.sort((ft,I)=>String(I.updatedAt||I.createdAt||"").localeCompare(String(ft.updatedAt||ft.createdAt||""))),nt[0]&&nt[0].id}async function U(S){if(!E){E=!0;try{let R=await z();if(!R){f("채팅을 찾지 못했어요");return}let V=await fetch("/api/chats/"+encodeURIComponent(R)+"/game-state",{credentials:"same-origin"});if(!V.ok){f("트래커 읽기 실패 ("+V.status+")");return}let nt=await V.json();if(!nt){f("트래커 데이터가 아직 없어요 (트래커 에이전트를 켜 주세요)");return}let ft=e.field.split(",").map(Z=>Z.trim().toLowerCase()).filter(Boolean),I=[];for(let Z of nt.presentCharacters||[])for(let j of Object.keys(Z.customFields||{}))I.push({owner:Z.name,key:j,value:Z.customFields[j]});for(let Z of nt.playerStats&&nt.playerStats.customTrackerFields||[])I.push({owner:null,key:Z.name,value:Z.value});for(let Z of nt.worldCustomFields||[])I.push({owner:null,key:Z.name,value:Z.value});let k=new Map;for(let Z of I){let j=String(Z.key||""),K=j.toLowerCase(),st=Z.value==null?"":String(Z.value),it=ft.find(q=>K.includes(q));if(!it||!st)continue;let vt=Z.owner;if(!vt){let q=K.indexOf(it);vt=d(j.slice(0,q)+" "+j.slice(q+it.length))}vt&&k.set(vt,(k.get(vt)?k.get(vt)+". ":"")+st)}let $=null;for(let Z of I){let j=String(Z.key||"").toLowerCase();if((j.includes("장소")||j.includes("위치")||j.includes("location"))&&Z.value){let K=l.placeOf(String(Z.value));if(K&&l.placeIsRoom(K)){$=K;break}}}for(let[Z,j]of k){let K=j+"|"+$;if(C.get(Z)===K)continue;if(C.set(Z,K),!l.chars.some(q=>q.def.name===Z))if(e.autoAdd&&l.addByName(Z))u("섬에 "+Z+" 추가");else{u("섬에 '"+Z+"'이(가) 없어요");continue}let st=l.interpret(j).filter(q=>q.action),it=st[st.length-1],vt=it&&(it.place||$);it?(l.do(Z,it.action,it.action==="intimate"||it.action==="chat"?it.who.find(q=>q!==Z&&q!=="*"):void 0,vt),u(Z+' ← "'+j.slice(0,30)+'" → '+it.action+(vt?" @"+vt:"")+" ('"+it.keyword+"')"),s("tracker",Z,j,it.action)):u(Z+' ← "'+j.slice(0,30)+'" → 해당 행동 없음')}f("트래커 연결됨 · 필드 "+I.length+"개 중 행동 "+k.size+"명"),S&&!k.size&&u("'"+e.field+"' 단어가 들어간 필드가 없어요. 찾은 필드: "+I.map(Z=>Z.key).slice(0,12).join(", "))}catch(R){f("트래커 읽기 오류: "+R.message)}finally{E=!1}}}function L(){clearInterval(D),e.poll&&(D=setInterval(()=>{document.hidden||U(!1)},e.sec*1e3))}L(),setTimeout(()=>U(!0),1500);function Q(){clearInterval(D);try{l.destroy()}catch{}r.remove(),delete window.__pixelWorldExt}window.__pixelWorldExt={destroy:Q,app:l,readTracker:U},window.marinara&&window.marinara.onCleanup&&window.marinara.onCleanup(Q)})();})();
