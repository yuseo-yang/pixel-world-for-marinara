/* Pixel World for Marinara - bundled (three.js MIT). Source: https://github.com/yuseo-yang/pixel-world-for-marinara */
(()=>{var Ji={LEFT:0,MIDDLE:1,RIGHT:2,ROTATE:0,DOLLY:1,PAN:2},$i={ROTATE:0,PAN:1,DOLLY_PAN:2,DOLLY_ROTATE:3},Cu=0,sc=1,Ru=2;var Uh=1,Ml=2,ei=3,Mi=0,nn=1,In=2;var Wn=0,ii=1,Rs=2,rc=3,ac=4,Pu=5,ki=100,Lu=101,Iu=102,oc=103,lc=104,Du=200,Uu=201,Nu=202,Ou=203,zo=204,ko=205,Fu=206,Bu=207,zu=208,ku=209,Hu=210,Vu=211,Gu=212,Wu=213,Xu=214,Yu=0,qu=1,Zu=2,sa=3,Ju=4,$u=5,ju=6,Ku=7,Nh=0,Qu=1,td=2,vi=0,bl=1,Sl=2,wl=3,Mr=4,ed=5,El=6;var Oh=300,Ps=301,Ls=302,Ho=303,Vo=304,Na=306,lr=1e3,Dn=1001,Go=1002,qe=1003,cc=1004;var oo=1005;var yn=1006,nd=1007;var cr=1008;var yi=1009,id=1010,sd=1011,Tl=1012,Fh=1013,gi=1014,xi=1015,mn=1016,Bh=1017,zh=1018,Vi=1020,rd=1021,Un=1023,ad=1024,od=1025,Gi=1026,Is=1027,ld=1028,kh=1029,cd=1030,Hh=1031,Vh=1033,lo=33776,co=33777,ho=33778,uo=33779,hc=35840,uc=35841,dc=35842,fc=35843,Gh=36196,pc=37492,mc=37496,gc=37808,xc=37809,_c=37810,vc=37811,yc=37812,Mc=37813,bc=37814,Sc=37815,wc=37816,Ec=37817,Tc=37818,Ac=37819,Cc=37820,Rc=37821,fo=36492,Pc=36494,Lc=36495,hd=36283,Ic=36284,Dc=36285,Uc=36286;var ra=2300,aa=2301,po=2302,Nc=2400,Oc=2401,Fc=2402;var Wh=3e3,Wi=3001,ud=3200,dd=3201,Xh=0,fd=1,Mn="",Re="srgb",si="srgb-linear",Al="display-p3",Oa="display-p3-linear",oa="linear",ge="srgb",la="rec709",ca="p3";var as=7680;var Bc=519,pd=512,md=513,gd=514,Yh=515,xd=516,_d=517,vd=518,yd=519,zc=35044;var kc="300 es",Wo=1035,ni=2e3,ha=2001,Xn=class{addEventListener(t,e){this._listeners===void 0&&(this._listeners={});let n=this._listeners;n[t]===void 0&&(n[t]=[]),n[t].indexOf(e)===-1&&n[t].push(e)}hasEventListener(t,e){if(this._listeners===void 0)return!1;let n=this._listeners;return n[t]!==void 0&&n[t].indexOf(e)!==-1}removeEventListener(t,e){if(this._listeners===void 0)return;let s=this._listeners[t];if(s!==void 0){let r=s.indexOf(e);r!==-1&&s.splice(r,1)}}dispatchEvent(t){if(this._listeners===void 0)return;let n=this._listeners[t.type];if(n!==void 0){t.target=this;let s=n.slice(0);for(let r=0,o=s.length;r<o;r++)s[r].call(this,t);t.target=null}}},Ke=["00","01","02","03","04","05","06","07","08","09","0a","0b","0c","0d","0e","0f","10","11","12","13","14","15","16","17","18","19","1a","1b","1c","1d","1e","1f","20","21","22","23","24","25","26","27","28","29","2a","2b","2c","2d","2e","2f","30","31","32","33","34","35","36","37","38","39","3a","3b","3c","3d","3e","3f","40","41","42","43","44","45","46","47","48","49","4a","4b","4c","4d","4e","4f","50","51","52","53","54","55","56","57","58","59","5a","5b","5c","5d","5e","5f","60","61","62","63","64","65","66","67","68","69","6a","6b","6c","6d","6e","6f","70","71","72","73","74","75","76","77","78","79","7a","7b","7c","7d","7e","7f","80","81","82","83","84","85","86","87","88","89","8a","8b","8c","8d","8e","8f","90","91","92","93","94","95","96","97","98","99","9a","9b","9c","9d","9e","9f","a0","a1","a2","a3","a4","a5","a6","a7","a8","a9","aa","ab","ac","ad","ae","af","b0","b1","b2","b3","b4","b5","b6","b7","b8","b9","ba","bb","bc","bd","be","bf","c0","c1","c2","c3","c4","c5","c6","c7","c8","c9","ca","cb","cc","cd","ce","cf","d0","d1","d2","d3","d4","d5","d6","d7","d8","d9","da","db","dc","dd","de","df","e0","e1","e2","e3","e4","e5","e6","e7","e8","e9","ea","eb","ec","ed","ee","ef","f0","f1","f2","f3","f4","f5","f6","f7","f8","f9","fa","fb","fc","fd","fe","ff"],Hc=1234567,sr=Math.PI/180,hr=180/Math.PI;function Bs(){let i=Math.random()*4294967295|0,t=Math.random()*4294967295|0,e=Math.random()*4294967295|0,n=Math.random()*4294967295|0;return(Ke[i&255]+Ke[i>>8&255]+Ke[i>>16&255]+Ke[i>>24&255]+"-"+Ke[t&255]+Ke[t>>8&255]+"-"+Ke[t>>16&15|64]+Ke[t>>24&255]+"-"+Ke[e&63|128]+Ke[e>>8&255]+"-"+Ke[e>>16&255]+Ke[e>>24&255]+Ke[n&255]+Ke[n>>8&255]+Ke[n>>16&255]+Ke[n>>24&255]).toLowerCase()}function tn(i,t,e){return Math.max(t,Math.min(e,i))}function Cl(i,t){return(i%t+t)%t}function Md(i,t,e,n,s){return n+(i-t)*(s-n)/(e-t)}function bd(i,t,e){return i!==t?(e-i)/(t-i):0}function rr(i,t,e){return(1-e)*i+e*t}function Sd(i,t,e,n){return rr(i,t,1-Math.exp(-e*n))}function wd(i,t=1){return t-Math.abs(Cl(i,t*2)-t)}function Ed(i,t,e){return i<=t?0:i>=e?1:(i=(i-t)/(e-t),i*i*(3-2*i))}function Td(i,t,e){return i<=t?0:i>=e?1:(i=(i-t)/(e-t),i*i*i*(i*(i*6-15)+10))}function Ad(i,t){return i+Math.floor(Math.random()*(t-i+1))}function Cd(i,t){return i+Math.random()*(t-i)}function Rd(i){return i*(.5-Math.random())}function Pd(i){i!==void 0&&(Hc=i);let t=Hc+=1831565813;return t=Math.imul(t^t>>>15,t|1),t^=t+Math.imul(t^t>>>7,t|61),((t^t>>>14)>>>0)/4294967296}function Ld(i){return i*sr}function Id(i){return i*hr}function Xo(i){return(i&i-1)===0&&i!==0}function Dd(i){return Math.pow(2,Math.ceil(Math.log(i)/Math.LN2))}function ua(i){return Math.pow(2,Math.floor(Math.log(i)/Math.LN2))}function Ud(i,t,e,n,s){let r=Math.cos,o=Math.sin,a=r(e/2),l=o(e/2),c=r((t+n)/2),u=o((t+n)/2),f=r((t-n)/2),p=o((t-n)/2),x=r((n-t)/2),y=o((n-t)/2);switch(s){case"XYX":i.set(a*u,l*f,l*p,a*c);break;case"YZY":i.set(l*p,a*u,l*f,a*c);break;case"ZXZ":i.set(l*f,l*p,a*u,a*c);break;case"XZX":i.set(a*u,l*y,l*x,a*c);break;case"YXY":i.set(l*x,a*u,l*y,a*c);break;case"ZYZ":i.set(l*y,l*x,a*u,a*c);break;default:console.warn("THREE.MathUtils: .setQuaternionFromProperEuler() encountered an unknown order: "+s)}}function Ss(i,t){switch(t.constructor){case Float32Array:return i;case Uint32Array:return i/4294967295;case Uint16Array:return i/65535;case Uint8Array:return i/255;case Int32Array:return Math.max(i/2147483647,-1);case Int16Array:return Math.max(i/32767,-1);case Int8Array:return Math.max(i/127,-1);default:throw new Error("Invalid component type.")}}function ln(i,t){switch(t.constructor){case Float32Array:return i;case Uint32Array:return Math.round(i*4294967295);case Uint16Array:return Math.round(i*65535);case Uint8Array:return Math.round(i*255);case Int32Array:return Math.round(i*2147483647);case Int16Array:return Math.round(i*32767);case Int8Array:return Math.round(i*127);default:throw new Error("Invalid component type.")}}var qh={DEG2RAD:sr,RAD2DEG:hr,generateUUID:Bs,clamp:tn,euclideanModulo:Cl,mapLinear:Md,inverseLerp:bd,lerp:rr,damp:Sd,pingpong:wd,smoothstep:Ed,smootherstep:Td,randInt:Ad,randFloat:Cd,randFloatSpread:Rd,seededRandom:Pd,degToRad:Ld,radToDeg:Id,isPowerOfTwo:Xo,ceilPowerOfTwo:Dd,floorPowerOfTwo:ua,setQuaternionFromProperEuler:Ud,normalize:ln,denormalize:Ss},Pt=class i{constructor(t=0,e=0){i.prototype.isVector2=!0,this.x=t,this.y=e}get width(){return this.x}set width(t){this.x=t}get height(){return this.y}set height(t){this.y=t}set(t,e){return this.x=t,this.y=e,this}setScalar(t){return this.x=t,this.y=t,this}setX(t){return this.x=t,this}setY(t){return this.y=t,this}setComponent(t,e){switch(t){case 0:this.x=e;break;case 1:this.y=e;break;default:throw new Error("index is out of range: "+t)}return this}getComponent(t){switch(t){case 0:return this.x;case 1:return this.y;default:throw new Error("index is out of range: "+t)}}clone(){return new this.constructor(this.x,this.y)}copy(t){return this.x=t.x,this.y=t.y,this}add(t){return this.x+=t.x,this.y+=t.y,this}addScalar(t){return this.x+=t,this.y+=t,this}addVectors(t,e){return this.x=t.x+e.x,this.y=t.y+e.y,this}addScaledVector(t,e){return this.x+=t.x*e,this.y+=t.y*e,this}sub(t){return this.x-=t.x,this.y-=t.y,this}subScalar(t){return this.x-=t,this.y-=t,this}subVectors(t,e){return this.x=t.x-e.x,this.y=t.y-e.y,this}multiply(t){return this.x*=t.x,this.y*=t.y,this}multiplyScalar(t){return this.x*=t,this.y*=t,this}divide(t){return this.x/=t.x,this.y/=t.y,this}divideScalar(t){return this.multiplyScalar(1/t)}applyMatrix3(t){let e=this.x,n=this.y,s=t.elements;return this.x=s[0]*e+s[3]*n+s[6],this.y=s[1]*e+s[4]*n+s[7],this}min(t){return this.x=Math.min(this.x,t.x),this.y=Math.min(this.y,t.y),this}max(t){return this.x=Math.max(this.x,t.x),this.y=Math.max(this.y,t.y),this}clamp(t,e){return this.x=Math.max(t.x,Math.min(e.x,this.x)),this.y=Math.max(t.y,Math.min(e.y,this.y)),this}clampScalar(t,e){return this.x=Math.max(t,Math.min(e,this.x)),this.y=Math.max(t,Math.min(e,this.y)),this}clampLength(t,e){let n=this.length();return this.divideScalar(n||1).multiplyScalar(Math.max(t,Math.min(e,n)))}floor(){return this.x=Math.floor(this.x),this.y=Math.floor(this.y),this}ceil(){return this.x=Math.ceil(this.x),this.y=Math.ceil(this.y),this}round(){return this.x=Math.round(this.x),this.y=Math.round(this.y),this}roundToZero(){return this.x=Math.trunc(this.x),this.y=Math.trunc(this.y),this}negate(){return this.x=-this.x,this.y=-this.y,this}dot(t){return this.x*t.x+this.y*t.y}cross(t){return this.x*t.y-this.y*t.x}lengthSq(){return this.x*this.x+this.y*this.y}length(){return Math.sqrt(this.x*this.x+this.y*this.y)}manhattanLength(){return Math.abs(this.x)+Math.abs(this.y)}normalize(){return this.divideScalar(this.length()||1)}angle(){return Math.atan2(-this.y,-this.x)+Math.PI}angleTo(t){let e=Math.sqrt(this.lengthSq()*t.lengthSq());if(e===0)return Math.PI/2;let n=this.dot(t)/e;return Math.acos(tn(n,-1,1))}distanceTo(t){return Math.sqrt(this.distanceToSquared(t))}distanceToSquared(t){let e=this.x-t.x,n=this.y-t.y;return e*e+n*n}manhattanDistanceTo(t){return Math.abs(this.x-t.x)+Math.abs(this.y-t.y)}setLength(t){return this.normalize().multiplyScalar(t)}lerp(t,e){return this.x+=(t.x-this.x)*e,this.y+=(t.y-this.y)*e,this}lerpVectors(t,e,n){return this.x=t.x+(e.x-t.x)*n,this.y=t.y+(e.y-t.y)*n,this}equals(t){return t.x===this.x&&t.y===this.y}fromArray(t,e=0){return this.x=t[e],this.y=t[e+1],this}toArray(t=[],e=0){return t[e]=this.x,t[e+1]=this.y,t}fromBufferAttribute(t,e){return this.x=t.getX(e),this.y=t.getY(e),this}rotateAround(t,e){let n=Math.cos(e),s=Math.sin(e),r=this.x-t.x,o=this.y-t.y;return this.x=r*n-o*s+t.x,this.y=r*s+o*n+t.y,this}random(){return this.x=Math.random(),this.y=Math.random(),this}*[Symbol.iterator](){yield this.x,yield this.y}},re=class i{constructor(t,e,n,s,r,o,a,l,c){i.prototype.isMatrix3=!0,this.elements=[1,0,0,0,1,0,0,0,1],t!==void 0&&this.set(t,e,n,s,r,o,a,l,c)}set(t,e,n,s,r,o,a,l,c){let u=this.elements;return u[0]=t,u[1]=s,u[2]=a,u[3]=e,u[4]=r,u[5]=l,u[6]=n,u[7]=o,u[8]=c,this}identity(){return this.set(1,0,0,0,1,0,0,0,1),this}copy(t){let e=this.elements,n=t.elements;return e[0]=n[0],e[1]=n[1],e[2]=n[2],e[3]=n[3],e[4]=n[4],e[5]=n[5],e[6]=n[6],e[7]=n[7],e[8]=n[8],this}extractBasis(t,e,n){return t.setFromMatrix3Column(this,0),e.setFromMatrix3Column(this,1),n.setFromMatrix3Column(this,2),this}setFromMatrix4(t){let e=t.elements;return this.set(e[0],e[4],e[8],e[1],e[5],e[9],e[2],e[6],e[10]),this}multiply(t){return this.multiplyMatrices(this,t)}premultiply(t){return this.multiplyMatrices(t,this)}multiplyMatrices(t,e){let n=t.elements,s=e.elements,r=this.elements,o=n[0],a=n[3],l=n[6],c=n[1],u=n[4],f=n[7],p=n[2],x=n[5],y=n[8],b=s[0],m=s[3],d=s[6],C=s[1],w=s[4],U=s[7],z=s[2],N=s[5],L=s[8];return r[0]=o*b+a*C+l*z,r[3]=o*m+a*w+l*N,r[6]=o*d+a*U+l*L,r[1]=c*b+u*C+f*z,r[4]=c*m+u*w+f*N,r[7]=c*d+u*U+f*L,r[2]=p*b+x*C+y*z,r[5]=p*m+x*w+y*N,r[8]=p*d+x*U+y*L,this}multiplyScalar(t){let e=this.elements;return e[0]*=t,e[3]*=t,e[6]*=t,e[1]*=t,e[4]*=t,e[7]*=t,e[2]*=t,e[5]*=t,e[8]*=t,this}determinant(){let t=this.elements,e=t[0],n=t[1],s=t[2],r=t[3],o=t[4],a=t[5],l=t[6],c=t[7],u=t[8];return e*o*u-e*a*c-n*r*u+n*a*l+s*r*c-s*o*l}invert(){let t=this.elements,e=t[0],n=t[1],s=t[2],r=t[3],o=t[4],a=t[5],l=t[6],c=t[7],u=t[8],f=u*o-a*c,p=a*l-u*r,x=c*r-o*l,y=e*f+n*p+s*x;if(y===0)return this.set(0,0,0,0,0,0,0,0,0);let b=1/y;return t[0]=f*b,t[1]=(s*c-u*n)*b,t[2]=(a*n-s*o)*b,t[3]=p*b,t[4]=(u*e-s*l)*b,t[5]=(s*r-a*e)*b,t[6]=x*b,t[7]=(n*l-c*e)*b,t[8]=(o*e-n*r)*b,this}transpose(){let t,e=this.elements;return t=e[1],e[1]=e[3],e[3]=t,t=e[2],e[2]=e[6],e[6]=t,t=e[5],e[5]=e[7],e[7]=t,this}getNormalMatrix(t){return this.setFromMatrix4(t).invert().transpose()}transposeIntoArray(t){let e=this.elements;return t[0]=e[0],t[1]=e[3],t[2]=e[6],t[3]=e[1],t[4]=e[4],t[5]=e[7],t[6]=e[2],t[7]=e[5],t[8]=e[8],this}setUvTransform(t,e,n,s,r,o,a){let l=Math.cos(r),c=Math.sin(r);return this.set(n*l,n*c,-n*(l*o+c*a)+o+t,-s*c,s*l,-s*(-c*o+l*a)+a+e,0,0,1),this}scale(t,e){return this.premultiply(mo.makeScale(t,e)),this}rotate(t){return this.premultiply(mo.makeRotation(-t)),this}translate(t,e){return this.premultiply(mo.makeTranslation(t,e)),this}makeTranslation(t,e){return t.isVector2?this.set(1,0,t.x,0,1,t.y,0,0,1):this.set(1,0,t,0,1,e,0,0,1),this}makeRotation(t){let e=Math.cos(t),n=Math.sin(t);return this.set(e,-n,0,n,e,0,0,0,1),this}makeScale(t,e){return this.set(t,0,0,0,e,0,0,0,1),this}equals(t){let e=this.elements,n=t.elements;for(let s=0;s<9;s++)if(e[s]!==n[s])return!1;return!0}fromArray(t,e=0){for(let n=0;n<9;n++)this.elements[n]=t[n+e];return this}toArray(t=[],e=0){let n=this.elements;return t[e]=n[0],t[e+1]=n[1],t[e+2]=n[2],t[e+3]=n[3],t[e+4]=n[4],t[e+5]=n[5],t[e+6]=n[6],t[e+7]=n[7],t[e+8]=n[8],t}clone(){return new this.constructor().fromArray(this.elements)}},mo=new re;function Zh(i){for(let t=i.length-1;t>=0;--t)if(i[t]>=65535)return!0;return!1}function da(i){return document.createElementNS("http://www.w3.org/1999/xhtml",i)}function Nd(){let i=da("canvas");return i.style.display="block",i}var Vc={};function ar(i){i in Vc||(Vc[i]=!0,console.warn(i))}var Gc=new re().set(.8224621,.177538,0,.0331941,.9668058,0,.0170827,.0723974,.9105199),Wc=new re().set(1.2249401,-.2249404,0,-.0420569,1.0420571,0,-.0196376,-.0786361,1.0982735),Ir={[si]:{transfer:oa,primaries:la,toReference:i=>i,fromReference:i=>i},[Re]:{transfer:ge,primaries:la,toReference:i=>i.convertSRGBToLinear(),fromReference:i=>i.convertLinearToSRGB()},[Oa]:{transfer:oa,primaries:ca,toReference:i=>i.applyMatrix3(Wc),fromReference:i=>i.applyMatrix3(Gc)},[Al]:{transfer:ge,primaries:ca,toReference:i=>i.convertSRGBToLinear().applyMatrix3(Wc),fromReference:i=>i.applyMatrix3(Gc).convertLinearToSRGB()}},Od=new Set([si,Oa]),fe={enabled:!0,_workingColorSpace:si,get workingColorSpace(){return this._workingColorSpace},set workingColorSpace(i){if(!Od.has(i))throw new Error(`Unsupported working color space, "${i}".`);this._workingColorSpace=i},convert:function(i,t,e){if(this.enabled===!1||t===e||!t||!e)return i;let n=Ir[t].toReference,s=Ir[e].fromReference;return s(n(i))},fromWorkingColorSpace:function(i,t){return this.convert(i,this._workingColorSpace,t)},toWorkingColorSpace:function(i,t){return this.convert(i,t,this._workingColorSpace)},getPrimaries:function(i){return Ir[i].primaries},getTransfer:function(i){return i===Mn?oa:Ir[i].transfer}};function As(i){return i<.04045?i*.0773993808:Math.pow(i*.9478672986+.0521327014,2.4)}function go(i){return i<.0031308?i*12.92:1.055*Math.pow(i,.41666)-.055}var os,fa=class{static getDataURL(t){if(/^data:/i.test(t.src)||typeof HTMLCanvasElement>"u")return t.src;let e;if(t instanceof HTMLCanvasElement)e=t;else{os===void 0&&(os=da("canvas")),os.width=t.width,os.height=t.height;let n=os.getContext("2d");t instanceof ImageData?n.putImageData(t,0,0):n.drawImage(t,0,0,t.width,t.height),e=os}return e.width>2048||e.height>2048?(console.warn("THREE.ImageUtils.getDataURL: Image converted to jpg for performance reasons",t),e.toDataURL("image/jpeg",.6)):e.toDataURL("image/png")}static sRGBToLinear(t){if(typeof HTMLImageElement<"u"&&t instanceof HTMLImageElement||typeof HTMLCanvasElement<"u"&&t instanceof HTMLCanvasElement||typeof ImageBitmap<"u"&&t instanceof ImageBitmap){let e=da("canvas");e.width=t.width,e.height=t.height;let n=e.getContext("2d");n.drawImage(t,0,0,t.width,t.height);let s=n.getImageData(0,0,t.width,t.height),r=s.data;for(let o=0;o<r.length;o++)r[o]=As(r[o]/255)*255;return n.putImageData(s,0,0),e}else if(t.data){let e=t.data.slice(0);for(let n=0;n<e.length;n++)e instanceof Uint8Array||e instanceof Uint8ClampedArray?e[n]=Math.floor(As(e[n]/255)*255):e[n]=As(e[n]);return{data:e,width:t.width,height:t.height}}else return console.warn("THREE.ImageUtils.sRGBToLinear(): Unsupported image type. No color space conversion applied."),t}},Fd=0,pa=class{constructor(t=null){this.isSource=!0,Object.defineProperty(this,"id",{value:Fd++}),this.uuid=Bs(),this.data=t,this.version=0}set needsUpdate(t){t===!0&&this.version++}toJSON(t){let e=t===void 0||typeof t=="string";if(!e&&t.images[this.uuid]!==void 0)return t.images[this.uuid];let n={uuid:this.uuid,url:""},s=this.data;if(s!==null){let r;if(Array.isArray(s)){r=[];for(let o=0,a=s.length;o<a;o++)s[o].isDataTexture?r.push(xo(s[o].image)):r.push(xo(s[o]))}else r=xo(s);n.url=r}return e||(t.images[this.uuid]=n),n}};function xo(i){return typeof HTMLImageElement<"u"&&i instanceof HTMLImageElement||typeof HTMLCanvasElement<"u"&&i instanceof HTMLCanvasElement||typeof ImageBitmap<"u"&&i instanceof ImageBitmap?fa.getDataURL(i):i.data?{data:Array.from(i.data),width:i.width,height:i.height,type:i.data.constructor.name}:(console.warn("THREE.Texture: Unable to serialize Texture."),{})}var Bd=0,bn=class i extends Xn{constructor(t=i.DEFAULT_IMAGE,e=i.DEFAULT_MAPPING,n=Dn,s=Dn,r=yn,o=cr,a=Un,l=yi,c=i.DEFAULT_ANISOTROPY,u=Mn){super(),this.isTexture=!0,Object.defineProperty(this,"id",{value:Bd++}),this.uuid=Bs(),this.name="",this.source=new pa(t),this.mipmaps=[],this.mapping=e,this.channel=0,this.wrapS=n,this.wrapT=s,this.magFilter=r,this.minFilter=o,this.anisotropy=c,this.format=a,this.internalFormat=null,this.type=l,this.offset=new Pt(0,0),this.repeat=new Pt(1,1),this.center=new Pt(0,0),this.rotation=0,this.matrixAutoUpdate=!0,this.matrix=new re,this.generateMipmaps=!0,this.premultiplyAlpha=!1,this.flipY=!0,this.unpackAlignment=4,typeof u=="string"?this.colorSpace=u:(ar("THREE.Texture: Property .encoding has been replaced by .colorSpace."),this.colorSpace=u===Wi?Re:Mn),this.userData={},this.version=0,this.onUpdate=null,this.isRenderTargetTexture=!1,this.needsPMREMUpdate=!1}get image(){return this.source.data}set image(t=null){this.source.data=t}updateMatrix(){this.matrix.setUvTransform(this.offset.x,this.offset.y,this.repeat.x,this.repeat.y,this.rotation,this.center.x,this.center.y)}clone(){return new this.constructor().copy(this)}copy(t){return this.name=t.name,this.source=t.source,this.mipmaps=t.mipmaps.slice(0),this.mapping=t.mapping,this.channel=t.channel,this.wrapS=t.wrapS,this.wrapT=t.wrapT,this.magFilter=t.magFilter,this.minFilter=t.minFilter,this.anisotropy=t.anisotropy,this.format=t.format,this.internalFormat=t.internalFormat,this.type=t.type,this.offset.copy(t.offset),this.repeat.copy(t.repeat),this.center.copy(t.center),this.rotation=t.rotation,this.matrixAutoUpdate=t.matrixAutoUpdate,this.matrix.copy(t.matrix),this.generateMipmaps=t.generateMipmaps,this.premultiplyAlpha=t.premultiplyAlpha,this.flipY=t.flipY,this.unpackAlignment=t.unpackAlignment,this.colorSpace=t.colorSpace,this.userData=JSON.parse(JSON.stringify(t.userData)),this.needsUpdate=!0,this}toJSON(t){let e=t===void 0||typeof t=="string";if(!e&&t.textures[this.uuid]!==void 0)return t.textures[this.uuid];let n={metadata:{version:4.6,type:"Texture",generator:"Texture.toJSON"},uuid:this.uuid,name:this.name,image:this.source.toJSON(t).uuid,mapping:this.mapping,channel:this.channel,repeat:[this.repeat.x,this.repeat.y],offset:[this.offset.x,this.offset.y],center:[this.center.x,this.center.y],rotation:this.rotation,wrap:[this.wrapS,this.wrapT],format:this.format,internalFormat:this.internalFormat,type:this.type,colorSpace:this.colorSpace,minFilter:this.minFilter,magFilter:this.magFilter,anisotropy:this.anisotropy,flipY:this.flipY,generateMipmaps:this.generateMipmaps,premultiplyAlpha:this.premultiplyAlpha,unpackAlignment:this.unpackAlignment};return Object.keys(this.userData).length>0&&(n.userData=this.userData),e||(t.textures[this.uuid]=n),n}dispose(){this.dispatchEvent({type:"dispose"})}transformUv(t){if(this.mapping!==Oh)return t;if(t.applyMatrix3(this.matrix),t.x<0||t.x>1)switch(this.wrapS){case lr:t.x=t.x-Math.floor(t.x);break;case Dn:t.x=t.x<0?0:1;break;case Go:Math.abs(Math.floor(t.x)%2)===1?t.x=Math.ceil(t.x)-t.x:t.x=t.x-Math.floor(t.x);break}if(t.y<0||t.y>1)switch(this.wrapT){case lr:t.y=t.y-Math.floor(t.y);break;case Dn:t.y=t.y<0?0:1;break;case Go:Math.abs(Math.floor(t.y)%2)===1?t.y=Math.ceil(t.y)-t.y:t.y=t.y-Math.floor(t.y);break}return this.flipY&&(t.y=1-t.y),t}set needsUpdate(t){t===!0&&(this.version++,this.source.needsUpdate=!0)}get encoding(){return ar("THREE.Texture: Property .encoding has been replaced by .colorSpace."),this.colorSpace===Re?Wi:Wh}set encoding(t){ar("THREE.Texture: Property .encoding has been replaced by .colorSpace."),this.colorSpace=t===Wi?Re:Mn}};bn.DEFAULT_IMAGE=null;bn.DEFAULT_MAPPING=Oh;bn.DEFAULT_ANISOTROPY=1;var we=class i{constructor(t=0,e=0,n=0,s=1){i.prototype.isVector4=!0,this.x=t,this.y=e,this.z=n,this.w=s}get width(){return this.z}set width(t){this.z=t}get height(){return this.w}set height(t){this.w=t}set(t,e,n,s){return this.x=t,this.y=e,this.z=n,this.w=s,this}setScalar(t){return this.x=t,this.y=t,this.z=t,this.w=t,this}setX(t){return this.x=t,this}setY(t){return this.y=t,this}setZ(t){return this.z=t,this}setW(t){return this.w=t,this}setComponent(t,e){switch(t){case 0:this.x=e;break;case 1:this.y=e;break;case 2:this.z=e;break;case 3:this.w=e;break;default:throw new Error("index is out of range: "+t)}return this}getComponent(t){switch(t){case 0:return this.x;case 1:return this.y;case 2:return this.z;case 3:return this.w;default:throw new Error("index is out of range: "+t)}}clone(){return new this.constructor(this.x,this.y,this.z,this.w)}copy(t){return this.x=t.x,this.y=t.y,this.z=t.z,this.w=t.w!==void 0?t.w:1,this}add(t){return this.x+=t.x,this.y+=t.y,this.z+=t.z,this.w+=t.w,this}addScalar(t){return this.x+=t,this.y+=t,this.z+=t,this.w+=t,this}addVectors(t,e){return this.x=t.x+e.x,this.y=t.y+e.y,this.z=t.z+e.z,this.w=t.w+e.w,this}addScaledVector(t,e){return this.x+=t.x*e,this.y+=t.y*e,this.z+=t.z*e,this.w+=t.w*e,this}sub(t){return this.x-=t.x,this.y-=t.y,this.z-=t.z,this.w-=t.w,this}subScalar(t){return this.x-=t,this.y-=t,this.z-=t,this.w-=t,this}subVectors(t,e){return this.x=t.x-e.x,this.y=t.y-e.y,this.z=t.z-e.z,this.w=t.w-e.w,this}multiply(t){return this.x*=t.x,this.y*=t.y,this.z*=t.z,this.w*=t.w,this}multiplyScalar(t){return this.x*=t,this.y*=t,this.z*=t,this.w*=t,this}applyMatrix4(t){let e=this.x,n=this.y,s=this.z,r=this.w,o=t.elements;return this.x=o[0]*e+o[4]*n+o[8]*s+o[12]*r,this.y=o[1]*e+o[5]*n+o[9]*s+o[13]*r,this.z=o[2]*e+o[6]*n+o[10]*s+o[14]*r,this.w=o[3]*e+o[7]*n+o[11]*s+o[15]*r,this}divideScalar(t){return this.multiplyScalar(1/t)}setAxisAngleFromQuaternion(t){this.w=2*Math.acos(t.w);let e=Math.sqrt(1-t.w*t.w);return e<1e-4?(this.x=1,this.y=0,this.z=0):(this.x=t.x/e,this.y=t.y/e,this.z=t.z/e),this}setAxisAngleFromRotationMatrix(t){let e,n,s,r,l=t.elements,c=l[0],u=l[4],f=l[8],p=l[1],x=l[5],y=l[9],b=l[2],m=l[6],d=l[10];if(Math.abs(u-p)<.01&&Math.abs(f-b)<.01&&Math.abs(y-m)<.01){if(Math.abs(u+p)<.1&&Math.abs(f+b)<.1&&Math.abs(y+m)<.1&&Math.abs(c+x+d-3)<.1)return this.set(1,0,0,0),this;e=Math.PI;let w=(c+1)/2,U=(x+1)/2,z=(d+1)/2,N=(u+p)/4,L=(f+b)/4,j=(y+m)/4;return w>U&&w>z?w<.01?(n=0,s=.707106781,r=.707106781):(n=Math.sqrt(w),s=N/n,r=L/n):U>z?U<.01?(n=.707106781,s=0,r=.707106781):(s=Math.sqrt(U),n=N/s,r=j/s):z<.01?(n=.707106781,s=.707106781,r=0):(r=Math.sqrt(z),n=L/r,s=j/r),this.set(n,s,r,e),this}let C=Math.sqrt((m-y)*(m-y)+(f-b)*(f-b)+(p-u)*(p-u));return Math.abs(C)<.001&&(C=1),this.x=(m-y)/C,this.y=(f-b)/C,this.z=(p-u)/C,this.w=Math.acos((c+x+d-1)/2),this}min(t){return this.x=Math.min(this.x,t.x),this.y=Math.min(this.y,t.y),this.z=Math.min(this.z,t.z),this.w=Math.min(this.w,t.w),this}max(t){return this.x=Math.max(this.x,t.x),this.y=Math.max(this.y,t.y),this.z=Math.max(this.z,t.z),this.w=Math.max(this.w,t.w),this}clamp(t,e){return this.x=Math.max(t.x,Math.min(e.x,this.x)),this.y=Math.max(t.y,Math.min(e.y,this.y)),this.z=Math.max(t.z,Math.min(e.z,this.z)),this.w=Math.max(t.w,Math.min(e.w,this.w)),this}clampScalar(t,e){return this.x=Math.max(t,Math.min(e,this.x)),this.y=Math.max(t,Math.min(e,this.y)),this.z=Math.max(t,Math.min(e,this.z)),this.w=Math.max(t,Math.min(e,this.w)),this}clampLength(t,e){let n=this.length();return this.divideScalar(n||1).multiplyScalar(Math.max(t,Math.min(e,n)))}floor(){return this.x=Math.floor(this.x),this.y=Math.floor(this.y),this.z=Math.floor(this.z),this.w=Math.floor(this.w),this}ceil(){return this.x=Math.ceil(this.x),this.y=Math.ceil(this.y),this.z=Math.ceil(this.z),this.w=Math.ceil(this.w),this}round(){return this.x=Math.round(this.x),this.y=Math.round(this.y),this.z=Math.round(this.z),this.w=Math.round(this.w),this}roundToZero(){return this.x=Math.trunc(this.x),this.y=Math.trunc(this.y),this.z=Math.trunc(this.z),this.w=Math.trunc(this.w),this}negate(){return this.x=-this.x,this.y=-this.y,this.z=-this.z,this.w=-this.w,this}dot(t){return this.x*t.x+this.y*t.y+this.z*t.z+this.w*t.w}lengthSq(){return this.x*this.x+this.y*this.y+this.z*this.z+this.w*this.w}length(){return Math.sqrt(this.x*this.x+this.y*this.y+this.z*this.z+this.w*this.w)}manhattanLength(){return Math.abs(this.x)+Math.abs(this.y)+Math.abs(this.z)+Math.abs(this.w)}normalize(){return this.divideScalar(this.length()||1)}setLength(t){return this.normalize().multiplyScalar(t)}lerp(t,e){return this.x+=(t.x-this.x)*e,this.y+=(t.y-this.y)*e,this.z+=(t.z-this.z)*e,this.w+=(t.w-this.w)*e,this}lerpVectors(t,e,n){return this.x=t.x+(e.x-t.x)*n,this.y=t.y+(e.y-t.y)*n,this.z=t.z+(e.z-t.z)*n,this.w=t.w+(e.w-t.w)*n,this}equals(t){return t.x===this.x&&t.y===this.y&&t.z===this.z&&t.w===this.w}fromArray(t,e=0){return this.x=t[e],this.y=t[e+1],this.z=t[e+2],this.w=t[e+3],this}toArray(t=[],e=0){return t[e]=this.x,t[e+1]=this.y,t[e+2]=this.z,t[e+3]=this.w,t}fromBufferAttribute(t,e){return this.x=t.getX(e),this.y=t.getY(e),this.z=t.getZ(e),this.w=t.getW(e),this}random(){return this.x=Math.random(),this.y=Math.random(),this.z=Math.random(),this.w=Math.random(),this}*[Symbol.iterator](){yield this.x,yield this.y,yield this.z,yield this.w}},Yo=class extends Xn{constructor(t=1,e=1,n={}){super(),this.isRenderTarget=!0,this.width=t,this.height=e,this.depth=1,this.scissor=new we(0,0,t,e),this.scissorTest=!1,this.viewport=new we(0,0,t,e);let s={width:t,height:e,depth:1};n.encoding!==void 0&&(ar("THREE.WebGLRenderTarget: option.encoding has been replaced by option.colorSpace."),n.colorSpace=n.encoding===Wi?Re:Mn),n=Object.assign({generateMipmaps:!1,internalFormat:null,minFilter:yn,depthBuffer:!0,stencilBuffer:!1,depthTexture:null,samples:0},n),this.texture=new bn(s,n.mapping,n.wrapS,n.wrapT,n.magFilter,n.minFilter,n.format,n.type,n.anisotropy,n.colorSpace),this.texture.isRenderTargetTexture=!0,this.texture.flipY=!1,this.texture.generateMipmaps=n.generateMipmaps,this.texture.internalFormat=n.internalFormat,this.depthBuffer=n.depthBuffer,this.stencilBuffer=n.stencilBuffer,this.depthTexture=n.depthTexture,this.samples=n.samples}setSize(t,e,n=1){(this.width!==t||this.height!==e||this.depth!==n)&&(this.width=t,this.height=e,this.depth=n,this.texture.image.width=t,this.texture.image.height=e,this.texture.image.depth=n,this.dispose()),this.viewport.set(0,0,t,e),this.scissor.set(0,0,t,e)}clone(){return new this.constructor().copy(this)}copy(t){this.width=t.width,this.height=t.height,this.depth=t.depth,this.scissor.copy(t.scissor),this.scissorTest=t.scissorTest,this.viewport.copy(t.viewport),this.texture=t.texture.clone(),this.texture.isRenderTargetTexture=!0;let e=Object.assign({},t.texture.image);return this.texture.source=new pa(e),this.depthBuffer=t.depthBuffer,this.stencilBuffer=t.stencilBuffer,t.depthTexture!==null&&(this.depthTexture=t.depthTexture.clone()),this.samples=t.samples,this}dispose(){this.dispatchEvent({type:"dispose"})}},je=class extends Yo{constructor(t=1,e=1,n={}){super(t,e,n),this.isWebGLRenderTarget=!0}},ma=class extends bn{constructor(t=null,e=1,n=1,s=1){super(null),this.isDataArrayTexture=!0,this.image={data:t,width:e,height:n,depth:s},this.magFilter=qe,this.minFilter=qe,this.wrapR=Dn,this.generateMipmaps=!1,this.flipY=!1,this.unpackAlignment=1}};var qo=class extends bn{constructor(t=null,e=1,n=1,s=1){super(null),this.isData3DTexture=!0,this.image={data:t,width:e,height:n,depth:s},this.magFilter=qe,this.minFilter=qe,this.wrapR=Dn,this.generateMipmaps=!1,this.flipY=!1,this.unpackAlignment=1}};var Nn=class{constructor(t=0,e=0,n=0,s=1){this.isQuaternion=!0,this._x=t,this._y=e,this._z=n,this._w=s}static slerpFlat(t,e,n,s,r,o,a){let l=n[s+0],c=n[s+1],u=n[s+2],f=n[s+3],p=r[o+0],x=r[o+1],y=r[o+2],b=r[o+3];if(a===0){t[e+0]=l,t[e+1]=c,t[e+2]=u,t[e+3]=f;return}if(a===1){t[e+0]=p,t[e+1]=x,t[e+2]=y,t[e+3]=b;return}if(f!==b||l!==p||c!==x||u!==y){let m=1-a,d=l*p+c*x+u*y+f*b,C=d>=0?1:-1,w=1-d*d;if(w>Number.EPSILON){let z=Math.sqrt(w),N=Math.atan2(z,d*C);m=Math.sin(m*N)/z,a=Math.sin(a*N)/z}let U=a*C;if(l=l*m+p*U,c=c*m+x*U,u=u*m+y*U,f=f*m+b*U,m===1-a){let z=1/Math.sqrt(l*l+c*c+u*u+f*f);l*=z,c*=z,u*=z,f*=z}}t[e]=l,t[e+1]=c,t[e+2]=u,t[e+3]=f}static multiplyQuaternionsFlat(t,e,n,s,r,o){let a=n[s],l=n[s+1],c=n[s+2],u=n[s+3],f=r[o],p=r[o+1],x=r[o+2],y=r[o+3];return t[e]=a*y+u*f+l*x-c*p,t[e+1]=l*y+u*p+c*f-a*x,t[e+2]=c*y+u*x+a*p-l*f,t[e+3]=u*y-a*f-l*p-c*x,t}get x(){return this._x}set x(t){this._x=t,this._onChangeCallback()}get y(){return this._y}set y(t){this._y=t,this._onChangeCallback()}get z(){return this._z}set z(t){this._z=t,this._onChangeCallback()}get w(){return this._w}set w(t){this._w=t,this._onChangeCallback()}set(t,e,n,s){return this._x=t,this._y=e,this._z=n,this._w=s,this._onChangeCallback(),this}clone(){return new this.constructor(this._x,this._y,this._z,this._w)}copy(t){return this._x=t.x,this._y=t.y,this._z=t.z,this._w=t.w,this._onChangeCallback(),this}setFromEuler(t,e=!0){let n=t._x,s=t._y,r=t._z,o=t._order,a=Math.cos,l=Math.sin,c=a(n/2),u=a(s/2),f=a(r/2),p=l(n/2),x=l(s/2),y=l(r/2);switch(o){case"XYZ":this._x=p*u*f+c*x*y,this._y=c*x*f-p*u*y,this._z=c*u*y+p*x*f,this._w=c*u*f-p*x*y;break;case"YXZ":this._x=p*u*f+c*x*y,this._y=c*x*f-p*u*y,this._z=c*u*y-p*x*f,this._w=c*u*f+p*x*y;break;case"ZXY":this._x=p*u*f-c*x*y,this._y=c*x*f+p*u*y,this._z=c*u*y+p*x*f,this._w=c*u*f-p*x*y;break;case"ZYX":this._x=p*u*f-c*x*y,this._y=c*x*f+p*u*y,this._z=c*u*y-p*x*f,this._w=c*u*f+p*x*y;break;case"YZX":this._x=p*u*f+c*x*y,this._y=c*x*f+p*u*y,this._z=c*u*y-p*x*f,this._w=c*u*f-p*x*y;break;case"XZY":this._x=p*u*f-c*x*y,this._y=c*x*f-p*u*y,this._z=c*u*y+p*x*f,this._w=c*u*f+p*x*y;break;default:console.warn("THREE.Quaternion: .setFromEuler() encountered an unknown order: "+o)}return e===!0&&this._onChangeCallback(),this}setFromAxisAngle(t,e){let n=e/2,s=Math.sin(n);return this._x=t.x*s,this._y=t.y*s,this._z=t.z*s,this._w=Math.cos(n),this._onChangeCallback(),this}setFromRotationMatrix(t){let e=t.elements,n=e[0],s=e[4],r=e[8],o=e[1],a=e[5],l=e[9],c=e[2],u=e[6],f=e[10],p=n+a+f;if(p>0){let x=.5/Math.sqrt(p+1);this._w=.25/x,this._x=(u-l)*x,this._y=(r-c)*x,this._z=(o-s)*x}else if(n>a&&n>f){let x=2*Math.sqrt(1+n-a-f);this._w=(u-l)/x,this._x=.25*x,this._y=(s+o)/x,this._z=(r+c)/x}else if(a>f){let x=2*Math.sqrt(1+a-n-f);this._w=(r-c)/x,this._x=(s+o)/x,this._y=.25*x,this._z=(l+u)/x}else{let x=2*Math.sqrt(1+f-n-a);this._w=(o-s)/x,this._x=(r+c)/x,this._y=(l+u)/x,this._z=.25*x}return this._onChangeCallback(),this}setFromUnitVectors(t,e){let n=t.dot(e)+1;return n<Number.EPSILON?(n=0,Math.abs(t.x)>Math.abs(t.z)?(this._x=-t.y,this._y=t.x,this._z=0,this._w=n):(this._x=0,this._y=-t.z,this._z=t.y,this._w=n)):(this._x=t.y*e.z-t.z*e.y,this._y=t.z*e.x-t.x*e.z,this._z=t.x*e.y-t.y*e.x,this._w=n),this.normalize()}angleTo(t){return 2*Math.acos(Math.abs(tn(this.dot(t),-1,1)))}rotateTowards(t,e){let n=this.angleTo(t);if(n===0)return this;let s=Math.min(1,e/n);return this.slerp(t,s),this}identity(){return this.set(0,0,0,1)}invert(){return this.conjugate()}conjugate(){return this._x*=-1,this._y*=-1,this._z*=-1,this._onChangeCallback(),this}dot(t){return this._x*t._x+this._y*t._y+this._z*t._z+this._w*t._w}lengthSq(){return this._x*this._x+this._y*this._y+this._z*this._z+this._w*this._w}length(){return Math.sqrt(this._x*this._x+this._y*this._y+this._z*this._z+this._w*this._w)}normalize(){let t=this.length();return t===0?(this._x=0,this._y=0,this._z=0,this._w=1):(t=1/t,this._x=this._x*t,this._y=this._y*t,this._z=this._z*t,this._w=this._w*t),this._onChangeCallback(),this}multiply(t){return this.multiplyQuaternions(this,t)}premultiply(t){return this.multiplyQuaternions(t,this)}multiplyQuaternions(t,e){let n=t._x,s=t._y,r=t._z,o=t._w,a=e._x,l=e._y,c=e._z,u=e._w;return this._x=n*u+o*a+s*c-r*l,this._y=s*u+o*l+r*a-n*c,this._z=r*u+o*c+n*l-s*a,this._w=o*u-n*a-s*l-r*c,this._onChangeCallback(),this}slerp(t,e){if(e===0)return this;if(e===1)return this.copy(t);let n=this._x,s=this._y,r=this._z,o=this._w,a=o*t._w+n*t._x+s*t._y+r*t._z;if(a<0?(this._w=-t._w,this._x=-t._x,this._y=-t._y,this._z=-t._z,a=-a):this.copy(t),a>=1)return this._w=o,this._x=n,this._y=s,this._z=r,this;let l=1-a*a;if(l<=Number.EPSILON){let x=1-e;return this._w=x*o+e*this._w,this._x=x*n+e*this._x,this._y=x*s+e*this._y,this._z=x*r+e*this._z,this.normalize(),this}let c=Math.sqrt(l),u=Math.atan2(c,a),f=Math.sin((1-e)*u)/c,p=Math.sin(e*u)/c;return this._w=o*f+this._w*p,this._x=n*f+this._x*p,this._y=s*f+this._y*p,this._z=r*f+this._z*p,this._onChangeCallback(),this}slerpQuaternions(t,e,n){return this.copy(t).slerp(e,n)}random(){let t=Math.random(),e=Math.sqrt(1-t),n=Math.sqrt(t),s=2*Math.PI*Math.random(),r=2*Math.PI*Math.random();return this.set(e*Math.cos(s),n*Math.sin(r),n*Math.cos(r),e*Math.sin(s))}equals(t){return t._x===this._x&&t._y===this._y&&t._z===this._z&&t._w===this._w}fromArray(t,e=0){return this._x=t[e],this._y=t[e+1],this._z=t[e+2],this._w=t[e+3],this._onChangeCallback(),this}toArray(t=[],e=0){return t[e]=this._x,t[e+1]=this._y,t[e+2]=this._z,t[e+3]=this._w,t}fromBufferAttribute(t,e){return this._x=t.getX(e),this._y=t.getY(e),this._z=t.getZ(e),this._w=t.getW(e),this._onChangeCallback(),this}toJSON(){return this.toArray()}_onChange(t){return this._onChangeCallback=t,this}_onChangeCallback(){}*[Symbol.iterator](){yield this._x,yield this._y,yield this._z,yield this._w}},F=class i{constructor(t=0,e=0,n=0){i.prototype.isVector3=!0,this.x=t,this.y=e,this.z=n}set(t,e,n){return n===void 0&&(n=this.z),this.x=t,this.y=e,this.z=n,this}setScalar(t){return this.x=t,this.y=t,this.z=t,this}setX(t){return this.x=t,this}setY(t){return this.y=t,this}setZ(t){return this.z=t,this}setComponent(t,e){switch(t){case 0:this.x=e;break;case 1:this.y=e;break;case 2:this.z=e;break;default:throw new Error("index is out of range: "+t)}return this}getComponent(t){switch(t){case 0:return this.x;case 1:return this.y;case 2:return this.z;default:throw new Error("index is out of range: "+t)}}clone(){return new this.constructor(this.x,this.y,this.z)}copy(t){return this.x=t.x,this.y=t.y,this.z=t.z,this}add(t){return this.x+=t.x,this.y+=t.y,this.z+=t.z,this}addScalar(t){return this.x+=t,this.y+=t,this.z+=t,this}addVectors(t,e){return this.x=t.x+e.x,this.y=t.y+e.y,this.z=t.z+e.z,this}addScaledVector(t,e){return this.x+=t.x*e,this.y+=t.y*e,this.z+=t.z*e,this}sub(t){return this.x-=t.x,this.y-=t.y,this.z-=t.z,this}subScalar(t){return this.x-=t,this.y-=t,this.z-=t,this}subVectors(t,e){return this.x=t.x-e.x,this.y=t.y-e.y,this.z=t.z-e.z,this}multiply(t){return this.x*=t.x,this.y*=t.y,this.z*=t.z,this}multiplyScalar(t){return this.x*=t,this.y*=t,this.z*=t,this}multiplyVectors(t,e){return this.x=t.x*e.x,this.y=t.y*e.y,this.z=t.z*e.z,this}applyEuler(t){return this.applyQuaternion(Xc.setFromEuler(t))}applyAxisAngle(t,e){return this.applyQuaternion(Xc.setFromAxisAngle(t,e))}applyMatrix3(t){let e=this.x,n=this.y,s=this.z,r=t.elements;return this.x=r[0]*e+r[3]*n+r[6]*s,this.y=r[1]*e+r[4]*n+r[7]*s,this.z=r[2]*e+r[5]*n+r[8]*s,this}applyNormalMatrix(t){return this.applyMatrix3(t).normalize()}applyMatrix4(t){let e=this.x,n=this.y,s=this.z,r=t.elements,o=1/(r[3]*e+r[7]*n+r[11]*s+r[15]);return this.x=(r[0]*e+r[4]*n+r[8]*s+r[12])*o,this.y=(r[1]*e+r[5]*n+r[9]*s+r[13])*o,this.z=(r[2]*e+r[6]*n+r[10]*s+r[14])*o,this}applyQuaternion(t){let e=this.x,n=this.y,s=this.z,r=t.x,o=t.y,a=t.z,l=t.w,c=2*(o*s-a*n),u=2*(a*e-r*s),f=2*(r*n-o*e);return this.x=e+l*c+o*f-a*u,this.y=n+l*u+a*c-r*f,this.z=s+l*f+r*u-o*c,this}project(t){return this.applyMatrix4(t.matrixWorldInverse).applyMatrix4(t.projectionMatrix)}unproject(t){return this.applyMatrix4(t.projectionMatrixInverse).applyMatrix4(t.matrixWorld)}transformDirection(t){let e=this.x,n=this.y,s=this.z,r=t.elements;return this.x=r[0]*e+r[4]*n+r[8]*s,this.y=r[1]*e+r[5]*n+r[9]*s,this.z=r[2]*e+r[6]*n+r[10]*s,this.normalize()}divide(t){return this.x/=t.x,this.y/=t.y,this.z/=t.z,this}divideScalar(t){return this.multiplyScalar(1/t)}min(t){return this.x=Math.min(this.x,t.x),this.y=Math.min(this.y,t.y),this.z=Math.min(this.z,t.z),this}max(t){return this.x=Math.max(this.x,t.x),this.y=Math.max(this.y,t.y),this.z=Math.max(this.z,t.z),this}clamp(t,e){return this.x=Math.max(t.x,Math.min(e.x,this.x)),this.y=Math.max(t.y,Math.min(e.y,this.y)),this.z=Math.max(t.z,Math.min(e.z,this.z)),this}clampScalar(t,e){return this.x=Math.max(t,Math.min(e,this.x)),this.y=Math.max(t,Math.min(e,this.y)),this.z=Math.max(t,Math.min(e,this.z)),this}clampLength(t,e){let n=this.length();return this.divideScalar(n||1).multiplyScalar(Math.max(t,Math.min(e,n)))}floor(){return this.x=Math.floor(this.x),this.y=Math.floor(this.y),this.z=Math.floor(this.z),this}ceil(){return this.x=Math.ceil(this.x),this.y=Math.ceil(this.y),this.z=Math.ceil(this.z),this}round(){return this.x=Math.round(this.x),this.y=Math.round(this.y),this.z=Math.round(this.z),this}roundToZero(){return this.x=Math.trunc(this.x),this.y=Math.trunc(this.y),this.z=Math.trunc(this.z),this}negate(){return this.x=-this.x,this.y=-this.y,this.z=-this.z,this}dot(t){return this.x*t.x+this.y*t.y+this.z*t.z}lengthSq(){return this.x*this.x+this.y*this.y+this.z*this.z}length(){return Math.sqrt(this.x*this.x+this.y*this.y+this.z*this.z)}manhattanLength(){return Math.abs(this.x)+Math.abs(this.y)+Math.abs(this.z)}normalize(){return this.divideScalar(this.length()||1)}setLength(t){return this.normalize().multiplyScalar(t)}lerp(t,e){return this.x+=(t.x-this.x)*e,this.y+=(t.y-this.y)*e,this.z+=(t.z-this.z)*e,this}lerpVectors(t,e,n){return this.x=t.x+(e.x-t.x)*n,this.y=t.y+(e.y-t.y)*n,this.z=t.z+(e.z-t.z)*n,this}cross(t){return this.crossVectors(this,t)}crossVectors(t,e){let n=t.x,s=t.y,r=t.z,o=e.x,a=e.y,l=e.z;return this.x=s*l-r*a,this.y=r*o-n*l,this.z=n*a-s*o,this}projectOnVector(t){let e=t.lengthSq();if(e===0)return this.set(0,0,0);let n=t.dot(this)/e;return this.copy(t).multiplyScalar(n)}projectOnPlane(t){return _o.copy(this).projectOnVector(t),this.sub(_o)}reflect(t){return this.sub(_o.copy(t).multiplyScalar(2*this.dot(t)))}angleTo(t){let e=Math.sqrt(this.lengthSq()*t.lengthSq());if(e===0)return Math.PI/2;let n=this.dot(t)/e;return Math.acos(tn(n,-1,1))}distanceTo(t){return Math.sqrt(this.distanceToSquared(t))}distanceToSquared(t){let e=this.x-t.x,n=this.y-t.y,s=this.z-t.z;return e*e+n*n+s*s}manhattanDistanceTo(t){return Math.abs(this.x-t.x)+Math.abs(this.y-t.y)+Math.abs(this.z-t.z)}setFromSpherical(t){return this.setFromSphericalCoords(t.radius,t.phi,t.theta)}setFromSphericalCoords(t,e,n){let s=Math.sin(e)*t;return this.x=s*Math.sin(n),this.y=Math.cos(e)*t,this.z=s*Math.cos(n),this}setFromCylindrical(t){return this.setFromCylindricalCoords(t.radius,t.theta,t.y)}setFromCylindricalCoords(t,e,n){return this.x=t*Math.sin(e),this.y=n,this.z=t*Math.cos(e),this}setFromMatrixPosition(t){let e=t.elements;return this.x=e[12],this.y=e[13],this.z=e[14],this}setFromMatrixScale(t){let e=this.setFromMatrixColumn(t,0).length(),n=this.setFromMatrixColumn(t,1).length(),s=this.setFromMatrixColumn(t,2).length();return this.x=e,this.y=n,this.z=s,this}setFromMatrixColumn(t,e){return this.fromArray(t.elements,e*4)}setFromMatrix3Column(t,e){return this.fromArray(t.elements,e*3)}setFromEuler(t){return this.x=t._x,this.y=t._y,this.z=t._z,this}setFromColor(t){return this.x=t.r,this.y=t.g,this.z=t.b,this}equals(t){return t.x===this.x&&t.y===this.y&&t.z===this.z}fromArray(t,e=0){return this.x=t[e],this.y=t[e+1],this.z=t[e+2],this}toArray(t=[],e=0){return t[e]=this.x,t[e+1]=this.y,t[e+2]=this.z,t}fromBufferAttribute(t,e){return this.x=t.getX(e),this.y=t.getY(e),this.z=t.getZ(e),this}random(){return this.x=Math.random(),this.y=Math.random(),this.z=Math.random(),this}randomDirection(){let t=(Math.random()-.5)*2,e=Math.random()*Math.PI*2,n=Math.sqrt(1-t**2);return this.x=n*Math.cos(e),this.y=n*Math.sin(e),this.z=t,this}*[Symbol.iterator](){yield this.x,yield this.y,yield this.z}},_o=new F,Xc=new Nn,ri=class{constructor(t=new F(1/0,1/0,1/0),e=new F(-1/0,-1/0,-1/0)){this.isBox3=!0,this.min=t,this.max=e}set(t,e){return this.min.copy(t),this.max.copy(e),this}setFromArray(t){this.makeEmpty();for(let e=0,n=t.length;e<n;e+=3)this.expandByPoint(Cn.fromArray(t,e));return this}setFromBufferAttribute(t){this.makeEmpty();for(let e=0,n=t.count;e<n;e++)this.expandByPoint(Cn.fromBufferAttribute(t,e));return this}setFromPoints(t){this.makeEmpty();for(let e=0,n=t.length;e<n;e++)this.expandByPoint(t[e]);return this}setFromCenterAndSize(t,e){let n=Cn.copy(e).multiplyScalar(.5);return this.min.copy(t).sub(n),this.max.copy(t).add(n),this}setFromObject(t,e=!1){return this.makeEmpty(),this.expandByObject(t,e)}clone(){return new this.constructor().copy(this)}copy(t){return this.min.copy(t.min),this.max.copy(t.max),this}makeEmpty(){return this.min.x=this.min.y=this.min.z=1/0,this.max.x=this.max.y=this.max.z=-1/0,this}isEmpty(){return this.max.x<this.min.x||this.max.y<this.min.y||this.max.z<this.min.z}getCenter(t){return this.isEmpty()?t.set(0,0,0):t.addVectors(this.min,this.max).multiplyScalar(.5)}getSize(t){return this.isEmpty()?t.set(0,0,0):t.subVectors(this.max,this.min)}expandByPoint(t){return this.min.min(t),this.max.max(t),this}expandByVector(t){return this.min.sub(t),this.max.add(t),this}expandByScalar(t){return this.min.addScalar(-t),this.max.addScalar(t),this}expandByObject(t,e=!1){t.updateWorldMatrix(!1,!1);let n=t.geometry;if(n!==void 0){let r=n.getAttribute("position");if(e===!0&&r!==void 0&&t.isInstancedMesh!==!0)for(let o=0,a=r.count;o<a;o++)t.isMesh===!0?t.getVertexPosition(o,Cn):Cn.fromBufferAttribute(r,o),Cn.applyMatrix4(t.matrixWorld),this.expandByPoint(Cn);else t.boundingBox!==void 0?(t.boundingBox===null&&t.computeBoundingBox(),Dr.copy(t.boundingBox)):(n.boundingBox===null&&n.computeBoundingBox(),Dr.copy(n.boundingBox)),Dr.applyMatrix4(t.matrixWorld),this.union(Dr)}let s=t.children;for(let r=0,o=s.length;r<o;r++)this.expandByObject(s[r],e);return this}containsPoint(t){return!(t.x<this.min.x||t.x>this.max.x||t.y<this.min.y||t.y>this.max.y||t.z<this.min.z||t.z>this.max.z)}containsBox(t){return this.min.x<=t.min.x&&t.max.x<=this.max.x&&this.min.y<=t.min.y&&t.max.y<=this.max.y&&this.min.z<=t.min.z&&t.max.z<=this.max.z}getParameter(t,e){return e.set((t.x-this.min.x)/(this.max.x-this.min.x),(t.y-this.min.y)/(this.max.y-this.min.y),(t.z-this.min.z)/(this.max.z-this.min.z))}intersectsBox(t){return!(t.max.x<this.min.x||t.min.x>this.max.x||t.max.y<this.min.y||t.min.y>this.max.y||t.max.z<this.min.z||t.min.z>this.max.z)}intersectsSphere(t){return this.clampPoint(t.center,Cn),Cn.distanceToSquared(t.center)<=t.radius*t.radius}intersectsPlane(t){let e,n;return t.normal.x>0?(e=t.normal.x*this.min.x,n=t.normal.x*this.max.x):(e=t.normal.x*this.max.x,n=t.normal.x*this.min.x),t.normal.y>0?(e+=t.normal.y*this.min.y,n+=t.normal.y*this.max.y):(e+=t.normal.y*this.max.y,n+=t.normal.y*this.min.y),t.normal.z>0?(e+=t.normal.z*this.min.z,n+=t.normal.z*this.max.z):(e+=t.normal.z*this.max.z,n+=t.normal.z*this.min.z),e<=-t.constant&&n>=-t.constant}intersectsTriangle(t){if(this.isEmpty())return!1;this.getCenter(js),Ur.subVectors(this.max,js),ls.subVectors(t.a,js),cs.subVectors(t.b,js),hs.subVectors(t.c,js),ui.subVectors(cs,ls),di.subVectors(hs,cs),Ni.subVectors(ls,hs);let e=[0,-ui.z,ui.y,0,-di.z,di.y,0,-Ni.z,Ni.y,ui.z,0,-ui.x,di.z,0,-di.x,Ni.z,0,-Ni.x,-ui.y,ui.x,0,-di.y,di.x,0,-Ni.y,Ni.x,0];return!vo(e,ls,cs,hs,Ur)||(e=[1,0,0,0,1,0,0,0,1],!vo(e,ls,cs,hs,Ur))?!1:(Nr.crossVectors(ui,di),e=[Nr.x,Nr.y,Nr.z],vo(e,ls,cs,hs,Ur))}clampPoint(t,e){return e.copy(t).clamp(this.min,this.max)}distanceToPoint(t){return this.clampPoint(t,Cn).distanceTo(t)}getBoundingSphere(t){return this.isEmpty()?t.makeEmpty():(this.getCenter(t.center),t.radius=this.getSize(Cn).length()*.5),t}intersect(t){return this.min.max(t.min),this.max.min(t.max),this.isEmpty()&&this.makeEmpty(),this}union(t){return this.min.min(t.min),this.max.max(t.max),this}applyMatrix4(t){return this.isEmpty()?this:($n[0].set(this.min.x,this.min.y,this.min.z).applyMatrix4(t),$n[1].set(this.min.x,this.min.y,this.max.z).applyMatrix4(t),$n[2].set(this.min.x,this.max.y,this.min.z).applyMatrix4(t),$n[3].set(this.min.x,this.max.y,this.max.z).applyMatrix4(t),$n[4].set(this.max.x,this.min.y,this.min.z).applyMatrix4(t),$n[5].set(this.max.x,this.min.y,this.max.z).applyMatrix4(t),$n[6].set(this.max.x,this.max.y,this.min.z).applyMatrix4(t),$n[7].set(this.max.x,this.max.y,this.max.z).applyMatrix4(t),this.setFromPoints($n),this)}translate(t){return this.min.add(t),this.max.add(t),this}equals(t){return t.min.equals(this.min)&&t.max.equals(this.max)}},$n=[new F,new F,new F,new F,new F,new F,new F,new F],Cn=new F,Dr=new ri,ls=new F,cs=new F,hs=new F,ui=new F,di=new F,Ni=new F,js=new F,Ur=new F,Nr=new F,Oi=new F;function vo(i,t,e,n,s){for(let r=0,o=i.length-3;r<=o;r+=3){Oi.fromArray(i,r);let a=s.x*Math.abs(Oi.x)+s.y*Math.abs(Oi.y)+s.z*Math.abs(Oi.z),l=t.dot(Oi),c=e.dot(Oi),u=n.dot(Oi);if(Math.max(-Math.max(l,c,u),Math.min(l,c,u))>a)return!1}return!0}var zd=new ri,Ks=new F,yo=new F,bi=class{constructor(t=new F,e=-1){this.isSphere=!0,this.center=t,this.radius=e}set(t,e){return this.center.copy(t),this.radius=e,this}setFromPoints(t,e){let n=this.center;e!==void 0?n.copy(e):zd.setFromPoints(t).getCenter(n);let s=0;for(let r=0,o=t.length;r<o;r++)s=Math.max(s,n.distanceToSquared(t[r]));return this.radius=Math.sqrt(s),this}copy(t){return this.center.copy(t.center),this.radius=t.radius,this}isEmpty(){return this.radius<0}makeEmpty(){return this.center.set(0,0,0),this.radius=-1,this}containsPoint(t){return t.distanceToSquared(this.center)<=this.radius*this.radius}distanceToPoint(t){return t.distanceTo(this.center)-this.radius}intersectsSphere(t){let e=this.radius+t.radius;return t.center.distanceToSquared(this.center)<=e*e}intersectsBox(t){return t.intersectsSphere(this)}intersectsPlane(t){return Math.abs(t.distanceToPoint(this.center))<=this.radius}clampPoint(t,e){let n=this.center.distanceToSquared(t);return e.copy(t),n>this.radius*this.radius&&(e.sub(this.center).normalize(),e.multiplyScalar(this.radius).add(this.center)),e}getBoundingBox(t){return this.isEmpty()?(t.makeEmpty(),t):(t.set(this.center,this.center),t.expandByScalar(this.radius),t)}applyMatrix4(t){return this.center.applyMatrix4(t),this.radius=this.radius*t.getMaxScaleOnAxis(),this}translate(t){return this.center.add(t),this}expandByPoint(t){if(this.isEmpty())return this.center.copy(t),this.radius=0,this;Ks.subVectors(t,this.center);let e=Ks.lengthSq();if(e>this.radius*this.radius){let n=Math.sqrt(e),s=(n-this.radius)*.5;this.center.addScaledVector(Ks,s/n),this.radius+=s}return this}union(t){return t.isEmpty()?this:this.isEmpty()?(this.copy(t),this):(this.center.equals(t.center)===!0?this.radius=Math.max(this.radius,t.radius):(yo.subVectors(t.center,this.center).setLength(t.radius),this.expandByPoint(Ks.copy(t.center).add(yo)),this.expandByPoint(Ks.copy(t.center).sub(yo))),this)}equals(t){return t.center.equals(this.center)&&t.radius===this.radius}clone(){return new this.constructor().copy(this)}},jn=new F,Mo=new F,Or=new F,fi=new F,bo=new F,Fr=new F,So=new F,Xi=class{constructor(t=new F,e=new F(0,0,-1)){this.origin=t,this.direction=e}set(t,e){return this.origin.copy(t),this.direction.copy(e),this}copy(t){return this.origin.copy(t.origin),this.direction.copy(t.direction),this}at(t,e){return e.copy(this.origin).addScaledVector(this.direction,t)}lookAt(t){return this.direction.copy(t).sub(this.origin).normalize(),this}recast(t){return this.origin.copy(this.at(t,jn)),this}closestPointToPoint(t,e){e.subVectors(t,this.origin);let n=e.dot(this.direction);return n<0?e.copy(this.origin):e.copy(this.origin).addScaledVector(this.direction,n)}distanceToPoint(t){return Math.sqrt(this.distanceSqToPoint(t))}distanceSqToPoint(t){let e=jn.subVectors(t,this.origin).dot(this.direction);return e<0?this.origin.distanceToSquared(t):(jn.copy(this.origin).addScaledVector(this.direction,e),jn.distanceToSquared(t))}distanceSqToSegment(t,e,n,s){Mo.copy(t).add(e).multiplyScalar(.5),Or.copy(e).sub(t).normalize(),fi.copy(this.origin).sub(Mo);let r=t.distanceTo(e)*.5,o=-this.direction.dot(Or),a=fi.dot(this.direction),l=-fi.dot(Or),c=fi.lengthSq(),u=Math.abs(1-o*o),f,p,x,y;if(u>0)if(f=o*l-a,p=o*a-l,y=r*u,f>=0)if(p>=-y)if(p<=y){let b=1/u;f*=b,p*=b,x=f*(f+o*p+2*a)+p*(o*f+p+2*l)+c}else p=r,f=Math.max(0,-(o*p+a)),x=-f*f+p*(p+2*l)+c;else p=-r,f=Math.max(0,-(o*p+a)),x=-f*f+p*(p+2*l)+c;else p<=-y?(f=Math.max(0,-(-o*r+a)),p=f>0?-r:Math.min(Math.max(-r,-l),r),x=-f*f+p*(p+2*l)+c):p<=y?(f=0,p=Math.min(Math.max(-r,-l),r),x=p*(p+2*l)+c):(f=Math.max(0,-(o*r+a)),p=f>0?r:Math.min(Math.max(-r,-l),r),x=-f*f+p*(p+2*l)+c);else p=o>0?-r:r,f=Math.max(0,-(o*p+a)),x=-f*f+p*(p+2*l)+c;return n&&n.copy(this.origin).addScaledVector(this.direction,f),s&&s.copy(Mo).addScaledVector(Or,p),x}intersectSphere(t,e){jn.subVectors(t.center,this.origin);let n=jn.dot(this.direction),s=jn.dot(jn)-n*n,r=t.radius*t.radius;if(s>r)return null;let o=Math.sqrt(r-s),a=n-o,l=n+o;return l<0?null:a<0?this.at(l,e):this.at(a,e)}intersectsSphere(t){return this.distanceSqToPoint(t.center)<=t.radius*t.radius}distanceToPlane(t){let e=t.normal.dot(this.direction);if(e===0)return t.distanceToPoint(this.origin)===0?0:null;let n=-(this.origin.dot(t.normal)+t.constant)/e;return n>=0?n:null}intersectPlane(t,e){let n=this.distanceToPlane(t);return n===null?null:this.at(n,e)}intersectsPlane(t){let e=t.distanceToPoint(this.origin);return e===0||t.normal.dot(this.direction)*e<0}intersectBox(t,e){let n,s,r,o,a,l,c=1/this.direction.x,u=1/this.direction.y,f=1/this.direction.z,p=this.origin;return c>=0?(n=(t.min.x-p.x)*c,s=(t.max.x-p.x)*c):(n=(t.max.x-p.x)*c,s=(t.min.x-p.x)*c),u>=0?(r=(t.min.y-p.y)*u,o=(t.max.y-p.y)*u):(r=(t.max.y-p.y)*u,o=(t.min.y-p.y)*u),n>o||r>s||((r>n||isNaN(n))&&(n=r),(o<s||isNaN(s))&&(s=o),f>=0?(a=(t.min.z-p.z)*f,l=(t.max.z-p.z)*f):(a=(t.max.z-p.z)*f,l=(t.min.z-p.z)*f),n>l||a>s)||((a>n||n!==n)&&(n=a),(l<s||s!==s)&&(s=l),s<0)?null:this.at(n>=0?n:s,e)}intersectsBox(t){return this.intersectBox(t,jn)!==null}intersectTriangle(t,e,n,s,r){bo.subVectors(e,t),Fr.subVectors(n,t),So.crossVectors(bo,Fr);let o=this.direction.dot(So),a;if(o>0){if(s)return null;a=1}else if(o<0)a=-1,o=-o;else return null;fi.subVectors(this.origin,t);let l=a*this.direction.dot(Fr.crossVectors(fi,Fr));if(l<0)return null;let c=a*this.direction.dot(bo.cross(fi));if(c<0||l+c>o)return null;let u=-a*fi.dot(So);return u<0?null:this.at(u/o,r)}applyMatrix4(t){return this.origin.applyMatrix4(t),this.direction.transformDirection(t),this}equals(t){return t.origin.equals(this.origin)&&t.direction.equals(this.direction)}clone(){return new this.constructor().copy(this)}},ve=class i{constructor(t,e,n,s,r,o,a,l,c,u,f,p,x,y,b,m){i.prototype.isMatrix4=!0,this.elements=[1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1],t!==void 0&&this.set(t,e,n,s,r,o,a,l,c,u,f,p,x,y,b,m)}set(t,e,n,s,r,o,a,l,c,u,f,p,x,y,b,m){let d=this.elements;return d[0]=t,d[4]=e,d[8]=n,d[12]=s,d[1]=r,d[5]=o,d[9]=a,d[13]=l,d[2]=c,d[6]=u,d[10]=f,d[14]=p,d[3]=x,d[7]=y,d[11]=b,d[15]=m,this}identity(){return this.set(1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1),this}clone(){return new i().fromArray(this.elements)}copy(t){let e=this.elements,n=t.elements;return e[0]=n[0],e[1]=n[1],e[2]=n[2],e[3]=n[3],e[4]=n[4],e[5]=n[5],e[6]=n[6],e[7]=n[7],e[8]=n[8],e[9]=n[9],e[10]=n[10],e[11]=n[11],e[12]=n[12],e[13]=n[13],e[14]=n[14],e[15]=n[15],this}copyPosition(t){let e=this.elements,n=t.elements;return e[12]=n[12],e[13]=n[13],e[14]=n[14],this}setFromMatrix3(t){let e=t.elements;return this.set(e[0],e[3],e[6],0,e[1],e[4],e[7],0,e[2],e[5],e[8],0,0,0,0,1),this}extractBasis(t,e,n){return t.setFromMatrixColumn(this,0),e.setFromMatrixColumn(this,1),n.setFromMatrixColumn(this,2),this}makeBasis(t,e,n){return this.set(t.x,e.x,n.x,0,t.y,e.y,n.y,0,t.z,e.z,n.z,0,0,0,0,1),this}extractRotation(t){let e=this.elements,n=t.elements,s=1/us.setFromMatrixColumn(t,0).length(),r=1/us.setFromMatrixColumn(t,1).length(),o=1/us.setFromMatrixColumn(t,2).length();return e[0]=n[0]*s,e[1]=n[1]*s,e[2]=n[2]*s,e[3]=0,e[4]=n[4]*r,e[5]=n[5]*r,e[6]=n[6]*r,e[7]=0,e[8]=n[8]*o,e[9]=n[9]*o,e[10]=n[10]*o,e[11]=0,e[12]=0,e[13]=0,e[14]=0,e[15]=1,this}makeRotationFromEuler(t){let e=this.elements,n=t.x,s=t.y,r=t.z,o=Math.cos(n),a=Math.sin(n),l=Math.cos(s),c=Math.sin(s),u=Math.cos(r),f=Math.sin(r);if(t.order==="XYZ"){let p=o*u,x=o*f,y=a*u,b=a*f;e[0]=l*u,e[4]=-l*f,e[8]=c,e[1]=x+y*c,e[5]=p-b*c,e[9]=-a*l,e[2]=b-p*c,e[6]=y+x*c,e[10]=o*l}else if(t.order==="YXZ"){let p=l*u,x=l*f,y=c*u,b=c*f;e[0]=p+b*a,e[4]=y*a-x,e[8]=o*c,e[1]=o*f,e[5]=o*u,e[9]=-a,e[2]=x*a-y,e[6]=b+p*a,e[10]=o*l}else if(t.order==="ZXY"){let p=l*u,x=l*f,y=c*u,b=c*f;e[0]=p-b*a,e[4]=-o*f,e[8]=y+x*a,e[1]=x+y*a,e[5]=o*u,e[9]=b-p*a,e[2]=-o*c,e[6]=a,e[10]=o*l}else if(t.order==="ZYX"){let p=o*u,x=o*f,y=a*u,b=a*f;e[0]=l*u,e[4]=y*c-x,e[8]=p*c+b,e[1]=l*f,e[5]=b*c+p,e[9]=x*c-y,e[2]=-c,e[6]=a*l,e[10]=o*l}else if(t.order==="YZX"){let p=o*l,x=o*c,y=a*l,b=a*c;e[0]=l*u,e[4]=b-p*f,e[8]=y*f+x,e[1]=f,e[5]=o*u,e[9]=-a*u,e[2]=-c*u,e[6]=x*f+y,e[10]=p-b*f}else if(t.order==="XZY"){let p=o*l,x=o*c,y=a*l,b=a*c;e[0]=l*u,e[4]=-f,e[8]=c*u,e[1]=p*f+b,e[5]=o*u,e[9]=x*f-y,e[2]=y*f-x,e[6]=a*u,e[10]=b*f+p}return e[3]=0,e[7]=0,e[11]=0,e[12]=0,e[13]=0,e[14]=0,e[15]=1,this}makeRotationFromQuaternion(t){return this.compose(kd,t,Hd)}lookAt(t,e,n){let s=this.elements;return fn.subVectors(t,e),fn.lengthSq()===0&&(fn.z=1),fn.normalize(),pi.crossVectors(n,fn),pi.lengthSq()===0&&(Math.abs(n.z)===1?fn.x+=1e-4:fn.z+=1e-4,fn.normalize(),pi.crossVectors(n,fn)),pi.normalize(),Br.crossVectors(fn,pi),s[0]=pi.x,s[4]=Br.x,s[8]=fn.x,s[1]=pi.y,s[5]=Br.y,s[9]=fn.y,s[2]=pi.z,s[6]=Br.z,s[10]=fn.z,this}multiply(t){return this.multiplyMatrices(this,t)}premultiply(t){return this.multiplyMatrices(t,this)}multiplyMatrices(t,e){let n=t.elements,s=e.elements,r=this.elements,o=n[0],a=n[4],l=n[8],c=n[12],u=n[1],f=n[5],p=n[9],x=n[13],y=n[2],b=n[6],m=n[10],d=n[14],C=n[3],w=n[7],U=n[11],z=n[15],N=s[0],L=s[4],j=s[8],S=s[12],R=s[1],V=s[5],tt=s[9],ft=s[13],I=s[2],k=s[6],G=s[10],K=s[14],Q=s[3],$=s[7],nt=s[11],ct=s[15];return r[0]=o*N+a*R+l*I+c*Q,r[4]=o*L+a*V+l*k+c*$,r[8]=o*j+a*tt+l*G+c*nt,r[12]=o*S+a*ft+l*K+c*ct,r[1]=u*N+f*R+p*I+x*Q,r[5]=u*L+f*V+p*k+x*$,r[9]=u*j+f*tt+p*G+x*nt,r[13]=u*S+f*ft+p*K+x*ct,r[2]=y*N+b*R+m*I+d*Q,r[6]=y*L+b*V+m*k+d*$,r[10]=y*j+b*tt+m*G+d*nt,r[14]=y*S+b*ft+m*K+d*ct,r[3]=C*N+w*R+U*I+z*Q,r[7]=C*L+w*V+U*k+z*$,r[11]=C*j+w*tt+U*G+z*nt,r[15]=C*S+w*ft+U*K+z*ct,this}multiplyScalar(t){let e=this.elements;return e[0]*=t,e[4]*=t,e[8]*=t,e[12]*=t,e[1]*=t,e[5]*=t,e[9]*=t,e[13]*=t,e[2]*=t,e[6]*=t,e[10]*=t,e[14]*=t,e[3]*=t,e[7]*=t,e[11]*=t,e[15]*=t,this}determinant(){let t=this.elements,e=t[0],n=t[4],s=t[8],r=t[12],o=t[1],a=t[5],l=t[9],c=t[13],u=t[2],f=t[6],p=t[10],x=t[14],y=t[3],b=t[7],m=t[11],d=t[15];return y*(+r*l*f-s*c*f-r*a*p+n*c*p+s*a*x-n*l*x)+b*(+e*l*x-e*c*p+r*o*p-s*o*x+s*c*u-r*l*u)+m*(+e*c*f-e*a*x-r*o*f+n*o*x+r*a*u-n*c*u)+d*(-s*a*u-e*l*f+e*a*p+s*o*f-n*o*p+n*l*u)}transpose(){let t=this.elements,e;return e=t[1],t[1]=t[4],t[4]=e,e=t[2],t[2]=t[8],t[8]=e,e=t[6],t[6]=t[9],t[9]=e,e=t[3],t[3]=t[12],t[12]=e,e=t[7],t[7]=t[13],t[13]=e,e=t[11],t[11]=t[14],t[14]=e,this}setPosition(t,e,n){let s=this.elements;return t.isVector3?(s[12]=t.x,s[13]=t.y,s[14]=t.z):(s[12]=t,s[13]=e,s[14]=n),this}invert(){let t=this.elements,e=t[0],n=t[1],s=t[2],r=t[3],o=t[4],a=t[5],l=t[6],c=t[7],u=t[8],f=t[9],p=t[10],x=t[11],y=t[12],b=t[13],m=t[14],d=t[15],C=f*m*c-b*p*c+b*l*x-a*m*x-f*l*d+a*p*d,w=y*p*c-u*m*c-y*l*x+o*m*x+u*l*d-o*p*d,U=u*b*c-y*f*c+y*a*x-o*b*x-u*a*d+o*f*d,z=y*f*l-u*b*l-y*a*p+o*b*p+u*a*m-o*f*m,N=e*C+n*w+s*U+r*z;if(N===0)return this.set(0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0);let L=1/N;return t[0]=C*L,t[1]=(b*p*r-f*m*r-b*s*x+n*m*x+f*s*d-n*p*d)*L,t[2]=(a*m*r-b*l*r+b*s*c-n*m*c-a*s*d+n*l*d)*L,t[3]=(f*l*r-a*p*r-f*s*c+n*p*c+a*s*x-n*l*x)*L,t[4]=w*L,t[5]=(u*m*r-y*p*r+y*s*x-e*m*x-u*s*d+e*p*d)*L,t[6]=(y*l*r-o*m*r-y*s*c+e*m*c+o*s*d-e*l*d)*L,t[7]=(o*p*r-u*l*r+u*s*c-e*p*c-o*s*x+e*l*x)*L,t[8]=U*L,t[9]=(y*f*r-u*b*r-y*n*x+e*b*x+u*n*d-e*f*d)*L,t[10]=(o*b*r-y*a*r+y*n*c-e*b*c-o*n*d+e*a*d)*L,t[11]=(u*a*r-o*f*r-u*n*c+e*f*c+o*n*x-e*a*x)*L,t[12]=z*L,t[13]=(u*b*s-y*f*s+y*n*p-e*b*p-u*n*m+e*f*m)*L,t[14]=(y*a*s-o*b*s-y*n*l+e*b*l+o*n*m-e*a*m)*L,t[15]=(o*f*s-u*a*s+u*n*l-e*f*l-o*n*p+e*a*p)*L,this}scale(t){let e=this.elements,n=t.x,s=t.y,r=t.z;return e[0]*=n,e[4]*=s,e[8]*=r,e[1]*=n,e[5]*=s,e[9]*=r,e[2]*=n,e[6]*=s,e[10]*=r,e[3]*=n,e[7]*=s,e[11]*=r,this}getMaxScaleOnAxis(){let t=this.elements,e=t[0]*t[0]+t[1]*t[1]+t[2]*t[2],n=t[4]*t[4]+t[5]*t[5]+t[6]*t[6],s=t[8]*t[8]+t[9]*t[9]+t[10]*t[10];return Math.sqrt(Math.max(e,n,s))}makeTranslation(t,e,n){return t.isVector3?this.set(1,0,0,t.x,0,1,0,t.y,0,0,1,t.z,0,0,0,1):this.set(1,0,0,t,0,1,0,e,0,0,1,n,0,0,0,1),this}makeRotationX(t){let e=Math.cos(t),n=Math.sin(t);return this.set(1,0,0,0,0,e,-n,0,0,n,e,0,0,0,0,1),this}makeRotationY(t){let e=Math.cos(t),n=Math.sin(t);return this.set(e,0,n,0,0,1,0,0,-n,0,e,0,0,0,0,1),this}makeRotationZ(t){let e=Math.cos(t),n=Math.sin(t);return this.set(e,-n,0,0,n,e,0,0,0,0,1,0,0,0,0,1),this}makeRotationAxis(t,e){let n=Math.cos(e),s=Math.sin(e),r=1-n,o=t.x,a=t.y,l=t.z,c=r*o,u=r*a;return this.set(c*o+n,c*a-s*l,c*l+s*a,0,c*a+s*l,u*a+n,u*l-s*o,0,c*l-s*a,u*l+s*o,r*l*l+n,0,0,0,0,1),this}makeScale(t,e,n){return this.set(t,0,0,0,0,e,0,0,0,0,n,0,0,0,0,1),this}makeShear(t,e,n,s,r,o){return this.set(1,n,r,0,t,1,o,0,e,s,1,0,0,0,0,1),this}compose(t,e,n){let s=this.elements,r=e._x,o=e._y,a=e._z,l=e._w,c=r+r,u=o+o,f=a+a,p=r*c,x=r*u,y=r*f,b=o*u,m=o*f,d=a*f,C=l*c,w=l*u,U=l*f,z=n.x,N=n.y,L=n.z;return s[0]=(1-(b+d))*z,s[1]=(x+U)*z,s[2]=(y-w)*z,s[3]=0,s[4]=(x-U)*N,s[5]=(1-(p+d))*N,s[6]=(m+C)*N,s[7]=0,s[8]=(y+w)*L,s[9]=(m-C)*L,s[10]=(1-(p+b))*L,s[11]=0,s[12]=t.x,s[13]=t.y,s[14]=t.z,s[15]=1,this}decompose(t,e,n){let s=this.elements,r=us.set(s[0],s[1],s[2]).length(),o=us.set(s[4],s[5],s[6]).length(),a=us.set(s[8],s[9],s[10]).length();this.determinant()<0&&(r=-r),t.x=s[12],t.y=s[13],t.z=s[14],Rn.copy(this);let c=1/r,u=1/o,f=1/a;return Rn.elements[0]*=c,Rn.elements[1]*=c,Rn.elements[2]*=c,Rn.elements[4]*=u,Rn.elements[5]*=u,Rn.elements[6]*=u,Rn.elements[8]*=f,Rn.elements[9]*=f,Rn.elements[10]*=f,e.setFromRotationMatrix(Rn),n.x=r,n.y=o,n.z=a,this}makePerspective(t,e,n,s,r,o,a=ni){let l=this.elements,c=2*r/(e-t),u=2*r/(n-s),f=(e+t)/(e-t),p=(n+s)/(n-s),x,y;if(a===ni)x=-(o+r)/(o-r),y=-2*o*r/(o-r);else if(a===ha)x=-o/(o-r),y=-o*r/(o-r);else throw new Error("THREE.Matrix4.makePerspective(): Invalid coordinate system: "+a);return l[0]=c,l[4]=0,l[8]=f,l[12]=0,l[1]=0,l[5]=u,l[9]=p,l[13]=0,l[2]=0,l[6]=0,l[10]=x,l[14]=y,l[3]=0,l[7]=0,l[11]=-1,l[15]=0,this}makeOrthographic(t,e,n,s,r,o,a=ni){let l=this.elements,c=1/(e-t),u=1/(n-s),f=1/(o-r),p=(e+t)*c,x=(n+s)*u,y,b;if(a===ni)y=(o+r)*f,b=-2*f;else if(a===ha)y=r*f,b=-1*f;else throw new Error("THREE.Matrix4.makeOrthographic(): Invalid coordinate system: "+a);return l[0]=2*c,l[4]=0,l[8]=0,l[12]=-p,l[1]=0,l[5]=2*u,l[9]=0,l[13]=-x,l[2]=0,l[6]=0,l[10]=b,l[14]=-y,l[3]=0,l[7]=0,l[11]=0,l[15]=1,this}equals(t){let e=this.elements,n=t.elements;for(let s=0;s<16;s++)if(e[s]!==n[s])return!1;return!0}fromArray(t,e=0){for(let n=0;n<16;n++)this.elements[n]=t[n+e];return this}toArray(t=[],e=0){let n=this.elements;return t[e]=n[0],t[e+1]=n[1],t[e+2]=n[2],t[e+3]=n[3],t[e+4]=n[4],t[e+5]=n[5],t[e+6]=n[6],t[e+7]=n[7],t[e+8]=n[8],t[e+9]=n[9],t[e+10]=n[10],t[e+11]=n[11],t[e+12]=n[12],t[e+13]=n[13],t[e+14]=n[14],t[e+15]=n[15],t}},us=new F,Rn=new ve,kd=new F(0,0,0),Hd=new F(1,1,1),pi=new F,Br=new F,fn=new F,Yc=new ve,qc=new Nn,ga=class i{constructor(t=0,e=0,n=0,s=i.DEFAULT_ORDER){this.isEuler=!0,this._x=t,this._y=e,this._z=n,this._order=s}get x(){return this._x}set x(t){this._x=t,this._onChangeCallback()}get y(){return this._y}set y(t){this._y=t,this._onChangeCallback()}get z(){return this._z}set z(t){this._z=t,this._onChangeCallback()}get order(){return this._order}set order(t){this._order=t,this._onChangeCallback()}set(t,e,n,s=this._order){return this._x=t,this._y=e,this._z=n,this._order=s,this._onChangeCallback(),this}clone(){return new this.constructor(this._x,this._y,this._z,this._order)}copy(t){return this._x=t._x,this._y=t._y,this._z=t._z,this._order=t._order,this._onChangeCallback(),this}setFromRotationMatrix(t,e=this._order,n=!0){let s=t.elements,r=s[0],o=s[4],a=s[8],l=s[1],c=s[5],u=s[9],f=s[2],p=s[6],x=s[10];switch(e){case"XYZ":this._y=Math.asin(tn(a,-1,1)),Math.abs(a)<.9999999?(this._x=Math.atan2(-u,x),this._z=Math.atan2(-o,r)):(this._x=Math.atan2(p,c),this._z=0);break;case"YXZ":this._x=Math.asin(-tn(u,-1,1)),Math.abs(u)<.9999999?(this._y=Math.atan2(a,x),this._z=Math.atan2(l,c)):(this._y=Math.atan2(-f,r),this._z=0);break;case"ZXY":this._x=Math.asin(tn(p,-1,1)),Math.abs(p)<.9999999?(this._y=Math.atan2(-f,x),this._z=Math.atan2(-o,c)):(this._y=0,this._z=Math.atan2(l,r));break;case"ZYX":this._y=Math.asin(-tn(f,-1,1)),Math.abs(f)<.9999999?(this._x=Math.atan2(p,x),this._z=Math.atan2(l,r)):(this._x=0,this._z=Math.atan2(-o,c));break;case"YZX":this._z=Math.asin(tn(l,-1,1)),Math.abs(l)<.9999999?(this._x=Math.atan2(-u,c),this._y=Math.atan2(-f,r)):(this._x=0,this._y=Math.atan2(a,x));break;case"XZY":this._z=Math.asin(-tn(o,-1,1)),Math.abs(o)<.9999999?(this._x=Math.atan2(p,c),this._y=Math.atan2(a,r)):(this._x=Math.atan2(-u,x),this._y=0);break;default:console.warn("THREE.Euler: .setFromRotationMatrix() encountered an unknown order: "+e)}return this._order=e,n===!0&&this._onChangeCallback(),this}setFromQuaternion(t,e,n){return Yc.makeRotationFromQuaternion(t),this.setFromRotationMatrix(Yc,e,n)}setFromVector3(t,e=this._order){return this.set(t.x,t.y,t.z,e)}reorder(t){return qc.setFromEuler(this),this.setFromQuaternion(qc,t)}equals(t){return t._x===this._x&&t._y===this._y&&t._z===this._z&&t._order===this._order}fromArray(t){return this._x=t[0],this._y=t[1],this._z=t[2],t[3]!==void 0&&(this._order=t[3]),this._onChangeCallback(),this}toArray(t=[],e=0){return t[e]=this._x,t[e+1]=this._y,t[e+2]=this._z,t[e+3]=this._order,t}_onChange(t){return this._onChangeCallback=t,this}_onChangeCallback(){}*[Symbol.iterator](){yield this._x,yield this._y,yield this._z,yield this._order}};ga.DEFAULT_ORDER="XYZ";var ur=class{constructor(){this.mask=1}set(t){this.mask=(1<<t|0)>>>0}enable(t){this.mask|=1<<t|0}enableAll(){this.mask=-1}toggle(t){this.mask^=1<<t|0}disable(t){this.mask&=~(1<<t|0)}disableAll(){this.mask=0}test(t){return(this.mask&t.mask)!==0}isEnabled(t){return(this.mask&(1<<t|0))!==0}},Vd=0,Zc=new F,ds=new Nn,Kn=new ve,zr=new F,Qs=new F,Gd=new F,Wd=new Nn,Jc=new F(1,0,0),$c=new F(0,1,0),jc=new F(0,0,1),Xd={type:"added"},Yd={type:"removed"},rn=class i extends Xn{constructor(){super(),this.isObject3D=!0,Object.defineProperty(this,"id",{value:Vd++}),this.uuid=Bs(),this.name="",this.type="Object3D",this.parent=null,this.children=[],this.up=i.DEFAULT_UP.clone();let t=new F,e=new ga,n=new Nn,s=new F(1,1,1);function r(){n.setFromEuler(e,!1)}function o(){e.setFromQuaternion(n,void 0,!1)}e._onChange(r),n._onChange(o),Object.defineProperties(this,{position:{configurable:!0,enumerable:!0,value:t},rotation:{configurable:!0,enumerable:!0,value:e},quaternion:{configurable:!0,enumerable:!0,value:n},scale:{configurable:!0,enumerable:!0,value:s},modelViewMatrix:{value:new ve},normalMatrix:{value:new re}}),this.matrix=new ve,this.matrixWorld=new ve,this.matrixAutoUpdate=i.DEFAULT_MATRIX_AUTO_UPDATE,this.matrixWorldAutoUpdate=i.DEFAULT_MATRIX_WORLD_AUTO_UPDATE,this.matrixWorldNeedsUpdate=!1,this.layers=new ur,this.visible=!0,this.castShadow=!1,this.receiveShadow=!1,this.frustumCulled=!0,this.renderOrder=0,this.animations=[],this.userData={}}onBeforeShadow(){}onAfterShadow(){}onBeforeRender(){}onAfterRender(){}applyMatrix4(t){this.matrixAutoUpdate&&this.updateMatrix(),this.matrix.premultiply(t),this.matrix.decompose(this.position,this.quaternion,this.scale)}applyQuaternion(t){return this.quaternion.premultiply(t),this}setRotationFromAxisAngle(t,e){this.quaternion.setFromAxisAngle(t,e)}setRotationFromEuler(t){this.quaternion.setFromEuler(t,!0)}setRotationFromMatrix(t){this.quaternion.setFromRotationMatrix(t)}setRotationFromQuaternion(t){this.quaternion.copy(t)}rotateOnAxis(t,e){return ds.setFromAxisAngle(t,e),this.quaternion.multiply(ds),this}rotateOnWorldAxis(t,e){return ds.setFromAxisAngle(t,e),this.quaternion.premultiply(ds),this}rotateX(t){return this.rotateOnAxis(Jc,t)}rotateY(t){return this.rotateOnAxis($c,t)}rotateZ(t){return this.rotateOnAxis(jc,t)}translateOnAxis(t,e){return Zc.copy(t).applyQuaternion(this.quaternion),this.position.add(Zc.multiplyScalar(e)),this}translateX(t){return this.translateOnAxis(Jc,t)}translateY(t){return this.translateOnAxis($c,t)}translateZ(t){return this.translateOnAxis(jc,t)}localToWorld(t){return this.updateWorldMatrix(!0,!1),t.applyMatrix4(this.matrixWorld)}worldToLocal(t){return this.updateWorldMatrix(!0,!1),t.applyMatrix4(Kn.copy(this.matrixWorld).invert())}lookAt(t,e,n){t.isVector3?zr.copy(t):zr.set(t,e,n);let s=this.parent;this.updateWorldMatrix(!0,!1),Qs.setFromMatrixPosition(this.matrixWorld),this.isCamera||this.isLight?Kn.lookAt(Qs,zr,this.up):Kn.lookAt(zr,Qs,this.up),this.quaternion.setFromRotationMatrix(Kn),s&&(Kn.extractRotation(s.matrixWorld),ds.setFromRotationMatrix(Kn),this.quaternion.premultiply(ds.invert()))}add(t){if(arguments.length>1){for(let e=0;e<arguments.length;e++)this.add(arguments[e]);return this}return t===this?(console.error("THREE.Object3D.add: object can't be added as a child of itself.",t),this):(t&&t.isObject3D?(t.parent!==null&&t.parent.remove(t),t.parent=this,this.children.push(t),t.dispatchEvent(Xd)):console.error("THREE.Object3D.add: object not an instance of THREE.Object3D.",t),this)}remove(t){if(arguments.length>1){for(let n=0;n<arguments.length;n++)this.remove(arguments[n]);return this}let e=this.children.indexOf(t);return e!==-1&&(t.parent=null,this.children.splice(e,1),t.dispatchEvent(Yd)),this}removeFromParent(){let t=this.parent;return t!==null&&t.remove(this),this}clear(){return this.remove(...this.children)}attach(t){return this.updateWorldMatrix(!0,!1),Kn.copy(this.matrixWorld).invert(),t.parent!==null&&(t.parent.updateWorldMatrix(!0,!1),Kn.multiply(t.parent.matrixWorld)),t.applyMatrix4(Kn),this.add(t),t.updateWorldMatrix(!1,!0),this}getObjectById(t){return this.getObjectByProperty("id",t)}getObjectByName(t){return this.getObjectByProperty("name",t)}getObjectByProperty(t,e){if(this[t]===e)return this;for(let n=0,s=this.children.length;n<s;n++){let o=this.children[n].getObjectByProperty(t,e);if(o!==void 0)return o}}getObjectsByProperty(t,e,n=[]){this[t]===e&&n.push(this);let s=this.children;for(let r=0,o=s.length;r<o;r++)s[r].getObjectsByProperty(t,e,n);return n}getWorldPosition(t){return this.updateWorldMatrix(!0,!1),t.setFromMatrixPosition(this.matrixWorld)}getWorldQuaternion(t){return this.updateWorldMatrix(!0,!1),this.matrixWorld.decompose(Qs,t,Gd),t}getWorldScale(t){return this.updateWorldMatrix(!0,!1),this.matrixWorld.decompose(Qs,Wd,t),t}getWorldDirection(t){this.updateWorldMatrix(!0,!1);let e=this.matrixWorld.elements;return t.set(e[8],e[9],e[10]).normalize()}raycast(){}traverse(t){t(this);let e=this.children;for(let n=0,s=e.length;n<s;n++)e[n].traverse(t)}traverseVisible(t){if(this.visible===!1)return;t(this);let e=this.children;for(let n=0,s=e.length;n<s;n++)e[n].traverseVisible(t)}traverseAncestors(t){let e=this.parent;e!==null&&(t(e),e.traverseAncestors(t))}updateMatrix(){this.matrix.compose(this.position,this.quaternion,this.scale),this.matrixWorldNeedsUpdate=!0}updateMatrixWorld(t){this.matrixAutoUpdate&&this.updateMatrix(),(this.matrixWorldNeedsUpdate||t)&&(this.parent===null?this.matrixWorld.copy(this.matrix):this.matrixWorld.multiplyMatrices(this.parent.matrixWorld,this.matrix),this.matrixWorldNeedsUpdate=!1,t=!0);let e=this.children;for(let n=0,s=e.length;n<s;n++){let r=e[n];(r.matrixWorldAutoUpdate===!0||t===!0)&&r.updateMatrixWorld(t)}}updateWorldMatrix(t,e){let n=this.parent;if(t===!0&&n!==null&&n.matrixWorldAutoUpdate===!0&&n.updateWorldMatrix(!0,!1),this.matrixAutoUpdate&&this.updateMatrix(),this.parent===null?this.matrixWorld.copy(this.matrix):this.matrixWorld.multiplyMatrices(this.parent.matrixWorld,this.matrix),e===!0){let s=this.children;for(let r=0,o=s.length;r<o;r++){let a=s[r];a.matrixWorldAutoUpdate===!0&&a.updateWorldMatrix(!1,!0)}}}toJSON(t){let e=t===void 0||typeof t=="string",n={};e&&(t={geometries:{},materials:{},textures:{},images:{},shapes:{},skeletons:{},animations:{},nodes:{}},n.metadata={version:4.6,type:"Object",generator:"Object3D.toJSON"});let s={};s.uuid=this.uuid,s.type=this.type,this.name!==""&&(s.name=this.name),this.castShadow===!0&&(s.castShadow=!0),this.receiveShadow===!0&&(s.receiveShadow=!0),this.visible===!1&&(s.visible=!1),this.frustumCulled===!1&&(s.frustumCulled=!1),this.renderOrder!==0&&(s.renderOrder=this.renderOrder),Object.keys(this.userData).length>0&&(s.userData=this.userData),s.layers=this.layers.mask,s.matrix=this.matrix.toArray(),s.up=this.up.toArray(),this.matrixAutoUpdate===!1&&(s.matrixAutoUpdate=!1),this.isInstancedMesh&&(s.type="InstancedMesh",s.count=this.count,s.instanceMatrix=this.instanceMatrix.toJSON(),this.instanceColor!==null&&(s.instanceColor=this.instanceColor.toJSON())),this.isBatchedMesh&&(s.type="BatchedMesh",s.perObjectFrustumCulled=this.perObjectFrustumCulled,s.sortObjects=this.sortObjects,s.drawRanges=this._drawRanges,s.reservedRanges=this._reservedRanges,s.visibility=this._visibility,s.active=this._active,s.bounds=this._bounds.map(a=>({boxInitialized:a.boxInitialized,boxMin:a.box.min.toArray(),boxMax:a.box.max.toArray(),sphereInitialized:a.sphereInitialized,sphereRadius:a.sphere.radius,sphereCenter:a.sphere.center.toArray()})),s.maxGeometryCount=this._maxGeometryCount,s.maxVertexCount=this._maxVertexCount,s.maxIndexCount=this._maxIndexCount,s.geometryInitialized=this._geometryInitialized,s.geometryCount=this._geometryCount,s.matricesTexture=this._matricesTexture.toJSON(t),this.boundingSphere!==null&&(s.boundingSphere={center:s.boundingSphere.center.toArray(),radius:s.boundingSphere.radius}),this.boundingBox!==null&&(s.boundingBox={min:s.boundingBox.min.toArray(),max:s.boundingBox.max.toArray()}));function r(a,l){return a[l.uuid]===void 0&&(a[l.uuid]=l.toJSON(t)),l.uuid}if(this.isScene)this.background&&(this.background.isColor?s.background=this.background.toJSON():this.background.isTexture&&(s.background=this.background.toJSON(t).uuid)),this.environment&&this.environment.isTexture&&this.environment.isRenderTargetTexture!==!0&&(s.environment=this.environment.toJSON(t).uuid);else if(this.isMesh||this.isLine||this.isPoints){s.geometry=r(t.geometries,this.geometry);let a=this.geometry.parameters;if(a!==void 0&&a.shapes!==void 0){let l=a.shapes;if(Array.isArray(l))for(let c=0,u=l.length;c<u;c++){let f=l[c];r(t.shapes,f)}else r(t.shapes,l)}}if(this.isSkinnedMesh&&(s.bindMode=this.bindMode,s.bindMatrix=this.bindMatrix.toArray(),this.skeleton!==void 0&&(r(t.skeletons,this.skeleton),s.skeleton=this.skeleton.uuid)),this.material!==void 0)if(Array.isArray(this.material)){let a=[];for(let l=0,c=this.material.length;l<c;l++)a.push(r(t.materials,this.material[l]));s.material=a}else s.material=r(t.materials,this.material);if(this.children.length>0){s.children=[];for(let a=0;a<this.children.length;a++)s.children.push(this.children[a].toJSON(t).object)}if(this.animations.length>0){s.animations=[];for(let a=0;a<this.animations.length;a++){let l=this.animations[a];s.animations.push(r(t.animations,l))}}if(e){let a=o(t.geometries),l=o(t.materials),c=o(t.textures),u=o(t.images),f=o(t.shapes),p=o(t.skeletons),x=o(t.animations),y=o(t.nodes);a.length>0&&(n.geometries=a),l.length>0&&(n.materials=l),c.length>0&&(n.textures=c),u.length>0&&(n.images=u),f.length>0&&(n.shapes=f),p.length>0&&(n.skeletons=p),x.length>0&&(n.animations=x),y.length>0&&(n.nodes=y)}return n.object=s,n;function o(a){let l=[];for(let c in a){let u=a[c];delete u.metadata,l.push(u)}return l}}clone(t){return new this.constructor().copy(this,t)}copy(t,e=!0){if(this.name=t.name,this.up.copy(t.up),this.position.copy(t.position),this.rotation.order=t.rotation.order,this.quaternion.copy(t.quaternion),this.scale.copy(t.scale),this.matrix.copy(t.matrix),this.matrixWorld.copy(t.matrixWorld),this.matrixAutoUpdate=t.matrixAutoUpdate,this.matrixWorldAutoUpdate=t.matrixWorldAutoUpdate,this.matrixWorldNeedsUpdate=t.matrixWorldNeedsUpdate,this.layers.mask=t.layers.mask,this.visible=t.visible,this.castShadow=t.castShadow,this.receiveShadow=t.receiveShadow,this.frustumCulled=t.frustumCulled,this.renderOrder=t.renderOrder,this.animations=t.animations.slice(),this.userData=JSON.parse(JSON.stringify(t.userData)),e===!0)for(let n=0;n<t.children.length;n++){let s=t.children[n];this.add(s.clone())}return this}};rn.DEFAULT_UP=new F(0,1,0);rn.DEFAULT_MATRIX_AUTO_UPDATE=!0;rn.DEFAULT_MATRIX_WORLD_AUTO_UPDATE=!0;var Pn=new F,Qn=new F,wo=new F,ti=new F,fs=new F,ps=new F,Kc=new F,Eo=new F,To=new F,Ao=new F,kr=!1,ws=class i{constructor(t=new F,e=new F,n=new F){this.a=t,this.b=e,this.c=n}static getNormal(t,e,n,s){s.subVectors(n,e),Pn.subVectors(t,e),s.cross(Pn);let r=s.lengthSq();return r>0?s.multiplyScalar(1/Math.sqrt(r)):s.set(0,0,0)}static getBarycoord(t,e,n,s,r){Pn.subVectors(s,e),Qn.subVectors(n,e),wo.subVectors(t,e);let o=Pn.dot(Pn),a=Pn.dot(Qn),l=Pn.dot(wo),c=Qn.dot(Qn),u=Qn.dot(wo),f=o*c-a*a;if(f===0)return r.set(0,0,0),null;let p=1/f,x=(c*l-a*u)*p,y=(o*u-a*l)*p;return r.set(1-x-y,y,x)}static containsPoint(t,e,n,s){return this.getBarycoord(t,e,n,s,ti)===null?!1:ti.x>=0&&ti.y>=0&&ti.x+ti.y<=1}static getUV(t,e,n,s,r,o,a,l){return kr===!1&&(console.warn("THREE.Triangle.getUV() has been renamed to THREE.Triangle.getInterpolation()."),kr=!0),this.getInterpolation(t,e,n,s,r,o,a,l)}static getInterpolation(t,e,n,s,r,o,a,l){return this.getBarycoord(t,e,n,s,ti)===null?(l.x=0,l.y=0,"z"in l&&(l.z=0),"w"in l&&(l.w=0),null):(l.setScalar(0),l.addScaledVector(r,ti.x),l.addScaledVector(o,ti.y),l.addScaledVector(a,ti.z),l)}static isFrontFacing(t,e,n,s){return Pn.subVectors(n,e),Qn.subVectors(t,e),Pn.cross(Qn).dot(s)<0}set(t,e,n){return this.a.copy(t),this.b.copy(e),this.c.copy(n),this}setFromPointsAndIndices(t,e,n,s){return this.a.copy(t[e]),this.b.copy(t[n]),this.c.copy(t[s]),this}setFromAttributeAndIndices(t,e,n,s){return this.a.fromBufferAttribute(t,e),this.b.fromBufferAttribute(t,n),this.c.fromBufferAttribute(t,s),this}clone(){return new this.constructor().copy(this)}copy(t){return this.a.copy(t.a),this.b.copy(t.b),this.c.copy(t.c),this}getArea(){return Pn.subVectors(this.c,this.b),Qn.subVectors(this.a,this.b),Pn.cross(Qn).length()*.5}getMidpoint(t){return t.addVectors(this.a,this.b).add(this.c).multiplyScalar(1/3)}getNormal(t){return i.getNormal(this.a,this.b,this.c,t)}getPlane(t){return t.setFromCoplanarPoints(this.a,this.b,this.c)}getBarycoord(t,e){return i.getBarycoord(t,this.a,this.b,this.c,e)}getUV(t,e,n,s,r){return kr===!1&&(console.warn("THREE.Triangle.getUV() has been renamed to THREE.Triangle.getInterpolation()."),kr=!0),i.getInterpolation(t,this.a,this.b,this.c,e,n,s,r)}getInterpolation(t,e,n,s,r){return i.getInterpolation(t,this.a,this.b,this.c,e,n,s,r)}containsPoint(t){return i.containsPoint(t,this.a,this.b,this.c)}isFrontFacing(t){return i.isFrontFacing(this.a,this.b,this.c,t)}intersectsBox(t){return t.intersectsTriangle(this)}closestPointToPoint(t,e){let n=this.a,s=this.b,r=this.c,o,a;fs.subVectors(s,n),ps.subVectors(r,n),Eo.subVectors(t,n);let l=fs.dot(Eo),c=ps.dot(Eo);if(l<=0&&c<=0)return e.copy(n);To.subVectors(t,s);let u=fs.dot(To),f=ps.dot(To);if(u>=0&&f<=u)return e.copy(s);let p=l*f-u*c;if(p<=0&&l>=0&&u<=0)return o=l/(l-u),e.copy(n).addScaledVector(fs,o);Ao.subVectors(t,r);let x=fs.dot(Ao),y=ps.dot(Ao);if(y>=0&&x<=y)return e.copy(r);let b=x*c-l*y;if(b<=0&&c>=0&&y<=0)return a=c/(c-y),e.copy(n).addScaledVector(ps,a);let m=u*y-x*f;if(m<=0&&f-u>=0&&x-y>=0)return Kc.subVectors(r,s),a=(f-u)/(f-u+(x-y)),e.copy(s).addScaledVector(Kc,a);let d=1/(m+b+p);return o=b*d,a=p*d,e.copy(n).addScaledVector(fs,o).addScaledVector(ps,a)}equals(t){return t.a.equals(this.a)&&t.b.equals(this.b)&&t.c.equals(this.c)}},Jh={aliceblue:15792383,antiquewhite:16444375,aqua:65535,aquamarine:8388564,azure:15794175,beige:16119260,bisque:16770244,black:0,blanchedalmond:16772045,blue:255,blueviolet:9055202,brown:10824234,burlywood:14596231,cadetblue:6266528,chartreuse:8388352,chocolate:13789470,coral:16744272,cornflowerblue:6591981,cornsilk:16775388,crimson:14423100,cyan:65535,darkblue:139,darkcyan:35723,darkgoldenrod:12092939,darkgray:11119017,darkgreen:25600,darkgrey:11119017,darkkhaki:12433259,darkmagenta:9109643,darkolivegreen:5597999,darkorange:16747520,darkorchid:10040012,darkred:9109504,darksalmon:15308410,darkseagreen:9419919,darkslateblue:4734347,darkslategray:3100495,darkslategrey:3100495,darkturquoise:52945,darkviolet:9699539,deeppink:16716947,deepskyblue:49151,dimgray:6908265,dimgrey:6908265,dodgerblue:2003199,firebrick:11674146,floralwhite:16775920,forestgreen:2263842,fuchsia:16711935,gainsboro:14474460,ghostwhite:16316671,gold:16766720,goldenrod:14329120,gray:8421504,green:32768,greenyellow:11403055,grey:8421504,honeydew:15794160,hotpink:16738740,indianred:13458524,indigo:4915330,ivory:16777200,khaki:15787660,lavender:15132410,lavenderblush:16773365,lawngreen:8190976,lemonchiffon:16775885,lightblue:11393254,lightcoral:15761536,lightcyan:14745599,lightgoldenrodyellow:16448210,lightgray:13882323,lightgreen:9498256,lightgrey:13882323,lightpink:16758465,lightsalmon:16752762,lightseagreen:2142890,lightskyblue:8900346,lightslategray:7833753,lightslategrey:7833753,lightsteelblue:11584734,lightyellow:16777184,lime:65280,limegreen:3329330,linen:16445670,magenta:16711935,maroon:8388608,mediumaquamarine:6737322,mediumblue:205,mediumorchid:12211667,mediumpurple:9662683,mediumseagreen:3978097,mediumslateblue:8087790,mediumspringgreen:64154,mediumturquoise:4772300,mediumvioletred:13047173,midnightblue:1644912,mintcream:16121850,mistyrose:16770273,moccasin:16770229,navajowhite:16768685,navy:128,oldlace:16643558,olive:8421376,olivedrab:7048739,orange:16753920,orangered:16729344,orchid:14315734,palegoldenrod:15657130,palegreen:10025880,paleturquoise:11529966,palevioletred:14381203,papayawhip:16773077,peachpuff:16767673,peru:13468991,pink:16761035,plum:14524637,powderblue:11591910,purple:8388736,rebeccapurple:6697881,red:16711680,rosybrown:12357519,royalblue:4286945,saddlebrown:9127187,salmon:16416882,sandybrown:16032864,seagreen:3050327,seashell:16774638,sienna:10506797,silver:12632256,skyblue:8900331,slateblue:6970061,slategray:7372944,slategrey:7372944,snow:16775930,springgreen:65407,steelblue:4620980,tan:13808780,teal:32896,thistle:14204888,tomato:16737095,turquoise:4251856,violet:15631086,wheat:16113331,white:16777215,whitesmoke:16119285,yellow:16776960,yellowgreen:10145074},mi={h:0,s:0,l:0},Hr={h:0,s:0,l:0};function Co(i,t,e){return e<0&&(e+=1),e>1&&(e-=1),e<1/6?i+(t-i)*6*e:e<1/2?t:e<2/3?i+(t-i)*6*(2/3-e):i}var qt=class{constructor(t,e,n){return this.isColor=!0,this.r=1,this.g=1,this.b=1,this.set(t,e,n)}set(t,e,n){if(e===void 0&&n===void 0){let s=t;s&&s.isColor?this.copy(s):typeof s=="number"?this.setHex(s):typeof s=="string"&&this.setStyle(s)}else this.setRGB(t,e,n);return this}setScalar(t){return this.r=t,this.g=t,this.b=t,this}setHex(t,e=Re){return t=Math.floor(t),this.r=(t>>16&255)/255,this.g=(t>>8&255)/255,this.b=(t&255)/255,fe.toWorkingColorSpace(this,e),this}setRGB(t,e,n,s=fe.workingColorSpace){return this.r=t,this.g=e,this.b=n,fe.toWorkingColorSpace(this,s),this}setHSL(t,e,n,s=fe.workingColorSpace){if(t=Cl(t,1),e=tn(e,0,1),n=tn(n,0,1),e===0)this.r=this.g=this.b=n;else{let r=n<=.5?n*(1+e):n+e-n*e,o=2*n-r;this.r=Co(o,r,t+1/3),this.g=Co(o,r,t),this.b=Co(o,r,t-1/3)}return fe.toWorkingColorSpace(this,s),this}setStyle(t,e=Re){function n(r){r!==void 0&&parseFloat(r)<1&&console.warn("THREE.Color: Alpha component of "+t+" will be ignored.")}let s;if(s=/^(\w+)\(([^\)]*)\)/.exec(t)){let r,o=s[1],a=s[2];switch(o){case"rgb":case"rgba":if(r=/^\s*(\d+)\s*,\s*(\d+)\s*,\s*(\d+)\s*(?:,\s*(\d*\.?\d+)\s*)?$/.exec(a))return n(r[4]),this.setRGB(Math.min(255,parseInt(r[1],10))/255,Math.min(255,parseInt(r[2],10))/255,Math.min(255,parseInt(r[3],10))/255,e);if(r=/^\s*(\d+)\%\s*,\s*(\d+)\%\s*,\s*(\d+)\%\s*(?:,\s*(\d*\.?\d+)\s*)?$/.exec(a))return n(r[4]),this.setRGB(Math.min(100,parseInt(r[1],10))/100,Math.min(100,parseInt(r[2],10))/100,Math.min(100,parseInt(r[3],10))/100,e);break;case"hsl":case"hsla":if(r=/^\s*(\d*\.?\d+)\s*,\s*(\d*\.?\d+)\%\s*,\s*(\d*\.?\d+)\%\s*(?:,\s*(\d*\.?\d+)\s*)?$/.exec(a))return n(r[4]),this.setHSL(parseFloat(r[1])/360,parseFloat(r[2])/100,parseFloat(r[3])/100,e);break;default:console.warn("THREE.Color: Unknown color model "+t)}}else if(s=/^\#([A-Fa-f\d]+)$/.exec(t)){let r=s[1],o=r.length;if(o===3)return this.setRGB(parseInt(r.charAt(0),16)/15,parseInt(r.charAt(1),16)/15,parseInt(r.charAt(2),16)/15,e);if(o===6)return this.setHex(parseInt(r,16),e);console.warn("THREE.Color: Invalid hex color "+t)}else if(t&&t.length>0)return this.setColorName(t,e);return this}setColorName(t,e=Re){let n=Jh[t.toLowerCase()];return n!==void 0?this.setHex(n,e):console.warn("THREE.Color: Unknown color "+t),this}clone(){return new this.constructor(this.r,this.g,this.b)}copy(t){return this.r=t.r,this.g=t.g,this.b=t.b,this}copySRGBToLinear(t){return this.r=As(t.r),this.g=As(t.g),this.b=As(t.b),this}copyLinearToSRGB(t){return this.r=go(t.r),this.g=go(t.g),this.b=go(t.b),this}convertSRGBToLinear(){return this.copySRGBToLinear(this),this}convertLinearToSRGB(){return this.copyLinearToSRGB(this),this}getHex(t=Re){return fe.fromWorkingColorSpace(Qe.copy(this),t),Math.round(tn(Qe.r*255,0,255))*65536+Math.round(tn(Qe.g*255,0,255))*256+Math.round(tn(Qe.b*255,0,255))}getHexString(t=Re){return("000000"+this.getHex(t).toString(16)).slice(-6)}getHSL(t,e=fe.workingColorSpace){fe.fromWorkingColorSpace(Qe.copy(this),e);let n=Qe.r,s=Qe.g,r=Qe.b,o=Math.max(n,s,r),a=Math.min(n,s,r),l,c,u=(a+o)/2;if(a===o)l=0,c=0;else{let f=o-a;switch(c=u<=.5?f/(o+a):f/(2-o-a),o){case n:l=(s-r)/f+(s<r?6:0);break;case s:l=(r-n)/f+2;break;case r:l=(n-s)/f+4;break}l/=6}return t.h=l,t.s=c,t.l=u,t}getRGB(t,e=fe.workingColorSpace){return fe.fromWorkingColorSpace(Qe.copy(this),e),t.r=Qe.r,t.g=Qe.g,t.b=Qe.b,t}getStyle(t=Re){fe.fromWorkingColorSpace(Qe.copy(this),t);let e=Qe.r,n=Qe.g,s=Qe.b;return t!==Re?`color(${t} ${e.toFixed(3)} ${n.toFixed(3)} ${s.toFixed(3)})`:`rgb(${Math.round(e*255)},${Math.round(n*255)},${Math.round(s*255)})`}offsetHSL(t,e,n){return this.getHSL(mi),this.setHSL(mi.h+t,mi.s+e,mi.l+n)}add(t){return this.r+=t.r,this.g+=t.g,this.b+=t.b,this}addColors(t,e){return this.r=t.r+e.r,this.g=t.g+e.g,this.b=t.b+e.b,this}addScalar(t){return this.r+=t,this.g+=t,this.b+=t,this}sub(t){return this.r=Math.max(0,this.r-t.r),this.g=Math.max(0,this.g-t.g),this.b=Math.max(0,this.b-t.b),this}multiply(t){return this.r*=t.r,this.g*=t.g,this.b*=t.b,this}multiplyScalar(t){return this.r*=t,this.g*=t,this.b*=t,this}lerp(t,e){return this.r+=(t.r-this.r)*e,this.g+=(t.g-this.g)*e,this.b+=(t.b-this.b)*e,this}lerpColors(t,e,n){return this.r=t.r+(e.r-t.r)*n,this.g=t.g+(e.g-t.g)*n,this.b=t.b+(e.b-t.b)*n,this}lerpHSL(t,e){this.getHSL(mi),t.getHSL(Hr);let n=rr(mi.h,Hr.h,e),s=rr(mi.s,Hr.s,e),r=rr(mi.l,Hr.l,e);return this.setHSL(n,s,r),this}setFromVector3(t){return this.r=t.x,this.g=t.y,this.b=t.z,this}applyMatrix3(t){let e=this.r,n=this.g,s=this.b,r=t.elements;return this.r=r[0]*e+r[3]*n+r[6]*s,this.g=r[1]*e+r[4]*n+r[7]*s,this.b=r[2]*e+r[5]*n+r[8]*s,this}equals(t){return t.r===this.r&&t.g===this.g&&t.b===this.b}fromArray(t,e=0){return this.r=t[e],this.g=t[e+1],this.b=t[e+2],this}toArray(t=[],e=0){return t[e]=this.r,t[e+1]=this.g,t[e+2]=this.b,t}fromBufferAttribute(t,e){return this.r=t.getX(e),this.g=t.getY(e),this.b=t.getZ(e),this}toJSON(){return this.getHex()}*[Symbol.iterator](){yield this.r,yield this.g,yield this.b}},Qe=new qt;qt.NAMES=Jh;var qd=0,Si=class extends Xn{constructor(){super(),this.isMaterial=!0,Object.defineProperty(this,"id",{value:qd++}),this.uuid=Bs(),this.name="",this.type="Material",this.blending=ii,this.side=Mi,this.vertexColors=!1,this.opacity=1,this.transparent=!1,this.alphaHash=!1,this.blendSrc=zo,this.blendDst=ko,this.blendEquation=ki,this.blendSrcAlpha=null,this.blendDstAlpha=null,this.blendEquationAlpha=null,this.blendColor=new qt(0,0,0),this.blendAlpha=0,this.depthFunc=sa,this.depthTest=!0,this.depthWrite=!0,this.stencilWriteMask=255,this.stencilFunc=Bc,this.stencilRef=0,this.stencilFuncMask=255,this.stencilFail=as,this.stencilZFail=as,this.stencilZPass=as,this.stencilWrite=!1,this.clippingPlanes=null,this.clipIntersection=!1,this.clipShadows=!1,this.shadowSide=null,this.colorWrite=!0,this.precision=null,this.polygonOffset=!1,this.polygonOffsetFactor=0,this.polygonOffsetUnits=0,this.dithering=!1,this.alphaToCoverage=!1,this.premultipliedAlpha=!1,this.forceSinglePass=!1,this.visible=!0,this.toneMapped=!0,this.userData={},this.version=0,this._alphaTest=0}get alphaTest(){return this._alphaTest}set alphaTest(t){this._alphaTest>0!=t>0&&this.version++,this._alphaTest=t}onBuild(){}onBeforeRender(){}onBeforeCompile(){}customProgramCacheKey(){return this.onBeforeCompile.toString()}setValues(t){if(t!==void 0)for(let e in t){let n=t[e];if(n===void 0){console.warn(`THREE.Material: parameter '${e}' has value of undefined.`);continue}let s=this[e];if(s===void 0){console.warn(`THREE.Material: '${e}' is not a property of THREE.${this.type}.`);continue}s&&s.isColor?s.set(n):s&&s.isVector3&&n&&n.isVector3?s.copy(n):this[e]=n}}toJSON(t){let e=t===void 0||typeof t=="string";e&&(t={textures:{},images:{}});let n={metadata:{version:4.6,type:"Material",generator:"Material.toJSON"}};n.uuid=this.uuid,n.type=this.type,this.name!==""&&(n.name=this.name),this.color&&this.color.isColor&&(n.color=this.color.getHex()),this.roughness!==void 0&&(n.roughness=this.roughness),this.metalness!==void 0&&(n.metalness=this.metalness),this.sheen!==void 0&&(n.sheen=this.sheen),this.sheenColor&&this.sheenColor.isColor&&(n.sheenColor=this.sheenColor.getHex()),this.sheenRoughness!==void 0&&(n.sheenRoughness=this.sheenRoughness),this.emissive&&this.emissive.isColor&&(n.emissive=this.emissive.getHex()),this.emissiveIntensity&&this.emissiveIntensity!==1&&(n.emissiveIntensity=this.emissiveIntensity),this.specular&&this.specular.isColor&&(n.specular=this.specular.getHex()),this.specularIntensity!==void 0&&(n.specularIntensity=this.specularIntensity),this.specularColor&&this.specularColor.isColor&&(n.specularColor=this.specularColor.getHex()),this.shininess!==void 0&&(n.shininess=this.shininess),this.clearcoat!==void 0&&(n.clearcoat=this.clearcoat),this.clearcoatRoughness!==void 0&&(n.clearcoatRoughness=this.clearcoatRoughness),this.clearcoatMap&&this.clearcoatMap.isTexture&&(n.clearcoatMap=this.clearcoatMap.toJSON(t).uuid),this.clearcoatRoughnessMap&&this.clearcoatRoughnessMap.isTexture&&(n.clearcoatRoughnessMap=this.clearcoatRoughnessMap.toJSON(t).uuid),this.clearcoatNormalMap&&this.clearcoatNormalMap.isTexture&&(n.clearcoatNormalMap=this.clearcoatNormalMap.toJSON(t).uuid,n.clearcoatNormalScale=this.clearcoatNormalScale.toArray()),this.iridescence!==void 0&&(n.iridescence=this.iridescence),this.iridescenceIOR!==void 0&&(n.iridescenceIOR=this.iridescenceIOR),this.iridescenceThicknessRange!==void 0&&(n.iridescenceThicknessRange=this.iridescenceThicknessRange),this.iridescenceMap&&this.iridescenceMap.isTexture&&(n.iridescenceMap=this.iridescenceMap.toJSON(t).uuid),this.iridescenceThicknessMap&&this.iridescenceThicknessMap.isTexture&&(n.iridescenceThicknessMap=this.iridescenceThicknessMap.toJSON(t).uuid),this.anisotropy!==void 0&&(n.anisotropy=this.anisotropy),this.anisotropyRotation!==void 0&&(n.anisotropyRotation=this.anisotropyRotation),this.anisotropyMap&&this.anisotropyMap.isTexture&&(n.anisotropyMap=this.anisotropyMap.toJSON(t).uuid),this.map&&this.map.isTexture&&(n.map=this.map.toJSON(t).uuid),this.matcap&&this.matcap.isTexture&&(n.matcap=this.matcap.toJSON(t).uuid),this.alphaMap&&this.alphaMap.isTexture&&(n.alphaMap=this.alphaMap.toJSON(t).uuid),this.lightMap&&this.lightMap.isTexture&&(n.lightMap=this.lightMap.toJSON(t).uuid,n.lightMapIntensity=this.lightMapIntensity),this.aoMap&&this.aoMap.isTexture&&(n.aoMap=this.aoMap.toJSON(t).uuid,n.aoMapIntensity=this.aoMapIntensity),this.bumpMap&&this.bumpMap.isTexture&&(n.bumpMap=this.bumpMap.toJSON(t).uuid,n.bumpScale=this.bumpScale),this.normalMap&&this.normalMap.isTexture&&(n.normalMap=this.normalMap.toJSON(t).uuid,n.normalMapType=this.normalMapType,n.normalScale=this.normalScale.toArray()),this.displacementMap&&this.displacementMap.isTexture&&(n.displacementMap=this.displacementMap.toJSON(t).uuid,n.displacementScale=this.displacementScale,n.displacementBias=this.displacementBias),this.roughnessMap&&this.roughnessMap.isTexture&&(n.roughnessMap=this.roughnessMap.toJSON(t).uuid),this.metalnessMap&&this.metalnessMap.isTexture&&(n.metalnessMap=this.metalnessMap.toJSON(t).uuid),this.emissiveMap&&this.emissiveMap.isTexture&&(n.emissiveMap=this.emissiveMap.toJSON(t).uuid),this.specularMap&&this.specularMap.isTexture&&(n.specularMap=this.specularMap.toJSON(t).uuid),this.specularIntensityMap&&this.specularIntensityMap.isTexture&&(n.specularIntensityMap=this.specularIntensityMap.toJSON(t).uuid),this.specularColorMap&&this.specularColorMap.isTexture&&(n.specularColorMap=this.specularColorMap.toJSON(t).uuid),this.envMap&&this.envMap.isTexture&&(n.envMap=this.envMap.toJSON(t).uuid,this.combine!==void 0&&(n.combine=this.combine)),this.envMapIntensity!==void 0&&(n.envMapIntensity=this.envMapIntensity),this.reflectivity!==void 0&&(n.reflectivity=this.reflectivity),this.refractionRatio!==void 0&&(n.refractionRatio=this.refractionRatio),this.gradientMap&&this.gradientMap.isTexture&&(n.gradientMap=this.gradientMap.toJSON(t).uuid),this.transmission!==void 0&&(n.transmission=this.transmission),this.transmissionMap&&this.transmissionMap.isTexture&&(n.transmissionMap=this.transmissionMap.toJSON(t).uuid),this.thickness!==void 0&&(n.thickness=this.thickness),this.thicknessMap&&this.thicknessMap.isTexture&&(n.thicknessMap=this.thicknessMap.toJSON(t).uuid),this.attenuationDistance!==void 0&&this.attenuationDistance!==1/0&&(n.attenuationDistance=this.attenuationDistance),this.attenuationColor!==void 0&&(n.attenuationColor=this.attenuationColor.getHex()),this.size!==void 0&&(n.size=this.size),this.shadowSide!==null&&(n.shadowSide=this.shadowSide),this.sizeAttenuation!==void 0&&(n.sizeAttenuation=this.sizeAttenuation),this.blending!==ii&&(n.blending=this.blending),this.side!==Mi&&(n.side=this.side),this.vertexColors===!0&&(n.vertexColors=!0),this.opacity<1&&(n.opacity=this.opacity),this.transparent===!0&&(n.transparent=!0),this.blendSrc!==zo&&(n.blendSrc=this.blendSrc),this.blendDst!==ko&&(n.blendDst=this.blendDst),this.blendEquation!==ki&&(n.blendEquation=this.blendEquation),this.blendSrcAlpha!==null&&(n.blendSrcAlpha=this.blendSrcAlpha),this.blendDstAlpha!==null&&(n.blendDstAlpha=this.blendDstAlpha),this.blendEquationAlpha!==null&&(n.blendEquationAlpha=this.blendEquationAlpha),this.blendColor&&this.blendColor.isColor&&(n.blendColor=this.blendColor.getHex()),this.blendAlpha!==0&&(n.blendAlpha=this.blendAlpha),this.depthFunc!==sa&&(n.depthFunc=this.depthFunc),this.depthTest===!1&&(n.depthTest=this.depthTest),this.depthWrite===!1&&(n.depthWrite=this.depthWrite),this.colorWrite===!1&&(n.colorWrite=this.colorWrite),this.stencilWriteMask!==255&&(n.stencilWriteMask=this.stencilWriteMask),this.stencilFunc!==Bc&&(n.stencilFunc=this.stencilFunc),this.stencilRef!==0&&(n.stencilRef=this.stencilRef),this.stencilFuncMask!==255&&(n.stencilFuncMask=this.stencilFuncMask),this.stencilFail!==as&&(n.stencilFail=this.stencilFail),this.stencilZFail!==as&&(n.stencilZFail=this.stencilZFail),this.stencilZPass!==as&&(n.stencilZPass=this.stencilZPass),this.stencilWrite===!0&&(n.stencilWrite=this.stencilWrite),this.rotation!==void 0&&this.rotation!==0&&(n.rotation=this.rotation),this.polygonOffset===!0&&(n.polygonOffset=!0),this.polygonOffsetFactor!==0&&(n.polygonOffsetFactor=this.polygonOffsetFactor),this.polygonOffsetUnits!==0&&(n.polygonOffsetUnits=this.polygonOffsetUnits),this.linewidth!==void 0&&this.linewidth!==1&&(n.linewidth=this.linewidth),this.dashSize!==void 0&&(n.dashSize=this.dashSize),this.gapSize!==void 0&&(n.gapSize=this.gapSize),this.scale!==void 0&&(n.scale=this.scale),this.dithering===!0&&(n.dithering=!0),this.alphaTest>0&&(n.alphaTest=this.alphaTest),this.alphaHash===!0&&(n.alphaHash=!0),this.alphaToCoverage===!0&&(n.alphaToCoverage=!0),this.premultipliedAlpha===!0&&(n.premultipliedAlpha=!0),this.forceSinglePass===!0&&(n.forceSinglePass=!0),this.wireframe===!0&&(n.wireframe=!0),this.wireframeLinewidth>1&&(n.wireframeLinewidth=this.wireframeLinewidth),this.wireframeLinecap!=="round"&&(n.wireframeLinecap=this.wireframeLinecap),this.wireframeLinejoin!=="round"&&(n.wireframeLinejoin=this.wireframeLinejoin),this.flatShading===!0&&(n.flatShading=!0),this.visible===!1&&(n.visible=!1),this.toneMapped===!1&&(n.toneMapped=!1),this.fog===!1&&(n.fog=!1),Object.keys(this.userData).length>0&&(n.userData=this.userData);function s(r){let o=[];for(let a in r){let l=r[a];delete l.metadata,o.push(l)}return o}if(e){let r=s(t.textures),o=s(t.images);r.length>0&&(n.textures=r),o.length>0&&(n.images=o)}return n}clone(){return new this.constructor().copy(this)}copy(t){this.name=t.name,this.blending=t.blending,this.side=t.side,this.vertexColors=t.vertexColors,this.opacity=t.opacity,this.transparent=t.transparent,this.blendSrc=t.blendSrc,this.blendDst=t.blendDst,this.blendEquation=t.blendEquation,this.blendSrcAlpha=t.blendSrcAlpha,this.blendDstAlpha=t.blendDstAlpha,this.blendEquationAlpha=t.blendEquationAlpha,this.blendColor.copy(t.blendColor),this.blendAlpha=t.blendAlpha,this.depthFunc=t.depthFunc,this.depthTest=t.depthTest,this.depthWrite=t.depthWrite,this.stencilWriteMask=t.stencilWriteMask,this.stencilFunc=t.stencilFunc,this.stencilRef=t.stencilRef,this.stencilFuncMask=t.stencilFuncMask,this.stencilFail=t.stencilFail,this.stencilZFail=t.stencilZFail,this.stencilZPass=t.stencilZPass,this.stencilWrite=t.stencilWrite;let e=t.clippingPlanes,n=null;if(e!==null){let s=e.length;n=new Array(s);for(let r=0;r!==s;++r)n[r]=e[r].clone()}return this.clippingPlanes=n,this.clipIntersection=t.clipIntersection,this.clipShadows=t.clipShadows,this.shadowSide=t.shadowSide,this.colorWrite=t.colorWrite,this.precision=t.precision,this.polygonOffset=t.polygonOffset,this.polygonOffsetFactor=t.polygonOffsetFactor,this.polygonOffsetUnits=t.polygonOffsetUnits,this.dithering=t.dithering,this.alphaTest=t.alphaTest,this.alphaHash=t.alphaHash,this.alphaToCoverage=t.alphaToCoverage,this.premultipliedAlpha=t.premultipliedAlpha,this.forceSinglePass=t.forceSinglePass,this.visible=t.visible,this.toneMapped=t.toneMapped,this.userData=JSON.parse(JSON.stringify(t.userData)),this}dispose(){this.dispatchEvent({type:"dispose"})}set needsUpdate(t){t===!0&&this.version++}},gn=class extends Si{constructor(t){super(),this.isMeshBasicMaterial=!0,this.type="MeshBasicMaterial",this.color=new qt(16777215),this.map=null,this.lightMap=null,this.lightMapIntensity=1,this.aoMap=null,this.aoMapIntensity=1,this.specularMap=null,this.alphaMap=null,this.envMap=null,this.combine=Nh,this.reflectivity=1,this.refractionRatio=.98,this.wireframe=!1,this.wireframeLinewidth=1,this.wireframeLinecap="round",this.wireframeLinejoin="round",this.fog=!0,this.setValues(t)}copy(t){return super.copy(t),this.color.copy(t.color),this.map=t.map,this.lightMap=t.lightMap,this.lightMapIntensity=t.lightMapIntensity,this.aoMap=t.aoMap,this.aoMapIntensity=t.aoMapIntensity,this.specularMap=t.specularMap,this.alphaMap=t.alphaMap,this.envMap=t.envMap,this.combine=t.combine,this.reflectivity=t.reflectivity,this.refractionRatio=t.refractionRatio,this.wireframe=t.wireframe,this.wireframeLinewidth=t.wireframeLinewidth,this.wireframeLinecap=t.wireframeLinecap,this.wireframeLinejoin=t.wireframeLinejoin,this.fog=t.fog,this}};var Ue=new F,Vr=new Pt,sn=class{constructor(t,e,n=!1){if(Array.isArray(t))throw new TypeError("THREE.BufferAttribute: array should be a Typed Array.");this.isBufferAttribute=!0,this.name="",this.array=t,this.itemSize=e,this.count=t!==void 0?t.length/e:0,this.normalized=n,this.usage=zc,this._updateRange={offset:0,count:-1},this.updateRanges=[],this.gpuType=xi,this.version=0}onUploadCallback(){}set needsUpdate(t){t===!0&&this.version++}get updateRange(){return console.warn("THREE.BufferAttribute: updateRange() is deprecated and will be removed in r169. Use addUpdateRange() instead."),this._updateRange}setUsage(t){return this.usage=t,this}addUpdateRange(t,e){this.updateRanges.push({start:t,count:e})}clearUpdateRanges(){this.updateRanges.length=0}copy(t){return this.name=t.name,this.array=new t.array.constructor(t.array),this.itemSize=t.itemSize,this.count=t.count,this.normalized=t.normalized,this.usage=t.usage,this.gpuType=t.gpuType,this}copyAt(t,e,n){t*=this.itemSize,n*=e.itemSize;for(let s=0,r=this.itemSize;s<r;s++)this.array[t+s]=e.array[n+s];return this}copyArray(t){return this.array.set(t),this}applyMatrix3(t){if(this.itemSize===2)for(let e=0,n=this.count;e<n;e++)Vr.fromBufferAttribute(this,e),Vr.applyMatrix3(t),this.setXY(e,Vr.x,Vr.y);else if(this.itemSize===3)for(let e=0,n=this.count;e<n;e++)Ue.fromBufferAttribute(this,e),Ue.applyMatrix3(t),this.setXYZ(e,Ue.x,Ue.y,Ue.z);return this}applyMatrix4(t){for(let e=0,n=this.count;e<n;e++)Ue.fromBufferAttribute(this,e),Ue.applyMatrix4(t),this.setXYZ(e,Ue.x,Ue.y,Ue.z);return this}applyNormalMatrix(t){for(let e=0,n=this.count;e<n;e++)Ue.fromBufferAttribute(this,e),Ue.applyNormalMatrix(t),this.setXYZ(e,Ue.x,Ue.y,Ue.z);return this}transformDirection(t){for(let e=0,n=this.count;e<n;e++)Ue.fromBufferAttribute(this,e),Ue.transformDirection(t),this.setXYZ(e,Ue.x,Ue.y,Ue.z);return this}set(t,e=0){return this.array.set(t,e),this}getComponent(t,e){let n=this.array[t*this.itemSize+e];return this.normalized&&(n=Ss(n,this.array)),n}setComponent(t,e,n){return this.normalized&&(n=ln(n,this.array)),this.array[t*this.itemSize+e]=n,this}getX(t){let e=this.array[t*this.itemSize];return this.normalized&&(e=Ss(e,this.array)),e}setX(t,e){return this.normalized&&(e=ln(e,this.array)),this.array[t*this.itemSize]=e,this}getY(t){let e=this.array[t*this.itemSize+1];return this.normalized&&(e=Ss(e,this.array)),e}setY(t,e){return this.normalized&&(e=ln(e,this.array)),this.array[t*this.itemSize+1]=e,this}getZ(t){let e=this.array[t*this.itemSize+2];return this.normalized&&(e=Ss(e,this.array)),e}setZ(t,e){return this.normalized&&(e=ln(e,this.array)),this.array[t*this.itemSize+2]=e,this}getW(t){let e=this.array[t*this.itemSize+3];return this.normalized&&(e=Ss(e,this.array)),e}setW(t,e){return this.normalized&&(e=ln(e,this.array)),this.array[t*this.itemSize+3]=e,this}setXY(t,e,n){return t*=this.itemSize,this.normalized&&(e=ln(e,this.array),n=ln(n,this.array)),this.array[t+0]=e,this.array[t+1]=n,this}setXYZ(t,e,n,s){return t*=this.itemSize,this.normalized&&(e=ln(e,this.array),n=ln(n,this.array),s=ln(s,this.array)),this.array[t+0]=e,this.array[t+1]=n,this.array[t+2]=s,this}setXYZW(t,e,n,s,r){return t*=this.itemSize,this.normalized&&(e=ln(e,this.array),n=ln(n,this.array),s=ln(s,this.array),r=ln(r,this.array)),this.array[t+0]=e,this.array[t+1]=n,this.array[t+2]=s,this.array[t+3]=r,this}onUpload(t){return this.onUploadCallback=t,this}clone(){return new this.constructor(this.array,this.itemSize).copy(this)}toJSON(){let t={itemSize:this.itemSize,type:this.array.constructor.name,array:Array.from(this.array),normalized:this.normalized};return this.name!==""&&(t.name=this.name),this.usage!==zc&&(t.usage=this.usage),t}};var xa=class extends sn{constructor(t,e,n){super(new Uint16Array(t),e,n)}};var _a=class extends sn{constructor(t,e,n){super(new Uint32Array(t),e,n)}};var Ze=class extends sn{constructor(t,e,n){super(new Float32Array(t),e,n)}};var Zd=0,vn=new ve,Ro=new rn,ms=new F,pn=new ri,tr=new ri,Ye=new F,hn=class i extends Xn{constructor(){super(),this.isBufferGeometry=!0,Object.defineProperty(this,"id",{value:Zd++}),this.uuid=Bs(),this.name="",this.type="BufferGeometry",this.index=null,this.attributes={},this.morphAttributes={},this.morphTargetsRelative=!1,this.groups=[],this.boundingBox=null,this.boundingSphere=null,this.drawRange={start:0,count:1/0},this.userData={}}getIndex(){return this.index}setIndex(t){return Array.isArray(t)?this.index=new(Zh(t)?_a:xa)(t,1):this.index=t,this}getAttribute(t){return this.attributes[t]}setAttribute(t,e){return this.attributes[t]=e,this}deleteAttribute(t){return delete this.attributes[t],this}hasAttribute(t){return this.attributes[t]!==void 0}addGroup(t,e,n=0){this.groups.push({start:t,count:e,materialIndex:n})}clearGroups(){this.groups=[]}setDrawRange(t,e){this.drawRange.start=t,this.drawRange.count=e}applyMatrix4(t){let e=this.attributes.position;e!==void 0&&(e.applyMatrix4(t),e.needsUpdate=!0);let n=this.attributes.normal;if(n!==void 0){let r=new re().getNormalMatrix(t);n.applyNormalMatrix(r),n.needsUpdate=!0}let s=this.attributes.tangent;return s!==void 0&&(s.transformDirection(t),s.needsUpdate=!0),this.boundingBox!==null&&this.computeBoundingBox(),this.boundingSphere!==null&&this.computeBoundingSphere(),this}applyQuaternion(t){return vn.makeRotationFromQuaternion(t),this.applyMatrix4(vn),this}rotateX(t){return vn.makeRotationX(t),this.applyMatrix4(vn),this}rotateY(t){return vn.makeRotationY(t),this.applyMatrix4(vn),this}rotateZ(t){return vn.makeRotationZ(t),this.applyMatrix4(vn),this}translate(t,e,n){return vn.makeTranslation(t,e,n),this.applyMatrix4(vn),this}scale(t,e,n){return vn.makeScale(t,e,n),this.applyMatrix4(vn),this}lookAt(t){return Ro.lookAt(t),Ro.updateMatrix(),this.applyMatrix4(Ro.matrix),this}center(){return this.computeBoundingBox(),this.boundingBox.getCenter(ms).negate(),this.translate(ms.x,ms.y,ms.z),this}setFromPoints(t){let e=[];for(let n=0,s=t.length;n<s;n++){let r=t[n];e.push(r.x,r.y,r.z||0)}return this.setAttribute("position",new Ze(e,3)),this}computeBoundingBox(){this.boundingBox===null&&(this.boundingBox=new ri);let t=this.attributes.position,e=this.morphAttributes.position;if(t&&t.isGLBufferAttribute){console.error('THREE.BufferGeometry.computeBoundingBox(): GLBufferAttribute requires a manual bounding box. Alternatively set "mesh.frustumCulled" to "false".',this),this.boundingBox.set(new F(-1/0,-1/0,-1/0),new F(1/0,1/0,1/0));return}if(t!==void 0){if(this.boundingBox.setFromBufferAttribute(t),e)for(let n=0,s=e.length;n<s;n++){let r=e[n];pn.setFromBufferAttribute(r),this.morphTargetsRelative?(Ye.addVectors(this.boundingBox.min,pn.min),this.boundingBox.expandByPoint(Ye),Ye.addVectors(this.boundingBox.max,pn.max),this.boundingBox.expandByPoint(Ye)):(this.boundingBox.expandByPoint(pn.min),this.boundingBox.expandByPoint(pn.max))}}else this.boundingBox.makeEmpty();(isNaN(this.boundingBox.min.x)||isNaN(this.boundingBox.min.y)||isNaN(this.boundingBox.min.z))&&console.error('THREE.BufferGeometry.computeBoundingBox(): Computed min/max have NaN values. The "position" attribute is likely to have NaN values.',this)}computeBoundingSphere(){this.boundingSphere===null&&(this.boundingSphere=new bi);let t=this.attributes.position,e=this.morphAttributes.position;if(t&&t.isGLBufferAttribute){console.error('THREE.BufferGeometry.computeBoundingSphere(): GLBufferAttribute requires a manual bounding sphere. Alternatively set "mesh.frustumCulled" to "false".',this),this.boundingSphere.set(new F,1/0);return}if(t){let n=this.boundingSphere.center;if(pn.setFromBufferAttribute(t),e)for(let r=0,o=e.length;r<o;r++){let a=e[r];tr.setFromBufferAttribute(a),this.morphTargetsRelative?(Ye.addVectors(pn.min,tr.min),pn.expandByPoint(Ye),Ye.addVectors(pn.max,tr.max),pn.expandByPoint(Ye)):(pn.expandByPoint(tr.min),pn.expandByPoint(tr.max))}pn.getCenter(n);let s=0;for(let r=0,o=t.count;r<o;r++)Ye.fromBufferAttribute(t,r),s=Math.max(s,n.distanceToSquared(Ye));if(e)for(let r=0,o=e.length;r<o;r++){let a=e[r],l=this.morphTargetsRelative;for(let c=0,u=a.count;c<u;c++)Ye.fromBufferAttribute(a,c),l&&(ms.fromBufferAttribute(t,c),Ye.add(ms)),s=Math.max(s,n.distanceToSquared(Ye))}this.boundingSphere.radius=Math.sqrt(s),isNaN(this.boundingSphere.radius)&&console.error('THREE.BufferGeometry.computeBoundingSphere(): Computed radius is NaN. The "position" attribute is likely to have NaN values.',this)}}computeTangents(){let t=this.index,e=this.attributes;if(t===null||e.position===void 0||e.normal===void 0||e.uv===void 0){console.error("THREE.BufferGeometry: .computeTangents() failed. Missing required attributes (index, position, normal or uv)");return}let n=t.array,s=e.position.array,r=e.normal.array,o=e.uv.array,a=s.length/3;this.hasAttribute("tangent")===!1&&this.setAttribute("tangent",new sn(new Float32Array(4*a),4));let l=this.getAttribute("tangent").array,c=[],u=[];for(let R=0;R<a;R++)c[R]=new F,u[R]=new F;let f=new F,p=new F,x=new F,y=new Pt,b=new Pt,m=new Pt,d=new F,C=new F;function w(R,V,tt){f.fromArray(s,R*3),p.fromArray(s,V*3),x.fromArray(s,tt*3),y.fromArray(o,R*2),b.fromArray(o,V*2),m.fromArray(o,tt*2),p.sub(f),x.sub(f),b.sub(y),m.sub(y);let ft=1/(b.x*m.y-m.x*b.y);isFinite(ft)&&(d.copy(p).multiplyScalar(m.y).addScaledVector(x,-b.y).multiplyScalar(ft),C.copy(x).multiplyScalar(b.x).addScaledVector(p,-m.x).multiplyScalar(ft),c[R].add(d),c[V].add(d),c[tt].add(d),u[R].add(C),u[V].add(C),u[tt].add(C))}let U=this.groups;U.length===0&&(U=[{start:0,count:n.length}]);for(let R=0,V=U.length;R<V;++R){let tt=U[R],ft=tt.start,I=tt.count;for(let k=ft,G=ft+I;k<G;k+=3)w(n[k+0],n[k+1],n[k+2])}let z=new F,N=new F,L=new F,j=new F;function S(R){L.fromArray(r,R*3),j.copy(L);let V=c[R];z.copy(V),z.sub(L.multiplyScalar(L.dot(V))).normalize(),N.crossVectors(j,V);let ft=N.dot(u[R])<0?-1:1;l[R*4]=z.x,l[R*4+1]=z.y,l[R*4+2]=z.z,l[R*4+3]=ft}for(let R=0,V=U.length;R<V;++R){let tt=U[R],ft=tt.start,I=tt.count;for(let k=ft,G=ft+I;k<G;k+=3)S(n[k+0]),S(n[k+1]),S(n[k+2])}}computeVertexNormals(){let t=this.index,e=this.getAttribute("position");if(e!==void 0){let n=this.getAttribute("normal");if(n===void 0)n=new sn(new Float32Array(e.count*3),3),this.setAttribute("normal",n);else for(let p=0,x=n.count;p<x;p++)n.setXYZ(p,0,0,0);let s=new F,r=new F,o=new F,a=new F,l=new F,c=new F,u=new F,f=new F;if(t)for(let p=0,x=t.count;p<x;p+=3){let y=t.getX(p+0),b=t.getX(p+1),m=t.getX(p+2);s.fromBufferAttribute(e,y),r.fromBufferAttribute(e,b),o.fromBufferAttribute(e,m),u.subVectors(o,r),f.subVectors(s,r),u.cross(f),a.fromBufferAttribute(n,y),l.fromBufferAttribute(n,b),c.fromBufferAttribute(n,m),a.add(u),l.add(u),c.add(u),n.setXYZ(y,a.x,a.y,a.z),n.setXYZ(b,l.x,l.y,l.z),n.setXYZ(m,c.x,c.y,c.z)}else for(let p=0,x=e.count;p<x;p+=3)s.fromBufferAttribute(e,p+0),r.fromBufferAttribute(e,p+1),o.fromBufferAttribute(e,p+2),u.subVectors(o,r),f.subVectors(s,r),u.cross(f),n.setXYZ(p+0,u.x,u.y,u.z),n.setXYZ(p+1,u.x,u.y,u.z),n.setXYZ(p+2,u.x,u.y,u.z);this.normalizeNormals(),n.needsUpdate=!0}}normalizeNormals(){let t=this.attributes.normal;for(let e=0,n=t.count;e<n;e++)Ye.fromBufferAttribute(t,e),Ye.normalize(),t.setXYZ(e,Ye.x,Ye.y,Ye.z)}toNonIndexed(){function t(a,l){let c=a.array,u=a.itemSize,f=a.normalized,p=new c.constructor(l.length*u),x=0,y=0;for(let b=0,m=l.length;b<m;b++){a.isInterleavedBufferAttribute?x=l[b]*a.data.stride+a.offset:x=l[b]*u;for(let d=0;d<u;d++)p[y++]=c[x++]}return new sn(p,u,f)}if(this.index===null)return console.warn("THREE.BufferGeometry.toNonIndexed(): BufferGeometry is already non-indexed."),this;let e=new i,n=this.index.array,s=this.attributes;for(let a in s){let l=s[a],c=t(l,n);e.setAttribute(a,c)}let r=this.morphAttributes;for(let a in r){let l=[],c=r[a];for(let u=0,f=c.length;u<f;u++){let p=c[u],x=t(p,n);l.push(x)}e.morphAttributes[a]=l}e.morphTargetsRelative=this.morphTargetsRelative;let o=this.groups;for(let a=0,l=o.length;a<l;a++){let c=o[a];e.addGroup(c.start,c.count,c.materialIndex)}return e}toJSON(){let t={metadata:{version:4.6,type:"BufferGeometry",generator:"BufferGeometry.toJSON"}};if(t.uuid=this.uuid,t.type=this.type,this.name!==""&&(t.name=this.name),Object.keys(this.userData).length>0&&(t.userData=this.userData),this.parameters!==void 0){let l=this.parameters;for(let c in l)l[c]!==void 0&&(t[c]=l[c]);return t}t.data={attributes:{}};let e=this.index;e!==null&&(t.data.index={type:e.array.constructor.name,array:Array.prototype.slice.call(e.array)});let n=this.attributes;for(let l in n){let c=n[l];t.data.attributes[l]=c.toJSON(t.data)}let s={},r=!1;for(let l in this.morphAttributes){let c=this.morphAttributes[l],u=[];for(let f=0,p=c.length;f<p;f++){let x=c[f];u.push(x.toJSON(t.data))}u.length>0&&(s[l]=u,r=!0)}r&&(t.data.morphAttributes=s,t.data.morphTargetsRelative=this.morphTargetsRelative);let o=this.groups;o.length>0&&(t.data.groups=JSON.parse(JSON.stringify(o)));let a=this.boundingSphere;return a!==null&&(t.data.boundingSphere={center:a.center.toArray(),radius:a.radius}),t}clone(){return new this.constructor().copy(this)}copy(t){this.index=null,this.attributes={},this.morphAttributes={},this.groups=[],this.boundingBox=null,this.boundingSphere=null;let e={};this.name=t.name;let n=t.index;n!==null&&this.setIndex(n.clone(e));let s=t.attributes;for(let c in s){let u=s[c];this.setAttribute(c,u.clone(e))}let r=t.morphAttributes;for(let c in r){let u=[],f=r[c];for(let p=0,x=f.length;p<x;p++)u.push(f[p].clone(e));this.morphAttributes[c]=u}this.morphTargetsRelative=t.morphTargetsRelative;let o=t.groups;for(let c=0,u=o.length;c<u;c++){let f=o[c];this.addGroup(f.start,f.count,f.materialIndex)}let a=t.boundingBox;a!==null&&(this.boundingBox=a.clone());let l=t.boundingSphere;return l!==null&&(this.boundingSphere=l.clone()),this.drawRange.start=t.drawRange.start,this.drawRange.count=t.drawRange.count,this.userData=t.userData,this}dispose(){this.dispatchEvent({type:"dispose"})}},Qc=new ve,Fi=new Xi,Gr=new bi,th=new F,gs=new F,xs=new F,_s=new F,Po=new F,Wr=new F,Xr=new Pt,Yr=new Pt,qr=new Pt,eh=new F,nh=new F,ih=new F,Zr=new F,Jr=new F,ke=class extends rn{constructor(t=new hn,e=new gn){super(),this.isMesh=!0,this.type="Mesh",this.geometry=t,this.material=e,this.updateMorphTargets()}copy(t,e){return super.copy(t,e),t.morphTargetInfluences!==void 0&&(this.morphTargetInfluences=t.morphTargetInfluences.slice()),t.morphTargetDictionary!==void 0&&(this.morphTargetDictionary=Object.assign({},t.morphTargetDictionary)),this.material=Array.isArray(t.material)?t.material.slice():t.material,this.geometry=t.geometry,this}updateMorphTargets(){let e=this.geometry.morphAttributes,n=Object.keys(e);if(n.length>0){let s=e[n[0]];if(s!==void 0){this.morphTargetInfluences=[],this.morphTargetDictionary={};for(let r=0,o=s.length;r<o;r++){let a=s[r].name||String(r);this.morphTargetInfluences.push(0),this.morphTargetDictionary[a]=r}}}}getVertexPosition(t,e){let n=this.geometry,s=n.attributes.position,r=n.morphAttributes.position,o=n.morphTargetsRelative;e.fromBufferAttribute(s,t);let a=this.morphTargetInfluences;if(r&&a){Wr.set(0,0,0);for(let l=0,c=r.length;l<c;l++){let u=a[l],f=r[l];u!==0&&(Po.fromBufferAttribute(f,t),o?Wr.addScaledVector(Po,u):Wr.addScaledVector(Po.sub(e),u))}e.add(Wr)}return e}raycast(t,e){let n=this.geometry,s=this.material,r=this.matrixWorld;s!==void 0&&(n.boundingSphere===null&&n.computeBoundingSphere(),Gr.copy(n.boundingSphere),Gr.applyMatrix4(r),Fi.copy(t.ray).recast(t.near),!(Gr.containsPoint(Fi.origin)===!1&&(Fi.intersectSphere(Gr,th)===null||Fi.origin.distanceToSquared(th)>(t.far-t.near)**2))&&(Qc.copy(r).invert(),Fi.copy(t.ray).applyMatrix4(Qc),!(n.boundingBox!==null&&Fi.intersectsBox(n.boundingBox)===!1)&&this._computeIntersections(t,e,Fi)))}_computeIntersections(t,e,n){let s,r=this.geometry,o=this.material,a=r.index,l=r.attributes.position,c=r.attributes.uv,u=r.attributes.uv1,f=r.attributes.normal,p=r.groups,x=r.drawRange;if(a!==null)if(Array.isArray(o))for(let y=0,b=p.length;y<b;y++){let m=p[y],d=o[m.materialIndex],C=Math.max(m.start,x.start),w=Math.min(a.count,Math.min(m.start+m.count,x.start+x.count));for(let U=C,z=w;U<z;U+=3){let N=a.getX(U),L=a.getX(U+1),j=a.getX(U+2);s=$r(this,d,t,n,c,u,f,N,L,j),s&&(s.faceIndex=Math.floor(U/3),s.face.materialIndex=m.materialIndex,e.push(s))}}else{let y=Math.max(0,x.start),b=Math.min(a.count,x.start+x.count);for(let m=y,d=b;m<d;m+=3){let C=a.getX(m),w=a.getX(m+1),U=a.getX(m+2);s=$r(this,o,t,n,c,u,f,C,w,U),s&&(s.faceIndex=Math.floor(m/3),e.push(s))}}else if(l!==void 0)if(Array.isArray(o))for(let y=0,b=p.length;y<b;y++){let m=p[y],d=o[m.materialIndex],C=Math.max(m.start,x.start),w=Math.min(l.count,Math.min(m.start+m.count,x.start+x.count));for(let U=C,z=w;U<z;U+=3){let N=U,L=U+1,j=U+2;s=$r(this,d,t,n,c,u,f,N,L,j),s&&(s.faceIndex=Math.floor(U/3),s.face.materialIndex=m.materialIndex,e.push(s))}}else{let y=Math.max(0,x.start),b=Math.min(l.count,x.start+x.count);for(let m=y,d=b;m<d;m+=3){let C=m,w=m+1,U=m+2;s=$r(this,o,t,n,c,u,f,C,w,U),s&&(s.faceIndex=Math.floor(m/3),e.push(s))}}}};function Jd(i,t,e,n,s,r,o,a){let l;if(t.side===nn?l=n.intersectTriangle(o,r,s,!0,a):l=n.intersectTriangle(s,r,o,t.side===Mi,a),l===null)return null;Jr.copy(a),Jr.applyMatrix4(i.matrixWorld);let c=e.ray.origin.distanceTo(Jr);return c<e.near||c>e.far?null:{distance:c,point:Jr.clone(),object:i}}function $r(i,t,e,n,s,r,o,a,l,c){i.getVertexPosition(a,gs),i.getVertexPosition(l,xs),i.getVertexPosition(c,_s);let u=Jd(i,t,e,n,gs,xs,_s,Zr);if(u){s&&(Xr.fromBufferAttribute(s,a),Yr.fromBufferAttribute(s,l),qr.fromBufferAttribute(s,c),u.uv=ws.getInterpolation(Zr,gs,xs,_s,Xr,Yr,qr,new Pt)),r&&(Xr.fromBufferAttribute(r,a),Yr.fromBufferAttribute(r,l),qr.fromBufferAttribute(r,c),u.uv1=ws.getInterpolation(Zr,gs,xs,_s,Xr,Yr,qr,new Pt),u.uv2=u.uv1),o&&(eh.fromBufferAttribute(o,a),nh.fromBufferAttribute(o,l),ih.fromBufferAttribute(o,c),u.normal=ws.getInterpolation(Zr,gs,xs,_s,eh,nh,ih,new F),u.normal.dot(n.direction)>0&&u.normal.multiplyScalar(-1));let f={a,b:l,c,normal:new F,materialIndex:0};ws.getNormal(gs,xs,_s,f.normal),u.face=f}return u}var Yi=class i extends hn{constructor(t=1,e=1,n=1,s=1,r=1,o=1){super(),this.type="BoxGeometry",this.parameters={width:t,height:e,depth:n,widthSegments:s,heightSegments:r,depthSegments:o};let a=this;s=Math.floor(s),r=Math.floor(r),o=Math.floor(o);let l=[],c=[],u=[],f=[],p=0,x=0;y("z","y","x",-1,-1,n,e,t,o,r,0),y("z","y","x",1,-1,n,e,-t,o,r,1),y("x","z","y",1,1,t,n,e,s,o,2),y("x","z","y",1,-1,t,n,-e,s,o,3),y("x","y","z",1,-1,t,e,n,s,r,4),y("x","y","z",-1,-1,t,e,-n,s,r,5),this.setIndex(l),this.setAttribute("position",new Ze(c,3)),this.setAttribute("normal",new Ze(u,3)),this.setAttribute("uv",new Ze(f,2));function y(b,m,d,C,w,U,z,N,L,j,S){let R=U/L,V=z/j,tt=U/2,ft=z/2,I=N/2,k=L+1,G=j+1,K=0,Q=0,$=new F;for(let nt=0;nt<G;nt++){let ct=nt*V-ft;for(let bt=0;bt<k;bt++){let J=bt*R-tt;$[b]=J*C,$[m]=ct*w,$[d]=I,c.push($.x,$.y,$.z),$[b]=0,$[m]=0,$[d]=N>0?1:-1,u.push($.x,$.y,$.z),f.push(bt/L),f.push(1-nt/j),K+=1}}for(let nt=0;nt<j;nt++)for(let ct=0;ct<L;ct++){let bt=p+ct+k*nt,J=p+ct+k*(nt+1),ot=p+(ct+1)+k*(nt+1),vt=p+(ct+1)+k*nt;l.push(bt,J,vt),l.push(J,ot,vt),Q+=6}a.addGroup(x,Q,S),x+=Q,p+=K}}copy(t){return super.copy(t),this.parameters=Object.assign({},t.parameters),this}static fromJSON(t){return new i(t.width,t.height,t.depth,t.widthSegments,t.heightSegments,t.depthSegments)}};function Ds(i){let t={};for(let e in i){t[e]={};for(let n in i[e]){let s=i[e][n];s&&(s.isColor||s.isMatrix3||s.isMatrix4||s.isVector2||s.isVector3||s.isVector4||s.isTexture||s.isQuaternion)?s.isRenderTargetTexture?(console.warn("UniformsUtils: Textures of render targets cannot be cloned via cloneUniforms() or mergeUniforms()."),t[e][n]=null):t[e][n]=s.clone():Array.isArray(s)?t[e][n]=s.slice():t[e][n]=s}}return t}function cn(i){let t={};for(let e=0;e<i.length;e++){let n=Ds(i[e]);for(let s in n)t[s]=n[s]}return t}function $d(i){let t=[];for(let e=0;e<i.length;e++)t.push(i[e].clone());return t}function $h(i){return i.getRenderTarget()===null?i.outputColorSpace:fe.workingColorSpace}var wi={clone:Ds,merge:cn},jd=`void main() {
	gl_Position = projectionMatrix * modelViewMatrix * vec4( position, 1.0 );
}`,Kd=`void main() {
	gl_FragColor = vec4( 1.0, 0.0, 0.0, 1.0 );
}`,Ne=class extends Si{constructor(t){super(),this.isShaderMaterial=!0,this.type="ShaderMaterial",this.defines={},this.uniforms={},this.uniformsGroups=[],this.vertexShader=jd,this.fragmentShader=Kd,this.linewidth=1,this.wireframe=!1,this.wireframeLinewidth=1,this.fog=!1,this.lights=!1,this.clipping=!1,this.forceSinglePass=!0,this.extensions={derivatives:!1,fragDepth:!1,drawBuffers:!1,shaderTextureLOD:!1,clipCullDistance:!1},this.defaultAttributeValues={color:[1,1,1],uv:[0,0],uv1:[0,0]},this.index0AttributeName=void 0,this.uniformsNeedUpdate=!1,this.glslVersion=null,t!==void 0&&this.setValues(t)}copy(t){return super.copy(t),this.fragmentShader=t.fragmentShader,this.vertexShader=t.vertexShader,this.uniforms=Ds(t.uniforms),this.uniformsGroups=$d(t.uniformsGroups),this.defines=Object.assign({},t.defines),this.wireframe=t.wireframe,this.wireframeLinewidth=t.wireframeLinewidth,this.fog=t.fog,this.lights=t.lights,this.clipping=t.clipping,this.extensions=Object.assign({},t.extensions),this.glslVersion=t.glslVersion,this}toJSON(t){let e=super.toJSON(t);e.glslVersion=this.glslVersion,e.uniforms={};for(let s in this.uniforms){let o=this.uniforms[s].value;o&&o.isTexture?e.uniforms[s]={type:"t",value:o.toJSON(t).uuid}:o&&o.isColor?e.uniforms[s]={type:"c",value:o.getHex()}:o&&o.isVector2?e.uniforms[s]={type:"v2",value:o.toArray()}:o&&o.isVector3?e.uniforms[s]={type:"v3",value:o.toArray()}:o&&o.isVector4?e.uniforms[s]={type:"v4",value:o.toArray()}:o&&o.isMatrix3?e.uniforms[s]={type:"m3",value:o.toArray()}:o&&o.isMatrix4?e.uniforms[s]={type:"m4",value:o.toArray()}:e.uniforms[s]={value:o}}Object.keys(this.defines).length>0&&(e.defines=this.defines),e.vertexShader=this.vertexShader,e.fragmentShader=this.fragmentShader,e.lights=this.lights,e.clipping=this.clipping;let n={};for(let s in this.extensions)this.extensions[s]===!0&&(n[s]=!0);return Object.keys(n).length>0&&(e.extensions=n),e}},va=class extends rn{constructor(){super(),this.isCamera=!0,this.type="Camera",this.matrixWorldInverse=new ve,this.projectionMatrix=new ve,this.projectionMatrixInverse=new ve,this.coordinateSystem=ni}copy(t,e){return super.copy(t,e),this.matrixWorldInverse.copy(t.matrixWorldInverse),this.projectionMatrix.copy(t.projectionMatrix),this.projectionMatrixInverse.copy(t.projectionMatrixInverse),this.coordinateSystem=t.coordinateSystem,this}getWorldDirection(t){return super.getWorldDirection(t).negate()}updateMatrixWorld(t){super.updateMatrixWorld(t),this.matrixWorldInverse.copy(this.matrixWorld).invert()}updateWorldMatrix(t,e){super.updateWorldMatrix(t,e),this.matrixWorldInverse.copy(this.matrixWorld).invert()}clone(){return new this.constructor().copy(this)}},en=class extends va{constructor(t=50,e=1,n=.1,s=2e3){super(),this.isPerspectiveCamera=!0,this.type="PerspectiveCamera",this.fov=t,this.zoom=1,this.near=n,this.far=s,this.focus=10,this.aspect=e,this.view=null,this.filmGauge=35,this.filmOffset=0,this.updateProjectionMatrix()}copy(t,e){return super.copy(t,e),this.fov=t.fov,this.zoom=t.zoom,this.near=t.near,this.far=t.far,this.focus=t.focus,this.aspect=t.aspect,this.view=t.view===null?null:Object.assign({},t.view),this.filmGauge=t.filmGauge,this.filmOffset=t.filmOffset,this}setFocalLength(t){let e=.5*this.getFilmHeight()/t;this.fov=hr*2*Math.atan(e),this.updateProjectionMatrix()}getFocalLength(){let t=Math.tan(sr*.5*this.fov);return .5*this.getFilmHeight()/t}getEffectiveFOV(){return hr*2*Math.atan(Math.tan(sr*.5*this.fov)/this.zoom)}getFilmWidth(){return this.filmGauge*Math.min(this.aspect,1)}getFilmHeight(){return this.filmGauge/Math.max(this.aspect,1)}setViewOffset(t,e,n,s,r,o){this.aspect=t/e,this.view===null&&(this.view={enabled:!0,fullWidth:1,fullHeight:1,offsetX:0,offsetY:0,width:1,height:1}),this.view.enabled=!0,this.view.fullWidth=t,this.view.fullHeight=e,this.view.offsetX=n,this.view.offsetY=s,this.view.width=r,this.view.height=o,this.updateProjectionMatrix()}clearViewOffset(){this.view!==null&&(this.view.enabled=!1),this.updateProjectionMatrix()}updateProjectionMatrix(){let t=this.near,e=t*Math.tan(sr*.5*this.fov)/this.zoom,n=2*e,s=this.aspect*n,r=-.5*s,o=this.view;if(this.view!==null&&this.view.enabled){let l=o.fullWidth,c=o.fullHeight;r+=o.offsetX*s/l,e-=o.offsetY*n/c,s*=o.width/l,n*=o.height/c}let a=this.filmOffset;a!==0&&(r+=t*a/this.getFilmWidth()),this.projectionMatrix.makePerspective(r,r+s,e,e-n,t,this.far,this.coordinateSystem),this.projectionMatrixInverse.copy(this.projectionMatrix).invert()}toJSON(t){let e=super.toJSON(t);return e.object.fov=this.fov,e.object.zoom=this.zoom,e.object.near=this.near,e.object.far=this.far,e.object.focus=this.focus,e.object.aspect=this.aspect,this.view!==null&&(e.object.view=Object.assign({},this.view)),e.object.filmGauge=this.filmGauge,e.object.filmOffset=this.filmOffset,e}},vs=-90,ys=1,Zo=class extends rn{constructor(t,e,n){super(),this.type="CubeCamera",this.renderTarget=n,this.coordinateSystem=null,this.activeMipmapLevel=0;let s=new en(vs,ys,t,e);s.layers=this.layers,this.add(s);let r=new en(vs,ys,t,e);r.layers=this.layers,this.add(r);let o=new en(vs,ys,t,e);o.layers=this.layers,this.add(o);let a=new en(vs,ys,t,e);a.layers=this.layers,this.add(a);let l=new en(vs,ys,t,e);l.layers=this.layers,this.add(l);let c=new en(vs,ys,t,e);c.layers=this.layers,this.add(c)}updateCoordinateSystem(){let t=this.coordinateSystem,e=this.children.concat(),[n,s,r,o,a,l]=e;for(let c of e)this.remove(c);if(t===ni)n.up.set(0,1,0),n.lookAt(1,0,0),s.up.set(0,1,0),s.lookAt(-1,0,0),r.up.set(0,0,-1),r.lookAt(0,1,0),o.up.set(0,0,1),o.lookAt(0,-1,0),a.up.set(0,1,0),a.lookAt(0,0,1),l.up.set(0,1,0),l.lookAt(0,0,-1);else if(t===ha)n.up.set(0,-1,0),n.lookAt(-1,0,0),s.up.set(0,-1,0),s.lookAt(1,0,0),r.up.set(0,0,1),r.lookAt(0,1,0),o.up.set(0,0,-1),o.lookAt(0,-1,0),a.up.set(0,-1,0),a.lookAt(0,0,1),l.up.set(0,-1,0),l.lookAt(0,0,-1);else throw new Error("THREE.CubeCamera.updateCoordinateSystem(): Invalid coordinate system: "+t);for(let c of e)this.add(c),c.updateMatrixWorld()}update(t,e){this.parent===null&&this.updateMatrixWorld();let{renderTarget:n,activeMipmapLevel:s}=this;this.coordinateSystem!==t.coordinateSystem&&(this.coordinateSystem=t.coordinateSystem,this.updateCoordinateSystem());let[r,o,a,l,c,u]=this.children,f=t.getRenderTarget(),p=t.getActiveCubeFace(),x=t.getActiveMipmapLevel(),y=t.xr.enabled;t.xr.enabled=!1;let b=n.texture.generateMipmaps;n.texture.generateMipmaps=!1,t.setRenderTarget(n,0,s),t.render(e,r),t.setRenderTarget(n,1,s),t.render(e,o),t.setRenderTarget(n,2,s),t.render(e,a),t.setRenderTarget(n,3,s),t.render(e,l),t.setRenderTarget(n,4,s),t.render(e,c),n.texture.generateMipmaps=b,t.setRenderTarget(n,5,s),t.render(e,u),t.setRenderTarget(f,p,x),t.xr.enabled=y,n.texture.needsPMREMUpdate=!0}},ya=class extends bn{constructor(t,e,n,s,r,o,a,l,c,u){t=t!==void 0?t:[],e=e!==void 0?e:Ps,super(t,e,n,s,r,o,a,l,c,u),this.isCubeTexture=!0,this.flipY=!1}get images(){return this.image}set images(t){this.image=t}},Jo=class extends je{constructor(t=1,e={}){super(t,t,e),this.isWebGLCubeRenderTarget=!0;let n={width:t,height:t,depth:1},s=[n,n,n,n,n,n];e.encoding!==void 0&&(ar("THREE.WebGLCubeRenderTarget: option.encoding has been replaced by option.colorSpace."),e.colorSpace=e.encoding===Wi?Re:Mn),this.texture=new ya(s,e.mapping,e.wrapS,e.wrapT,e.magFilter,e.minFilter,e.format,e.type,e.anisotropy,e.colorSpace),this.texture.isRenderTargetTexture=!0,this.texture.generateMipmaps=e.generateMipmaps!==void 0?e.generateMipmaps:!1,this.texture.minFilter=e.minFilter!==void 0?e.minFilter:yn}fromEquirectangularTexture(t,e){this.texture.type=e.type,this.texture.colorSpace=e.colorSpace,this.texture.generateMipmaps=e.generateMipmaps,this.texture.minFilter=e.minFilter,this.texture.magFilter=e.magFilter;let n={uniforms:{tEquirect:{value:null}},vertexShader:`

				varying vec3 vWorldDirection;

				vec3 transformDirection( in vec3 dir, in mat4 matrix ) {

					return normalize( ( matrix * vec4( dir, 0.0 ) ).xyz );

				}

				void main() {

					vWorldDirection = transformDirection( position, modelMatrix );

					#include <begin_vertex>
					#include <project_vertex>

				}
			`,fragmentShader:`

				uniform sampler2D tEquirect;

				varying vec3 vWorldDirection;

				#include <common>

				void main() {

					vec3 direction = normalize( vWorldDirection );

					vec2 sampleUV = equirectUv( direction );

					gl_FragColor = texture2D( tEquirect, sampleUV );

				}
			`},s=new Yi(5,5,5),r=new Ne({name:"CubemapFromEquirect",uniforms:Ds(n.uniforms),vertexShader:n.vertexShader,fragmentShader:n.fragmentShader,side:nn,blending:Wn});r.uniforms.tEquirect.value=e;let o=new ke(s,r),a=e.minFilter;return e.minFilter===cr&&(e.minFilter=yn),new Zo(1,10,this).update(t,o),e.minFilter=a,o.geometry.dispose(),o.material.dispose(),this}clear(t,e,n,s){let r=t.getRenderTarget();for(let o=0;o<6;o++)t.setRenderTarget(this,o),t.clear(e,n,s);t.setRenderTarget(r)}},Lo=new F,Qd=new F,tf=new re,Ln=class{constructor(t=new F(1,0,0),e=0){this.isPlane=!0,this.normal=t,this.constant=e}set(t,e){return this.normal.copy(t),this.constant=e,this}setComponents(t,e,n,s){return this.normal.set(t,e,n),this.constant=s,this}setFromNormalAndCoplanarPoint(t,e){return this.normal.copy(t),this.constant=-e.dot(this.normal),this}setFromCoplanarPoints(t,e,n){let s=Lo.subVectors(n,e).cross(Qd.subVectors(t,e)).normalize();return this.setFromNormalAndCoplanarPoint(s,t),this}copy(t){return this.normal.copy(t.normal),this.constant=t.constant,this}normalize(){let t=1/this.normal.length();return this.normal.multiplyScalar(t),this.constant*=t,this}negate(){return this.constant*=-1,this.normal.negate(),this}distanceToPoint(t){return this.normal.dot(t)+this.constant}distanceToSphere(t){return this.distanceToPoint(t.center)-t.radius}projectPoint(t,e){return e.copy(t).addScaledVector(this.normal,-this.distanceToPoint(t))}intersectLine(t,e){let n=t.delta(Lo),s=this.normal.dot(n);if(s===0)return this.distanceToPoint(t.start)===0?e.copy(t.start):null;let r=-(t.start.dot(this.normal)+this.constant)/s;return r<0||r>1?null:e.copy(t.start).addScaledVector(n,r)}intersectsLine(t){let e=this.distanceToPoint(t.start),n=this.distanceToPoint(t.end);return e<0&&n>0||n<0&&e>0}intersectsBox(t){return t.intersectsPlane(this)}intersectsSphere(t){return t.intersectsPlane(this)}coplanarPoint(t){return t.copy(this.normal).multiplyScalar(-this.constant)}applyMatrix4(t,e){let n=e||tf.getNormalMatrix(t),s=this.coplanarPoint(Lo).applyMatrix4(t),r=this.normal.applyMatrix3(n).normalize();return this.constant=-s.dot(r),this}translate(t){return this.constant-=t.dot(this.normal),this}equals(t){return t.normal.equals(this.normal)&&t.constant===this.constant}clone(){return new this.constructor().copy(this)}},Bi=new bi,jr=new F,dr=class{constructor(t=new Ln,e=new Ln,n=new Ln,s=new Ln,r=new Ln,o=new Ln){this.planes=[t,e,n,s,r,o]}set(t,e,n,s,r,o){let a=this.planes;return a[0].copy(t),a[1].copy(e),a[2].copy(n),a[3].copy(s),a[4].copy(r),a[5].copy(o),this}copy(t){let e=this.planes;for(let n=0;n<6;n++)e[n].copy(t.planes[n]);return this}setFromProjectionMatrix(t,e=ni){let n=this.planes,s=t.elements,r=s[0],o=s[1],a=s[2],l=s[3],c=s[4],u=s[5],f=s[6],p=s[7],x=s[8],y=s[9],b=s[10],m=s[11],d=s[12],C=s[13],w=s[14],U=s[15];if(n[0].setComponents(l-r,p-c,m-x,U-d).normalize(),n[1].setComponents(l+r,p+c,m+x,U+d).normalize(),n[2].setComponents(l+o,p+u,m+y,U+C).normalize(),n[3].setComponents(l-o,p-u,m-y,U-C).normalize(),n[4].setComponents(l-a,p-f,m-b,U-w).normalize(),e===ni)n[5].setComponents(l+a,p+f,m+b,U+w).normalize();else if(e===ha)n[5].setComponents(a,f,b,w).normalize();else throw new Error("THREE.Frustum.setFromProjectionMatrix(): Invalid coordinate system: "+e);return this}intersectsObject(t){if(t.boundingSphere!==void 0)t.boundingSphere===null&&t.computeBoundingSphere(),Bi.copy(t.boundingSphere).applyMatrix4(t.matrixWorld);else{let e=t.geometry;e.boundingSphere===null&&e.computeBoundingSphere(),Bi.copy(e.boundingSphere).applyMatrix4(t.matrixWorld)}return this.intersectsSphere(Bi)}intersectsSprite(t){return Bi.center.set(0,0,0),Bi.radius=.7071067811865476,Bi.applyMatrix4(t.matrixWorld),this.intersectsSphere(Bi)}intersectsSphere(t){let e=this.planes,n=t.center,s=-t.radius;for(let r=0;r<6;r++)if(e[r].distanceToPoint(n)<s)return!1;return!0}intersectsBox(t){let e=this.planes;for(let n=0;n<6;n++){let s=e[n];if(jr.x=s.normal.x>0?t.max.x:t.min.x,jr.y=s.normal.y>0?t.max.y:t.min.y,jr.z=s.normal.z>0?t.max.z:t.min.z,s.distanceToPoint(jr)<0)return!1}return!0}containsPoint(t){let e=this.planes;for(let n=0;n<6;n++)if(e[n].distanceToPoint(t)<0)return!1;return!0}clone(){return new this.constructor().copy(this)}};function jh(){let i=null,t=!1,e=null,n=null;function s(r,o){e(r,o),n=i.requestAnimationFrame(s)}return{start:function(){t!==!0&&e!==null&&(n=i.requestAnimationFrame(s),t=!0)},stop:function(){i.cancelAnimationFrame(n),t=!1},setAnimationLoop:function(r){e=r},setContext:function(r){i=r}}}function ef(i,t){let e=t.isWebGL2,n=new WeakMap;function s(c,u){let f=c.array,p=c.usage,x=f.byteLength,y=i.createBuffer();i.bindBuffer(u,y),i.bufferData(u,f,p),c.onUploadCallback();let b;if(f instanceof Float32Array)b=i.FLOAT;else if(f instanceof Uint16Array)if(c.isFloat16BufferAttribute)if(e)b=i.HALF_FLOAT;else throw new Error("THREE.WebGLAttributes: Usage of Float16BufferAttribute requires WebGL2.");else b=i.UNSIGNED_SHORT;else if(f instanceof Int16Array)b=i.SHORT;else if(f instanceof Uint32Array)b=i.UNSIGNED_INT;else if(f instanceof Int32Array)b=i.INT;else if(f instanceof Int8Array)b=i.BYTE;else if(f instanceof Uint8Array)b=i.UNSIGNED_BYTE;else if(f instanceof Uint8ClampedArray)b=i.UNSIGNED_BYTE;else throw new Error("THREE.WebGLAttributes: Unsupported buffer data format: "+f);return{buffer:y,type:b,bytesPerElement:f.BYTES_PER_ELEMENT,version:c.version,size:x}}function r(c,u,f){let p=u.array,x=u._updateRange,y=u.updateRanges;if(i.bindBuffer(f,c),x.count===-1&&y.length===0&&i.bufferSubData(f,0,p),y.length!==0){for(let b=0,m=y.length;b<m;b++){let d=y[b];e?i.bufferSubData(f,d.start*p.BYTES_PER_ELEMENT,p,d.start,d.count):i.bufferSubData(f,d.start*p.BYTES_PER_ELEMENT,p.subarray(d.start,d.start+d.count))}u.clearUpdateRanges()}x.count!==-1&&(e?i.bufferSubData(f,x.offset*p.BYTES_PER_ELEMENT,p,x.offset,x.count):i.bufferSubData(f,x.offset*p.BYTES_PER_ELEMENT,p.subarray(x.offset,x.offset+x.count)),x.count=-1),u.onUploadCallback()}function o(c){return c.isInterleavedBufferAttribute&&(c=c.data),n.get(c)}function a(c){c.isInterleavedBufferAttribute&&(c=c.data);let u=n.get(c);u&&(i.deleteBuffer(u.buffer),n.delete(c))}function l(c,u){if(c.isGLBufferAttribute){let p=n.get(c);(!p||p.version<c.version)&&n.set(c,{buffer:c.buffer,type:c.type,bytesPerElement:c.elementSize,version:c.version});return}c.isInterleavedBufferAttribute&&(c=c.data);let f=n.get(c);if(f===void 0)n.set(c,s(c,u));else if(f.version<c.version){if(f.size!==c.array.byteLength)throw new Error("THREE.WebGLAttributes: The size of the buffer attribute's array buffer does not match the original size. Resizing buffer attributes is not supported.");r(f.buffer,c,u),f.version=c.version}}return{get:o,remove:a,update:l}}var fr=class i extends hn{constructor(t=1,e=1,n=1,s=1){super(),this.type="PlaneGeometry",this.parameters={width:t,height:e,widthSegments:n,heightSegments:s};let r=t/2,o=e/2,a=Math.floor(n),l=Math.floor(s),c=a+1,u=l+1,f=t/a,p=e/l,x=[],y=[],b=[],m=[];for(let d=0;d<u;d++){let C=d*p-o;for(let w=0;w<c;w++){let U=w*f-r;y.push(U,-C,0),b.push(0,0,1),m.push(w/a),m.push(1-d/l)}}for(let d=0;d<l;d++)for(let C=0;C<a;C++){let w=C+c*d,U=C+c*(d+1),z=C+1+c*(d+1),N=C+1+c*d;x.push(w,U,N),x.push(U,z,N)}this.setIndex(x),this.setAttribute("position",new Ze(y,3)),this.setAttribute("normal",new Ze(b,3)),this.setAttribute("uv",new Ze(m,2))}copy(t){return super.copy(t),this.parameters=Object.assign({},t.parameters),this}static fromJSON(t){return new i(t.width,t.height,t.widthSegments,t.heightSegments)}},nf=`#ifdef USE_ALPHAHASH
	if ( diffuseColor.a < getAlphaHashThreshold( vPosition ) ) discard;
#endif`,sf=`#ifdef USE_ALPHAHASH
	const float ALPHA_HASH_SCALE = 0.05;
	float hash2D( vec2 value ) {
		return fract( 1.0e4 * sin( 17.0 * value.x + 0.1 * value.y ) * ( 0.1 + abs( sin( 13.0 * value.y + value.x ) ) ) );
	}
	float hash3D( vec3 value ) {
		return hash2D( vec2( hash2D( value.xy ), value.z ) );
	}
	float getAlphaHashThreshold( vec3 position ) {
		float maxDeriv = max(
			length( dFdx( position.xyz ) ),
			length( dFdy( position.xyz ) )
		);
		float pixScale = 1.0 / ( ALPHA_HASH_SCALE * maxDeriv );
		vec2 pixScales = vec2(
			exp2( floor( log2( pixScale ) ) ),
			exp2( ceil( log2( pixScale ) ) )
		);
		vec2 alpha = vec2(
			hash3D( floor( pixScales.x * position.xyz ) ),
			hash3D( floor( pixScales.y * position.xyz ) )
		);
		float lerpFactor = fract( log2( pixScale ) );
		float x = ( 1.0 - lerpFactor ) * alpha.x + lerpFactor * alpha.y;
		float a = min( lerpFactor, 1.0 - lerpFactor );
		vec3 cases = vec3(
			x * x / ( 2.0 * a * ( 1.0 - a ) ),
			( x - 0.5 * a ) / ( 1.0 - a ),
			1.0 - ( ( 1.0 - x ) * ( 1.0 - x ) / ( 2.0 * a * ( 1.0 - a ) ) )
		);
		float threshold = ( x < ( 1.0 - a ) )
			? ( ( x < a ) ? cases.x : cases.y )
			: cases.z;
		return clamp( threshold , 1.0e-6, 1.0 );
	}
#endif`,rf=`#ifdef USE_ALPHAMAP
	diffuseColor.a *= texture2D( alphaMap, vAlphaMapUv ).g;
#endif`,af=`#ifdef USE_ALPHAMAP
	uniform sampler2D alphaMap;
#endif`,of=`#ifdef USE_ALPHATEST
	if ( diffuseColor.a < alphaTest ) discard;
#endif`,lf=`#ifdef USE_ALPHATEST
	uniform float alphaTest;
#endif`,cf=`#ifdef USE_AOMAP
	float ambientOcclusion = ( texture2D( aoMap, vAoMapUv ).r - 1.0 ) * aoMapIntensity + 1.0;
	reflectedLight.indirectDiffuse *= ambientOcclusion;
	#if defined( USE_CLEARCOAT ) 
		clearcoatSpecularIndirect *= ambientOcclusion;
	#endif
	#if defined( USE_SHEEN ) 
		sheenSpecularIndirect *= ambientOcclusion;
	#endif
	#if defined( USE_ENVMAP ) && defined( STANDARD )
		float dotNV = saturate( dot( geometryNormal, geometryViewDir ) );
		reflectedLight.indirectSpecular *= computeSpecularOcclusion( dotNV, ambientOcclusion, material.roughness );
	#endif
#endif`,hf=`#ifdef USE_AOMAP
	uniform sampler2D aoMap;
	uniform float aoMapIntensity;
#endif`,uf=`#ifdef USE_BATCHING
	attribute float batchId;
	uniform highp sampler2D batchingTexture;
	mat4 getBatchingMatrix( const in float i ) {
		int size = textureSize( batchingTexture, 0 ).x;
		int j = int( i ) * 4;
		int x = j % size;
		int y = j / size;
		vec4 v1 = texelFetch( batchingTexture, ivec2( x, y ), 0 );
		vec4 v2 = texelFetch( batchingTexture, ivec2( x + 1, y ), 0 );
		vec4 v3 = texelFetch( batchingTexture, ivec2( x + 2, y ), 0 );
		vec4 v4 = texelFetch( batchingTexture, ivec2( x + 3, y ), 0 );
		return mat4( v1, v2, v3, v4 );
	}
#endif`,df=`#ifdef USE_BATCHING
	mat4 batchingMatrix = getBatchingMatrix( batchId );
#endif`,ff=`vec3 transformed = vec3( position );
#ifdef USE_ALPHAHASH
	vPosition = vec3( position );
#endif`,pf=`vec3 objectNormal = vec3( normal );
#ifdef USE_TANGENT
	vec3 objectTangent = vec3( tangent.xyz );
#endif`,mf=`float G_BlinnPhong_Implicit( ) {
	return 0.25;
}
float D_BlinnPhong( const in float shininess, const in float dotNH ) {
	return RECIPROCAL_PI * ( shininess * 0.5 + 1.0 ) * pow( dotNH, shininess );
}
vec3 BRDF_BlinnPhong( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, const in vec3 specularColor, const in float shininess ) {
	vec3 halfDir = normalize( lightDir + viewDir );
	float dotNH = saturate( dot( normal, halfDir ) );
	float dotVH = saturate( dot( viewDir, halfDir ) );
	vec3 F = F_Schlick( specularColor, 1.0, dotVH );
	float G = G_BlinnPhong_Implicit( );
	float D = D_BlinnPhong( shininess, dotNH );
	return F * ( G * D );
} // validated`,gf=`#ifdef USE_IRIDESCENCE
	const mat3 XYZ_TO_REC709 = mat3(
		 3.2404542, -0.9692660,  0.0556434,
		-1.5371385,  1.8760108, -0.2040259,
		-0.4985314,  0.0415560,  1.0572252
	);
	vec3 Fresnel0ToIor( vec3 fresnel0 ) {
		vec3 sqrtF0 = sqrt( fresnel0 );
		return ( vec3( 1.0 ) + sqrtF0 ) / ( vec3( 1.0 ) - sqrtF0 );
	}
	vec3 IorToFresnel0( vec3 transmittedIor, float incidentIor ) {
		return pow2( ( transmittedIor - vec3( incidentIor ) ) / ( transmittedIor + vec3( incidentIor ) ) );
	}
	float IorToFresnel0( float transmittedIor, float incidentIor ) {
		return pow2( ( transmittedIor - incidentIor ) / ( transmittedIor + incidentIor ));
	}
	vec3 evalSensitivity( float OPD, vec3 shift ) {
		float phase = 2.0 * PI * OPD * 1.0e-9;
		vec3 val = vec3( 5.4856e-13, 4.4201e-13, 5.2481e-13 );
		vec3 pos = vec3( 1.6810e+06, 1.7953e+06, 2.2084e+06 );
		vec3 var = vec3( 4.3278e+09, 9.3046e+09, 6.6121e+09 );
		vec3 xyz = val * sqrt( 2.0 * PI * var ) * cos( pos * phase + shift ) * exp( - pow2( phase ) * var );
		xyz.x += 9.7470e-14 * sqrt( 2.0 * PI * 4.5282e+09 ) * cos( 2.2399e+06 * phase + shift[ 0 ] ) * exp( - 4.5282e+09 * pow2( phase ) );
		xyz /= 1.0685e-7;
		vec3 rgb = XYZ_TO_REC709 * xyz;
		return rgb;
	}
	vec3 evalIridescence( float outsideIOR, float eta2, float cosTheta1, float thinFilmThickness, vec3 baseF0 ) {
		vec3 I;
		float iridescenceIOR = mix( outsideIOR, eta2, smoothstep( 0.0, 0.03, thinFilmThickness ) );
		float sinTheta2Sq = pow2( outsideIOR / iridescenceIOR ) * ( 1.0 - pow2( cosTheta1 ) );
		float cosTheta2Sq = 1.0 - sinTheta2Sq;
		if ( cosTheta2Sq < 0.0 ) {
			return vec3( 1.0 );
		}
		float cosTheta2 = sqrt( cosTheta2Sq );
		float R0 = IorToFresnel0( iridescenceIOR, outsideIOR );
		float R12 = F_Schlick( R0, 1.0, cosTheta1 );
		float T121 = 1.0 - R12;
		float phi12 = 0.0;
		if ( iridescenceIOR < outsideIOR ) phi12 = PI;
		float phi21 = PI - phi12;
		vec3 baseIOR = Fresnel0ToIor( clamp( baseF0, 0.0, 0.9999 ) );		vec3 R1 = IorToFresnel0( baseIOR, iridescenceIOR );
		vec3 R23 = F_Schlick( R1, 1.0, cosTheta2 );
		vec3 phi23 = vec3( 0.0 );
		if ( baseIOR[ 0 ] < iridescenceIOR ) phi23[ 0 ] = PI;
		if ( baseIOR[ 1 ] < iridescenceIOR ) phi23[ 1 ] = PI;
		if ( baseIOR[ 2 ] < iridescenceIOR ) phi23[ 2 ] = PI;
		float OPD = 2.0 * iridescenceIOR * thinFilmThickness * cosTheta2;
		vec3 phi = vec3( phi21 ) + phi23;
		vec3 R123 = clamp( R12 * R23, 1e-5, 0.9999 );
		vec3 r123 = sqrt( R123 );
		vec3 Rs = pow2( T121 ) * R23 / ( vec3( 1.0 ) - R123 );
		vec3 C0 = R12 + Rs;
		I = C0;
		vec3 Cm = Rs - T121;
		for ( int m = 1; m <= 2; ++ m ) {
			Cm *= r123;
			vec3 Sm = 2.0 * evalSensitivity( float( m ) * OPD, float( m ) * phi );
			I += Cm * Sm;
		}
		return max( I, vec3( 0.0 ) );
	}
#endif`,xf=`#ifdef USE_BUMPMAP
	uniform sampler2D bumpMap;
	uniform float bumpScale;
	vec2 dHdxy_fwd() {
		vec2 dSTdx = dFdx( vBumpMapUv );
		vec2 dSTdy = dFdy( vBumpMapUv );
		float Hll = bumpScale * texture2D( bumpMap, vBumpMapUv ).x;
		float dBx = bumpScale * texture2D( bumpMap, vBumpMapUv + dSTdx ).x - Hll;
		float dBy = bumpScale * texture2D( bumpMap, vBumpMapUv + dSTdy ).x - Hll;
		return vec2( dBx, dBy );
	}
	vec3 perturbNormalArb( vec3 surf_pos, vec3 surf_norm, vec2 dHdxy, float faceDirection ) {
		vec3 vSigmaX = normalize( dFdx( surf_pos.xyz ) );
		vec3 vSigmaY = normalize( dFdy( surf_pos.xyz ) );
		vec3 vN = surf_norm;
		vec3 R1 = cross( vSigmaY, vN );
		vec3 R2 = cross( vN, vSigmaX );
		float fDet = dot( vSigmaX, R1 ) * faceDirection;
		vec3 vGrad = sign( fDet ) * ( dHdxy.x * R1 + dHdxy.y * R2 );
		return normalize( abs( fDet ) * surf_norm - vGrad );
	}
#endif`,_f=`#if NUM_CLIPPING_PLANES > 0
	vec4 plane;
	#pragma unroll_loop_start
	for ( int i = 0; i < UNION_CLIPPING_PLANES; i ++ ) {
		plane = clippingPlanes[ i ];
		if ( dot( vClipPosition, plane.xyz ) > plane.w ) discard;
	}
	#pragma unroll_loop_end
	#if UNION_CLIPPING_PLANES < NUM_CLIPPING_PLANES
		bool clipped = true;
		#pragma unroll_loop_start
		for ( int i = UNION_CLIPPING_PLANES; i < NUM_CLIPPING_PLANES; i ++ ) {
			plane = clippingPlanes[ i ];
			clipped = ( dot( vClipPosition, plane.xyz ) > plane.w ) && clipped;
		}
		#pragma unroll_loop_end
		if ( clipped ) discard;
	#endif
#endif`,vf=`#if NUM_CLIPPING_PLANES > 0
	varying vec3 vClipPosition;
	uniform vec4 clippingPlanes[ NUM_CLIPPING_PLANES ];
#endif`,yf=`#if NUM_CLIPPING_PLANES > 0
	varying vec3 vClipPosition;
#endif`,Mf=`#if NUM_CLIPPING_PLANES > 0
	vClipPosition = - mvPosition.xyz;
#endif`,bf=`#if defined( USE_COLOR_ALPHA )
	diffuseColor *= vColor;
#elif defined( USE_COLOR )
	diffuseColor.rgb *= vColor;
#endif`,Sf=`#if defined( USE_COLOR_ALPHA )
	varying vec4 vColor;
#elif defined( USE_COLOR )
	varying vec3 vColor;
#endif`,wf=`#if defined( USE_COLOR_ALPHA )
	varying vec4 vColor;
#elif defined( USE_COLOR ) || defined( USE_INSTANCING_COLOR )
	varying vec3 vColor;
#endif`,Ef=`#if defined( USE_COLOR_ALPHA )
	vColor = vec4( 1.0 );
#elif defined( USE_COLOR ) || defined( USE_INSTANCING_COLOR )
	vColor = vec3( 1.0 );
#endif
#ifdef USE_COLOR
	vColor *= color;
#endif
#ifdef USE_INSTANCING_COLOR
	vColor.xyz *= instanceColor.xyz;
#endif`,Tf=`#define PI 3.141592653589793
#define PI2 6.283185307179586
#define PI_HALF 1.5707963267948966
#define RECIPROCAL_PI 0.3183098861837907
#define RECIPROCAL_PI2 0.15915494309189535
#define EPSILON 1e-6
#ifndef saturate
#define saturate( a ) clamp( a, 0.0, 1.0 )
#endif
#define whiteComplement( a ) ( 1.0 - saturate( a ) )
float pow2( const in float x ) { return x*x; }
vec3 pow2( const in vec3 x ) { return x*x; }
float pow3( const in float x ) { return x*x*x; }
float pow4( const in float x ) { float x2 = x*x; return x2*x2; }
float max3( const in vec3 v ) { return max( max( v.x, v.y ), v.z ); }
float average( const in vec3 v ) { return dot( v, vec3( 0.3333333 ) ); }
highp float rand( const in vec2 uv ) {
	const highp float a = 12.9898, b = 78.233, c = 43758.5453;
	highp float dt = dot( uv.xy, vec2( a,b ) ), sn = mod( dt, PI );
	return fract( sin( sn ) * c );
}
#ifdef HIGH_PRECISION
	float precisionSafeLength( vec3 v ) { return length( v ); }
#else
	float precisionSafeLength( vec3 v ) {
		float maxComponent = max3( abs( v ) );
		return length( v / maxComponent ) * maxComponent;
	}
#endif
struct IncidentLight {
	vec3 color;
	vec3 direction;
	bool visible;
};
struct ReflectedLight {
	vec3 directDiffuse;
	vec3 directSpecular;
	vec3 indirectDiffuse;
	vec3 indirectSpecular;
};
#ifdef USE_ALPHAHASH
	varying vec3 vPosition;
#endif
vec3 transformDirection( in vec3 dir, in mat4 matrix ) {
	return normalize( ( matrix * vec4( dir, 0.0 ) ).xyz );
}
vec3 inverseTransformDirection( in vec3 dir, in mat4 matrix ) {
	return normalize( ( vec4( dir, 0.0 ) * matrix ).xyz );
}
mat3 transposeMat3( const in mat3 m ) {
	mat3 tmp;
	tmp[ 0 ] = vec3( m[ 0 ].x, m[ 1 ].x, m[ 2 ].x );
	tmp[ 1 ] = vec3( m[ 0 ].y, m[ 1 ].y, m[ 2 ].y );
	tmp[ 2 ] = vec3( m[ 0 ].z, m[ 1 ].z, m[ 2 ].z );
	return tmp;
}
float luminance( const in vec3 rgb ) {
	const vec3 weights = vec3( 0.2126729, 0.7151522, 0.0721750 );
	return dot( weights, rgb );
}
bool isPerspectiveMatrix( mat4 m ) {
	return m[ 2 ][ 3 ] == - 1.0;
}
vec2 equirectUv( in vec3 dir ) {
	float u = atan( dir.z, dir.x ) * RECIPROCAL_PI2 + 0.5;
	float v = asin( clamp( dir.y, - 1.0, 1.0 ) ) * RECIPROCAL_PI + 0.5;
	return vec2( u, v );
}
vec3 BRDF_Lambert( const in vec3 diffuseColor ) {
	return RECIPROCAL_PI * diffuseColor;
}
vec3 F_Schlick( const in vec3 f0, const in float f90, const in float dotVH ) {
	float fresnel = exp2( ( - 5.55473 * dotVH - 6.98316 ) * dotVH );
	return f0 * ( 1.0 - fresnel ) + ( f90 * fresnel );
}
float F_Schlick( const in float f0, const in float f90, const in float dotVH ) {
	float fresnel = exp2( ( - 5.55473 * dotVH - 6.98316 ) * dotVH );
	return f0 * ( 1.0 - fresnel ) + ( f90 * fresnel );
} // validated`,Af=`#ifdef ENVMAP_TYPE_CUBE_UV
	#define cubeUV_minMipLevel 4.0
	#define cubeUV_minTileSize 16.0
	float getFace( vec3 direction ) {
		vec3 absDirection = abs( direction );
		float face = - 1.0;
		if ( absDirection.x > absDirection.z ) {
			if ( absDirection.x > absDirection.y )
				face = direction.x > 0.0 ? 0.0 : 3.0;
			else
				face = direction.y > 0.0 ? 1.0 : 4.0;
		} else {
			if ( absDirection.z > absDirection.y )
				face = direction.z > 0.0 ? 2.0 : 5.0;
			else
				face = direction.y > 0.0 ? 1.0 : 4.0;
		}
		return face;
	}
	vec2 getUV( vec3 direction, float face ) {
		vec2 uv;
		if ( face == 0.0 ) {
			uv = vec2( direction.z, direction.y ) / abs( direction.x );
		} else if ( face == 1.0 ) {
			uv = vec2( - direction.x, - direction.z ) / abs( direction.y );
		} else if ( face == 2.0 ) {
			uv = vec2( - direction.x, direction.y ) / abs( direction.z );
		} else if ( face == 3.0 ) {
			uv = vec2( - direction.z, direction.y ) / abs( direction.x );
		} else if ( face == 4.0 ) {
			uv = vec2( - direction.x, direction.z ) / abs( direction.y );
		} else {
			uv = vec2( direction.x, direction.y ) / abs( direction.z );
		}
		return 0.5 * ( uv + 1.0 );
	}
	vec3 bilinearCubeUV( sampler2D envMap, vec3 direction, float mipInt ) {
		float face = getFace( direction );
		float filterInt = max( cubeUV_minMipLevel - mipInt, 0.0 );
		mipInt = max( mipInt, cubeUV_minMipLevel );
		float faceSize = exp2( mipInt );
		highp vec2 uv = getUV( direction, face ) * ( faceSize - 2.0 ) + 1.0;
		if ( face > 2.0 ) {
			uv.y += faceSize;
			face -= 3.0;
		}
		uv.x += face * faceSize;
		uv.x += filterInt * 3.0 * cubeUV_minTileSize;
		uv.y += 4.0 * ( exp2( CUBEUV_MAX_MIP ) - faceSize );
		uv.x *= CUBEUV_TEXEL_WIDTH;
		uv.y *= CUBEUV_TEXEL_HEIGHT;
		#ifdef texture2DGradEXT
			return texture2DGradEXT( envMap, uv, vec2( 0.0 ), vec2( 0.0 ) ).rgb;
		#else
			return texture2D( envMap, uv ).rgb;
		#endif
	}
	#define cubeUV_r0 1.0
	#define cubeUV_m0 - 2.0
	#define cubeUV_r1 0.8
	#define cubeUV_m1 - 1.0
	#define cubeUV_r4 0.4
	#define cubeUV_m4 2.0
	#define cubeUV_r5 0.305
	#define cubeUV_m5 3.0
	#define cubeUV_r6 0.21
	#define cubeUV_m6 4.0
	float roughnessToMip( float roughness ) {
		float mip = 0.0;
		if ( roughness >= cubeUV_r1 ) {
			mip = ( cubeUV_r0 - roughness ) * ( cubeUV_m1 - cubeUV_m0 ) / ( cubeUV_r0 - cubeUV_r1 ) + cubeUV_m0;
		} else if ( roughness >= cubeUV_r4 ) {
			mip = ( cubeUV_r1 - roughness ) * ( cubeUV_m4 - cubeUV_m1 ) / ( cubeUV_r1 - cubeUV_r4 ) + cubeUV_m1;
		} else if ( roughness >= cubeUV_r5 ) {
			mip = ( cubeUV_r4 - roughness ) * ( cubeUV_m5 - cubeUV_m4 ) / ( cubeUV_r4 - cubeUV_r5 ) + cubeUV_m4;
		} else if ( roughness >= cubeUV_r6 ) {
			mip = ( cubeUV_r5 - roughness ) * ( cubeUV_m6 - cubeUV_m5 ) / ( cubeUV_r5 - cubeUV_r6 ) + cubeUV_m5;
		} else {
			mip = - 2.0 * log2( 1.16 * roughness );		}
		return mip;
	}
	vec4 textureCubeUV( sampler2D envMap, vec3 sampleDir, float roughness ) {
		float mip = clamp( roughnessToMip( roughness ), cubeUV_m0, CUBEUV_MAX_MIP );
		float mipF = fract( mip );
		float mipInt = floor( mip );
		vec3 color0 = bilinearCubeUV( envMap, sampleDir, mipInt );
		if ( mipF == 0.0 ) {
			return vec4( color0, 1.0 );
		} else {
			vec3 color1 = bilinearCubeUV( envMap, sampleDir, mipInt + 1.0 );
			return vec4( mix( color0, color1, mipF ), 1.0 );
		}
	}
#endif`,Cf=`vec3 transformedNormal = objectNormal;
#ifdef USE_TANGENT
	vec3 transformedTangent = objectTangent;
#endif
#ifdef USE_BATCHING
	mat3 bm = mat3( batchingMatrix );
	transformedNormal /= vec3( dot( bm[ 0 ], bm[ 0 ] ), dot( bm[ 1 ], bm[ 1 ] ), dot( bm[ 2 ], bm[ 2 ] ) );
	transformedNormal = bm * transformedNormal;
	#ifdef USE_TANGENT
		transformedTangent = bm * transformedTangent;
	#endif
#endif
#ifdef USE_INSTANCING
	mat3 im = mat3( instanceMatrix );
	transformedNormal /= vec3( dot( im[ 0 ], im[ 0 ] ), dot( im[ 1 ], im[ 1 ] ), dot( im[ 2 ], im[ 2 ] ) );
	transformedNormal = im * transformedNormal;
	#ifdef USE_TANGENT
		transformedTangent = im * transformedTangent;
	#endif
#endif
transformedNormal = normalMatrix * transformedNormal;
#ifdef FLIP_SIDED
	transformedNormal = - transformedNormal;
#endif
#ifdef USE_TANGENT
	transformedTangent = ( modelViewMatrix * vec4( transformedTangent, 0.0 ) ).xyz;
	#ifdef FLIP_SIDED
		transformedTangent = - transformedTangent;
	#endif
#endif`,Rf=`#ifdef USE_DISPLACEMENTMAP
	uniform sampler2D displacementMap;
	uniform float displacementScale;
	uniform float displacementBias;
#endif`,Pf=`#ifdef USE_DISPLACEMENTMAP
	transformed += normalize( objectNormal ) * ( texture2D( displacementMap, vDisplacementMapUv ).x * displacementScale + displacementBias );
#endif`,Lf=`#ifdef USE_EMISSIVEMAP
	vec4 emissiveColor = texture2D( emissiveMap, vEmissiveMapUv );
	totalEmissiveRadiance *= emissiveColor.rgb;
#endif`,If=`#ifdef USE_EMISSIVEMAP
	uniform sampler2D emissiveMap;
#endif`,Df="gl_FragColor = linearToOutputTexel( gl_FragColor );",Uf=`
const mat3 LINEAR_SRGB_TO_LINEAR_DISPLAY_P3 = mat3(
	vec3( 0.8224621, 0.177538, 0.0 ),
	vec3( 0.0331941, 0.9668058, 0.0 ),
	vec3( 0.0170827, 0.0723974, 0.9105199 )
);
const mat3 LINEAR_DISPLAY_P3_TO_LINEAR_SRGB = mat3(
	vec3( 1.2249401, - 0.2249404, 0.0 ),
	vec3( - 0.0420569, 1.0420571, 0.0 ),
	vec3( - 0.0196376, - 0.0786361, 1.0982735 )
);
vec4 LinearSRGBToLinearDisplayP3( in vec4 value ) {
	return vec4( value.rgb * LINEAR_SRGB_TO_LINEAR_DISPLAY_P3, value.a );
}
vec4 LinearDisplayP3ToLinearSRGB( in vec4 value ) {
	return vec4( value.rgb * LINEAR_DISPLAY_P3_TO_LINEAR_SRGB, value.a );
}
vec4 LinearTransferOETF( in vec4 value ) {
	return value;
}
vec4 sRGBTransferOETF( in vec4 value ) {
	return vec4( mix( pow( value.rgb, vec3( 0.41666 ) ) * 1.055 - vec3( 0.055 ), value.rgb * 12.92, vec3( lessThanEqual( value.rgb, vec3( 0.0031308 ) ) ) ), value.a );
}
vec4 LinearToLinear( in vec4 value ) {
	return value;
}
vec4 LinearTosRGB( in vec4 value ) {
	return sRGBTransferOETF( value );
}`,Nf=`#ifdef USE_ENVMAP
	#ifdef ENV_WORLDPOS
		vec3 cameraToFrag;
		if ( isOrthographic ) {
			cameraToFrag = normalize( vec3( - viewMatrix[ 0 ][ 2 ], - viewMatrix[ 1 ][ 2 ], - viewMatrix[ 2 ][ 2 ] ) );
		} else {
			cameraToFrag = normalize( vWorldPosition - cameraPosition );
		}
		vec3 worldNormal = inverseTransformDirection( normal, viewMatrix );
		#ifdef ENVMAP_MODE_REFLECTION
			vec3 reflectVec = reflect( cameraToFrag, worldNormal );
		#else
			vec3 reflectVec = refract( cameraToFrag, worldNormal, refractionRatio );
		#endif
	#else
		vec3 reflectVec = vReflect;
	#endif
	#ifdef ENVMAP_TYPE_CUBE
		vec4 envColor = textureCube( envMap, vec3( flipEnvMap * reflectVec.x, reflectVec.yz ) );
	#else
		vec4 envColor = vec4( 0.0 );
	#endif
	#ifdef ENVMAP_BLENDING_MULTIPLY
		outgoingLight = mix( outgoingLight, outgoingLight * envColor.xyz, specularStrength * reflectivity );
	#elif defined( ENVMAP_BLENDING_MIX )
		outgoingLight = mix( outgoingLight, envColor.xyz, specularStrength * reflectivity );
	#elif defined( ENVMAP_BLENDING_ADD )
		outgoingLight += envColor.xyz * specularStrength * reflectivity;
	#endif
#endif`,Of=`#ifdef USE_ENVMAP
	uniform float envMapIntensity;
	uniform float flipEnvMap;
	#ifdef ENVMAP_TYPE_CUBE
		uniform samplerCube envMap;
	#else
		uniform sampler2D envMap;
	#endif
	
#endif`,Ff=`#ifdef USE_ENVMAP
	uniform float reflectivity;
	#if defined( USE_BUMPMAP ) || defined( USE_NORMALMAP ) || defined( PHONG ) || defined( LAMBERT )
		#define ENV_WORLDPOS
	#endif
	#ifdef ENV_WORLDPOS
		varying vec3 vWorldPosition;
		uniform float refractionRatio;
	#else
		varying vec3 vReflect;
	#endif
#endif`,Bf=`#ifdef USE_ENVMAP
	#if defined( USE_BUMPMAP ) || defined( USE_NORMALMAP ) || defined( PHONG ) || defined( LAMBERT )
		#define ENV_WORLDPOS
	#endif
	#ifdef ENV_WORLDPOS
		
		varying vec3 vWorldPosition;
	#else
		varying vec3 vReflect;
		uniform float refractionRatio;
	#endif
#endif`,zf=`#ifdef USE_ENVMAP
	#ifdef ENV_WORLDPOS
		vWorldPosition = worldPosition.xyz;
	#else
		vec3 cameraToVertex;
		if ( isOrthographic ) {
			cameraToVertex = normalize( vec3( - viewMatrix[ 0 ][ 2 ], - viewMatrix[ 1 ][ 2 ], - viewMatrix[ 2 ][ 2 ] ) );
		} else {
			cameraToVertex = normalize( worldPosition.xyz - cameraPosition );
		}
		vec3 worldNormal = inverseTransformDirection( transformedNormal, viewMatrix );
		#ifdef ENVMAP_MODE_REFLECTION
			vReflect = reflect( cameraToVertex, worldNormal );
		#else
			vReflect = refract( cameraToVertex, worldNormal, refractionRatio );
		#endif
	#endif
#endif`,kf=`#ifdef USE_FOG
	vFogDepth = - mvPosition.z;
#endif`,Hf=`#ifdef USE_FOG
	varying float vFogDepth;
#endif`,Vf=`#ifdef USE_FOG
	#ifdef FOG_EXP2
		float fogFactor = 1.0 - exp( - fogDensity * fogDensity * vFogDepth * vFogDepth );
	#else
		float fogFactor = smoothstep( fogNear, fogFar, vFogDepth );
	#endif
	gl_FragColor.rgb = mix( gl_FragColor.rgb, fogColor, fogFactor );
#endif`,Gf=`#ifdef USE_FOG
	uniform vec3 fogColor;
	varying float vFogDepth;
	#ifdef FOG_EXP2
		uniform float fogDensity;
	#else
		uniform float fogNear;
		uniform float fogFar;
	#endif
#endif`,Wf=`#ifdef USE_GRADIENTMAP
	uniform sampler2D gradientMap;
#endif
vec3 getGradientIrradiance( vec3 normal, vec3 lightDirection ) {
	float dotNL = dot( normal, lightDirection );
	vec2 coord = vec2( dotNL * 0.5 + 0.5, 0.0 );
	#ifdef USE_GRADIENTMAP
		return vec3( texture2D( gradientMap, coord ).r );
	#else
		vec2 fw = fwidth( coord ) * 0.5;
		return mix( vec3( 0.7 ), vec3( 1.0 ), smoothstep( 0.7 - fw.x, 0.7 + fw.x, coord.x ) );
	#endif
}`,Xf=`#ifdef USE_LIGHTMAP
	vec4 lightMapTexel = texture2D( lightMap, vLightMapUv );
	vec3 lightMapIrradiance = lightMapTexel.rgb * lightMapIntensity;
	reflectedLight.indirectDiffuse += lightMapIrradiance;
#endif`,Yf=`#ifdef USE_LIGHTMAP
	uniform sampler2D lightMap;
	uniform float lightMapIntensity;
#endif`,qf=`LambertMaterial material;
material.diffuseColor = diffuseColor.rgb;
material.specularStrength = specularStrength;`,Zf=`varying vec3 vViewPosition;
struct LambertMaterial {
	vec3 diffuseColor;
	float specularStrength;
};
void RE_Direct_Lambert( const in IncidentLight directLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in LambertMaterial material, inout ReflectedLight reflectedLight ) {
	float dotNL = saturate( dot( geometryNormal, directLight.direction ) );
	vec3 irradiance = dotNL * directLight.color;
	reflectedLight.directDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
void RE_IndirectDiffuse_Lambert( const in vec3 irradiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in LambertMaterial material, inout ReflectedLight reflectedLight ) {
	reflectedLight.indirectDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
#define RE_Direct				RE_Direct_Lambert
#define RE_IndirectDiffuse		RE_IndirectDiffuse_Lambert`,Jf=`uniform bool receiveShadow;
uniform vec3 ambientLightColor;
#if defined( USE_LIGHT_PROBES )
	uniform vec3 lightProbe[ 9 ];
#endif
vec3 shGetIrradianceAt( in vec3 normal, in vec3 shCoefficients[ 9 ] ) {
	float x = normal.x, y = normal.y, z = normal.z;
	vec3 result = shCoefficients[ 0 ] * 0.886227;
	result += shCoefficients[ 1 ] * 2.0 * 0.511664 * y;
	result += shCoefficients[ 2 ] * 2.0 * 0.511664 * z;
	result += shCoefficients[ 3 ] * 2.0 * 0.511664 * x;
	result += shCoefficients[ 4 ] * 2.0 * 0.429043 * x * y;
	result += shCoefficients[ 5 ] * 2.0 * 0.429043 * y * z;
	result += shCoefficients[ 6 ] * ( 0.743125 * z * z - 0.247708 );
	result += shCoefficients[ 7 ] * 2.0 * 0.429043 * x * z;
	result += shCoefficients[ 8 ] * 0.429043 * ( x * x - y * y );
	return result;
}
vec3 getLightProbeIrradiance( const in vec3 lightProbe[ 9 ], const in vec3 normal ) {
	vec3 worldNormal = inverseTransformDirection( normal, viewMatrix );
	vec3 irradiance = shGetIrradianceAt( worldNormal, lightProbe );
	return irradiance;
}
vec3 getAmbientLightIrradiance( const in vec3 ambientLightColor ) {
	vec3 irradiance = ambientLightColor;
	return irradiance;
}
float getDistanceAttenuation( const in float lightDistance, const in float cutoffDistance, const in float decayExponent ) {
	#if defined ( LEGACY_LIGHTS )
		if ( cutoffDistance > 0.0 && decayExponent > 0.0 ) {
			return pow( saturate( - lightDistance / cutoffDistance + 1.0 ), decayExponent );
		}
		return 1.0;
	#else
		float distanceFalloff = 1.0 / max( pow( lightDistance, decayExponent ), 0.01 );
		if ( cutoffDistance > 0.0 ) {
			distanceFalloff *= pow2( saturate( 1.0 - pow4( lightDistance / cutoffDistance ) ) );
		}
		return distanceFalloff;
	#endif
}
float getSpotAttenuation( const in float coneCosine, const in float penumbraCosine, const in float angleCosine ) {
	return smoothstep( coneCosine, penumbraCosine, angleCosine );
}
#if NUM_DIR_LIGHTS > 0
	struct DirectionalLight {
		vec3 direction;
		vec3 color;
	};
	uniform DirectionalLight directionalLights[ NUM_DIR_LIGHTS ];
	void getDirectionalLightInfo( const in DirectionalLight directionalLight, out IncidentLight light ) {
		light.color = directionalLight.color;
		light.direction = directionalLight.direction;
		light.visible = true;
	}
#endif
#if NUM_POINT_LIGHTS > 0
	struct PointLight {
		vec3 position;
		vec3 color;
		float distance;
		float decay;
	};
	uniform PointLight pointLights[ NUM_POINT_LIGHTS ];
	void getPointLightInfo( const in PointLight pointLight, const in vec3 geometryPosition, out IncidentLight light ) {
		vec3 lVector = pointLight.position - geometryPosition;
		light.direction = normalize( lVector );
		float lightDistance = length( lVector );
		light.color = pointLight.color;
		light.color *= getDistanceAttenuation( lightDistance, pointLight.distance, pointLight.decay );
		light.visible = ( light.color != vec3( 0.0 ) );
	}
#endif
#if NUM_SPOT_LIGHTS > 0
	struct SpotLight {
		vec3 position;
		vec3 direction;
		vec3 color;
		float distance;
		float decay;
		float coneCos;
		float penumbraCos;
	};
	uniform SpotLight spotLights[ NUM_SPOT_LIGHTS ];
	void getSpotLightInfo( const in SpotLight spotLight, const in vec3 geometryPosition, out IncidentLight light ) {
		vec3 lVector = spotLight.position - geometryPosition;
		light.direction = normalize( lVector );
		float angleCos = dot( light.direction, spotLight.direction );
		float spotAttenuation = getSpotAttenuation( spotLight.coneCos, spotLight.penumbraCos, angleCos );
		if ( spotAttenuation > 0.0 ) {
			float lightDistance = length( lVector );
			light.color = spotLight.color * spotAttenuation;
			light.color *= getDistanceAttenuation( lightDistance, spotLight.distance, spotLight.decay );
			light.visible = ( light.color != vec3( 0.0 ) );
		} else {
			light.color = vec3( 0.0 );
			light.visible = false;
		}
	}
#endif
#if NUM_RECT_AREA_LIGHTS > 0
	struct RectAreaLight {
		vec3 color;
		vec3 position;
		vec3 halfWidth;
		vec3 halfHeight;
	};
	uniform sampler2D ltc_1;	uniform sampler2D ltc_2;
	uniform RectAreaLight rectAreaLights[ NUM_RECT_AREA_LIGHTS ];
#endif
#if NUM_HEMI_LIGHTS > 0
	struct HemisphereLight {
		vec3 direction;
		vec3 skyColor;
		vec3 groundColor;
	};
	uniform HemisphereLight hemisphereLights[ NUM_HEMI_LIGHTS ];
	vec3 getHemisphereLightIrradiance( const in HemisphereLight hemiLight, const in vec3 normal ) {
		float dotNL = dot( normal, hemiLight.direction );
		float hemiDiffuseWeight = 0.5 * dotNL + 0.5;
		vec3 irradiance = mix( hemiLight.groundColor, hemiLight.skyColor, hemiDiffuseWeight );
		return irradiance;
	}
#endif`,$f=`#ifdef USE_ENVMAP
	vec3 getIBLIrradiance( const in vec3 normal ) {
		#ifdef ENVMAP_TYPE_CUBE_UV
			vec3 worldNormal = inverseTransformDirection( normal, viewMatrix );
			vec4 envMapColor = textureCubeUV( envMap, worldNormal, 1.0 );
			return PI * envMapColor.rgb * envMapIntensity;
		#else
			return vec3( 0.0 );
		#endif
	}
	vec3 getIBLRadiance( const in vec3 viewDir, const in vec3 normal, const in float roughness ) {
		#ifdef ENVMAP_TYPE_CUBE_UV
			vec3 reflectVec = reflect( - viewDir, normal );
			reflectVec = normalize( mix( reflectVec, normal, roughness * roughness) );
			reflectVec = inverseTransformDirection( reflectVec, viewMatrix );
			vec4 envMapColor = textureCubeUV( envMap, reflectVec, roughness );
			return envMapColor.rgb * envMapIntensity;
		#else
			return vec3( 0.0 );
		#endif
	}
	#ifdef USE_ANISOTROPY
		vec3 getIBLAnisotropyRadiance( const in vec3 viewDir, const in vec3 normal, const in float roughness, const in vec3 bitangent, const in float anisotropy ) {
			#ifdef ENVMAP_TYPE_CUBE_UV
				vec3 bentNormal = cross( bitangent, viewDir );
				bentNormal = normalize( cross( bentNormal, bitangent ) );
				bentNormal = normalize( mix( bentNormal, normal, pow2( pow2( 1.0 - anisotropy * ( 1.0 - roughness ) ) ) ) );
				return getIBLRadiance( viewDir, bentNormal, roughness );
			#else
				return vec3( 0.0 );
			#endif
		}
	#endif
#endif`,jf=`ToonMaterial material;
material.diffuseColor = diffuseColor.rgb;`,Kf=`varying vec3 vViewPosition;
struct ToonMaterial {
	vec3 diffuseColor;
};
void RE_Direct_Toon( const in IncidentLight directLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in ToonMaterial material, inout ReflectedLight reflectedLight ) {
	vec3 irradiance = getGradientIrradiance( geometryNormal, directLight.direction ) * directLight.color;
	reflectedLight.directDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
void RE_IndirectDiffuse_Toon( const in vec3 irradiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in ToonMaterial material, inout ReflectedLight reflectedLight ) {
	reflectedLight.indirectDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
#define RE_Direct				RE_Direct_Toon
#define RE_IndirectDiffuse		RE_IndirectDiffuse_Toon`,Qf=`BlinnPhongMaterial material;
material.diffuseColor = diffuseColor.rgb;
material.specularColor = specular;
material.specularShininess = shininess;
material.specularStrength = specularStrength;`,tp=`varying vec3 vViewPosition;
struct BlinnPhongMaterial {
	vec3 diffuseColor;
	vec3 specularColor;
	float specularShininess;
	float specularStrength;
};
void RE_Direct_BlinnPhong( const in IncidentLight directLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in BlinnPhongMaterial material, inout ReflectedLight reflectedLight ) {
	float dotNL = saturate( dot( geometryNormal, directLight.direction ) );
	vec3 irradiance = dotNL * directLight.color;
	reflectedLight.directDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
	reflectedLight.directSpecular += irradiance * BRDF_BlinnPhong( directLight.direction, geometryViewDir, geometryNormal, material.specularColor, material.specularShininess ) * material.specularStrength;
}
void RE_IndirectDiffuse_BlinnPhong( const in vec3 irradiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in BlinnPhongMaterial material, inout ReflectedLight reflectedLight ) {
	reflectedLight.indirectDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
#define RE_Direct				RE_Direct_BlinnPhong
#define RE_IndirectDiffuse		RE_IndirectDiffuse_BlinnPhong`,ep=`PhysicalMaterial material;
material.diffuseColor = diffuseColor.rgb * ( 1.0 - metalnessFactor );
vec3 dxy = max( abs( dFdx( nonPerturbedNormal ) ), abs( dFdy( nonPerturbedNormal ) ) );
float geometryRoughness = max( max( dxy.x, dxy.y ), dxy.z );
material.roughness = max( roughnessFactor, 0.0525 );material.roughness += geometryRoughness;
material.roughness = min( material.roughness, 1.0 );
#ifdef IOR
	material.ior = ior;
	#ifdef USE_SPECULAR
		float specularIntensityFactor = specularIntensity;
		vec3 specularColorFactor = specularColor;
		#ifdef USE_SPECULAR_COLORMAP
			specularColorFactor *= texture2D( specularColorMap, vSpecularColorMapUv ).rgb;
		#endif
		#ifdef USE_SPECULAR_INTENSITYMAP
			specularIntensityFactor *= texture2D( specularIntensityMap, vSpecularIntensityMapUv ).a;
		#endif
		material.specularF90 = mix( specularIntensityFactor, 1.0, metalnessFactor );
	#else
		float specularIntensityFactor = 1.0;
		vec3 specularColorFactor = vec3( 1.0 );
		material.specularF90 = 1.0;
	#endif
	material.specularColor = mix( min( pow2( ( material.ior - 1.0 ) / ( material.ior + 1.0 ) ) * specularColorFactor, vec3( 1.0 ) ) * specularIntensityFactor, diffuseColor.rgb, metalnessFactor );
#else
	material.specularColor = mix( vec3( 0.04 ), diffuseColor.rgb, metalnessFactor );
	material.specularF90 = 1.0;
#endif
#ifdef USE_CLEARCOAT
	material.clearcoat = clearcoat;
	material.clearcoatRoughness = clearcoatRoughness;
	material.clearcoatF0 = vec3( 0.04 );
	material.clearcoatF90 = 1.0;
	#ifdef USE_CLEARCOATMAP
		material.clearcoat *= texture2D( clearcoatMap, vClearcoatMapUv ).x;
	#endif
	#ifdef USE_CLEARCOAT_ROUGHNESSMAP
		material.clearcoatRoughness *= texture2D( clearcoatRoughnessMap, vClearcoatRoughnessMapUv ).y;
	#endif
	material.clearcoat = saturate( material.clearcoat );	material.clearcoatRoughness = max( material.clearcoatRoughness, 0.0525 );
	material.clearcoatRoughness += geometryRoughness;
	material.clearcoatRoughness = min( material.clearcoatRoughness, 1.0 );
#endif
#ifdef USE_IRIDESCENCE
	material.iridescence = iridescence;
	material.iridescenceIOR = iridescenceIOR;
	#ifdef USE_IRIDESCENCEMAP
		material.iridescence *= texture2D( iridescenceMap, vIridescenceMapUv ).r;
	#endif
	#ifdef USE_IRIDESCENCE_THICKNESSMAP
		material.iridescenceThickness = (iridescenceThicknessMaximum - iridescenceThicknessMinimum) * texture2D( iridescenceThicknessMap, vIridescenceThicknessMapUv ).g + iridescenceThicknessMinimum;
	#else
		material.iridescenceThickness = iridescenceThicknessMaximum;
	#endif
#endif
#ifdef USE_SHEEN
	material.sheenColor = sheenColor;
	#ifdef USE_SHEEN_COLORMAP
		material.sheenColor *= texture2D( sheenColorMap, vSheenColorMapUv ).rgb;
	#endif
	material.sheenRoughness = clamp( sheenRoughness, 0.07, 1.0 );
	#ifdef USE_SHEEN_ROUGHNESSMAP
		material.sheenRoughness *= texture2D( sheenRoughnessMap, vSheenRoughnessMapUv ).a;
	#endif
#endif
#ifdef USE_ANISOTROPY
	#ifdef USE_ANISOTROPYMAP
		mat2 anisotropyMat = mat2( anisotropyVector.x, anisotropyVector.y, - anisotropyVector.y, anisotropyVector.x );
		vec3 anisotropyPolar = texture2D( anisotropyMap, vAnisotropyMapUv ).rgb;
		vec2 anisotropyV = anisotropyMat * normalize( 2.0 * anisotropyPolar.rg - vec2( 1.0 ) ) * anisotropyPolar.b;
	#else
		vec2 anisotropyV = anisotropyVector;
	#endif
	material.anisotropy = length( anisotropyV );
	if( material.anisotropy == 0.0 ) {
		anisotropyV = vec2( 1.0, 0.0 );
	} else {
		anisotropyV /= material.anisotropy;
		material.anisotropy = saturate( material.anisotropy );
	}
	material.alphaT = mix( pow2( material.roughness ), 1.0, pow2( material.anisotropy ) );
	material.anisotropyT = tbn[ 0 ] * anisotropyV.x + tbn[ 1 ] * anisotropyV.y;
	material.anisotropyB = tbn[ 1 ] * anisotropyV.x - tbn[ 0 ] * anisotropyV.y;
#endif`,np=`struct PhysicalMaterial {
	vec3 diffuseColor;
	float roughness;
	vec3 specularColor;
	float specularF90;
	#ifdef USE_CLEARCOAT
		float clearcoat;
		float clearcoatRoughness;
		vec3 clearcoatF0;
		float clearcoatF90;
	#endif
	#ifdef USE_IRIDESCENCE
		float iridescence;
		float iridescenceIOR;
		float iridescenceThickness;
		vec3 iridescenceFresnel;
		vec3 iridescenceF0;
	#endif
	#ifdef USE_SHEEN
		vec3 sheenColor;
		float sheenRoughness;
	#endif
	#ifdef IOR
		float ior;
	#endif
	#ifdef USE_TRANSMISSION
		float transmission;
		float transmissionAlpha;
		float thickness;
		float attenuationDistance;
		vec3 attenuationColor;
	#endif
	#ifdef USE_ANISOTROPY
		float anisotropy;
		float alphaT;
		vec3 anisotropyT;
		vec3 anisotropyB;
	#endif
};
vec3 clearcoatSpecularDirect = vec3( 0.0 );
vec3 clearcoatSpecularIndirect = vec3( 0.0 );
vec3 sheenSpecularDirect = vec3( 0.0 );
vec3 sheenSpecularIndirect = vec3(0.0 );
vec3 Schlick_to_F0( const in vec3 f, const in float f90, const in float dotVH ) {
    float x = clamp( 1.0 - dotVH, 0.0, 1.0 );
    float x2 = x * x;
    float x5 = clamp( x * x2 * x2, 0.0, 0.9999 );
    return ( f - vec3( f90 ) * x5 ) / ( 1.0 - x5 );
}
float V_GGX_SmithCorrelated( const in float alpha, const in float dotNL, const in float dotNV ) {
	float a2 = pow2( alpha );
	float gv = dotNL * sqrt( a2 + ( 1.0 - a2 ) * pow2( dotNV ) );
	float gl = dotNV * sqrt( a2 + ( 1.0 - a2 ) * pow2( dotNL ) );
	return 0.5 / max( gv + gl, EPSILON );
}
float D_GGX( const in float alpha, const in float dotNH ) {
	float a2 = pow2( alpha );
	float denom = pow2( dotNH ) * ( a2 - 1.0 ) + 1.0;
	return RECIPROCAL_PI * a2 / pow2( denom );
}
#ifdef USE_ANISOTROPY
	float V_GGX_SmithCorrelated_Anisotropic( const in float alphaT, const in float alphaB, const in float dotTV, const in float dotBV, const in float dotTL, const in float dotBL, const in float dotNV, const in float dotNL ) {
		float gv = dotNL * length( vec3( alphaT * dotTV, alphaB * dotBV, dotNV ) );
		float gl = dotNV * length( vec3( alphaT * dotTL, alphaB * dotBL, dotNL ) );
		float v = 0.5 / ( gv + gl );
		return saturate(v);
	}
	float D_GGX_Anisotropic( const in float alphaT, const in float alphaB, const in float dotNH, const in float dotTH, const in float dotBH ) {
		float a2 = alphaT * alphaB;
		highp vec3 v = vec3( alphaB * dotTH, alphaT * dotBH, a2 * dotNH );
		highp float v2 = dot( v, v );
		float w2 = a2 / v2;
		return RECIPROCAL_PI * a2 * pow2 ( w2 );
	}
#endif
#ifdef USE_CLEARCOAT
	vec3 BRDF_GGX_Clearcoat( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, const in PhysicalMaterial material) {
		vec3 f0 = material.clearcoatF0;
		float f90 = material.clearcoatF90;
		float roughness = material.clearcoatRoughness;
		float alpha = pow2( roughness );
		vec3 halfDir = normalize( lightDir + viewDir );
		float dotNL = saturate( dot( normal, lightDir ) );
		float dotNV = saturate( dot( normal, viewDir ) );
		float dotNH = saturate( dot( normal, halfDir ) );
		float dotVH = saturate( dot( viewDir, halfDir ) );
		vec3 F = F_Schlick( f0, f90, dotVH );
		float V = V_GGX_SmithCorrelated( alpha, dotNL, dotNV );
		float D = D_GGX( alpha, dotNH );
		return F * ( V * D );
	}
#endif
vec3 BRDF_GGX( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, const in PhysicalMaterial material ) {
	vec3 f0 = material.specularColor;
	float f90 = material.specularF90;
	float roughness = material.roughness;
	float alpha = pow2( roughness );
	vec3 halfDir = normalize( lightDir + viewDir );
	float dotNL = saturate( dot( normal, lightDir ) );
	float dotNV = saturate( dot( normal, viewDir ) );
	float dotNH = saturate( dot( normal, halfDir ) );
	float dotVH = saturate( dot( viewDir, halfDir ) );
	vec3 F = F_Schlick( f0, f90, dotVH );
	#ifdef USE_IRIDESCENCE
		F = mix( F, material.iridescenceFresnel, material.iridescence );
	#endif
	#ifdef USE_ANISOTROPY
		float dotTL = dot( material.anisotropyT, lightDir );
		float dotTV = dot( material.anisotropyT, viewDir );
		float dotTH = dot( material.anisotropyT, halfDir );
		float dotBL = dot( material.anisotropyB, lightDir );
		float dotBV = dot( material.anisotropyB, viewDir );
		float dotBH = dot( material.anisotropyB, halfDir );
		float V = V_GGX_SmithCorrelated_Anisotropic( material.alphaT, alpha, dotTV, dotBV, dotTL, dotBL, dotNV, dotNL );
		float D = D_GGX_Anisotropic( material.alphaT, alpha, dotNH, dotTH, dotBH );
	#else
		float V = V_GGX_SmithCorrelated( alpha, dotNL, dotNV );
		float D = D_GGX( alpha, dotNH );
	#endif
	return F * ( V * D );
}
vec2 LTC_Uv( const in vec3 N, const in vec3 V, const in float roughness ) {
	const float LUT_SIZE = 64.0;
	const float LUT_SCALE = ( LUT_SIZE - 1.0 ) / LUT_SIZE;
	const float LUT_BIAS = 0.5 / LUT_SIZE;
	float dotNV = saturate( dot( N, V ) );
	vec2 uv = vec2( roughness, sqrt( 1.0 - dotNV ) );
	uv = uv * LUT_SCALE + LUT_BIAS;
	return uv;
}
float LTC_ClippedSphereFormFactor( const in vec3 f ) {
	float l = length( f );
	return max( ( l * l + f.z ) / ( l + 1.0 ), 0.0 );
}
vec3 LTC_EdgeVectorFormFactor( const in vec3 v1, const in vec3 v2 ) {
	float x = dot( v1, v2 );
	float y = abs( x );
	float a = 0.8543985 + ( 0.4965155 + 0.0145206 * y ) * y;
	float b = 3.4175940 + ( 4.1616724 + y ) * y;
	float v = a / b;
	float theta_sintheta = ( x > 0.0 ) ? v : 0.5 * inversesqrt( max( 1.0 - x * x, 1e-7 ) ) - v;
	return cross( v1, v2 ) * theta_sintheta;
}
vec3 LTC_Evaluate( const in vec3 N, const in vec3 V, const in vec3 P, const in mat3 mInv, const in vec3 rectCoords[ 4 ] ) {
	vec3 v1 = rectCoords[ 1 ] - rectCoords[ 0 ];
	vec3 v2 = rectCoords[ 3 ] - rectCoords[ 0 ];
	vec3 lightNormal = cross( v1, v2 );
	if( dot( lightNormal, P - rectCoords[ 0 ] ) < 0.0 ) return vec3( 0.0 );
	vec3 T1, T2;
	T1 = normalize( V - N * dot( V, N ) );
	T2 = - cross( N, T1 );
	mat3 mat = mInv * transposeMat3( mat3( T1, T2, N ) );
	vec3 coords[ 4 ];
	coords[ 0 ] = mat * ( rectCoords[ 0 ] - P );
	coords[ 1 ] = mat * ( rectCoords[ 1 ] - P );
	coords[ 2 ] = mat * ( rectCoords[ 2 ] - P );
	coords[ 3 ] = mat * ( rectCoords[ 3 ] - P );
	coords[ 0 ] = normalize( coords[ 0 ] );
	coords[ 1 ] = normalize( coords[ 1 ] );
	coords[ 2 ] = normalize( coords[ 2 ] );
	coords[ 3 ] = normalize( coords[ 3 ] );
	vec3 vectorFormFactor = vec3( 0.0 );
	vectorFormFactor += LTC_EdgeVectorFormFactor( coords[ 0 ], coords[ 1 ] );
	vectorFormFactor += LTC_EdgeVectorFormFactor( coords[ 1 ], coords[ 2 ] );
	vectorFormFactor += LTC_EdgeVectorFormFactor( coords[ 2 ], coords[ 3 ] );
	vectorFormFactor += LTC_EdgeVectorFormFactor( coords[ 3 ], coords[ 0 ] );
	float result = LTC_ClippedSphereFormFactor( vectorFormFactor );
	return vec3( result );
}
#if defined( USE_SHEEN )
float D_Charlie( float roughness, float dotNH ) {
	float alpha = pow2( roughness );
	float invAlpha = 1.0 / alpha;
	float cos2h = dotNH * dotNH;
	float sin2h = max( 1.0 - cos2h, 0.0078125 );
	return ( 2.0 + invAlpha ) * pow( sin2h, invAlpha * 0.5 ) / ( 2.0 * PI );
}
float V_Neubelt( float dotNV, float dotNL ) {
	return saturate( 1.0 / ( 4.0 * ( dotNL + dotNV - dotNL * dotNV ) ) );
}
vec3 BRDF_Sheen( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, vec3 sheenColor, const in float sheenRoughness ) {
	vec3 halfDir = normalize( lightDir + viewDir );
	float dotNL = saturate( dot( normal, lightDir ) );
	float dotNV = saturate( dot( normal, viewDir ) );
	float dotNH = saturate( dot( normal, halfDir ) );
	float D = D_Charlie( sheenRoughness, dotNH );
	float V = V_Neubelt( dotNV, dotNL );
	return sheenColor * ( D * V );
}
#endif
float IBLSheenBRDF( const in vec3 normal, const in vec3 viewDir, const in float roughness ) {
	float dotNV = saturate( dot( normal, viewDir ) );
	float r2 = roughness * roughness;
	float a = roughness < 0.25 ? -339.2 * r2 + 161.4 * roughness - 25.9 : -8.48 * r2 + 14.3 * roughness - 9.95;
	float b = roughness < 0.25 ? 44.0 * r2 - 23.7 * roughness + 3.26 : 1.97 * r2 - 3.27 * roughness + 0.72;
	float DG = exp( a * dotNV + b ) + ( roughness < 0.25 ? 0.0 : 0.1 * ( roughness - 0.25 ) );
	return saturate( DG * RECIPROCAL_PI );
}
vec2 DFGApprox( const in vec3 normal, const in vec3 viewDir, const in float roughness ) {
	float dotNV = saturate( dot( normal, viewDir ) );
	const vec4 c0 = vec4( - 1, - 0.0275, - 0.572, 0.022 );
	const vec4 c1 = vec4( 1, 0.0425, 1.04, - 0.04 );
	vec4 r = roughness * c0 + c1;
	float a004 = min( r.x * r.x, exp2( - 9.28 * dotNV ) ) * r.x + r.y;
	vec2 fab = vec2( - 1.04, 1.04 ) * a004 + r.zw;
	return fab;
}
vec3 EnvironmentBRDF( const in vec3 normal, const in vec3 viewDir, const in vec3 specularColor, const in float specularF90, const in float roughness ) {
	vec2 fab = DFGApprox( normal, viewDir, roughness );
	return specularColor * fab.x + specularF90 * fab.y;
}
#ifdef USE_IRIDESCENCE
void computeMultiscatteringIridescence( const in vec3 normal, const in vec3 viewDir, const in vec3 specularColor, const in float specularF90, const in float iridescence, const in vec3 iridescenceF0, const in float roughness, inout vec3 singleScatter, inout vec3 multiScatter ) {
#else
void computeMultiscattering( const in vec3 normal, const in vec3 viewDir, const in vec3 specularColor, const in float specularF90, const in float roughness, inout vec3 singleScatter, inout vec3 multiScatter ) {
#endif
	vec2 fab = DFGApprox( normal, viewDir, roughness );
	#ifdef USE_IRIDESCENCE
		vec3 Fr = mix( specularColor, iridescenceF0, iridescence );
	#else
		vec3 Fr = specularColor;
	#endif
	vec3 FssEss = Fr * fab.x + specularF90 * fab.y;
	float Ess = fab.x + fab.y;
	float Ems = 1.0 - Ess;
	vec3 Favg = Fr + ( 1.0 - Fr ) * 0.047619;	vec3 Fms = FssEss * Favg / ( 1.0 - Ems * Favg );
	singleScatter += FssEss;
	multiScatter += Fms * Ems;
}
#if NUM_RECT_AREA_LIGHTS > 0
	void RE_Direct_RectArea_Physical( const in RectAreaLight rectAreaLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in PhysicalMaterial material, inout ReflectedLight reflectedLight ) {
		vec3 normal = geometryNormal;
		vec3 viewDir = geometryViewDir;
		vec3 position = geometryPosition;
		vec3 lightPos = rectAreaLight.position;
		vec3 halfWidth = rectAreaLight.halfWidth;
		vec3 halfHeight = rectAreaLight.halfHeight;
		vec3 lightColor = rectAreaLight.color;
		float roughness = material.roughness;
		vec3 rectCoords[ 4 ];
		rectCoords[ 0 ] = lightPos + halfWidth - halfHeight;		rectCoords[ 1 ] = lightPos - halfWidth - halfHeight;
		rectCoords[ 2 ] = lightPos - halfWidth + halfHeight;
		rectCoords[ 3 ] = lightPos + halfWidth + halfHeight;
		vec2 uv = LTC_Uv( normal, viewDir, roughness );
		vec4 t1 = texture2D( ltc_1, uv );
		vec4 t2 = texture2D( ltc_2, uv );
		mat3 mInv = mat3(
			vec3( t1.x, 0, t1.y ),
			vec3(    0, 1,    0 ),
			vec3( t1.z, 0, t1.w )
		);
		vec3 fresnel = ( material.specularColor * t2.x + ( vec3( 1.0 ) - material.specularColor ) * t2.y );
		reflectedLight.directSpecular += lightColor * fresnel * LTC_Evaluate( normal, viewDir, position, mInv, rectCoords );
		reflectedLight.directDiffuse += lightColor * material.diffuseColor * LTC_Evaluate( normal, viewDir, position, mat3( 1.0 ), rectCoords );
	}
#endif
void RE_Direct_Physical( const in IncidentLight directLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in PhysicalMaterial material, inout ReflectedLight reflectedLight ) {
	float dotNL = saturate( dot( geometryNormal, directLight.direction ) );
	vec3 irradiance = dotNL * directLight.color;
	#ifdef USE_CLEARCOAT
		float dotNLcc = saturate( dot( geometryClearcoatNormal, directLight.direction ) );
		vec3 ccIrradiance = dotNLcc * directLight.color;
		clearcoatSpecularDirect += ccIrradiance * BRDF_GGX_Clearcoat( directLight.direction, geometryViewDir, geometryClearcoatNormal, material );
	#endif
	#ifdef USE_SHEEN
		sheenSpecularDirect += irradiance * BRDF_Sheen( directLight.direction, geometryViewDir, geometryNormal, material.sheenColor, material.sheenRoughness );
	#endif
	reflectedLight.directSpecular += irradiance * BRDF_GGX( directLight.direction, geometryViewDir, geometryNormal, material );
	reflectedLight.directDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
void RE_IndirectDiffuse_Physical( const in vec3 irradiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in PhysicalMaterial material, inout ReflectedLight reflectedLight ) {
	reflectedLight.indirectDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
void RE_IndirectSpecular_Physical( const in vec3 radiance, const in vec3 irradiance, const in vec3 clearcoatRadiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in PhysicalMaterial material, inout ReflectedLight reflectedLight) {
	#ifdef USE_CLEARCOAT
		clearcoatSpecularIndirect += clearcoatRadiance * EnvironmentBRDF( geometryClearcoatNormal, geometryViewDir, material.clearcoatF0, material.clearcoatF90, material.clearcoatRoughness );
	#endif
	#ifdef USE_SHEEN
		sheenSpecularIndirect += irradiance * material.sheenColor * IBLSheenBRDF( geometryNormal, geometryViewDir, material.sheenRoughness );
	#endif
	vec3 singleScattering = vec3( 0.0 );
	vec3 multiScattering = vec3( 0.0 );
	vec3 cosineWeightedIrradiance = irradiance * RECIPROCAL_PI;
	#ifdef USE_IRIDESCENCE
		computeMultiscatteringIridescence( geometryNormal, geometryViewDir, material.specularColor, material.specularF90, material.iridescence, material.iridescenceFresnel, material.roughness, singleScattering, multiScattering );
	#else
		computeMultiscattering( geometryNormal, geometryViewDir, material.specularColor, material.specularF90, material.roughness, singleScattering, multiScattering );
	#endif
	vec3 totalScattering = singleScattering + multiScattering;
	vec3 diffuse = material.diffuseColor * ( 1.0 - max( max( totalScattering.r, totalScattering.g ), totalScattering.b ) );
	reflectedLight.indirectSpecular += radiance * singleScattering;
	reflectedLight.indirectSpecular += multiScattering * cosineWeightedIrradiance;
	reflectedLight.indirectDiffuse += diffuse * cosineWeightedIrradiance;
}
#define RE_Direct				RE_Direct_Physical
#define RE_Direct_RectArea		RE_Direct_RectArea_Physical
#define RE_IndirectDiffuse		RE_IndirectDiffuse_Physical
#define RE_IndirectSpecular		RE_IndirectSpecular_Physical
float computeSpecularOcclusion( const in float dotNV, const in float ambientOcclusion, const in float roughness ) {
	return saturate( pow( dotNV + ambientOcclusion, exp2( - 16.0 * roughness - 1.0 ) ) - 1.0 + ambientOcclusion );
}`,ip=`
vec3 geometryPosition = - vViewPosition;
vec3 geometryNormal = normal;
vec3 geometryViewDir = ( isOrthographic ) ? vec3( 0, 0, 1 ) : normalize( vViewPosition );
vec3 geometryClearcoatNormal = vec3( 0.0 );
#ifdef USE_CLEARCOAT
	geometryClearcoatNormal = clearcoatNormal;
#endif
#ifdef USE_IRIDESCENCE
	float dotNVi = saturate( dot( normal, geometryViewDir ) );
	if ( material.iridescenceThickness == 0.0 ) {
		material.iridescence = 0.0;
	} else {
		material.iridescence = saturate( material.iridescence );
	}
	if ( material.iridescence > 0.0 ) {
		material.iridescenceFresnel = evalIridescence( 1.0, material.iridescenceIOR, dotNVi, material.iridescenceThickness, material.specularColor );
		material.iridescenceF0 = Schlick_to_F0( material.iridescenceFresnel, 1.0, dotNVi );
	}
#endif
IncidentLight directLight;
#if ( NUM_POINT_LIGHTS > 0 ) && defined( RE_Direct )
	PointLight pointLight;
	#if defined( USE_SHADOWMAP ) && NUM_POINT_LIGHT_SHADOWS > 0
	PointLightShadow pointLightShadow;
	#endif
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_POINT_LIGHTS; i ++ ) {
		pointLight = pointLights[ i ];
		getPointLightInfo( pointLight, geometryPosition, directLight );
		#if defined( USE_SHADOWMAP ) && ( UNROLLED_LOOP_INDEX < NUM_POINT_LIGHT_SHADOWS )
		pointLightShadow = pointLightShadows[ i ];
		directLight.color *= ( directLight.visible && receiveShadow ) ? getPointShadow( pointShadowMap[ i ], pointLightShadow.shadowMapSize, pointLightShadow.shadowBias, pointLightShadow.shadowRadius, vPointShadowCoord[ i ], pointLightShadow.shadowCameraNear, pointLightShadow.shadowCameraFar ) : 1.0;
		#endif
		RE_Direct( directLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
	}
	#pragma unroll_loop_end
#endif
#if ( NUM_SPOT_LIGHTS > 0 ) && defined( RE_Direct )
	SpotLight spotLight;
	vec4 spotColor;
	vec3 spotLightCoord;
	bool inSpotLightMap;
	#if defined( USE_SHADOWMAP ) && NUM_SPOT_LIGHT_SHADOWS > 0
	SpotLightShadow spotLightShadow;
	#endif
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_SPOT_LIGHTS; i ++ ) {
		spotLight = spotLights[ i ];
		getSpotLightInfo( spotLight, geometryPosition, directLight );
		#if ( UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS_WITH_MAPS )
		#define SPOT_LIGHT_MAP_INDEX UNROLLED_LOOP_INDEX
		#elif ( UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS )
		#define SPOT_LIGHT_MAP_INDEX NUM_SPOT_LIGHT_MAPS
		#else
		#define SPOT_LIGHT_MAP_INDEX ( UNROLLED_LOOP_INDEX - NUM_SPOT_LIGHT_SHADOWS + NUM_SPOT_LIGHT_SHADOWS_WITH_MAPS )
		#endif
		#if ( SPOT_LIGHT_MAP_INDEX < NUM_SPOT_LIGHT_MAPS )
			spotLightCoord = vSpotLightCoord[ i ].xyz / vSpotLightCoord[ i ].w;
			inSpotLightMap = all( lessThan( abs( spotLightCoord * 2. - 1. ), vec3( 1.0 ) ) );
			spotColor = texture2D( spotLightMap[ SPOT_LIGHT_MAP_INDEX ], spotLightCoord.xy );
			directLight.color = inSpotLightMap ? directLight.color * spotColor.rgb : directLight.color;
		#endif
		#undef SPOT_LIGHT_MAP_INDEX
		#if defined( USE_SHADOWMAP ) && ( UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS )
		spotLightShadow = spotLightShadows[ i ];
		directLight.color *= ( directLight.visible && receiveShadow ) ? getShadow( spotShadowMap[ i ], spotLightShadow.shadowMapSize, spotLightShadow.shadowBias, spotLightShadow.shadowRadius, vSpotLightCoord[ i ] ) : 1.0;
		#endif
		RE_Direct( directLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
	}
	#pragma unroll_loop_end
#endif
#if ( NUM_DIR_LIGHTS > 0 ) && defined( RE_Direct )
	DirectionalLight directionalLight;
	#if defined( USE_SHADOWMAP ) && NUM_DIR_LIGHT_SHADOWS > 0
	DirectionalLightShadow directionalLightShadow;
	#endif
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_DIR_LIGHTS; i ++ ) {
		directionalLight = directionalLights[ i ];
		getDirectionalLightInfo( directionalLight, directLight );
		#if defined( USE_SHADOWMAP ) && ( UNROLLED_LOOP_INDEX < NUM_DIR_LIGHT_SHADOWS )
		directionalLightShadow = directionalLightShadows[ i ];
		directLight.color *= ( directLight.visible && receiveShadow ) ? getShadow( directionalShadowMap[ i ], directionalLightShadow.shadowMapSize, directionalLightShadow.shadowBias, directionalLightShadow.shadowRadius, vDirectionalShadowCoord[ i ] ) : 1.0;
		#endif
		RE_Direct( directLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
	}
	#pragma unroll_loop_end
#endif
#if ( NUM_RECT_AREA_LIGHTS > 0 ) && defined( RE_Direct_RectArea )
	RectAreaLight rectAreaLight;
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_RECT_AREA_LIGHTS; i ++ ) {
		rectAreaLight = rectAreaLights[ i ];
		RE_Direct_RectArea( rectAreaLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
	}
	#pragma unroll_loop_end
#endif
#if defined( RE_IndirectDiffuse )
	vec3 iblIrradiance = vec3( 0.0 );
	vec3 irradiance = getAmbientLightIrradiance( ambientLightColor );
	#if defined( USE_LIGHT_PROBES )
		irradiance += getLightProbeIrradiance( lightProbe, geometryNormal );
	#endif
	#if ( NUM_HEMI_LIGHTS > 0 )
		#pragma unroll_loop_start
		for ( int i = 0; i < NUM_HEMI_LIGHTS; i ++ ) {
			irradiance += getHemisphereLightIrradiance( hemisphereLights[ i ], geometryNormal );
		}
		#pragma unroll_loop_end
	#endif
#endif
#if defined( RE_IndirectSpecular )
	vec3 radiance = vec3( 0.0 );
	vec3 clearcoatRadiance = vec3( 0.0 );
#endif`,sp=`#if defined( RE_IndirectDiffuse )
	#ifdef USE_LIGHTMAP
		vec4 lightMapTexel = texture2D( lightMap, vLightMapUv );
		vec3 lightMapIrradiance = lightMapTexel.rgb * lightMapIntensity;
		irradiance += lightMapIrradiance;
	#endif
	#if defined( USE_ENVMAP ) && defined( STANDARD ) && defined( ENVMAP_TYPE_CUBE_UV )
		iblIrradiance += getIBLIrradiance( geometryNormal );
	#endif
#endif
#if defined( USE_ENVMAP ) && defined( RE_IndirectSpecular )
	#ifdef USE_ANISOTROPY
		radiance += getIBLAnisotropyRadiance( geometryViewDir, geometryNormal, material.roughness, material.anisotropyB, material.anisotropy );
	#else
		radiance += getIBLRadiance( geometryViewDir, geometryNormal, material.roughness );
	#endif
	#ifdef USE_CLEARCOAT
		clearcoatRadiance += getIBLRadiance( geometryViewDir, geometryClearcoatNormal, material.clearcoatRoughness );
	#endif
#endif`,rp=`#if defined( RE_IndirectDiffuse )
	RE_IndirectDiffuse( irradiance, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
#endif
#if defined( RE_IndirectSpecular )
	RE_IndirectSpecular( radiance, iblIrradiance, clearcoatRadiance, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
#endif`,ap=`#if defined( USE_LOGDEPTHBUF ) && defined( USE_LOGDEPTHBUF_EXT )
	gl_FragDepthEXT = vIsPerspective == 0.0 ? gl_FragCoord.z : log2( vFragDepth ) * logDepthBufFC * 0.5;
#endif`,op=`#if defined( USE_LOGDEPTHBUF ) && defined( USE_LOGDEPTHBUF_EXT )
	uniform float logDepthBufFC;
	varying float vFragDepth;
	varying float vIsPerspective;
#endif`,lp=`#ifdef USE_LOGDEPTHBUF
	#ifdef USE_LOGDEPTHBUF_EXT
		varying float vFragDepth;
		varying float vIsPerspective;
	#else
		uniform float logDepthBufFC;
	#endif
#endif`,cp=`#ifdef USE_LOGDEPTHBUF
	#ifdef USE_LOGDEPTHBUF_EXT
		vFragDepth = 1.0 + gl_Position.w;
		vIsPerspective = float( isPerspectiveMatrix( projectionMatrix ) );
	#else
		if ( isPerspectiveMatrix( projectionMatrix ) ) {
			gl_Position.z = log2( max( EPSILON, gl_Position.w + 1.0 ) ) * logDepthBufFC - 1.0;
			gl_Position.z *= gl_Position.w;
		}
	#endif
#endif`,hp=`#ifdef USE_MAP
	vec4 sampledDiffuseColor = texture2D( map, vMapUv );
	#ifdef DECODE_VIDEO_TEXTURE
		sampledDiffuseColor = vec4( mix( pow( sampledDiffuseColor.rgb * 0.9478672986 + vec3( 0.0521327014 ), vec3( 2.4 ) ), sampledDiffuseColor.rgb * 0.0773993808, vec3( lessThanEqual( sampledDiffuseColor.rgb, vec3( 0.04045 ) ) ) ), sampledDiffuseColor.w );
	
	#endif
	diffuseColor *= sampledDiffuseColor;
#endif`,up=`#ifdef USE_MAP
	uniform sampler2D map;
#endif`,dp=`#if defined( USE_MAP ) || defined( USE_ALPHAMAP )
	#if defined( USE_POINTS_UV )
		vec2 uv = vUv;
	#else
		vec2 uv = ( uvTransform * vec3( gl_PointCoord.x, 1.0 - gl_PointCoord.y, 1 ) ).xy;
	#endif
#endif
#ifdef USE_MAP
	diffuseColor *= texture2D( map, uv );
#endif
#ifdef USE_ALPHAMAP
	diffuseColor.a *= texture2D( alphaMap, uv ).g;
#endif`,fp=`#if defined( USE_POINTS_UV )
	varying vec2 vUv;
#else
	#if defined( USE_MAP ) || defined( USE_ALPHAMAP )
		uniform mat3 uvTransform;
	#endif
#endif
#ifdef USE_MAP
	uniform sampler2D map;
#endif
#ifdef USE_ALPHAMAP
	uniform sampler2D alphaMap;
#endif`,pp=`float metalnessFactor = metalness;
#ifdef USE_METALNESSMAP
	vec4 texelMetalness = texture2D( metalnessMap, vMetalnessMapUv );
	metalnessFactor *= texelMetalness.b;
#endif`,mp=`#ifdef USE_METALNESSMAP
	uniform sampler2D metalnessMap;
#endif`,gp=`#if defined( USE_MORPHCOLORS ) && defined( MORPHTARGETS_TEXTURE )
	vColor *= morphTargetBaseInfluence;
	for ( int i = 0; i < MORPHTARGETS_COUNT; i ++ ) {
		#if defined( USE_COLOR_ALPHA )
			if ( morphTargetInfluences[ i ] != 0.0 ) vColor += getMorph( gl_VertexID, i, 2 ) * morphTargetInfluences[ i ];
		#elif defined( USE_COLOR )
			if ( morphTargetInfluences[ i ] != 0.0 ) vColor += getMorph( gl_VertexID, i, 2 ).rgb * morphTargetInfluences[ i ];
		#endif
	}
#endif`,xp=`#ifdef USE_MORPHNORMALS
	objectNormal *= morphTargetBaseInfluence;
	#ifdef MORPHTARGETS_TEXTURE
		for ( int i = 0; i < MORPHTARGETS_COUNT; i ++ ) {
			if ( morphTargetInfluences[ i ] != 0.0 ) objectNormal += getMorph( gl_VertexID, i, 1 ).xyz * morphTargetInfluences[ i ];
		}
	#else
		objectNormal += morphNormal0 * morphTargetInfluences[ 0 ];
		objectNormal += morphNormal1 * morphTargetInfluences[ 1 ];
		objectNormal += morphNormal2 * morphTargetInfluences[ 2 ];
		objectNormal += morphNormal3 * morphTargetInfluences[ 3 ];
	#endif
#endif`,_p=`#ifdef USE_MORPHTARGETS
	uniform float morphTargetBaseInfluence;
	#ifdef MORPHTARGETS_TEXTURE
		uniform float morphTargetInfluences[ MORPHTARGETS_COUNT ];
		uniform sampler2DArray morphTargetsTexture;
		uniform ivec2 morphTargetsTextureSize;
		vec4 getMorph( const in int vertexIndex, const in int morphTargetIndex, const in int offset ) {
			int texelIndex = vertexIndex * MORPHTARGETS_TEXTURE_STRIDE + offset;
			int y = texelIndex / morphTargetsTextureSize.x;
			int x = texelIndex - y * morphTargetsTextureSize.x;
			ivec3 morphUV = ivec3( x, y, morphTargetIndex );
			return texelFetch( morphTargetsTexture, morphUV, 0 );
		}
	#else
		#ifndef USE_MORPHNORMALS
			uniform float morphTargetInfluences[ 8 ];
		#else
			uniform float morphTargetInfluences[ 4 ];
		#endif
	#endif
#endif`,vp=`#ifdef USE_MORPHTARGETS
	transformed *= morphTargetBaseInfluence;
	#ifdef MORPHTARGETS_TEXTURE
		for ( int i = 0; i < MORPHTARGETS_COUNT; i ++ ) {
			if ( morphTargetInfluences[ i ] != 0.0 ) transformed += getMorph( gl_VertexID, i, 0 ).xyz * morphTargetInfluences[ i ];
		}
	#else
		transformed += morphTarget0 * morphTargetInfluences[ 0 ];
		transformed += morphTarget1 * morphTargetInfluences[ 1 ];
		transformed += morphTarget2 * morphTargetInfluences[ 2 ];
		transformed += morphTarget3 * morphTargetInfluences[ 3 ];
		#ifndef USE_MORPHNORMALS
			transformed += morphTarget4 * morphTargetInfluences[ 4 ];
			transformed += morphTarget5 * morphTargetInfluences[ 5 ];
			transformed += morphTarget6 * morphTargetInfluences[ 6 ];
			transformed += morphTarget7 * morphTargetInfluences[ 7 ];
		#endif
	#endif
#endif`,yp=`float faceDirection = gl_FrontFacing ? 1.0 : - 1.0;
#ifdef FLAT_SHADED
	vec3 fdx = dFdx( vViewPosition );
	vec3 fdy = dFdy( vViewPosition );
	vec3 normal = normalize( cross( fdx, fdy ) );
#else
	vec3 normal = normalize( vNormal );
	#ifdef DOUBLE_SIDED
		normal *= faceDirection;
	#endif
#endif
#if defined( USE_NORMALMAP_TANGENTSPACE ) || defined( USE_CLEARCOAT_NORMALMAP ) || defined( USE_ANISOTROPY )
	#ifdef USE_TANGENT
		mat3 tbn = mat3( normalize( vTangent ), normalize( vBitangent ), normal );
	#else
		mat3 tbn = getTangentFrame( - vViewPosition, normal,
		#if defined( USE_NORMALMAP )
			vNormalMapUv
		#elif defined( USE_CLEARCOAT_NORMALMAP )
			vClearcoatNormalMapUv
		#else
			vUv
		#endif
		);
	#endif
	#if defined( DOUBLE_SIDED ) && ! defined( FLAT_SHADED )
		tbn[0] *= faceDirection;
		tbn[1] *= faceDirection;
	#endif
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	#ifdef USE_TANGENT
		mat3 tbn2 = mat3( normalize( vTangent ), normalize( vBitangent ), normal );
	#else
		mat3 tbn2 = getTangentFrame( - vViewPosition, normal, vClearcoatNormalMapUv );
	#endif
	#if defined( DOUBLE_SIDED ) && ! defined( FLAT_SHADED )
		tbn2[0] *= faceDirection;
		tbn2[1] *= faceDirection;
	#endif
#endif
vec3 nonPerturbedNormal = normal;`,Mp=`#ifdef USE_NORMALMAP_OBJECTSPACE
	normal = texture2D( normalMap, vNormalMapUv ).xyz * 2.0 - 1.0;
	#ifdef FLIP_SIDED
		normal = - normal;
	#endif
	#ifdef DOUBLE_SIDED
		normal = normal * faceDirection;
	#endif
	normal = normalize( normalMatrix * normal );
#elif defined( USE_NORMALMAP_TANGENTSPACE )
	vec3 mapN = texture2D( normalMap, vNormalMapUv ).xyz * 2.0 - 1.0;
	mapN.xy *= normalScale;
	normal = normalize( tbn * mapN );
#elif defined( USE_BUMPMAP )
	normal = perturbNormalArb( - vViewPosition, normal, dHdxy_fwd(), faceDirection );
#endif`,bp=`#ifndef FLAT_SHADED
	varying vec3 vNormal;
	#ifdef USE_TANGENT
		varying vec3 vTangent;
		varying vec3 vBitangent;
	#endif
#endif`,Sp=`#ifndef FLAT_SHADED
	varying vec3 vNormal;
	#ifdef USE_TANGENT
		varying vec3 vTangent;
		varying vec3 vBitangent;
	#endif
#endif`,wp=`#ifndef FLAT_SHADED
	vNormal = normalize( transformedNormal );
	#ifdef USE_TANGENT
		vTangent = normalize( transformedTangent );
		vBitangent = normalize( cross( vNormal, vTangent ) * tangent.w );
	#endif
#endif`,Ep=`#ifdef USE_NORMALMAP
	uniform sampler2D normalMap;
	uniform vec2 normalScale;
#endif
#ifdef USE_NORMALMAP_OBJECTSPACE
	uniform mat3 normalMatrix;
#endif
#if ! defined ( USE_TANGENT ) && ( defined ( USE_NORMALMAP_TANGENTSPACE ) || defined ( USE_CLEARCOAT_NORMALMAP ) || defined( USE_ANISOTROPY ) )
	mat3 getTangentFrame( vec3 eye_pos, vec3 surf_norm, vec2 uv ) {
		vec3 q0 = dFdx( eye_pos.xyz );
		vec3 q1 = dFdy( eye_pos.xyz );
		vec2 st0 = dFdx( uv.st );
		vec2 st1 = dFdy( uv.st );
		vec3 N = surf_norm;
		vec3 q1perp = cross( q1, N );
		vec3 q0perp = cross( N, q0 );
		vec3 T = q1perp * st0.x + q0perp * st1.x;
		vec3 B = q1perp * st0.y + q0perp * st1.y;
		float det = max( dot( T, T ), dot( B, B ) );
		float scale = ( det == 0.0 ) ? 0.0 : inversesqrt( det );
		return mat3( T * scale, B * scale, N );
	}
#endif`,Tp=`#ifdef USE_CLEARCOAT
	vec3 clearcoatNormal = nonPerturbedNormal;
#endif`,Ap=`#ifdef USE_CLEARCOAT_NORMALMAP
	vec3 clearcoatMapN = texture2D( clearcoatNormalMap, vClearcoatNormalMapUv ).xyz * 2.0 - 1.0;
	clearcoatMapN.xy *= clearcoatNormalScale;
	clearcoatNormal = normalize( tbn2 * clearcoatMapN );
#endif`,Cp=`#ifdef USE_CLEARCOATMAP
	uniform sampler2D clearcoatMap;
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	uniform sampler2D clearcoatNormalMap;
	uniform vec2 clearcoatNormalScale;
#endif
#ifdef USE_CLEARCOAT_ROUGHNESSMAP
	uniform sampler2D clearcoatRoughnessMap;
#endif`,Rp=`#ifdef USE_IRIDESCENCEMAP
	uniform sampler2D iridescenceMap;
#endif
#ifdef USE_IRIDESCENCE_THICKNESSMAP
	uniform sampler2D iridescenceThicknessMap;
#endif`,Pp=`#ifdef OPAQUE
diffuseColor.a = 1.0;
#endif
#ifdef USE_TRANSMISSION
diffuseColor.a *= material.transmissionAlpha;
#endif
gl_FragColor = vec4( outgoingLight, diffuseColor.a );`,Lp=`vec3 packNormalToRGB( const in vec3 normal ) {
	return normalize( normal ) * 0.5 + 0.5;
}
vec3 unpackRGBToNormal( const in vec3 rgb ) {
	return 2.0 * rgb.xyz - 1.0;
}
const float PackUpscale = 256. / 255.;const float UnpackDownscale = 255. / 256.;
const vec3 PackFactors = vec3( 256. * 256. * 256., 256. * 256., 256. );
const vec4 UnpackFactors = UnpackDownscale / vec4( PackFactors, 1. );
const float ShiftRight8 = 1. / 256.;
vec4 packDepthToRGBA( const in float v ) {
	vec4 r = vec4( fract( v * PackFactors ), v );
	r.yzw -= r.xyz * ShiftRight8;	return r * PackUpscale;
}
float unpackRGBAToDepth( const in vec4 v ) {
	return dot( v, UnpackFactors );
}
vec2 packDepthToRG( in highp float v ) {
	return packDepthToRGBA( v ).yx;
}
float unpackRGToDepth( const in highp vec2 v ) {
	return unpackRGBAToDepth( vec4( v.xy, 0.0, 0.0 ) );
}
vec4 pack2HalfToRGBA( vec2 v ) {
	vec4 r = vec4( v.x, fract( v.x * 255.0 ), v.y, fract( v.y * 255.0 ) );
	return vec4( r.x - r.y / 255.0, r.y, r.z - r.w / 255.0, r.w );
}
vec2 unpackRGBATo2Half( vec4 v ) {
	return vec2( v.x + ( v.y / 255.0 ), v.z + ( v.w / 255.0 ) );
}
float viewZToOrthographicDepth( const in float viewZ, const in float near, const in float far ) {
	return ( viewZ + near ) / ( near - far );
}
float orthographicDepthToViewZ( const in float depth, const in float near, const in float far ) {
	return depth * ( near - far ) - near;
}
float viewZToPerspectiveDepth( const in float viewZ, const in float near, const in float far ) {
	return ( ( near + viewZ ) * far ) / ( ( far - near ) * viewZ );
}
float perspectiveDepthToViewZ( const in float depth, const in float near, const in float far ) {
	return ( near * far ) / ( ( far - near ) * depth - far );
}`,Ip=`#ifdef PREMULTIPLIED_ALPHA
	gl_FragColor.rgb *= gl_FragColor.a;
#endif`,Dp=`vec4 mvPosition = vec4( transformed, 1.0 );
#ifdef USE_BATCHING
	mvPosition = batchingMatrix * mvPosition;
#endif
#ifdef USE_INSTANCING
	mvPosition = instanceMatrix * mvPosition;
#endif
mvPosition = modelViewMatrix * mvPosition;
gl_Position = projectionMatrix * mvPosition;`,Up=`#ifdef DITHERING
	gl_FragColor.rgb = dithering( gl_FragColor.rgb );
#endif`,Np=`#ifdef DITHERING
	vec3 dithering( vec3 color ) {
		float grid_position = rand( gl_FragCoord.xy );
		vec3 dither_shift_RGB = vec3( 0.25 / 255.0, -0.25 / 255.0, 0.25 / 255.0 );
		dither_shift_RGB = mix( 2.0 * dither_shift_RGB, -2.0 * dither_shift_RGB, grid_position );
		return color + dither_shift_RGB;
	}
#endif`,Op=`float roughnessFactor = roughness;
#ifdef USE_ROUGHNESSMAP
	vec4 texelRoughness = texture2D( roughnessMap, vRoughnessMapUv );
	roughnessFactor *= texelRoughness.g;
#endif`,Fp=`#ifdef USE_ROUGHNESSMAP
	uniform sampler2D roughnessMap;
#endif`,Bp=`#if NUM_SPOT_LIGHT_COORDS > 0
	varying vec4 vSpotLightCoord[ NUM_SPOT_LIGHT_COORDS ];
#endif
#if NUM_SPOT_LIGHT_MAPS > 0
	uniform sampler2D spotLightMap[ NUM_SPOT_LIGHT_MAPS ];
#endif
#ifdef USE_SHADOWMAP
	#if NUM_DIR_LIGHT_SHADOWS > 0
		uniform sampler2D directionalShadowMap[ NUM_DIR_LIGHT_SHADOWS ];
		varying vec4 vDirectionalShadowCoord[ NUM_DIR_LIGHT_SHADOWS ];
		struct DirectionalLightShadow {
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};
		uniform DirectionalLightShadow directionalLightShadows[ NUM_DIR_LIGHT_SHADOWS ];
	#endif
	#if NUM_SPOT_LIGHT_SHADOWS > 0
		uniform sampler2D spotShadowMap[ NUM_SPOT_LIGHT_SHADOWS ];
		struct SpotLightShadow {
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};
		uniform SpotLightShadow spotLightShadows[ NUM_SPOT_LIGHT_SHADOWS ];
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0
		uniform sampler2D pointShadowMap[ NUM_POINT_LIGHT_SHADOWS ];
		varying vec4 vPointShadowCoord[ NUM_POINT_LIGHT_SHADOWS ];
		struct PointLightShadow {
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
			float shadowCameraNear;
			float shadowCameraFar;
		};
		uniform PointLightShadow pointLightShadows[ NUM_POINT_LIGHT_SHADOWS ];
	#endif
	float texture2DCompare( sampler2D depths, vec2 uv, float compare ) {
		return step( compare, unpackRGBAToDepth( texture2D( depths, uv ) ) );
	}
	vec2 texture2DDistribution( sampler2D shadow, vec2 uv ) {
		return unpackRGBATo2Half( texture2D( shadow, uv ) );
	}
	float VSMShadow (sampler2D shadow, vec2 uv, float compare ){
		float occlusion = 1.0;
		vec2 distribution = texture2DDistribution( shadow, uv );
		float hard_shadow = step( compare , distribution.x );
		if (hard_shadow != 1.0 ) {
			float distance = compare - distribution.x ;
			float variance = max( 0.00000, distribution.y * distribution.y );
			float softness_probability = variance / (variance + distance * distance );			softness_probability = clamp( ( softness_probability - 0.3 ) / ( 0.95 - 0.3 ), 0.0, 1.0 );			occlusion = clamp( max( hard_shadow, softness_probability ), 0.0, 1.0 );
		}
		return occlusion;
	}
	float getShadow( sampler2D shadowMap, vec2 shadowMapSize, float shadowBias, float shadowRadius, vec4 shadowCoord ) {
		float shadow = 1.0;
		shadowCoord.xyz /= shadowCoord.w;
		shadowCoord.z += shadowBias;
		bool inFrustum = shadowCoord.x >= 0.0 && shadowCoord.x <= 1.0 && shadowCoord.y >= 0.0 && shadowCoord.y <= 1.0;
		bool frustumTest = inFrustum && shadowCoord.z <= 1.0;
		if ( frustumTest ) {
		#if defined( SHADOWMAP_TYPE_PCF )
			vec2 texelSize = vec2( 1.0 ) / shadowMapSize;
			float dx0 = - texelSize.x * shadowRadius;
			float dy0 = - texelSize.y * shadowRadius;
			float dx1 = + texelSize.x * shadowRadius;
			float dy1 = + texelSize.y * shadowRadius;
			float dx2 = dx0 / 2.0;
			float dy2 = dy0 / 2.0;
			float dx3 = dx1 / 2.0;
			float dy3 = dy1 / 2.0;
			shadow = (
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx0, dy0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( 0.0, dy0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx1, dy0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx2, dy2 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( 0.0, dy2 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx3, dy2 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx0, 0.0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx2, 0.0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy, shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx3, 0.0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx1, 0.0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx2, dy3 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( 0.0, dy3 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx3, dy3 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx0, dy1 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( 0.0, dy1 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx1, dy1 ), shadowCoord.z )
			) * ( 1.0 / 17.0 );
		#elif defined( SHADOWMAP_TYPE_PCF_SOFT )
			vec2 texelSize = vec2( 1.0 ) / shadowMapSize;
			float dx = texelSize.x;
			float dy = texelSize.y;
			vec2 uv = shadowCoord.xy;
			vec2 f = fract( uv * shadowMapSize + 0.5 );
			uv -= f * texelSize;
			shadow = (
				texture2DCompare( shadowMap, uv, shadowCoord.z ) +
				texture2DCompare( shadowMap, uv + vec2( dx, 0.0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, uv + vec2( 0.0, dy ), shadowCoord.z ) +
				texture2DCompare( shadowMap, uv + texelSize, shadowCoord.z ) +
				mix( texture2DCompare( shadowMap, uv + vec2( -dx, 0.0 ), shadowCoord.z ),
					 texture2DCompare( shadowMap, uv + vec2( 2.0 * dx, 0.0 ), shadowCoord.z ),
					 f.x ) +
				mix( texture2DCompare( shadowMap, uv + vec2( -dx, dy ), shadowCoord.z ),
					 texture2DCompare( shadowMap, uv + vec2( 2.0 * dx, dy ), shadowCoord.z ),
					 f.x ) +
				mix( texture2DCompare( shadowMap, uv + vec2( 0.0, -dy ), shadowCoord.z ),
					 texture2DCompare( shadowMap, uv + vec2( 0.0, 2.0 * dy ), shadowCoord.z ),
					 f.y ) +
				mix( texture2DCompare( shadowMap, uv + vec2( dx, -dy ), shadowCoord.z ),
					 texture2DCompare( shadowMap, uv + vec2( dx, 2.0 * dy ), shadowCoord.z ),
					 f.y ) +
				mix( mix( texture2DCompare( shadowMap, uv + vec2( -dx, -dy ), shadowCoord.z ),
						  texture2DCompare( shadowMap, uv + vec2( 2.0 * dx, -dy ), shadowCoord.z ),
						  f.x ),
					 mix( texture2DCompare( shadowMap, uv + vec2( -dx, 2.0 * dy ), shadowCoord.z ),
						  texture2DCompare( shadowMap, uv + vec2( 2.0 * dx, 2.0 * dy ), shadowCoord.z ),
						  f.x ),
					 f.y )
			) * ( 1.0 / 9.0 );
		#elif defined( SHADOWMAP_TYPE_VSM )
			shadow = VSMShadow( shadowMap, shadowCoord.xy, shadowCoord.z );
		#else
			shadow = texture2DCompare( shadowMap, shadowCoord.xy, shadowCoord.z );
		#endif
		}
		return shadow;
	}
	vec2 cubeToUV( vec3 v, float texelSizeY ) {
		vec3 absV = abs( v );
		float scaleToCube = 1.0 / max( absV.x, max( absV.y, absV.z ) );
		absV *= scaleToCube;
		v *= scaleToCube * ( 1.0 - 2.0 * texelSizeY );
		vec2 planar = v.xy;
		float almostATexel = 1.5 * texelSizeY;
		float almostOne = 1.0 - almostATexel;
		if ( absV.z >= almostOne ) {
			if ( v.z > 0.0 )
				planar.x = 4.0 - v.x;
		} else if ( absV.x >= almostOne ) {
			float signX = sign( v.x );
			planar.x = v.z * signX + 2.0 * signX;
		} else if ( absV.y >= almostOne ) {
			float signY = sign( v.y );
			planar.x = v.x + 2.0 * signY + 2.0;
			planar.y = v.z * signY - 2.0;
		}
		return vec2( 0.125, 0.25 ) * planar + vec2( 0.375, 0.75 );
	}
	float getPointShadow( sampler2D shadowMap, vec2 shadowMapSize, float shadowBias, float shadowRadius, vec4 shadowCoord, float shadowCameraNear, float shadowCameraFar ) {
		vec2 texelSize = vec2( 1.0 ) / ( shadowMapSize * vec2( 4.0, 2.0 ) );
		vec3 lightToPosition = shadowCoord.xyz;
		float dp = ( length( lightToPosition ) - shadowCameraNear ) / ( shadowCameraFar - shadowCameraNear );		dp += shadowBias;
		vec3 bd3D = normalize( lightToPosition );
		#if defined( SHADOWMAP_TYPE_PCF ) || defined( SHADOWMAP_TYPE_PCF_SOFT ) || defined( SHADOWMAP_TYPE_VSM )
			vec2 offset = vec2( - 1, 1 ) * shadowRadius * texelSize.y;
			return (
				texture2DCompare( shadowMap, cubeToUV( bd3D + offset.xyy, texelSize.y ), dp ) +
				texture2DCompare( shadowMap, cubeToUV( bd3D + offset.yyy, texelSize.y ), dp ) +
				texture2DCompare( shadowMap, cubeToUV( bd3D + offset.xyx, texelSize.y ), dp ) +
				texture2DCompare( shadowMap, cubeToUV( bd3D + offset.yyx, texelSize.y ), dp ) +
				texture2DCompare( shadowMap, cubeToUV( bd3D, texelSize.y ), dp ) +
				texture2DCompare( shadowMap, cubeToUV( bd3D + offset.xxy, texelSize.y ), dp ) +
				texture2DCompare( shadowMap, cubeToUV( bd3D + offset.yxy, texelSize.y ), dp ) +
				texture2DCompare( shadowMap, cubeToUV( bd3D + offset.xxx, texelSize.y ), dp ) +
				texture2DCompare( shadowMap, cubeToUV( bd3D + offset.yxx, texelSize.y ), dp )
			) * ( 1.0 / 9.0 );
		#else
			return texture2DCompare( shadowMap, cubeToUV( bd3D, texelSize.y ), dp );
		#endif
	}
#endif`,zp=`#if NUM_SPOT_LIGHT_COORDS > 0
	uniform mat4 spotLightMatrix[ NUM_SPOT_LIGHT_COORDS ];
	varying vec4 vSpotLightCoord[ NUM_SPOT_LIGHT_COORDS ];
#endif
#ifdef USE_SHADOWMAP
	#if NUM_DIR_LIGHT_SHADOWS > 0
		uniform mat4 directionalShadowMatrix[ NUM_DIR_LIGHT_SHADOWS ];
		varying vec4 vDirectionalShadowCoord[ NUM_DIR_LIGHT_SHADOWS ];
		struct DirectionalLightShadow {
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};
		uniform DirectionalLightShadow directionalLightShadows[ NUM_DIR_LIGHT_SHADOWS ];
	#endif
	#if NUM_SPOT_LIGHT_SHADOWS > 0
		struct SpotLightShadow {
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};
		uniform SpotLightShadow spotLightShadows[ NUM_SPOT_LIGHT_SHADOWS ];
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0
		uniform mat4 pointShadowMatrix[ NUM_POINT_LIGHT_SHADOWS ];
		varying vec4 vPointShadowCoord[ NUM_POINT_LIGHT_SHADOWS ];
		struct PointLightShadow {
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
			float shadowCameraNear;
			float shadowCameraFar;
		};
		uniform PointLightShadow pointLightShadows[ NUM_POINT_LIGHT_SHADOWS ];
	#endif
#endif`,kp=`#if ( defined( USE_SHADOWMAP ) && ( NUM_DIR_LIGHT_SHADOWS > 0 || NUM_POINT_LIGHT_SHADOWS > 0 ) ) || ( NUM_SPOT_LIGHT_COORDS > 0 )
	vec3 shadowWorldNormal = inverseTransformDirection( transformedNormal, viewMatrix );
	vec4 shadowWorldPosition;
#endif
#if defined( USE_SHADOWMAP )
	#if NUM_DIR_LIGHT_SHADOWS > 0
		#pragma unroll_loop_start
		for ( int i = 0; i < NUM_DIR_LIGHT_SHADOWS; i ++ ) {
			shadowWorldPosition = worldPosition + vec4( shadowWorldNormal * directionalLightShadows[ i ].shadowNormalBias, 0 );
			vDirectionalShadowCoord[ i ] = directionalShadowMatrix[ i ] * shadowWorldPosition;
		}
		#pragma unroll_loop_end
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0
		#pragma unroll_loop_start
		for ( int i = 0; i < NUM_POINT_LIGHT_SHADOWS; i ++ ) {
			shadowWorldPosition = worldPosition + vec4( shadowWorldNormal * pointLightShadows[ i ].shadowNormalBias, 0 );
			vPointShadowCoord[ i ] = pointShadowMatrix[ i ] * shadowWorldPosition;
		}
		#pragma unroll_loop_end
	#endif
#endif
#if NUM_SPOT_LIGHT_COORDS > 0
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_SPOT_LIGHT_COORDS; i ++ ) {
		shadowWorldPosition = worldPosition;
		#if ( defined( USE_SHADOWMAP ) && UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS )
			shadowWorldPosition.xyz += shadowWorldNormal * spotLightShadows[ i ].shadowNormalBias;
		#endif
		vSpotLightCoord[ i ] = spotLightMatrix[ i ] * shadowWorldPosition;
	}
	#pragma unroll_loop_end
#endif`,Hp=`float getShadowMask() {
	float shadow = 1.0;
	#ifdef USE_SHADOWMAP
	#if NUM_DIR_LIGHT_SHADOWS > 0
	DirectionalLightShadow directionalLight;
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_DIR_LIGHT_SHADOWS; i ++ ) {
		directionalLight = directionalLightShadows[ i ];
		shadow *= receiveShadow ? getShadow( directionalShadowMap[ i ], directionalLight.shadowMapSize, directionalLight.shadowBias, directionalLight.shadowRadius, vDirectionalShadowCoord[ i ] ) : 1.0;
	}
	#pragma unroll_loop_end
	#endif
	#if NUM_SPOT_LIGHT_SHADOWS > 0
	SpotLightShadow spotLight;
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_SPOT_LIGHT_SHADOWS; i ++ ) {
		spotLight = spotLightShadows[ i ];
		shadow *= receiveShadow ? getShadow( spotShadowMap[ i ], spotLight.shadowMapSize, spotLight.shadowBias, spotLight.shadowRadius, vSpotLightCoord[ i ] ) : 1.0;
	}
	#pragma unroll_loop_end
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0
	PointLightShadow pointLight;
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_POINT_LIGHT_SHADOWS; i ++ ) {
		pointLight = pointLightShadows[ i ];
		shadow *= receiveShadow ? getPointShadow( pointShadowMap[ i ], pointLight.shadowMapSize, pointLight.shadowBias, pointLight.shadowRadius, vPointShadowCoord[ i ], pointLight.shadowCameraNear, pointLight.shadowCameraFar ) : 1.0;
	}
	#pragma unroll_loop_end
	#endif
	#endif
	return shadow;
}`,Vp=`#ifdef USE_SKINNING
	mat4 boneMatX = getBoneMatrix( skinIndex.x );
	mat4 boneMatY = getBoneMatrix( skinIndex.y );
	mat4 boneMatZ = getBoneMatrix( skinIndex.z );
	mat4 boneMatW = getBoneMatrix( skinIndex.w );
#endif`,Gp=`#ifdef USE_SKINNING
	uniform mat4 bindMatrix;
	uniform mat4 bindMatrixInverse;
	uniform highp sampler2D boneTexture;
	mat4 getBoneMatrix( const in float i ) {
		int size = textureSize( boneTexture, 0 ).x;
		int j = int( i ) * 4;
		int x = j % size;
		int y = j / size;
		vec4 v1 = texelFetch( boneTexture, ivec2( x, y ), 0 );
		vec4 v2 = texelFetch( boneTexture, ivec2( x + 1, y ), 0 );
		vec4 v3 = texelFetch( boneTexture, ivec2( x + 2, y ), 0 );
		vec4 v4 = texelFetch( boneTexture, ivec2( x + 3, y ), 0 );
		return mat4( v1, v2, v3, v4 );
	}
#endif`,Wp=`#ifdef USE_SKINNING
	vec4 skinVertex = bindMatrix * vec4( transformed, 1.0 );
	vec4 skinned = vec4( 0.0 );
	skinned += boneMatX * skinVertex * skinWeight.x;
	skinned += boneMatY * skinVertex * skinWeight.y;
	skinned += boneMatZ * skinVertex * skinWeight.z;
	skinned += boneMatW * skinVertex * skinWeight.w;
	transformed = ( bindMatrixInverse * skinned ).xyz;
#endif`,Xp=`#ifdef USE_SKINNING
	mat4 skinMatrix = mat4( 0.0 );
	skinMatrix += skinWeight.x * boneMatX;
	skinMatrix += skinWeight.y * boneMatY;
	skinMatrix += skinWeight.z * boneMatZ;
	skinMatrix += skinWeight.w * boneMatW;
	skinMatrix = bindMatrixInverse * skinMatrix * bindMatrix;
	objectNormal = vec4( skinMatrix * vec4( objectNormal, 0.0 ) ).xyz;
	#ifdef USE_TANGENT
		objectTangent = vec4( skinMatrix * vec4( objectTangent, 0.0 ) ).xyz;
	#endif
#endif`,Yp=`float specularStrength;
#ifdef USE_SPECULARMAP
	vec4 texelSpecular = texture2D( specularMap, vSpecularMapUv );
	specularStrength = texelSpecular.r;
#else
	specularStrength = 1.0;
#endif`,qp=`#ifdef USE_SPECULARMAP
	uniform sampler2D specularMap;
#endif`,Zp=`#if defined( TONE_MAPPING )
	gl_FragColor.rgb = toneMapping( gl_FragColor.rgb );
#endif`,Jp=`#ifndef saturate
#define saturate( a ) clamp( a, 0.0, 1.0 )
#endif
uniform float toneMappingExposure;
vec3 LinearToneMapping( vec3 color ) {
	return saturate( toneMappingExposure * color );
}
vec3 ReinhardToneMapping( vec3 color ) {
	color *= toneMappingExposure;
	return saturate( color / ( vec3( 1.0 ) + color ) );
}
vec3 OptimizedCineonToneMapping( vec3 color ) {
	color *= toneMappingExposure;
	color = max( vec3( 0.0 ), color - 0.004 );
	return pow( ( color * ( 6.2 * color + 0.5 ) ) / ( color * ( 6.2 * color + 1.7 ) + 0.06 ), vec3( 2.2 ) );
}
vec3 RRTAndODTFit( vec3 v ) {
	vec3 a = v * ( v + 0.0245786 ) - 0.000090537;
	vec3 b = v * ( 0.983729 * v + 0.4329510 ) + 0.238081;
	return a / b;
}
vec3 ACESFilmicToneMapping( vec3 color ) {
	const mat3 ACESInputMat = mat3(
		vec3( 0.59719, 0.07600, 0.02840 ),		vec3( 0.35458, 0.90834, 0.13383 ),
		vec3( 0.04823, 0.01566, 0.83777 )
	);
	const mat3 ACESOutputMat = mat3(
		vec3(  1.60475, -0.10208, -0.00327 ),		vec3( -0.53108,  1.10813, -0.07276 ),
		vec3( -0.07367, -0.00605,  1.07602 )
	);
	color *= toneMappingExposure / 0.6;
	color = ACESInputMat * color;
	color = RRTAndODTFit( color );
	color = ACESOutputMat * color;
	return saturate( color );
}
const mat3 LINEAR_REC2020_TO_LINEAR_SRGB = mat3(
	vec3( 1.6605, - 0.1246, - 0.0182 ),
	vec3( - 0.5876, 1.1329, - 0.1006 ),
	vec3( - 0.0728, - 0.0083, 1.1187 )
);
const mat3 LINEAR_SRGB_TO_LINEAR_REC2020 = mat3(
	vec3( 0.6274, 0.0691, 0.0164 ),
	vec3( 0.3293, 0.9195, 0.0880 ),
	vec3( 0.0433, 0.0113, 0.8956 )
);
vec3 agxDefaultContrastApprox( vec3 x ) {
	vec3 x2 = x * x;
	vec3 x4 = x2 * x2;
	return + 15.5 * x4 * x2
		- 40.14 * x4 * x
		+ 31.96 * x4
		- 6.868 * x2 * x
		+ 0.4298 * x2
		+ 0.1191 * x
		- 0.00232;
}
vec3 AgXToneMapping( vec3 color ) {
	const mat3 AgXInsetMatrix = mat3(
		vec3( 0.856627153315983, 0.137318972929847, 0.11189821299995 ),
		vec3( 0.0951212405381588, 0.761241990602591, 0.0767994186031903 ),
		vec3( 0.0482516061458583, 0.101439036467562, 0.811302368396859 )
	);
	const mat3 AgXOutsetMatrix = mat3(
		vec3( 1.1271005818144368, - 0.1413297634984383, - 0.14132976349843826 ),
		vec3( - 0.11060664309660323, 1.157823702216272, - 0.11060664309660294 ),
		vec3( - 0.016493938717834573, - 0.016493938717834257, 1.2519364065950405 )
	);
	const float AgxMinEv = - 12.47393;	const float AgxMaxEv = 4.026069;
	color = LINEAR_SRGB_TO_LINEAR_REC2020 * color;
	color *= toneMappingExposure;
	color = AgXInsetMatrix * color;
	color = max( color, 1e-10 );	color = log2( color );
	color = ( color - AgxMinEv ) / ( AgxMaxEv - AgxMinEv );
	color = clamp( color, 0.0, 1.0 );
	color = agxDefaultContrastApprox( color );
	color = AgXOutsetMatrix * color;
	color = pow( max( vec3( 0.0 ), color ), vec3( 2.2 ) );
	color = LINEAR_REC2020_TO_LINEAR_SRGB * color;
	return color;
}
vec3 CustomToneMapping( vec3 color ) { return color; }`,$p=`#ifdef USE_TRANSMISSION
	material.transmission = transmission;
	material.transmissionAlpha = 1.0;
	material.thickness = thickness;
	material.attenuationDistance = attenuationDistance;
	material.attenuationColor = attenuationColor;
	#ifdef USE_TRANSMISSIONMAP
		material.transmission *= texture2D( transmissionMap, vTransmissionMapUv ).r;
	#endif
	#ifdef USE_THICKNESSMAP
		material.thickness *= texture2D( thicknessMap, vThicknessMapUv ).g;
	#endif
	vec3 pos = vWorldPosition;
	vec3 v = normalize( cameraPosition - pos );
	vec3 n = inverseTransformDirection( normal, viewMatrix );
	vec4 transmitted = getIBLVolumeRefraction(
		n, v, material.roughness, material.diffuseColor, material.specularColor, material.specularF90,
		pos, modelMatrix, viewMatrix, projectionMatrix, material.ior, material.thickness,
		material.attenuationColor, material.attenuationDistance );
	material.transmissionAlpha = mix( material.transmissionAlpha, transmitted.a, material.transmission );
	totalDiffuse = mix( totalDiffuse, transmitted.rgb, material.transmission );
#endif`,jp=`#ifdef USE_TRANSMISSION
	uniform float transmission;
	uniform float thickness;
	uniform float attenuationDistance;
	uniform vec3 attenuationColor;
	#ifdef USE_TRANSMISSIONMAP
		uniform sampler2D transmissionMap;
	#endif
	#ifdef USE_THICKNESSMAP
		uniform sampler2D thicknessMap;
	#endif
	uniform vec2 transmissionSamplerSize;
	uniform sampler2D transmissionSamplerMap;
	uniform mat4 modelMatrix;
	uniform mat4 projectionMatrix;
	varying vec3 vWorldPosition;
	float w0( float a ) {
		return ( 1.0 / 6.0 ) * ( a * ( a * ( - a + 3.0 ) - 3.0 ) + 1.0 );
	}
	float w1( float a ) {
		return ( 1.0 / 6.0 ) * ( a *  a * ( 3.0 * a - 6.0 ) + 4.0 );
	}
	float w2( float a ){
		return ( 1.0 / 6.0 ) * ( a * ( a * ( - 3.0 * a + 3.0 ) + 3.0 ) + 1.0 );
	}
	float w3( float a ) {
		return ( 1.0 / 6.0 ) * ( a * a * a );
	}
	float g0( float a ) {
		return w0( a ) + w1( a );
	}
	float g1( float a ) {
		return w2( a ) + w3( a );
	}
	float h0( float a ) {
		return - 1.0 + w1( a ) / ( w0( a ) + w1( a ) );
	}
	float h1( float a ) {
		return 1.0 + w3( a ) / ( w2( a ) + w3( a ) );
	}
	vec4 bicubic( sampler2D tex, vec2 uv, vec4 texelSize, float lod ) {
		uv = uv * texelSize.zw + 0.5;
		vec2 iuv = floor( uv );
		vec2 fuv = fract( uv );
		float g0x = g0( fuv.x );
		float g1x = g1( fuv.x );
		float h0x = h0( fuv.x );
		float h1x = h1( fuv.x );
		float h0y = h0( fuv.y );
		float h1y = h1( fuv.y );
		vec2 p0 = ( vec2( iuv.x + h0x, iuv.y + h0y ) - 0.5 ) * texelSize.xy;
		vec2 p1 = ( vec2( iuv.x + h1x, iuv.y + h0y ) - 0.5 ) * texelSize.xy;
		vec2 p2 = ( vec2( iuv.x + h0x, iuv.y + h1y ) - 0.5 ) * texelSize.xy;
		vec2 p3 = ( vec2( iuv.x + h1x, iuv.y + h1y ) - 0.5 ) * texelSize.xy;
		return g0( fuv.y ) * ( g0x * textureLod( tex, p0, lod ) + g1x * textureLod( tex, p1, lod ) ) +
			g1( fuv.y ) * ( g0x * textureLod( tex, p2, lod ) + g1x * textureLod( tex, p3, lod ) );
	}
	vec4 textureBicubic( sampler2D sampler, vec2 uv, float lod ) {
		vec2 fLodSize = vec2( textureSize( sampler, int( lod ) ) );
		vec2 cLodSize = vec2( textureSize( sampler, int( lod + 1.0 ) ) );
		vec2 fLodSizeInv = 1.0 / fLodSize;
		vec2 cLodSizeInv = 1.0 / cLodSize;
		vec4 fSample = bicubic( sampler, uv, vec4( fLodSizeInv, fLodSize ), floor( lod ) );
		vec4 cSample = bicubic( sampler, uv, vec4( cLodSizeInv, cLodSize ), ceil( lod ) );
		return mix( fSample, cSample, fract( lod ) );
	}
	vec3 getVolumeTransmissionRay( const in vec3 n, const in vec3 v, const in float thickness, const in float ior, const in mat4 modelMatrix ) {
		vec3 refractionVector = refract( - v, normalize( n ), 1.0 / ior );
		vec3 modelScale;
		modelScale.x = length( vec3( modelMatrix[ 0 ].xyz ) );
		modelScale.y = length( vec3( modelMatrix[ 1 ].xyz ) );
		modelScale.z = length( vec3( modelMatrix[ 2 ].xyz ) );
		return normalize( refractionVector ) * thickness * modelScale;
	}
	float applyIorToRoughness( const in float roughness, const in float ior ) {
		return roughness * clamp( ior * 2.0 - 2.0, 0.0, 1.0 );
	}
	vec4 getTransmissionSample( const in vec2 fragCoord, const in float roughness, const in float ior ) {
		float lod = log2( transmissionSamplerSize.x ) * applyIorToRoughness( roughness, ior );
		return textureBicubic( transmissionSamplerMap, fragCoord.xy, lod );
	}
	vec3 volumeAttenuation( const in float transmissionDistance, const in vec3 attenuationColor, const in float attenuationDistance ) {
		if ( isinf( attenuationDistance ) ) {
			return vec3( 1.0 );
		} else {
			vec3 attenuationCoefficient = -log( attenuationColor ) / attenuationDistance;
			vec3 transmittance = exp( - attenuationCoefficient * transmissionDistance );			return transmittance;
		}
	}
	vec4 getIBLVolumeRefraction( const in vec3 n, const in vec3 v, const in float roughness, const in vec3 diffuseColor,
		const in vec3 specularColor, const in float specularF90, const in vec3 position, const in mat4 modelMatrix,
		const in mat4 viewMatrix, const in mat4 projMatrix, const in float ior, const in float thickness,
		const in vec3 attenuationColor, const in float attenuationDistance ) {
		vec3 transmissionRay = getVolumeTransmissionRay( n, v, thickness, ior, modelMatrix );
		vec3 refractedRayExit = position + transmissionRay;
		vec4 ndcPos = projMatrix * viewMatrix * vec4( refractedRayExit, 1.0 );
		vec2 refractionCoords = ndcPos.xy / ndcPos.w;
		refractionCoords += 1.0;
		refractionCoords /= 2.0;
		vec4 transmittedLight = getTransmissionSample( refractionCoords, roughness, ior );
		vec3 transmittance = diffuseColor * volumeAttenuation( length( transmissionRay ), attenuationColor, attenuationDistance );
		vec3 attenuatedColor = transmittance * transmittedLight.rgb;
		vec3 F = EnvironmentBRDF( n, v, specularColor, specularF90, roughness );
		float transmittanceFactor = ( transmittance.r + transmittance.g + transmittance.b ) / 3.0;
		return vec4( ( 1.0 - F ) * attenuatedColor, 1.0 - ( 1.0 - transmittedLight.a ) * transmittanceFactor );
	}
#endif`,Kp=`#if defined( USE_UV ) || defined( USE_ANISOTROPY )
	varying vec2 vUv;
#endif
#ifdef USE_MAP
	varying vec2 vMapUv;
#endif
#ifdef USE_ALPHAMAP
	varying vec2 vAlphaMapUv;
#endif
#ifdef USE_LIGHTMAP
	varying vec2 vLightMapUv;
#endif
#ifdef USE_AOMAP
	varying vec2 vAoMapUv;
#endif
#ifdef USE_BUMPMAP
	varying vec2 vBumpMapUv;
#endif
#ifdef USE_NORMALMAP
	varying vec2 vNormalMapUv;
#endif
#ifdef USE_EMISSIVEMAP
	varying vec2 vEmissiveMapUv;
#endif
#ifdef USE_METALNESSMAP
	varying vec2 vMetalnessMapUv;
#endif
#ifdef USE_ROUGHNESSMAP
	varying vec2 vRoughnessMapUv;
#endif
#ifdef USE_ANISOTROPYMAP
	varying vec2 vAnisotropyMapUv;
#endif
#ifdef USE_CLEARCOATMAP
	varying vec2 vClearcoatMapUv;
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	varying vec2 vClearcoatNormalMapUv;
#endif
#ifdef USE_CLEARCOAT_ROUGHNESSMAP
	varying vec2 vClearcoatRoughnessMapUv;
#endif
#ifdef USE_IRIDESCENCEMAP
	varying vec2 vIridescenceMapUv;
#endif
#ifdef USE_IRIDESCENCE_THICKNESSMAP
	varying vec2 vIridescenceThicknessMapUv;
#endif
#ifdef USE_SHEEN_COLORMAP
	varying vec2 vSheenColorMapUv;
#endif
#ifdef USE_SHEEN_ROUGHNESSMAP
	varying vec2 vSheenRoughnessMapUv;
#endif
#ifdef USE_SPECULARMAP
	varying vec2 vSpecularMapUv;
#endif
#ifdef USE_SPECULAR_COLORMAP
	varying vec2 vSpecularColorMapUv;
#endif
#ifdef USE_SPECULAR_INTENSITYMAP
	varying vec2 vSpecularIntensityMapUv;
#endif
#ifdef USE_TRANSMISSIONMAP
	uniform mat3 transmissionMapTransform;
	varying vec2 vTransmissionMapUv;
#endif
#ifdef USE_THICKNESSMAP
	uniform mat3 thicknessMapTransform;
	varying vec2 vThicknessMapUv;
#endif`,Qp=`#if defined( USE_UV ) || defined( USE_ANISOTROPY )
	varying vec2 vUv;
#endif
#ifdef USE_MAP
	uniform mat3 mapTransform;
	varying vec2 vMapUv;
#endif
#ifdef USE_ALPHAMAP
	uniform mat3 alphaMapTransform;
	varying vec2 vAlphaMapUv;
#endif
#ifdef USE_LIGHTMAP
	uniform mat3 lightMapTransform;
	varying vec2 vLightMapUv;
#endif
#ifdef USE_AOMAP
	uniform mat3 aoMapTransform;
	varying vec2 vAoMapUv;
#endif
#ifdef USE_BUMPMAP
	uniform mat3 bumpMapTransform;
	varying vec2 vBumpMapUv;
#endif
#ifdef USE_NORMALMAP
	uniform mat3 normalMapTransform;
	varying vec2 vNormalMapUv;
#endif
#ifdef USE_DISPLACEMENTMAP
	uniform mat3 displacementMapTransform;
	varying vec2 vDisplacementMapUv;
#endif
#ifdef USE_EMISSIVEMAP
	uniform mat3 emissiveMapTransform;
	varying vec2 vEmissiveMapUv;
#endif
#ifdef USE_METALNESSMAP
	uniform mat3 metalnessMapTransform;
	varying vec2 vMetalnessMapUv;
#endif
#ifdef USE_ROUGHNESSMAP
	uniform mat3 roughnessMapTransform;
	varying vec2 vRoughnessMapUv;
#endif
#ifdef USE_ANISOTROPYMAP
	uniform mat3 anisotropyMapTransform;
	varying vec2 vAnisotropyMapUv;
#endif
#ifdef USE_CLEARCOATMAP
	uniform mat3 clearcoatMapTransform;
	varying vec2 vClearcoatMapUv;
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	uniform mat3 clearcoatNormalMapTransform;
	varying vec2 vClearcoatNormalMapUv;
#endif
#ifdef USE_CLEARCOAT_ROUGHNESSMAP
	uniform mat3 clearcoatRoughnessMapTransform;
	varying vec2 vClearcoatRoughnessMapUv;
#endif
#ifdef USE_SHEEN_COLORMAP
	uniform mat3 sheenColorMapTransform;
	varying vec2 vSheenColorMapUv;
#endif
#ifdef USE_SHEEN_ROUGHNESSMAP
	uniform mat3 sheenRoughnessMapTransform;
	varying vec2 vSheenRoughnessMapUv;
#endif
#ifdef USE_IRIDESCENCEMAP
	uniform mat3 iridescenceMapTransform;
	varying vec2 vIridescenceMapUv;
#endif
#ifdef USE_IRIDESCENCE_THICKNESSMAP
	uniform mat3 iridescenceThicknessMapTransform;
	varying vec2 vIridescenceThicknessMapUv;
#endif
#ifdef USE_SPECULARMAP
	uniform mat3 specularMapTransform;
	varying vec2 vSpecularMapUv;
#endif
#ifdef USE_SPECULAR_COLORMAP
	uniform mat3 specularColorMapTransform;
	varying vec2 vSpecularColorMapUv;
#endif
#ifdef USE_SPECULAR_INTENSITYMAP
	uniform mat3 specularIntensityMapTransform;
	varying vec2 vSpecularIntensityMapUv;
#endif
#ifdef USE_TRANSMISSIONMAP
	uniform mat3 transmissionMapTransform;
	varying vec2 vTransmissionMapUv;
#endif
#ifdef USE_THICKNESSMAP
	uniform mat3 thicknessMapTransform;
	varying vec2 vThicknessMapUv;
#endif`,tm=`#if defined( USE_UV ) || defined( USE_ANISOTROPY )
	vUv = vec3( uv, 1 ).xy;
#endif
#ifdef USE_MAP
	vMapUv = ( mapTransform * vec3( MAP_UV, 1 ) ).xy;
#endif
#ifdef USE_ALPHAMAP
	vAlphaMapUv = ( alphaMapTransform * vec3( ALPHAMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_LIGHTMAP
	vLightMapUv = ( lightMapTransform * vec3( LIGHTMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_AOMAP
	vAoMapUv = ( aoMapTransform * vec3( AOMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_BUMPMAP
	vBumpMapUv = ( bumpMapTransform * vec3( BUMPMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_NORMALMAP
	vNormalMapUv = ( normalMapTransform * vec3( NORMALMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_DISPLACEMENTMAP
	vDisplacementMapUv = ( displacementMapTransform * vec3( DISPLACEMENTMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_EMISSIVEMAP
	vEmissiveMapUv = ( emissiveMapTransform * vec3( EMISSIVEMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_METALNESSMAP
	vMetalnessMapUv = ( metalnessMapTransform * vec3( METALNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_ROUGHNESSMAP
	vRoughnessMapUv = ( roughnessMapTransform * vec3( ROUGHNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_ANISOTROPYMAP
	vAnisotropyMapUv = ( anisotropyMapTransform * vec3( ANISOTROPYMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_CLEARCOATMAP
	vClearcoatMapUv = ( clearcoatMapTransform * vec3( CLEARCOATMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	vClearcoatNormalMapUv = ( clearcoatNormalMapTransform * vec3( CLEARCOAT_NORMALMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_CLEARCOAT_ROUGHNESSMAP
	vClearcoatRoughnessMapUv = ( clearcoatRoughnessMapTransform * vec3( CLEARCOAT_ROUGHNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_IRIDESCENCEMAP
	vIridescenceMapUv = ( iridescenceMapTransform * vec3( IRIDESCENCEMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_IRIDESCENCE_THICKNESSMAP
	vIridescenceThicknessMapUv = ( iridescenceThicknessMapTransform * vec3( IRIDESCENCE_THICKNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SHEEN_COLORMAP
	vSheenColorMapUv = ( sheenColorMapTransform * vec3( SHEEN_COLORMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SHEEN_ROUGHNESSMAP
	vSheenRoughnessMapUv = ( sheenRoughnessMapTransform * vec3( SHEEN_ROUGHNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SPECULARMAP
	vSpecularMapUv = ( specularMapTransform * vec3( SPECULARMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SPECULAR_COLORMAP
	vSpecularColorMapUv = ( specularColorMapTransform * vec3( SPECULAR_COLORMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SPECULAR_INTENSITYMAP
	vSpecularIntensityMapUv = ( specularIntensityMapTransform * vec3( SPECULAR_INTENSITYMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_TRANSMISSIONMAP
	vTransmissionMapUv = ( transmissionMapTransform * vec3( TRANSMISSIONMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_THICKNESSMAP
	vThicknessMapUv = ( thicknessMapTransform * vec3( THICKNESSMAP_UV, 1 ) ).xy;
#endif`,em=`#if defined( USE_ENVMAP ) || defined( DISTANCE ) || defined ( USE_SHADOWMAP ) || defined ( USE_TRANSMISSION ) || NUM_SPOT_LIGHT_COORDS > 0
	vec4 worldPosition = vec4( transformed, 1.0 );
	#ifdef USE_BATCHING
		worldPosition = batchingMatrix * worldPosition;
	#endif
	#ifdef USE_INSTANCING
		worldPosition = instanceMatrix * worldPosition;
	#endif
	worldPosition = modelMatrix * worldPosition;
#endif`,nm=`varying vec2 vUv;
uniform mat3 uvTransform;
void main() {
	vUv = ( uvTransform * vec3( uv, 1 ) ).xy;
	gl_Position = vec4( position.xy, 1.0, 1.0 );
}`,im=`uniform sampler2D t2D;
uniform float backgroundIntensity;
varying vec2 vUv;
void main() {
	vec4 texColor = texture2D( t2D, vUv );
	#ifdef DECODE_VIDEO_TEXTURE
		texColor = vec4( mix( pow( texColor.rgb * 0.9478672986 + vec3( 0.0521327014 ), vec3( 2.4 ) ), texColor.rgb * 0.0773993808, vec3( lessThanEqual( texColor.rgb, vec3( 0.04045 ) ) ) ), texColor.w );
	#endif
	texColor.rgb *= backgroundIntensity;
	gl_FragColor = texColor;
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
}`,sm=`varying vec3 vWorldDirection;
#include <common>
void main() {
	vWorldDirection = transformDirection( position, modelMatrix );
	#include <begin_vertex>
	#include <project_vertex>
	gl_Position.z = gl_Position.w;
}`,rm=`#ifdef ENVMAP_TYPE_CUBE
	uniform samplerCube envMap;
#elif defined( ENVMAP_TYPE_CUBE_UV )
	uniform sampler2D envMap;
#endif
uniform float flipEnvMap;
uniform float backgroundBlurriness;
uniform float backgroundIntensity;
varying vec3 vWorldDirection;
#include <cube_uv_reflection_fragment>
void main() {
	#ifdef ENVMAP_TYPE_CUBE
		vec4 texColor = textureCube( envMap, vec3( flipEnvMap * vWorldDirection.x, vWorldDirection.yz ) );
	#elif defined( ENVMAP_TYPE_CUBE_UV )
		vec4 texColor = textureCubeUV( envMap, vWorldDirection, backgroundBlurriness );
	#else
		vec4 texColor = vec4( 0.0, 0.0, 0.0, 1.0 );
	#endif
	texColor.rgb *= backgroundIntensity;
	gl_FragColor = texColor;
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
}`,am=`varying vec3 vWorldDirection;
#include <common>
void main() {
	vWorldDirection = transformDirection( position, modelMatrix );
	#include <begin_vertex>
	#include <project_vertex>
	gl_Position.z = gl_Position.w;
}`,om=`uniform samplerCube tCube;
uniform float tFlip;
uniform float opacity;
varying vec3 vWorldDirection;
void main() {
	vec4 texColor = textureCube( tCube, vec3( tFlip * vWorldDirection.x, vWorldDirection.yz ) );
	gl_FragColor = texColor;
	gl_FragColor.a *= opacity;
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
}`,lm=`#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
varying vec2 vHighPrecisionZW;
void main() {
	#include <uv_vertex>
	#include <batching_vertex>
	#include <skinbase_vertex>
	#ifdef USE_DISPLACEMENTMAP
		#include <beginnormal_vertex>
		#include <morphnormal_vertex>
		#include <skinnormal_vertex>
	#endif
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vHighPrecisionZW = gl_Position.zw;
}`,cm=`#if DEPTH_PACKING == 3200
	uniform float opacity;
#endif
#include <common>
#include <packing>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
varying vec2 vHighPrecisionZW;
void main() {
	#include <clipping_planes_fragment>
	vec4 diffuseColor = vec4( 1.0 );
	#if DEPTH_PACKING == 3200
		diffuseColor.a = opacity;
	#endif
	#include <map_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <logdepthbuf_fragment>
	float fragCoordZ = 0.5 * vHighPrecisionZW[0] / vHighPrecisionZW[1] + 0.5;
	#if DEPTH_PACKING == 3200
		gl_FragColor = vec4( vec3( 1.0 - fragCoordZ ), opacity );
	#elif DEPTH_PACKING == 3201
		gl_FragColor = packDepthToRGBA( fragCoordZ );
	#endif
}`,hm=`#define DISTANCE
varying vec3 vWorldPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <batching_vertex>
	#include <skinbase_vertex>
	#ifdef USE_DISPLACEMENTMAP
		#include <beginnormal_vertex>
		#include <morphnormal_vertex>
		#include <skinnormal_vertex>
	#endif
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <worldpos_vertex>
	#include <clipping_planes_vertex>
	vWorldPosition = worldPosition.xyz;
}`,um=`#define DISTANCE
uniform vec3 referencePosition;
uniform float nearDistance;
uniform float farDistance;
varying vec3 vWorldPosition;
#include <common>
#include <packing>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <clipping_planes_pars_fragment>
void main () {
	#include <clipping_planes_fragment>
	vec4 diffuseColor = vec4( 1.0 );
	#include <map_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	float dist = length( vWorldPosition - referencePosition );
	dist = ( dist - nearDistance ) / ( farDistance - nearDistance );
	dist = saturate( dist );
	gl_FragColor = packDepthToRGBA( dist );
}`,dm=`varying vec3 vWorldDirection;
#include <common>
void main() {
	vWorldDirection = transformDirection( position, modelMatrix );
	#include <begin_vertex>
	#include <project_vertex>
}`,fm=`uniform sampler2D tEquirect;
varying vec3 vWorldDirection;
#include <common>
void main() {
	vec3 direction = normalize( vWorldDirection );
	vec2 sampleUV = equirectUv( direction );
	gl_FragColor = texture2D( tEquirect, sampleUV );
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
}`,pm=`uniform float scale;
attribute float lineDistance;
varying float vLineDistance;
#include <common>
#include <uv_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <morphtarget_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	vLineDistance = scale * lineDistance;
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphcolor_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <fog_vertex>
}`,mm=`uniform vec3 diffuse;
uniform float opacity;
uniform float dashSize;
uniform float totalSize;
varying float vLineDistance;
#include <common>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <fog_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	#include <clipping_planes_fragment>
	if ( mod( vLineDistance, totalSize ) > dashSize ) {
		discard;
	}
	vec3 outgoingLight = vec3( 0.0 );
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	outgoingLight = diffuseColor.rgb;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
}`,gm=`#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <envmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#if defined ( USE_ENVMAP ) || defined ( USE_SKINNING )
		#include <beginnormal_vertex>
		#include <morphnormal_vertex>
		#include <skinbase_vertex>
		#include <skinnormal_vertex>
		#include <defaultnormal_vertex>
	#endif
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <worldpos_vertex>
	#include <envmap_vertex>
	#include <fog_vertex>
}`,xm=`uniform vec3 diffuse;
uniform float opacity;
#ifndef FLAT_SHADED
	varying vec3 vNormal;
#endif
#include <common>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <envmap_common_pars_fragment>
#include <envmap_pars_fragment>
#include <fog_pars_fragment>
#include <specularmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	#include <clipping_planes_fragment>
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <specularmap_fragment>
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	#ifdef USE_LIGHTMAP
		vec4 lightMapTexel = texture2D( lightMap, vLightMapUv );
		reflectedLight.indirectDiffuse += lightMapTexel.rgb * lightMapIntensity * RECIPROCAL_PI;
	#else
		reflectedLight.indirectDiffuse += vec3( 1.0 );
	#endif
	#include <aomap_fragment>
	reflectedLight.indirectDiffuse *= diffuseColor.rgb;
	vec3 outgoingLight = reflectedLight.indirectDiffuse;
	#include <envmap_fragment>
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,_m=`#define LAMBERT
varying vec3 vViewPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <envmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <shadowmap_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vViewPosition = - mvPosition.xyz;
	#include <worldpos_vertex>
	#include <envmap_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
}`,vm=`#define LAMBERT
uniform vec3 diffuse;
uniform vec3 emissive;
uniform float opacity;
#include <common>
#include <packing>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <emissivemap_pars_fragment>
#include <envmap_common_pars_fragment>
#include <envmap_pars_fragment>
#include <fog_pars_fragment>
#include <bsdfs>
#include <lights_pars_begin>
#include <normal_pars_fragment>
#include <lights_lambert_pars_fragment>
#include <shadowmap_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <specularmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	#include <clipping_planes_fragment>
	vec4 diffuseColor = vec4( diffuse, opacity );
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	vec3 totalEmissiveRadiance = emissive;
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <specularmap_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	#include <emissivemap_fragment>
	#include <lights_lambert_fragment>
	#include <lights_fragment_begin>
	#include <lights_fragment_maps>
	#include <lights_fragment_end>
	#include <aomap_fragment>
	vec3 outgoingLight = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse + totalEmissiveRadiance;
	#include <envmap_fragment>
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,ym=`#define MATCAP
varying vec3 vViewPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <color_pars_vertex>
#include <displacementmap_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <fog_vertex>
	vViewPosition = - mvPosition.xyz;
}`,Mm=`#define MATCAP
uniform vec3 diffuse;
uniform float opacity;
uniform sampler2D matcap;
varying vec3 vViewPosition;
#include <common>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <fog_pars_fragment>
#include <normal_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	#include <clipping_planes_fragment>
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	vec3 viewDir = normalize( vViewPosition );
	vec3 x = normalize( vec3( viewDir.z, 0.0, - viewDir.x ) );
	vec3 y = cross( viewDir, x );
	vec2 uv = vec2( dot( x, normal ), dot( y, normal ) ) * 0.495 + 0.5;
	#ifdef USE_MATCAP
		vec4 matcapColor = texture2D( matcap, uv );
	#else
		vec4 matcapColor = vec4( vec3( mix( 0.2, 0.8, uv.y ) ), 1.0 );
	#endif
	vec3 outgoingLight = diffuseColor.rgb * matcapColor.rgb;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,bm=`#define NORMAL
#if defined( FLAT_SHADED ) || defined( USE_BUMPMAP ) || defined( USE_NORMALMAP_TANGENTSPACE )
	varying vec3 vViewPosition;
#endif
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
#if defined( FLAT_SHADED ) || defined( USE_BUMPMAP ) || defined( USE_NORMALMAP_TANGENTSPACE )
	vViewPosition = - mvPosition.xyz;
#endif
}`,Sm=`#define NORMAL
uniform float opacity;
#if defined( FLAT_SHADED ) || defined( USE_BUMPMAP ) || defined( USE_NORMALMAP_TANGENTSPACE )
	varying vec3 vViewPosition;
#endif
#include <packing>
#include <uv_pars_fragment>
#include <normal_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	#include <clipping_planes_fragment>
	#include <logdepthbuf_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	gl_FragColor = vec4( packNormalToRGB( normal ), opacity );
	#ifdef OPAQUE
		gl_FragColor.a = 1.0;
	#endif
}`,wm=`#define PHONG
varying vec3 vViewPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <envmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <shadowmap_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vViewPosition = - mvPosition.xyz;
	#include <worldpos_vertex>
	#include <envmap_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
}`,Em=`#define PHONG
uniform vec3 diffuse;
uniform vec3 emissive;
uniform vec3 specular;
uniform float shininess;
uniform float opacity;
#include <common>
#include <packing>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <emissivemap_pars_fragment>
#include <envmap_common_pars_fragment>
#include <envmap_pars_fragment>
#include <fog_pars_fragment>
#include <bsdfs>
#include <lights_pars_begin>
#include <normal_pars_fragment>
#include <lights_phong_pars_fragment>
#include <shadowmap_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <specularmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	#include <clipping_planes_fragment>
	vec4 diffuseColor = vec4( diffuse, opacity );
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	vec3 totalEmissiveRadiance = emissive;
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <specularmap_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	#include <emissivemap_fragment>
	#include <lights_phong_fragment>
	#include <lights_fragment_begin>
	#include <lights_fragment_maps>
	#include <lights_fragment_end>
	#include <aomap_fragment>
	vec3 outgoingLight = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse + reflectedLight.directSpecular + reflectedLight.indirectSpecular + totalEmissiveRadiance;
	#include <envmap_fragment>
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,Tm=`#define STANDARD
varying vec3 vViewPosition;
#ifdef USE_TRANSMISSION
	varying vec3 vWorldPosition;
#endif
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <shadowmap_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vViewPosition = - mvPosition.xyz;
	#include <worldpos_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
#ifdef USE_TRANSMISSION
	vWorldPosition = worldPosition.xyz;
#endif
}`,Am=`#define STANDARD
#ifdef PHYSICAL
	#define IOR
	#define USE_SPECULAR
#endif
uniform vec3 diffuse;
uniform vec3 emissive;
uniform float roughness;
uniform float metalness;
uniform float opacity;
#ifdef IOR
	uniform float ior;
#endif
#ifdef USE_SPECULAR
	uniform float specularIntensity;
	uniform vec3 specularColor;
	#ifdef USE_SPECULAR_COLORMAP
		uniform sampler2D specularColorMap;
	#endif
	#ifdef USE_SPECULAR_INTENSITYMAP
		uniform sampler2D specularIntensityMap;
	#endif
#endif
#ifdef USE_CLEARCOAT
	uniform float clearcoat;
	uniform float clearcoatRoughness;
#endif
#ifdef USE_IRIDESCENCE
	uniform float iridescence;
	uniform float iridescenceIOR;
	uniform float iridescenceThicknessMinimum;
	uniform float iridescenceThicknessMaximum;
#endif
#ifdef USE_SHEEN
	uniform vec3 sheenColor;
	uniform float sheenRoughness;
	#ifdef USE_SHEEN_COLORMAP
		uniform sampler2D sheenColorMap;
	#endif
	#ifdef USE_SHEEN_ROUGHNESSMAP
		uniform sampler2D sheenRoughnessMap;
	#endif
#endif
#ifdef USE_ANISOTROPY
	uniform vec2 anisotropyVector;
	#ifdef USE_ANISOTROPYMAP
		uniform sampler2D anisotropyMap;
	#endif
#endif
varying vec3 vViewPosition;
#include <common>
#include <packing>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <emissivemap_pars_fragment>
#include <iridescence_fragment>
#include <cube_uv_reflection_fragment>
#include <envmap_common_pars_fragment>
#include <envmap_physical_pars_fragment>
#include <fog_pars_fragment>
#include <lights_pars_begin>
#include <normal_pars_fragment>
#include <lights_physical_pars_fragment>
#include <transmission_pars_fragment>
#include <shadowmap_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <clearcoat_pars_fragment>
#include <iridescence_pars_fragment>
#include <roughnessmap_pars_fragment>
#include <metalnessmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	#include <clipping_planes_fragment>
	vec4 diffuseColor = vec4( diffuse, opacity );
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	vec3 totalEmissiveRadiance = emissive;
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <roughnessmap_fragment>
	#include <metalnessmap_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	#include <clearcoat_normal_fragment_begin>
	#include <clearcoat_normal_fragment_maps>
	#include <emissivemap_fragment>
	#include <lights_physical_fragment>
	#include <lights_fragment_begin>
	#include <lights_fragment_maps>
	#include <lights_fragment_end>
	#include <aomap_fragment>
	vec3 totalDiffuse = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse;
	vec3 totalSpecular = reflectedLight.directSpecular + reflectedLight.indirectSpecular;
	#include <transmission_fragment>
	vec3 outgoingLight = totalDiffuse + totalSpecular + totalEmissiveRadiance;
	#ifdef USE_SHEEN
		float sheenEnergyComp = 1.0 - 0.157 * max3( material.sheenColor );
		outgoingLight = outgoingLight * sheenEnergyComp + sheenSpecularDirect + sheenSpecularIndirect;
	#endif
	#ifdef USE_CLEARCOAT
		float dotNVcc = saturate( dot( geometryClearcoatNormal, geometryViewDir ) );
		vec3 Fcc = F_Schlick( material.clearcoatF0, material.clearcoatF90, dotNVcc );
		outgoingLight = outgoingLight * ( 1.0 - material.clearcoat * Fcc ) + ( clearcoatSpecularDirect + clearcoatSpecularIndirect ) * material.clearcoat;
	#endif
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,Cm=`#define TOON
varying vec3 vViewPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <shadowmap_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vViewPosition = - mvPosition.xyz;
	#include <worldpos_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
}`,Rm=`#define TOON
uniform vec3 diffuse;
uniform vec3 emissive;
uniform float opacity;
#include <common>
#include <packing>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <emissivemap_pars_fragment>
#include <gradientmap_pars_fragment>
#include <fog_pars_fragment>
#include <bsdfs>
#include <lights_pars_begin>
#include <normal_pars_fragment>
#include <lights_toon_pars_fragment>
#include <shadowmap_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	#include <clipping_planes_fragment>
	vec4 diffuseColor = vec4( diffuse, opacity );
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	vec3 totalEmissiveRadiance = emissive;
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	#include <emissivemap_fragment>
	#include <lights_toon_fragment>
	#include <lights_fragment_begin>
	#include <lights_fragment_maps>
	#include <lights_fragment_end>
	#include <aomap_fragment>
	vec3 outgoingLight = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse + totalEmissiveRadiance;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,Pm=`uniform float size;
uniform float scale;
#include <common>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <morphtarget_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
#ifdef USE_POINTS_UV
	varying vec2 vUv;
	uniform mat3 uvTransform;
#endif
void main() {
	#ifdef USE_POINTS_UV
		vUv = ( uvTransform * vec3( uv, 1 ) ).xy;
	#endif
	#include <color_vertex>
	#include <morphcolor_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <project_vertex>
	gl_PointSize = size;
	#ifdef USE_SIZEATTENUATION
		bool isPerspective = isPerspectiveMatrix( projectionMatrix );
		if ( isPerspective ) gl_PointSize *= ( scale / - mvPosition.z );
	#endif
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <worldpos_vertex>
	#include <fog_vertex>
}`,Lm=`uniform vec3 diffuse;
uniform float opacity;
#include <common>
#include <color_pars_fragment>
#include <map_particle_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <fog_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	#include <clipping_planes_fragment>
	vec3 outgoingLight = vec3( 0.0 );
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <logdepthbuf_fragment>
	#include <map_particle_fragment>
	#include <color_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	outgoingLight = diffuseColor.rgb;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
}`,Im=`#include <common>
#include <batching_pars_vertex>
#include <fog_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <shadowmap_pars_vertex>
void main() {
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <worldpos_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
}`,Dm=`uniform vec3 color;
uniform float opacity;
#include <common>
#include <packing>
#include <fog_pars_fragment>
#include <bsdfs>
#include <lights_pars_begin>
#include <logdepthbuf_pars_fragment>
#include <shadowmap_pars_fragment>
#include <shadowmask_pars_fragment>
void main() {
	#include <logdepthbuf_fragment>
	gl_FragColor = vec4( color, opacity * ( 1.0 - getShadowMask() ) );
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
}`,Um=`uniform float rotation;
uniform vec2 center;
#include <common>
#include <uv_pars_vertex>
#include <fog_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	vec4 mvPosition = modelViewMatrix * vec4( 0.0, 0.0, 0.0, 1.0 );
	vec2 scale;
	scale.x = length( vec3( modelMatrix[ 0 ].x, modelMatrix[ 0 ].y, modelMatrix[ 0 ].z ) );
	scale.y = length( vec3( modelMatrix[ 1 ].x, modelMatrix[ 1 ].y, modelMatrix[ 1 ].z ) );
	#ifndef USE_SIZEATTENUATION
		bool isPerspective = isPerspectiveMatrix( projectionMatrix );
		if ( isPerspective ) scale *= - mvPosition.z;
	#endif
	vec2 alignedPosition = ( position.xy - ( center - vec2( 0.5 ) ) ) * scale;
	vec2 rotatedPosition;
	rotatedPosition.x = cos( rotation ) * alignedPosition.x - sin( rotation ) * alignedPosition.y;
	rotatedPosition.y = sin( rotation ) * alignedPosition.x + cos( rotation ) * alignedPosition.y;
	mvPosition.xy += rotatedPosition;
	gl_Position = projectionMatrix * mvPosition;
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <fog_vertex>
}`,Nm=`uniform vec3 diffuse;
uniform float opacity;
#include <common>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <fog_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	#include <clipping_planes_fragment>
	vec3 outgoingLight = vec3( 0.0 );
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	outgoingLight = diffuseColor.rgb;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
}`,te={alphahash_fragment:nf,alphahash_pars_fragment:sf,alphamap_fragment:rf,alphamap_pars_fragment:af,alphatest_fragment:of,alphatest_pars_fragment:lf,aomap_fragment:cf,aomap_pars_fragment:hf,batching_pars_vertex:uf,batching_vertex:df,begin_vertex:ff,beginnormal_vertex:pf,bsdfs:mf,iridescence_fragment:gf,bumpmap_pars_fragment:xf,clipping_planes_fragment:_f,clipping_planes_pars_fragment:vf,clipping_planes_pars_vertex:yf,clipping_planes_vertex:Mf,color_fragment:bf,color_pars_fragment:Sf,color_pars_vertex:wf,color_vertex:Ef,common:Tf,cube_uv_reflection_fragment:Af,defaultnormal_vertex:Cf,displacementmap_pars_vertex:Rf,displacementmap_vertex:Pf,emissivemap_fragment:Lf,emissivemap_pars_fragment:If,colorspace_fragment:Df,colorspace_pars_fragment:Uf,envmap_fragment:Nf,envmap_common_pars_fragment:Of,envmap_pars_fragment:Ff,envmap_pars_vertex:Bf,envmap_physical_pars_fragment:$f,envmap_vertex:zf,fog_vertex:kf,fog_pars_vertex:Hf,fog_fragment:Vf,fog_pars_fragment:Gf,gradientmap_pars_fragment:Wf,lightmap_fragment:Xf,lightmap_pars_fragment:Yf,lights_lambert_fragment:qf,lights_lambert_pars_fragment:Zf,lights_pars_begin:Jf,lights_toon_fragment:jf,lights_toon_pars_fragment:Kf,lights_phong_fragment:Qf,lights_phong_pars_fragment:tp,lights_physical_fragment:ep,lights_physical_pars_fragment:np,lights_fragment_begin:ip,lights_fragment_maps:sp,lights_fragment_end:rp,logdepthbuf_fragment:ap,logdepthbuf_pars_fragment:op,logdepthbuf_pars_vertex:lp,logdepthbuf_vertex:cp,map_fragment:hp,map_pars_fragment:up,map_particle_fragment:dp,map_particle_pars_fragment:fp,metalnessmap_fragment:pp,metalnessmap_pars_fragment:mp,morphcolor_vertex:gp,morphnormal_vertex:xp,morphtarget_pars_vertex:_p,morphtarget_vertex:vp,normal_fragment_begin:yp,normal_fragment_maps:Mp,normal_pars_fragment:bp,normal_pars_vertex:Sp,normal_vertex:wp,normalmap_pars_fragment:Ep,clearcoat_normal_fragment_begin:Tp,clearcoat_normal_fragment_maps:Ap,clearcoat_pars_fragment:Cp,iridescence_pars_fragment:Rp,opaque_fragment:Pp,packing:Lp,premultiplied_alpha_fragment:Ip,project_vertex:Dp,dithering_fragment:Up,dithering_pars_fragment:Np,roughnessmap_fragment:Op,roughnessmap_pars_fragment:Fp,shadowmap_pars_fragment:Bp,shadowmap_pars_vertex:zp,shadowmap_vertex:kp,shadowmask_pars_fragment:Hp,skinbase_vertex:Vp,skinning_pars_vertex:Gp,skinning_vertex:Wp,skinnormal_vertex:Xp,specularmap_fragment:Yp,specularmap_pars_fragment:qp,tonemapping_fragment:Zp,tonemapping_pars_fragment:Jp,transmission_fragment:$p,transmission_pars_fragment:jp,uv_pars_fragment:Kp,uv_pars_vertex:Qp,uv_vertex:tm,worldpos_vertex:em,background_vert:nm,background_frag:im,backgroundCube_vert:sm,backgroundCube_frag:rm,cube_vert:am,cube_frag:om,depth_vert:lm,depth_frag:cm,distanceRGBA_vert:hm,distanceRGBA_frag:um,equirect_vert:dm,equirect_frag:fm,linedashed_vert:pm,linedashed_frag:mm,meshbasic_vert:gm,meshbasic_frag:xm,meshlambert_vert:_m,meshlambert_frag:vm,meshmatcap_vert:ym,meshmatcap_frag:Mm,meshnormal_vert:bm,meshnormal_frag:Sm,meshphong_vert:wm,meshphong_frag:Em,meshphysical_vert:Tm,meshphysical_frag:Am,meshtoon_vert:Cm,meshtoon_frag:Rm,points_vert:Pm,points_frag:Lm,shadow_vert:Im,shadow_frag:Dm,sprite_vert:Um,sprite_frag:Nm},yt={common:{diffuse:{value:new qt(16777215)},opacity:{value:1},map:{value:null},mapTransform:{value:new re},alphaMap:{value:null},alphaMapTransform:{value:new re},alphaTest:{value:0}},specularmap:{specularMap:{value:null},specularMapTransform:{value:new re}},envmap:{envMap:{value:null},flipEnvMap:{value:-1},reflectivity:{value:1},ior:{value:1.5},refractionRatio:{value:.98}},aomap:{aoMap:{value:null},aoMapIntensity:{value:1},aoMapTransform:{value:new re}},lightmap:{lightMap:{value:null},lightMapIntensity:{value:1},lightMapTransform:{value:new re}},bumpmap:{bumpMap:{value:null},bumpMapTransform:{value:new re},bumpScale:{value:1}},normalmap:{normalMap:{value:null},normalMapTransform:{value:new re},normalScale:{value:new Pt(1,1)}},displacementmap:{displacementMap:{value:null},displacementMapTransform:{value:new re},displacementScale:{value:1},displacementBias:{value:0}},emissivemap:{emissiveMap:{value:null},emissiveMapTransform:{value:new re}},metalnessmap:{metalnessMap:{value:null},metalnessMapTransform:{value:new re}},roughnessmap:{roughnessMap:{value:null},roughnessMapTransform:{value:new re}},gradientmap:{gradientMap:{value:null}},fog:{fogDensity:{value:25e-5},fogNear:{value:1},fogFar:{value:2e3},fogColor:{value:new qt(16777215)}},lights:{ambientLightColor:{value:[]},lightProbe:{value:[]},directionalLights:{value:[],properties:{direction:{},color:{}}},directionalLightShadows:{value:[],properties:{shadowBias:{},shadowNormalBias:{},shadowRadius:{},shadowMapSize:{}}},directionalShadowMap:{value:[]},directionalShadowMatrix:{value:[]},spotLights:{value:[],properties:{color:{},position:{},direction:{},distance:{},coneCos:{},penumbraCos:{},decay:{}}},spotLightShadows:{value:[],properties:{shadowBias:{},shadowNormalBias:{},shadowRadius:{},shadowMapSize:{}}},spotLightMap:{value:[]},spotShadowMap:{value:[]},spotLightMatrix:{value:[]},pointLights:{value:[],properties:{color:{},position:{},decay:{},distance:{}}},pointLightShadows:{value:[],properties:{shadowBias:{},shadowNormalBias:{},shadowRadius:{},shadowMapSize:{},shadowCameraNear:{},shadowCameraFar:{}}},pointShadowMap:{value:[]},pointShadowMatrix:{value:[]},hemisphereLights:{value:[],properties:{direction:{},skyColor:{},groundColor:{}}},rectAreaLights:{value:[],properties:{color:{},position:{},width:{},height:{}}},ltc_1:{value:null},ltc_2:{value:null}},points:{diffuse:{value:new qt(16777215)},opacity:{value:1},size:{value:1},scale:{value:1},map:{value:null},alphaMap:{value:null},alphaMapTransform:{value:new re},alphaTest:{value:0},uvTransform:{value:new re}},sprite:{diffuse:{value:new qt(16777215)},opacity:{value:1},center:{value:new Pt(.5,.5)},rotation:{value:0},map:{value:null},mapTransform:{value:new re},alphaMap:{value:null},alphaMapTransform:{value:new re},alphaTest:{value:0}}},Gn={basic:{uniforms:cn([yt.common,yt.specularmap,yt.envmap,yt.aomap,yt.lightmap,yt.fog]),vertexShader:te.meshbasic_vert,fragmentShader:te.meshbasic_frag},lambert:{uniforms:cn([yt.common,yt.specularmap,yt.envmap,yt.aomap,yt.lightmap,yt.emissivemap,yt.bumpmap,yt.normalmap,yt.displacementmap,yt.fog,yt.lights,{emissive:{value:new qt(0)}}]),vertexShader:te.meshlambert_vert,fragmentShader:te.meshlambert_frag},phong:{uniforms:cn([yt.common,yt.specularmap,yt.envmap,yt.aomap,yt.lightmap,yt.emissivemap,yt.bumpmap,yt.normalmap,yt.displacementmap,yt.fog,yt.lights,{emissive:{value:new qt(0)},specular:{value:new qt(1118481)},shininess:{value:30}}]),vertexShader:te.meshphong_vert,fragmentShader:te.meshphong_frag},standard:{uniforms:cn([yt.common,yt.envmap,yt.aomap,yt.lightmap,yt.emissivemap,yt.bumpmap,yt.normalmap,yt.displacementmap,yt.roughnessmap,yt.metalnessmap,yt.fog,yt.lights,{emissive:{value:new qt(0)},roughness:{value:1},metalness:{value:0},envMapIntensity:{value:1}}]),vertexShader:te.meshphysical_vert,fragmentShader:te.meshphysical_frag},toon:{uniforms:cn([yt.common,yt.aomap,yt.lightmap,yt.emissivemap,yt.bumpmap,yt.normalmap,yt.displacementmap,yt.gradientmap,yt.fog,yt.lights,{emissive:{value:new qt(0)}}]),vertexShader:te.meshtoon_vert,fragmentShader:te.meshtoon_frag},matcap:{uniforms:cn([yt.common,yt.bumpmap,yt.normalmap,yt.displacementmap,yt.fog,{matcap:{value:null}}]),vertexShader:te.meshmatcap_vert,fragmentShader:te.meshmatcap_frag},points:{uniforms:cn([yt.points,yt.fog]),vertexShader:te.points_vert,fragmentShader:te.points_frag},dashed:{uniforms:cn([yt.common,yt.fog,{scale:{value:1},dashSize:{value:1},totalSize:{value:2}}]),vertexShader:te.linedashed_vert,fragmentShader:te.linedashed_frag},depth:{uniforms:cn([yt.common,yt.displacementmap]),vertexShader:te.depth_vert,fragmentShader:te.depth_frag},normal:{uniforms:cn([yt.common,yt.bumpmap,yt.normalmap,yt.displacementmap,{opacity:{value:1}}]),vertexShader:te.meshnormal_vert,fragmentShader:te.meshnormal_frag},sprite:{uniforms:cn([yt.sprite,yt.fog]),vertexShader:te.sprite_vert,fragmentShader:te.sprite_frag},background:{uniforms:{uvTransform:{value:new re},t2D:{value:null},backgroundIntensity:{value:1}},vertexShader:te.background_vert,fragmentShader:te.background_frag},backgroundCube:{uniforms:{envMap:{value:null},flipEnvMap:{value:-1},backgroundBlurriness:{value:0},backgroundIntensity:{value:1}},vertexShader:te.backgroundCube_vert,fragmentShader:te.backgroundCube_frag},cube:{uniforms:{tCube:{value:null},tFlip:{value:-1},opacity:{value:1}},vertexShader:te.cube_vert,fragmentShader:te.cube_frag},equirect:{uniforms:{tEquirect:{value:null}},vertexShader:te.equirect_vert,fragmentShader:te.equirect_frag},distanceRGBA:{uniforms:cn([yt.common,yt.displacementmap,{referencePosition:{value:new F},nearDistance:{value:1},farDistance:{value:1e3}}]),vertexShader:te.distanceRGBA_vert,fragmentShader:te.distanceRGBA_frag},shadow:{uniforms:cn([yt.lights,yt.fog,{color:{value:new qt(0)},opacity:{value:1}}]),vertexShader:te.shadow_vert,fragmentShader:te.shadow_frag}};Gn.physical={uniforms:cn([Gn.standard.uniforms,{clearcoat:{value:0},clearcoatMap:{value:null},clearcoatMapTransform:{value:new re},clearcoatNormalMap:{value:null},clearcoatNormalMapTransform:{value:new re},clearcoatNormalScale:{value:new Pt(1,1)},clearcoatRoughness:{value:0},clearcoatRoughnessMap:{value:null},clearcoatRoughnessMapTransform:{value:new re},iridescence:{value:0},iridescenceMap:{value:null},iridescenceMapTransform:{value:new re},iridescenceIOR:{value:1.3},iridescenceThicknessMinimum:{value:100},iridescenceThicknessMaximum:{value:400},iridescenceThicknessMap:{value:null},iridescenceThicknessMapTransform:{value:new re},sheen:{value:0},sheenColor:{value:new qt(0)},sheenColorMap:{value:null},sheenColorMapTransform:{value:new re},sheenRoughness:{value:1},sheenRoughnessMap:{value:null},sheenRoughnessMapTransform:{value:new re},transmission:{value:0},transmissionMap:{value:null},transmissionMapTransform:{value:new re},transmissionSamplerSize:{value:new Pt},transmissionSamplerMap:{value:null},thickness:{value:0},thicknessMap:{value:null},thicknessMapTransform:{value:new re},attenuationDistance:{value:0},attenuationColor:{value:new qt(0)},specularColor:{value:new qt(1,1,1)},specularColorMap:{value:null},specularColorMapTransform:{value:new re},specularIntensity:{value:1},specularIntensityMap:{value:null},specularIntensityMapTransform:{value:new re},anisotropyVector:{value:new Pt},anisotropyMap:{value:null},anisotropyMapTransform:{value:new re}}]),vertexShader:te.meshphysical_vert,fragmentShader:te.meshphysical_frag};var Kr={r:0,b:0,g:0};function Om(i,t,e,n,s,r,o){let a=new qt(0),l=r===!0?0:1,c,u,f=null,p=0,x=null;function y(m,d){let C=!1,w=d.isScene===!0?d.background:null;w&&w.isTexture&&(w=(d.backgroundBlurriness>0?e:t).get(w)),w===null?b(a,l):w&&w.isColor&&(b(w,1),C=!0);let U=i.xr.getEnvironmentBlendMode();U==="additive"?n.buffers.color.setClear(0,0,0,1,o):U==="alpha-blend"&&n.buffers.color.setClear(0,0,0,0,o),(i.autoClear||C)&&i.clear(i.autoClearColor,i.autoClearDepth,i.autoClearStencil),w&&(w.isCubeTexture||w.mapping===Na)?(u===void 0&&(u=new ke(new Yi(1,1,1),new Ne({name:"BackgroundCubeMaterial",uniforms:Ds(Gn.backgroundCube.uniforms),vertexShader:Gn.backgroundCube.vertexShader,fragmentShader:Gn.backgroundCube.fragmentShader,side:nn,depthTest:!1,depthWrite:!1,fog:!1})),u.geometry.deleteAttribute("normal"),u.geometry.deleteAttribute("uv"),u.onBeforeRender=function(z,N,L){this.matrixWorld.copyPosition(L.matrixWorld)},Object.defineProperty(u.material,"envMap",{get:function(){return this.uniforms.envMap.value}}),s.update(u)),u.material.uniforms.envMap.value=w,u.material.uniforms.flipEnvMap.value=w.isCubeTexture&&w.isRenderTargetTexture===!1?-1:1,u.material.uniforms.backgroundBlurriness.value=d.backgroundBlurriness,u.material.uniforms.backgroundIntensity.value=d.backgroundIntensity,u.material.toneMapped=fe.getTransfer(w.colorSpace)!==ge,(f!==w||p!==w.version||x!==i.toneMapping)&&(u.material.needsUpdate=!0,f=w,p=w.version,x=i.toneMapping),u.layers.enableAll(),m.unshift(u,u.geometry,u.material,0,0,null)):w&&w.isTexture&&(c===void 0&&(c=new ke(new fr(2,2),new Ne({name:"BackgroundMaterial",uniforms:Ds(Gn.background.uniforms),vertexShader:Gn.background.vertexShader,fragmentShader:Gn.background.fragmentShader,side:Mi,depthTest:!1,depthWrite:!1,fog:!1})),c.geometry.deleteAttribute("normal"),Object.defineProperty(c.material,"map",{get:function(){return this.uniforms.t2D.value}}),s.update(c)),c.material.uniforms.t2D.value=w,c.material.uniforms.backgroundIntensity.value=d.backgroundIntensity,c.material.toneMapped=fe.getTransfer(w.colorSpace)!==ge,w.matrixAutoUpdate===!0&&w.updateMatrix(),c.material.uniforms.uvTransform.value.copy(w.matrix),(f!==w||p!==w.version||x!==i.toneMapping)&&(c.material.needsUpdate=!0,f=w,p=w.version,x=i.toneMapping),c.layers.enableAll(),m.unshift(c,c.geometry,c.material,0,0,null))}function b(m,d){m.getRGB(Kr,$h(i)),n.buffers.color.setClear(Kr.r,Kr.g,Kr.b,d,o)}return{getClearColor:function(){return a},setClearColor:function(m,d=1){a.set(m),l=d,b(a,l)},getClearAlpha:function(){return l},setClearAlpha:function(m){l=m,b(a,l)},render:y}}function Fm(i,t,e,n){let s=i.getParameter(i.MAX_VERTEX_ATTRIBS),r=n.isWebGL2?null:t.get("OES_vertex_array_object"),o=n.isWebGL2||r!==null,a={},l=m(null),c=l,u=!1;function f(I,k,G,K,Q){let $=!1;if(o){let nt=b(K,G,k);c!==nt&&(c=nt,x(c.object)),$=d(I,K,G,Q),$&&C(I,K,G,Q)}else{let nt=k.wireframe===!0;(c.geometry!==K.id||c.program!==G.id||c.wireframe!==nt)&&(c.geometry=K.id,c.program=G.id,c.wireframe=nt,$=!0)}Q!==null&&e.update(Q,i.ELEMENT_ARRAY_BUFFER),($||u)&&(u=!1,j(I,k,G,K),Q!==null&&i.bindBuffer(i.ELEMENT_ARRAY_BUFFER,e.get(Q).buffer))}function p(){return n.isWebGL2?i.createVertexArray():r.createVertexArrayOES()}function x(I){return n.isWebGL2?i.bindVertexArray(I):r.bindVertexArrayOES(I)}function y(I){return n.isWebGL2?i.deleteVertexArray(I):r.deleteVertexArrayOES(I)}function b(I,k,G){let K=G.wireframe===!0,Q=a[I.id];Q===void 0&&(Q={},a[I.id]=Q);let $=Q[k.id];$===void 0&&($={},Q[k.id]=$);let nt=$[K];return nt===void 0&&(nt=m(p()),$[K]=nt),nt}function m(I){let k=[],G=[],K=[];for(let Q=0;Q<s;Q++)k[Q]=0,G[Q]=0,K[Q]=0;return{geometry:null,program:null,wireframe:!1,newAttributes:k,enabledAttributes:G,attributeDivisors:K,object:I,attributes:{},index:null}}function d(I,k,G,K){let Q=c.attributes,$=k.attributes,nt=0,ct=G.getAttributes();for(let bt in ct)if(ct[bt].location>=0){let ot=Q[bt],vt=$[bt];if(vt===void 0&&(bt==="instanceMatrix"&&I.instanceMatrix&&(vt=I.instanceMatrix),bt==="instanceColor"&&I.instanceColor&&(vt=I.instanceColor)),ot===void 0||ot.attribute!==vt||vt&&ot.data!==vt.data)return!0;nt++}return c.attributesNum!==nt||c.index!==K}function C(I,k,G,K){let Q={},$=k.attributes,nt=0,ct=G.getAttributes();for(let bt in ct)if(ct[bt].location>=0){let ot=$[bt];ot===void 0&&(bt==="instanceMatrix"&&I.instanceMatrix&&(ot=I.instanceMatrix),bt==="instanceColor"&&I.instanceColor&&(ot=I.instanceColor));let vt={};vt.attribute=ot,ot&&ot.data&&(vt.data=ot.data),Q[bt]=vt,nt++}c.attributes=Q,c.attributesNum=nt,c.index=K}function w(){let I=c.newAttributes;for(let k=0,G=I.length;k<G;k++)I[k]=0}function U(I){z(I,0)}function z(I,k){let G=c.newAttributes,K=c.enabledAttributes,Q=c.attributeDivisors;G[I]=1,K[I]===0&&(i.enableVertexAttribArray(I),K[I]=1),Q[I]!==k&&((n.isWebGL2?i:t.get("ANGLE_instanced_arrays"))[n.isWebGL2?"vertexAttribDivisor":"vertexAttribDivisorANGLE"](I,k),Q[I]=k)}function N(){let I=c.newAttributes,k=c.enabledAttributes;for(let G=0,K=k.length;G<K;G++)k[G]!==I[G]&&(i.disableVertexAttribArray(G),k[G]=0)}function L(I,k,G,K,Q,$,nt){nt===!0?i.vertexAttribIPointer(I,k,G,Q,$):i.vertexAttribPointer(I,k,G,K,Q,$)}function j(I,k,G,K){if(n.isWebGL2===!1&&(I.isInstancedMesh||K.isInstancedBufferGeometry)&&t.get("ANGLE_instanced_arrays")===null)return;w();let Q=K.attributes,$=G.getAttributes(),nt=k.defaultAttributeValues;for(let ct in $){let bt=$[ct];if(bt.location>=0){let J=Q[ct];if(J===void 0&&(ct==="instanceMatrix"&&I.instanceMatrix&&(J=I.instanceMatrix),ct==="instanceColor"&&I.instanceColor&&(J=I.instanceColor)),J!==void 0){let ot=J.normalized,vt=J.itemSize,Lt=e.get(J);if(Lt===void 0)continue;let Nt=Lt.buffer,Ct=Lt.type,It=Lt.bytesPerElement,Tt=n.isWebGL2===!0&&(Ct===i.INT||Ct===i.UNSIGNED_INT||J.gpuType===Fh);if(J.isInterleavedBufferAttribute){let kt=J.data,W=kt.stride,Pe=J.offset;if(kt.isInstancedInterleavedBuffer){for(let Dt=0;Dt<bt.locationSize;Dt++)z(bt.location+Dt,kt.meshPerAttribute);I.isInstancedMesh!==!0&&K._maxInstanceCount===void 0&&(K._maxInstanceCount=kt.meshPerAttribute*kt.count)}else for(let Dt=0;Dt<bt.locationSize;Dt++)U(bt.location+Dt);i.bindBuffer(i.ARRAY_BUFFER,Nt);for(let Dt=0;Dt<bt.locationSize;Dt++)L(bt.location+Dt,vt/bt.locationSize,Ct,ot,W*It,(Pe+vt/bt.locationSize*Dt)*It,Tt)}else{if(J.isInstancedBufferAttribute){for(let kt=0;kt<bt.locationSize;kt++)z(bt.location+kt,J.meshPerAttribute);I.isInstancedMesh!==!0&&K._maxInstanceCount===void 0&&(K._maxInstanceCount=J.meshPerAttribute*J.count)}else for(let kt=0;kt<bt.locationSize;kt++)U(bt.location+kt);i.bindBuffer(i.ARRAY_BUFFER,Nt);for(let kt=0;kt<bt.locationSize;kt++)L(bt.location+kt,vt/bt.locationSize,Ct,ot,vt*It,vt/bt.locationSize*kt*It,Tt)}}else if(nt!==void 0){let ot=nt[ct];if(ot!==void 0)switch(ot.length){case 2:i.vertexAttrib2fv(bt.location,ot);break;case 3:i.vertexAttrib3fv(bt.location,ot);break;case 4:i.vertexAttrib4fv(bt.location,ot);break;default:i.vertexAttrib1fv(bt.location,ot)}}}}N()}function S(){tt();for(let I in a){let k=a[I];for(let G in k){let K=k[G];for(let Q in K)y(K[Q].object),delete K[Q];delete k[G]}delete a[I]}}function R(I){if(a[I.id]===void 0)return;let k=a[I.id];for(let G in k){let K=k[G];for(let Q in K)y(K[Q].object),delete K[Q];delete k[G]}delete a[I.id]}function V(I){for(let k in a){let G=a[k];if(G[I.id]===void 0)continue;let K=G[I.id];for(let Q in K)y(K[Q].object),delete K[Q];delete G[I.id]}}function tt(){ft(),u=!0,c!==l&&(c=l,x(c.object))}function ft(){l.geometry=null,l.program=null,l.wireframe=!1}return{setup:f,reset:tt,resetDefaultState:ft,dispose:S,releaseStatesOfGeometry:R,releaseStatesOfProgram:V,initAttributes:w,enableAttribute:U,disableUnusedAttributes:N}}function Bm(i,t,e,n){let s=n.isWebGL2,r;function o(u){r=u}function a(u,f){i.drawArrays(r,u,f),e.update(f,r,1)}function l(u,f,p){if(p===0)return;let x,y;if(s)x=i,y="drawArraysInstanced";else if(x=t.get("ANGLE_instanced_arrays"),y="drawArraysInstancedANGLE",x===null){console.error("THREE.WebGLBufferRenderer: using THREE.InstancedBufferGeometry but hardware does not support extension ANGLE_instanced_arrays.");return}x[y](r,u,f,p),e.update(f,r,p)}function c(u,f,p){if(p===0)return;let x=t.get("WEBGL_multi_draw");if(x===null)for(let y=0;y<p;y++)this.render(u[y],f[y]);else{x.multiDrawArraysWEBGL(r,u,0,f,0,p);let y=0;for(let b=0;b<p;b++)y+=f[b];e.update(y,r,1)}}this.setMode=o,this.render=a,this.renderInstances=l,this.renderMultiDraw=c}function zm(i,t,e){let n;function s(){if(n!==void 0)return n;if(t.has("EXT_texture_filter_anisotropic")===!0){let L=t.get("EXT_texture_filter_anisotropic");n=i.getParameter(L.MAX_TEXTURE_MAX_ANISOTROPY_EXT)}else n=0;return n}function r(L){if(L==="highp"){if(i.getShaderPrecisionFormat(i.VERTEX_SHADER,i.HIGH_FLOAT).precision>0&&i.getShaderPrecisionFormat(i.FRAGMENT_SHADER,i.HIGH_FLOAT).precision>0)return"highp";L="mediump"}return L==="mediump"&&i.getShaderPrecisionFormat(i.VERTEX_SHADER,i.MEDIUM_FLOAT).precision>0&&i.getShaderPrecisionFormat(i.FRAGMENT_SHADER,i.MEDIUM_FLOAT).precision>0?"mediump":"lowp"}let o=typeof WebGL2RenderingContext<"u"&&i.constructor.name==="WebGL2RenderingContext",a=e.precision!==void 0?e.precision:"highp",l=r(a);l!==a&&(console.warn("THREE.WebGLRenderer:",a,"not supported, using",l,"instead."),a=l);let c=o||t.has("WEBGL_draw_buffers"),u=e.logarithmicDepthBuffer===!0,f=i.getParameter(i.MAX_TEXTURE_IMAGE_UNITS),p=i.getParameter(i.MAX_VERTEX_TEXTURE_IMAGE_UNITS),x=i.getParameter(i.MAX_TEXTURE_SIZE),y=i.getParameter(i.MAX_CUBE_MAP_TEXTURE_SIZE),b=i.getParameter(i.MAX_VERTEX_ATTRIBS),m=i.getParameter(i.MAX_VERTEX_UNIFORM_VECTORS),d=i.getParameter(i.MAX_VARYING_VECTORS),C=i.getParameter(i.MAX_FRAGMENT_UNIFORM_VECTORS),w=p>0,U=o||t.has("OES_texture_float"),z=w&&U,N=o?i.getParameter(i.MAX_SAMPLES):0;return{isWebGL2:o,drawBuffers:c,getMaxAnisotropy:s,getMaxPrecision:r,precision:a,logarithmicDepthBuffer:u,maxTextures:f,maxVertexTextures:p,maxTextureSize:x,maxCubemapSize:y,maxAttributes:b,maxVertexUniforms:m,maxVaryings:d,maxFragmentUniforms:C,vertexTextures:w,floatFragmentTextures:U,floatVertexTextures:z,maxSamples:N}}function km(i){let t=this,e=null,n=0,s=!1,r=!1,o=new Ln,a=new re,l={value:null,needsUpdate:!1};this.uniform=l,this.numPlanes=0,this.numIntersection=0,this.init=function(f,p){let x=f.length!==0||p||n!==0||s;return s=p,n=f.length,x},this.beginShadows=function(){r=!0,u(null)},this.endShadows=function(){r=!1},this.setGlobalState=function(f,p){e=u(f,p,0)},this.setState=function(f,p,x){let y=f.clippingPlanes,b=f.clipIntersection,m=f.clipShadows,d=i.get(f);if(!s||y===null||y.length===0||r&&!m)r?u(null):c();else{let C=r?0:n,w=C*4,U=d.clippingState||null;l.value=U,U=u(y,p,w,x);for(let z=0;z!==w;++z)U[z]=e[z];d.clippingState=U,this.numIntersection=b?this.numPlanes:0,this.numPlanes+=C}};function c(){l.value!==e&&(l.value=e,l.needsUpdate=n>0),t.numPlanes=n,t.numIntersection=0}function u(f,p,x,y){let b=f!==null?f.length:0,m=null;if(b!==0){if(m=l.value,y!==!0||m===null){let d=x+b*4,C=p.matrixWorldInverse;a.getNormalMatrix(C),(m===null||m.length<d)&&(m=new Float32Array(d));for(let w=0,U=x;w!==b;++w,U+=4)o.copy(f[w]).applyMatrix4(C,a),o.normal.toArray(m,U),m[U+3]=o.constant}l.value=m,l.needsUpdate=!0}return t.numPlanes=b,t.numIntersection=0,m}}function Hm(i){let t=new WeakMap;function e(o,a){return a===Ho?o.mapping=Ps:a===Vo&&(o.mapping=Ls),o}function n(o){if(o&&o.isTexture){let a=o.mapping;if(a===Ho||a===Vo)if(t.has(o)){let l=t.get(o).texture;return e(l,o.mapping)}else{let l=o.image;if(l&&l.height>0){let c=new Jo(l.height/2);return c.fromEquirectangularTexture(i,o),t.set(o,c),o.addEventListener("dispose",s),e(c.texture,o.mapping)}else return null}}return o}function s(o){let a=o.target;a.removeEventListener("dispose",s);let l=t.get(a);l!==void 0&&(t.delete(a),l.dispose())}function r(){t=new WeakMap}return{get:n,dispose:r}}var Us=class extends va{constructor(t=-1,e=1,n=1,s=-1,r=.1,o=2e3){super(),this.isOrthographicCamera=!0,this.type="OrthographicCamera",this.zoom=1,this.view=null,this.left=t,this.right=e,this.top=n,this.bottom=s,this.near=r,this.far=o,this.updateProjectionMatrix()}copy(t,e){return super.copy(t,e),this.left=t.left,this.right=t.right,this.top=t.top,this.bottom=t.bottom,this.near=t.near,this.far=t.far,this.zoom=t.zoom,this.view=t.view===null?null:Object.assign({},t.view),this}setViewOffset(t,e,n,s,r,o){this.view===null&&(this.view={enabled:!0,fullWidth:1,fullHeight:1,offsetX:0,offsetY:0,width:1,height:1}),this.view.enabled=!0,this.view.fullWidth=t,this.view.fullHeight=e,this.view.offsetX=n,this.view.offsetY=s,this.view.width=r,this.view.height=o,this.updateProjectionMatrix()}clearViewOffset(){this.view!==null&&(this.view.enabled=!1),this.updateProjectionMatrix()}updateProjectionMatrix(){let t=(this.right-this.left)/(2*this.zoom),e=(this.top-this.bottom)/(2*this.zoom),n=(this.right+this.left)/2,s=(this.top+this.bottom)/2,r=n-t,o=n+t,a=s+e,l=s-e;if(this.view!==null&&this.view.enabled){let c=(this.right-this.left)/this.view.fullWidth/this.zoom,u=(this.top-this.bottom)/this.view.fullHeight/this.zoom;r+=c*this.view.offsetX,o=r+c*this.view.width,a-=u*this.view.offsetY,l=a-u*this.view.height}this.projectionMatrix.makeOrthographic(r,o,a,l,this.near,this.far,this.coordinateSystem),this.projectionMatrixInverse.copy(this.projectionMatrix).invert()}toJSON(t){let e=super.toJSON(t);return e.object.zoom=this.zoom,e.object.left=this.left,e.object.right=this.right,e.object.top=this.top,e.object.bottom=this.bottom,e.object.near=this.near,e.object.far=this.far,this.view!==null&&(e.object.view=Object.assign({},this.view)),e}},Es=4,sh=[.125,.215,.35,.446,.526,.582],Hi=20,Io=new Us,rh=new qt,Do=null,Uo=0,No=0,zi=(1+Math.sqrt(5))/2,Ms=1/zi,ah=[new F(1,1,1),new F(-1,1,1),new F(1,1,-1),new F(-1,1,-1),new F(0,zi,Ms),new F(0,zi,-Ms),new F(Ms,0,zi),new F(-Ms,0,zi),new F(zi,Ms,0),new F(-zi,Ms,0)],Ma=class{constructor(t){this._renderer=t,this._pingPongRenderTarget=null,this._lodMax=0,this._cubeSize=0,this._lodPlanes=[],this._sizeLods=[],this._sigmas=[],this._blurMaterial=null,this._cubemapMaterial=null,this._equirectMaterial=null,this._compileMaterial(this._blurMaterial)}fromScene(t,e=0,n=.1,s=100){Do=this._renderer.getRenderTarget(),Uo=this._renderer.getActiveCubeFace(),No=this._renderer.getActiveMipmapLevel(),this._setSize(256);let r=this._allocateTargets();return r.depthBuffer=!0,this._sceneToCubeUV(t,n,s,r),e>0&&this._blur(r,0,0,e),this._applyPMREM(r),this._cleanup(r),r}fromEquirectangular(t,e=null){return this._fromTexture(t,e)}fromCubemap(t,e=null){return this._fromTexture(t,e)}compileCubemapShader(){this._cubemapMaterial===null&&(this._cubemapMaterial=ch(),this._compileMaterial(this._cubemapMaterial))}compileEquirectangularShader(){this._equirectMaterial===null&&(this._equirectMaterial=lh(),this._compileMaterial(this._equirectMaterial))}dispose(){this._dispose(),this._cubemapMaterial!==null&&this._cubemapMaterial.dispose(),this._equirectMaterial!==null&&this._equirectMaterial.dispose()}_setSize(t){this._lodMax=Math.floor(Math.log2(t)),this._cubeSize=Math.pow(2,this._lodMax)}_dispose(){this._blurMaterial!==null&&this._blurMaterial.dispose(),this._pingPongRenderTarget!==null&&this._pingPongRenderTarget.dispose();for(let t=0;t<this._lodPlanes.length;t++)this._lodPlanes[t].dispose()}_cleanup(t){this._renderer.setRenderTarget(Do,Uo,No),t.scissorTest=!1,Qr(t,0,0,t.width,t.height)}_fromTexture(t,e){t.mapping===Ps||t.mapping===Ls?this._setSize(t.image.length===0?16:t.image[0].width||t.image[0].image.width):this._setSize(t.image.width/4),Do=this._renderer.getRenderTarget(),Uo=this._renderer.getActiveCubeFace(),No=this._renderer.getActiveMipmapLevel();let n=e||this._allocateTargets();return this._textureToCubeUV(t,n),this._applyPMREM(n),this._cleanup(n),n}_allocateTargets(){let t=3*Math.max(this._cubeSize,112),e=4*this._cubeSize,n={magFilter:yn,minFilter:yn,generateMipmaps:!1,type:mn,format:Un,colorSpace:si,depthBuffer:!1},s=oh(t,e,n);if(this._pingPongRenderTarget===null||this._pingPongRenderTarget.width!==t||this._pingPongRenderTarget.height!==e){this._pingPongRenderTarget!==null&&this._dispose(),this._pingPongRenderTarget=oh(t,e,n);let{_lodMax:r}=this;({sizeLods:this._sizeLods,lodPlanes:this._lodPlanes,sigmas:this._sigmas}=Vm(r)),this._blurMaterial=Gm(r,t,e)}return s}_compileMaterial(t){let e=new ke(this._lodPlanes[0],t);this._renderer.compile(e,Io)}_sceneToCubeUV(t,e,n,s){let a=new en(90,1,e,n),l=[1,-1,1,1,1,1],c=[1,1,1,-1,-1,-1],u=this._renderer,f=u.autoClear,p=u.toneMapping;u.getClearColor(rh),u.toneMapping=vi,u.autoClear=!1;let x=new gn({name:"PMREM.Background",side:nn,depthWrite:!1,depthTest:!1}),y=new ke(new Yi,x),b=!1,m=t.background;m?m.isColor&&(x.color.copy(m),t.background=null,b=!0):(x.color.copy(rh),b=!0);for(let d=0;d<6;d++){let C=d%3;C===0?(a.up.set(0,l[d],0),a.lookAt(c[d],0,0)):C===1?(a.up.set(0,0,l[d]),a.lookAt(0,c[d],0)):(a.up.set(0,l[d],0),a.lookAt(0,0,c[d]));let w=this._cubeSize;Qr(s,C*w,d>2?w:0,w,w),u.setRenderTarget(s),b&&u.render(y,a),u.render(t,a)}y.geometry.dispose(),y.material.dispose(),u.toneMapping=p,u.autoClear=f,t.background=m}_textureToCubeUV(t,e){let n=this._renderer,s=t.mapping===Ps||t.mapping===Ls;s?(this._cubemapMaterial===null&&(this._cubemapMaterial=ch()),this._cubemapMaterial.uniforms.flipEnvMap.value=t.isRenderTargetTexture===!1?-1:1):this._equirectMaterial===null&&(this._equirectMaterial=lh());let r=s?this._cubemapMaterial:this._equirectMaterial,o=new ke(this._lodPlanes[0],r),a=r.uniforms;a.envMap.value=t;let l=this._cubeSize;Qr(e,0,0,3*l,2*l),n.setRenderTarget(e),n.render(o,Io)}_applyPMREM(t){let e=this._renderer,n=e.autoClear;e.autoClear=!1;for(let s=1;s<this._lodPlanes.length;s++){let r=Math.sqrt(this._sigmas[s]*this._sigmas[s]-this._sigmas[s-1]*this._sigmas[s-1]),o=ah[(s-1)%ah.length];this._blur(t,s-1,s,r,o)}e.autoClear=n}_blur(t,e,n,s,r){let o=this._pingPongRenderTarget;this._halfBlur(t,o,e,n,s,"latitudinal",r),this._halfBlur(o,t,n,n,s,"longitudinal",r)}_halfBlur(t,e,n,s,r,o,a){let l=this._renderer,c=this._blurMaterial;o!=="latitudinal"&&o!=="longitudinal"&&console.error("blur direction must be either latitudinal or longitudinal!");let u=3,f=new ke(this._lodPlanes[s],c),p=c.uniforms,x=this._sizeLods[n]-1,y=isFinite(r)?Math.PI/(2*x):2*Math.PI/(2*Hi-1),b=r/y,m=isFinite(r)?1+Math.floor(u*b):Hi;m>Hi&&console.warn(`sigmaRadians, ${r}, is too large and will clip, as it requested ${m} samples when the maximum is set to ${Hi}`);let d=[],C=0;for(let L=0;L<Hi;++L){let j=L/b,S=Math.exp(-j*j/2);d.push(S),L===0?C+=S:L<m&&(C+=2*S)}for(let L=0;L<d.length;L++)d[L]=d[L]/C;p.envMap.value=t.texture,p.samples.value=m,p.weights.value=d,p.latitudinal.value=o==="latitudinal",a&&(p.poleAxis.value=a);let{_lodMax:w}=this;p.dTheta.value=y,p.mipInt.value=w-n;let U=this._sizeLods[s],z=3*U*(s>w-Es?s-w+Es:0),N=4*(this._cubeSize-U);Qr(e,z,N,3*U,2*U),l.setRenderTarget(e),l.render(f,Io)}};function Vm(i){let t=[],e=[],n=[],s=i,r=i-Es+1+sh.length;for(let o=0;o<r;o++){let a=Math.pow(2,s);e.push(a);let l=1/a;o>i-Es?l=sh[o-i+Es-1]:o===0&&(l=0),n.push(l);let c=1/(a-2),u=-c,f=1+c,p=[u,u,f,u,f,f,u,u,f,f,u,f],x=6,y=6,b=3,m=2,d=1,C=new Float32Array(b*y*x),w=new Float32Array(m*y*x),U=new Float32Array(d*y*x);for(let N=0;N<x;N++){let L=N%3*2/3-1,j=N>2?0:-1,S=[L,j,0,L+2/3,j,0,L+2/3,j+1,0,L,j,0,L+2/3,j+1,0,L,j+1,0];C.set(S,b*y*N),w.set(p,m*y*N);let R=[N,N,N,N,N,N];U.set(R,d*y*N)}let z=new hn;z.setAttribute("position",new sn(C,b)),z.setAttribute("uv",new sn(w,m)),z.setAttribute("faceIndex",new sn(U,d)),t.push(z),s>Es&&s--}return{lodPlanes:t,sizeLods:e,sigmas:n}}function oh(i,t,e){let n=new je(i,t,e);return n.texture.mapping=Na,n.texture.name="PMREM.cubeUv",n.scissorTest=!0,n}function Qr(i,t,e,n,s){i.viewport.set(t,e,n,s),i.scissor.set(t,e,n,s)}function Gm(i,t,e){let n=new Float32Array(Hi),s=new F(0,1,0);return new Ne({name:"SphericalGaussianBlur",defines:{n:Hi,CUBEUV_TEXEL_WIDTH:1/t,CUBEUV_TEXEL_HEIGHT:1/e,CUBEUV_MAX_MIP:`${i}.0`},uniforms:{envMap:{value:null},samples:{value:1},weights:{value:n},latitudinal:{value:!1},dTheta:{value:0},mipInt:{value:0},poleAxis:{value:s}},vertexShader:Rl(),fragmentShader:`

			precision mediump float;
			precision mediump int;

			varying vec3 vOutputDirection;

			uniform sampler2D envMap;
			uniform int samples;
			uniform float weights[ n ];
			uniform bool latitudinal;
			uniform float dTheta;
			uniform float mipInt;
			uniform vec3 poleAxis;

			#define ENVMAP_TYPE_CUBE_UV
			#include <cube_uv_reflection_fragment>

			vec3 getSample( float theta, vec3 axis ) {

				float cosTheta = cos( theta );
				// Rodrigues' axis-angle rotation
				vec3 sampleDirection = vOutputDirection * cosTheta
					+ cross( axis, vOutputDirection ) * sin( theta )
					+ axis * dot( axis, vOutputDirection ) * ( 1.0 - cosTheta );

				return bilinearCubeUV( envMap, sampleDirection, mipInt );

			}

			void main() {

				vec3 axis = latitudinal ? poleAxis : cross( poleAxis, vOutputDirection );

				if ( all( equal( axis, vec3( 0.0 ) ) ) ) {

					axis = vec3( vOutputDirection.z, 0.0, - vOutputDirection.x );

				}

				axis = normalize( axis );

				gl_FragColor = vec4( 0.0, 0.0, 0.0, 1.0 );
				gl_FragColor.rgb += weights[ 0 ] * getSample( 0.0, axis );

				for ( int i = 1; i < n; i++ ) {

					if ( i >= samples ) {

						break;

					}

					float theta = dTheta * float( i );
					gl_FragColor.rgb += weights[ i ] * getSample( -1.0 * theta, axis );
					gl_FragColor.rgb += weights[ i ] * getSample( theta, axis );

				}

			}
		`,blending:Wn,depthTest:!1,depthWrite:!1})}function lh(){return new Ne({name:"EquirectangularToCubeUV",uniforms:{envMap:{value:null}},vertexShader:Rl(),fragmentShader:`

			precision mediump float;
			precision mediump int;

			varying vec3 vOutputDirection;

			uniform sampler2D envMap;

			#include <common>

			void main() {

				vec3 outputDirection = normalize( vOutputDirection );
				vec2 uv = equirectUv( outputDirection );

				gl_FragColor = vec4( texture2D ( envMap, uv ).rgb, 1.0 );

			}
		`,blending:Wn,depthTest:!1,depthWrite:!1})}function ch(){return new Ne({name:"CubemapToCubeUV",uniforms:{envMap:{value:null},flipEnvMap:{value:-1}},vertexShader:Rl(),fragmentShader:`

			precision mediump float;
			precision mediump int;

			uniform float flipEnvMap;

			varying vec3 vOutputDirection;

			uniform samplerCube envMap;

			void main() {

				gl_FragColor = textureCube( envMap, vec3( flipEnvMap * vOutputDirection.x, vOutputDirection.yz ) );

			}
		`,blending:Wn,depthTest:!1,depthWrite:!1})}function Rl(){return`

		precision mediump float;
		precision mediump int;

		attribute float faceIndex;

		varying vec3 vOutputDirection;

		// RH coordinate system; PMREM face-indexing convention
		vec3 getDirection( vec2 uv, float face ) {

			uv = 2.0 * uv - 1.0;

			vec3 direction = vec3( uv, 1.0 );

			if ( face == 0.0 ) {

				direction = direction.zyx; // ( 1, v, u ) pos x

			} else if ( face == 1.0 ) {

				direction = direction.xzy;
				direction.xz *= -1.0; // ( -u, 1, -v ) pos y

			} else if ( face == 2.0 ) {

				direction.x *= -1.0; // ( -u, v, 1 ) pos z

			} else if ( face == 3.0 ) {

				direction = direction.zyx;
				direction.xz *= -1.0; // ( -1, v, -u ) neg x

			} else if ( face == 4.0 ) {

				direction = direction.xzy;
				direction.xy *= -1.0; // ( -u, -1, v ) neg y

			} else if ( face == 5.0 ) {

				direction.z *= -1.0; // ( u, v, -1 ) neg z

			}

			return direction;

		}

		void main() {

			vOutputDirection = getDirection( uv, faceIndex );
			gl_Position = vec4( position, 1.0 );

		}
	`}function Wm(i){let t=new WeakMap,e=null;function n(a){if(a&&a.isTexture){let l=a.mapping,c=l===Ho||l===Vo,u=l===Ps||l===Ls;if(c||u)if(a.isRenderTargetTexture&&a.needsPMREMUpdate===!0){a.needsPMREMUpdate=!1;let f=t.get(a);return e===null&&(e=new Ma(i)),f=c?e.fromEquirectangular(a,f):e.fromCubemap(a,f),t.set(a,f),f.texture}else{if(t.has(a))return t.get(a).texture;{let f=a.image;if(c&&f&&f.height>0||u&&f&&s(f)){e===null&&(e=new Ma(i));let p=c?e.fromEquirectangular(a):e.fromCubemap(a);return t.set(a,p),a.addEventListener("dispose",r),p.texture}else return null}}}return a}function s(a){let l=0,c=6;for(let u=0;u<c;u++)a[u]!==void 0&&l++;return l===c}function r(a){let l=a.target;l.removeEventListener("dispose",r);let c=t.get(l);c!==void 0&&(t.delete(l),c.dispose())}function o(){t=new WeakMap,e!==null&&(e.dispose(),e=null)}return{get:n,dispose:o}}function Xm(i){let t={};function e(n){if(t[n]!==void 0)return t[n];let s;switch(n){case"WEBGL_depth_texture":s=i.getExtension("WEBGL_depth_texture")||i.getExtension("MOZ_WEBGL_depth_texture")||i.getExtension("WEBKIT_WEBGL_depth_texture");break;case"EXT_texture_filter_anisotropic":s=i.getExtension("EXT_texture_filter_anisotropic")||i.getExtension("MOZ_EXT_texture_filter_anisotropic")||i.getExtension("WEBKIT_EXT_texture_filter_anisotropic");break;case"WEBGL_compressed_texture_s3tc":s=i.getExtension("WEBGL_compressed_texture_s3tc")||i.getExtension("MOZ_WEBGL_compressed_texture_s3tc")||i.getExtension("WEBKIT_WEBGL_compressed_texture_s3tc");break;case"WEBGL_compressed_texture_pvrtc":s=i.getExtension("WEBGL_compressed_texture_pvrtc")||i.getExtension("WEBKIT_WEBGL_compressed_texture_pvrtc");break;default:s=i.getExtension(n)}return t[n]=s,s}return{has:function(n){return e(n)!==null},init:function(n){n.isWebGL2?(e("EXT_color_buffer_float"),e("WEBGL_clip_cull_distance")):(e("WEBGL_depth_texture"),e("OES_texture_float"),e("OES_texture_half_float"),e("OES_texture_half_float_linear"),e("OES_standard_derivatives"),e("OES_element_index_uint"),e("OES_vertex_array_object"),e("ANGLE_instanced_arrays")),e("OES_texture_float_linear"),e("EXT_color_buffer_half_float"),e("WEBGL_multisampled_render_to_texture")},get:function(n){let s=e(n);return s===null&&console.warn("THREE.WebGLRenderer: "+n+" extension not supported."),s}}}function Ym(i,t,e,n){let s={},r=new WeakMap;function o(f){let p=f.target;p.index!==null&&t.remove(p.index);for(let y in p.attributes)t.remove(p.attributes[y]);for(let y in p.morphAttributes){let b=p.morphAttributes[y];for(let m=0,d=b.length;m<d;m++)t.remove(b[m])}p.removeEventListener("dispose",o),delete s[p.id];let x=r.get(p);x&&(t.remove(x),r.delete(p)),n.releaseStatesOfGeometry(p),p.isInstancedBufferGeometry===!0&&delete p._maxInstanceCount,e.memory.geometries--}function a(f,p){return s[p.id]===!0||(p.addEventListener("dispose",o),s[p.id]=!0,e.memory.geometries++),p}function l(f){let p=f.attributes;for(let y in p)t.update(p[y],i.ARRAY_BUFFER);let x=f.morphAttributes;for(let y in x){let b=x[y];for(let m=0,d=b.length;m<d;m++)t.update(b[m],i.ARRAY_BUFFER)}}function c(f){let p=[],x=f.index,y=f.attributes.position,b=0;if(x!==null){let C=x.array;b=x.version;for(let w=0,U=C.length;w<U;w+=3){let z=C[w+0],N=C[w+1],L=C[w+2];p.push(z,N,N,L,L,z)}}else if(y!==void 0){let C=y.array;b=y.version;for(let w=0,U=C.length/3-1;w<U;w+=3){let z=w+0,N=w+1,L=w+2;p.push(z,N,N,L,L,z)}}else return;let m=new(Zh(p)?_a:xa)(p,1);m.version=b;let d=r.get(f);d&&t.remove(d),r.set(f,m)}function u(f){let p=r.get(f);if(p){let x=f.index;x!==null&&p.version<x.version&&c(f)}else c(f);return r.get(f)}return{get:a,update:l,getWireframeAttribute:u}}function qm(i,t,e,n){let s=n.isWebGL2,r;function o(x){r=x}let a,l;function c(x){a=x.type,l=x.bytesPerElement}function u(x,y){i.drawElements(r,y,a,x*l),e.update(y,r,1)}function f(x,y,b){if(b===0)return;let m,d;if(s)m=i,d="drawElementsInstanced";else if(m=t.get("ANGLE_instanced_arrays"),d="drawElementsInstancedANGLE",m===null){console.error("THREE.WebGLIndexedBufferRenderer: using THREE.InstancedBufferGeometry but hardware does not support extension ANGLE_instanced_arrays.");return}m[d](r,y,a,x*l,b),e.update(y,r,b)}function p(x,y,b){if(b===0)return;let m=t.get("WEBGL_multi_draw");if(m===null)for(let d=0;d<b;d++)this.render(x[d]/l,y[d]);else{m.multiDrawElementsWEBGL(r,y,0,a,x,0,b);let d=0;for(let C=0;C<b;C++)d+=y[C];e.update(d,r,1)}}this.setMode=o,this.setIndex=c,this.render=u,this.renderInstances=f,this.renderMultiDraw=p}function Zm(i){let t={geometries:0,textures:0},e={frame:0,calls:0,triangles:0,points:0,lines:0};function n(r,o,a){switch(e.calls++,o){case i.TRIANGLES:e.triangles+=a*(r/3);break;case i.LINES:e.lines+=a*(r/2);break;case i.LINE_STRIP:e.lines+=a*(r-1);break;case i.LINE_LOOP:e.lines+=a*r;break;case i.POINTS:e.points+=a*r;break;default:console.error("THREE.WebGLInfo: Unknown draw mode:",o);break}}function s(){e.calls=0,e.triangles=0,e.points=0,e.lines=0}return{memory:t,render:e,programs:null,autoReset:!0,reset:s,update:n}}function Jm(i,t){return i[0]-t[0]}function $m(i,t){return Math.abs(t[1])-Math.abs(i[1])}function jm(i,t,e){let n={},s=new Float32Array(8),r=new WeakMap,o=new we,a=[];for(let c=0;c<8;c++)a[c]=[c,0];function l(c,u,f){let p=c.morphTargetInfluences;if(t.isWebGL2===!0){let x=u.morphAttributes.position||u.morphAttributes.normal||u.morphAttributes.color,y=x!==void 0?x.length:0,b=r.get(u);if(b===void 0||b.count!==y){let I=function(){tt.dispose(),r.delete(u),u.removeEventListener("dispose",I)};b!==void 0&&b.texture.dispose();let C=u.morphAttributes.position!==void 0,w=u.morphAttributes.normal!==void 0,U=u.morphAttributes.color!==void 0,z=u.morphAttributes.position||[],N=u.morphAttributes.normal||[],L=u.morphAttributes.color||[],j=0;C===!0&&(j=1),w===!0&&(j=2),U===!0&&(j=3);let S=u.attributes.position.count*j,R=1;S>t.maxTextureSize&&(R=Math.ceil(S/t.maxTextureSize),S=t.maxTextureSize);let V=new Float32Array(S*R*4*y),tt=new ma(V,S,R,y);tt.type=xi,tt.needsUpdate=!0;let ft=j*4;for(let k=0;k<y;k++){let G=z[k],K=N[k],Q=L[k],$=S*R*4*k;for(let nt=0;nt<G.count;nt++){let ct=nt*ft;C===!0&&(o.fromBufferAttribute(G,nt),V[$+ct+0]=o.x,V[$+ct+1]=o.y,V[$+ct+2]=o.z,V[$+ct+3]=0),w===!0&&(o.fromBufferAttribute(K,nt),V[$+ct+4]=o.x,V[$+ct+5]=o.y,V[$+ct+6]=o.z,V[$+ct+7]=0),U===!0&&(o.fromBufferAttribute(Q,nt),V[$+ct+8]=o.x,V[$+ct+9]=o.y,V[$+ct+10]=o.z,V[$+ct+11]=Q.itemSize===4?o.w:1)}}b={count:y,texture:tt,size:new Pt(S,R)},r.set(u,b),u.addEventListener("dispose",I)}let m=0;for(let C=0;C<p.length;C++)m+=p[C];let d=u.morphTargetsRelative?1:1-m;f.getUniforms().setValue(i,"morphTargetBaseInfluence",d),f.getUniforms().setValue(i,"morphTargetInfluences",p),f.getUniforms().setValue(i,"morphTargetsTexture",b.texture,e),f.getUniforms().setValue(i,"morphTargetsTextureSize",b.size)}else{let x=p===void 0?0:p.length,y=n[u.id];if(y===void 0||y.length!==x){y=[];for(let w=0;w<x;w++)y[w]=[w,0];n[u.id]=y}for(let w=0;w<x;w++){let U=y[w];U[0]=w,U[1]=p[w]}y.sort($m);for(let w=0;w<8;w++)w<x&&y[w][1]?(a[w][0]=y[w][0],a[w][1]=y[w][1]):(a[w][0]=Number.MAX_SAFE_INTEGER,a[w][1]=0);a.sort(Jm);let b=u.morphAttributes.position,m=u.morphAttributes.normal,d=0;for(let w=0;w<8;w++){let U=a[w],z=U[0],N=U[1];z!==Number.MAX_SAFE_INTEGER&&N?(b&&u.getAttribute("morphTarget"+w)!==b[z]&&u.setAttribute("morphTarget"+w,b[z]),m&&u.getAttribute("morphNormal"+w)!==m[z]&&u.setAttribute("morphNormal"+w,m[z]),s[w]=N,d+=N):(b&&u.hasAttribute("morphTarget"+w)===!0&&u.deleteAttribute("morphTarget"+w),m&&u.hasAttribute("morphNormal"+w)===!0&&u.deleteAttribute("morphNormal"+w),s[w]=0)}let C=u.morphTargetsRelative?1:1-d;f.getUniforms().setValue(i,"morphTargetBaseInfluence",C),f.getUniforms().setValue(i,"morphTargetInfluences",s)}}return{update:l}}function Km(i,t,e,n){let s=new WeakMap;function r(l){let c=n.render.frame,u=l.geometry,f=t.get(l,u);if(s.get(f)!==c&&(t.update(f),s.set(f,c)),l.isInstancedMesh&&(l.hasEventListener("dispose",a)===!1&&l.addEventListener("dispose",a),s.get(l)!==c&&(e.update(l.instanceMatrix,i.ARRAY_BUFFER),l.instanceColor!==null&&e.update(l.instanceColor,i.ARRAY_BUFFER),s.set(l,c))),l.isSkinnedMesh){let p=l.skeleton;s.get(p)!==c&&(p.update(),s.set(p,c))}return f}function o(){s=new WeakMap}function a(l){let c=l.target;c.removeEventListener("dispose",a),e.remove(c.instanceMatrix),c.instanceColor!==null&&e.remove(c.instanceColor)}return{update:r,dispose:o}}var ba=class extends bn{constructor(t,e,n,s,r,o,a,l,c,u){if(u=u!==void 0?u:Gi,u!==Gi&&u!==Is)throw new Error("DepthTexture format must be either THREE.DepthFormat or THREE.DepthStencilFormat");n===void 0&&u===Gi&&(n=gi),n===void 0&&u===Is&&(n=Vi),super(null,s,r,o,a,l,u,n,c),this.isDepthTexture=!0,this.image={width:t,height:e},this.magFilter=a!==void 0?a:qe,this.minFilter=l!==void 0?l:qe,this.flipY=!1,this.generateMipmaps=!1,this.compareFunction=null}copy(t){return super.copy(t),this.compareFunction=t.compareFunction,this}toJSON(t){let e=super.toJSON(t);return this.compareFunction!==null&&(e.compareFunction=this.compareFunction),e}},Kh=new bn,Qh=new ba(1,1);Qh.compareFunction=Yh;var tu=new ma,eu=new qo,nu=new ya,hh=[],uh=[],dh=new Float32Array(16),fh=new Float32Array(9),ph=new Float32Array(4);function zs(i,t,e){let n=i[0];if(n<=0||n>0)return i;let s=t*e,r=hh[s];if(r===void 0&&(r=new Float32Array(s),hh[s]=r),t!==0){n.toArray(r,0);for(let o=1,a=0;o!==t;++o)a+=e,i[o].toArray(r,a)}return r}function He(i,t){if(i.length!==t.length)return!1;for(let e=0,n=i.length;e<n;e++)if(i[e]!==t[e])return!1;return!0}function Ve(i,t){for(let e=0,n=t.length;e<n;e++)i[e]=t[e]}function Fa(i,t){let e=uh[t];e===void 0&&(e=new Int32Array(t),uh[t]=e);for(let n=0;n!==t;++n)e[n]=i.allocateTextureUnit();return e}function Qm(i,t){let e=this.cache;e[0]!==t&&(i.uniform1f(this.addr,t),e[0]=t)}function tg(i,t){let e=this.cache;if(t.x!==void 0)(e[0]!==t.x||e[1]!==t.y)&&(i.uniform2f(this.addr,t.x,t.y),e[0]=t.x,e[1]=t.y);else{if(He(e,t))return;i.uniform2fv(this.addr,t),Ve(e,t)}}function eg(i,t){let e=this.cache;if(t.x!==void 0)(e[0]!==t.x||e[1]!==t.y||e[2]!==t.z)&&(i.uniform3f(this.addr,t.x,t.y,t.z),e[0]=t.x,e[1]=t.y,e[2]=t.z);else if(t.r!==void 0)(e[0]!==t.r||e[1]!==t.g||e[2]!==t.b)&&(i.uniform3f(this.addr,t.r,t.g,t.b),e[0]=t.r,e[1]=t.g,e[2]=t.b);else{if(He(e,t))return;i.uniform3fv(this.addr,t),Ve(e,t)}}function ng(i,t){let e=this.cache;if(t.x!==void 0)(e[0]!==t.x||e[1]!==t.y||e[2]!==t.z||e[3]!==t.w)&&(i.uniform4f(this.addr,t.x,t.y,t.z,t.w),e[0]=t.x,e[1]=t.y,e[2]=t.z,e[3]=t.w);else{if(He(e,t))return;i.uniform4fv(this.addr,t),Ve(e,t)}}function ig(i,t){let e=this.cache,n=t.elements;if(n===void 0){if(He(e,t))return;i.uniformMatrix2fv(this.addr,!1,t),Ve(e,t)}else{if(He(e,n))return;ph.set(n),i.uniformMatrix2fv(this.addr,!1,ph),Ve(e,n)}}function sg(i,t){let e=this.cache,n=t.elements;if(n===void 0){if(He(e,t))return;i.uniformMatrix3fv(this.addr,!1,t),Ve(e,t)}else{if(He(e,n))return;fh.set(n),i.uniformMatrix3fv(this.addr,!1,fh),Ve(e,n)}}function rg(i,t){let e=this.cache,n=t.elements;if(n===void 0){if(He(e,t))return;i.uniformMatrix4fv(this.addr,!1,t),Ve(e,t)}else{if(He(e,n))return;dh.set(n),i.uniformMatrix4fv(this.addr,!1,dh),Ve(e,n)}}function ag(i,t){let e=this.cache;e[0]!==t&&(i.uniform1i(this.addr,t),e[0]=t)}function og(i,t){let e=this.cache;if(t.x!==void 0)(e[0]!==t.x||e[1]!==t.y)&&(i.uniform2i(this.addr,t.x,t.y),e[0]=t.x,e[1]=t.y);else{if(He(e,t))return;i.uniform2iv(this.addr,t),Ve(e,t)}}function lg(i,t){let e=this.cache;if(t.x!==void 0)(e[0]!==t.x||e[1]!==t.y||e[2]!==t.z)&&(i.uniform3i(this.addr,t.x,t.y,t.z),e[0]=t.x,e[1]=t.y,e[2]=t.z);else{if(He(e,t))return;i.uniform3iv(this.addr,t),Ve(e,t)}}function cg(i,t){let e=this.cache;if(t.x!==void 0)(e[0]!==t.x||e[1]!==t.y||e[2]!==t.z||e[3]!==t.w)&&(i.uniform4i(this.addr,t.x,t.y,t.z,t.w),e[0]=t.x,e[1]=t.y,e[2]=t.z,e[3]=t.w);else{if(He(e,t))return;i.uniform4iv(this.addr,t),Ve(e,t)}}function hg(i,t){let e=this.cache;e[0]!==t&&(i.uniform1ui(this.addr,t),e[0]=t)}function ug(i,t){let e=this.cache;if(t.x!==void 0)(e[0]!==t.x||e[1]!==t.y)&&(i.uniform2ui(this.addr,t.x,t.y),e[0]=t.x,e[1]=t.y);else{if(He(e,t))return;i.uniform2uiv(this.addr,t),Ve(e,t)}}function dg(i,t){let e=this.cache;if(t.x!==void 0)(e[0]!==t.x||e[1]!==t.y||e[2]!==t.z)&&(i.uniform3ui(this.addr,t.x,t.y,t.z),e[0]=t.x,e[1]=t.y,e[2]=t.z);else{if(He(e,t))return;i.uniform3uiv(this.addr,t),Ve(e,t)}}function fg(i,t){let e=this.cache;if(t.x!==void 0)(e[0]!==t.x||e[1]!==t.y||e[2]!==t.z||e[3]!==t.w)&&(i.uniform4ui(this.addr,t.x,t.y,t.z,t.w),e[0]=t.x,e[1]=t.y,e[2]=t.z,e[3]=t.w);else{if(He(e,t))return;i.uniform4uiv(this.addr,t),Ve(e,t)}}function pg(i,t,e){let n=this.cache,s=e.allocateTextureUnit();n[0]!==s&&(i.uniform1i(this.addr,s),n[0]=s);let r=this.type===i.SAMPLER_2D_SHADOW?Qh:Kh;e.setTexture2D(t||r,s)}function mg(i,t,e){let n=this.cache,s=e.allocateTextureUnit();n[0]!==s&&(i.uniform1i(this.addr,s),n[0]=s),e.setTexture3D(t||eu,s)}function gg(i,t,e){let n=this.cache,s=e.allocateTextureUnit();n[0]!==s&&(i.uniform1i(this.addr,s),n[0]=s),e.setTextureCube(t||nu,s)}function xg(i,t,e){let n=this.cache,s=e.allocateTextureUnit();n[0]!==s&&(i.uniform1i(this.addr,s),n[0]=s),e.setTexture2DArray(t||tu,s)}function _g(i){switch(i){case 5126:return Qm;case 35664:return tg;case 35665:return eg;case 35666:return ng;case 35674:return ig;case 35675:return sg;case 35676:return rg;case 5124:case 35670:return ag;case 35667:case 35671:return og;case 35668:case 35672:return lg;case 35669:case 35673:return cg;case 5125:return hg;case 36294:return ug;case 36295:return dg;case 36296:return fg;case 35678:case 36198:case 36298:case 36306:case 35682:return pg;case 35679:case 36299:case 36307:return mg;case 35680:case 36300:case 36308:case 36293:return gg;case 36289:case 36303:case 36311:case 36292:return xg}}function vg(i,t){i.uniform1fv(this.addr,t)}function yg(i,t){let e=zs(t,this.size,2);i.uniform2fv(this.addr,e)}function Mg(i,t){let e=zs(t,this.size,3);i.uniform3fv(this.addr,e)}function bg(i,t){let e=zs(t,this.size,4);i.uniform4fv(this.addr,e)}function Sg(i,t){let e=zs(t,this.size,4);i.uniformMatrix2fv(this.addr,!1,e)}function wg(i,t){let e=zs(t,this.size,9);i.uniformMatrix3fv(this.addr,!1,e)}function Eg(i,t){let e=zs(t,this.size,16);i.uniformMatrix4fv(this.addr,!1,e)}function Tg(i,t){i.uniform1iv(this.addr,t)}function Ag(i,t){i.uniform2iv(this.addr,t)}function Cg(i,t){i.uniform3iv(this.addr,t)}function Rg(i,t){i.uniform4iv(this.addr,t)}function Pg(i,t){i.uniform1uiv(this.addr,t)}function Lg(i,t){i.uniform2uiv(this.addr,t)}function Ig(i,t){i.uniform3uiv(this.addr,t)}function Dg(i,t){i.uniform4uiv(this.addr,t)}function Ug(i,t,e){let n=this.cache,s=t.length,r=Fa(e,s);He(n,r)||(i.uniform1iv(this.addr,r),Ve(n,r));for(let o=0;o!==s;++o)e.setTexture2D(t[o]||Kh,r[o])}function Ng(i,t,e){let n=this.cache,s=t.length,r=Fa(e,s);He(n,r)||(i.uniform1iv(this.addr,r),Ve(n,r));for(let o=0;o!==s;++o)e.setTexture3D(t[o]||eu,r[o])}function Og(i,t,e){let n=this.cache,s=t.length,r=Fa(e,s);He(n,r)||(i.uniform1iv(this.addr,r),Ve(n,r));for(let o=0;o!==s;++o)e.setTextureCube(t[o]||nu,r[o])}function Fg(i,t,e){let n=this.cache,s=t.length,r=Fa(e,s);He(n,r)||(i.uniform1iv(this.addr,r),Ve(n,r));for(let o=0;o!==s;++o)e.setTexture2DArray(t[o]||tu,r[o])}function Bg(i){switch(i){case 5126:return vg;case 35664:return yg;case 35665:return Mg;case 35666:return bg;case 35674:return Sg;case 35675:return wg;case 35676:return Eg;case 5124:case 35670:return Tg;case 35667:case 35671:return Ag;case 35668:case 35672:return Cg;case 35669:case 35673:return Rg;case 5125:return Pg;case 36294:return Lg;case 36295:return Ig;case 36296:return Dg;case 35678:case 36198:case 36298:case 36306:case 35682:return Ug;case 35679:case 36299:case 36307:return Ng;case 35680:case 36300:case 36308:case 36293:return Og;case 36289:case 36303:case 36311:case 36292:return Fg}}var $o=class{constructor(t,e,n){this.id=t,this.addr=n,this.cache=[],this.type=e.type,this.setValue=_g(e.type)}},jo=class{constructor(t,e,n){this.id=t,this.addr=n,this.cache=[],this.type=e.type,this.size=e.size,this.setValue=Bg(e.type)}},Ko=class{constructor(t){this.id=t,this.seq=[],this.map={}}setValue(t,e,n){let s=this.seq;for(let r=0,o=s.length;r!==o;++r){let a=s[r];a.setValue(t,e[a.id],n)}}},Oo=/(\w+)(\])?(\[|\.)?/g;function mh(i,t){i.seq.push(t),i.map[t.id]=t}function zg(i,t,e){let n=i.name,s=n.length;for(Oo.lastIndex=0;;){let r=Oo.exec(n),o=Oo.lastIndex,a=r[1],l=r[2]==="]",c=r[3];if(l&&(a=a|0),c===void 0||c==="["&&o+2===s){mh(e,c===void 0?new $o(a,i,t):new jo(a,i,t));break}else{let f=e.map[a];f===void 0&&(f=new Ko(a),mh(e,f)),e=f}}}var Cs=class{constructor(t,e){this.seq=[],this.map={};let n=t.getProgramParameter(e,t.ACTIVE_UNIFORMS);for(let s=0;s<n;++s){let r=t.getActiveUniform(e,s),o=t.getUniformLocation(e,r.name);zg(r,o,this)}}setValue(t,e,n,s){let r=this.map[e];r!==void 0&&r.setValue(t,n,s)}setOptional(t,e,n){let s=e[n];s!==void 0&&this.setValue(t,n,s)}static upload(t,e,n,s){for(let r=0,o=e.length;r!==o;++r){let a=e[r],l=n[a.id];l.needsUpdate!==!1&&a.setValue(t,l.value,s)}}static seqWithValue(t,e){let n=[];for(let s=0,r=t.length;s!==r;++s){let o=t[s];o.id in e&&n.push(o)}return n}};function gh(i,t,e){let n=i.createShader(t);return i.shaderSource(n,e),i.compileShader(n),n}var kg=37297,Hg=0;function Vg(i,t){let e=i.split(`
`),n=[],s=Math.max(t-6,0),r=Math.min(t+6,e.length);for(let o=s;o<r;o++){let a=o+1;n.push(`${a===t?">":" "} ${a}: ${e[o]}`)}return n.join(`
`)}function Gg(i){let t=fe.getPrimaries(fe.workingColorSpace),e=fe.getPrimaries(i),n;switch(t===e?n="":t===ca&&e===la?n="LinearDisplayP3ToLinearSRGB":t===la&&e===ca&&(n="LinearSRGBToLinearDisplayP3"),i){case si:case Oa:return[n,"LinearTransferOETF"];case Re:case Al:return[n,"sRGBTransferOETF"];default:return console.warn("THREE.WebGLProgram: Unsupported color space:",i),[n,"LinearTransferOETF"]}}function xh(i,t,e){let n=i.getShaderParameter(t,i.COMPILE_STATUS),s=i.getShaderInfoLog(t).trim();if(n&&s==="")return"";let r=/ERROR: 0:(\d+)/.exec(s);if(r){let o=parseInt(r[1]);return e.toUpperCase()+`

`+s+`

`+Vg(i.getShaderSource(t),o)}else return s}function Wg(i,t){let e=Gg(t);return`vec4 ${i}( vec4 value ) { return ${e[0]}( ${e[1]}( value ) ); }`}function Xg(i,t){let e;switch(t){case bl:e="Linear";break;case Sl:e="Reinhard";break;case wl:e="OptimizedCineon";break;case Mr:e="ACESFilmic";break;case El:e="AgX";break;case ed:e="Custom";break;default:console.warn("THREE.WebGLProgram: Unsupported toneMapping:",t),e="Linear"}return"vec3 "+i+"( vec3 color ) { return "+e+"ToneMapping( color ); }"}function Yg(i){return[i.extensionDerivatives||i.envMapCubeUVHeight||i.bumpMap||i.normalMapTangentSpace||i.clearcoatNormalMap||i.flatShading||i.shaderID==="physical"?"#extension GL_OES_standard_derivatives : enable":"",(i.extensionFragDepth||i.logarithmicDepthBuffer)&&i.rendererExtensionFragDepth?"#extension GL_EXT_frag_depth : enable":"",i.extensionDrawBuffers&&i.rendererExtensionDrawBuffers?"#extension GL_EXT_draw_buffers : require":"",(i.extensionShaderTextureLOD||i.envMap||i.transmission)&&i.rendererExtensionShaderTextureLod?"#extension GL_EXT_shader_texture_lod : enable":""].filter(Ts).join(`
`)}function qg(i){return[i.extensionClipCullDistance?"#extension GL_ANGLE_clip_cull_distance : require":""].filter(Ts).join(`
`)}function Zg(i){let t=[];for(let e in i){let n=i[e];n!==!1&&t.push("#define "+e+" "+n)}return t.join(`
`)}function Jg(i,t){let e={},n=i.getProgramParameter(t,i.ACTIVE_ATTRIBUTES);for(let s=0;s<n;s++){let r=i.getActiveAttrib(t,s),o=r.name,a=1;r.type===i.FLOAT_MAT2&&(a=2),r.type===i.FLOAT_MAT3&&(a=3),r.type===i.FLOAT_MAT4&&(a=4),e[o]={type:r.type,location:i.getAttribLocation(t,o),locationSize:a}}return e}function Ts(i){return i!==""}function _h(i,t){let e=t.numSpotLightShadows+t.numSpotLightMaps-t.numSpotLightShadowsWithMaps;return i.replace(/NUM_DIR_LIGHTS/g,t.numDirLights).replace(/NUM_SPOT_LIGHTS/g,t.numSpotLights).replace(/NUM_SPOT_LIGHT_MAPS/g,t.numSpotLightMaps).replace(/NUM_SPOT_LIGHT_COORDS/g,e).replace(/NUM_RECT_AREA_LIGHTS/g,t.numRectAreaLights).replace(/NUM_POINT_LIGHTS/g,t.numPointLights).replace(/NUM_HEMI_LIGHTS/g,t.numHemiLights).replace(/NUM_DIR_LIGHT_SHADOWS/g,t.numDirLightShadows).replace(/NUM_SPOT_LIGHT_SHADOWS_WITH_MAPS/g,t.numSpotLightShadowsWithMaps).replace(/NUM_SPOT_LIGHT_SHADOWS/g,t.numSpotLightShadows).replace(/NUM_POINT_LIGHT_SHADOWS/g,t.numPointLightShadows)}function vh(i,t){return i.replace(/NUM_CLIPPING_PLANES/g,t.numClippingPlanes).replace(/UNION_CLIPPING_PLANES/g,t.numClippingPlanes-t.numClipIntersection)}var $g=/^[ \t]*#include +<([\w\d./]+)>/gm;function Qo(i){return i.replace($g,Kg)}var jg=new Map([["encodings_fragment","colorspace_fragment"],["encodings_pars_fragment","colorspace_pars_fragment"],["output_fragment","opaque_fragment"]]);function Kg(i,t){let e=te[t];if(e===void 0){let n=jg.get(t);if(n!==void 0)e=te[n],console.warn('THREE.WebGLRenderer: Shader chunk "%s" has been deprecated. Use "%s" instead.',t,n);else throw new Error("Can not resolve #include <"+t+">")}return Qo(e)}var Qg=/#pragma unroll_loop_start\s+for\s*\(\s*int\s+i\s*=\s*(\d+)\s*;\s*i\s*<\s*(\d+)\s*;\s*i\s*\+\+\s*\)\s*{([\s\S]+?)}\s+#pragma unroll_loop_end/g;function yh(i){return i.replace(Qg,t0)}function t0(i,t,e,n){let s="";for(let r=parseInt(t);r<parseInt(e);r++)s+=n.replace(/\[\s*i\s*\]/g,"[ "+r+" ]").replace(/UNROLLED_LOOP_INDEX/g,r);return s}function Mh(i){let t="precision "+i.precision+` float;
precision `+i.precision+" int;";return i.precision==="highp"?t+=`
#define HIGH_PRECISION`:i.precision==="mediump"?t+=`
#define MEDIUM_PRECISION`:i.precision==="lowp"&&(t+=`
#define LOW_PRECISION`),t}function e0(i){let t="SHADOWMAP_TYPE_BASIC";return i.shadowMapType===Uh?t="SHADOWMAP_TYPE_PCF":i.shadowMapType===Ml?t="SHADOWMAP_TYPE_PCF_SOFT":i.shadowMapType===ei&&(t="SHADOWMAP_TYPE_VSM"),t}function n0(i){let t="ENVMAP_TYPE_CUBE";if(i.envMap)switch(i.envMapMode){case Ps:case Ls:t="ENVMAP_TYPE_CUBE";break;case Na:t="ENVMAP_TYPE_CUBE_UV";break}return t}function i0(i){let t="ENVMAP_MODE_REFLECTION";return i.envMap&&i.envMapMode===Ls&&(t="ENVMAP_MODE_REFRACTION"),t}function s0(i){let t="ENVMAP_BLENDING_NONE";if(i.envMap)switch(i.combine){case Nh:t="ENVMAP_BLENDING_MULTIPLY";break;case Qu:t="ENVMAP_BLENDING_MIX";break;case td:t="ENVMAP_BLENDING_ADD";break}return t}function r0(i){let t=i.envMapCubeUVHeight;if(t===null)return null;let e=Math.log2(t)-2,n=1/t;return{texelWidth:1/(3*Math.max(Math.pow(2,e),112)),texelHeight:n,maxMip:e}}function a0(i,t,e,n){let s=i.getContext(),r=e.defines,o=e.vertexShader,a=e.fragmentShader,l=e0(e),c=n0(e),u=i0(e),f=s0(e),p=r0(e),x=e.isWebGL2?"":Yg(e),y=qg(e),b=Zg(r),m=s.createProgram(),d,C,w=e.glslVersion?"#version "+e.glslVersion+`
`:"";e.isRawShaderMaterial?(d=["#define SHADER_TYPE "+e.shaderType,"#define SHADER_NAME "+e.shaderName,b].filter(Ts).join(`
`),d.length>0&&(d+=`
`),C=[x,"#define SHADER_TYPE "+e.shaderType,"#define SHADER_NAME "+e.shaderName,b].filter(Ts).join(`
`),C.length>0&&(C+=`
`)):(d=[Mh(e),"#define SHADER_TYPE "+e.shaderType,"#define SHADER_NAME "+e.shaderName,b,e.extensionClipCullDistance?"#define USE_CLIP_DISTANCE":"",e.batching?"#define USE_BATCHING":"",e.instancing?"#define USE_INSTANCING":"",e.instancingColor?"#define USE_INSTANCING_COLOR":"",e.useFog&&e.fog?"#define USE_FOG":"",e.useFog&&e.fogExp2?"#define FOG_EXP2":"",e.map?"#define USE_MAP":"",e.envMap?"#define USE_ENVMAP":"",e.envMap?"#define "+u:"",e.lightMap?"#define USE_LIGHTMAP":"",e.aoMap?"#define USE_AOMAP":"",e.bumpMap?"#define USE_BUMPMAP":"",e.normalMap?"#define USE_NORMALMAP":"",e.normalMapObjectSpace?"#define USE_NORMALMAP_OBJECTSPACE":"",e.normalMapTangentSpace?"#define USE_NORMALMAP_TANGENTSPACE":"",e.displacementMap?"#define USE_DISPLACEMENTMAP":"",e.emissiveMap?"#define USE_EMISSIVEMAP":"",e.anisotropy?"#define USE_ANISOTROPY":"",e.anisotropyMap?"#define USE_ANISOTROPYMAP":"",e.clearcoatMap?"#define USE_CLEARCOATMAP":"",e.clearcoatRoughnessMap?"#define USE_CLEARCOAT_ROUGHNESSMAP":"",e.clearcoatNormalMap?"#define USE_CLEARCOAT_NORMALMAP":"",e.iridescenceMap?"#define USE_IRIDESCENCEMAP":"",e.iridescenceThicknessMap?"#define USE_IRIDESCENCE_THICKNESSMAP":"",e.specularMap?"#define USE_SPECULARMAP":"",e.specularColorMap?"#define USE_SPECULAR_COLORMAP":"",e.specularIntensityMap?"#define USE_SPECULAR_INTENSITYMAP":"",e.roughnessMap?"#define USE_ROUGHNESSMAP":"",e.metalnessMap?"#define USE_METALNESSMAP":"",e.alphaMap?"#define USE_ALPHAMAP":"",e.alphaHash?"#define USE_ALPHAHASH":"",e.transmission?"#define USE_TRANSMISSION":"",e.transmissionMap?"#define USE_TRANSMISSIONMAP":"",e.thicknessMap?"#define USE_THICKNESSMAP":"",e.sheenColorMap?"#define USE_SHEEN_COLORMAP":"",e.sheenRoughnessMap?"#define USE_SHEEN_ROUGHNESSMAP":"",e.mapUv?"#define MAP_UV "+e.mapUv:"",e.alphaMapUv?"#define ALPHAMAP_UV "+e.alphaMapUv:"",e.lightMapUv?"#define LIGHTMAP_UV "+e.lightMapUv:"",e.aoMapUv?"#define AOMAP_UV "+e.aoMapUv:"",e.emissiveMapUv?"#define EMISSIVEMAP_UV "+e.emissiveMapUv:"",e.bumpMapUv?"#define BUMPMAP_UV "+e.bumpMapUv:"",e.normalMapUv?"#define NORMALMAP_UV "+e.normalMapUv:"",e.displacementMapUv?"#define DISPLACEMENTMAP_UV "+e.displacementMapUv:"",e.metalnessMapUv?"#define METALNESSMAP_UV "+e.metalnessMapUv:"",e.roughnessMapUv?"#define ROUGHNESSMAP_UV "+e.roughnessMapUv:"",e.anisotropyMapUv?"#define ANISOTROPYMAP_UV "+e.anisotropyMapUv:"",e.clearcoatMapUv?"#define CLEARCOATMAP_UV "+e.clearcoatMapUv:"",e.clearcoatNormalMapUv?"#define CLEARCOAT_NORMALMAP_UV "+e.clearcoatNormalMapUv:"",e.clearcoatRoughnessMapUv?"#define CLEARCOAT_ROUGHNESSMAP_UV "+e.clearcoatRoughnessMapUv:"",e.iridescenceMapUv?"#define IRIDESCENCEMAP_UV "+e.iridescenceMapUv:"",e.iridescenceThicknessMapUv?"#define IRIDESCENCE_THICKNESSMAP_UV "+e.iridescenceThicknessMapUv:"",e.sheenColorMapUv?"#define SHEEN_COLORMAP_UV "+e.sheenColorMapUv:"",e.sheenRoughnessMapUv?"#define SHEEN_ROUGHNESSMAP_UV "+e.sheenRoughnessMapUv:"",e.specularMapUv?"#define SPECULARMAP_UV "+e.specularMapUv:"",e.specularColorMapUv?"#define SPECULAR_COLORMAP_UV "+e.specularColorMapUv:"",e.specularIntensityMapUv?"#define SPECULAR_INTENSITYMAP_UV "+e.specularIntensityMapUv:"",e.transmissionMapUv?"#define TRANSMISSIONMAP_UV "+e.transmissionMapUv:"",e.thicknessMapUv?"#define THICKNESSMAP_UV "+e.thicknessMapUv:"",e.vertexTangents&&e.flatShading===!1?"#define USE_TANGENT":"",e.vertexColors?"#define USE_COLOR":"",e.vertexAlphas?"#define USE_COLOR_ALPHA":"",e.vertexUv1s?"#define USE_UV1":"",e.vertexUv2s?"#define USE_UV2":"",e.vertexUv3s?"#define USE_UV3":"",e.pointsUvs?"#define USE_POINTS_UV":"",e.flatShading?"#define FLAT_SHADED":"",e.skinning?"#define USE_SKINNING":"",e.morphTargets?"#define USE_MORPHTARGETS":"",e.morphNormals&&e.flatShading===!1?"#define USE_MORPHNORMALS":"",e.morphColors&&e.isWebGL2?"#define USE_MORPHCOLORS":"",e.morphTargetsCount>0&&e.isWebGL2?"#define MORPHTARGETS_TEXTURE":"",e.morphTargetsCount>0&&e.isWebGL2?"#define MORPHTARGETS_TEXTURE_STRIDE "+e.morphTextureStride:"",e.morphTargetsCount>0&&e.isWebGL2?"#define MORPHTARGETS_COUNT "+e.morphTargetsCount:"",e.doubleSided?"#define DOUBLE_SIDED":"",e.flipSided?"#define FLIP_SIDED":"",e.shadowMapEnabled?"#define USE_SHADOWMAP":"",e.shadowMapEnabled?"#define "+l:"",e.sizeAttenuation?"#define USE_SIZEATTENUATION":"",e.numLightProbes>0?"#define USE_LIGHT_PROBES":"",e.useLegacyLights?"#define LEGACY_LIGHTS":"",e.logarithmicDepthBuffer?"#define USE_LOGDEPTHBUF":"",e.logarithmicDepthBuffer&&e.rendererExtensionFragDepth?"#define USE_LOGDEPTHBUF_EXT":"","uniform mat4 modelMatrix;","uniform mat4 modelViewMatrix;","uniform mat4 projectionMatrix;","uniform mat4 viewMatrix;","uniform mat3 normalMatrix;","uniform vec3 cameraPosition;","uniform bool isOrthographic;","#ifdef USE_INSTANCING","	attribute mat4 instanceMatrix;","#endif","#ifdef USE_INSTANCING_COLOR","	attribute vec3 instanceColor;","#endif","attribute vec3 position;","attribute vec3 normal;","attribute vec2 uv;","#ifdef USE_UV1","	attribute vec2 uv1;","#endif","#ifdef USE_UV2","	attribute vec2 uv2;","#endif","#ifdef USE_UV3","	attribute vec2 uv3;","#endif","#ifdef USE_TANGENT","	attribute vec4 tangent;","#endif","#if defined( USE_COLOR_ALPHA )","	attribute vec4 color;","#elif defined( USE_COLOR )","	attribute vec3 color;","#endif","#if ( defined( USE_MORPHTARGETS ) && ! defined( MORPHTARGETS_TEXTURE ) )","	attribute vec3 morphTarget0;","	attribute vec3 morphTarget1;","	attribute vec3 morphTarget2;","	attribute vec3 morphTarget3;","	#ifdef USE_MORPHNORMALS","		attribute vec3 morphNormal0;","		attribute vec3 morphNormal1;","		attribute vec3 morphNormal2;","		attribute vec3 morphNormal3;","	#else","		attribute vec3 morphTarget4;","		attribute vec3 morphTarget5;","		attribute vec3 morphTarget6;","		attribute vec3 morphTarget7;","	#endif","#endif","#ifdef USE_SKINNING","	attribute vec4 skinIndex;","	attribute vec4 skinWeight;","#endif",`
`].filter(Ts).join(`
`),C=[x,Mh(e),"#define SHADER_TYPE "+e.shaderType,"#define SHADER_NAME "+e.shaderName,b,e.useFog&&e.fog?"#define USE_FOG":"",e.useFog&&e.fogExp2?"#define FOG_EXP2":"",e.map?"#define USE_MAP":"",e.matcap?"#define USE_MATCAP":"",e.envMap?"#define USE_ENVMAP":"",e.envMap?"#define "+c:"",e.envMap?"#define "+u:"",e.envMap?"#define "+f:"",p?"#define CUBEUV_TEXEL_WIDTH "+p.texelWidth:"",p?"#define CUBEUV_TEXEL_HEIGHT "+p.texelHeight:"",p?"#define CUBEUV_MAX_MIP "+p.maxMip+".0":"",e.lightMap?"#define USE_LIGHTMAP":"",e.aoMap?"#define USE_AOMAP":"",e.bumpMap?"#define USE_BUMPMAP":"",e.normalMap?"#define USE_NORMALMAP":"",e.normalMapObjectSpace?"#define USE_NORMALMAP_OBJECTSPACE":"",e.normalMapTangentSpace?"#define USE_NORMALMAP_TANGENTSPACE":"",e.emissiveMap?"#define USE_EMISSIVEMAP":"",e.anisotropy?"#define USE_ANISOTROPY":"",e.anisotropyMap?"#define USE_ANISOTROPYMAP":"",e.clearcoat?"#define USE_CLEARCOAT":"",e.clearcoatMap?"#define USE_CLEARCOATMAP":"",e.clearcoatRoughnessMap?"#define USE_CLEARCOAT_ROUGHNESSMAP":"",e.clearcoatNormalMap?"#define USE_CLEARCOAT_NORMALMAP":"",e.iridescence?"#define USE_IRIDESCENCE":"",e.iridescenceMap?"#define USE_IRIDESCENCEMAP":"",e.iridescenceThicknessMap?"#define USE_IRIDESCENCE_THICKNESSMAP":"",e.specularMap?"#define USE_SPECULARMAP":"",e.specularColorMap?"#define USE_SPECULAR_COLORMAP":"",e.specularIntensityMap?"#define USE_SPECULAR_INTENSITYMAP":"",e.roughnessMap?"#define USE_ROUGHNESSMAP":"",e.metalnessMap?"#define USE_METALNESSMAP":"",e.alphaMap?"#define USE_ALPHAMAP":"",e.alphaTest?"#define USE_ALPHATEST":"",e.alphaHash?"#define USE_ALPHAHASH":"",e.sheen?"#define USE_SHEEN":"",e.sheenColorMap?"#define USE_SHEEN_COLORMAP":"",e.sheenRoughnessMap?"#define USE_SHEEN_ROUGHNESSMAP":"",e.transmission?"#define USE_TRANSMISSION":"",e.transmissionMap?"#define USE_TRANSMISSIONMAP":"",e.thicknessMap?"#define USE_THICKNESSMAP":"",e.vertexTangents&&e.flatShading===!1?"#define USE_TANGENT":"",e.vertexColors||e.instancingColor?"#define USE_COLOR":"",e.vertexAlphas?"#define USE_COLOR_ALPHA":"",e.vertexUv1s?"#define USE_UV1":"",e.vertexUv2s?"#define USE_UV2":"",e.vertexUv3s?"#define USE_UV3":"",e.pointsUvs?"#define USE_POINTS_UV":"",e.gradientMap?"#define USE_GRADIENTMAP":"",e.flatShading?"#define FLAT_SHADED":"",e.doubleSided?"#define DOUBLE_SIDED":"",e.flipSided?"#define FLIP_SIDED":"",e.shadowMapEnabled?"#define USE_SHADOWMAP":"",e.shadowMapEnabled?"#define "+l:"",e.premultipliedAlpha?"#define PREMULTIPLIED_ALPHA":"",e.numLightProbes>0?"#define USE_LIGHT_PROBES":"",e.useLegacyLights?"#define LEGACY_LIGHTS":"",e.decodeVideoTexture?"#define DECODE_VIDEO_TEXTURE":"",e.logarithmicDepthBuffer?"#define USE_LOGDEPTHBUF":"",e.logarithmicDepthBuffer&&e.rendererExtensionFragDepth?"#define USE_LOGDEPTHBUF_EXT":"","uniform mat4 viewMatrix;","uniform vec3 cameraPosition;","uniform bool isOrthographic;",e.toneMapping!==vi?"#define TONE_MAPPING":"",e.toneMapping!==vi?te.tonemapping_pars_fragment:"",e.toneMapping!==vi?Xg("toneMapping",e.toneMapping):"",e.dithering?"#define DITHERING":"",e.opaque?"#define OPAQUE":"",te.colorspace_pars_fragment,Wg("linearToOutputTexel",e.outputColorSpace),e.useDepthPacking?"#define DEPTH_PACKING "+e.depthPacking:"",`
`].filter(Ts).join(`
`)),o=Qo(o),o=_h(o,e),o=vh(o,e),a=Qo(a),a=_h(a,e),a=vh(a,e),o=yh(o),a=yh(a),e.isWebGL2&&e.isRawShaderMaterial!==!0&&(w=`#version 300 es
`,d=[y,"precision mediump sampler2DArray;","#define attribute in","#define varying out","#define texture2D texture"].join(`
`)+`
`+d,C=["precision mediump sampler2DArray;","#define varying in",e.glslVersion===kc?"":"layout(location = 0) out highp vec4 pc_fragColor;",e.glslVersion===kc?"":"#define gl_FragColor pc_fragColor","#define gl_FragDepthEXT gl_FragDepth","#define texture2D texture","#define textureCube texture","#define texture2DProj textureProj","#define texture2DLodEXT textureLod","#define texture2DProjLodEXT textureProjLod","#define textureCubeLodEXT textureLod","#define texture2DGradEXT textureGrad","#define texture2DProjGradEXT textureProjGrad","#define textureCubeGradEXT textureGrad"].join(`
`)+`
`+C);let U=w+d+o,z=w+C+a,N=gh(s,s.VERTEX_SHADER,U),L=gh(s,s.FRAGMENT_SHADER,z);s.attachShader(m,N),s.attachShader(m,L),e.index0AttributeName!==void 0?s.bindAttribLocation(m,0,e.index0AttributeName):e.morphTargets===!0&&s.bindAttribLocation(m,0,"position"),s.linkProgram(m);function j(tt){if(i.debug.checkShaderErrors){let ft=s.getProgramInfoLog(m).trim(),I=s.getShaderInfoLog(N).trim(),k=s.getShaderInfoLog(L).trim(),G=!0,K=!0;if(s.getProgramParameter(m,s.LINK_STATUS)===!1)if(G=!1,typeof i.debug.onShaderError=="function")i.debug.onShaderError(s,m,N,L);else{let Q=xh(s,N,"vertex"),$=xh(s,L,"fragment");console.error("THREE.WebGLProgram: Shader Error "+s.getError()+" - VALIDATE_STATUS "+s.getProgramParameter(m,s.VALIDATE_STATUS)+`

Program Info Log: `+ft+`
`+Q+`
`+$)}else ft!==""?console.warn("THREE.WebGLProgram: Program Info Log:",ft):(I===""||k==="")&&(K=!1);K&&(tt.diagnostics={runnable:G,programLog:ft,vertexShader:{log:I,prefix:d},fragmentShader:{log:k,prefix:C}})}s.deleteShader(N),s.deleteShader(L),S=new Cs(s,m),R=Jg(s,m)}let S;this.getUniforms=function(){return S===void 0&&j(this),S};let R;this.getAttributes=function(){return R===void 0&&j(this),R};let V=e.rendererExtensionParallelShaderCompile===!1;return this.isReady=function(){return V===!1&&(V=s.getProgramParameter(m,kg)),V},this.destroy=function(){n.releaseStatesOfProgram(this),s.deleteProgram(m),this.program=void 0},this.type=e.shaderType,this.name=e.shaderName,this.id=Hg++,this.cacheKey=t,this.usedTimes=1,this.program=m,this.vertexShader=N,this.fragmentShader=L,this}var o0=0,tl=class{constructor(){this.shaderCache=new Map,this.materialCache=new Map}update(t){let e=t.vertexShader,n=t.fragmentShader,s=this._getShaderStage(e),r=this._getShaderStage(n),o=this._getShaderCacheForMaterial(t);return o.has(s)===!1&&(o.add(s),s.usedTimes++),o.has(r)===!1&&(o.add(r),r.usedTimes++),this}remove(t){let e=this.materialCache.get(t);for(let n of e)n.usedTimes--,n.usedTimes===0&&this.shaderCache.delete(n.code);return this.materialCache.delete(t),this}getVertexShaderID(t){return this._getShaderStage(t.vertexShader).id}getFragmentShaderID(t){return this._getShaderStage(t.fragmentShader).id}dispose(){this.shaderCache.clear(),this.materialCache.clear()}_getShaderCacheForMaterial(t){let e=this.materialCache,n=e.get(t);return n===void 0&&(n=new Set,e.set(t,n)),n}_getShaderStage(t){let e=this.shaderCache,n=e.get(t);return n===void 0&&(n=new el(t),e.set(t,n)),n}},el=class{constructor(t){this.id=o0++,this.code=t,this.usedTimes=0}};function l0(i,t,e,n,s,r,o){let a=new ur,l=new tl,c=[],u=s.isWebGL2,f=s.logarithmicDepthBuffer,p=s.vertexTextures,x=s.precision,y={MeshDepthMaterial:"depth",MeshDistanceMaterial:"distanceRGBA",MeshNormalMaterial:"normal",MeshBasicMaterial:"basic",MeshLambertMaterial:"lambert",MeshPhongMaterial:"phong",MeshToonMaterial:"toon",MeshStandardMaterial:"physical",MeshPhysicalMaterial:"physical",MeshMatcapMaterial:"matcap",LineBasicMaterial:"basic",LineDashedMaterial:"dashed",PointsMaterial:"points",ShadowMaterial:"shadow",SpriteMaterial:"sprite"};function b(S){return S===0?"uv":`uv${S}`}function m(S,R,V,tt,ft){let I=tt.fog,k=ft.geometry,G=S.isMeshStandardMaterial?tt.environment:null,K=(S.isMeshStandardMaterial?e:t).get(S.envMap||G),Q=K&&K.mapping===Na?K.image.height:null,$=y[S.type];S.precision!==null&&(x=s.getMaxPrecision(S.precision),x!==S.precision&&console.warn("THREE.WebGLProgram.getParameters:",S.precision,"not supported, using",x,"instead."));let nt=k.morphAttributes.position||k.morphAttributes.normal||k.morphAttributes.color,ct=nt!==void 0?nt.length:0,bt=0;k.morphAttributes.position!==void 0&&(bt=1),k.morphAttributes.normal!==void 0&&(bt=2),k.morphAttributes.color!==void 0&&(bt=3);let J,ot,vt,Lt;if($){let _e=Gn[$];J=_e.vertexShader,ot=_e.fragmentShader}else J=S.vertexShader,ot=S.fragmentShader,l.update(S),vt=l.getVertexShaderID(S),Lt=l.getFragmentShaderID(S);let Nt=i.getRenderTarget(),Ct=ft.isInstancedMesh===!0,It=ft.isBatchedMesh===!0,Tt=!!S.map,kt=!!S.matcap,W=!!K,Pe=!!S.aoMap,Dt=!!S.lightMap,Gt=!!S.bumpMap,Rt=!!S.normalMap,me=!!S.displacementMap,$t=!!S.emissiveMap,A=!!S.metalnessMap,M=!!S.roughnessMap,X=S.anisotropy>0,ut=S.clearcoat>0,lt=S.iridescence>0,st=S.sheen>0,Et=S.transmission>0,Mt=X&&!!S.anisotropyMap,ht=ut&&!!S.clearcoatMap,Ot=ut&&!!S.clearcoatNormalMap,Yt=ut&&!!S.clearcoatRoughnessMap,at=lt&&!!S.iridescenceMap,se=lt&&!!S.iridescenceThicknessMap,P=st&&!!S.sheenColorMap,rt=st&&!!S.sheenRoughnessMap,mt=!!S.specularMap,pt=!!S.specularColorMap,Ut=!!S.specularIntensityMap,Qt=Et&&!!S.transmissionMap,ee=Et&&!!S.thicknessMap,Kt=!!S.gradientMap,_t=!!S.alphaMap,O=S.alphaTest>0,gt=!!S.alphaHash,xt=!!S.extensions,Ht=!!k.attributes.uv1,Ft=!!k.attributes.uv2,ce=!!k.attributes.uv3,ne=vi;return S.toneMapped&&(Nt===null||Nt.isXRRenderTarget===!0)&&(ne=i.toneMapping),{isWebGL2:u,shaderID:$,shaderType:S.type,shaderName:S.name,vertexShader:J,fragmentShader:ot,defines:S.defines,customVertexShaderID:vt,customFragmentShaderID:Lt,isRawShaderMaterial:S.isRawShaderMaterial===!0,glslVersion:S.glslVersion,precision:x,batching:It,instancing:Ct,instancingColor:Ct&&ft.instanceColor!==null,supportsVertexTextures:p,outputColorSpace:Nt===null?i.outputColorSpace:Nt.isXRRenderTarget===!0?Nt.texture.colorSpace:si,map:Tt,matcap:kt,envMap:W,envMapMode:W&&K.mapping,envMapCubeUVHeight:Q,aoMap:Pe,lightMap:Dt,bumpMap:Gt,normalMap:Rt,displacementMap:p&&me,emissiveMap:$t,normalMapObjectSpace:Rt&&S.normalMapType===fd,normalMapTangentSpace:Rt&&S.normalMapType===Xh,metalnessMap:A,roughnessMap:M,anisotropy:X,anisotropyMap:Mt,clearcoat:ut,clearcoatMap:ht,clearcoatNormalMap:Ot,clearcoatRoughnessMap:Yt,iridescence:lt,iridescenceMap:at,iridescenceThicknessMap:se,sheen:st,sheenColorMap:P,sheenRoughnessMap:rt,specularMap:mt,specularColorMap:pt,specularIntensityMap:Ut,transmission:Et,transmissionMap:Qt,thicknessMap:ee,gradientMap:Kt,opaque:S.transparent===!1&&S.blending===ii,alphaMap:_t,alphaTest:O,alphaHash:gt,combine:S.combine,mapUv:Tt&&b(S.map.channel),aoMapUv:Pe&&b(S.aoMap.channel),lightMapUv:Dt&&b(S.lightMap.channel),bumpMapUv:Gt&&b(S.bumpMap.channel),normalMapUv:Rt&&b(S.normalMap.channel),displacementMapUv:me&&b(S.displacementMap.channel),emissiveMapUv:$t&&b(S.emissiveMap.channel),metalnessMapUv:A&&b(S.metalnessMap.channel),roughnessMapUv:M&&b(S.roughnessMap.channel),anisotropyMapUv:Mt&&b(S.anisotropyMap.channel),clearcoatMapUv:ht&&b(S.clearcoatMap.channel),clearcoatNormalMapUv:Ot&&b(S.clearcoatNormalMap.channel),clearcoatRoughnessMapUv:Yt&&b(S.clearcoatRoughnessMap.channel),iridescenceMapUv:at&&b(S.iridescenceMap.channel),iridescenceThicknessMapUv:se&&b(S.iridescenceThicknessMap.channel),sheenColorMapUv:P&&b(S.sheenColorMap.channel),sheenRoughnessMapUv:rt&&b(S.sheenRoughnessMap.channel),specularMapUv:mt&&b(S.specularMap.channel),specularColorMapUv:pt&&b(S.specularColorMap.channel),specularIntensityMapUv:Ut&&b(S.specularIntensityMap.channel),transmissionMapUv:Qt&&b(S.transmissionMap.channel),thicknessMapUv:ee&&b(S.thicknessMap.channel),alphaMapUv:_t&&b(S.alphaMap.channel),vertexTangents:!!k.attributes.tangent&&(Rt||X),vertexColors:S.vertexColors,vertexAlphas:S.vertexColors===!0&&!!k.attributes.color&&k.attributes.color.itemSize===4,vertexUv1s:Ht,vertexUv2s:Ft,vertexUv3s:ce,pointsUvs:ft.isPoints===!0&&!!k.attributes.uv&&(Tt||_t),fog:!!I,useFog:S.fog===!0,fogExp2:I&&I.isFogExp2,flatShading:S.flatShading===!0,sizeAttenuation:S.sizeAttenuation===!0,logarithmicDepthBuffer:f,skinning:ft.isSkinnedMesh===!0,morphTargets:k.morphAttributes.position!==void 0,morphNormals:k.morphAttributes.normal!==void 0,morphColors:k.morphAttributes.color!==void 0,morphTargetsCount:ct,morphTextureStride:bt,numDirLights:R.directional.length,numPointLights:R.point.length,numSpotLights:R.spot.length,numSpotLightMaps:R.spotLightMap.length,numRectAreaLights:R.rectArea.length,numHemiLights:R.hemi.length,numDirLightShadows:R.directionalShadowMap.length,numPointLightShadows:R.pointShadowMap.length,numSpotLightShadows:R.spotShadowMap.length,numSpotLightShadowsWithMaps:R.numSpotLightShadowsWithMaps,numLightProbes:R.numLightProbes,numClippingPlanes:o.numPlanes,numClipIntersection:o.numIntersection,dithering:S.dithering,shadowMapEnabled:i.shadowMap.enabled&&V.length>0,shadowMapType:i.shadowMap.type,toneMapping:ne,useLegacyLights:i._useLegacyLights,decodeVideoTexture:Tt&&S.map.isVideoTexture===!0&&fe.getTransfer(S.map.colorSpace)===ge,premultipliedAlpha:S.premultipliedAlpha,doubleSided:S.side===In,flipSided:S.side===nn,useDepthPacking:S.depthPacking>=0,depthPacking:S.depthPacking||0,index0AttributeName:S.index0AttributeName,extensionDerivatives:xt&&S.extensions.derivatives===!0,extensionFragDepth:xt&&S.extensions.fragDepth===!0,extensionDrawBuffers:xt&&S.extensions.drawBuffers===!0,extensionShaderTextureLOD:xt&&S.extensions.shaderTextureLOD===!0,extensionClipCullDistance:xt&&S.extensions.clipCullDistance&&n.has("WEBGL_clip_cull_distance"),rendererExtensionFragDepth:u||n.has("EXT_frag_depth"),rendererExtensionDrawBuffers:u||n.has("WEBGL_draw_buffers"),rendererExtensionShaderTextureLod:u||n.has("EXT_shader_texture_lod"),rendererExtensionParallelShaderCompile:n.has("KHR_parallel_shader_compile"),customProgramCacheKey:S.customProgramCacheKey()}}function d(S){let R=[];if(S.shaderID?R.push(S.shaderID):(R.push(S.customVertexShaderID),R.push(S.customFragmentShaderID)),S.defines!==void 0)for(let V in S.defines)R.push(V),R.push(S.defines[V]);return S.isRawShaderMaterial===!1&&(C(R,S),w(R,S),R.push(i.outputColorSpace)),R.push(S.customProgramCacheKey),R.join()}function C(S,R){S.push(R.precision),S.push(R.outputColorSpace),S.push(R.envMapMode),S.push(R.envMapCubeUVHeight),S.push(R.mapUv),S.push(R.alphaMapUv),S.push(R.lightMapUv),S.push(R.aoMapUv),S.push(R.bumpMapUv),S.push(R.normalMapUv),S.push(R.displacementMapUv),S.push(R.emissiveMapUv),S.push(R.metalnessMapUv),S.push(R.roughnessMapUv),S.push(R.anisotropyMapUv),S.push(R.clearcoatMapUv),S.push(R.clearcoatNormalMapUv),S.push(R.clearcoatRoughnessMapUv),S.push(R.iridescenceMapUv),S.push(R.iridescenceThicknessMapUv),S.push(R.sheenColorMapUv),S.push(R.sheenRoughnessMapUv),S.push(R.specularMapUv),S.push(R.specularColorMapUv),S.push(R.specularIntensityMapUv),S.push(R.transmissionMapUv),S.push(R.thicknessMapUv),S.push(R.combine),S.push(R.fogExp2),S.push(R.sizeAttenuation),S.push(R.morphTargetsCount),S.push(R.morphAttributeCount),S.push(R.numDirLights),S.push(R.numPointLights),S.push(R.numSpotLights),S.push(R.numSpotLightMaps),S.push(R.numHemiLights),S.push(R.numRectAreaLights),S.push(R.numDirLightShadows),S.push(R.numPointLightShadows),S.push(R.numSpotLightShadows),S.push(R.numSpotLightShadowsWithMaps),S.push(R.numLightProbes),S.push(R.shadowMapType),S.push(R.toneMapping),S.push(R.numClippingPlanes),S.push(R.numClipIntersection),S.push(R.depthPacking)}function w(S,R){a.disableAll(),R.isWebGL2&&a.enable(0),R.supportsVertexTextures&&a.enable(1),R.instancing&&a.enable(2),R.instancingColor&&a.enable(3),R.matcap&&a.enable(4),R.envMap&&a.enable(5),R.normalMapObjectSpace&&a.enable(6),R.normalMapTangentSpace&&a.enable(7),R.clearcoat&&a.enable(8),R.iridescence&&a.enable(9),R.alphaTest&&a.enable(10),R.vertexColors&&a.enable(11),R.vertexAlphas&&a.enable(12),R.vertexUv1s&&a.enable(13),R.vertexUv2s&&a.enable(14),R.vertexUv3s&&a.enable(15),R.vertexTangents&&a.enable(16),R.anisotropy&&a.enable(17),R.alphaHash&&a.enable(18),R.batching&&a.enable(19),S.push(a.mask),a.disableAll(),R.fog&&a.enable(0),R.useFog&&a.enable(1),R.flatShading&&a.enable(2),R.logarithmicDepthBuffer&&a.enable(3),R.skinning&&a.enable(4),R.morphTargets&&a.enable(5),R.morphNormals&&a.enable(6),R.morphColors&&a.enable(7),R.premultipliedAlpha&&a.enable(8),R.shadowMapEnabled&&a.enable(9),R.useLegacyLights&&a.enable(10),R.doubleSided&&a.enable(11),R.flipSided&&a.enable(12),R.useDepthPacking&&a.enable(13),R.dithering&&a.enable(14),R.transmission&&a.enable(15),R.sheen&&a.enable(16),R.opaque&&a.enable(17),R.pointsUvs&&a.enable(18),R.decodeVideoTexture&&a.enable(19),S.push(a.mask)}function U(S){let R=y[S.type],V;if(R){let tt=Gn[R];V=wi.clone(tt.uniforms)}else V=S.uniforms;return V}function z(S,R){let V;for(let tt=0,ft=c.length;tt<ft;tt++){let I=c[tt];if(I.cacheKey===R){V=I,++V.usedTimes;break}}return V===void 0&&(V=new a0(i,R,S,r),c.push(V)),V}function N(S){if(--S.usedTimes===0){let R=c.indexOf(S);c[R]=c[c.length-1],c.pop(),S.destroy()}}function L(S){l.remove(S)}function j(){l.dispose()}return{getParameters:m,getProgramCacheKey:d,getUniforms:U,acquireProgram:z,releaseProgram:N,releaseShaderCache:L,programs:c,dispose:j}}function c0(){let i=new WeakMap;function t(r){let o=i.get(r);return o===void 0&&(o={},i.set(r,o)),o}function e(r){i.delete(r)}function n(r,o,a){i.get(r)[o]=a}function s(){i=new WeakMap}return{get:t,remove:e,update:n,dispose:s}}function h0(i,t){return i.groupOrder!==t.groupOrder?i.groupOrder-t.groupOrder:i.renderOrder!==t.renderOrder?i.renderOrder-t.renderOrder:i.material.id!==t.material.id?i.material.id-t.material.id:i.z!==t.z?i.z-t.z:i.id-t.id}function bh(i,t){return i.groupOrder!==t.groupOrder?i.groupOrder-t.groupOrder:i.renderOrder!==t.renderOrder?i.renderOrder-t.renderOrder:i.z!==t.z?t.z-i.z:i.id-t.id}function Sh(){let i=[],t=0,e=[],n=[],s=[];function r(){t=0,e.length=0,n.length=0,s.length=0}function o(f,p,x,y,b,m){let d=i[t];return d===void 0?(d={id:f.id,object:f,geometry:p,material:x,groupOrder:y,renderOrder:f.renderOrder,z:b,group:m},i[t]=d):(d.id=f.id,d.object=f,d.geometry=p,d.material=x,d.groupOrder=y,d.renderOrder=f.renderOrder,d.z=b,d.group=m),t++,d}function a(f,p,x,y,b,m){let d=o(f,p,x,y,b,m);x.transmission>0?n.push(d):x.transparent===!0?s.push(d):e.push(d)}function l(f,p,x,y,b,m){let d=o(f,p,x,y,b,m);x.transmission>0?n.unshift(d):x.transparent===!0?s.unshift(d):e.unshift(d)}function c(f,p){e.length>1&&e.sort(f||h0),n.length>1&&n.sort(p||bh),s.length>1&&s.sort(p||bh)}function u(){for(let f=t,p=i.length;f<p;f++){let x=i[f];if(x.id===null)break;x.id=null,x.object=null,x.geometry=null,x.material=null,x.group=null}}return{opaque:e,transmissive:n,transparent:s,init:r,push:a,unshift:l,finish:u,sort:c}}function u0(){let i=new WeakMap;function t(n,s){let r=i.get(n),o;return r===void 0?(o=new Sh,i.set(n,[o])):s>=r.length?(o=new Sh,r.push(o)):o=r[s],o}function e(){i=new WeakMap}return{get:t,dispose:e}}function d0(){let i={};return{get:function(t){if(i[t.id]!==void 0)return i[t.id];let e;switch(t.type){case"DirectionalLight":e={direction:new F,color:new qt};break;case"SpotLight":e={position:new F,direction:new F,color:new qt,distance:0,coneCos:0,penumbraCos:0,decay:0};break;case"PointLight":e={position:new F,color:new qt,distance:0,decay:0};break;case"HemisphereLight":e={direction:new F,skyColor:new qt,groundColor:new qt};break;case"RectAreaLight":e={color:new qt,position:new F,halfWidth:new F,halfHeight:new F};break}return i[t.id]=e,e}}}function f0(){let i={};return{get:function(t){if(i[t.id]!==void 0)return i[t.id];let e;switch(t.type){case"DirectionalLight":e={shadowBias:0,shadowNormalBias:0,shadowRadius:1,shadowMapSize:new Pt};break;case"SpotLight":e={shadowBias:0,shadowNormalBias:0,shadowRadius:1,shadowMapSize:new Pt};break;case"PointLight":e={shadowBias:0,shadowNormalBias:0,shadowRadius:1,shadowMapSize:new Pt,shadowCameraNear:1,shadowCameraFar:1e3};break}return i[t.id]=e,e}}}var p0=0;function m0(i,t){return(t.castShadow?2:0)-(i.castShadow?2:0)+(t.map?1:0)-(i.map?1:0)}function g0(i,t){let e=new d0,n=f0(),s={version:0,hash:{directionalLength:-1,pointLength:-1,spotLength:-1,rectAreaLength:-1,hemiLength:-1,numDirectionalShadows:-1,numPointShadows:-1,numSpotShadows:-1,numSpotMaps:-1,numLightProbes:-1},ambient:[0,0,0],probe:[],directional:[],directionalShadow:[],directionalShadowMap:[],directionalShadowMatrix:[],spot:[],spotLightMap:[],spotShadow:[],spotShadowMap:[],spotLightMatrix:[],rectArea:[],rectAreaLTC1:null,rectAreaLTC2:null,point:[],pointShadow:[],pointShadowMap:[],pointShadowMatrix:[],hemi:[],numSpotLightShadowsWithMaps:0,numLightProbes:0};for(let u=0;u<9;u++)s.probe.push(new F);let r=new F,o=new ve,a=new ve;function l(u,f){let p=0,x=0,y=0;for(let tt=0;tt<9;tt++)s.probe[tt].set(0,0,0);let b=0,m=0,d=0,C=0,w=0,U=0,z=0,N=0,L=0,j=0,S=0;u.sort(m0);let R=f===!0?Math.PI:1;for(let tt=0,ft=u.length;tt<ft;tt++){let I=u[tt],k=I.color,G=I.intensity,K=I.distance,Q=I.shadow&&I.shadow.map?I.shadow.map.texture:null;if(I.isAmbientLight)p+=k.r*G*R,x+=k.g*G*R,y+=k.b*G*R;else if(I.isLightProbe){for(let $=0;$<9;$++)s.probe[$].addScaledVector(I.sh.coefficients[$],G);S++}else if(I.isDirectionalLight){let $=e.get(I);if($.color.copy(I.color).multiplyScalar(I.intensity*R),I.castShadow){let nt=I.shadow,ct=n.get(I);ct.shadowBias=nt.bias,ct.shadowNormalBias=nt.normalBias,ct.shadowRadius=nt.radius,ct.shadowMapSize=nt.mapSize,s.directionalShadow[b]=ct,s.directionalShadowMap[b]=Q,s.directionalShadowMatrix[b]=I.shadow.matrix,U++}s.directional[b]=$,b++}else if(I.isSpotLight){let $=e.get(I);$.position.setFromMatrixPosition(I.matrixWorld),$.color.copy(k).multiplyScalar(G*R),$.distance=K,$.coneCos=Math.cos(I.angle),$.penumbraCos=Math.cos(I.angle*(1-I.penumbra)),$.decay=I.decay,s.spot[d]=$;let nt=I.shadow;if(I.map&&(s.spotLightMap[L]=I.map,L++,nt.updateMatrices(I),I.castShadow&&j++),s.spotLightMatrix[d]=nt.matrix,I.castShadow){let ct=n.get(I);ct.shadowBias=nt.bias,ct.shadowNormalBias=nt.normalBias,ct.shadowRadius=nt.radius,ct.shadowMapSize=nt.mapSize,s.spotShadow[d]=ct,s.spotShadowMap[d]=Q,N++}d++}else if(I.isRectAreaLight){let $=e.get(I);$.color.copy(k).multiplyScalar(G),$.halfWidth.set(I.width*.5,0,0),$.halfHeight.set(0,I.height*.5,0),s.rectArea[C]=$,C++}else if(I.isPointLight){let $=e.get(I);if($.color.copy(I.color).multiplyScalar(I.intensity*R),$.distance=I.distance,$.decay=I.decay,I.castShadow){let nt=I.shadow,ct=n.get(I);ct.shadowBias=nt.bias,ct.shadowNormalBias=nt.normalBias,ct.shadowRadius=nt.radius,ct.shadowMapSize=nt.mapSize,ct.shadowCameraNear=nt.camera.near,ct.shadowCameraFar=nt.camera.far,s.pointShadow[m]=ct,s.pointShadowMap[m]=Q,s.pointShadowMatrix[m]=I.shadow.matrix,z++}s.point[m]=$,m++}else if(I.isHemisphereLight){let $=e.get(I);$.skyColor.copy(I.color).multiplyScalar(G*R),$.groundColor.copy(I.groundColor).multiplyScalar(G*R),s.hemi[w]=$,w++}}C>0&&(t.isWebGL2?i.has("OES_texture_float_linear")===!0?(s.rectAreaLTC1=yt.LTC_FLOAT_1,s.rectAreaLTC2=yt.LTC_FLOAT_2):(s.rectAreaLTC1=yt.LTC_HALF_1,s.rectAreaLTC2=yt.LTC_HALF_2):i.has("OES_texture_float_linear")===!0?(s.rectAreaLTC1=yt.LTC_FLOAT_1,s.rectAreaLTC2=yt.LTC_FLOAT_2):i.has("OES_texture_half_float_linear")===!0?(s.rectAreaLTC1=yt.LTC_HALF_1,s.rectAreaLTC2=yt.LTC_HALF_2):console.error("THREE.WebGLRenderer: Unable to use RectAreaLight. Missing WebGL extensions.")),s.ambient[0]=p,s.ambient[1]=x,s.ambient[2]=y;let V=s.hash;(V.directionalLength!==b||V.pointLength!==m||V.spotLength!==d||V.rectAreaLength!==C||V.hemiLength!==w||V.numDirectionalShadows!==U||V.numPointShadows!==z||V.numSpotShadows!==N||V.numSpotMaps!==L||V.numLightProbes!==S)&&(s.directional.length=b,s.spot.length=d,s.rectArea.length=C,s.point.length=m,s.hemi.length=w,s.directionalShadow.length=U,s.directionalShadowMap.length=U,s.pointShadow.length=z,s.pointShadowMap.length=z,s.spotShadow.length=N,s.spotShadowMap.length=N,s.directionalShadowMatrix.length=U,s.pointShadowMatrix.length=z,s.spotLightMatrix.length=N+L-j,s.spotLightMap.length=L,s.numSpotLightShadowsWithMaps=j,s.numLightProbes=S,V.directionalLength=b,V.pointLength=m,V.spotLength=d,V.rectAreaLength=C,V.hemiLength=w,V.numDirectionalShadows=U,V.numPointShadows=z,V.numSpotShadows=N,V.numSpotMaps=L,V.numLightProbes=S,s.version=p0++)}function c(u,f){let p=0,x=0,y=0,b=0,m=0,d=f.matrixWorldInverse;for(let C=0,w=u.length;C<w;C++){let U=u[C];if(U.isDirectionalLight){let z=s.directional[p];z.direction.setFromMatrixPosition(U.matrixWorld),r.setFromMatrixPosition(U.target.matrixWorld),z.direction.sub(r),z.direction.transformDirection(d),p++}else if(U.isSpotLight){let z=s.spot[y];z.position.setFromMatrixPosition(U.matrixWorld),z.position.applyMatrix4(d),z.direction.setFromMatrixPosition(U.matrixWorld),r.setFromMatrixPosition(U.target.matrixWorld),z.direction.sub(r),z.direction.transformDirection(d),y++}else if(U.isRectAreaLight){let z=s.rectArea[b];z.position.setFromMatrixPosition(U.matrixWorld),z.position.applyMatrix4(d),a.identity(),o.copy(U.matrixWorld),o.premultiply(d),a.extractRotation(o),z.halfWidth.set(U.width*.5,0,0),z.halfHeight.set(0,U.height*.5,0),z.halfWidth.applyMatrix4(a),z.halfHeight.applyMatrix4(a),b++}else if(U.isPointLight){let z=s.point[x];z.position.setFromMatrixPosition(U.matrixWorld),z.position.applyMatrix4(d),x++}else if(U.isHemisphereLight){let z=s.hemi[m];z.direction.setFromMatrixPosition(U.matrixWorld),z.direction.transformDirection(d),m++}}}return{setup:l,setupView:c,state:s}}function wh(i,t){let e=new g0(i,t),n=[],s=[];function r(){n.length=0,s.length=0}function o(f){n.push(f)}function a(f){s.push(f)}function l(f){e.setup(n,f)}function c(f){e.setupView(n,f)}return{init:r,state:{lightsArray:n,shadowsArray:s,lights:e},setupLights:l,setupLightsView:c,pushLight:o,pushShadow:a}}function x0(i,t){let e=new WeakMap;function n(r,o=0){let a=e.get(r),l;return a===void 0?(l=new wh(i,t),e.set(r,[l])):o>=a.length?(l=new wh(i,t),a.push(l)):l=a[o],l}function s(){e=new WeakMap}return{get:n,dispose:s}}var nl=class extends Si{constructor(t){super(),this.isMeshDepthMaterial=!0,this.type="MeshDepthMaterial",this.depthPacking=ud,this.map=null,this.alphaMap=null,this.displacementMap=null,this.displacementScale=1,this.displacementBias=0,this.wireframe=!1,this.wireframeLinewidth=1,this.setValues(t)}copy(t){return super.copy(t),this.depthPacking=t.depthPacking,this.map=t.map,this.alphaMap=t.alphaMap,this.displacementMap=t.displacementMap,this.displacementScale=t.displacementScale,this.displacementBias=t.displacementBias,this.wireframe=t.wireframe,this.wireframeLinewidth=t.wireframeLinewidth,this}},il=class extends Si{constructor(t){super(),this.isMeshDistanceMaterial=!0,this.type="MeshDistanceMaterial",this.map=null,this.alphaMap=null,this.displacementMap=null,this.displacementScale=1,this.displacementBias=0,this.setValues(t)}copy(t){return super.copy(t),this.map=t.map,this.alphaMap=t.alphaMap,this.displacementMap=t.displacementMap,this.displacementScale=t.displacementScale,this.displacementBias=t.displacementBias,this}},_0=`void main() {
	gl_Position = vec4( position, 1.0 );
}`,v0=`uniform sampler2D shadow_pass;
uniform vec2 resolution;
uniform float radius;
#include <packing>
void main() {
	const float samples = float( VSM_SAMPLES );
	float mean = 0.0;
	float squared_mean = 0.0;
	float uvStride = samples <= 1.0 ? 0.0 : 2.0 / ( samples - 1.0 );
	float uvStart = samples <= 1.0 ? 0.0 : - 1.0;
	for ( float i = 0.0; i < samples; i ++ ) {
		float uvOffset = uvStart + i * uvStride;
		#ifdef HORIZONTAL_PASS
			vec2 distribution = unpackRGBATo2Half( texture2D( shadow_pass, ( gl_FragCoord.xy + vec2( uvOffset, 0.0 ) * radius ) / resolution ) );
			mean += distribution.x;
			squared_mean += distribution.y * distribution.y + distribution.x * distribution.x;
		#else
			float depth = unpackRGBAToDepth( texture2D( shadow_pass, ( gl_FragCoord.xy + vec2( 0.0, uvOffset ) * radius ) / resolution ) );
			mean += depth;
			squared_mean += depth * depth;
		#endif
	}
	mean = mean / samples;
	squared_mean = squared_mean / samples;
	float std_dev = sqrt( squared_mean - mean * mean );
	gl_FragColor = pack2HalfToRGBA( vec2( mean, std_dev ) );
}`;function y0(i,t,e){let n=new dr,s=new Pt,r=new Pt,o=new we,a=new nl({depthPacking:dd}),l=new il,c={},u=e.maxTextureSize,f={[Mi]:nn,[nn]:Mi,[In]:In},p=new Ne({defines:{VSM_SAMPLES:8},uniforms:{shadow_pass:{value:null},resolution:{value:new Pt},radius:{value:4}},vertexShader:_0,fragmentShader:v0}),x=p.clone();x.defines.HORIZONTAL_PASS=1;let y=new hn;y.setAttribute("position",new sn(new Float32Array([-1,-1,.5,3,-1,.5,-1,3,.5]),3));let b=new ke(y,p),m=this;this.enabled=!1,this.autoUpdate=!0,this.needsUpdate=!1,this.type=Uh;let d=this.type;this.render=function(N,L,j){if(m.enabled===!1||m.autoUpdate===!1&&m.needsUpdate===!1||N.length===0)return;let S=i.getRenderTarget(),R=i.getActiveCubeFace(),V=i.getActiveMipmapLevel(),tt=i.state;tt.setBlending(Wn),tt.buffers.color.setClear(1,1,1,1),tt.buffers.depth.setTest(!0),tt.setScissorTest(!1);let ft=d!==ei&&this.type===ei,I=d===ei&&this.type!==ei;for(let k=0,G=N.length;k<G;k++){let K=N[k],Q=K.shadow;if(Q===void 0){console.warn("THREE.WebGLShadowMap:",K,"has no shadow.");continue}if(Q.autoUpdate===!1&&Q.needsUpdate===!1)continue;s.copy(Q.mapSize);let $=Q.getFrameExtents();if(s.multiply($),r.copy(Q.mapSize),(s.x>u||s.y>u)&&(s.x>u&&(r.x=Math.floor(u/$.x),s.x=r.x*$.x,Q.mapSize.x=r.x),s.y>u&&(r.y=Math.floor(u/$.y),s.y=r.y*$.y,Q.mapSize.y=r.y)),Q.map===null||ft===!0||I===!0){let ct=this.type!==ei?{minFilter:qe,magFilter:qe}:{};Q.map!==null&&Q.map.dispose(),Q.map=new je(s.x,s.y,ct),Q.map.texture.name=K.name+".shadowMap",Q.camera.updateProjectionMatrix()}i.setRenderTarget(Q.map),i.clear();let nt=Q.getViewportCount();for(let ct=0;ct<nt;ct++){let bt=Q.getViewport(ct);o.set(r.x*bt.x,r.y*bt.y,r.x*bt.z,r.y*bt.w),tt.viewport(o),Q.updateMatrices(K,ct),n=Q.getFrustum(),U(L,j,Q.camera,K,this.type)}Q.isPointLightShadow!==!0&&this.type===ei&&C(Q,j),Q.needsUpdate=!1}d=this.type,m.needsUpdate=!1,i.setRenderTarget(S,R,V)};function C(N,L){let j=t.update(b);p.defines.VSM_SAMPLES!==N.blurSamples&&(p.defines.VSM_SAMPLES=N.blurSamples,x.defines.VSM_SAMPLES=N.blurSamples,p.needsUpdate=!0,x.needsUpdate=!0),N.mapPass===null&&(N.mapPass=new je(s.x,s.y)),p.uniforms.shadow_pass.value=N.map.texture,p.uniforms.resolution.value=N.mapSize,p.uniforms.radius.value=N.radius,i.setRenderTarget(N.mapPass),i.clear(),i.renderBufferDirect(L,null,j,p,b,null),x.uniforms.shadow_pass.value=N.mapPass.texture,x.uniforms.resolution.value=N.mapSize,x.uniforms.radius.value=N.radius,i.setRenderTarget(N.map),i.clear(),i.renderBufferDirect(L,null,j,x,b,null)}function w(N,L,j,S){let R=null,V=j.isPointLight===!0?N.customDistanceMaterial:N.customDepthMaterial;if(V!==void 0)R=V;else if(R=j.isPointLight===!0?l:a,i.localClippingEnabled&&L.clipShadows===!0&&Array.isArray(L.clippingPlanes)&&L.clippingPlanes.length!==0||L.displacementMap&&L.displacementScale!==0||L.alphaMap&&L.alphaTest>0||L.map&&L.alphaTest>0){let tt=R.uuid,ft=L.uuid,I=c[tt];I===void 0&&(I={},c[tt]=I);let k=I[ft];k===void 0&&(k=R.clone(),I[ft]=k,L.addEventListener("dispose",z)),R=k}if(R.visible=L.visible,R.wireframe=L.wireframe,S===ei?R.side=L.shadowSide!==null?L.shadowSide:L.side:R.side=L.shadowSide!==null?L.shadowSide:f[L.side],R.alphaMap=L.alphaMap,R.alphaTest=L.alphaTest,R.map=L.map,R.clipShadows=L.clipShadows,R.clippingPlanes=L.clippingPlanes,R.clipIntersection=L.clipIntersection,R.displacementMap=L.displacementMap,R.displacementScale=L.displacementScale,R.displacementBias=L.displacementBias,R.wireframeLinewidth=L.wireframeLinewidth,R.linewidth=L.linewidth,j.isPointLight===!0&&R.isMeshDistanceMaterial===!0){let tt=i.properties.get(R);tt.light=j}return R}function U(N,L,j,S,R){if(N.visible===!1)return;if(N.layers.test(L.layers)&&(N.isMesh||N.isLine||N.isPoints)&&(N.castShadow||N.receiveShadow&&R===ei)&&(!N.frustumCulled||n.intersectsObject(N))){N.modelViewMatrix.multiplyMatrices(j.matrixWorldInverse,N.matrixWorld);let ft=t.update(N),I=N.material;if(Array.isArray(I)){let k=ft.groups;for(let G=0,K=k.length;G<K;G++){let Q=k[G],$=I[Q.materialIndex];if($&&$.visible){let nt=w(N,$,S,R);N.onBeforeShadow(i,N,L,j,ft,nt,Q),i.renderBufferDirect(j,null,ft,nt,N,Q),N.onAfterShadow(i,N,L,j,ft,nt,Q)}}}else if(I.visible){let k=w(N,I,S,R);N.onBeforeShadow(i,N,L,j,ft,k,null),i.renderBufferDirect(j,null,ft,k,N,null),N.onAfterShadow(i,N,L,j,ft,k,null)}}let tt=N.children;for(let ft=0,I=tt.length;ft<I;ft++)U(tt[ft],L,j,S,R)}function z(N){N.target.removeEventListener("dispose",z);for(let j in c){let S=c[j],R=N.target.uuid;R in S&&(S[R].dispose(),delete S[R])}}}function M0(i,t,e){let n=e.isWebGL2;function s(){let O=!1,gt=new we,xt=null,Ht=new we(0,0,0,0);return{setMask:function(Ft){xt!==Ft&&!O&&(i.colorMask(Ft,Ft,Ft,Ft),xt=Ft)},setLocked:function(Ft){O=Ft},setClear:function(Ft,ce,ne,Oe,_e){_e===!0&&(Ft*=Oe,ce*=Oe,ne*=Oe),gt.set(Ft,ce,ne,Oe),Ht.equals(gt)===!1&&(i.clearColor(Ft,ce,ne,Oe),Ht.copy(gt))},reset:function(){O=!1,xt=null,Ht.set(-1,0,0,0)}}}function r(){let O=!1,gt=null,xt=null,Ht=null;return{setTest:function(Ft){Ft?It(i.DEPTH_TEST):Tt(i.DEPTH_TEST)},setMask:function(Ft){gt!==Ft&&!O&&(i.depthMask(Ft),gt=Ft)},setFunc:function(Ft){if(xt!==Ft){switch(Ft){case Yu:i.depthFunc(i.NEVER);break;case qu:i.depthFunc(i.ALWAYS);break;case Zu:i.depthFunc(i.LESS);break;case sa:i.depthFunc(i.LEQUAL);break;case Ju:i.depthFunc(i.EQUAL);break;case $u:i.depthFunc(i.GEQUAL);break;case ju:i.depthFunc(i.GREATER);break;case Ku:i.depthFunc(i.NOTEQUAL);break;default:i.depthFunc(i.LEQUAL)}xt=Ft}},setLocked:function(Ft){O=Ft},setClear:function(Ft){Ht!==Ft&&(i.clearDepth(Ft),Ht=Ft)},reset:function(){O=!1,gt=null,xt=null,Ht=null}}}function o(){let O=!1,gt=null,xt=null,Ht=null,Ft=null,ce=null,ne=null,Oe=null,_e=null;return{setTest:function(pe){O||(pe?It(i.STENCIL_TEST):Tt(i.STENCIL_TEST))},setMask:function(pe){gt!==pe&&!O&&(i.stencilMask(pe),gt=pe)},setFunc:function(pe,Ge,_n){(xt!==pe||Ht!==Ge||Ft!==_n)&&(i.stencilFunc(pe,Ge,_n),xt=pe,Ht=Ge,Ft=_n)},setOp:function(pe,Ge,_n){(ce!==pe||ne!==Ge||Oe!==_n)&&(i.stencilOp(pe,Ge,_n),ce=pe,ne=Ge,Oe=_n)},setLocked:function(pe){O=pe},setClear:function(pe){_e!==pe&&(i.clearStencil(pe),_e=pe)},reset:function(){O=!1,gt=null,xt=null,Ht=null,Ft=null,ce=null,ne=null,Oe=null,_e=null}}}let a=new s,l=new r,c=new o,u=new WeakMap,f=new WeakMap,p={},x={},y=new WeakMap,b=[],m=null,d=!1,C=null,w=null,U=null,z=null,N=null,L=null,j=null,S=new qt(0,0,0),R=0,V=!1,tt=null,ft=null,I=null,k=null,G=null,K=i.getParameter(i.MAX_COMBINED_TEXTURE_IMAGE_UNITS),Q=!1,$=0,nt=i.getParameter(i.VERSION);nt.indexOf("WebGL")!==-1?($=parseFloat(/^WebGL (\d)/.exec(nt)[1]),Q=$>=1):nt.indexOf("OpenGL ES")!==-1&&($=parseFloat(/^OpenGL ES (\d)/.exec(nt)[1]),Q=$>=2);let ct=null,bt={},J=i.getParameter(i.SCISSOR_BOX),ot=i.getParameter(i.VIEWPORT),vt=new we().fromArray(J),Lt=new we().fromArray(ot);function Nt(O,gt,xt,Ht){let Ft=new Uint8Array(4),ce=i.createTexture();i.bindTexture(O,ce),i.texParameteri(O,i.TEXTURE_MIN_FILTER,i.NEAREST),i.texParameteri(O,i.TEXTURE_MAG_FILTER,i.NEAREST);for(let ne=0;ne<xt;ne++)n&&(O===i.TEXTURE_3D||O===i.TEXTURE_2D_ARRAY)?i.texImage3D(gt,0,i.RGBA,1,1,Ht,0,i.RGBA,i.UNSIGNED_BYTE,Ft):i.texImage2D(gt+ne,0,i.RGBA,1,1,0,i.RGBA,i.UNSIGNED_BYTE,Ft);return ce}let Ct={};Ct[i.TEXTURE_2D]=Nt(i.TEXTURE_2D,i.TEXTURE_2D,1),Ct[i.TEXTURE_CUBE_MAP]=Nt(i.TEXTURE_CUBE_MAP,i.TEXTURE_CUBE_MAP_POSITIVE_X,6),n&&(Ct[i.TEXTURE_2D_ARRAY]=Nt(i.TEXTURE_2D_ARRAY,i.TEXTURE_2D_ARRAY,1,1),Ct[i.TEXTURE_3D]=Nt(i.TEXTURE_3D,i.TEXTURE_3D,1,1)),a.setClear(0,0,0,1),l.setClear(1),c.setClear(0),It(i.DEPTH_TEST),l.setFunc(sa),$t(!1),A(sc),It(i.CULL_FACE),Rt(Wn);function It(O){p[O]!==!0&&(i.enable(O),p[O]=!0)}function Tt(O){p[O]!==!1&&(i.disable(O),p[O]=!1)}function kt(O,gt){return x[O]!==gt?(i.bindFramebuffer(O,gt),x[O]=gt,n&&(O===i.DRAW_FRAMEBUFFER&&(x[i.FRAMEBUFFER]=gt),O===i.FRAMEBUFFER&&(x[i.DRAW_FRAMEBUFFER]=gt)),!0):!1}function W(O,gt){let xt=b,Ht=!1;if(O)if(xt=y.get(gt),xt===void 0&&(xt=[],y.set(gt,xt)),O.isWebGLMultipleRenderTargets){let Ft=O.texture;if(xt.length!==Ft.length||xt[0]!==i.COLOR_ATTACHMENT0){for(let ce=0,ne=Ft.length;ce<ne;ce++)xt[ce]=i.COLOR_ATTACHMENT0+ce;xt.length=Ft.length,Ht=!0}}else xt[0]!==i.COLOR_ATTACHMENT0&&(xt[0]=i.COLOR_ATTACHMENT0,Ht=!0);else xt[0]!==i.BACK&&(xt[0]=i.BACK,Ht=!0);Ht&&(e.isWebGL2?i.drawBuffers(xt):t.get("WEBGL_draw_buffers").drawBuffersWEBGL(xt))}function Pe(O){return m!==O?(i.useProgram(O),m=O,!0):!1}let Dt={[ki]:i.FUNC_ADD,[Lu]:i.FUNC_SUBTRACT,[Iu]:i.FUNC_REVERSE_SUBTRACT};if(n)Dt[oc]=i.MIN,Dt[lc]=i.MAX;else{let O=t.get("EXT_blend_minmax");O!==null&&(Dt[oc]=O.MIN_EXT,Dt[lc]=O.MAX_EXT)}let Gt={[Du]:i.ZERO,[Uu]:i.ONE,[Nu]:i.SRC_COLOR,[zo]:i.SRC_ALPHA,[Hu]:i.SRC_ALPHA_SATURATE,[zu]:i.DST_COLOR,[Fu]:i.DST_ALPHA,[Ou]:i.ONE_MINUS_SRC_COLOR,[ko]:i.ONE_MINUS_SRC_ALPHA,[ku]:i.ONE_MINUS_DST_COLOR,[Bu]:i.ONE_MINUS_DST_ALPHA,[Vu]:i.CONSTANT_COLOR,[Gu]:i.ONE_MINUS_CONSTANT_COLOR,[Wu]:i.CONSTANT_ALPHA,[Xu]:i.ONE_MINUS_CONSTANT_ALPHA};function Rt(O,gt,xt,Ht,Ft,ce,ne,Oe,_e,pe){if(O===Wn){d===!0&&(Tt(i.BLEND),d=!1);return}if(d===!1&&(It(i.BLEND),d=!0),O!==Pu){if(O!==C||pe!==V){if((w!==ki||N!==ki)&&(i.blendEquation(i.FUNC_ADD),w=ki,N=ki),pe)switch(O){case ii:i.blendFuncSeparate(i.ONE,i.ONE_MINUS_SRC_ALPHA,i.ONE,i.ONE_MINUS_SRC_ALPHA);break;case Rs:i.blendFunc(i.ONE,i.ONE);break;case rc:i.blendFuncSeparate(i.ZERO,i.ONE_MINUS_SRC_COLOR,i.ZERO,i.ONE);break;case ac:i.blendFuncSeparate(i.ZERO,i.SRC_COLOR,i.ZERO,i.SRC_ALPHA);break;default:console.error("THREE.WebGLState: Invalid blending: ",O);break}else switch(O){case ii:i.blendFuncSeparate(i.SRC_ALPHA,i.ONE_MINUS_SRC_ALPHA,i.ONE,i.ONE_MINUS_SRC_ALPHA);break;case Rs:i.blendFunc(i.SRC_ALPHA,i.ONE);break;case rc:i.blendFuncSeparate(i.ZERO,i.ONE_MINUS_SRC_COLOR,i.ZERO,i.ONE);break;case ac:i.blendFunc(i.ZERO,i.SRC_COLOR);break;default:console.error("THREE.WebGLState: Invalid blending: ",O);break}U=null,z=null,L=null,j=null,S.set(0,0,0),R=0,C=O,V=pe}return}Ft=Ft||gt,ce=ce||xt,ne=ne||Ht,(gt!==w||Ft!==N)&&(i.blendEquationSeparate(Dt[gt],Dt[Ft]),w=gt,N=Ft),(xt!==U||Ht!==z||ce!==L||ne!==j)&&(i.blendFuncSeparate(Gt[xt],Gt[Ht],Gt[ce],Gt[ne]),U=xt,z=Ht,L=ce,j=ne),(Oe.equals(S)===!1||_e!==R)&&(i.blendColor(Oe.r,Oe.g,Oe.b,_e),S.copy(Oe),R=_e),C=O,V=!1}function me(O,gt){O.side===In?Tt(i.CULL_FACE):It(i.CULL_FACE);let xt=O.side===nn;gt&&(xt=!xt),$t(xt),O.blending===ii&&O.transparent===!1?Rt(Wn):Rt(O.blending,O.blendEquation,O.blendSrc,O.blendDst,O.blendEquationAlpha,O.blendSrcAlpha,O.blendDstAlpha,O.blendColor,O.blendAlpha,O.premultipliedAlpha),l.setFunc(O.depthFunc),l.setTest(O.depthTest),l.setMask(O.depthWrite),a.setMask(O.colorWrite);let Ht=O.stencilWrite;c.setTest(Ht),Ht&&(c.setMask(O.stencilWriteMask),c.setFunc(O.stencilFunc,O.stencilRef,O.stencilFuncMask),c.setOp(O.stencilFail,O.stencilZFail,O.stencilZPass)),X(O.polygonOffset,O.polygonOffsetFactor,O.polygonOffsetUnits),O.alphaToCoverage===!0?It(i.SAMPLE_ALPHA_TO_COVERAGE):Tt(i.SAMPLE_ALPHA_TO_COVERAGE)}function $t(O){tt!==O&&(O?i.frontFace(i.CW):i.frontFace(i.CCW),tt=O)}function A(O){O!==Cu?(It(i.CULL_FACE),O!==ft&&(O===sc?i.cullFace(i.BACK):O===Ru?i.cullFace(i.FRONT):i.cullFace(i.FRONT_AND_BACK))):Tt(i.CULL_FACE),ft=O}function M(O){O!==I&&(Q&&i.lineWidth(O),I=O)}function X(O,gt,xt){O?(It(i.POLYGON_OFFSET_FILL),(k!==gt||G!==xt)&&(i.polygonOffset(gt,xt),k=gt,G=xt)):Tt(i.POLYGON_OFFSET_FILL)}function ut(O){O?It(i.SCISSOR_TEST):Tt(i.SCISSOR_TEST)}function lt(O){O===void 0&&(O=i.TEXTURE0+K-1),ct!==O&&(i.activeTexture(O),ct=O)}function st(O,gt,xt){xt===void 0&&(ct===null?xt=i.TEXTURE0+K-1:xt=ct);let Ht=bt[xt];Ht===void 0&&(Ht={type:void 0,texture:void 0},bt[xt]=Ht),(Ht.type!==O||Ht.texture!==gt)&&(ct!==xt&&(i.activeTexture(xt),ct=xt),i.bindTexture(O,gt||Ct[O]),Ht.type=O,Ht.texture=gt)}function Et(){let O=bt[ct];O!==void 0&&O.type!==void 0&&(i.bindTexture(O.type,null),O.type=void 0,O.texture=void 0)}function Mt(){try{i.compressedTexImage2D.apply(i,arguments)}catch(O){console.error("THREE.WebGLState:",O)}}function ht(){try{i.compressedTexImage3D.apply(i,arguments)}catch(O){console.error("THREE.WebGLState:",O)}}function Ot(){try{i.texSubImage2D.apply(i,arguments)}catch(O){console.error("THREE.WebGLState:",O)}}function Yt(){try{i.texSubImage3D.apply(i,arguments)}catch(O){console.error("THREE.WebGLState:",O)}}function at(){try{i.compressedTexSubImage2D.apply(i,arguments)}catch(O){console.error("THREE.WebGLState:",O)}}function se(){try{i.compressedTexSubImage3D.apply(i,arguments)}catch(O){console.error("THREE.WebGLState:",O)}}function P(){try{i.texStorage2D.apply(i,arguments)}catch(O){console.error("THREE.WebGLState:",O)}}function rt(){try{i.texStorage3D.apply(i,arguments)}catch(O){console.error("THREE.WebGLState:",O)}}function mt(){try{i.texImage2D.apply(i,arguments)}catch(O){console.error("THREE.WebGLState:",O)}}function pt(){try{i.texImage3D.apply(i,arguments)}catch(O){console.error("THREE.WebGLState:",O)}}function Ut(O){vt.equals(O)===!1&&(i.scissor(O.x,O.y,O.z,O.w),vt.copy(O))}function Qt(O){Lt.equals(O)===!1&&(i.viewport(O.x,O.y,O.z,O.w),Lt.copy(O))}function ee(O,gt){let xt=f.get(gt);xt===void 0&&(xt=new WeakMap,f.set(gt,xt));let Ht=xt.get(O);Ht===void 0&&(Ht=i.getUniformBlockIndex(gt,O.name),xt.set(O,Ht))}function Kt(O,gt){let Ht=f.get(gt).get(O);u.get(gt)!==Ht&&(i.uniformBlockBinding(gt,Ht,O.__bindingPointIndex),u.set(gt,Ht))}function _t(){i.disable(i.BLEND),i.disable(i.CULL_FACE),i.disable(i.DEPTH_TEST),i.disable(i.POLYGON_OFFSET_FILL),i.disable(i.SCISSOR_TEST),i.disable(i.STENCIL_TEST),i.disable(i.SAMPLE_ALPHA_TO_COVERAGE),i.blendEquation(i.FUNC_ADD),i.blendFunc(i.ONE,i.ZERO),i.blendFuncSeparate(i.ONE,i.ZERO,i.ONE,i.ZERO),i.blendColor(0,0,0,0),i.colorMask(!0,!0,!0,!0),i.clearColor(0,0,0,0),i.depthMask(!0),i.depthFunc(i.LESS),i.clearDepth(1),i.stencilMask(4294967295),i.stencilFunc(i.ALWAYS,0,4294967295),i.stencilOp(i.KEEP,i.KEEP,i.KEEP),i.clearStencil(0),i.cullFace(i.BACK),i.frontFace(i.CCW),i.polygonOffset(0,0),i.activeTexture(i.TEXTURE0),i.bindFramebuffer(i.FRAMEBUFFER,null),n===!0&&(i.bindFramebuffer(i.DRAW_FRAMEBUFFER,null),i.bindFramebuffer(i.READ_FRAMEBUFFER,null)),i.useProgram(null),i.lineWidth(1),i.scissor(0,0,i.canvas.width,i.canvas.height),i.viewport(0,0,i.canvas.width,i.canvas.height),p={},ct=null,bt={},x={},y=new WeakMap,b=[],m=null,d=!1,C=null,w=null,U=null,z=null,N=null,L=null,j=null,S=new qt(0,0,0),R=0,V=!1,tt=null,ft=null,I=null,k=null,G=null,vt.set(0,0,i.canvas.width,i.canvas.height),Lt.set(0,0,i.canvas.width,i.canvas.height),a.reset(),l.reset(),c.reset()}return{buffers:{color:a,depth:l,stencil:c},enable:It,disable:Tt,bindFramebuffer:kt,drawBuffers:W,useProgram:Pe,setBlending:Rt,setMaterial:me,setFlipSided:$t,setCullFace:A,setLineWidth:M,setPolygonOffset:X,setScissorTest:ut,activeTexture:lt,bindTexture:st,unbindTexture:Et,compressedTexImage2D:Mt,compressedTexImage3D:ht,texImage2D:mt,texImage3D:pt,updateUBOMapping:ee,uniformBlockBinding:Kt,texStorage2D:P,texStorage3D:rt,texSubImage2D:Ot,texSubImage3D:Yt,compressedTexSubImage2D:at,compressedTexSubImage3D:se,scissor:Ut,viewport:Qt,reset:_t}}function b0(i,t,e,n,s,r,o){let a=s.isWebGL2,l=t.has("WEBGL_multisampled_render_to_texture")?t.get("WEBGL_multisampled_render_to_texture"):null,c=typeof navigator>"u"?!1:/OculusBrowser/g.test(navigator.userAgent),u=new WeakMap,f,p=new WeakMap,x=!1;try{x=typeof OffscreenCanvas<"u"&&new OffscreenCanvas(1,1).getContext("2d")!==null}catch{}function y(A,M){return x?new OffscreenCanvas(A,M):da("canvas")}function b(A,M,X,ut){let lt=1;if((A.width>ut||A.height>ut)&&(lt=ut/Math.max(A.width,A.height)),lt<1||M===!0)if(typeof HTMLImageElement<"u"&&A instanceof HTMLImageElement||typeof HTMLCanvasElement<"u"&&A instanceof HTMLCanvasElement||typeof ImageBitmap<"u"&&A instanceof ImageBitmap){let st=M?ua:Math.floor,Et=st(lt*A.width),Mt=st(lt*A.height);f===void 0&&(f=y(Et,Mt));let ht=X?y(Et,Mt):f;return ht.width=Et,ht.height=Mt,ht.getContext("2d").drawImage(A,0,0,Et,Mt),console.warn("THREE.WebGLRenderer: Texture has been resized from ("+A.width+"x"+A.height+") to ("+Et+"x"+Mt+")."),ht}else return"data"in A&&console.warn("THREE.WebGLRenderer: Image in DataTexture is too big ("+A.width+"x"+A.height+")."),A;return A}function m(A){return Xo(A.width)&&Xo(A.height)}function d(A){return a?!1:A.wrapS!==Dn||A.wrapT!==Dn||A.minFilter!==qe&&A.minFilter!==yn}function C(A,M){return A.generateMipmaps&&M&&A.minFilter!==qe&&A.minFilter!==yn}function w(A){i.generateMipmap(A)}function U(A,M,X,ut,lt=!1){if(a===!1)return M;if(A!==null){if(i[A]!==void 0)return i[A];console.warn("THREE.WebGLRenderer: Attempt to use non-existing WebGL internal format '"+A+"'")}let st=M;if(M===i.RED&&(X===i.FLOAT&&(st=i.R32F),X===i.HALF_FLOAT&&(st=i.R16F),X===i.UNSIGNED_BYTE&&(st=i.R8)),M===i.RED_INTEGER&&(X===i.UNSIGNED_BYTE&&(st=i.R8UI),X===i.UNSIGNED_SHORT&&(st=i.R16UI),X===i.UNSIGNED_INT&&(st=i.R32UI),X===i.BYTE&&(st=i.R8I),X===i.SHORT&&(st=i.R16I),X===i.INT&&(st=i.R32I)),M===i.RG&&(X===i.FLOAT&&(st=i.RG32F),X===i.HALF_FLOAT&&(st=i.RG16F),X===i.UNSIGNED_BYTE&&(st=i.RG8)),M===i.RGBA){let Et=lt?oa:fe.getTransfer(ut);X===i.FLOAT&&(st=i.RGBA32F),X===i.HALF_FLOAT&&(st=i.RGBA16F),X===i.UNSIGNED_BYTE&&(st=Et===ge?i.SRGB8_ALPHA8:i.RGBA8),X===i.UNSIGNED_SHORT_4_4_4_4&&(st=i.RGBA4),X===i.UNSIGNED_SHORT_5_5_5_1&&(st=i.RGB5_A1)}return(st===i.R16F||st===i.R32F||st===i.RG16F||st===i.RG32F||st===i.RGBA16F||st===i.RGBA32F)&&t.get("EXT_color_buffer_float"),st}function z(A,M,X){return C(A,X)===!0||A.isFramebufferTexture&&A.minFilter!==qe&&A.minFilter!==yn?Math.log2(Math.max(M.width,M.height))+1:A.mipmaps!==void 0&&A.mipmaps.length>0?A.mipmaps.length:A.isCompressedTexture&&Array.isArray(A.image)?M.mipmaps.length:1}function N(A){return A===qe||A===cc||A===oo?i.NEAREST:i.LINEAR}function L(A){let M=A.target;M.removeEventListener("dispose",L),S(M),M.isVideoTexture&&u.delete(M)}function j(A){let M=A.target;M.removeEventListener("dispose",j),V(M)}function S(A){let M=n.get(A);if(M.__webglInit===void 0)return;let X=A.source,ut=p.get(X);if(ut){let lt=ut[M.__cacheKey];lt.usedTimes--,lt.usedTimes===0&&R(A),Object.keys(ut).length===0&&p.delete(X)}n.remove(A)}function R(A){let M=n.get(A);i.deleteTexture(M.__webglTexture);let X=A.source,ut=p.get(X);delete ut[M.__cacheKey],o.memory.textures--}function V(A){let M=A.texture,X=n.get(A),ut=n.get(M);if(ut.__webglTexture!==void 0&&(i.deleteTexture(ut.__webglTexture),o.memory.textures--),A.depthTexture&&A.depthTexture.dispose(),A.isWebGLCubeRenderTarget)for(let lt=0;lt<6;lt++){if(Array.isArray(X.__webglFramebuffer[lt]))for(let st=0;st<X.__webglFramebuffer[lt].length;st++)i.deleteFramebuffer(X.__webglFramebuffer[lt][st]);else i.deleteFramebuffer(X.__webglFramebuffer[lt]);X.__webglDepthbuffer&&i.deleteRenderbuffer(X.__webglDepthbuffer[lt])}else{if(Array.isArray(X.__webglFramebuffer))for(let lt=0;lt<X.__webglFramebuffer.length;lt++)i.deleteFramebuffer(X.__webglFramebuffer[lt]);else i.deleteFramebuffer(X.__webglFramebuffer);if(X.__webglDepthbuffer&&i.deleteRenderbuffer(X.__webglDepthbuffer),X.__webglMultisampledFramebuffer&&i.deleteFramebuffer(X.__webglMultisampledFramebuffer),X.__webglColorRenderbuffer)for(let lt=0;lt<X.__webglColorRenderbuffer.length;lt++)X.__webglColorRenderbuffer[lt]&&i.deleteRenderbuffer(X.__webglColorRenderbuffer[lt]);X.__webglDepthRenderbuffer&&i.deleteRenderbuffer(X.__webglDepthRenderbuffer)}if(A.isWebGLMultipleRenderTargets)for(let lt=0,st=M.length;lt<st;lt++){let Et=n.get(M[lt]);Et.__webglTexture&&(i.deleteTexture(Et.__webglTexture),o.memory.textures--),n.remove(M[lt])}n.remove(M),n.remove(A)}let tt=0;function ft(){tt=0}function I(){let A=tt;return A>=s.maxTextures&&console.warn("THREE.WebGLTextures: Trying to use "+A+" texture units while this GPU supports only "+s.maxTextures),tt+=1,A}function k(A){let M=[];return M.push(A.wrapS),M.push(A.wrapT),M.push(A.wrapR||0),M.push(A.magFilter),M.push(A.minFilter),M.push(A.anisotropy),M.push(A.internalFormat),M.push(A.format),M.push(A.type),M.push(A.generateMipmaps),M.push(A.premultiplyAlpha),M.push(A.flipY),M.push(A.unpackAlignment),M.push(A.colorSpace),M.join()}function G(A,M){let X=n.get(A);if(A.isVideoTexture&&me(A),A.isRenderTargetTexture===!1&&A.version>0&&X.__version!==A.version){let ut=A.image;if(ut===null)console.warn("THREE.WebGLRenderer: Texture marked for update but no image data found.");else if(ut.complete===!1)console.warn("THREE.WebGLRenderer: Texture marked for update but image is incomplete");else{vt(X,A,M);return}}e.bindTexture(i.TEXTURE_2D,X.__webglTexture,i.TEXTURE0+M)}function K(A,M){let X=n.get(A);if(A.version>0&&X.__version!==A.version){vt(X,A,M);return}e.bindTexture(i.TEXTURE_2D_ARRAY,X.__webglTexture,i.TEXTURE0+M)}function Q(A,M){let X=n.get(A);if(A.version>0&&X.__version!==A.version){vt(X,A,M);return}e.bindTexture(i.TEXTURE_3D,X.__webglTexture,i.TEXTURE0+M)}function $(A,M){let X=n.get(A);if(A.version>0&&X.__version!==A.version){Lt(X,A,M);return}e.bindTexture(i.TEXTURE_CUBE_MAP,X.__webglTexture,i.TEXTURE0+M)}let nt={[lr]:i.REPEAT,[Dn]:i.CLAMP_TO_EDGE,[Go]:i.MIRRORED_REPEAT},ct={[qe]:i.NEAREST,[cc]:i.NEAREST_MIPMAP_NEAREST,[oo]:i.NEAREST_MIPMAP_LINEAR,[yn]:i.LINEAR,[nd]:i.LINEAR_MIPMAP_NEAREST,[cr]:i.LINEAR_MIPMAP_LINEAR},bt={[pd]:i.NEVER,[yd]:i.ALWAYS,[md]:i.LESS,[Yh]:i.LEQUAL,[gd]:i.EQUAL,[vd]:i.GEQUAL,[xd]:i.GREATER,[_d]:i.NOTEQUAL};function J(A,M,X){if(X?(i.texParameteri(A,i.TEXTURE_WRAP_S,nt[M.wrapS]),i.texParameteri(A,i.TEXTURE_WRAP_T,nt[M.wrapT]),(A===i.TEXTURE_3D||A===i.TEXTURE_2D_ARRAY)&&i.texParameteri(A,i.TEXTURE_WRAP_R,nt[M.wrapR]),i.texParameteri(A,i.TEXTURE_MAG_FILTER,ct[M.magFilter]),i.texParameteri(A,i.TEXTURE_MIN_FILTER,ct[M.minFilter])):(i.texParameteri(A,i.TEXTURE_WRAP_S,i.CLAMP_TO_EDGE),i.texParameteri(A,i.TEXTURE_WRAP_T,i.CLAMP_TO_EDGE),(A===i.TEXTURE_3D||A===i.TEXTURE_2D_ARRAY)&&i.texParameteri(A,i.TEXTURE_WRAP_R,i.CLAMP_TO_EDGE),(M.wrapS!==Dn||M.wrapT!==Dn)&&console.warn("THREE.WebGLRenderer: Texture is not power of two. Texture.wrapS and Texture.wrapT should be set to THREE.ClampToEdgeWrapping."),i.texParameteri(A,i.TEXTURE_MAG_FILTER,N(M.magFilter)),i.texParameteri(A,i.TEXTURE_MIN_FILTER,N(M.minFilter)),M.minFilter!==qe&&M.minFilter!==yn&&console.warn("THREE.WebGLRenderer: Texture is not power of two. Texture.minFilter should be set to THREE.NearestFilter or THREE.LinearFilter.")),M.compareFunction&&(i.texParameteri(A,i.TEXTURE_COMPARE_MODE,i.COMPARE_REF_TO_TEXTURE),i.texParameteri(A,i.TEXTURE_COMPARE_FUNC,bt[M.compareFunction])),t.has("EXT_texture_filter_anisotropic")===!0){let ut=t.get("EXT_texture_filter_anisotropic");if(M.magFilter===qe||M.minFilter!==oo&&M.minFilter!==cr||M.type===xi&&t.has("OES_texture_float_linear")===!1||a===!1&&M.type===mn&&t.has("OES_texture_half_float_linear")===!1)return;(M.anisotropy>1||n.get(M).__currentAnisotropy)&&(i.texParameterf(A,ut.TEXTURE_MAX_ANISOTROPY_EXT,Math.min(M.anisotropy,s.getMaxAnisotropy())),n.get(M).__currentAnisotropy=M.anisotropy)}}function ot(A,M){let X=!1;A.__webglInit===void 0&&(A.__webglInit=!0,M.addEventListener("dispose",L));let ut=M.source,lt=p.get(ut);lt===void 0&&(lt={},p.set(ut,lt));let st=k(M);if(st!==A.__cacheKey){lt[st]===void 0&&(lt[st]={texture:i.createTexture(),usedTimes:0},o.memory.textures++,X=!0),lt[st].usedTimes++;let Et=lt[A.__cacheKey];Et!==void 0&&(lt[A.__cacheKey].usedTimes--,Et.usedTimes===0&&R(M)),A.__cacheKey=st,A.__webglTexture=lt[st].texture}return X}function vt(A,M,X){let ut=i.TEXTURE_2D;(M.isDataArrayTexture||M.isCompressedArrayTexture)&&(ut=i.TEXTURE_2D_ARRAY),M.isData3DTexture&&(ut=i.TEXTURE_3D);let lt=ot(A,M),st=M.source;e.bindTexture(ut,A.__webglTexture,i.TEXTURE0+X);let Et=n.get(st);if(st.version!==Et.__version||lt===!0){e.activeTexture(i.TEXTURE0+X);let Mt=fe.getPrimaries(fe.workingColorSpace),ht=M.colorSpace===Mn?null:fe.getPrimaries(M.colorSpace),Ot=M.colorSpace===Mn||Mt===ht?i.NONE:i.BROWSER_DEFAULT_WEBGL;i.pixelStorei(i.UNPACK_FLIP_Y_WEBGL,M.flipY),i.pixelStorei(i.UNPACK_PREMULTIPLY_ALPHA_WEBGL,M.premultiplyAlpha),i.pixelStorei(i.UNPACK_ALIGNMENT,M.unpackAlignment),i.pixelStorei(i.UNPACK_COLORSPACE_CONVERSION_WEBGL,Ot);let Yt=d(M)&&m(M.image)===!1,at=b(M.image,Yt,!1,s.maxTextureSize);at=$t(M,at);let se=m(at)||a,P=r.convert(M.format,M.colorSpace),rt=r.convert(M.type),mt=U(M.internalFormat,P,rt,M.colorSpace,M.isVideoTexture);J(ut,M,se);let pt,Ut=M.mipmaps,Qt=a&&M.isVideoTexture!==!0&&mt!==Gh,ee=Et.__version===void 0||lt===!0,Kt=z(M,at,se);if(M.isDepthTexture)mt=i.DEPTH_COMPONENT,a?M.type===xi?mt=i.DEPTH_COMPONENT32F:M.type===gi?mt=i.DEPTH_COMPONENT24:M.type===Vi?mt=i.DEPTH24_STENCIL8:mt=i.DEPTH_COMPONENT16:M.type===xi&&console.error("WebGLRenderer: Floating point depth texture requires WebGL2."),M.format===Gi&&mt===i.DEPTH_COMPONENT&&M.type!==Tl&&M.type!==gi&&(console.warn("THREE.WebGLRenderer: Use UnsignedShortType or UnsignedIntType for DepthFormat DepthTexture."),M.type=gi,rt=r.convert(M.type)),M.format===Is&&mt===i.DEPTH_COMPONENT&&(mt=i.DEPTH_STENCIL,M.type!==Vi&&(console.warn("THREE.WebGLRenderer: Use UnsignedInt248Type for DepthStencilFormat DepthTexture."),M.type=Vi,rt=r.convert(M.type))),ee&&(Qt?e.texStorage2D(i.TEXTURE_2D,1,mt,at.width,at.height):e.texImage2D(i.TEXTURE_2D,0,mt,at.width,at.height,0,P,rt,null));else if(M.isDataTexture)if(Ut.length>0&&se){Qt&&ee&&e.texStorage2D(i.TEXTURE_2D,Kt,mt,Ut[0].width,Ut[0].height);for(let _t=0,O=Ut.length;_t<O;_t++)pt=Ut[_t],Qt?e.texSubImage2D(i.TEXTURE_2D,_t,0,0,pt.width,pt.height,P,rt,pt.data):e.texImage2D(i.TEXTURE_2D,_t,mt,pt.width,pt.height,0,P,rt,pt.data);M.generateMipmaps=!1}else Qt?(ee&&e.texStorage2D(i.TEXTURE_2D,Kt,mt,at.width,at.height),e.texSubImage2D(i.TEXTURE_2D,0,0,0,at.width,at.height,P,rt,at.data)):e.texImage2D(i.TEXTURE_2D,0,mt,at.width,at.height,0,P,rt,at.data);else if(M.isCompressedTexture)if(M.isCompressedArrayTexture){Qt&&ee&&e.texStorage3D(i.TEXTURE_2D_ARRAY,Kt,mt,Ut[0].width,Ut[0].height,at.depth);for(let _t=0,O=Ut.length;_t<O;_t++)pt=Ut[_t],M.format!==Un?P!==null?Qt?e.compressedTexSubImage3D(i.TEXTURE_2D_ARRAY,_t,0,0,0,pt.width,pt.height,at.depth,P,pt.data,0,0):e.compressedTexImage3D(i.TEXTURE_2D_ARRAY,_t,mt,pt.width,pt.height,at.depth,0,pt.data,0,0):console.warn("THREE.WebGLRenderer: Attempt to load unsupported compressed texture format in .uploadTexture()"):Qt?e.texSubImage3D(i.TEXTURE_2D_ARRAY,_t,0,0,0,pt.width,pt.height,at.depth,P,rt,pt.data):e.texImage3D(i.TEXTURE_2D_ARRAY,_t,mt,pt.width,pt.height,at.depth,0,P,rt,pt.data)}else{Qt&&ee&&e.texStorage2D(i.TEXTURE_2D,Kt,mt,Ut[0].width,Ut[0].height);for(let _t=0,O=Ut.length;_t<O;_t++)pt=Ut[_t],M.format!==Un?P!==null?Qt?e.compressedTexSubImage2D(i.TEXTURE_2D,_t,0,0,pt.width,pt.height,P,pt.data):e.compressedTexImage2D(i.TEXTURE_2D,_t,mt,pt.width,pt.height,0,pt.data):console.warn("THREE.WebGLRenderer: Attempt to load unsupported compressed texture format in .uploadTexture()"):Qt?e.texSubImage2D(i.TEXTURE_2D,_t,0,0,pt.width,pt.height,P,rt,pt.data):e.texImage2D(i.TEXTURE_2D,_t,mt,pt.width,pt.height,0,P,rt,pt.data)}else if(M.isDataArrayTexture)Qt?(ee&&e.texStorage3D(i.TEXTURE_2D_ARRAY,Kt,mt,at.width,at.height,at.depth),e.texSubImage3D(i.TEXTURE_2D_ARRAY,0,0,0,0,at.width,at.height,at.depth,P,rt,at.data)):e.texImage3D(i.TEXTURE_2D_ARRAY,0,mt,at.width,at.height,at.depth,0,P,rt,at.data);else if(M.isData3DTexture)Qt?(ee&&e.texStorage3D(i.TEXTURE_3D,Kt,mt,at.width,at.height,at.depth),e.texSubImage3D(i.TEXTURE_3D,0,0,0,0,at.width,at.height,at.depth,P,rt,at.data)):e.texImage3D(i.TEXTURE_3D,0,mt,at.width,at.height,at.depth,0,P,rt,at.data);else if(M.isFramebufferTexture){if(ee)if(Qt)e.texStorage2D(i.TEXTURE_2D,Kt,mt,at.width,at.height);else{let _t=at.width,O=at.height;for(let gt=0;gt<Kt;gt++)e.texImage2D(i.TEXTURE_2D,gt,mt,_t,O,0,P,rt,null),_t>>=1,O>>=1}}else if(Ut.length>0&&se){Qt&&ee&&e.texStorage2D(i.TEXTURE_2D,Kt,mt,Ut[0].width,Ut[0].height);for(let _t=0,O=Ut.length;_t<O;_t++)pt=Ut[_t],Qt?e.texSubImage2D(i.TEXTURE_2D,_t,0,0,P,rt,pt):e.texImage2D(i.TEXTURE_2D,_t,mt,P,rt,pt);M.generateMipmaps=!1}else Qt?(ee&&e.texStorage2D(i.TEXTURE_2D,Kt,mt,at.width,at.height),e.texSubImage2D(i.TEXTURE_2D,0,0,0,P,rt,at)):e.texImage2D(i.TEXTURE_2D,0,mt,P,rt,at);C(M,se)&&w(ut),Et.__version=st.version,M.onUpdate&&M.onUpdate(M)}A.__version=M.version}function Lt(A,M,X){if(M.image.length!==6)return;let ut=ot(A,M),lt=M.source;e.bindTexture(i.TEXTURE_CUBE_MAP,A.__webglTexture,i.TEXTURE0+X);let st=n.get(lt);if(lt.version!==st.__version||ut===!0){e.activeTexture(i.TEXTURE0+X);let Et=fe.getPrimaries(fe.workingColorSpace),Mt=M.colorSpace===Mn?null:fe.getPrimaries(M.colorSpace),ht=M.colorSpace===Mn||Et===Mt?i.NONE:i.BROWSER_DEFAULT_WEBGL;i.pixelStorei(i.UNPACK_FLIP_Y_WEBGL,M.flipY),i.pixelStorei(i.UNPACK_PREMULTIPLY_ALPHA_WEBGL,M.premultiplyAlpha),i.pixelStorei(i.UNPACK_ALIGNMENT,M.unpackAlignment),i.pixelStorei(i.UNPACK_COLORSPACE_CONVERSION_WEBGL,ht);let Ot=M.isCompressedTexture||M.image[0].isCompressedTexture,Yt=M.image[0]&&M.image[0].isDataTexture,at=[];for(let _t=0;_t<6;_t++)!Ot&&!Yt?at[_t]=b(M.image[_t],!1,!0,s.maxCubemapSize):at[_t]=Yt?M.image[_t].image:M.image[_t],at[_t]=$t(M,at[_t]);let se=at[0],P=m(se)||a,rt=r.convert(M.format,M.colorSpace),mt=r.convert(M.type),pt=U(M.internalFormat,rt,mt,M.colorSpace),Ut=a&&M.isVideoTexture!==!0,Qt=st.__version===void 0||ut===!0,ee=z(M,se,P);J(i.TEXTURE_CUBE_MAP,M,P);let Kt;if(Ot){Ut&&Qt&&e.texStorage2D(i.TEXTURE_CUBE_MAP,ee,pt,se.width,se.height);for(let _t=0;_t<6;_t++){Kt=at[_t].mipmaps;for(let O=0;O<Kt.length;O++){let gt=Kt[O];M.format!==Un?rt!==null?Ut?e.compressedTexSubImage2D(i.TEXTURE_CUBE_MAP_POSITIVE_X+_t,O,0,0,gt.width,gt.height,rt,gt.data):e.compressedTexImage2D(i.TEXTURE_CUBE_MAP_POSITIVE_X+_t,O,pt,gt.width,gt.height,0,gt.data):console.warn("THREE.WebGLRenderer: Attempt to load unsupported compressed texture format in .setTextureCube()"):Ut?e.texSubImage2D(i.TEXTURE_CUBE_MAP_POSITIVE_X+_t,O,0,0,gt.width,gt.height,rt,mt,gt.data):e.texImage2D(i.TEXTURE_CUBE_MAP_POSITIVE_X+_t,O,pt,gt.width,gt.height,0,rt,mt,gt.data)}}}else{Kt=M.mipmaps,Ut&&Qt&&(Kt.length>0&&ee++,e.texStorage2D(i.TEXTURE_CUBE_MAP,ee,pt,at[0].width,at[0].height));for(let _t=0;_t<6;_t++)if(Yt){Ut?e.texSubImage2D(i.TEXTURE_CUBE_MAP_POSITIVE_X+_t,0,0,0,at[_t].width,at[_t].height,rt,mt,at[_t].data):e.texImage2D(i.TEXTURE_CUBE_MAP_POSITIVE_X+_t,0,pt,at[_t].width,at[_t].height,0,rt,mt,at[_t].data);for(let O=0;O<Kt.length;O++){let xt=Kt[O].image[_t].image;Ut?e.texSubImage2D(i.TEXTURE_CUBE_MAP_POSITIVE_X+_t,O+1,0,0,xt.width,xt.height,rt,mt,xt.data):e.texImage2D(i.TEXTURE_CUBE_MAP_POSITIVE_X+_t,O+1,pt,xt.width,xt.height,0,rt,mt,xt.data)}}else{Ut?e.texSubImage2D(i.TEXTURE_CUBE_MAP_POSITIVE_X+_t,0,0,0,rt,mt,at[_t]):e.texImage2D(i.TEXTURE_CUBE_MAP_POSITIVE_X+_t,0,pt,rt,mt,at[_t]);for(let O=0;O<Kt.length;O++){let gt=Kt[O];Ut?e.texSubImage2D(i.TEXTURE_CUBE_MAP_POSITIVE_X+_t,O+1,0,0,rt,mt,gt.image[_t]):e.texImage2D(i.TEXTURE_CUBE_MAP_POSITIVE_X+_t,O+1,pt,rt,mt,gt.image[_t])}}}C(M,P)&&w(i.TEXTURE_CUBE_MAP),st.__version=lt.version,M.onUpdate&&M.onUpdate(M)}A.__version=M.version}function Nt(A,M,X,ut,lt,st){let Et=r.convert(X.format,X.colorSpace),Mt=r.convert(X.type),ht=U(X.internalFormat,Et,Mt,X.colorSpace);if(!n.get(M).__hasExternalTextures){let Yt=Math.max(1,M.width>>st),at=Math.max(1,M.height>>st);lt===i.TEXTURE_3D||lt===i.TEXTURE_2D_ARRAY?e.texImage3D(lt,st,ht,Yt,at,M.depth,0,Et,Mt,null):e.texImage2D(lt,st,ht,Yt,at,0,Et,Mt,null)}e.bindFramebuffer(i.FRAMEBUFFER,A),Rt(M)?l.framebufferTexture2DMultisampleEXT(i.FRAMEBUFFER,ut,lt,n.get(X).__webglTexture,0,Gt(M)):(lt===i.TEXTURE_2D||lt>=i.TEXTURE_CUBE_MAP_POSITIVE_X&&lt<=i.TEXTURE_CUBE_MAP_NEGATIVE_Z)&&i.framebufferTexture2D(i.FRAMEBUFFER,ut,lt,n.get(X).__webglTexture,st),e.bindFramebuffer(i.FRAMEBUFFER,null)}function Ct(A,M,X){if(i.bindRenderbuffer(i.RENDERBUFFER,A),M.depthBuffer&&!M.stencilBuffer){let ut=a===!0?i.DEPTH_COMPONENT24:i.DEPTH_COMPONENT16;if(X||Rt(M)){let lt=M.depthTexture;lt&&lt.isDepthTexture&&(lt.type===xi?ut=i.DEPTH_COMPONENT32F:lt.type===gi&&(ut=i.DEPTH_COMPONENT24));let st=Gt(M);Rt(M)?l.renderbufferStorageMultisampleEXT(i.RENDERBUFFER,st,ut,M.width,M.height):i.renderbufferStorageMultisample(i.RENDERBUFFER,st,ut,M.width,M.height)}else i.renderbufferStorage(i.RENDERBUFFER,ut,M.width,M.height);i.framebufferRenderbuffer(i.FRAMEBUFFER,i.DEPTH_ATTACHMENT,i.RENDERBUFFER,A)}else if(M.depthBuffer&&M.stencilBuffer){let ut=Gt(M);X&&Rt(M)===!1?i.renderbufferStorageMultisample(i.RENDERBUFFER,ut,i.DEPTH24_STENCIL8,M.width,M.height):Rt(M)?l.renderbufferStorageMultisampleEXT(i.RENDERBUFFER,ut,i.DEPTH24_STENCIL8,M.width,M.height):i.renderbufferStorage(i.RENDERBUFFER,i.DEPTH_STENCIL,M.width,M.height),i.framebufferRenderbuffer(i.FRAMEBUFFER,i.DEPTH_STENCIL_ATTACHMENT,i.RENDERBUFFER,A)}else{let ut=M.isWebGLMultipleRenderTargets===!0?M.texture:[M.texture];for(let lt=0;lt<ut.length;lt++){let st=ut[lt],Et=r.convert(st.format,st.colorSpace),Mt=r.convert(st.type),ht=U(st.internalFormat,Et,Mt,st.colorSpace),Ot=Gt(M);X&&Rt(M)===!1?i.renderbufferStorageMultisample(i.RENDERBUFFER,Ot,ht,M.width,M.height):Rt(M)?l.renderbufferStorageMultisampleEXT(i.RENDERBUFFER,Ot,ht,M.width,M.height):i.renderbufferStorage(i.RENDERBUFFER,ht,M.width,M.height)}}i.bindRenderbuffer(i.RENDERBUFFER,null)}function It(A,M){if(M&&M.isWebGLCubeRenderTarget)throw new Error("Depth Texture with cube render targets is not supported");if(e.bindFramebuffer(i.FRAMEBUFFER,A),!(M.depthTexture&&M.depthTexture.isDepthTexture))throw new Error("renderTarget.depthTexture must be an instance of THREE.DepthTexture");(!n.get(M.depthTexture).__webglTexture||M.depthTexture.image.width!==M.width||M.depthTexture.image.height!==M.height)&&(M.depthTexture.image.width=M.width,M.depthTexture.image.height=M.height,M.depthTexture.needsUpdate=!0),G(M.depthTexture,0);let ut=n.get(M.depthTexture).__webglTexture,lt=Gt(M);if(M.depthTexture.format===Gi)Rt(M)?l.framebufferTexture2DMultisampleEXT(i.FRAMEBUFFER,i.DEPTH_ATTACHMENT,i.TEXTURE_2D,ut,0,lt):i.framebufferTexture2D(i.FRAMEBUFFER,i.DEPTH_ATTACHMENT,i.TEXTURE_2D,ut,0);else if(M.depthTexture.format===Is)Rt(M)?l.framebufferTexture2DMultisampleEXT(i.FRAMEBUFFER,i.DEPTH_STENCIL_ATTACHMENT,i.TEXTURE_2D,ut,0,lt):i.framebufferTexture2D(i.FRAMEBUFFER,i.DEPTH_STENCIL_ATTACHMENT,i.TEXTURE_2D,ut,0);else throw new Error("Unknown depthTexture format")}function Tt(A){let M=n.get(A),X=A.isWebGLCubeRenderTarget===!0;if(A.depthTexture&&!M.__autoAllocateDepthBuffer){if(X)throw new Error("target.depthTexture not supported in Cube render targets");It(M.__webglFramebuffer,A)}else if(X){M.__webglDepthbuffer=[];for(let ut=0;ut<6;ut++)e.bindFramebuffer(i.FRAMEBUFFER,M.__webglFramebuffer[ut]),M.__webglDepthbuffer[ut]=i.createRenderbuffer(),Ct(M.__webglDepthbuffer[ut],A,!1)}else e.bindFramebuffer(i.FRAMEBUFFER,M.__webglFramebuffer),M.__webglDepthbuffer=i.createRenderbuffer(),Ct(M.__webglDepthbuffer,A,!1);e.bindFramebuffer(i.FRAMEBUFFER,null)}function kt(A,M,X){let ut=n.get(A);M!==void 0&&Nt(ut.__webglFramebuffer,A,A.texture,i.COLOR_ATTACHMENT0,i.TEXTURE_2D,0),X!==void 0&&Tt(A)}function W(A){let M=A.texture,X=n.get(A),ut=n.get(M);A.addEventListener("dispose",j),A.isWebGLMultipleRenderTargets!==!0&&(ut.__webglTexture===void 0&&(ut.__webglTexture=i.createTexture()),ut.__version=M.version,o.memory.textures++);let lt=A.isWebGLCubeRenderTarget===!0,st=A.isWebGLMultipleRenderTargets===!0,Et=m(A)||a;if(lt){X.__webglFramebuffer=[];for(let Mt=0;Mt<6;Mt++)if(a&&M.mipmaps&&M.mipmaps.length>0){X.__webglFramebuffer[Mt]=[];for(let ht=0;ht<M.mipmaps.length;ht++)X.__webglFramebuffer[Mt][ht]=i.createFramebuffer()}else X.__webglFramebuffer[Mt]=i.createFramebuffer()}else{if(a&&M.mipmaps&&M.mipmaps.length>0){X.__webglFramebuffer=[];for(let Mt=0;Mt<M.mipmaps.length;Mt++)X.__webglFramebuffer[Mt]=i.createFramebuffer()}else X.__webglFramebuffer=i.createFramebuffer();if(st)if(s.drawBuffers){let Mt=A.texture;for(let ht=0,Ot=Mt.length;ht<Ot;ht++){let Yt=n.get(Mt[ht]);Yt.__webglTexture===void 0&&(Yt.__webglTexture=i.createTexture(),o.memory.textures++)}}else console.warn("THREE.WebGLRenderer: WebGLMultipleRenderTargets can only be used with WebGL2 or WEBGL_draw_buffers extension.");if(a&&A.samples>0&&Rt(A)===!1){let Mt=st?M:[M];X.__webglMultisampledFramebuffer=i.createFramebuffer(),X.__webglColorRenderbuffer=[],e.bindFramebuffer(i.FRAMEBUFFER,X.__webglMultisampledFramebuffer);for(let ht=0;ht<Mt.length;ht++){let Ot=Mt[ht];X.__webglColorRenderbuffer[ht]=i.createRenderbuffer(),i.bindRenderbuffer(i.RENDERBUFFER,X.__webglColorRenderbuffer[ht]);let Yt=r.convert(Ot.format,Ot.colorSpace),at=r.convert(Ot.type),se=U(Ot.internalFormat,Yt,at,Ot.colorSpace,A.isXRRenderTarget===!0),P=Gt(A);i.renderbufferStorageMultisample(i.RENDERBUFFER,P,se,A.width,A.height),i.framebufferRenderbuffer(i.FRAMEBUFFER,i.COLOR_ATTACHMENT0+ht,i.RENDERBUFFER,X.__webglColorRenderbuffer[ht])}i.bindRenderbuffer(i.RENDERBUFFER,null),A.depthBuffer&&(X.__webglDepthRenderbuffer=i.createRenderbuffer(),Ct(X.__webglDepthRenderbuffer,A,!0)),e.bindFramebuffer(i.FRAMEBUFFER,null)}}if(lt){e.bindTexture(i.TEXTURE_CUBE_MAP,ut.__webglTexture),J(i.TEXTURE_CUBE_MAP,M,Et);for(let Mt=0;Mt<6;Mt++)if(a&&M.mipmaps&&M.mipmaps.length>0)for(let ht=0;ht<M.mipmaps.length;ht++)Nt(X.__webglFramebuffer[Mt][ht],A,M,i.COLOR_ATTACHMENT0,i.TEXTURE_CUBE_MAP_POSITIVE_X+Mt,ht);else Nt(X.__webglFramebuffer[Mt],A,M,i.COLOR_ATTACHMENT0,i.TEXTURE_CUBE_MAP_POSITIVE_X+Mt,0);C(M,Et)&&w(i.TEXTURE_CUBE_MAP),e.unbindTexture()}else if(st){let Mt=A.texture;for(let ht=0,Ot=Mt.length;ht<Ot;ht++){let Yt=Mt[ht],at=n.get(Yt);e.bindTexture(i.TEXTURE_2D,at.__webglTexture),J(i.TEXTURE_2D,Yt,Et),Nt(X.__webglFramebuffer,A,Yt,i.COLOR_ATTACHMENT0+ht,i.TEXTURE_2D,0),C(Yt,Et)&&w(i.TEXTURE_2D)}e.unbindTexture()}else{let Mt=i.TEXTURE_2D;if((A.isWebGL3DRenderTarget||A.isWebGLArrayRenderTarget)&&(a?Mt=A.isWebGL3DRenderTarget?i.TEXTURE_3D:i.TEXTURE_2D_ARRAY:console.error("THREE.WebGLTextures: THREE.Data3DTexture and THREE.DataArrayTexture only supported with WebGL2.")),e.bindTexture(Mt,ut.__webglTexture),J(Mt,M,Et),a&&M.mipmaps&&M.mipmaps.length>0)for(let ht=0;ht<M.mipmaps.length;ht++)Nt(X.__webglFramebuffer[ht],A,M,i.COLOR_ATTACHMENT0,Mt,ht);else Nt(X.__webglFramebuffer,A,M,i.COLOR_ATTACHMENT0,Mt,0);C(M,Et)&&w(Mt),e.unbindTexture()}A.depthBuffer&&Tt(A)}function Pe(A){let M=m(A)||a,X=A.isWebGLMultipleRenderTargets===!0?A.texture:[A.texture];for(let ut=0,lt=X.length;ut<lt;ut++){let st=X[ut];if(C(st,M)){let Et=A.isWebGLCubeRenderTarget?i.TEXTURE_CUBE_MAP:i.TEXTURE_2D,Mt=n.get(st).__webglTexture;e.bindTexture(Et,Mt),w(Et),e.unbindTexture()}}}function Dt(A){if(a&&A.samples>0&&Rt(A)===!1){let M=A.isWebGLMultipleRenderTargets?A.texture:[A.texture],X=A.width,ut=A.height,lt=i.COLOR_BUFFER_BIT,st=[],Et=A.stencilBuffer?i.DEPTH_STENCIL_ATTACHMENT:i.DEPTH_ATTACHMENT,Mt=n.get(A),ht=A.isWebGLMultipleRenderTargets===!0;if(ht)for(let Ot=0;Ot<M.length;Ot++)e.bindFramebuffer(i.FRAMEBUFFER,Mt.__webglMultisampledFramebuffer),i.framebufferRenderbuffer(i.FRAMEBUFFER,i.COLOR_ATTACHMENT0+Ot,i.RENDERBUFFER,null),e.bindFramebuffer(i.FRAMEBUFFER,Mt.__webglFramebuffer),i.framebufferTexture2D(i.DRAW_FRAMEBUFFER,i.COLOR_ATTACHMENT0+Ot,i.TEXTURE_2D,null,0);e.bindFramebuffer(i.READ_FRAMEBUFFER,Mt.__webglMultisampledFramebuffer),e.bindFramebuffer(i.DRAW_FRAMEBUFFER,Mt.__webglFramebuffer);for(let Ot=0;Ot<M.length;Ot++){st.push(i.COLOR_ATTACHMENT0+Ot),A.depthBuffer&&st.push(Et);let Yt=Mt.__ignoreDepthValues!==void 0?Mt.__ignoreDepthValues:!1;if(Yt===!1&&(A.depthBuffer&&(lt|=i.DEPTH_BUFFER_BIT),A.stencilBuffer&&(lt|=i.STENCIL_BUFFER_BIT)),ht&&i.framebufferRenderbuffer(i.READ_FRAMEBUFFER,i.COLOR_ATTACHMENT0,i.RENDERBUFFER,Mt.__webglColorRenderbuffer[Ot]),Yt===!0&&(i.invalidateFramebuffer(i.READ_FRAMEBUFFER,[Et]),i.invalidateFramebuffer(i.DRAW_FRAMEBUFFER,[Et])),ht){let at=n.get(M[Ot]).__webglTexture;i.framebufferTexture2D(i.DRAW_FRAMEBUFFER,i.COLOR_ATTACHMENT0,i.TEXTURE_2D,at,0)}i.blitFramebuffer(0,0,X,ut,0,0,X,ut,lt,i.NEAREST),c&&i.invalidateFramebuffer(i.READ_FRAMEBUFFER,st)}if(e.bindFramebuffer(i.READ_FRAMEBUFFER,null),e.bindFramebuffer(i.DRAW_FRAMEBUFFER,null),ht)for(let Ot=0;Ot<M.length;Ot++){e.bindFramebuffer(i.FRAMEBUFFER,Mt.__webglMultisampledFramebuffer),i.framebufferRenderbuffer(i.FRAMEBUFFER,i.COLOR_ATTACHMENT0+Ot,i.RENDERBUFFER,Mt.__webglColorRenderbuffer[Ot]);let Yt=n.get(M[Ot]).__webglTexture;e.bindFramebuffer(i.FRAMEBUFFER,Mt.__webglFramebuffer),i.framebufferTexture2D(i.DRAW_FRAMEBUFFER,i.COLOR_ATTACHMENT0+Ot,i.TEXTURE_2D,Yt,0)}e.bindFramebuffer(i.DRAW_FRAMEBUFFER,Mt.__webglMultisampledFramebuffer)}}function Gt(A){return Math.min(s.maxSamples,A.samples)}function Rt(A){let M=n.get(A);return a&&A.samples>0&&t.has("WEBGL_multisampled_render_to_texture")===!0&&M.__useRenderToTexture!==!1}function me(A){let M=o.render.frame;u.get(A)!==M&&(u.set(A,M),A.update())}function $t(A,M){let X=A.colorSpace,ut=A.format,lt=A.type;return A.isCompressedTexture===!0||A.isVideoTexture===!0||A.format===Wo||X!==si&&X!==Mn&&(fe.getTransfer(X)===ge?a===!1?t.has("EXT_sRGB")===!0&&ut===Un?(A.format=Wo,A.minFilter=yn,A.generateMipmaps=!1):M=fa.sRGBToLinear(M):(ut!==Un||lt!==yi)&&console.warn("THREE.WebGLTextures: sRGB encoded textures have to use RGBAFormat and UnsignedByteType."):console.error("THREE.WebGLTextures: Unsupported texture color space:",X)),M}this.allocateTextureUnit=I,this.resetTextureUnits=ft,this.setTexture2D=G,this.setTexture2DArray=K,this.setTexture3D=Q,this.setTextureCube=$,this.rebindTextures=kt,this.setupRenderTarget=W,this.updateRenderTargetMipmap=Pe,this.updateMultisampleRenderTarget=Dt,this.setupDepthRenderbuffer=Tt,this.setupFrameBufferTexture=Nt,this.useMultisampledRTT=Rt}function S0(i,t,e){let n=e.isWebGL2;function s(r,o=Mn){let a,l=fe.getTransfer(o);if(r===yi)return i.UNSIGNED_BYTE;if(r===Bh)return i.UNSIGNED_SHORT_4_4_4_4;if(r===zh)return i.UNSIGNED_SHORT_5_5_5_1;if(r===id)return i.BYTE;if(r===sd)return i.SHORT;if(r===Tl)return i.UNSIGNED_SHORT;if(r===Fh)return i.INT;if(r===gi)return i.UNSIGNED_INT;if(r===xi)return i.FLOAT;if(r===mn)return n?i.HALF_FLOAT:(a=t.get("OES_texture_half_float"),a!==null?a.HALF_FLOAT_OES:null);if(r===rd)return i.ALPHA;if(r===Un)return i.RGBA;if(r===ad)return i.LUMINANCE;if(r===od)return i.LUMINANCE_ALPHA;if(r===Gi)return i.DEPTH_COMPONENT;if(r===Is)return i.DEPTH_STENCIL;if(r===Wo)return a=t.get("EXT_sRGB"),a!==null?a.SRGB_ALPHA_EXT:null;if(r===ld)return i.RED;if(r===kh)return i.RED_INTEGER;if(r===cd)return i.RG;if(r===Hh)return i.RG_INTEGER;if(r===Vh)return i.RGBA_INTEGER;if(r===lo||r===co||r===ho||r===uo)if(l===ge)if(a=t.get("WEBGL_compressed_texture_s3tc_srgb"),a!==null){if(r===lo)return a.COMPRESSED_SRGB_S3TC_DXT1_EXT;if(r===co)return a.COMPRESSED_SRGB_ALPHA_S3TC_DXT1_EXT;if(r===ho)return a.COMPRESSED_SRGB_ALPHA_S3TC_DXT3_EXT;if(r===uo)return a.COMPRESSED_SRGB_ALPHA_S3TC_DXT5_EXT}else return null;else if(a=t.get("WEBGL_compressed_texture_s3tc"),a!==null){if(r===lo)return a.COMPRESSED_RGB_S3TC_DXT1_EXT;if(r===co)return a.COMPRESSED_RGBA_S3TC_DXT1_EXT;if(r===ho)return a.COMPRESSED_RGBA_S3TC_DXT3_EXT;if(r===uo)return a.COMPRESSED_RGBA_S3TC_DXT5_EXT}else return null;if(r===hc||r===uc||r===dc||r===fc)if(a=t.get("WEBGL_compressed_texture_pvrtc"),a!==null){if(r===hc)return a.COMPRESSED_RGB_PVRTC_4BPPV1_IMG;if(r===uc)return a.COMPRESSED_RGB_PVRTC_2BPPV1_IMG;if(r===dc)return a.COMPRESSED_RGBA_PVRTC_4BPPV1_IMG;if(r===fc)return a.COMPRESSED_RGBA_PVRTC_2BPPV1_IMG}else return null;if(r===Gh)return a=t.get("WEBGL_compressed_texture_etc1"),a!==null?a.COMPRESSED_RGB_ETC1_WEBGL:null;if(r===pc||r===mc)if(a=t.get("WEBGL_compressed_texture_etc"),a!==null){if(r===pc)return l===ge?a.COMPRESSED_SRGB8_ETC2:a.COMPRESSED_RGB8_ETC2;if(r===mc)return l===ge?a.COMPRESSED_SRGB8_ALPHA8_ETC2_EAC:a.COMPRESSED_RGBA8_ETC2_EAC}else return null;if(r===gc||r===xc||r===_c||r===vc||r===yc||r===Mc||r===bc||r===Sc||r===wc||r===Ec||r===Tc||r===Ac||r===Cc||r===Rc)if(a=t.get("WEBGL_compressed_texture_astc"),a!==null){if(r===gc)return l===ge?a.COMPRESSED_SRGB8_ALPHA8_ASTC_4x4_KHR:a.COMPRESSED_RGBA_ASTC_4x4_KHR;if(r===xc)return l===ge?a.COMPRESSED_SRGB8_ALPHA8_ASTC_5x4_KHR:a.COMPRESSED_RGBA_ASTC_5x4_KHR;if(r===_c)return l===ge?a.COMPRESSED_SRGB8_ALPHA8_ASTC_5x5_KHR:a.COMPRESSED_RGBA_ASTC_5x5_KHR;if(r===vc)return l===ge?a.COMPRESSED_SRGB8_ALPHA8_ASTC_6x5_KHR:a.COMPRESSED_RGBA_ASTC_6x5_KHR;if(r===yc)return l===ge?a.COMPRESSED_SRGB8_ALPHA8_ASTC_6x6_KHR:a.COMPRESSED_RGBA_ASTC_6x6_KHR;if(r===Mc)return l===ge?a.COMPRESSED_SRGB8_ALPHA8_ASTC_8x5_KHR:a.COMPRESSED_RGBA_ASTC_8x5_KHR;if(r===bc)return l===ge?a.COMPRESSED_SRGB8_ALPHA8_ASTC_8x6_KHR:a.COMPRESSED_RGBA_ASTC_8x6_KHR;if(r===Sc)return l===ge?a.COMPRESSED_SRGB8_ALPHA8_ASTC_8x8_KHR:a.COMPRESSED_RGBA_ASTC_8x8_KHR;if(r===wc)return l===ge?a.COMPRESSED_SRGB8_ALPHA8_ASTC_10x5_KHR:a.COMPRESSED_RGBA_ASTC_10x5_KHR;if(r===Ec)return l===ge?a.COMPRESSED_SRGB8_ALPHA8_ASTC_10x6_KHR:a.COMPRESSED_RGBA_ASTC_10x6_KHR;if(r===Tc)return l===ge?a.COMPRESSED_SRGB8_ALPHA8_ASTC_10x8_KHR:a.COMPRESSED_RGBA_ASTC_10x8_KHR;if(r===Ac)return l===ge?a.COMPRESSED_SRGB8_ALPHA8_ASTC_10x10_KHR:a.COMPRESSED_RGBA_ASTC_10x10_KHR;if(r===Cc)return l===ge?a.COMPRESSED_SRGB8_ALPHA8_ASTC_12x10_KHR:a.COMPRESSED_RGBA_ASTC_12x10_KHR;if(r===Rc)return l===ge?a.COMPRESSED_SRGB8_ALPHA8_ASTC_12x12_KHR:a.COMPRESSED_RGBA_ASTC_12x12_KHR}else return null;if(r===fo||r===Pc||r===Lc)if(a=t.get("EXT_texture_compression_bptc"),a!==null){if(r===fo)return l===ge?a.COMPRESSED_SRGB_ALPHA_BPTC_UNORM_EXT:a.COMPRESSED_RGBA_BPTC_UNORM_EXT;if(r===Pc)return a.COMPRESSED_RGB_BPTC_SIGNED_FLOAT_EXT;if(r===Lc)return a.COMPRESSED_RGB_BPTC_UNSIGNED_FLOAT_EXT}else return null;if(r===hd||r===Ic||r===Dc||r===Uc)if(a=t.get("EXT_texture_compression_rgtc"),a!==null){if(r===fo)return a.COMPRESSED_RED_RGTC1_EXT;if(r===Ic)return a.COMPRESSED_SIGNED_RED_RGTC1_EXT;if(r===Dc)return a.COMPRESSED_RED_GREEN_RGTC2_EXT;if(r===Uc)return a.COMPRESSED_SIGNED_RED_GREEN_RGTC2_EXT}else return null;return r===Vi?n?i.UNSIGNED_INT_24_8:(a=t.get("WEBGL_depth_texture"),a!==null?a.UNSIGNED_INT_24_8_WEBGL:null):i[r]!==void 0?i[r]:null}return{convert:s}}var sl=class extends en{constructor(t=[]){super(),this.isArrayCamera=!0,this.cameras=t}},_i=class extends rn{constructor(){super(),this.isGroup=!0,this.type="Group"}},w0={type:"move"},or=class{constructor(){this._targetRay=null,this._grip=null,this._hand=null}getHandSpace(){return this._hand===null&&(this._hand=new _i,this._hand.matrixAutoUpdate=!1,this._hand.visible=!1,this._hand.joints={},this._hand.inputState={pinching:!1}),this._hand}getTargetRaySpace(){return this._targetRay===null&&(this._targetRay=new _i,this._targetRay.matrixAutoUpdate=!1,this._targetRay.visible=!1,this._targetRay.hasLinearVelocity=!1,this._targetRay.linearVelocity=new F,this._targetRay.hasAngularVelocity=!1,this._targetRay.angularVelocity=new F),this._targetRay}getGripSpace(){return this._grip===null&&(this._grip=new _i,this._grip.matrixAutoUpdate=!1,this._grip.visible=!1,this._grip.hasLinearVelocity=!1,this._grip.linearVelocity=new F,this._grip.hasAngularVelocity=!1,this._grip.angularVelocity=new F),this._grip}dispatchEvent(t){return this._targetRay!==null&&this._targetRay.dispatchEvent(t),this._grip!==null&&this._grip.dispatchEvent(t),this._hand!==null&&this._hand.dispatchEvent(t),this}connect(t){if(t&&t.hand){let e=this._hand;if(e)for(let n of t.hand.values())this._getHandJoint(e,n)}return this.dispatchEvent({type:"connected",data:t}),this}disconnect(t){return this.dispatchEvent({type:"disconnected",data:t}),this._targetRay!==null&&(this._targetRay.visible=!1),this._grip!==null&&(this._grip.visible=!1),this._hand!==null&&(this._hand.visible=!1),this}update(t,e,n){let s=null,r=null,o=null,a=this._targetRay,l=this._grip,c=this._hand;if(t&&e.session.visibilityState!=="visible-blurred"){if(c&&t.hand){o=!0;for(let b of t.hand.values()){let m=e.getJointPose(b,n),d=this._getHandJoint(c,b);m!==null&&(d.matrix.fromArray(m.transform.matrix),d.matrix.decompose(d.position,d.rotation,d.scale),d.matrixWorldNeedsUpdate=!0,d.jointRadius=m.radius),d.visible=m!==null}let u=c.joints["index-finger-tip"],f=c.joints["thumb-tip"],p=u.position.distanceTo(f.position),x=.02,y=.005;c.inputState.pinching&&p>x+y?(c.inputState.pinching=!1,this.dispatchEvent({type:"pinchend",handedness:t.handedness,target:this})):!c.inputState.pinching&&p<=x-y&&(c.inputState.pinching=!0,this.dispatchEvent({type:"pinchstart",handedness:t.handedness,target:this}))}else l!==null&&t.gripSpace&&(r=e.getPose(t.gripSpace,n),r!==null&&(l.matrix.fromArray(r.transform.matrix),l.matrix.decompose(l.position,l.rotation,l.scale),l.matrixWorldNeedsUpdate=!0,r.linearVelocity?(l.hasLinearVelocity=!0,l.linearVelocity.copy(r.linearVelocity)):l.hasLinearVelocity=!1,r.angularVelocity?(l.hasAngularVelocity=!0,l.angularVelocity.copy(r.angularVelocity)):l.hasAngularVelocity=!1));a!==null&&(s=e.getPose(t.targetRaySpace,n),s===null&&r!==null&&(s=r),s!==null&&(a.matrix.fromArray(s.transform.matrix),a.matrix.decompose(a.position,a.rotation,a.scale),a.matrixWorldNeedsUpdate=!0,s.linearVelocity?(a.hasLinearVelocity=!0,a.linearVelocity.copy(s.linearVelocity)):a.hasLinearVelocity=!1,s.angularVelocity?(a.hasAngularVelocity=!0,a.angularVelocity.copy(s.angularVelocity)):a.hasAngularVelocity=!1,this.dispatchEvent(w0)))}return a!==null&&(a.visible=s!==null),l!==null&&(l.visible=r!==null),c!==null&&(c.visible=o!==null),this}_getHandJoint(t,e){if(t.joints[e.jointName]===void 0){let n=new _i;n.matrixAutoUpdate=!1,n.visible=!1,t.joints[e.jointName]=n,t.add(n)}return t.joints[e.jointName]}},rl=class extends Xn{constructor(t,e){super();let n=this,s=null,r=1,o=null,a="local-floor",l=1,c=null,u=null,f=null,p=null,x=null,y=null,b=e.getContextAttributes(),m=null,d=null,C=[],w=[],U=new Pt,z=null,N=new en;N.layers.enable(1),N.viewport=new we;let L=new en;L.layers.enable(2),L.viewport=new we;let j=[N,L],S=new sl;S.layers.enable(1),S.layers.enable(2);let R=null,V=null;this.cameraAutoUpdate=!0,this.enabled=!1,this.isPresenting=!1,this.getController=function(J){let ot=C[J];return ot===void 0&&(ot=new or,C[J]=ot),ot.getTargetRaySpace()},this.getControllerGrip=function(J){let ot=C[J];return ot===void 0&&(ot=new or,C[J]=ot),ot.getGripSpace()},this.getHand=function(J){let ot=C[J];return ot===void 0&&(ot=new or,C[J]=ot),ot.getHandSpace()};function tt(J){let ot=w.indexOf(J.inputSource);if(ot===-1)return;let vt=C[ot];vt!==void 0&&(vt.update(J.inputSource,J.frame,c||o),vt.dispatchEvent({type:J.type,data:J.inputSource}))}function ft(){s.removeEventListener("select",tt),s.removeEventListener("selectstart",tt),s.removeEventListener("selectend",tt),s.removeEventListener("squeeze",tt),s.removeEventListener("squeezestart",tt),s.removeEventListener("squeezeend",tt),s.removeEventListener("end",ft),s.removeEventListener("inputsourceschange",I);for(let J=0;J<C.length;J++){let ot=w[J];ot!==null&&(w[J]=null,C[J].disconnect(ot))}R=null,V=null,t.setRenderTarget(m),x=null,p=null,f=null,s=null,d=null,bt.stop(),n.isPresenting=!1,t.setPixelRatio(z),t.setSize(U.width,U.height,!1),n.dispatchEvent({type:"sessionend"})}this.setFramebufferScaleFactor=function(J){r=J,n.isPresenting===!0&&console.warn("THREE.WebXRManager: Cannot change framebuffer scale while presenting.")},this.setReferenceSpaceType=function(J){a=J,n.isPresenting===!0&&console.warn("THREE.WebXRManager: Cannot change reference space type while presenting.")},this.getReferenceSpace=function(){return c||o},this.setReferenceSpace=function(J){c=J},this.getBaseLayer=function(){return p!==null?p:x},this.getBinding=function(){return f},this.getFrame=function(){return y},this.getSession=function(){return s},this.setSession=async function(J){if(s=J,s!==null){if(m=t.getRenderTarget(),s.addEventListener("select",tt),s.addEventListener("selectstart",tt),s.addEventListener("selectend",tt),s.addEventListener("squeeze",tt),s.addEventListener("squeezestart",tt),s.addEventListener("squeezeend",tt),s.addEventListener("end",ft),s.addEventListener("inputsourceschange",I),b.xrCompatible!==!0&&await e.makeXRCompatible(),z=t.getPixelRatio(),t.getSize(U),s.renderState.layers===void 0||t.capabilities.isWebGL2===!1){let ot={antialias:s.renderState.layers===void 0?b.antialias:!0,alpha:!0,depth:b.depth,stencil:b.stencil,framebufferScaleFactor:r};x=new XRWebGLLayer(s,e,ot),s.updateRenderState({baseLayer:x}),t.setPixelRatio(1),t.setSize(x.framebufferWidth,x.framebufferHeight,!1),d=new je(x.framebufferWidth,x.framebufferHeight,{format:Un,type:yi,colorSpace:t.outputColorSpace,stencilBuffer:b.stencil})}else{let ot=null,vt=null,Lt=null;b.depth&&(Lt=b.stencil?e.DEPTH24_STENCIL8:e.DEPTH_COMPONENT24,ot=b.stencil?Is:Gi,vt=b.stencil?Vi:gi);let Nt={colorFormat:e.RGBA8,depthFormat:Lt,scaleFactor:r};f=new XRWebGLBinding(s,e),p=f.createProjectionLayer(Nt),s.updateRenderState({layers:[p]}),t.setPixelRatio(1),t.setSize(p.textureWidth,p.textureHeight,!1),d=new je(p.textureWidth,p.textureHeight,{format:Un,type:yi,depthTexture:new ba(p.textureWidth,p.textureHeight,vt,void 0,void 0,void 0,void 0,void 0,void 0,ot),stencilBuffer:b.stencil,colorSpace:t.outputColorSpace,samples:b.antialias?4:0});let Ct=t.properties.get(d);Ct.__ignoreDepthValues=p.ignoreDepthValues}d.isXRRenderTarget=!0,this.setFoveation(l),c=null,o=await s.requestReferenceSpace(a),bt.setContext(s),bt.start(),n.isPresenting=!0,n.dispatchEvent({type:"sessionstart"})}},this.getEnvironmentBlendMode=function(){if(s!==null)return s.environmentBlendMode};function I(J){for(let ot=0;ot<J.removed.length;ot++){let vt=J.removed[ot],Lt=w.indexOf(vt);Lt>=0&&(w[Lt]=null,C[Lt].disconnect(vt))}for(let ot=0;ot<J.added.length;ot++){let vt=J.added[ot],Lt=w.indexOf(vt);if(Lt===-1){for(let Ct=0;Ct<C.length;Ct++)if(Ct>=w.length){w.push(vt),Lt=Ct;break}else if(w[Ct]===null){w[Ct]=vt,Lt=Ct;break}if(Lt===-1)break}let Nt=C[Lt];Nt&&Nt.connect(vt)}}let k=new F,G=new F;function K(J,ot,vt){k.setFromMatrixPosition(ot.matrixWorld),G.setFromMatrixPosition(vt.matrixWorld);let Lt=k.distanceTo(G),Nt=ot.projectionMatrix.elements,Ct=vt.projectionMatrix.elements,It=Nt[14]/(Nt[10]-1),Tt=Nt[14]/(Nt[10]+1),kt=(Nt[9]+1)/Nt[5],W=(Nt[9]-1)/Nt[5],Pe=(Nt[8]-1)/Nt[0],Dt=(Ct[8]+1)/Ct[0],Gt=It*Pe,Rt=It*Dt,me=Lt/(-Pe+Dt),$t=me*-Pe;ot.matrixWorld.decompose(J.position,J.quaternion,J.scale),J.translateX($t),J.translateZ(me),J.matrixWorld.compose(J.position,J.quaternion,J.scale),J.matrixWorldInverse.copy(J.matrixWorld).invert();let A=It+me,M=Tt+me,X=Gt-$t,ut=Rt+(Lt-$t),lt=kt*Tt/M*A,st=W*Tt/M*A;J.projectionMatrix.makePerspective(X,ut,lt,st,A,M),J.projectionMatrixInverse.copy(J.projectionMatrix).invert()}function Q(J,ot){ot===null?J.matrixWorld.copy(J.matrix):J.matrixWorld.multiplyMatrices(ot.matrixWorld,J.matrix),J.matrixWorldInverse.copy(J.matrixWorld).invert()}this.updateCamera=function(J){if(s===null)return;S.near=L.near=N.near=J.near,S.far=L.far=N.far=J.far,(R!==S.near||V!==S.far)&&(s.updateRenderState({depthNear:S.near,depthFar:S.far}),R=S.near,V=S.far);let ot=J.parent,vt=S.cameras;Q(S,ot);for(let Lt=0;Lt<vt.length;Lt++)Q(vt[Lt],ot);vt.length===2?K(S,N,L):S.projectionMatrix.copy(N.projectionMatrix),$(J,S,ot)};function $(J,ot,vt){vt===null?J.matrix.copy(ot.matrixWorld):(J.matrix.copy(vt.matrixWorld),J.matrix.invert(),J.matrix.multiply(ot.matrixWorld)),J.matrix.decompose(J.position,J.quaternion,J.scale),J.updateMatrixWorld(!0),J.projectionMatrix.copy(ot.projectionMatrix),J.projectionMatrixInverse.copy(ot.projectionMatrixInverse),J.isPerspectiveCamera&&(J.fov=hr*2*Math.atan(1/J.projectionMatrix.elements[5]),J.zoom=1)}this.getCamera=function(){return S},this.getFoveation=function(){if(!(p===null&&x===null))return l},this.setFoveation=function(J){l=J,p!==null&&(p.fixedFoveation=J),x!==null&&x.fixedFoveation!==void 0&&(x.fixedFoveation=J)};let nt=null;function ct(J,ot){if(u=ot.getViewerPose(c||o),y=ot,u!==null){let vt=u.views;x!==null&&(t.setRenderTargetFramebuffer(d,x.framebuffer),t.setRenderTarget(d));let Lt=!1;vt.length!==S.cameras.length&&(S.cameras.length=0,Lt=!0);for(let Nt=0;Nt<vt.length;Nt++){let Ct=vt[Nt],It=null;if(x!==null)It=x.getViewport(Ct);else{let kt=f.getViewSubImage(p,Ct);It=kt.viewport,Nt===0&&(t.setRenderTargetTextures(d,kt.colorTexture,p.ignoreDepthValues?void 0:kt.depthStencilTexture),t.setRenderTarget(d))}let Tt=j[Nt];Tt===void 0&&(Tt=new en,Tt.layers.enable(Nt),Tt.viewport=new we,j[Nt]=Tt),Tt.matrix.fromArray(Ct.transform.matrix),Tt.matrix.decompose(Tt.position,Tt.quaternion,Tt.scale),Tt.projectionMatrix.fromArray(Ct.projectionMatrix),Tt.projectionMatrixInverse.copy(Tt.projectionMatrix).invert(),Tt.viewport.set(It.x,It.y,It.width,It.height),Nt===0&&(S.matrix.copy(Tt.matrix),S.matrix.decompose(S.position,S.quaternion,S.scale)),Lt===!0&&S.cameras.push(Tt)}}for(let vt=0;vt<C.length;vt++){let Lt=w[vt],Nt=C[vt];Lt!==null&&Nt!==void 0&&Nt.update(Lt,ot,c||o)}nt&&nt(J,ot),ot.detectedPlanes&&n.dispatchEvent({type:"planesdetected",data:ot}),y=null}let bt=new jh;bt.setAnimationLoop(ct),this.setAnimationLoop=function(J){nt=J},this.dispose=function(){}}};function E0(i,t){function e(m,d){m.matrixAutoUpdate===!0&&m.updateMatrix(),d.value.copy(m.matrix)}function n(m,d){d.color.getRGB(m.fogColor.value,$h(i)),d.isFog?(m.fogNear.value=d.near,m.fogFar.value=d.far):d.isFogExp2&&(m.fogDensity.value=d.density)}function s(m,d,C,w,U){d.isMeshBasicMaterial||d.isMeshLambertMaterial?r(m,d):d.isMeshToonMaterial?(r(m,d),f(m,d)):d.isMeshPhongMaterial?(r(m,d),u(m,d)):d.isMeshStandardMaterial?(r(m,d),p(m,d),d.isMeshPhysicalMaterial&&x(m,d,U)):d.isMeshMatcapMaterial?(r(m,d),y(m,d)):d.isMeshDepthMaterial?r(m,d):d.isMeshDistanceMaterial?(r(m,d),b(m,d)):d.isMeshNormalMaterial?r(m,d):d.isLineBasicMaterial?(o(m,d),d.isLineDashedMaterial&&a(m,d)):d.isPointsMaterial?l(m,d,C,w):d.isSpriteMaterial?c(m,d):d.isShadowMaterial?(m.color.value.copy(d.color),m.opacity.value=d.opacity):d.isShaderMaterial&&(d.uniformsNeedUpdate=!1)}function r(m,d){m.opacity.value=d.opacity,d.color&&m.diffuse.value.copy(d.color),d.emissive&&m.emissive.value.copy(d.emissive).multiplyScalar(d.emissiveIntensity),d.map&&(m.map.value=d.map,e(d.map,m.mapTransform)),d.alphaMap&&(m.alphaMap.value=d.alphaMap,e(d.alphaMap,m.alphaMapTransform)),d.bumpMap&&(m.bumpMap.value=d.bumpMap,e(d.bumpMap,m.bumpMapTransform),m.bumpScale.value=d.bumpScale,d.side===nn&&(m.bumpScale.value*=-1)),d.normalMap&&(m.normalMap.value=d.normalMap,e(d.normalMap,m.normalMapTransform),m.normalScale.value.copy(d.normalScale),d.side===nn&&m.normalScale.value.negate()),d.displacementMap&&(m.displacementMap.value=d.displacementMap,e(d.displacementMap,m.displacementMapTransform),m.displacementScale.value=d.displacementScale,m.displacementBias.value=d.displacementBias),d.emissiveMap&&(m.emissiveMap.value=d.emissiveMap,e(d.emissiveMap,m.emissiveMapTransform)),d.specularMap&&(m.specularMap.value=d.specularMap,e(d.specularMap,m.specularMapTransform)),d.alphaTest>0&&(m.alphaTest.value=d.alphaTest);let C=t.get(d).envMap;if(C&&(m.envMap.value=C,m.flipEnvMap.value=C.isCubeTexture&&C.isRenderTargetTexture===!1?-1:1,m.reflectivity.value=d.reflectivity,m.ior.value=d.ior,m.refractionRatio.value=d.refractionRatio),d.lightMap){m.lightMap.value=d.lightMap;let w=i._useLegacyLights===!0?Math.PI:1;m.lightMapIntensity.value=d.lightMapIntensity*w,e(d.lightMap,m.lightMapTransform)}d.aoMap&&(m.aoMap.value=d.aoMap,m.aoMapIntensity.value=d.aoMapIntensity,e(d.aoMap,m.aoMapTransform))}function o(m,d){m.diffuse.value.copy(d.color),m.opacity.value=d.opacity,d.map&&(m.map.value=d.map,e(d.map,m.mapTransform))}function a(m,d){m.dashSize.value=d.dashSize,m.totalSize.value=d.dashSize+d.gapSize,m.scale.value=d.scale}function l(m,d,C,w){m.diffuse.value.copy(d.color),m.opacity.value=d.opacity,m.size.value=d.size*C,m.scale.value=w*.5,d.map&&(m.map.value=d.map,e(d.map,m.uvTransform)),d.alphaMap&&(m.alphaMap.value=d.alphaMap,e(d.alphaMap,m.alphaMapTransform)),d.alphaTest>0&&(m.alphaTest.value=d.alphaTest)}function c(m,d){m.diffuse.value.copy(d.color),m.opacity.value=d.opacity,m.rotation.value=d.rotation,d.map&&(m.map.value=d.map,e(d.map,m.mapTransform)),d.alphaMap&&(m.alphaMap.value=d.alphaMap,e(d.alphaMap,m.alphaMapTransform)),d.alphaTest>0&&(m.alphaTest.value=d.alphaTest)}function u(m,d){m.specular.value.copy(d.specular),m.shininess.value=Math.max(d.shininess,1e-4)}function f(m,d){d.gradientMap&&(m.gradientMap.value=d.gradientMap)}function p(m,d){m.metalness.value=d.metalness,d.metalnessMap&&(m.metalnessMap.value=d.metalnessMap,e(d.metalnessMap,m.metalnessMapTransform)),m.roughness.value=d.roughness,d.roughnessMap&&(m.roughnessMap.value=d.roughnessMap,e(d.roughnessMap,m.roughnessMapTransform)),t.get(d).envMap&&(m.envMapIntensity.value=d.envMapIntensity)}function x(m,d,C){m.ior.value=d.ior,d.sheen>0&&(m.sheenColor.value.copy(d.sheenColor).multiplyScalar(d.sheen),m.sheenRoughness.value=d.sheenRoughness,d.sheenColorMap&&(m.sheenColorMap.value=d.sheenColorMap,e(d.sheenColorMap,m.sheenColorMapTransform)),d.sheenRoughnessMap&&(m.sheenRoughnessMap.value=d.sheenRoughnessMap,e(d.sheenRoughnessMap,m.sheenRoughnessMapTransform))),d.clearcoat>0&&(m.clearcoat.value=d.clearcoat,m.clearcoatRoughness.value=d.clearcoatRoughness,d.clearcoatMap&&(m.clearcoatMap.value=d.clearcoatMap,e(d.clearcoatMap,m.clearcoatMapTransform)),d.clearcoatRoughnessMap&&(m.clearcoatRoughnessMap.value=d.clearcoatRoughnessMap,e(d.clearcoatRoughnessMap,m.clearcoatRoughnessMapTransform)),d.clearcoatNormalMap&&(m.clearcoatNormalMap.value=d.clearcoatNormalMap,e(d.clearcoatNormalMap,m.clearcoatNormalMapTransform),m.clearcoatNormalScale.value.copy(d.clearcoatNormalScale),d.side===nn&&m.clearcoatNormalScale.value.negate())),d.iridescence>0&&(m.iridescence.value=d.iridescence,m.iridescenceIOR.value=d.iridescenceIOR,m.iridescenceThicknessMinimum.value=d.iridescenceThicknessRange[0],m.iridescenceThicknessMaximum.value=d.iridescenceThicknessRange[1],d.iridescenceMap&&(m.iridescenceMap.value=d.iridescenceMap,e(d.iridescenceMap,m.iridescenceMapTransform)),d.iridescenceThicknessMap&&(m.iridescenceThicknessMap.value=d.iridescenceThicknessMap,e(d.iridescenceThicknessMap,m.iridescenceThicknessMapTransform))),d.transmission>0&&(m.transmission.value=d.transmission,m.transmissionSamplerMap.value=C.texture,m.transmissionSamplerSize.value.set(C.width,C.height),d.transmissionMap&&(m.transmissionMap.value=d.transmissionMap,e(d.transmissionMap,m.transmissionMapTransform)),m.thickness.value=d.thickness,d.thicknessMap&&(m.thicknessMap.value=d.thicknessMap,e(d.thicknessMap,m.thicknessMapTransform)),m.attenuationDistance.value=d.attenuationDistance,m.attenuationColor.value.copy(d.attenuationColor)),d.anisotropy>0&&(m.anisotropyVector.value.set(d.anisotropy*Math.cos(d.anisotropyRotation),d.anisotropy*Math.sin(d.anisotropyRotation)),d.anisotropyMap&&(m.anisotropyMap.value=d.anisotropyMap,e(d.anisotropyMap,m.anisotropyMapTransform))),m.specularIntensity.value=d.specularIntensity,m.specularColor.value.copy(d.specularColor),d.specularColorMap&&(m.specularColorMap.value=d.specularColorMap,e(d.specularColorMap,m.specularColorMapTransform)),d.specularIntensityMap&&(m.specularIntensityMap.value=d.specularIntensityMap,e(d.specularIntensityMap,m.specularIntensityMapTransform))}function y(m,d){d.matcap&&(m.matcap.value=d.matcap)}function b(m,d){let C=t.get(d).light;m.referencePosition.value.setFromMatrixPosition(C.matrixWorld),m.nearDistance.value=C.shadow.camera.near,m.farDistance.value=C.shadow.camera.far}return{refreshFogUniforms:n,refreshMaterialUniforms:s}}function T0(i,t,e,n){let s={},r={},o=[],a=e.isWebGL2?i.getParameter(i.MAX_UNIFORM_BUFFER_BINDINGS):0;function l(C,w){let U=w.program;n.uniformBlockBinding(C,U)}function c(C,w){let U=s[C.id];U===void 0&&(y(C),U=u(C),s[C.id]=U,C.addEventListener("dispose",m));let z=w.program;n.updateUBOMapping(C,z);let N=t.render.frame;r[C.id]!==N&&(p(C),r[C.id]=N)}function u(C){let w=f();C.__bindingPointIndex=w;let U=i.createBuffer(),z=C.__size,N=C.usage;return i.bindBuffer(i.UNIFORM_BUFFER,U),i.bufferData(i.UNIFORM_BUFFER,z,N),i.bindBuffer(i.UNIFORM_BUFFER,null),i.bindBufferBase(i.UNIFORM_BUFFER,w,U),U}function f(){for(let C=0;C<a;C++)if(o.indexOf(C)===-1)return o.push(C),C;return console.error("THREE.WebGLRenderer: Maximum number of simultaneously usable uniforms groups reached."),0}function p(C){let w=s[C.id],U=C.uniforms,z=C.__cache;i.bindBuffer(i.UNIFORM_BUFFER,w);for(let N=0,L=U.length;N<L;N++){let j=Array.isArray(U[N])?U[N]:[U[N]];for(let S=0,R=j.length;S<R;S++){let V=j[S];if(x(V,N,S,z)===!0){let tt=V.__offset,ft=Array.isArray(V.value)?V.value:[V.value],I=0;for(let k=0;k<ft.length;k++){let G=ft[k],K=b(G);typeof G=="number"||typeof G=="boolean"?(V.__data[0]=G,i.bufferSubData(i.UNIFORM_BUFFER,tt+I,V.__data)):G.isMatrix3?(V.__data[0]=G.elements[0],V.__data[1]=G.elements[1],V.__data[2]=G.elements[2],V.__data[3]=0,V.__data[4]=G.elements[3],V.__data[5]=G.elements[4],V.__data[6]=G.elements[5],V.__data[7]=0,V.__data[8]=G.elements[6],V.__data[9]=G.elements[7],V.__data[10]=G.elements[8],V.__data[11]=0):(G.toArray(V.__data,I),I+=K.storage/Float32Array.BYTES_PER_ELEMENT)}i.bufferSubData(i.UNIFORM_BUFFER,tt,V.__data)}}}i.bindBuffer(i.UNIFORM_BUFFER,null)}function x(C,w,U,z){let N=C.value,L=w+"_"+U;if(z[L]===void 0)return typeof N=="number"||typeof N=="boolean"?z[L]=N:z[L]=N.clone(),!0;{let j=z[L];if(typeof N=="number"||typeof N=="boolean"){if(j!==N)return z[L]=N,!0}else if(j.equals(N)===!1)return j.copy(N),!0}return!1}function y(C){let w=C.uniforms,U=0,z=16;for(let L=0,j=w.length;L<j;L++){let S=Array.isArray(w[L])?w[L]:[w[L]];for(let R=0,V=S.length;R<V;R++){let tt=S[R],ft=Array.isArray(tt.value)?tt.value:[tt.value];for(let I=0,k=ft.length;I<k;I++){let G=ft[I],K=b(G),Q=U%z;Q!==0&&z-Q<K.boundary&&(U+=z-Q),tt.__data=new Float32Array(K.storage/Float32Array.BYTES_PER_ELEMENT),tt.__offset=U,U+=K.storage}}}let N=U%z;return N>0&&(U+=z-N),C.__size=U,C.__cache={},this}function b(C){let w={boundary:0,storage:0};return typeof C=="number"||typeof C=="boolean"?(w.boundary=4,w.storage=4):C.isVector2?(w.boundary=8,w.storage=8):C.isVector3||C.isColor?(w.boundary=16,w.storage=12):C.isVector4?(w.boundary=16,w.storage=16):C.isMatrix3?(w.boundary=48,w.storage=48):C.isMatrix4?(w.boundary=64,w.storage=64):C.isTexture?console.warn("THREE.WebGLRenderer: Texture samplers can not be part of an uniforms group."):console.warn("THREE.WebGLRenderer: Unsupported uniform value type.",C),w}function m(C){let w=C.target;w.removeEventListener("dispose",m);let U=o.indexOf(w.__bindingPointIndex);o.splice(U,1),i.deleteBuffer(s[w.id]),delete s[w.id],delete r[w.id]}function d(){for(let C in s)i.deleteBuffer(s[C]);o=[],s={},r={}}return{bind:l,update:c,dispose:d}}var pr=class{constructor(t={}){let{canvas:e=Nd(),context:n=null,depth:s=!0,stencil:r=!0,alpha:o=!1,antialias:a=!1,premultipliedAlpha:l=!0,preserveDrawingBuffer:c=!1,powerPreference:u="default",failIfMajorPerformanceCaveat:f=!1}=t;this.isWebGLRenderer=!0;let p;n!==null?p=n.getContextAttributes().alpha:p=o;let x=new Uint32Array(4),y=new Int32Array(4),b=null,m=null,d=[],C=[];this.domElement=e,this.debug={checkShaderErrors:!0,onShaderError:null},this.autoClear=!0,this.autoClearColor=!0,this.autoClearDepth=!0,this.autoClearStencil=!0,this.sortObjects=!0,this.clippingPlanes=[],this.localClippingEnabled=!1,this._outputColorSpace=Re,this._useLegacyLights=!1,this.toneMapping=vi,this.toneMappingExposure=1;let w=this,U=!1,z=0,N=0,L=null,j=-1,S=null,R=new we,V=new we,tt=null,ft=new qt(0),I=0,k=e.width,G=e.height,K=1,Q=null,$=null,nt=new we(0,0,k,G),ct=new we(0,0,k,G),bt=!1,J=new dr,ot=!1,vt=!1,Lt=null,Nt=new ve,Ct=new Pt,It=new F,Tt={background:null,fog:null,environment:null,overrideMaterial:null,isScene:!0};function kt(){return L===null?K:1}let W=n;function Pe(E,H){for(let Y=0;Y<E.length;Y++){let Z=E[Y],q=e.getContext(Z,H);if(q!==null)return q}return null}try{let E={alpha:!0,depth:s,stencil:r,antialias:a,premultipliedAlpha:l,preserveDrawingBuffer:c,powerPreference:u,failIfMajorPerformanceCaveat:f};if("setAttribute"in e&&e.setAttribute("data-engine","three.js r160"),e.addEventListener("webglcontextlost",_t,!1),e.addEventListener("webglcontextrestored",O,!1),e.addEventListener("webglcontextcreationerror",gt,!1),W===null){let H=["webgl2","webgl","experimental-webgl"];if(w.isWebGL1Renderer===!0&&H.shift(),W=Pe(H,E),W===null)throw Pe(H)?new Error("Error creating WebGL context with your selected attributes."):new Error("Error creating WebGL context.")}typeof WebGLRenderingContext<"u"&&W instanceof WebGLRenderingContext&&console.warn("THREE.WebGLRenderer: WebGL 1 support was deprecated in r153 and will be removed in r163."),W.getShaderPrecisionFormat===void 0&&(W.getShaderPrecisionFormat=function(){return{rangeMin:1,rangeMax:1,precision:1}})}catch(E){throw console.error("THREE.WebGLRenderer: "+E.message),E}let Dt,Gt,Rt,me,$t,A,M,X,ut,lt,st,Et,Mt,ht,Ot,Yt,at,se,P,rt,mt,pt,Ut,Qt;function ee(){Dt=new Xm(W),Gt=new zm(W,Dt,t),Dt.init(Gt),pt=new S0(W,Dt,Gt),Rt=new M0(W,Dt,Gt),me=new Zm(W),$t=new c0,A=new b0(W,Dt,Rt,$t,Gt,pt,me),M=new Hm(w),X=new Wm(w),ut=new ef(W,Gt),Ut=new Fm(W,Dt,ut,Gt),lt=new Ym(W,ut,me,Ut),st=new Km(W,lt,ut,me),P=new jm(W,Gt,A),Yt=new km($t),Et=new l0(w,M,X,Dt,Gt,Ut,Yt),Mt=new E0(w,$t),ht=new u0,Ot=new x0(Dt,Gt),se=new Om(w,M,X,Rt,st,p,l),at=new y0(w,st,Gt),Qt=new T0(W,me,Gt,Rt),rt=new Bm(W,Dt,me,Gt),mt=new qm(W,Dt,me,Gt),me.programs=Et.programs,w.capabilities=Gt,w.extensions=Dt,w.properties=$t,w.renderLists=ht,w.shadowMap=at,w.state=Rt,w.info=me}ee();let Kt=new rl(w,W);this.xr=Kt,this.getContext=function(){return W},this.getContextAttributes=function(){return W.getContextAttributes()},this.forceContextLoss=function(){let E=Dt.get("WEBGL_lose_context");E&&E.loseContext()},this.forceContextRestore=function(){let E=Dt.get("WEBGL_lose_context");E&&E.restoreContext()},this.getPixelRatio=function(){return K},this.setPixelRatio=function(E){E!==void 0&&(K=E,this.setSize(k,G,!1))},this.getSize=function(E){return E.set(k,G)},this.setSize=function(E,H,Y=!0){if(Kt.isPresenting){console.warn("THREE.WebGLRenderer: Can't change size while VR device is presenting.");return}k=E,G=H,e.width=Math.floor(E*K),e.height=Math.floor(H*K),Y===!0&&(e.style.width=E+"px",e.style.height=H+"px"),this.setViewport(0,0,E,H)},this.getDrawingBufferSize=function(E){return E.set(k*K,G*K).floor()},this.setDrawingBufferSize=function(E,H,Y){k=E,G=H,K=Y,e.width=Math.floor(E*Y),e.height=Math.floor(H*Y),this.setViewport(0,0,E,H)},this.getCurrentViewport=function(E){return E.copy(R)},this.getViewport=function(E){return E.copy(nt)},this.setViewport=function(E,H,Y,Z){E.isVector4?nt.set(E.x,E.y,E.z,E.w):nt.set(E,H,Y,Z),Rt.viewport(R.copy(nt).multiplyScalar(K).floor())},this.getScissor=function(E){return E.copy(ct)},this.setScissor=function(E,H,Y,Z){E.isVector4?ct.set(E.x,E.y,E.z,E.w):ct.set(E,H,Y,Z),Rt.scissor(V.copy(ct).multiplyScalar(K).floor())},this.getScissorTest=function(){return bt},this.setScissorTest=function(E){Rt.setScissorTest(bt=E)},this.setOpaqueSort=function(E){Q=E},this.setTransparentSort=function(E){$=E},this.getClearColor=function(E){return E.copy(se.getClearColor())},this.setClearColor=function(){se.setClearColor.apply(se,arguments)},this.getClearAlpha=function(){return se.getClearAlpha()},this.setClearAlpha=function(){se.setClearAlpha.apply(se,arguments)},this.clear=function(E=!0,H=!0,Y=!0){let Z=0;if(E){let q=!1;if(L!==null){let wt=L.texture.format;q=wt===Vh||wt===Hh||wt===kh}if(q){let wt=L.texture.type,Bt=wt===yi||wt===gi||wt===Tl||wt===Vi||wt===Bh||wt===zh,Xt=se.getClearColor(),Zt=se.getClearAlpha(),Vt=Xt.r,Wt=Xt.g,Jt=Xt.b;Bt?(x[0]=Vt,x[1]=Wt,x[2]=Jt,x[3]=Zt,W.clearBufferuiv(W.COLOR,0,x)):(y[0]=Vt,y[1]=Wt,y[2]=Jt,y[3]=Zt,W.clearBufferiv(W.COLOR,0,y))}else Z|=W.COLOR_BUFFER_BIT}H&&(Z|=W.DEPTH_BUFFER_BIT),Y&&(Z|=W.STENCIL_BUFFER_BIT,this.state.buffers.stencil.setMask(4294967295)),W.clear(Z)},this.clearColor=function(){this.clear(!0,!1,!1)},this.clearDepth=function(){this.clear(!1,!0,!1)},this.clearStencil=function(){this.clear(!1,!1,!0)},this.dispose=function(){e.removeEventListener("webglcontextlost",_t,!1),e.removeEventListener("webglcontextrestored",O,!1),e.removeEventListener("webglcontextcreationerror",gt,!1),ht.dispose(),Ot.dispose(),$t.dispose(),M.dispose(),X.dispose(),st.dispose(),Ut.dispose(),Qt.dispose(),Et.dispose(),Kt.dispose(),Kt.removeEventListener("sessionstart",_e),Kt.removeEventListener("sessionend",pe),Lt&&(Lt.dispose(),Lt=null),Ge.stop()};function _t(E){E.preventDefault(),console.log("THREE.WebGLRenderer: Context Lost."),U=!0}function O(){console.log("THREE.WebGLRenderer: Context Restored."),U=!1;let E=me.autoReset,H=at.enabled,Y=at.autoUpdate,Z=at.needsUpdate,q=at.type;ee(),me.autoReset=E,at.enabled=H,at.autoUpdate=Y,at.needsUpdate=Z,at.type=q}function gt(E){console.error("THREE.WebGLRenderer: A WebGL context could not be created. Reason: ",E.statusMessage)}function xt(E){let H=E.target;H.removeEventListener("dispose",xt),Ht(H)}function Ht(E){Ft(E),$t.remove(E)}function Ft(E){let H=$t.get(E).programs;H!==void 0&&(H.forEach(function(Y){Et.releaseProgram(Y)}),E.isShaderMaterial&&Et.releaseShaderCache(E))}this.renderBufferDirect=function(E,H,Y,Z,q,wt){H===null&&(H=Tt);let Bt=q.isMesh&&q.matrixWorld.determinant()<0,Xt=Xa(E,H,Y,Z,q);Rt.setMaterial(Z,Bt);let Zt=Y.index,Vt=1;if(Z.wireframe===!0){if(Zt=lt.getWireframeAttribute(Y),Zt===void 0)return;Vt=2}let Wt=Y.drawRange,Jt=Y.attributes.position,ue=Wt.start*Vt,Le=(Wt.start+Wt.count)*Vt;wt!==null&&(ue=Math.max(ue,wt.start*Vt),Le=Math.min(Le,(wt.start+wt.count)*Vt)),Zt!==null?(ue=Math.max(ue,0),Le=Math.min(Le,Zt.count)):Jt!=null&&(ue=Math.max(ue,0),Le=Math.min(Le,Jt.count));let Ee=Le-ue;if(Ee<0||Ee===1/0)return;Ut.setup(q,Z,Xt,Y,Zt);let Sn,xe=rt;if(Zt!==null&&(Sn=ut.get(Zt),xe=mt,xe.setIndex(Sn)),q.isMesh)Z.wireframe===!0?(Rt.setLineWidth(Z.wireframeLinewidth*kt()),xe.setMode(W.LINES)):xe.setMode(W.TRIANGLES);else if(q.isLine){let jt=Z.linewidth;jt===void 0&&(jt=1),Rt.setLineWidth(jt*kt()),q.isLineSegments?xe.setMode(W.LINES):q.isLineLoop?xe.setMode(W.LINE_LOOP):xe.setMode(W.LINE_STRIP)}else q.isPoints?xe.setMode(W.POINTS):q.isSprite&&xe.setMode(W.TRIANGLES);if(q.isBatchedMesh)xe.renderMultiDraw(q._multiDrawStarts,q._multiDrawCounts,q._multiDrawCount);else if(q.isInstancedMesh)xe.renderInstances(ue,Ee,q.count);else if(Y.isInstancedBufferGeometry){let jt=Y._maxInstanceCount!==void 0?Y._maxInstanceCount:1/0,qn=Math.min(Y.instanceCount,jt);xe.renderInstances(ue,Ee,qn)}else xe.render(ue,Ee)};function ce(E,H,Y){E.transparent===!0&&E.side===In&&E.forceSinglePass===!1?(E.side=nn,E.needsUpdate=!0,Fn(E,H,Y),E.side=Mi,E.needsUpdate=!0,Fn(E,H,Y),E.side=In):Fn(E,H,Y)}this.compile=function(E,H,Y=null){Y===null&&(Y=E),m=Ot.get(Y),m.init(),C.push(m),Y.traverseVisible(function(q){q.isLight&&q.layers.test(H.layers)&&(m.pushLight(q),q.castShadow&&m.pushShadow(q))}),E!==Y&&E.traverseVisible(function(q){q.isLight&&q.layers.test(H.layers)&&(m.pushLight(q),q.castShadow&&m.pushShadow(q))}),m.setupLights(w._useLegacyLights);let Z=new Set;return E.traverse(function(q){let wt=q.material;if(wt)if(Array.isArray(wt))for(let Bt=0;Bt<wt.length;Bt++){let Xt=wt[Bt];ce(Xt,Y,q),Z.add(Xt)}else ce(wt,Y,q),Z.add(wt)}),C.pop(),m=null,Z},this.compileAsync=function(E,H,Y=null){let Z=this.compile(E,H,Y);return new Promise(q=>{function wt(){if(Z.forEach(function(Bt){$t.get(Bt).currentProgram.isReady()&&Z.delete(Bt)}),Z.size===0){q(E);return}setTimeout(wt,10)}Dt.get("KHR_parallel_shader_compile")!==null?wt():setTimeout(wt,10)})};let ne=null;function Oe(E){ne&&ne(E)}function _e(){Ge.stop()}function pe(){Ge.start()}let Ge=new jh;Ge.setAnimationLoop(Oe),typeof self<"u"&&Ge.setContext(self),this.setAnimationLoop=function(E){ne=E,Kt.setAnimationLoop(E),E===null?Ge.stop():Ge.start()},Kt.addEventListener("sessionstart",_e),Kt.addEventListener("sessionend",pe),this.render=function(E,H){if(H!==void 0&&H.isCamera!==!0){console.error("THREE.WebGLRenderer.render: camera is not an instance of THREE.Camera.");return}if(U===!0)return;E.matrixWorldAutoUpdate===!0&&E.updateMatrixWorld(),H.parent===null&&H.matrixWorldAutoUpdate===!0&&H.updateMatrixWorld(),Kt.enabled===!0&&Kt.isPresenting===!0&&(Kt.cameraAutoUpdate===!0&&Kt.updateCamera(H),H=Kt.getCamera()),E.isScene===!0&&E.onBeforeRender(w,E,H,L),m=Ot.get(E,C.length),m.init(),C.push(m),Nt.multiplyMatrices(H.projectionMatrix,H.matrixWorldInverse),J.setFromProjectionMatrix(Nt),vt=this.localClippingEnabled,ot=Yt.init(this.clippingPlanes,vt),b=ht.get(E,d.length),b.init(),d.push(b),_n(E,H,0,w.sortObjects),b.finish(),w.sortObjects===!0&&b.sort(Q,$),this.info.render.frame++,ot===!0&&Yt.beginShadows();let Y=m.state.shadowsArray;if(at.render(Y,E,H),ot===!0&&Yt.endShadows(),this.info.autoReset===!0&&this.info.reset(),se.render(b,E),m.setupLights(w._useLegacyLights),H.isArrayCamera){let Z=H.cameras;for(let q=0,wt=Z.length;q<wt;q++){let Bt=Z[q];Ti(b,E,Bt,Bt.viewport)}}else Ti(b,E,H);L!==null&&(A.updateMultisampleRenderTarget(L),A.updateRenderTargetMipmap(L)),E.isScene===!0&&E.onAfterRender(w,E,H),Ut.resetDefaultState(),j=-1,S=null,C.pop(),C.length>0?m=C[C.length-1]:m=null,d.pop(),d.length>0?b=d[d.length-1]:b=null};function _n(E,H,Y,Z){if(E.visible===!1)return;if(E.layers.test(H.layers)){if(E.isGroup)Y=E.renderOrder;else if(E.isLOD)E.autoUpdate===!0&&E.update(H);else if(E.isLight)m.pushLight(E),E.castShadow&&m.pushShadow(E);else if(E.isSprite){if(!E.frustumCulled||J.intersectsSprite(E)){Z&&It.setFromMatrixPosition(E.matrixWorld).applyMatrix4(Nt);let Bt=st.update(E),Xt=E.material;Xt.visible&&b.push(E,Bt,Xt,Y,It.z,null)}}else if((E.isMesh||E.isLine||E.isPoints)&&(!E.frustumCulled||J.intersectsObject(E))){let Bt=st.update(E),Xt=E.material;if(Z&&(E.boundingSphere!==void 0?(E.boundingSphere===null&&E.computeBoundingSphere(),It.copy(E.boundingSphere.center)):(Bt.boundingSphere===null&&Bt.computeBoundingSphere(),It.copy(Bt.boundingSphere.center)),It.applyMatrix4(E.matrixWorld).applyMatrix4(Nt)),Array.isArray(Xt)){let Zt=Bt.groups;for(let Vt=0,Wt=Zt.length;Vt<Wt;Vt++){let Jt=Zt[Vt],ue=Xt[Jt.materialIndex];ue&&ue.visible&&b.push(E,Bt,ue,Y,It.z,Jt)}}else Xt.visible&&b.push(E,Bt,Xt,Y,It.z,null)}}let wt=E.children;for(let Bt=0,Xt=wt.length;Bt<Xt;Bt++)_n(wt[Bt],H,Y,Z)}function Ti(E,H,Y,Z){let q=E.opaque,wt=E.transmissive,Bt=E.transparent;m.setupLightsView(Y),ot===!0&&Yt.setGlobalState(w.clippingPlanes,Y),wt.length>0&&Ai(q,wt,H,Y),Z&&Rt.viewport(R.copy(Z)),q.length>0&&Yn(q,H,Y),wt.length>0&&Yn(wt,H,Y),Bt.length>0&&Yn(Bt,H,Y),Rt.buffers.depth.setTest(!0),Rt.buffers.depth.setMask(!0),Rt.buffers.color.setMask(!0),Rt.setPolygonOffset(!1)}function Ai(E,H,Y,Z){if((Y.isScene===!0?Y.overrideMaterial:null)!==null)return;let wt=Gt.isWebGL2;Lt===null&&(Lt=new je(1,1,{generateMipmaps:!0,type:Dt.has("EXT_color_buffer_half_float")?mn:yi,minFilter:cr,samples:wt?4:0})),w.getDrawingBufferSize(Ct),wt?Lt.setSize(Ct.x,Ct.y):Lt.setSize(ua(Ct.x),ua(Ct.y));let Bt=w.getRenderTarget();w.setRenderTarget(Lt),w.getClearColor(ft),I=w.getClearAlpha(),I<1&&w.setClearColor(16777215,.5),w.clear();let Xt=w.toneMapping;w.toneMapping=vi,Yn(E,Y,Z),A.updateMultisampleRenderTarget(Lt),A.updateRenderTargetMipmap(Lt);let Zt=!1;for(let Vt=0,Wt=H.length;Vt<Wt;Vt++){let Jt=H[Vt],ue=Jt.object,Le=Jt.geometry,Ee=Jt.material,Sn=Jt.group;if(Ee.side===In&&ue.layers.test(Z.layers)){let xe=Ee.side;Ee.side=nn,Ee.needsUpdate=!0,Ci(ue,Y,Z,Le,Ee,Sn),Ee.side=xe,Ee.needsUpdate=!0,Zt=!0}}Zt===!0&&(A.updateMultisampleRenderTarget(Lt),A.updateRenderTargetMipmap(Lt)),w.setRenderTarget(Bt),w.setClearColor(ft,I),w.toneMapping=Xt}function Yn(E,H,Y){let Z=H.isScene===!0?H.overrideMaterial:null;for(let q=0,wt=E.length;q<wt;q++){let Bt=E[q],Xt=Bt.object,Zt=Bt.geometry,Vt=Z===null?Bt.material:Z,Wt=Bt.group;Xt.layers.test(Y.layers)&&Ci(Xt,H,Y,Zt,Vt,Wt)}}function Ci(E,H,Y,Z,q,wt){E.onBeforeRender(w,H,Y,Z,q,wt),E.modelViewMatrix.multiplyMatrices(Y.matrixWorldInverse,E.matrixWorld),E.normalMatrix.getNormalMatrix(E.modelViewMatrix),q.onBeforeRender(w,H,Y,Z,E,wt),q.transparent===!0&&q.side===In&&q.forceSinglePass===!1?(q.side=nn,q.needsUpdate=!0,w.renderBufferDirect(Y,H,Z,q,E,wt),q.side=Mi,q.needsUpdate=!0,w.renderBufferDirect(Y,H,Z,q,E,wt),q.side=In):w.renderBufferDirect(Y,H,Z,q,E,wt),E.onAfterRender(w,H,Y,Z,q,wt)}function Fn(E,H,Y){H.isScene!==!0&&(H=Tt);let Z=$t.get(E),q=m.state.lights,wt=m.state.shadowsArray,Bt=q.state.version,Xt=Et.getParameters(E,q.state,wt,H,Y),Zt=Et.getProgramCacheKey(Xt),Vt=Z.programs;Z.environment=E.isMeshStandardMaterial?H.environment:null,Z.fog=H.fog,Z.envMap=(E.isMeshStandardMaterial?X:M).get(E.envMap||Z.environment),Vt===void 0&&(E.addEventListener("dispose",xt),Vt=new Map,Z.programs=Vt);let Wt=Vt.get(Zt);if(Wt!==void 0){if(Z.currentProgram===Wt&&Z.lightsStateVersion===Bt)return Sr(E,Xt),Wt}else Xt.uniforms=Et.getUniforms(E),E.onBuild(Y,Xt,w),E.onBeforeCompile(Xt,w),Wt=Et.acquireProgram(Xt,Zt),Vt.set(Zt,Wt),Z.uniforms=Xt.uniforms;let Jt=Z.uniforms;return(!E.isShaderMaterial&&!E.isRawShaderMaterial||E.clipping===!0)&&(Jt.clippingPlanes=Yt.uniform),Sr(E,Xt),Z.needsLights=ji(E),Z.lightsStateVersion=Bt,Z.needsLights&&(Jt.ambientLightColor.value=q.state.ambient,Jt.lightProbe.value=q.state.probe,Jt.directionalLights.value=q.state.directional,Jt.directionalLightShadows.value=q.state.directionalShadow,Jt.spotLights.value=q.state.spot,Jt.spotLightShadows.value=q.state.spotShadow,Jt.rectAreaLights.value=q.state.rectArea,Jt.ltc_1.value=q.state.rectAreaLTC1,Jt.ltc_2.value=q.state.rectAreaLTC2,Jt.pointLights.value=q.state.point,Jt.pointLightShadows.value=q.state.pointShadow,Jt.hemisphereLights.value=q.state.hemi,Jt.directionalShadowMap.value=q.state.directionalShadowMap,Jt.directionalShadowMatrix.value=q.state.directionalShadowMatrix,Jt.spotShadowMap.value=q.state.spotShadowMap,Jt.spotLightMatrix.value=q.state.spotLightMatrix,Jt.spotLightMap.value=q.state.spotLightMap,Jt.pointShadowMap.value=q.state.pointShadowMap,Jt.pointShadowMatrix.value=q.state.pointShadowMatrix),Z.currentProgram=Wt,Z.uniformsList=null,Wt}function Vs(E){if(E.uniformsList===null){let H=E.currentProgram.getUniforms();E.uniformsList=Cs.seqWithValue(H.seq,E.uniforms)}return E.uniformsList}function Sr(E,H){let Y=$t.get(E);Y.outputColorSpace=H.outputColorSpace,Y.batching=H.batching,Y.instancing=H.instancing,Y.instancingColor=H.instancingColor,Y.skinning=H.skinning,Y.morphTargets=H.morphTargets,Y.morphNormals=H.morphNormals,Y.morphColors=H.morphColors,Y.morphTargetsCount=H.morphTargetsCount,Y.numClippingPlanes=H.numClippingPlanes,Y.numIntersection=H.numClipIntersection,Y.vertexAlphas=H.vertexAlphas,Y.vertexTangents=H.vertexTangents,Y.toneMapping=H.toneMapping}function Xa(E,H,Y,Z,q){H.isScene!==!0&&(H=Tt),A.resetTextureUnits();let wt=H.fog,Bt=Z.isMeshStandardMaterial?H.environment:null,Xt=L===null?w.outputColorSpace:L.isXRRenderTarget===!0?L.texture.colorSpace:si,Zt=(Z.isMeshStandardMaterial?X:M).get(Z.envMap||Bt),Vt=Z.vertexColors===!0&&!!Y.attributes.color&&Y.attributes.color.itemSize===4,Wt=!!Y.attributes.tangent&&(!!Z.normalMap||Z.anisotropy>0),Jt=!!Y.morphAttributes.position,ue=!!Y.morphAttributes.normal,Le=!!Y.morphAttributes.color,Ee=vi;Z.toneMapped&&(L===null||L.isXRRenderTarget===!0)&&(Ee=w.toneMapping);let Sn=Y.morphAttributes.position||Y.morphAttributes.normal||Y.morphAttributes.color,xe=Sn!==void 0?Sn.length:0,jt=$t.get(Z),qn=m.state.lights;if(ot===!0&&(vt===!0||E!==S)){let an=E===S&&Z.id===j;Yt.setState(Z,E,an)}let ye=!1;Z.version===jt.__version?(jt.needsLights&&jt.lightsStateVersion!==qn.state.version||jt.outputColorSpace!==Xt||q.isBatchedMesh&&jt.batching===!1||!q.isBatchedMesh&&jt.batching===!0||q.isInstancedMesh&&jt.instancing===!1||!q.isInstancedMesh&&jt.instancing===!0||q.isSkinnedMesh&&jt.skinning===!1||!q.isSkinnedMesh&&jt.skinning===!0||q.isInstancedMesh&&jt.instancingColor===!0&&q.instanceColor===null||q.isInstancedMesh&&jt.instancingColor===!1&&q.instanceColor!==null||jt.envMap!==Zt||Z.fog===!0&&jt.fog!==wt||jt.numClippingPlanes!==void 0&&(jt.numClippingPlanes!==Yt.numPlanes||jt.numIntersection!==Yt.numIntersection)||jt.vertexAlphas!==Vt||jt.vertexTangents!==Wt||jt.morphTargets!==Jt||jt.morphNormals!==ue||jt.morphColors!==Le||jt.toneMapping!==Ee||Gt.isWebGL2===!0&&jt.morphTargetsCount!==xe)&&(ye=!0):(ye=!0,jt.__version=Z.version);let Bn=jt.currentProgram;ye===!0&&(Bn=Fn(Z,H,q));let Gs=!1,Ri=!1,Ws=!1,We=Bn.getUniforms(),Zn=jt.uniforms;if(Rt.useProgram(Bn.program)&&(Gs=!0,Ri=!0,Ws=!0),Z.id!==j&&(j=Z.id,Ri=!0),Gs||S!==E){We.setValue(W,"projectionMatrix",E.projectionMatrix),We.setValue(W,"viewMatrix",E.matrixWorldInverse);let an=We.map.cameraPosition;an!==void 0&&an.setValue(W,It.setFromMatrixPosition(E.matrixWorld)),Gt.logarithmicDepthBuffer&&We.setValue(W,"logDepthBufFC",2/(Math.log(E.far+1)/Math.LN2)),(Z.isMeshPhongMaterial||Z.isMeshToonMaterial||Z.isMeshLambertMaterial||Z.isMeshBasicMaterial||Z.isMeshStandardMaterial||Z.isShaderMaterial)&&We.setValue(W,"isOrthographic",E.isOrthographicCamera===!0),S!==E&&(S=E,Ri=!0,Ws=!0)}if(q.isSkinnedMesh){We.setOptional(W,q,"bindMatrix"),We.setOptional(W,q,"bindMatrixInverse");let an=q.skeleton;an&&(Gt.floatVertexTextures?(an.boneTexture===null&&an.computeBoneTexture(),We.setValue(W,"boneTexture",an.boneTexture,A)):console.warn("THREE.WebGLRenderer: SkinnedMesh can only be used with WebGL 2. With WebGL 1 OES_texture_float and vertex textures support is required."))}q.isBatchedMesh&&(We.setOptional(W,q,"batchingTexture"),We.setValue(W,"batchingTexture",q._matricesTexture,A));let Xs=Y.morphAttributes;if((Xs.position!==void 0||Xs.normal!==void 0||Xs.color!==void 0&&Gt.isWebGL2===!0)&&P.update(q,Y,Bn),(Ri||jt.receiveShadow!==q.receiveShadow)&&(jt.receiveShadow=q.receiveShadow,We.setValue(W,"receiveShadow",q.receiveShadow)),Z.isMeshGouraudMaterial&&Z.envMap!==null&&(Zn.envMap.value=Zt,Zn.flipEnvMap.value=Zt.isCubeTexture&&Zt.isRenderTargetTexture===!1?-1:1),Ri&&(We.setValue(W,"toneMappingExposure",w.toneMappingExposure),jt.needsLights&&Ya(Zn,Ws),wt&&Z.fog===!0&&Mt.refreshFogUniforms(Zn,wt),Mt.refreshMaterialUniforms(Zn,Z,K,G,Lt),Cs.upload(W,Vs(jt),Zn,A)),Z.isShaderMaterial&&Z.uniformsNeedUpdate===!0&&(Cs.upload(W,Vs(jt),Zn,A),Z.uniformsNeedUpdate=!1),Z.isSpriteMaterial&&We.setValue(W,"center",q.center),We.setValue(W,"modelViewMatrix",q.modelViewMatrix),We.setValue(W,"normalMatrix",q.normalMatrix),We.setValue(W,"modelMatrix",q.matrixWorld),Z.isShaderMaterial||Z.isRawShaderMaterial){let an=Z.uniformsGroups;for(let Pi=0,qa=an.length;Pi<qa;Pi++)if(Gt.isWebGL2){let Te=an[Pi];Qt.update(Te,Bn),Qt.bind(Te,Bn)}else console.warn("THREE.WebGLRenderer: Uniform Buffer Objects can only be used with WebGL 2.")}return Bn}function Ya(E,H){E.ambientLightColor.needsUpdate=H,E.lightProbe.needsUpdate=H,E.directionalLights.needsUpdate=H,E.directionalLightShadows.needsUpdate=H,E.pointLights.needsUpdate=H,E.pointLightShadows.needsUpdate=H,E.spotLights.needsUpdate=H,E.spotLightShadows.needsUpdate=H,E.rectAreaLights.needsUpdate=H,E.hemisphereLights.needsUpdate=H}function ji(E){return E.isMeshLambertMaterial||E.isMeshToonMaterial||E.isMeshPhongMaterial||E.isMeshStandardMaterial||E.isShadowMaterial||E.isShaderMaterial&&E.lights===!0}this.getActiveCubeFace=function(){return z},this.getActiveMipmapLevel=function(){return N},this.getRenderTarget=function(){return L},this.setRenderTargetTextures=function(E,H,Y){$t.get(E.texture).__webglTexture=H,$t.get(E.depthTexture).__webglTexture=Y;let Z=$t.get(E);Z.__hasExternalTextures=!0,Z.__hasExternalTextures&&(Z.__autoAllocateDepthBuffer=Y===void 0,Z.__autoAllocateDepthBuffer||Dt.has("WEBGL_multisampled_render_to_texture")===!0&&(console.warn("THREE.WebGLRenderer: Render-to-texture extension was disabled because an external texture was provided"),Z.__useRenderToTexture=!1))},this.setRenderTargetFramebuffer=function(E,H){let Y=$t.get(E);Y.__webglFramebuffer=H,Y.__useDefaultFramebuffer=H===void 0},this.setRenderTarget=function(E,H=0,Y=0){L=E,z=H,N=Y;let Z=!0,q=null,wt=!1,Bt=!1;if(E){let Zt=$t.get(E);Zt.__useDefaultFramebuffer!==void 0?(Rt.bindFramebuffer(W.FRAMEBUFFER,null),Z=!1):Zt.__webglFramebuffer===void 0?A.setupRenderTarget(E):Zt.__hasExternalTextures&&A.rebindTextures(E,$t.get(E.texture).__webglTexture,$t.get(E.depthTexture).__webglTexture);let Vt=E.texture;(Vt.isData3DTexture||Vt.isDataArrayTexture||Vt.isCompressedArrayTexture)&&(Bt=!0);let Wt=$t.get(E).__webglFramebuffer;E.isWebGLCubeRenderTarget?(Array.isArray(Wt[H])?q=Wt[H][Y]:q=Wt[H],wt=!0):Gt.isWebGL2&&E.samples>0&&A.useMultisampledRTT(E)===!1?q=$t.get(E).__webglMultisampledFramebuffer:Array.isArray(Wt)?q=Wt[Y]:q=Wt,R.copy(E.viewport),V.copy(E.scissor),tt=E.scissorTest}else R.copy(nt).multiplyScalar(K).floor(),V.copy(ct).multiplyScalar(K).floor(),tt=bt;if(Rt.bindFramebuffer(W.FRAMEBUFFER,q)&&Gt.drawBuffers&&Z&&Rt.drawBuffers(E,q),Rt.viewport(R),Rt.scissor(V),Rt.setScissorTest(tt),wt){let Zt=$t.get(E.texture);W.framebufferTexture2D(W.FRAMEBUFFER,W.COLOR_ATTACHMENT0,W.TEXTURE_CUBE_MAP_POSITIVE_X+H,Zt.__webglTexture,Y)}else if(Bt){let Zt=$t.get(E.texture),Vt=H||0;W.framebufferTextureLayer(W.FRAMEBUFFER,W.COLOR_ATTACHMENT0,Zt.__webglTexture,Y||0,Vt)}j=-1},this.readRenderTargetPixels=function(E,H,Y,Z,q,wt,Bt){if(!(E&&E.isWebGLRenderTarget)){console.error("THREE.WebGLRenderer.readRenderTargetPixels: renderTarget is not THREE.WebGLRenderTarget.");return}let Xt=$t.get(E).__webglFramebuffer;if(E.isWebGLCubeRenderTarget&&Bt!==void 0&&(Xt=Xt[Bt]),Xt){Rt.bindFramebuffer(W.FRAMEBUFFER,Xt);try{let Zt=E.texture,Vt=Zt.format,Wt=Zt.type;if(Vt!==Un&&pt.convert(Vt)!==W.getParameter(W.IMPLEMENTATION_COLOR_READ_FORMAT)){console.error("THREE.WebGLRenderer.readRenderTargetPixels: renderTarget is not in RGBA or implementation defined format.");return}let Jt=Wt===mn&&(Dt.has("EXT_color_buffer_half_float")||Gt.isWebGL2&&Dt.has("EXT_color_buffer_float"));if(Wt!==yi&&pt.convert(Wt)!==W.getParameter(W.IMPLEMENTATION_COLOR_READ_TYPE)&&!(Wt===xi&&(Gt.isWebGL2||Dt.has("OES_texture_float")||Dt.has("WEBGL_color_buffer_float")))&&!Jt){console.error("THREE.WebGLRenderer.readRenderTargetPixels: renderTarget is not in UnsignedByteType or implementation defined type.");return}H>=0&&H<=E.width-Z&&Y>=0&&Y<=E.height-q&&W.readPixels(H,Y,Z,q,pt.convert(Vt),pt.convert(Wt),wt)}finally{let Zt=L!==null?$t.get(L).__webglFramebuffer:null;Rt.bindFramebuffer(W.FRAMEBUFFER,Zt)}}},this.copyFramebufferToTexture=function(E,H,Y=0){let Z=Math.pow(2,-Y),q=Math.floor(H.image.width*Z),wt=Math.floor(H.image.height*Z);A.setTexture2D(H,0),W.copyTexSubImage2D(W.TEXTURE_2D,Y,0,0,E.x,E.y,q,wt),Rt.unbindTexture()},this.copyTextureToTexture=function(E,H,Y,Z=0){let q=H.image.width,wt=H.image.height,Bt=pt.convert(Y.format),Xt=pt.convert(Y.type);A.setTexture2D(Y,0),W.pixelStorei(W.UNPACK_FLIP_Y_WEBGL,Y.flipY),W.pixelStorei(W.UNPACK_PREMULTIPLY_ALPHA_WEBGL,Y.premultiplyAlpha),W.pixelStorei(W.UNPACK_ALIGNMENT,Y.unpackAlignment),H.isDataTexture?W.texSubImage2D(W.TEXTURE_2D,Z,E.x,E.y,q,wt,Bt,Xt,H.image.data):H.isCompressedTexture?W.compressedTexSubImage2D(W.TEXTURE_2D,Z,E.x,E.y,H.mipmaps[0].width,H.mipmaps[0].height,Bt,H.mipmaps[0].data):W.texSubImage2D(W.TEXTURE_2D,Z,E.x,E.y,Bt,Xt,H.image),Z===0&&Y.generateMipmaps&&W.generateMipmap(W.TEXTURE_2D),Rt.unbindTexture()},this.copyTextureToTexture3D=function(E,H,Y,Z,q=0){if(w.isWebGL1Renderer){console.warn("THREE.WebGLRenderer.copyTextureToTexture3D: can only be used with WebGL2.");return}let wt=E.max.x-E.min.x+1,Bt=E.max.y-E.min.y+1,Xt=E.max.z-E.min.z+1,Zt=pt.convert(Z.format),Vt=pt.convert(Z.type),Wt;if(Z.isData3DTexture)A.setTexture3D(Z,0),Wt=W.TEXTURE_3D;else if(Z.isDataArrayTexture||Z.isCompressedArrayTexture)A.setTexture2DArray(Z,0),Wt=W.TEXTURE_2D_ARRAY;else{console.warn("THREE.WebGLRenderer.copyTextureToTexture3D: only supports THREE.DataTexture3D and THREE.DataTexture2DArray.");return}W.pixelStorei(W.UNPACK_FLIP_Y_WEBGL,Z.flipY),W.pixelStorei(W.UNPACK_PREMULTIPLY_ALPHA_WEBGL,Z.premultiplyAlpha),W.pixelStorei(W.UNPACK_ALIGNMENT,Z.unpackAlignment);let Jt=W.getParameter(W.UNPACK_ROW_LENGTH),ue=W.getParameter(W.UNPACK_IMAGE_HEIGHT),Le=W.getParameter(W.UNPACK_SKIP_PIXELS),Ee=W.getParameter(W.UNPACK_SKIP_ROWS),Sn=W.getParameter(W.UNPACK_SKIP_IMAGES),xe=Y.isCompressedTexture?Y.mipmaps[q]:Y.image;W.pixelStorei(W.UNPACK_ROW_LENGTH,xe.width),W.pixelStorei(W.UNPACK_IMAGE_HEIGHT,xe.height),W.pixelStorei(W.UNPACK_SKIP_PIXELS,E.min.x),W.pixelStorei(W.UNPACK_SKIP_ROWS,E.min.y),W.pixelStorei(W.UNPACK_SKIP_IMAGES,E.min.z),Y.isDataTexture||Y.isData3DTexture?W.texSubImage3D(Wt,q,H.x,H.y,H.z,wt,Bt,Xt,Zt,Vt,xe.data):Y.isCompressedArrayTexture?(console.warn("THREE.WebGLRenderer.copyTextureToTexture3D: untested support for compressed srcTexture."),W.compressedTexSubImage3D(Wt,q,H.x,H.y,H.z,wt,Bt,Xt,Zt,xe.data)):W.texSubImage3D(Wt,q,H.x,H.y,H.z,wt,Bt,Xt,Zt,Vt,xe),W.pixelStorei(W.UNPACK_ROW_LENGTH,Jt),W.pixelStorei(W.UNPACK_IMAGE_HEIGHT,ue),W.pixelStorei(W.UNPACK_SKIP_PIXELS,Le),W.pixelStorei(W.UNPACK_SKIP_ROWS,Ee),W.pixelStorei(W.UNPACK_SKIP_IMAGES,Sn),q===0&&Z.generateMipmaps&&W.generateMipmap(Wt),Rt.unbindTexture()},this.initTexture=function(E){E.isCubeTexture?A.setTextureCube(E,0):E.isData3DTexture?A.setTexture3D(E,0):E.isDataArrayTexture||E.isCompressedArrayTexture?A.setTexture2DArray(E,0):A.setTexture2D(E,0),Rt.unbindTexture()},this.resetState=function(){z=0,N=0,L=null,Rt.reset(),Ut.reset()},typeof __THREE_DEVTOOLS__<"u"&&__THREE_DEVTOOLS__.dispatchEvent(new CustomEvent("observe",{detail:this}))}get coordinateSystem(){return ni}get outputColorSpace(){return this._outputColorSpace}set outputColorSpace(t){this._outputColorSpace=t;let e=this.getContext();e.drawingBufferColorSpace=t===Al?"display-p3":"srgb",e.unpackColorSpace=fe.workingColorSpace===Oa?"display-p3":"srgb"}get outputEncoding(){return console.warn("THREE.WebGLRenderer: Property .outputEncoding has been removed. Use .outputColorSpace instead."),this.outputColorSpace===Re?Wi:Wh}set outputEncoding(t){console.warn("THREE.WebGLRenderer: Property .outputEncoding has been removed. Use .outputColorSpace instead."),this.outputColorSpace=t===Wi?Re:si}get useLegacyLights(){return console.warn("THREE.WebGLRenderer: The property .useLegacyLights has been deprecated. Migrate your lighting according to the following guide: https://discourse.threejs.org/t/updates-to-lighting-in-three-js-r155/53733."),this._useLegacyLights}set useLegacyLights(t){console.warn("THREE.WebGLRenderer: The property .useLegacyLights has been deprecated. Migrate your lighting according to the following guide: https://discourse.threejs.org/t/updates-to-lighting-in-three-js-r155/53733."),this._useLegacyLights=t}},al=class extends pr{};al.prototype.isWebGL1Renderer=!0;var Sa=class i{constructor(t,e=25e-5){this.isFogExp2=!0,this.name="",this.color=new qt(t),this.density=e}clone(){return new i(this.color,this.density)}toJSON(){return{type:"FogExp2",name:this.name,color:this.color.getHex(),density:this.density}}};var wa=class extends rn{constructor(){super(),this.isScene=!0,this.type="Scene",this.background=null,this.environment=null,this.fog=null,this.backgroundBlurriness=0,this.backgroundIntensity=1,this.overrideMaterial=null,typeof __THREE_DEVTOOLS__<"u"&&__THREE_DEVTOOLS__.dispatchEvent(new CustomEvent("observe",{detail:this}))}copy(t,e){return super.copy(t,e),t.background!==null&&(this.background=t.background.clone()),t.environment!==null&&(this.environment=t.environment.clone()),t.fog!==null&&(this.fog=t.fog.clone()),this.backgroundBlurriness=t.backgroundBlurriness,this.backgroundIntensity=t.backgroundIntensity,t.overrideMaterial!==null&&(this.overrideMaterial=t.overrideMaterial.clone()),this.matrixAutoUpdate=t.matrixAutoUpdate,this}toJSON(t){let e=super.toJSON(t);return this.fog!==null&&(e.object.fog=this.fog.toJSON()),this.backgroundBlurriness>0&&(e.object.backgroundBlurriness=this.backgroundBlurriness),this.backgroundIntensity!==1&&(e.object.backgroundIntensity=this.backgroundIntensity),e}};var Ea=class extends sn{constructor(t,e,n,s=1){super(t,e,n),this.isInstancedBufferAttribute=!0,this.meshPerAttribute=s}copy(t){return super.copy(t),this.meshPerAttribute=t.meshPerAttribute,this}toJSON(){let t=super.toJSON();return t.meshPerAttribute=this.meshPerAttribute,t.isInstancedBufferAttribute=!0,t}},bs=new ve,Eh=new ve,ta=[],Th=new ri,A0=new ve,er=new ke,nr=new bi,Ta=class extends ke{constructor(t,e,n){super(t,e),this.isInstancedMesh=!0,this.instanceMatrix=new Ea(new Float32Array(n*16),16),this.instanceColor=null,this.count=n,this.boundingBox=null,this.boundingSphere=null;for(let s=0;s<n;s++)this.setMatrixAt(s,A0)}computeBoundingBox(){let t=this.geometry,e=this.count;this.boundingBox===null&&(this.boundingBox=new ri),t.boundingBox===null&&t.computeBoundingBox(),this.boundingBox.makeEmpty();for(let n=0;n<e;n++)this.getMatrixAt(n,bs),Th.copy(t.boundingBox).applyMatrix4(bs),this.boundingBox.union(Th)}computeBoundingSphere(){let t=this.geometry,e=this.count;this.boundingSphere===null&&(this.boundingSphere=new bi),t.boundingSphere===null&&t.computeBoundingSphere(),this.boundingSphere.makeEmpty();for(let n=0;n<e;n++)this.getMatrixAt(n,bs),nr.copy(t.boundingSphere).applyMatrix4(bs),this.boundingSphere.union(nr)}copy(t,e){return super.copy(t,e),this.instanceMatrix.copy(t.instanceMatrix),t.instanceColor!==null&&(this.instanceColor=t.instanceColor.clone()),this.count=t.count,t.boundingBox!==null&&(this.boundingBox=t.boundingBox.clone()),t.boundingSphere!==null&&(this.boundingSphere=t.boundingSphere.clone()),this}getColorAt(t,e){e.fromArray(this.instanceColor.array,t*3)}getMatrixAt(t,e){e.fromArray(this.instanceMatrix.array,t*16)}raycast(t,e){let n=this.matrixWorld,s=this.count;if(er.geometry=this.geometry,er.material=this.material,er.material!==void 0&&(this.boundingSphere===null&&this.computeBoundingSphere(),nr.copy(this.boundingSphere),nr.applyMatrix4(n),t.ray.intersectsSphere(nr)!==!1))for(let r=0;r<s;r++){this.getMatrixAt(r,bs),Eh.multiplyMatrices(n,bs),er.matrixWorld=Eh,er.raycast(t,ta);for(let o=0,a=ta.length;o<a;o++){let l=ta[o];l.instanceId=r,l.object=this,e.push(l)}ta.length=0}}setColorAt(t,e){this.instanceColor===null&&(this.instanceColor=new Ea(new Float32Array(this.instanceMatrix.count*3),3)),e.toArray(this.instanceColor.array,t*3)}setMatrixAt(t,e){e.toArray(this.instanceMatrix.array,t*16)}updateMorphTargets(){}dispose(){this.dispatchEvent({type:"dispose"})}};var Ns=class extends Si{constructor(t){super(),this.isPointsMaterial=!0,this.type="PointsMaterial",this.color=new qt(16777215),this.map=null,this.alphaMap=null,this.size=1,this.sizeAttenuation=!0,this.fog=!0,this.setValues(t)}copy(t){return super.copy(t),this.color.copy(t.color),this.map=t.map,this.alphaMap=t.alphaMap,this.size=t.size,this.sizeAttenuation=t.sizeAttenuation,this.fog=t.fog,this}},Ah=new ve,ol=new Xi,ea=new bi,na=new F,mr=class extends rn{constructor(t=new hn,e=new Ns){super(),this.isPoints=!0,this.type="Points",this.geometry=t,this.material=e,this.updateMorphTargets()}copy(t,e){return super.copy(t,e),this.material=Array.isArray(t.material)?t.material.slice():t.material,this.geometry=t.geometry,this}raycast(t,e){let n=this.geometry,s=this.matrixWorld,r=t.params.Points.threshold,o=n.drawRange;if(n.boundingSphere===null&&n.computeBoundingSphere(),ea.copy(n.boundingSphere),ea.applyMatrix4(s),ea.radius+=r,t.ray.intersectsSphere(ea)===!1)return;Ah.copy(s).invert(),ol.copy(t.ray).applyMatrix4(Ah);let a=r/((this.scale.x+this.scale.y+this.scale.z)/3),l=a*a,c=n.index,f=n.attributes.position;if(c!==null){let p=Math.max(0,o.start),x=Math.min(c.count,o.start+o.count);for(let y=p,b=x;y<b;y++){let m=c.getX(y);na.fromBufferAttribute(f,m),Ch(na,m,l,s,t,e,this)}}else{let p=Math.max(0,o.start),x=Math.min(f.count,o.start+o.count);for(let y=p,b=x;y<b;y++)na.fromBufferAttribute(f,y),Ch(na,y,l,s,t,e,this)}}updateMorphTargets(){let e=this.geometry.morphAttributes,n=Object.keys(e);if(n.length>0){let s=e[n[0]];if(s!==void 0){this.morphTargetInfluences=[],this.morphTargetDictionary={};for(let r=0,o=s.length;r<o;r++){let a=s[r].name||String(r);this.morphTargetInfluences.push(0),this.morphTargetDictionary[a]=r}}}}};function Ch(i,t,e,n,s,r,o){let a=ol.distanceSqToPoint(i);if(a<e){let l=new F;ol.closestPointToPoint(i,l),l.applyMatrix4(n);let c=s.ray.origin.distanceTo(l);if(c<s.near||c>s.far)return;r.push({distance:c,distanceToRay:Math.sqrt(a),point:l,index:t,face:null,object:o})}}var Os=class extends bn{constructor(t,e,n,s,r,o,a,l,c){super(t,e,n,s,r,o,a,l,c),this.isCanvasTexture=!0,this.needsUpdate=!0}};var gr=class i extends hn{constructor(t=1,e=32,n=0,s=Math.PI*2){super(),this.type="CircleGeometry",this.parameters={radius:t,segments:e,thetaStart:n,thetaLength:s},e=Math.max(3,e);let r=[],o=[],a=[],l=[],c=new F,u=new Pt;o.push(0,0,0),a.push(0,0,1),l.push(.5,.5);for(let f=0,p=3;f<=e;f++,p+=3){let x=n+f/e*s;c.x=t*Math.cos(x),c.y=t*Math.sin(x),o.push(c.x,c.y,c.z),a.push(0,0,1),u.x=(o[p]/t+1)/2,u.y=(o[p+1]/t+1)/2,l.push(u.x,u.y)}for(let f=1;f<=e;f++)r.push(f,f+1,0);this.setIndex(r),this.setAttribute("position",new Ze(o,3)),this.setAttribute("normal",new Ze(a,3)),this.setAttribute("uv",new Ze(l,2))}copy(t){return super.copy(t),this.parameters=Object.assign({},t.parameters),this}static fromJSON(t){return new i(t.radius,t.segments,t.thetaStart,t.thetaLength)}};var Aa=class i extends hn{constructor(t=1,e=32,n=16,s=0,r=Math.PI*2,o=0,a=Math.PI){super(),this.type="SphereGeometry",this.parameters={radius:t,widthSegments:e,heightSegments:n,phiStart:s,phiLength:r,thetaStart:o,thetaLength:a},e=Math.max(3,Math.floor(e)),n=Math.max(2,Math.floor(n));let l=Math.min(o+a,Math.PI),c=0,u=[],f=new F,p=new F,x=[],y=[],b=[],m=[];for(let d=0;d<=n;d++){let C=[],w=d/n,U=0;d===0&&o===0?U=.5/e:d===n&&l===Math.PI&&(U=-.5/e);for(let z=0;z<=e;z++){let N=z/e;f.x=-t*Math.cos(s+N*r)*Math.sin(o+w*a),f.y=t*Math.cos(o+w*a),f.z=t*Math.sin(s+N*r)*Math.sin(o+w*a),y.push(f.x,f.y,f.z),p.copy(f).normalize(),b.push(p.x,p.y,p.z),m.push(N+U,1-w),C.push(c++)}u.push(C)}for(let d=0;d<n;d++)for(let C=0;C<e;C++){let w=u[d][C+1],U=u[d][C],z=u[d+1][C],N=u[d+1][C+1];(d!==0||o>0)&&x.push(w,U,N),(d!==n-1||l<Math.PI)&&x.push(U,z,N)}this.setIndex(x),this.setAttribute("position",new Ze(y,3)),this.setAttribute("normal",new Ze(b,3)),this.setAttribute("uv",new Ze(m,2))}copy(t){return super.copy(t),this.parameters=Object.assign({},t.parameters),this}static fromJSON(t){return new i(t.radius,t.widthSegments,t.heightSegments,t.phiStart,t.phiLength,t.thetaStart,t.thetaLength)}};var Ca=class extends Ne{constructor(t){super(t),this.isRawShaderMaterial=!0,this.type="RawShaderMaterial"}},xr=class extends Si{constructor(t){super(),this.isMeshStandardMaterial=!0,this.defines={STANDARD:""},this.type="MeshStandardMaterial",this.color=new qt(16777215),this.roughness=1,this.metalness=0,this.map=null,this.lightMap=null,this.lightMapIntensity=1,this.aoMap=null,this.aoMapIntensity=1,this.emissive=new qt(0),this.emissiveIntensity=1,this.emissiveMap=null,this.bumpMap=null,this.bumpScale=1,this.normalMap=null,this.normalMapType=Xh,this.normalScale=new Pt(1,1),this.displacementMap=null,this.displacementScale=1,this.displacementBias=0,this.roughnessMap=null,this.metalnessMap=null,this.alphaMap=null,this.envMap=null,this.envMapIntensity=1,this.wireframe=!1,this.wireframeLinewidth=1,this.wireframeLinecap="round",this.wireframeLinejoin="round",this.flatShading=!1,this.fog=!0,this.setValues(t)}copy(t){return super.copy(t),this.defines={STANDARD:""},this.color.copy(t.color),this.roughness=t.roughness,this.metalness=t.metalness,this.map=t.map,this.lightMap=t.lightMap,this.lightMapIntensity=t.lightMapIntensity,this.aoMap=t.aoMap,this.aoMapIntensity=t.aoMapIntensity,this.emissive.copy(t.emissive),this.emissiveMap=t.emissiveMap,this.emissiveIntensity=t.emissiveIntensity,this.bumpMap=t.bumpMap,this.bumpScale=t.bumpScale,this.normalMap=t.normalMap,this.normalMapType=t.normalMapType,this.normalScale.copy(t.normalScale),this.displacementMap=t.displacementMap,this.displacementScale=t.displacementScale,this.displacementBias=t.displacementBias,this.roughnessMap=t.roughnessMap,this.metalnessMap=t.metalnessMap,this.alphaMap=t.alphaMap,this.envMap=t.envMap,this.envMapIntensity=t.envMapIntensity,this.wireframe=t.wireframe,this.wireframeLinewidth=t.wireframeLinewidth,this.wireframeLinecap=t.wireframeLinecap,this.wireframeLinejoin=t.wireframeLinejoin,this.flatShading=t.flatShading,this.fog=t.fog,this}};function ia(i,t,e){return!i||!e&&i.constructor===t?i:typeof t.BYTES_PER_ELEMENT=="number"?new t(i):Array.prototype.slice.call(i)}function C0(i){return ArrayBuffer.isView(i)&&!(i instanceof DataView)}var Fs=class{constructor(t,e,n,s){this.parameterPositions=t,this._cachedIndex=0,this.resultBuffer=s!==void 0?s:new e.constructor(n),this.sampleValues=e,this.valueSize=n,this.settings=null,this.DefaultSettings_={}}evaluate(t){let e=this.parameterPositions,n=this._cachedIndex,s=e[n],r=e[n-1];n:{t:{let o;e:{i:if(!(t<s)){for(let a=n+2;;){if(s===void 0){if(t<r)break i;return n=e.length,this._cachedIndex=n,this.copySampleValue_(n-1)}if(n===a)break;if(r=s,s=e[++n],t<s)break t}o=e.length;break e}if(!(t>=r)){let a=e[1];t<a&&(n=2,r=a);for(let l=n-2;;){if(r===void 0)return this._cachedIndex=0,this.copySampleValue_(0);if(n===l)break;if(s=r,r=e[--n-1],t>=r)break t}o=n,n=0;break e}break n}for(;n<o;){let a=n+o>>>1;t<e[a]?o=a:n=a+1}if(s=e[n],r=e[n-1],r===void 0)return this._cachedIndex=0,this.copySampleValue_(0);if(s===void 0)return n=e.length,this._cachedIndex=n,this.copySampleValue_(n-1)}this._cachedIndex=n,this.intervalChanged_(n,r,s)}return this.interpolate_(n,r,t,s)}getSettings_(){return this.settings||this.DefaultSettings_}copySampleValue_(t){let e=this.resultBuffer,n=this.sampleValues,s=this.valueSize,r=t*s;for(let o=0;o!==s;++o)e[o]=n[r+o];return e}interpolate_(){throw new Error("call to abstract method")}intervalChanged_(){}},ll=class extends Fs{constructor(t,e,n,s){super(t,e,n,s),this._weightPrev=-0,this._offsetPrev=-0,this._weightNext=-0,this._offsetNext=-0,this.DefaultSettings_={endingStart:Nc,endingEnd:Nc}}intervalChanged_(t,e,n){let s=this.parameterPositions,r=t-2,o=t+1,a=s[r],l=s[o];if(a===void 0)switch(this.getSettings_().endingStart){case Oc:r=t,a=2*e-n;break;case Fc:r=s.length-2,a=e+s[r]-s[r+1];break;default:r=t,a=n}if(l===void 0)switch(this.getSettings_().endingEnd){case Oc:o=t,l=2*n-e;break;case Fc:o=1,l=n+s[1]-s[0];break;default:o=t-1,l=e}let c=(n-e)*.5,u=this.valueSize;this._weightPrev=c/(e-a),this._weightNext=c/(l-n),this._offsetPrev=r*u,this._offsetNext=o*u}interpolate_(t,e,n,s){let r=this.resultBuffer,o=this.sampleValues,a=this.valueSize,l=t*a,c=l-a,u=this._offsetPrev,f=this._offsetNext,p=this._weightPrev,x=this._weightNext,y=(n-e)/(s-e),b=y*y,m=b*y,d=-p*m+2*p*b-p*y,C=(1+p)*m+(-1.5-2*p)*b+(-.5+p)*y+1,w=(-1-x)*m+(1.5+x)*b+.5*y,U=x*m-x*b;for(let z=0;z!==a;++z)r[z]=d*o[u+z]+C*o[c+z]+w*o[l+z]+U*o[f+z];return r}},cl=class extends Fs{constructor(t,e,n,s){super(t,e,n,s)}interpolate_(t,e,n,s){let r=this.resultBuffer,o=this.sampleValues,a=this.valueSize,l=t*a,c=l-a,u=(n-e)/(s-e),f=1-u;for(let p=0;p!==a;++p)r[p]=o[c+p]*f+o[l+p]*u;return r}},hl=class extends Fs{constructor(t,e,n,s){super(t,e,n,s)}interpolate_(t){return this.copySampleValue_(t-1)}},On=class{constructor(t,e,n,s){if(t===void 0)throw new Error("THREE.KeyframeTrack: track name is undefined");if(e===void 0||e.length===0)throw new Error("THREE.KeyframeTrack: no keyframes in track named "+t);this.name=t,this.times=ia(e,this.TimeBufferType),this.values=ia(n,this.ValueBufferType),this.setInterpolation(s||this.DefaultInterpolation)}static toJSON(t){let e=t.constructor,n;if(e.toJSON!==this.toJSON)n=e.toJSON(t);else{n={name:t.name,times:ia(t.times,Array),values:ia(t.values,Array)};let s=t.getInterpolation();s!==t.DefaultInterpolation&&(n.interpolation=s)}return n.type=t.ValueTypeName,n}InterpolantFactoryMethodDiscrete(t){return new hl(this.times,this.values,this.getValueSize(),t)}InterpolantFactoryMethodLinear(t){return new cl(this.times,this.values,this.getValueSize(),t)}InterpolantFactoryMethodSmooth(t){return new ll(this.times,this.values,this.getValueSize(),t)}setInterpolation(t){let e;switch(t){case ra:e=this.InterpolantFactoryMethodDiscrete;break;case aa:e=this.InterpolantFactoryMethodLinear;break;case po:e=this.InterpolantFactoryMethodSmooth;break}if(e===void 0){let n="unsupported interpolation for "+this.ValueTypeName+" keyframe track named "+this.name;if(this.createInterpolant===void 0)if(t!==this.DefaultInterpolation)this.setInterpolation(this.DefaultInterpolation);else throw new Error(n);return console.warn("THREE.KeyframeTrack:",n),this}return this.createInterpolant=e,this}getInterpolation(){switch(this.createInterpolant){case this.InterpolantFactoryMethodDiscrete:return ra;case this.InterpolantFactoryMethodLinear:return aa;case this.InterpolantFactoryMethodSmooth:return po}}getValueSize(){return this.values.length/this.times.length}shift(t){if(t!==0){let e=this.times;for(let n=0,s=e.length;n!==s;++n)e[n]+=t}return this}scale(t){if(t!==1){let e=this.times;for(let n=0,s=e.length;n!==s;++n)e[n]*=t}return this}trim(t,e){let n=this.times,s=n.length,r=0,o=s-1;for(;r!==s&&n[r]<t;)++r;for(;o!==-1&&n[o]>e;)--o;if(++o,r!==0||o!==s){r>=o&&(o=Math.max(o,1),r=o-1);let a=this.getValueSize();this.times=n.slice(r,o),this.values=this.values.slice(r*a,o*a)}return this}validate(){let t=!0,e=this.getValueSize();e-Math.floor(e)!==0&&(console.error("THREE.KeyframeTrack: Invalid value size in track.",this),t=!1);let n=this.times,s=this.values,r=n.length;r===0&&(console.error("THREE.KeyframeTrack: Track is empty.",this),t=!1);let o=null;for(let a=0;a!==r;a++){let l=n[a];if(typeof l=="number"&&isNaN(l)){console.error("THREE.KeyframeTrack: Time is not a valid number.",this,a,l),t=!1;break}if(o!==null&&o>l){console.error("THREE.KeyframeTrack: Out of order keys.",this,a,l,o),t=!1;break}o=l}if(s!==void 0&&C0(s))for(let a=0,l=s.length;a!==l;++a){let c=s[a];if(isNaN(c)){console.error("THREE.KeyframeTrack: Value is not a valid number.",this,a,c),t=!1;break}}return t}optimize(){let t=this.times.slice(),e=this.values.slice(),n=this.getValueSize(),s=this.getInterpolation()===po,r=t.length-1,o=1;for(let a=1;a<r;++a){let l=!1,c=t[a],u=t[a+1];if(c!==u&&(a!==1||c!==t[0]))if(s)l=!0;else{let f=a*n,p=f-n,x=f+n;for(let y=0;y!==n;++y){let b=e[f+y];if(b!==e[p+y]||b!==e[x+y]){l=!0;break}}}if(l){if(a!==o){t[o]=t[a];let f=a*n,p=o*n;for(let x=0;x!==n;++x)e[p+x]=e[f+x]}++o}}if(r>0){t[o]=t[r];for(let a=r*n,l=o*n,c=0;c!==n;++c)e[l+c]=e[a+c];++o}return o!==t.length?(this.times=t.slice(0,o),this.values=e.slice(0,o*n)):(this.times=t,this.values=e),this}clone(){let t=this.times.slice(),e=this.values.slice(),n=this.constructor,s=new n(this.name,t,e);return s.createInterpolant=this.createInterpolant,s}};On.prototype.TimeBufferType=Float32Array;On.prototype.ValueBufferType=Float32Array;On.prototype.DefaultInterpolation=aa;var qi=class extends On{};qi.prototype.ValueTypeName="bool";qi.prototype.ValueBufferType=Array;qi.prototype.DefaultInterpolation=ra;qi.prototype.InterpolantFactoryMethodLinear=void 0;qi.prototype.InterpolantFactoryMethodSmooth=void 0;var ul=class extends On{};ul.prototype.ValueTypeName="color";var dl=class extends On{};dl.prototype.ValueTypeName="number";var fl=class extends Fs{constructor(t,e,n,s){super(t,e,n,s)}interpolate_(t,e,n,s){let r=this.resultBuffer,o=this.sampleValues,a=this.valueSize,l=(n-e)/(s-e),c=t*a;for(let u=c+a;c!==u;c+=4)Nn.slerpFlat(r,0,o,c-a,o,c,l);return r}},_r=class extends On{InterpolantFactoryMethodLinear(t){return new fl(this.times,this.values,this.getValueSize(),t)}};_r.prototype.ValueTypeName="quaternion";_r.prototype.DefaultInterpolation=aa;_r.prototype.InterpolantFactoryMethodSmooth=void 0;var Zi=class extends On{};Zi.prototype.ValueTypeName="string";Zi.prototype.ValueBufferType=Array;Zi.prototype.DefaultInterpolation=ra;Zi.prototype.InterpolantFactoryMethodLinear=void 0;Zi.prototype.InterpolantFactoryMethodSmooth=void 0;var pl=class extends On{};pl.prototype.ValueTypeName="vector";var ml=class{constructor(t,e,n){let s=this,r=!1,o=0,a=0,l,c=[];this.onStart=void 0,this.onLoad=t,this.onProgress=e,this.onError=n,this.itemStart=function(u){a++,r===!1&&s.onStart!==void 0&&s.onStart(u,o,a),r=!0},this.itemEnd=function(u){o++,s.onProgress!==void 0&&s.onProgress(u,o,a),o===a&&(r=!1,s.onLoad!==void 0&&s.onLoad())},this.itemError=function(u){s.onError!==void 0&&s.onError(u)},this.resolveURL=function(u){return l?l(u):u},this.setURLModifier=function(u){return l=u,this},this.addHandler=function(u,f){return c.push(u,f),this},this.removeHandler=function(u){let f=c.indexOf(u);return f!==-1&&c.splice(f,2),this},this.getHandler=function(u){for(let f=0,p=c.length;f<p;f+=2){let x=c[f],y=c[f+1];if(x.global&&(x.lastIndex=0),x.test(u))return y}return null}}},R0=new ml,gl=class{constructor(t){this.manager=t!==void 0?t:R0,this.crossOrigin="anonymous",this.withCredentials=!1,this.path="",this.resourcePath="",this.requestHeader={}}load(){}loadAsync(t,e){let n=this;return new Promise(function(s,r){n.load(t,s,e,r)})}parse(){}setCrossOrigin(t){return this.crossOrigin=t,this}setWithCredentials(t){return this.withCredentials=t,this}setPath(t){return this.path=t,this}setResourcePath(t){return this.resourcePath=t,this}setRequestHeader(t){return this.requestHeader=t,this}};gl.DEFAULT_MATERIAL_NAME="__DEFAULT";var vr=class extends rn{constructor(t,e=1){super(),this.isLight=!0,this.type="Light",this.color=new qt(t),this.intensity=e}dispose(){}copy(t,e){return super.copy(t,e),this.color.copy(t.color),this.intensity=t.intensity,this}toJSON(t){let e=super.toJSON(t);return e.object.color=this.color.getHex(),e.object.intensity=this.intensity,this.groundColor!==void 0&&(e.object.groundColor=this.groundColor.getHex()),this.distance!==void 0&&(e.object.distance=this.distance),this.angle!==void 0&&(e.object.angle=this.angle),this.decay!==void 0&&(e.object.decay=this.decay),this.penumbra!==void 0&&(e.object.penumbra=this.penumbra),this.shadow!==void 0&&(e.object.shadow=this.shadow.toJSON()),e}},Ra=class extends vr{constructor(t,e,n){super(t,n),this.isHemisphereLight=!0,this.type="HemisphereLight",this.position.copy(rn.DEFAULT_UP),this.updateMatrix(),this.groundColor=new qt(e)}copy(t,e){return super.copy(t,e),this.groundColor.copy(t.groundColor),this}},Fo=new ve,Rh=new F,Ph=new F,Pa=class{constructor(t){this.camera=t,this.bias=0,this.normalBias=0,this.radius=1,this.blurSamples=8,this.mapSize=new Pt(512,512),this.map=null,this.mapPass=null,this.matrix=new ve,this.autoUpdate=!0,this.needsUpdate=!1,this._frustum=new dr,this._frameExtents=new Pt(1,1),this._viewportCount=1,this._viewports=[new we(0,0,1,1)]}getViewportCount(){return this._viewportCount}getFrustum(){return this._frustum}updateMatrices(t){let e=this.camera,n=this.matrix;Rh.setFromMatrixPosition(t.matrixWorld),e.position.copy(Rh),Ph.setFromMatrixPosition(t.target.matrixWorld),e.lookAt(Ph),e.updateMatrixWorld(),Fo.multiplyMatrices(e.projectionMatrix,e.matrixWorldInverse),this._frustum.setFromProjectionMatrix(Fo),n.set(.5,0,0,.5,0,.5,0,.5,0,0,.5,.5,0,0,0,1),n.multiply(Fo)}getViewport(t){return this._viewports[t]}getFrameExtents(){return this._frameExtents}dispose(){this.map&&this.map.dispose(),this.mapPass&&this.mapPass.dispose()}copy(t){return this.camera=t.camera.clone(),this.bias=t.bias,this.radius=t.radius,this.mapSize.copy(t.mapSize),this}clone(){return new this.constructor().copy(this)}toJSON(){let t={};return this.bias!==0&&(t.bias=this.bias),this.normalBias!==0&&(t.normalBias=this.normalBias),this.radius!==1&&(t.radius=this.radius),(this.mapSize.x!==512||this.mapSize.y!==512)&&(t.mapSize=this.mapSize.toArray()),t.camera=this.camera.toJSON(!1).object,delete t.camera.matrix,t}};var Lh=new ve,ir=new F,Bo=new F,xl=class extends Pa{constructor(){super(new en(90,1,.5,500)),this.isPointLightShadow=!0,this._frameExtents=new Pt(4,2),this._viewportCount=6,this._viewports=[new we(2,1,1,1),new we(0,1,1,1),new we(3,1,1,1),new we(1,1,1,1),new we(3,0,1,1),new we(1,0,1,1)],this._cubeDirections=[new F(1,0,0),new F(-1,0,0),new F(0,0,1),new F(0,0,-1),new F(0,1,0),new F(0,-1,0)],this._cubeUps=[new F(0,1,0),new F(0,1,0),new F(0,1,0),new F(0,1,0),new F(0,0,1),new F(0,0,-1)]}updateMatrices(t,e=0){let n=this.camera,s=this.matrix,r=t.distance||n.far;r!==n.far&&(n.far=r,n.updateProjectionMatrix()),ir.setFromMatrixPosition(t.matrixWorld),n.position.copy(ir),Bo.copy(n.position),Bo.add(this._cubeDirections[e]),n.up.copy(this._cubeUps[e]),n.lookAt(Bo),n.updateMatrixWorld(),s.makeTranslation(-ir.x,-ir.y,-ir.z),Lh.multiplyMatrices(n.projectionMatrix,n.matrixWorldInverse),this._frustum.setFromProjectionMatrix(Lh)}},La=class extends vr{constructor(t,e,n=0,s=2){super(t,e),this.isPointLight=!0,this.type="PointLight",this.distance=n,this.decay=s,this.shadow=new xl}get power(){return this.intensity*4*Math.PI}set power(t){this.intensity=t/(4*Math.PI)}dispose(){this.shadow.dispose()}copy(t,e){return super.copy(t,e),this.distance=t.distance,this.decay=t.decay,this.shadow=t.shadow.clone(),this}},_l=class extends Pa{constructor(){super(new Us(-5,5,5,-5,.5,500)),this.isDirectionalLightShadow=!0}},Ia=class extends vr{constructor(t,e){super(t,e),this.isDirectionalLight=!0,this.type="DirectionalLight",this.position.copy(rn.DEFAULT_UP),this.updateMatrix(),this.target=new rn,this.shadow=new _l}dispose(){this.shadow.dispose()}copy(t){return super.copy(t),this.target=t.target.clone(),this.shadow=t.shadow.clone(),this}};var Da=class{constructor(t=!0){this.autoStart=t,this.startTime=0,this.oldTime=0,this.elapsedTime=0,this.running=!1}start(){this.startTime=Ih(),this.oldTime=this.startTime,this.elapsedTime=0,this.running=!0}stop(){this.getElapsedTime(),this.running=!1,this.autoStart=!1}getElapsedTime(){return this.getDelta(),this.elapsedTime}getDelta(){let t=0;if(this.autoStart&&!this.running)return this.start(),0;if(this.running){let e=Ih();t=(e-this.oldTime)/1e3,this.oldTime=e,this.elapsedTime+=t}return t}};function Ih(){return(typeof performance>"u"?Date:performance).now()}var Pl="\\[\\]\\.:\\/",P0=new RegExp("["+Pl+"]","g"),Ll="[^"+Pl+"]",L0="[^"+Pl.replace("\\.","")+"]",I0=/((?:WC+[\/:])*)/.source.replace("WC",Ll),D0=/(WCOD+)?/.source.replace("WCOD",L0),U0=/(?:\.(WC+)(?:\[(.+)\])?)?/.source.replace("WC",Ll),N0=/\.(WC+)(?:\[(.+)\])?/.source.replace("WC",Ll),O0=new RegExp("^"+I0+D0+U0+N0+"$"),F0=["material","materials","bones","map"],vl=class{constructor(t,e,n){let s=n||Se.parseTrackName(e);this._targetGroup=t,this._bindings=t.subscribe_(e,s)}getValue(t,e){this.bind();let n=this._targetGroup.nCachedObjects_,s=this._bindings[n];s!==void 0&&s.getValue(t,e)}setValue(t,e){let n=this._bindings;for(let s=this._targetGroup.nCachedObjects_,r=n.length;s!==r;++s)n[s].setValue(t,e)}bind(){let t=this._bindings;for(let e=this._targetGroup.nCachedObjects_,n=t.length;e!==n;++e)t[e].bind()}unbind(){let t=this._bindings;for(let e=this._targetGroup.nCachedObjects_,n=t.length;e!==n;++e)t[e].unbind()}},Se=class i{constructor(t,e,n){this.path=e,this.parsedPath=n||i.parseTrackName(e),this.node=i.findNode(t,this.parsedPath.nodeName),this.rootNode=t,this.getValue=this._getValue_unbound,this.setValue=this._setValue_unbound}static create(t,e,n){return t&&t.isAnimationObjectGroup?new i.Composite(t,e,n):new i(t,e,n)}static sanitizeNodeName(t){return t.replace(/\s/g,"_").replace(P0,"")}static parseTrackName(t){let e=O0.exec(t);if(e===null)throw new Error("PropertyBinding: Cannot parse trackName: "+t);let n={nodeName:e[2],objectName:e[3],objectIndex:e[4],propertyName:e[5],propertyIndex:e[6]},s=n.nodeName&&n.nodeName.lastIndexOf(".");if(s!==void 0&&s!==-1){let r=n.nodeName.substring(s+1);F0.indexOf(r)!==-1&&(n.nodeName=n.nodeName.substring(0,s),n.objectName=r)}if(n.propertyName===null||n.propertyName.length===0)throw new Error("PropertyBinding: can not parse propertyName from trackName: "+t);return n}static findNode(t,e){if(e===void 0||e===""||e==="."||e===-1||e===t.name||e===t.uuid)return t;if(t.skeleton){let n=t.skeleton.getBoneByName(e);if(n!==void 0)return n}if(t.children){let n=function(r){for(let o=0;o<r.length;o++){let a=r[o];if(a.name===e||a.uuid===e)return a;let l=n(a.children);if(l)return l}return null},s=n(t.children);if(s)return s}return null}_getValue_unavailable(){}_setValue_unavailable(){}_getValue_direct(t,e){t[e]=this.targetObject[this.propertyName]}_getValue_array(t,e){let n=this.resolvedProperty;for(let s=0,r=n.length;s!==r;++s)t[e++]=n[s]}_getValue_arrayElement(t,e){t[e]=this.resolvedProperty[this.propertyIndex]}_getValue_toArray(t,e){this.resolvedProperty.toArray(t,e)}_setValue_direct(t,e){this.targetObject[this.propertyName]=t[e]}_setValue_direct_setNeedsUpdate(t,e){this.targetObject[this.propertyName]=t[e],this.targetObject.needsUpdate=!0}_setValue_direct_setMatrixWorldNeedsUpdate(t,e){this.targetObject[this.propertyName]=t[e],this.targetObject.matrixWorldNeedsUpdate=!0}_setValue_array(t,e){let n=this.resolvedProperty;for(let s=0,r=n.length;s!==r;++s)n[s]=t[e++]}_setValue_array_setNeedsUpdate(t,e){let n=this.resolvedProperty;for(let s=0,r=n.length;s!==r;++s)n[s]=t[e++];this.targetObject.needsUpdate=!0}_setValue_array_setMatrixWorldNeedsUpdate(t,e){let n=this.resolvedProperty;for(let s=0,r=n.length;s!==r;++s)n[s]=t[e++];this.targetObject.matrixWorldNeedsUpdate=!0}_setValue_arrayElement(t,e){this.resolvedProperty[this.propertyIndex]=t[e]}_setValue_arrayElement_setNeedsUpdate(t,e){this.resolvedProperty[this.propertyIndex]=t[e],this.targetObject.needsUpdate=!0}_setValue_arrayElement_setMatrixWorldNeedsUpdate(t,e){this.resolvedProperty[this.propertyIndex]=t[e],this.targetObject.matrixWorldNeedsUpdate=!0}_setValue_fromArray(t,e){this.resolvedProperty.fromArray(t,e)}_setValue_fromArray_setNeedsUpdate(t,e){this.resolvedProperty.fromArray(t,e),this.targetObject.needsUpdate=!0}_setValue_fromArray_setMatrixWorldNeedsUpdate(t,e){this.resolvedProperty.fromArray(t,e),this.targetObject.matrixWorldNeedsUpdate=!0}_getValue_unbound(t,e){this.bind(),this.getValue(t,e)}_setValue_unbound(t,e){this.bind(),this.setValue(t,e)}bind(){let t=this.node,e=this.parsedPath,n=e.objectName,s=e.propertyName,r=e.propertyIndex;if(t||(t=i.findNode(this.rootNode,e.nodeName),this.node=t),this.getValue=this._getValue_unavailable,this.setValue=this._setValue_unavailable,!t){console.warn("THREE.PropertyBinding: No target node found for track: "+this.path+".");return}if(n){let c=e.objectIndex;switch(n){case"materials":if(!t.material){console.error("THREE.PropertyBinding: Can not bind to material as node does not have a material.",this);return}if(!t.material.materials){console.error("THREE.PropertyBinding: Can not bind to material.materials as node.material does not have a materials array.",this);return}t=t.material.materials;break;case"bones":if(!t.skeleton){console.error("THREE.PropertyBinding: Can not bind to bones as node does not have a skeleton.",this);return}t=t.skeleton.bones;for(let u=0;u<t.length;u++)if(t[u].name===c){c=u;break}break;case"map":if("map"in t){t=t.map;break}if(!t.material){console.error("THREE.PropertyBinding: Can not bind to material as node does not have a material.",this);return}if(!t.material.map){console.error("THREE.PropertyBinding: Can not bind to material.map as node.material does not have a map.",this);return}t=t.material.map;break;default:if(t[n]===void 0){console.error("THREE.PropertyBinding: Can not bind to objectName of node undefined.",this);return}t=t[n]}if(c!==void 0){if(t[c]===void 0){console.error("THREE.PropertyBinding: Trying to bind to objectIndex of objectName, but is undefined.",this,t);return}t=t[c]}}let o=t[s];if(o===void 0){let c=e.nodeName;console.error("THREE.PropertyBinding: Trying to update property for track: "+c+"."+s+" but it wasn't found.",t);return}let a=this.Versioning.None;this.targetObject=t,t.needsUpdate!==void 0?a=this.Versioning.NeedsUpdate:t.matrixWorldNeedsUpdate!==void 0&&(a=this.Versioning.MatrixWorldNeedsUpdate);let l=this.BindingType.Direct;if(r!==void 0){if(s==="morphTargetInfluences"){if(!t.geometry){console.error("THREE.PropertyBinding: Can not bind to morphTargetInfluences because node does not have a geometry.",this);return}if(!t.geometry.morphAttributes){console.error("THREE.PropertyBinding: Can not bind to morphTargetInfluences because node does not have a geometry.morphAttributes.",this);return}t.morphTargetDictionary[r]!==void 0&&(r=t.morphTargetDictionary[r])}l=this.BindingType.ArrayElement,this.resolvedProperty=o,this.propertyIndex=r}else o.fromArray!==void 0&&o.toArray!==void 0?(l=this.BindingType.HasFromToArray,this.resolvedProperty=o):Array.isArray(o)?(l=this.BindingType.EntireArray,this.resolvedProperty=o):this.propertyName=s;this.getValue=this.GetterByBindingType[l],this.setValue=this.SetterByBindingTypeAndVersioning[l][a]}unbind(){this.node=null,this.getValue=this._getValue_unbound,this.setValue=this._setValue_unbound}};Se.Composite=vl;Se.prototype.BindingType={Direct:0,EntireArray:1,ArrayElement:2,HasFromToArray:3};Se.prototype.Versioning={None:0,NeedsUpdate:1,MatrixWorldNeedsUpdate:2};Se.prototype.GetterByBindingType=[Se.prototype._getValue_direct,Se.prototype._getValue_array,Se.prototype._getValue_arrayElement,Se.prototype._getValue_toArray];Se.prototype.SetterByBindingTypeAndVersioning=[[Se.prototype._setValue_direct,Se.prototype._setValue_direct_setNeedsUpdate,Se.prototype._setValue_direct_setMatrixWorldNeedsUpdate],[Se.prototype._setValue_array,Se.prototype._setValue_array_setNeedsUpdate,Se.prototype._setValue_array_setMatrixWorldNeedsUpdate],[Se.prototype._setValue_arrayElement,Se.prototype._setValue_arrayElement_setNeedsUpdate,Se.prototype._setValue_arrayElement_setMatrixWorldNeedsUpdate],[Se.prototype._setValue_fromArray,Se.prototype._setValue_fromArray_setNeedsUpdate,Se.prototype._setValue_fromArray_setMatrixWorldNeedsUpdate]];var X0=new Float32Array(1);var Ua=class{constructor(t,e,n=0,s=1/0){this.ray=new Xi(t,e),this.near=n,this.far=s,this.camera=null,this.layers=new ur,this.params={Mesh:{},Line:{threshold:1},LOD:{},Points:{threshold:1},Sprite:{}}}set(t,e){this.ray.set(t,e)}setFromCamera(t,e){e.isPerspectiveCamera?(this.ray.origin.setFromMatrixPosition(e.matrixWorld),this.ray.direction.set(t.x,t.y,.5).unproject(e).sub(this.ray.origin).normalize(),this.camera=e):e.isOrthographicCamera?(this.ray.origin.set(t.x,t.y,(e.near+e.far)/(e.near-e.far)).unproject(e),this.ray.direction.set(0,0,-1).transformDirection(e.matrixWorld),this.camera=e):console.error("THREE.Raycaster: Unsupported camera type: "+e.type)}intersectObject(t,e=!0,n=[]){return yl(t,this,n,e),n.sort(Dh),n}intersectObjects(t,e=!0,n=[]){for(let s=0,r=t.length;s<r;s++)yl(t[s],this,n,e);return n.sort(Dh),n}};function Dh(i,t){return i.distance-t.distance}function yl(i,t,e,n){if(i.layers.test(t.layers)&&i.raycast(t,e),n===!0){let s=i.children;for(let r=0,o=s.length;r<o;r++)yl(s[r],t,e,!0)}}var yr=class{constructor(t=1,e=0,n=0){return this.radius=t,this.phi=e,this.theta=n,this}set(t,e,n){return this.radius=t,this.phi=e,this.theta=n,this}copy(t){return this.radius=t.radius,this.phi=t.phi,this.theta=t.theta,this}makeSafe(){return this.phi=Math.max(1e-6,Math.min(Math.PI-1e-6,this.phi)),this}setFromVector3(t){return this.setFromCartesianCoords(t.x,t.y,t.z)}setFromCartesianCoords(t,e,n){return this.radius=Math.sqrt(t*t+e*e+n*n),this.radius===0?(this.theta=0,this.phi=0):(this.theta=Math.atan2(t,n),this.phi=Math.acos(tn(e/this.radius,-1,1))),this}clone(){return new this.constructor().copy(this)}};typeof __THREE_DEVTOOLS__<"u"&&__THREE_DEVTOOLS__.dispatchEvent(new CustomEvent("register",{detail:{revision:"160"}}));typeof window<"u"&&(window.__THREE__?console.warn("WARNING: Multiple instances of Three.js being imported."):window.__THREE__="160");var iu={type:"change"},Il={type:"start"},su={type:"end"},Ba=new Xi,ru=new Ln,z0=Math.cos(70*qh.DEG2RAD),za=class extends Xn{constructor(t,e){super(),this.object=t,this.domElement=e,this.domElement.style.touchAction="none",this.enabled=!0,this.target=new F,this.cursor=new F,this.minDistance=0,this.maxDistance=1/0,this.minZoom=0,this.maxZoom=1/0,this.minTargetRadius=0,this.maxTargetRadius=1/0,this.minPolarAngle=0,this.maxPolarAngle=Math.PI,this.minAzimuthAngle=-1/0,this.maxAzimuthAngle=1/0,this.enableDamping=!1,this.dampingFactor=.05,this.enableZoom=!0,this.zoomSpeed=1,this.enableRotate=!0,this.rotateSpeed=1,this.enablePan=!0,this.panSpeed=1,this.screenSpacePanning=!0,this.keyPanSpeed=7,this.zoomToCursor=!1,this.autoRotate=!1,this.autoRotateSpeed=2,this.keys={LEFT:"ArrowLeft",UP:"ArrowUp",RIGHT:"ArrowRight",BOTTOM:"ArrowDown"},this.mouseButtons={LEFT:Ji.ROTATE,MIDDLE:Ji.DOLLY,RIGHT:Ji.PAN},this.touches={ONE:$i.ROTATE,TWO:$i.DOLLY_PAN},this.target0=this.target.clone(),this.position0=this.object.position.clone(),this.zoom0=this.object.zoom,this._domElementKeyEvents=null,this.getPolarAngle=function(){return a.phi},this.getAzimuthalAngle=function(){return a.theta},this.getDistance=function(){return this.object.position.distanceTo(this.target)},this.listenToKeyEvents=function(P){P.addEventListener("keydown",st),this._domElementKeyEvents=P},this.stopListenToKeyEvents=function(){this._domElementKeyEvents.removeEventListener("keydown",st),this._domElementKeyEvents=null},this.saveState=function(){n.target0.copy(n.target),n.position0.copy(n.object.position),n.zoom0=n.object.zoom},this.reset=function(){n.target.copy(n.target0),n.object.position.copy(n.position0),n.object.zoom=n.zoom0,n.object.updateProjectionMatrix(),n.dispatchEvent(iu),n.update(),r=s.NONE},this.update=(function(){let P=new F,rt=new Nn().setFromUnitVectors(t.up,new F(0,1,0)),mt=rt.clone().invert(),pt=new F,Ut=new Nn,Qt=new F,ee=2*Math.PI;return function(_t=null){let O=n.object.position;P.copy(O).sub(n.target),P.applyQuaternion(rt),a.setFromVector3(P),n.autoRotate&&r===s.NONE&&V(S(_t)),n.enableDamping?(a.theta+=l.theta*n.dampingFactor,a.phi+=l.phi*n.dampingFactor):(a.theta+=l.theta,a.phi+=l.phi);let gt=n.minAzimuthAngle,xt=n.maxAzimuthAngle;isFinite(gt)&&isFinite(xt)&&(gt<-Math.PI?gt+=ee:gt>Math.PI&&(gt-=ee),xt<-Math.PI?xt+=ee:xt>Math.PI&&(xt-=ee),gt<=xt?a.theta=Math.max(gt,Math.min(xt,a.theta)):a.theta=a.theta>(gt+xt)/2?Math.max(gt,a.theta):Math.min(xt,a.theta)),a.phi=Math.max(n.minPolarAngle,Math.min(n.maxPolarAngle,a.phi)),a.makeSafe(),n.enableDamping===!0?n.target.addScaledVector(u,n.dampingFactor):n.target.add(u),n.target.sub(n.cursor),n.target.clampLength(n.minTargetRadius,n.maxTargetRadius),n.target.add(n.cursor),n.zoomToCursor&&N||n.object.isOrthographicCamera?a.radius=$(a.radius):a.radius=$(a.radius*c),P.setFromSpherical(a),P.applyQuaternion(mt),O.copy(n.target).add(P),n.object.lookAt(n.target),n.enableDamping===!0?(l.theta*=1-n.dampingFactor,l.phi*=1-n.dampingFactor,u.multiplyScalar(1-n.dampingFactor)):(l.set(0,0,0),u.set(0,0,0));let Ht=!1;if(n.zoomToCursor&&N){let Ft=null;if(n.object.isPerspectiveCamera){let ce=P.length();Ft=$(ce*c);let ne=ce-Ft;n.object.position.addScaledVector(U,ne),n.object.updateMatrixWorld()}else if(n.object.isOrthographicCamera){let ce=new F(z.x,z.y,0);ce.unproject(n.object),n.object.zoom=Math.max(n.minZoom,Math.min(n.maxZoom,n.object.zoom/c)),n.object.updateProjectionMatrix(),Ht=!0;let ne=new F(z.x,z.y,0);ne.unproject(n.object),n.object.position.sub(ne).add(ce),n.object.updateMatrixWorld(),Ft=P.length()}else console.warn("WARNING: OrbitControls.js encountered an unknown camera type - zoom to cursor disabled."),n.zoomToCursor=!1;Ft!==null&&(this.screenSpacePanning?n.target.set(0,0,-1).transformDirection(n.object.matrix).multiplyScalar(Ft).add(n.object.position):(Ba.origin.copy(n.object.position),Ba.direction.set(0,0,-1).transformDirection(n.object.matrix),Math.abs(n.object.up.dot(Ba.direction))<z0?t.lookAt(n.target):(ru.setFromNormalAndCoplanarPoint(n.object.up,n.target),Ba.intersectPlane(ru,n.target))))}else n.object.isOrthographicCamera&&(n.object.zoom=Math.max(n.minZoom,Math.min(n.maxZoom,n.object.zoom/c)),n.object.updateProjectionMatrix(),Ht=!0);return c=1,N=!1,Ht||pt.distanceToSquared(n.object.position)>o||8*(1-Ut.dot(n.object.quaternion))>o||Qt.distanceToSquared(n.target)>0?(n.dispatchEvent(iu),pt.copy(n.object.position),Ut.copy(n.object.quaternion),Qt.copy(n.target),!0):!1}})(),this.dispose=function(){n.domElement.removeEventListener("contextmenu",ht),n.domElement.removeEventListener("pointerdown",$t),n.domElement.removeEventListener("pointercancel",M),n.domElement.removeEventListener("wheel",lt),n.domElement.removeEventListener("pointermove",A),n.domElement.removeEventListener("pointerup",M),n._domElementKeyEvents!==null&&(n._domElementKeyEvents.removeEventListener("keydown",st),n._domElementKeyEvents=null)};let n=this,s={NONE:-1,ROTATE:0,DOLLY:1,PAN:2,TOUCH_ROTATE:3,TOUCH_PAN:4,TOUCH_DOLLY_PAN:5,TOUCH_DOLLY_ROTATE:6},r=s.NONE,o=1e-6,a=new yr,l=new yr,c=1,u=new F,f=new Pt,p=new Pt,x=new Pt,y=new Pt,b=new Pt,m=new Pt,d=new Pt,C=new Pt,w=new Pt,U=new F,z=new Pt,N=!1,L=[],j={};function S(P){return P!==null?2*Math.PI/60*n.autoRotateSpeed*P:2*Math.PI/60/60*n.autoRotateSpeed}function R(P){let rt=Math.abs(P)/(100*(window.devicePixelRatio|0));return Math.pow(.95,n.zoomSpeed*rt)}function V(P){l.theta-=P}function tt(P){l.phi-=P}let ft=(function(){let P=new F;return function(mt,pt){P.setFromMatrixColumn(pt,0),P.multiplyScalar(-mt),u.add(P)}})(),I=(function(){let P=new F;return function(mt,pt){n.screenSpacePanning===!0?P.setFromMatrixColumn(pt,1):(P.setFromMatrixColumn(pt,0),P.crossVectors(n.object.up,P)),P.multiplyScalar(mt),u.add(P)}})(),k=(function(){let P=new F;return function(mt,pt){let Ut=n.domElement;if(n.object.isPerspectiveCamera){let Qt=n.object.position;P.copy(Qt).sub(n.target);let ee=P.length();ee*=Math.tan(n.object.fov/2*Math.PI/180),ft(2*mt*ee/Ut.clientHeight,n.object.matrix),I(2*pt*ee/Ut.clientHeight,n.object.matrix)}else n.object.isOrthographicCamera?(ft(mt*(n.object.right-n.object.left)/n.object.zoom/Ut.clientWidth,n.object.matrix),I(pt*(n.object.top-n.object.bottom)/n.object.zoom/Ut.clientHeight,n.object.matrix)):(console.warn("WARNING: OrbitControls.js encountered an unknown camera type - pan disabled."),n.enablePan=!1)}})();function G(P){n.object.isPerspectiveCamera||n.object.isOrthographicCamera?c/=P:(console.warn("WARNING: OrbitControls.js encountered an unknown camera type - dolly/zoom disabled."),n.enableZoom=!1)}function K(P){n.object.isPerspectiveCamera||n.object.isOrthographicCamera?c*=P:(console.warn("WARNING: OrbitControls.js encountered an unknown camera type - dolly/zoom disabled."),n.enableZoom=!1)}function Q(P,rt){if(!n.zoomToCursor)return;N=!0;let mt=n.domElement.getBoundingClientRect(),pt=P-mt.left,Ut=rt-mt.top,Qt=mt.width,ee=mt.height;z.x=pt/Qt*2-1,z.y=-(Ut/ee)*2+1,U.set(z.x,z.y,1).unproject(n.object).sub(n.object.position).normalize()}function $(P){return Math.max(n.minDistance,Math.min(n.maxDistance,P))}function nt(P){f.set(P.clientX,P.clientY)}function ct(P){Q(P.clientX,P.clientX),d.set(P.clientX,P.clientY)}function bt(P){y.set(P.clientX,P.clientY)}function J(P){p.set(P.clientX,P.clientY),x.subVectors(p,f).multiplyScalar(n.rotateSpeed);let rt=n.domElement;V(2*Math.PI*x.x/rt.clientHeight),tt(2*Math.PI*x.y/rt.clientHeight),f.copy(p),n.update()}function ot(P){C.set(P.clientX,P.clientY),w.subVectors(C,d),w.y>0?G(R(w.y)):w.y<0&&K(R(w.y)),d.copy(C),n.update()}function vt(P){b.set(P.clientX,P.clientY),m.subVectors(b,y).multiplyScalar(n.panSpeed),k(m.x,m.y),y.copy(b),n.update()}function Lt(P){Q(P.clientX,P.clientY),P.deltaY<0?K(R(P.deltaY)):P.deltaY>0&&G(R(P.deltaY)),n.update()}function Nt(P){let rt=!1;switch(P.code){case n.keys.UP:P.ctrlKey||P.metaKey||P.shiftKey?tt(2*Math.PI*n.rotateSpeed/n.domElement.clientHeight):k(0,n.keyPanSpeed),rt=!0;break;case n.keys.BOTTOM:P.ctrlKey||P.metaKey||P.shiftKey?tt(-2*Math.PI*n.rotateSpeed/n.domElement.clientHeight):k(0,-n.keyPanSpeed),rt=!0;break;case n.keys.LEFT:P.ctrlKey||P.metaKey||P.shiftKey?V(2*Math.PI*n.rotateSpeed/n.domElement.clientHeight):k(n.keyPanSpeed,0),rt=!0;break;case n.keys.RIGHT:P.ctrlKey||P.metaKey||P.shiftKey?V(-2*Math.PI*n.rotateSpeed/n.domElement.clientHeight):k(-n.keyPanSpeed,0),rt=!0;break}rt&&(P.preventDefault(),n.update())}function Ct(P){if(L.length===1)f.set(P.pageX,P.pageY);else{let rt=se(P),mt=.5*(P.pageX+rt.x),pt=.5*(P.pageY+rt.y);f.set(mt,pt)}}function It(P){if(L.length===1)y.set(P.pageX,P.pageY);else{let rt=se(P),mt=.5*(P.pageX+rt.x),pt=.5*(P.pageY+rt.y);y.set(mt,pt)}}function Tt(P){let rt=se(P),mt=P.pageX-rt.x,pt=P.pageY-rt.y,Ut=Math.sqrt(mt*mt+pt*pt);d.set(0,Ut)}function kt(P){n.enableZoom&&Tt(P),n.enablePan&&It(P)}function W(P){n.enableZoom&&Tt(P),n.enableRotate&&Ct(P)}function Pe(P){if(L.length==1)p.set(P.pageX,P.pageY);else{let mt=se(P),pt=.5*(P.pageX+mt.x),Ut=.5*(P.pageY+mt.y);p.set(pt,Ut)}x.subVectors(p,f).multiplyScalar(n.rotateSpeed);let rt=n.domElement;V(2*Math.PI*x.x/rt.clientHeight),tt(2*Math.PI*x.y/rt.clientHeight),f.copy(p)}function Dt(P){if(L.length===1)b.set(P.pageX,P.pageY);else{let rt=se(P),mt=.5*(P.pageX+rt.x),pt=.5*(P.pageY+rt.y);b.set(mt,pt)}m.subVectors(b,y).multiplyScalar(n.panSpeed),k(m.x,m.y),y.copy(b)}function Gt(P){let rt=se(P),mt=P.pageX-rt.x,pt=P.pageY-rt.y,Ut=Math.sqrt(mt*mt+pt*pt);C.set(0,Ut),w.set(0,Math.pow(C.y/d.y,n.zoomSpeed)),G(w.y),d.copy(C);let Qt=(P.pageX+rt.x)*.5,ee=(P.pageY+rt.y)*.5;Q(Qt,ee)}function Rt(P){n.enableZoom&&Gt(P),n.enablePan&&Dt(P)}function me(P){n.enableZoom&&Gt(P),n.enableRotate&&Pe(P)}function $t(P){n.enabled!==!1&&(L.length===0&&(n.domElement.setPointerCapture(P.pointerId),n.domElement.addEventListener("pointermove",A),n.domElement.addEventListener("pointerup",M)),Ot(P),P.pointerType==="touch"?Et(P):X(P))}function A(P){n.enabled!==!1&&(P.pointerType==="touch"?Mt(P):ut(P))}function M(P){Yt(P),L.length===0&&(n.domElement.releasePointerCapture(P.pointerId),n.domElement.removeEventListener("pointermove",A),n.domElement.removeEventListener("pointerup",M)),n.dispatchEvent(su),r=s.NONE}function X(P){let rt;switch(P.button){case 0:rt=n.mouseButtons.LEFT;break;case 1:rt=n.mouseButtons.MIDDLE;break;case 2:rt=n.mouseButtons.RIGHT;break;default:rt=-1}switch(rt){case Ji.DOLLY:if(n.enableZoom===!1)return;ct(P),r=s.DOLLY;break;case Ji.ROTATE:if(P.ctrlKey||P.metaKey||P.shiftKey){if(n.enablePan===!1)return;bt(P),r=s.PAN}else{if(n.enableRotate===!1)return;nt(P),r=s.ROTATE}break;case Ji.PAN:if(P.ctrlKey||P.metaKey||P.shiftKey){if(n.enableRotate===!1)return;nt(P),r=s.ROTATE}else{if(n.enablePan===!1)return;bt(P),r=s.PAN}break;default:r=s.NONE}r!==s.NONE&&n.dispatchEvent(Il)}function ut(P){switch(r){case s.ROTATE:if(n.enableRotate===!1)return;J(P);break;case s.DOLLY:if(n.enableZoom===!1)return;ot(P);break;case s.PAN:if(n.enablePan===!1)return;vt(P);break}}function lt(P){n.enabled===!1||n.enableZoom===!1||r!==s.NONE||(P.preventDefault(),n.dispatchEvent(Il),Lt(P),n.dispatchEvent(su))}function st(P){n.enabled===!1||n.enablePan===!1||Nt(P)}function Et(P){switch(at(P),L.length){case 1:switch(n.touches.ONE){case $i.ROTATE:if(n.enableRotate===!1)return;Ct(P),r=s.TOUCH_ROTATE;break;case $i.PAN:if(n.enablePan===!1)return;It(P),r=s.TOUCH_PAN;break;default:r=s.NONE}break;case 2:switch(n.touches.TWO){case $i.DOLLY_PAN:if(n.enableZoom===!1&&n.enablePan===!1)return;kt(P),r=s.TOUCH_DOLLY_PAN;break;case $i.DOLLY_ROTATE:if(n.enableZoom===!1&&n.enableRotate===!1)return;W(P),r=s.TOUCH_DOLLY_ROTATE;break;default:r=s.NONE}break;default:r=s.NONE}r!==s.NONE&&n.dispatchEvent(Il)}function Mt(P){switch(at(P),r){case s.TOUCH_ROTATE:if(n.enableRotate===!1)return;Pe(P),n.update();break;case s.TOUCH_PAN:if(n.enablePan===!1)return;Dt(P),n.update();break;case s.TOUCH_DOLLY_PAN:if(n.enableZoom===!1&&n.enablePan===!1)return;Rt(P),n.update();break;case s.TOUCH_DOLLY_ROTATE:if(n.enableZoom===!1&&n.enableRotate===!1)return;me(P),n.update();break;default:r=s.NONE}}function ht(P){n.enabled!==!1&&P.preventDefault()}function Ot(P){L.push(P.pointerId)}function Yt(P){delete j[P.pointerId];for(let rt=0;rt<L.length;rt++)if(L[rt]==P.pointerId){L.splice(rt,1);return}}function at(P){let rt=j[P.pointerId];rt===void 0&&(rt=new Pt,j[P.pointerId]=rt),rt.set(P.pageX,P.pageY)}function se(P){let rt=P.pointerId===L[0]?L[1]:L[0];return j[rt]}n.domElement.addEventListener("contextmenu",ht),n.domElement.addEventListener("pointerdown",$t),n.domElement.addEventListener("pointercancel",M),n.domElement.addEventListener("wheel",lt,{passive:!1}),this.update()}};var ka={name:"CopyShader",uniforms:{tDiffuse:{value:null},opacity:{value:1}},vertexShader:`

		varying vec2 vUv;

		void main() {

			vUv = uv;
			gl_Position = projectionMatrix * modelViewMatrix * vec4( position, 1.0 );

		}`,fragmentShader:`

		uniform float opacity;

		uniform sampler2D tDiffuse;

		varying vec2 vUv;

		void main() {

			vec4 texel = texture2D( tDiffuse, vUv );
			gl_FragColor = opacity * texel;


		}`};var xn=class{constructor(){this.isPass=!0,this.enabled=!0,this.needsSwap=!0,this.clear=!1,this.renderToScreen=!1}setSize(){}render(){console.error("THREE.Pass: .render() must be implemented in derived pass.")}dispose(){}},k0=new Us(-1,1,1,-1,0,1),Dl=class extends hn{constructor(){super(),this.setAttribute("position",new Ze([-1,3,0,-1,-1,0,3,-1,0],3)),this.setAttribute("uv",new Ze([0,2,0,0,2,0],2))}},H0=new Dl,Ei=class{constructor(t){this._mesh=new ke(H0,t)}dispose(){this._mesh.geometry.dispose()}render(t){t.render(this._mesh,k0)}get material(){return this._mesh.material}set material(t){this._mesh.material=t}};var ks=class extends xn{constructor(t,e){super(),this.textureID=e!==void 0?e:"tDiffuse",t instanceof Ne?(this.uniforms=t.uniforms,this.material=t):t&&(this.uniforms=wi.clone(t.uniforms),this.material=new Ne({name:t.name!==void 0?t.name:"unspecified",defines:Object.assign({},t.defines),uniforms:this.uniforms,vertexShader:t.vertexShader,fragmentShader:t.fragmentShader})),this.fsQuad=new Ei(this.material)}render(t,e,n){this.uniforms[this.textureID]&&(this.uniforms[this.textureID].value=n.texture),this.fsQuad.material=this.material,this.renderToScreen?(t.setRenderTarget(null),this.fsQuad.render(t)):(t.setRenderTarget(e),this.clear&&t.clear(t.autoClearColor,t.autoClearDepth,t.autoClearStencil),this.fsQuad.render(t))}dispose(){this.material.dispose(),this.fsQuad.dispose()}};var br=class extends xn{constructor(t,e){super(),this.scene=t,this.camera=e,this.clear=!0,this.needsSwap=!1,this.inverse=!1}render(t,e,n){let s=t.getContext(),r=t.state;r.buffers.color.setMask(!1),r.buffers.depth.setMask(!1),r.buffers.color.setLocked(!0),r.buffers.depth.setLocked(!0);let o,a;this.inverse?(o=0,a=1):(o=1,a=0),r.buffers.stencil.setTest(!0),r.buffers.stencil.setOp(s.REPLACE,s.REPLACE,s.REPLACE),r.buffers.stencil.setFunc(s.ALWAYS,o,4294967295),r.buffers.stencil.setClear(a),r.buffers.stencil.setLocked(!0),t.setRenderTarget(n),this.clear&&t.clear(),t.render(this.scene,this.camera),t.setRenderTarget(e),this.clear&&t.clear(),t.render(this.scene,this.camera),r.buffers.color.setLocked(!1),r.buffers.depth.setLocked(!1),r.buffers.color.setMask(!0),r.buffers.depth.setMask(!0),r.buffers.stencil.setLocked(!1),r.buffers.stencil.setFunc(s.EQUAL,1,4294967295),r.buffers.stencil.setOp(s.KEEP,s.KEEP,s.KEEP),r.buffers.stencil.setLocked(!0)}},Ha=class extends xn{constructor(){super(),this.needsSwap=!1}render(t){t.state.buffers.stencil.setLocked(!1),t.state.buffers.stencil.setTest(!1)}};var Va=class{constructor(t,e){if(this.renderer=t,this._pixelRatio=t.getPixelRatio(),e===void 0){let n=t.getSize(new Pt);this._width=n.width,this._height=n.height,e=new je(this._width*this._pixelRatio,this._height*this._pixelRatio,{type:mn}),e.texture.name="EffectComposer.rt1"}else this._width=e.width,this._height=e.height;this.renderTarget1=e,this.renderTarget2=e.clone(),this.renderTarget2.texture.name="EffectComposer.rt2",this.writeBuffer=this.renderTarget1,this.readBuffer=this.renderTarget2,this.renderToScreen=!0,this.passes=[],this.copyPass=new ks(ka),this.copyPass.material.blending=Wn,this.clock=new Da}swapBuffers(){let t=this.readBuffer;this.readBuffer=this.writeBuffer,this.writeBuffer=t}addPass(t){this.passes.push(t),t.setSize(this._width*this._pixelRatio,this._height*this._pixelRatio)}insertPass(t,e){this.passes.splice(e,0,t),t.setSize(this._width*this._pixelRatio,this._height*this._pixelRatio)}removePass(t){let e=this.passes.indexOf(t);e!==-1&&this.passes.splice(e,1)}isLastEnabledPass(t){for(let e=t+1;e<this.passes.length;e++)if(this.passes[e].enabled)return!1;return!0}render(t){t===void 0&&(t=this.clock.getDelta());let e=this.renderer.getRenderTarget(),n=!1;for(let s=0,r=this.passes.length;s<r;s++){let o=this.passes[s];if(o.enabled!==!1){if(o.renderToScreen=this.renderToScreen&&this.isLastEnabledPass(s),o.render(this.renderer,this.writeBuffer,this.readBuffer,t,n),o.needsSwap){if(n){let a=this.renderer.getContext(),l=this.renderer.state.buffers.stencil;l.setFunc(a.NOTEQUAL,1,4294967295),this.copyPass.render(this.renderer,this.writeBuffer,this.readBuffer,t),l.setFunc(a.EQUAL,1,4294967295)}this.swapBuffers()}br!==void 0&&(o instanceof br?n=!0:o instanceof Ha&&(n=!1))}}this.renderer.setRenderTarget(e)}reset(t){if(t===void 0){let e=this.renderer.getSize(new Pt);this._pixelRatio=this.renderer.getPixelRatio(),this._width=e.width,this._height=e.height,t=this.renderTarget1.clone(),t.setSize(this._width*this._pixelRatio,this._height*this._pixelRatio)}this.renderTarget1.dispose(),this.renderTarget2.dispose(),this.renderTarget1=t,this.renderTarget2=t.clone(),this.writeBuffer=this.renderTarget1,this.readBuffer=this.renderTarget2}setSize(t,e){this._width=t,this._height=e;let n=this._width*this._pixelRatio,s=this._height*this._pixelRatio;this.renderTarget1.setSize(n,s),this.renderTarget2.setSize(n,s);for(let r=0;r<this.passes.length;r++)this.passes[r].setSize(n,s)}setPixelRatio(t){this._pixelRatio=t,this.setSize(this._width,this._height)}dispose(){this.renderTarget1.dispose(),this.renderTarget2.dispose(),this.copyPass.dispose()}};var Ga=class extends xn{constructor(t,e,n=null,s=null,r=null){super(),this.scene=t,this.camera=e,this.overrideMaterial=n,this.clearColor=s,this.clearAlpha=r,this.clear=!0,this.clearDepth=!1,this.needsSwap=!1,this._oldClearColor=new qt}render(t,e,n){let s=t.autoClear;t.autoClear=!1;let r,o;this.overrideMaterial!==null&&(o=this.scene.overrideMaterial,this.scene.overrideMaterial=this.overrideMaterial),this.clearColor!==null&&(t.getClearColor(this._oldClearColor),t.setClearColor(this.clearColor)),this.clearAlpha!==null&&(r=t.getClearAlpha(),t.setClearAlpha(this.clearAlpha)),this.clearDepth==!0&&t.clearDepth(),t.setRenderTarget(this.renderToScreen?null:n),this.clear===!0&&t.clear(t.autoClearColor,t.autoClearDepth,t.autoClearStencil),t.render(this.scene,this.camera),this.clearColor!==null&&t.setClearColor(this._oldClearColor),this.clearAlpha!==null&&t.setClearAlpha(r),this.overrideMaterial!==null&&(this.scene.overrideMaterial=o),t.autoClear=s}};var au={name:"LuminosityHighPassShader",shaderID:"luminosityHighPass",uniforms:{tDiffuse:{value:null},luminosityThreshold:{value:1},smoothWidth:{value:1},defaultColor:{value:new qt(0)},defaultOpacity:{value:0}},vertexShader:`

		varying vec2 vUv;

		void main() {

			vUv = uv;

			gl_Position = projectionMatrix * modelViewMatrix * vec4( position, 1.0 );

		}`,fragmentShader:`

		uniform sampler2D tDiffuse;
		uniform vec3 defaultColor;
		uniform float defaultOpacity;
		uniform float luminosityThreshold;
		uniform float smoothWidth;

		varying vec2 vUv;

		void main() {

			vec4 texel = texture2D( tDiffuse, vUv );

			vec3 luma = vec3( 0.299, 0.587, 0.114 );

			float v = dot( texel.xyz, luma );

			vec4 outputColor = vec4( defaultColor.rgb, defaultOpacity );

			float alpha = smoothstep( luminosityThreshold, luminosityThreshold + smoothWidth, v );

			gl_FragColor = mix( outputColor, texel, alpha );

		}`};var Hs=class i extends xn{constructor(t,e,n,s){super(),this.strength=e!==void 0?e:1,this.radius=n,this.threshold=s,this.resolution=t!==void 0?new Pt(t.x,t.y):new Pt(256,256),this.clearColor=new qt(0,0,0),this.renderTargetsHorizontal=[],this.renderTargetsVertical=[],this.nMips=5;let r=Math.round(this.resolution.x/2),o=Math.round(this.resolution.y/2);this.renderTargetBright=new je(r,o,{type:mn}),this.renderTargetBright.texture.name="UnrealBloomPass.bright",this.renderTargetBright.texture.generateMipmaps=!1;for(let f=0;f<this.nMips;f++){let p=new je(r,o,{type:mn});p.texture.name="UnrealBloomPass.h"+f,p.texture.generateMipmaps=!1,this.renderTargetsHorizontal.push(p);let x=new je(r,o,{type:mn});x.texture.name="UnrealBloomPass.v"+f,x.texture.generateMipmaps=!1,this.renderTargetsVertical.push(x),r=Math.round(r/2),o=Math.round(o/2)}let a=au;this.highPassUniforms=wi.clone(a.uniforms),this.highPassUniforms.luminosityThreshold.value=s,this.highPassUniforms.smoothWidth.value=.01,this.materialHighPassFilter=new Ne({uniforms:this.highPassUniforms,vertexShader:a.vertexShader,fragmentShader:a.fragmentShader}),this.separableBlurMaterials=[];let l=[3,5,7,9,11];r=Math.round(this.resolution.x/2),o=Math.round(this.resolution.y/2);for(let f=0;f<this.nMips;f++)this.separableBlurMaterials.push(this.getSeperableBlurMaterial(l[f])),this.separableBlurMaterials[f].uniforms.invSize.value=new Pt(1/r,1/o),r=Math.round(r/2),o=Math.round(o/2);this.compositeMaterial=this.getCompositeMaterial(this.nMips),this.compositeMaterial.uniforms.blurTexture1.value=this.renderTargetsVertical[0].texture,this.compositeMaterial.uniforms.blurTexture2.value=this.renderTargetsVertical[1].texture,this.compositeMaterial.uniforms.blurTexture3.value=this.renderTargetsVertical[2].texture,this.compositeMaterial.uniforms.blurTexture4.value=this.renderTargetsVertical[3].texture,this.compositeMaterial.uniforms.blurTexture5.value=this.renderTargetsVertical[4].texture,this.compositeMaterial.uniforms.bloomStrength.value=e,this.compositeMaterial.uniforms.bloomRadius.value=.1;let c=[1,.8,.6,.4,.2];this.compositeMaterial.uniforms.bloomFactors.value=c,this.bloomTintColors=[new F(1,1,1),new F(1,1,1),new F(1,1,1),new F(1,1,1),new F(1,1,1)],this.compositeMaterial.uniforms.bloomTintColors.value=this.bloomTintColors;let u=ka;this.copyUniforms=wi.clone(u.uniforms),this.blendMaterial=new Ne({uniforms:this.copyUniforms,vertexShader:u.vertexShader,fragmentShader:u.fragmentShader,blending:Rs,depthTest:!1,depthWrite:!1,transparent:!0}),this.enabled=!0,this.needsSwap=!1,this._oldClearColor=new qt,this.oldClearAlpha=1,this.basic=new gn,this.fsQuad=new Ei(null)}dispose(){for(let t=0;t<this.renderTargetsHorizontal.length;t++)this.renderTargetsHorizontal[t].dispose();for(let t=0;t<this.renderTargetsVertical.length;t++)this.renderTargetsVertical[t].dispose();this.renderTargetBright.dispose();for(let t=0;t<this.separableBlurMaterials.length;t++)this.separableBlurMaterials[t].dispose();this.compositeMaterial.dispose(),this.blendMaterial.dispose(),this.basic.dispose(),this.fsQuad.dispose()}setSize(t,e){let n=Math.round(t/2),s=Math.round(e/2);this.renderTargetBright.setSize(n,s);for(let r=0;r<this.nMips;r++)this.renderTargetsHorizontal[r].setSize(n,s),this.renderTargetsVertical[r].setSize(n,s),this.separableBlurMaterials[r].uniforms.invSize.value=new Pt(1/n,1/s),n=Math.round(n/2),s=Math.round(s/2)}render(t,e,n,s,r){t.getClearColor(this._oldClearColor),this.oldClearAlpha=t.getClearAlpha();let o=t.autoClear;t.autoClear=!1,t.setClearColor(this.clearColor,0),r&&t.state.buffers.stencil.setTest(!1),this.renderToScreen&&(this.fsQuad.material=this.basic,this.basic.map=n.texture,t.setRenderTarget(null),t.clear(),this.fsQuad.render(t)),this.highPassUniforms.tDiffuse.value=n.texture,this.highPassUniforms.luminosityThreshold.value=this.threshold,this.fsQuad.material=this.materialHighPassFilter,t.setRenderTarget(this.renderTargetBright),t.clear(),this.fsQuad.render(t);let a=this.renderTargetBright;for(let l=0;l<this.nMips;l++)this.fsQuad.material=this.separableBlurMaterials[l],this.separableBlurMaterials[l].uniforms.colorTexture.value=a.texture,this.separableBlurMaterials[l].uniforms.direction.value=i.BlurDirectionX,t.setRenderTarget(this.renderTargetsHorizontal[l]),t.clear(),this.fsQuad.render(t),this.separableBlurMaterials[l].uniforms.colorTexture.value=this.renderTargetsHorizontal[l].texture,this.separableBlurMaterials[l].uniforms.direction.value=i.BlurDirectionY,t.setRenderTarget(this.renderTargetsVertical[l]),t.clear(),this.fsQuad.render(t),a=this.renderTargetsVertical[l];this.fsQuad.material=this.compositeMaterial,this.compositeMaterial.uniforms.bloomStrength.value=this.strength,this.compositeMaterial.uniforms.bloomRadius.value=this.radius,this.compositeMaterial.uniforms.bloomTintColors.value=this.bloomTintColors,t.setRenderTarget(this.renderTargetsHorizontal[0]),t.clear(),this.fsQuad.render(t),this.fsQuad.material=this.blendMaterial,this.copyUniforms.tDiffuse.value=this.renderTargetsHorizontal[0].texture,r&&t.state.buffers.stencil.setTest(!0),this.renderToScreen?(t.setRenderTarget(null),this.fsQuad.render(t)):(t.setRenderTarget(n),this.fsQuad.render(t)),t.setClearColor(this._oldClearColor,this.oldClearAlpha),t.autoClear=o}getSeperableBlurMaterial(t){let e=[];for(let n=0;n<t;n++)e.push(.39894*Math.exp(-.5*n*n/(t*t))/t);return new Ne({defines:{KERNEL_RADIUS:t},uniforms:{colorTexture:{value:null},invSize:{value:new Pt(.5,.5)},direction:{value:new Pt(.5,.5)},gaussianCoefficients:{value:e}},vertexShader:`varying vec2 vUv;
				void main() {
					vUv = uv;
					gl_Position = projectionMatrix * modelViewMatrix * vec4( position, 1.0 );
				}`,fragmentShader:`#include <common>
				varying vec2 vUv;
				uniform sampler2D colorTexture;
				uniform vec2 invSize;
				uniform vec2 direction;
				uniform float gaussianCoefficients[KERNEL_RADIUS];

				void main() {
					float weightSum = gaussianCoefficients[0];
					vec3 diffuseSum = texture2D( colorTexture, vUv ).rgb * weightSum;
					for( int i = 1; i < KERNEL_RADIUS; i ++ ) {
						float x = float(i);
						float w = gaussianCoefficients[i];
						vec2 uvOffset = direction * invSize * x;
						vec3 sample1 = texture2D( colorTexture, vUv + uvOffset ).rgb;
						vec3 sample2 = texture2D( colorTexture, vUv - uvOffset ).rgb;
						diffuseSum += (sample1 + sample2) * w;
						weightSum += 2.0 * w;
					}
					gl_FragColor = vec4(diffuseSum/weightSum, 1.0);
				}`})}getCompositeMaterial(t){return new Ne({defines:{NUM_MIPS:t},uniforms:{blurTexture1:{value:null},blurTexture2:{value:null},blurTexture3:{value:null},blurTexture4:{value:null},blurTexture5:{value:null},bloomStrength:{value:1},bloomFactors:{value:null},bloomTintColors:{value:null},bloomRadius:{value:0}},vertexShader:`varying vec2 vUv;
				void main() {
					vUv = uv;
					gl_Position = projectionMatrix * modelViewMatrix * vec4( position, 1.0 );
				}`,fragmentShader:`varying vec2 vUv;
				uniform sampler2D blurTexture1;
				uniform sampler2D blurTexture2;
				uniform sampler2D blurTexture3;
				uniform sampler2D blurTexture4;
				uniform sampler2D blurTexture5;
				uniform float bloomStrength;
				uniform float bloomRadius;
				uniform float bloomFactors[NUM_MIPS];
				uniform vec3 bloomTintColors[NUM_MIPS];

				float lerpBloomFactor(const in float factor) {
					float mirrorFactor = 1.2 - factor;
					return mix(factor, mirrorFactor, bloomRadius);
				}

				void main() {
					gl_FragColor = bloomStrength * ( lerpBloomFactor(bloomFactors[0]) * vec4(bloomTintColors[0], 1.0) * texture2D(blurTexture1, vUv) +
						lerpBloomFactor(bloomFactors[1]) * vec4(bloomTintColors[1], 1.0) * texture2D(blurTexture2, vUv) +
						lerpBloomFactor(bloomFactors[2]) * vec4(bloomTintColors[2], 1.0) * texture2D(blurTexture3, vUv) +
						lerpBloomFactor(bloomFactors[3]) * vec4(bloomTintColors[3], 1.0) * texture2D(blurTexture4, vUv) +
						lerpBloomFactor(bloomFactors[4]) * vec4(bloomTintColors[4], 1.0) * texture2D(blurTexture5, vUv) );
				}`})}};Hs.BlurDirectionX=new Pt(1,0);Hs.BlurDirectionY=new Pt(0,1);var ou={name:"VignetteShader",uniforms:{tDiffuse:{value:null},offset:{value:1},darkness:{value:1}},vertexShader:`

		varying vec2 vUv;

		void main() {

			vUv = uv;
			gl_Position = projectionMatrix * modelViewMatrix * vec4( position, 1.0 );

		}`,fragmentShader:`

		uniform float offset;
		uniform float darkness;

		uniform sampler2D tDiffuse;

		varying vec2 vUv;

		void main() {

			// Eskil's vignette

			vec4 texel = texture2D( tDiffuse, vUv );
			vec2 uv = ( vUv - vec2( 0.5 ) ) * vec2( offset );
			gl_FragColor = vec4( mix( texel.rgb, vec3( 1.0 - darkness ), dot( uv, uv ) ), texel.a );

		}`};var lu={name:"OutputShader",uniforms:{tDiffuse:{value:null},toneMappingExposure:{value:1}},vertexShader:`
		precision highp float;

		uniform mat4 modelViewMatrix;
		uniform mat4 projectionMatrix;

		attribute vec3 position;
		attribute vec2 uv;

		varying vec2 vUv;

		void main() {

			vUv = uv;
			gl_Position = projectionMatrix * modelViewMatrix * vec4( position, 1.0 );

		}`,fragmentShader:`
	
		precision highp float;

		uniform sampler2D tDiffuse;

		#include <tonemapping_pars_fragment>
		#include <colorspace_pars_fragment>

		varying vec2 vUv;

		void main() {

			gl_FragColor = texture2D( tDiffuse, vUv );

			// tone mapping

			#ifdef LINEAR_TONE_MAPPING

				gl_FragColor.rgb = LinearToneMapping( gl_FragColor.rgb );

			#elif defined( REINHARD_TONE_MAPPING )

				gl_FragColor.rgb = ReinhardToneMapping( gl_FragColor.rgb );

			#elif defined( CINEON_TONE_MAPPING )

				gl_FragColor.rgb = OptimizedCineonToneMapping( gl_FragColor.rgb );

			#elif defined( ACES_FILMIC_TONE_MAPPING )

				gl_FragColor.rgb = ACESFilmicToneMapping( gl_FragColor.rgb );

			#elif defined( AGX_TONE_MAPPING )

				gl_FragColor.rgb = AgXToneMapping( gl_FragColor.rgb );

			#endif

			// color space

			#ifdef SRGB_TRANSFER

				gl_FragColor = sRGBTransferOETF( gl_FragColor );

			#endif

		}`};var Wa=class extends xn{constructor(){super();let t=lu;this.uniforms=wi.clone(t.uniforms),this.material=new Ca({name:t.name,uniforms:this.uniforms,vertexShader:t.vertexShader,fragmentShader:t.fragmentShader}),this.fsQuad=new Ei(this.material),this._outputColorSpace=null,this._toneMapping=null}render(t,e,n){this.uniforms.tDiffuse.value=n.texture,this.uniforms.toneMappingExposure.value=t.toneMappingExposure,(this._outputColorSpace!==t.outputColorSpace||this._toneMapping!==t.toneMapping)&&(this._outputColorSpace=t.outputColorSpace,this._toneMapping=t.toneMapping,this.material.defines={},fe.getTransfer(this._outputColorSpace)===ge&&(this.material.defines.SRGB_TRANSFER=""),this._toneMapping===bl?this.material.defines.LINEAR_TONE_MAPPING="":this._toneMapping===Sl?this.material.defines.REINHARD_TONE_MAPPING="":this._toneMapping===wl?this.material.defines.CINEON_TONE_MAPPING="":this._toneMapping===Mr?this.material.defines.ACES_FILMIC_TONE_MAPPING="":this._toneMapping===El&&(this.material.defines.AGX_TONE_MAPPING=""),this.material.needsUpdate=!0),this.renderToScreen===!0?(t.setRenderTarget(null),this.fsQuad.render(t)):(t.setRenderTarget(e),this.clear&&t.clear(t.autoClearColor,t.autoClearDepth,t.autoClearStencil),this.fsQuad.render(t))}dispose(){this.material.dispose(),this.fsQuad.dispose()}};var V0=`.pw { position: relative; width: 100%; height: 100%; overflow: hidden; background: #2a1d4a; color: #fff; font-family: "Malgun Gothic", "Apple SD Gothic Neo", sans-serif; }

  .pw { --bg: rgba(36,22,60,.82); --bd: rgba(255,255,255,.35); --ac: #ffaa64; }
  
  canvas.gl { display: block; }
  button { font: inherit; color: inherit; cursor: pointer; }
  #rail { position: absolute; left: 0; top: 0; bottom: 0; width: 56px; background: rgba(28,16,48,.88); border-right: 2px solid var(--bd); display: flex; flex-direction: column; align-items: center; padding-top: 10px; gap: 6px; z-index: 5; }
  #rail .logo { font-weight: 800; font-size: 11px; letter-spacing: .05em; margin-bottom: 8px; opacity: .85; text-align: center; line-height: 1.1; }
  #rail button { width: 44px; height: 48px; background: transparent; border: 2px solid transparent; font-size: 20px; display: flex; flex-direction: column; align-items: center; justify-content: center; gap: 1px; }
  #rail button span { font-size: 10px; font-weight: 700; opacity: .85; }
  #rail button:hover { background: rgba(255,255,255,.08); }
  #rail button.on { background: rgba(255,170,100,.9); border-color: #fff; color: #3a1f4a; }
  #panel { position: absolute; left: 56px; top: 0; bottom: 0; width: 340px; background: var(--bg); border-right: 2px solid var(--bd); backdrop-filter: blur(6px); transform: translateX(-110%); transition: transform .22s; z-index: 4; overflow-y: auto; padding: 14px 16px 30px; box-sizing: border-box; }
  #panel.open { transform: none; }
  #panel h2 { margin: 0 0 12px; font-size: 16px; letter-spacing: .04em; }
  #panel h3 { margin: 16px 0 6px; font-size: 12px; opacity: .8; font-weight: 700; }
  .sec { display: none; } .sec.on { display: block; }
  .row { display: flex; flex-wrap: wrap; gap: 5px; align-items: center; }
  .chip { background: rgba(255,255,255,.08); border: 2px solid var(--bd); padding: 4px 9px; font-size: 12px; font-weight: 700; }
  .chip.on { background: var(--ac); color: #3a1f4a; border-color: #fff; }
  .chip.dis { opacity: .35; pointer-events: none; }
  .sw { width: 22px; height: 22px; border: 2px solid rgba(255,255,255,.4); padding: 0; }
  .sw.on { border-color: #fff; outline: 2px solid var(--ac); }
  input[type=color] { width: 28px; height: 26px; padding: 0; border: 2px solid var(--bd); background: none; }
  input[type=text], select { background: rgba(0,0,0,.3); color: #fff; border: 2px solid var(--bd); padding: 5px 8px; font: inherit; font-size: 13px; width: 100%; box-sizing: border-box; }
  .btn { background: var(--ac); color: #3a1f4a; border: 2px solid #fff; padding: 7px 14px; font-weight: 800; font-size: 13px; }
  .btn.sub { background: rgba(255,255,255,.1); color: #fff; border-color: var(--bd); }
  .btn.danger { background: #c4402e; color: #fff; }
  #previews { display: flex; gap: 8px; justify-content: center; background: rgba(0,0,0,.28); border: 2px solid var(--bd); padding: 10px 6px 6px; margin-bottom: 10px; }
  #previews div { text-align: center; font-size: 10px; opacity: .85; } #previews canvas { image-rendering: pixelated; display: block; margin: 0 auto 2px; }
  .card { display: flex; align-items: center; gap: 10px; background: rgba(255,255,255,.07); border: 2px solid var(--bd); padding: 6px 8px; margin-bottom: 7px; cursor: pointer; }
  .card.sel { border-color: var(--ac); background: rgba(255,170,100,.15); }
  .card canvas { image-rendering: pixelated; width: 36px; height: 44px; } .card .t { flex: 1; font-size: 13px; font-weight: 700; } .card .t small { display: block; font-weight: 400; font-size: 11px; opacity: .8; }
  .card button { padding: 3px 7px; font-size: 11px; background: rgba(255,255,255,.1); border: 2px solid var(--bd); }
  label.tg { display: flex; justify-content: space-between; align-items: center; font-size: 13px; padding: 6px 0; } label.tg input { width: 18px; height: 18px; }
  input[type=range] { width: 100%; }
  #toast { position: absolute; left: 50%; bottom: 24px; transform: translateX(-50%); background: var(--bg); border: 2px solid var(--bd); padding: 8px 16px; font-size: 13px; opacity: 0; transition: opacity .25s; z-index: 6; pointer-events: none; }
  #bubbles { position: absolute; inset: 0; pointer-events: none; overflow: hidden; }
  .bubble { position: absolute; transform: translate(-50%, -100%); background: #fff; color: #2b1d33; font-size: 12px; font-weight: 700; padding: 3px 7px; border: 2px solid #2b1d33; box-shadow: 0 2px 0 rgba(0,0,0,.25); white-space: nowrap; opacity: 0; transition: opacity .25s; }
  .bubble::after { content: ""; position: absolute; left: 50%; bottom: -7px; margin-left: -4px; border: 4px solid transparent; border-top-color: #2b1d33; }
  .bubble.show { opacity: 1; } .pw.nobubble .bubble { display: none; }
  .name { position: absolute; transform: translate(-50%, 0); font-size: 11px; font-weight: 700; text-shadow: 0 1px 0 #2b1d33, 0 0 4px #2b1d33; opacity: 0; transition: opacity .2s; white-space: nowrap; }
  .name.show { opacity: .95; }
  #roomtags .rt { position: absolute; transform: translate(-50%, -50%); font-size: 12px; font-weight: 800; letter-spacing: .12em; padding: 2px 8px; background: rgba(28,16,48,.55); border: 2px solid rgba(255,255,255,.3); opacity: .85; pointer-events: none; }
  .pw.noroomtag #roomtags { display: none; }
`,G0=`<div class="pw"><canvas id="gl" class="gl"></canvas>
<div id="bubbles"></div><div id="roomtags" style="position:absolute;inset:0;pointer-events:none"></div>

<div id="rail">
  <div class="logo">PIXEL<br>HOUSE</div>
  <button data-p="cast">👥<span>친구들</span></button>
  <button data-p="create">✨<span>캐릭터</span></button>
  <button data-p="scene">🎬<span>장면</span></button>
  <button data-p="settings">⚙️<span>설정</span></button>
</div>

<div id="panel">
  <div class="sec" id="s-cast">
    <h2>👥 친구들</h2>
    <div id="castList"></div>
    <button class="btn" id="newChar" style="width:100%;margin-top:6px">＋ 새 캐릭터 만들기</button>
  </div>

  <div class="sec" id="s-create">
    <h2 id="createTitle">✨ 캐릭터 만들기</h2>
    <div id="previews"><div><canvas id="pv0"></canvas>앞</div><div><canvas id="pv1"></canvas>걷기</div><div><canvas id="pv2"></canvas>뒤</div></div>
    <input type="text" id="cName" maxlength="8" placeholder="이름 (최대 8자)">
    <h3>헤어스타일</h3><div class="row" id="o-hairStyle"></div>
    <h3>머리 색</h3><div class="row" id="o-hair"></div>
    <h3>눈 색</h3><div class="row" id="o-eye"></div>
    <h3>피부색</h3><div class="row" id="o-skin"></div>
    <h3>상의</h3><div class="row" id="o-top"></div>
    <h3>상의 색</h3><div class="row" id="o-topC"></div>
    <h3>하의 <small id="dressNote" style="opacity:.7"></small></h3><div class="row" id="o-bottom"></div>
    <h3>하의 색</h3><div class="row" id="o-botC"></div>
    <h3>모자</h3><div class="row" id="o-hat"></div>
    <h3>모자 색</h3><div class="row" id="o-hatC"></div>
    <div class="row" style="margin-top:18px">
      <button class="btn" id="cSave">집에 추가하기</button>
      <button class="btn sub" id="cRand">🎲 랜덤</button>
      <button class="btn sub" id="cCancel">취소</button>
    </div>
  </div>

  <div class="sec" id="s-scene">
    <h2>🎬 장면 테스트</h2>
    <h3>누구에게?</h3><select id="sceneWho"></select>
    <h3>이동</h3><div class="row" id="sceneGo"></div>
    <h3>행동</h3><div class="row" id="sceneAct"></div>
    <h3>이야기 읽기 테스트</h3>
    <textarea id="storyIn" rows="4" placeholder="예) 모리는 소파에 앉아 TV를 봤다. 별이는 졸려서 침대로 갔다." style="width:100%;box-sizing:border-box;background:rgba(0,0,0,.3);color:#fff;border:2px solid var(--bd);padding:6px 8px;font:inherit;font-size:13px;resize:vertical"></textarea>
    <div class="row" style="margin-top:6px"><button class="btn" id="storyGo">읽고 반응하기</button><button class="btn sub" id="storyEx">예시 넣기</button></div>
    <div id="storyOut" style="margin-top:8px;font-size:12px;line-height:1.55"></div>
    <p style="font-size:11px;opacity:.7;margin-top:16px;line-height:1.5">나중에 마리나라 확장에서 <code>postMessage({type:'scene', who:'모리', action:'sleep'})</code> 로 같은 명령을 보낼 수 있게 해 둔 자리예요.</p>
  </div>

  <div class="sec" id="s-settings">
    <h2>⚙️ 설정</h2>
    <h3>시간대</h3><div class="row" id="setTod"></div>
    <h3>표시</h3>
    <label class="tg">말풍선<input type="checkbox" id="setBubble" checked></label>
    <label class="tg">방 이름표<input type="checkbox" id="setRoomTag" checked></label>
    <label class="tg">이름표 항상 보기<input type="checkbox" id="setNames"></label>
    <label class="tg">빛 번짐(블룸)<input type="checkbox" id="setBloom" checked></label>
    <h3>움직임</h3>
    <label class="tg">스스로 움직이기<input type="checkbox" id="setAuto" checked></label>
    <label class="tg">카메라 천천히 회전<input type="checkbox" id="setRotate"></label>
    <div style="font-size:12px;margin-top:8px">걷는 속도 <span id="spdVal">1.0</span>×</div><input type="range" id="setSpeed" min="0.5" max="2.5" step="0.1" value="1">
    <h3>데이터</h3>
    <div class="row"><button class="btn sub" id="resetCast">기본 캐릭터로 되돌리기</button></div>
  </div>
</div>
<div id="toast"></div></div>`;function cu(i,t={}){let e=i.shadowRoot||i.attachShadow({mode:"open"});e.innerHTML=`<style>${V0}</style>${G0}`;let n=e.querySelector(".pw"),s=h=>e.querySelector(h),r=h=>e.querySelectorAll(h),o=()=>n.clientWidth||800,a=()=>n.clientHeight||450,l=!0,c=.5;function u(h){return()=>{h|=0,h=h+1831565813|0;let g=Math.imul(h^h>>>15,1|h);return g=g+Math.imul(g^g>>>7,61|g)^g,((g^g>>>14)>>>0)/4294967296}}let f=u(21),p=(h,g=Math.random)=>h[Math.floor(g()*h.length)];function x(h,g,_=0){let T=Math.imul(h|0,374761393)^Math.imul(g|0,668265263)^Math.imul((_|0)+1,2147483647);return T=Math.imul(T^T>>>13,1274126177),((T^T>>>16)>>>0)/4294967296}function y(h,g,_=0){let T=Math.floor(h),v=Math.floor(g),B=h-T,it=g-v,et=B*B*(3-2*B),St=it*it*(3-2*it),dt=x(T,v,_),D=x(T+1,v,_),zt=x(T,v+1,_),le=x(T+1,v+1,_);return dt+(D-dt)*et+(zt-dt)*St+(dt-D-zt+le)*et*St}let b=new qt,m=new qt;function d(h,g,_){return b.setHex(h),m.setHex(g),b.lerp(m,_).getHex()}let C=h=>new qt(h),w=(h,g,_)=>new F(h,g,_),U=h=>typeof h=="number"?"#"+h.toString(16).padStart(6,"0"):h,z=(h,g)=>{let _=Math.min(255,(h>>16&255)*g)|0,T=Math.min(255,(h>>8&255)*g)|0,v=Math.min(255,(h&255)*g)|0;return"#"+(1<<24|_<<16|T<<8|v).toString(16).slice(1)},N={get(h,g){try{let _=localStorage.getItem(h);return _?JSON.parse(_):g}catch{return g}},set(h,g){try{localStorage.setItem(h,JSON.stringify(g))}catch{}}};class L{constructor(g=c){this.size=g,this.d=[]}add(g,_,T,v,B=1){this.d.push([g,_,T,v,B])}box(g,_,T,v,B,it,et){for(let St=g;St<=v;St++)for(let dt=_;dt<=B;dt++)for(let D=T;D<=it;D++)this.add(St,dt,D,typeof et=="function"?et(St,dt,D):et)}build(g,{shadow:_=!0,jit:T=.04}={}){let v=this.d.length,B=this.size,it=new Ta(new Yi(B,B,B),g,Math.max(v,1)),et=new ve,St=new qt;for(let dt=0;dt<v;dt++){let[D,zt,le,de,ie]=this.d[dt];et.makeScale(ie,ie,ie),et.setPosition(D*B,le*B,zt*B),it.setMatrixAt(dt,et),St.setHex(de),T&&St.offsetHSL(0,0,(x(D*7+3,zt*13+1,Math.floor(le*4))-.5)*T*2),it.setColorAt(dt,St)}return it.count=v,it.castShadow=it.receiveShadow=_,it.frustumCulled=!1,it}}let j=new pr({canvas:s("#gl"),antialias:!1,preserveDrawingBuffer:!0});j.setPixelRatio(Math.min(devicePixelRatio,2)),j.setSize(o(),a()),j.outputColorSpace=Re,j.toneMapping=Mr,j.shadowMap.enabled=!0,j.shadowMap.type=Ml;let S=new wa;S.fog=new Sa(9263784,.008);let R=new en(36,o()/a(),.5,1800);R.position.set(0,19,31);let V=new za(R,j.domElement);V.target.set(0,1.5,.5),V.enableDamping=!0,V.dampingFactor=.07,V.enablePan=!1,V.minDistance=9,V.maxDistance=58,V.minPolarAngle=.35,V.maxPolarAngle=1.3,V.minAzimuthAngle=-.85,V.maxAzimuthAngle=.85,V.autoRotateSpeed=.5;let tt={dusk:{top:C(3811960),mid:C(13593234),hor:C(16296044),fog:C(9263784),keyCol:C(16756856),keyInt:2.6,hSky:C(11571416),hGnd:C(5914728),hInt:.8,den:.0085,stars:.3,glow:1,win:C(16756848),lamp:.75,bloom:.45,expo:1.15,tint:C(16772834),sun:w(-.9,.16,-.4),disc:C(16763024),discK:1,key:w(-.3,.8,.5)},night:{top:C(461350),mid:C(1777510),hor:C(4012680),fog:C(1907538),keyCol:C(9086719),keyInt:.7,hSky:C(4870816),hGnd:C(2366528),hInt:.85,den:.0105,stars:1,glow:1.9,win:C(1976934),lamp:1.5,bloom:.75,expo:1.3,tint:C(12633328),sun:w(.55,.45,-.7),disc:C(12570879),discK:.65,key:w(.35,.8,.5)},day:{top:C(4032224),mid:C(9227762),hor:C(15267071),fog:C(11852016),keyCol:C(16773336),keyInt:3.2,hSky:C(13626111),hGnd:C(9079400),hInt:1.3,den:.006,stars:0,glow:.5,win:C(14676735),lamp:.12,bloom:.15,expo:1.1,tint:C(16777215),sun:w(-.5,.65,-.5),disc:C(16774344),discK:1,key:w(-.3,.9,.5)}},ft=h=>{let g={};for(let _ in h)g[_]=h[_].clone?h[_].clone():h[_];return g},I=ft(tt.dusk),k=Object.assign({mode:"dusk",bubble:!0,roomtag:!0,names:!1,bloom:!0,auto:!0,rotate:!1,speed:1},N.get("house.settings.v1",{})),G=k.mode;Object.assign(I,ft(tt[G]));function K(h,g){let _=tt[G],T=g?1:1-Math.exp(-h*2.2);for(let v in I){let B=I[v],it=_[v];typeof B=="number"?I[v]=B+(it-B)*T:B.lerp(it,T)}}let Q=new Ne({side:nn,depthWrite:!1,fog:!1,uniforms:{top:{value:I.top},mid:{value:I.mid},hor:{value:I.hor},sunDir:{value:I.sun},disc:{value:I.disc},discK:{value:1}},vertexShader:"varying vec3 vD; void main(){ vD = position; gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0); }",fragmentShader:`uniform vec3 top, mid, hor, sunDir, disc; uniform float discK; varying vec3 vD;
    void main(){ vec3 d = normalize(vD); float h = d.y;
      vec3 c = mix(hor, mid, smoothstep(-0.02, 0.2, h)); c = mix(c, top, smoothstep(0.12, 0.7, h));
      float s = max(dot(d, normalize(sunDir)), 0.0);
      c += disc * (pow(s, 14.0) * 0.5 + pow(s, 160.0) * 0.5) * discK;
      c += disc * smoothstep(0.9988, 0.9992, s) * 2.5 * discK;
      gl_FragColor = vec4(c, 1.0); }`});S.add(new ke(new Aa(1e3,32,16),Q));let $=new hn;{let g=new Float32Array(4500);for(let _=0;_<1500;_++){let T=f(),v=f()*.97+.03,B=T*Math.PI*2,it=Math.sqrt(1-v*v);g.set([Math.cos(B)*it*900,v*900,Math.sin(B)*it*900],_*3)}$.setAttribute("position",new sn(g,3))}let nt=new Ns({color:14673663,size:2.2,sizeAttenuation:!1,transparent:!0,opacity:.3,depthWrite:!1,fog:!1});S.add(new mr($,nt));let ct=(()=>{let h=document.createElement("canvas");h.width=h.height=256;let g=h.getContext("2d");g.fillStyle="#e6e6e6",g.fillRect(0,0,256,256);let _=u(5);for(let v=0;v<260;v++){let B=_()*256,it=_()*256,et=14+_()*40,St=_()<.5?255:196;for(let dt of[-256,0,256])for(let D of[-256,0,256]){let zt=g.createRadialGradient(B+dt,it+D,0,B+dt,it+D,et);zt.addColorStop(0,`rgba(${St},${St},${St},.22)`),zt.addColorStop(1,`rgba(${St},${St},${St},0)`),g.fillStyle=zt,g.fillRect(B+dt-et,it+D-et,et*2,et*2)}}let T=new Os(h);return T.wrapS=T.wrapT=lr,T.repeat.set(22,22),T.colorSpace=Re,T})(),bt=new gn({map:ct,color:10121400}),J=new ke(new gr(1300,48),bt);J.rotation.x=-Math.PI/2,J.position.y=-26,S.add(J);let ot=[];{let h=new xr({roughness:1,metalness:0});for(let g=0;g<30;g++){let _=f()*Math.PI*2,T=30+f()*120,v=5+f()*7,B=new L(1.5),it=v*(1+f()*.6),et=v*(.8+f()*.5);for(let dt=0;dt<5;dt++){let D=1-dt*.19,zt=(f()-.5)*2,le=(f()-.5)*2;for(let de=-Math.ceil(it);de<=Math.ceil(it);de++)for(let ie=-Math.ceil(et);ie<=Math.ceil(et);ie++)Math.hypot((de-zt)/(it*D),(ie-le)/(et*D))+y(de*.4+g,ie*.4,2)*.25>1||B.add(de,ie,dt,d(12166116,15853311,dt/4*.8+x(de,ie,g)*.2))}let St=B.build(h,{shadow:!1,jit:.02});St.position.set(Math.cos(_)*T,-25+f()*9,Math.sin(_)*T),S.add(St),ot.push({m:St,sp:.1+f()*.25})}}let vt=new Ia(16756856,2.6);vt.castShadow=!0,vt.shadow.mapSize.set(2048,2048),Object.assign(vt.shadow.camera,{left:-20,right:20,top:14,bottom:-14,near:1,far:100}),vt.shadow.normalBias=.03,vt.shadow.bias=-4e-4,S.add(vt,vt.target);let Lt=new Ra(11571416,5914728,1.15);S.add(Lt);let Nt=[[-5,3.6,-4],[7,3.6,-4.5],[-6,3.6,4],[7,3.6,4]].map(h=>{let g=new La(16763024,8,14,1.7);return g.position.set(...h),S.add(g),g}),Ct=-24,It=23,Tt=-16,kt=15,W=9,Pe=3,Dt=4,Gt=0,Rt=(h,g)=>g<Gt?h<Dt?"kitchen":"bedroom":h<Dt?"living":"bath",me={kitchen:"주방",bedroom:"안방",living:"거실",bath:"화장실"},$t={kitchen:15916196,bedroom:14468332,living:15257524,bath:12904178},A=9067062,M=new xr({roughness:.9,metalness:0}),X=new gn({color:16777215}),ut=new gn({color:16777215}),lt=new gn({color:16777215}),st=(h,g)=>h*1e3+g,Et=new Set,Mt=new Set,ht=[],Ot=new _i;S.add(Ot);let Yt=new L,at=new L,se=new L,P=(h,g,_)=>h>=g&&h<=_;function rt(h,g){for(let v of _e)if(v.type==="rug"){let B={i0:v.i,i1:v.i+v.p.w-1,j0:v.j,j1:v.j+v.p.d-1};if(P(h,B.i0,B.i1)&&P(g,B.j0,B.j1))return h===B.i0||h===B.i1||g===B.j0||g===B.j1?v.p.b:(h+g)%4===0?d(v.p.a,v.p.b,.2):v.p.a}let _=Rt(h,g);if(_==="kitchen")return h+g&1?15920350:14734522;if(_==="bath")return h+g&1?16055295:12574958;let T=g&1?13146720:12291156;return x(h>>3,g,4)<.18?d(T,15253640,.5):T}let mt=null;function pt(){let h=new L;for(let g=Ct-1;g<=It+1;g++)for(let _=Tt-1;_<=kt+1;_++)h.add(g,_,0,rt(g,_));for(let g=1;g<=7;g++){let _=[0,0,1,3,6,9,12,15][g],T=[0,9067062,6965854,5786224,4734050,3812946,3023940,2366520][g];for(let v=Ct-2+_;v<=It+2-_;v++)for(let B=Tt-2+_;B<=kt+2-_*.7;B++)h.add(v,Math.round(B),-g,x(v,B,g)<.15?d(T,16777215,.08):T)}mt&&(Ot.remove(mt),mt.geometry.dispose(),mt.dispose()),mt=h.build(M,{jit:.035}),Ot.add(mt)}let Ut=[{ax:"j",pos:Tt-1,a0:-10,a1:-5,k0:5,k1:8},{ax:"j",pos:Tt-1,a0:14,a1:19,k0:4,k1:8},{ax:"i",pos:Ct-1,a0:2,a1:4,k0:4,k1:8},{ax:"i",pos:Ct-1,a0:12,a1:14,k0:4,k1:8},{ax:"i",pos:It+1,a0:-13,a1:-10,k0:4,k1:7},{ax:"i",pos:It+1,a0:8,a1:10,k0:5,k1:7}];function Qt(h,g,_){for(let T of Ut){let v=T.ax==="j"?h:g;if((T.ax==="j"?g:h)!==T.pos||!P(v,T.a0,T.a1)||!P(_,T.k0,T.k1))continue;let it=v===T.a0||v===T.a1||_===T.k0||_===T.k1,et=v===Math.floor((T.a0+T.a1)/2)||_===Math.floor((T.k0+T.k1)/2);return it||et&&T.a1-T.a0>2?"frame":"glass"}return null}function ee(h,g,_,T){let v=Qt(h,g,_);if(v==="glass"){se.add(h,g,_,16777215);return}if(v==="frame"){Yt.add(h,g,_,16051420);return}let B=$t[T];_===1?B=d(B,A,.55):_===W?B=16051420:T==="bath"&&_<=3?B=h+g+_&1?16055295:14216950:(_+(h|0)+g)%5===0&&x(h,g,_)<.2&&(B=d(B,16777215,.12)),Yt.add(h,g,_,B)}for(let h=Ct-1;h<=It+1;h++)for(let g=1;g<=W;g++)ee(h,Tt-1,g,h<Dt?"kitchen":"bedroom");for(let h=Tt;h<=kt;h++)for(let g=1;g<=W;g++)ee(Ct-1,h,g,h<Gt?"kitchen":"living"),ee(It+1,h,g,h<Gt?"bedroom":"bath");for(let h=Tt-1;h<=kt;h++)Et.add(st(Ct-1,h)),Et.add(st(It+1,h));for(let h=Ct-1;h<=It+1;h++)Et.add(st(h,Tt-1));let Kt=[[-9,-6],[6,9]],_t=[[-18,-6],[12,15]],O=h=>Kt.some(([g,_])=>P(h,g,_)),gt=h=>_t.some(([g,_])=>P(h,g,_)),xt=h=>Kt.some(([g,_])=>h===g-1||h===_+1),Ht=h=>_t.some(([g,_])=>h===g-1||h===_+1);function Ft(h,g,_){let T=_?6:Pe;for(let v=1;v<=T;v++)Yt.add(h,g,v,_?v===6?12861486:A:v===Pe?14207152:v===1?12098168:15853784)}for(let h=Tt;h<=kt;h++)O(h)||(Ft(Dt,h,xt(h)),Et.add(st(Dt,h)));for(let h=Ct;h<=It;h++)h!==Dt&&!gt(h)&&(Ft(h,Gt,Ht(h)),Et.add(st(h,Gt)));for(let h=Ct-1;h<=It+1;h++){let g=P(h,-9,-6);for(let _=1;_<=(g&&(h===-9||h===-6)?6:1);_++)Yt.add(h,kt+1,_,g&&_===6?12861486:A);P(h,-8,-7)||Et.add(st(h,kt+1))}for(let h=-9;h<=-6;h++)Yt.add(h,kt+1,6,12861486);at.add(-10,kt+1,4,16762976,.8),at.add(-5,kt+1,4,16762976,.8);let ce=[14172206,4890840,16046170,6995818,10124008,15769792,15764010],ne={counter:{name:"조리대",size:h=>[h.w||4,2],build({P:h,w:g,p:_}){for(let T=0;T<g;T++)for(let v=0;v<2;v++){let B=T%3===0&&v===1?9724470:11829836;h(T,v,1,B),h(T,v,2,B),h(T,v,3,15854560)}for(let T of _.items||[])h(T.x,T.z,T.k,T.col,T.sc)}},sink:{name:"싱크대",size:()=>[3,2],build({P:h}){for(let g=0;g<3;g++)for(let _=0;_<2;_++)h(g,_,1,11829836),h(g,_,2,11829836),h(g,_,3,8046832);h(1,0,4,9079446,.35),h(1,0,4.45,9079446,.35)},slots:()=>[{kind:"cook",walk:[1,2],at:[1,2],face:[0,-1],pose:"stand",txt:"설거지 중",say:["쓱싹쓱싹","♪"]}]},stove:{name:"가스레인지",size:()=>[3,2],build({P:h,G:g}){for(let _=0;_<3;_++)for(let T=0;T<2;T++)h(_,T,1,6974070),h(_,T,2,6974070),h(_,T,3,2763312);g(1,1,3.75,16747056,.5),h(2,1,4,10132136,.9),h(2,1,4.55,8026760,.5)},slots:()=>[{kind:"cook",walk:[1,2],at:[1,2],face:[0,-1],pose:"stand",txt:"요리 중",say:["보글보글","맛있겠다","간 맞추는 중"],steam:!0}],emit:()=>[{type:"steam",x:2,z:1,k:5}]},upper_cabinet:{name:"벽 찬장",size:h=>[h.w||4,1],noBlock:!0,build({P:h,w:g}){for(let _=0;_<g;_++)for(let T=6;T<=8;T++)h(_,0,T,T===6&&_%3===0?6963752:9067066);for(let _=1;_<g;_+=3)h(_,1,7,15255672,.3)}},fridge:{name:"냉장고",size:()=>[2,2],build({P:h,box:g}){g(0,0,1,1,1,7,(_,T,v)=>v===5?12107976:15265522),h(1,2,3,9079446,.4),h(1,2,6,9079446,.4)}},table:{name:"식탁",size:h=>[h.w||6,h.d||4],build({P:h,w:g,d:_}){for(let T=0;T<g;T++)for(let v=0;v<_;v++)h(T,v,2,13145948);for(let[T,v]of[[0,0],[g-1,0],[0,_-1],[g-1,_-1]])h(T,v,1,9067062);h(3,1,3,16053496,.6),h(3,1,3.45,15764010,.4),h(2,2,3.3,14172206,.35),h(4,2,3.3,16046170,.35)}},chair:{name:"의자",size:()=>[1,2],build({P:h,p:g}){h(0,0,1,12077624),h(0,0,2,12077624),(g.backH||3)>=3&&h(0,0,3,12077624),h(0,1,1,14180426)},slots:h=>[{kind:"eat",walk:[h.p.side||-1,1],at:[0,1],face:[0,1],pose:"sit",y:.75,txt:"식사 중",say:["냠냠","맛있다!","잘 먹겠습니다","한 입 더!"]}]},bed:{name:"침대",size:()=>[8,6],build({P:h,box:g}){g(0,0,1,0,5,2,9067062),g(7,0,1,7,5,5,9067062);for(let _=1;_<=6;_++)for(let T=0;T<6;T++)h(_,T,1,9067062),h(_,T,2,_>=5?16315628:(_+T)%2?15239848:15769784);h(6,1,2.75,16777215,.6),h(6,4,2.75,16777215,.6),h(2,4,2.9,12092492,.6),h(2,4,3.3,12092492,.4)},slots:()=>[{kind:"sleep",walk:[3,6],at:[4,3],face:[1,0],pose:"lie",y:1.25,txt:"자는 중",say:["zzz","zZ…","쿨쿨"]}]},nightstand:{name:"협탁",size:()=>[2,2],build({P:h,G:g,box:_}){_(0,0,1,1,1,2,10512444),h(1,0,3,16051420,.5),g(1,0,3.75,16767120,.7)}},wardrobe:{name:"옷장",size:()=>[4,2],build({P:h,box:g}){g(0,0,1,3,1,8,(_,T)=>_===1&&T===1?6963752:9067066),h(1,2,4,15255672,.3),h(2,2,4,15255672,.3)},slots:()=>[{kind:"dress",walk:[1,2],at:[1,2],face:[0,-1],pose:"stand",txt:"옷 고르는 중",say:["뭐 입지?","이거 어때?"]}]},dresser:{name:"화장대",size:()=>[3,2],build({P:h,box:g}){g(0,0,1,2,1,3,11829836);for(let _=0;_<3;_++)for(let T=5;T<=7;T++)h(_,0,T,_===0||_===2||T===5||T===7?9067062:13167864)}},curtain:{name:"커튼",size:()=>[1,1],noBlock:!0,build({P:h}){for(let g=4;g<=8;g++)h(0,0,g,11565272)}},plant:{name:"화분",size:()=>[3,3],build({P:h,p:g}){h(1,1,1,12869678),h(1,1,2,12869678,.9);for(let _=-1;_<=1;_++)for(let T=-1;T<=1;T++)for(let v=0;v<=2;v++)Math.abs(_)+Math.abs(T)+(v?0:1)<=2&&x(_+(g.seed||0),T,v)<.85&&h(1+_,1+T,3+v,x(_+9,T,v)<.5?5216826:7321162)}},bathtub:{name:"욕조",size:()=>[8,5],build({P:h}){for(let g=0;g<8;g++)for(let _=0;_<5;_++){let T=g===0||_===0||_===4||g===7;h(g,_,1,T?16053496:(g+_)%3?8048880:10150136),T&&h(g,_,2,16053496)}for(let[g,_]of[[2.2,1],[4.2,3],[6.2,1],[3.2,3],[5.2,2]])h(g,_,1.7,16777215,.5);h(1,1,1.75,16767050,.45),h(0,2,3,10132136,.4),h(0,2,3.6,10132136,.4),h(1,2,3.6,10132136,.4)},slots:()=>[{kind:"bath",walk:[3,5],at:[3,2],face:[0,1],pose:"bath",y:.95,txt:"목욕 중",say:["으아~ 시원해","♪","거품 거품"]}],emit:()=>[{type:"bubbles",x:4,z:2,k:2}]},toilet:{name:"변기",size:()=>[2,3],build({box:h}){h(0,0,1,1,0,4,16053496),h(0,1,1,1,2,2,16053496),h(0,2,3,1,2,3,15263984)}},vanity:{name:"세면대",size:()=>[4,2],build({P:h,box:g}){g(0,0,1,3,1,3,13152400),g(1,0,3,2,1,3,13627647);for(let _=0;_<4;_++)for(let T=5;T<=8;T++)h(_,-1,T,_===0||_===3||T===5||T===8?9067062:13627647)},slots:()=>[{kind:"wash",walk:[1,2],at:[1,2],face:[0,-1],pose:"stand",txt:"세수 중",say:["쓱쓱","양치 중…"]}]},washer:{name:"세탁기",size:()=>[3,3],build({box:h}){h(0,0,1,2,2,4,(g,_,T)=>g===1&&_===2&&T>=2&&T<=3?6990040:16053496)},slots:()=>[{kind:"wash",walk:[1,-1],at:[1,-1],face:[0,1],pose:"stand",txt:"빨래 중",say:["뽀송뽀송","돌아간다~"]}]},basket:{name:"빨래바구니",size:()=>[2,2],build({P:h,box:g}){g(0,0,1,1,1,2,11829836),h(0,0,3,15226698,.5),h(1,0,3,4890840,.5)}},tv_unit:{name:"TV장",size:h=>[h.w||7,1],build({P:h,T:g,w:_}){for(let T=0;T<_;T++)h(T,0,1,9067066),h(T,0,2,9067066);for(let T=1;T<_-1;T++)for(let v=3;v<=6;v++)T>=2&&T<=_-3&&v>=4&&v<=5?g(T,0,v,16777215):h(T,0,v,2236970);for(let T=2;T<=_-3;T++)for(let v=7;v<=8;v++)h(T,0,v,(T+v)%2?15769664:T===3?6994136:14180426)}},sofa:{name:"소파",size:()=>[11,4],build({P:h}){for(let g=0;g<4;g++)for(let _ of[0,10])for(let T=1;T<=3;T++)h(_,g,T,12077624);for(let g=1;g<=9;g++){for(let _=1;_<=3;_++)h(g,_,1,14180426),h(g,_,2,g%3===1&&_>=2?12865596:15235682);for(let _=1;_<=3;_++)h(g,0,_,_===3?12865596:14180426)}},slots:()=>[[3,["재밌다","ㅋㅋㅋ","다음 화!"]],[5,["어, 저거다","헉"]],[7,["과자 먹고 싶다","♪"]]].map(([h,g])=>({kind:"tv",walk:[h,4],at:[h,2],face:[0,1],pose:"sit",y:1.25,txt:"TV 보는 중",say:g}))},coffee_table:{name:"테이블",size:()=>[3,5],build({P:h}){for(let g=0;g<3;g++)for(let _=0;_<5;_++)h(g,_,2,10514496);for(let[g,_]of[[0,0],[2,0],[0,4],[2,4]])h(g,_,1,8014380);h(1,2,3,14172206,.55),h(0,1,3,16051420,.4)}},floor_lamp:{name:"스탠드",size:()=>[1,1],build({P:h,G:g}){for(let _=1;_<=6;_++)h(0,0,_,4864560);g(0,0,7,16767120,1.1)}},bookshelf:{name:"책장",size:()=>[4,2],build({box:h}){h(0,0,1,3,1,7,(g,_,T)=>T%2===1||_===0||x(g,T,6)<.12?9067066:ce[Math.floor(x(g,T,7)*ce.length)])},slots:()=>[{kind:"read",walk:[1,2],at:[1,2],face:[0,-1],pose:"stand",txt:"책 고르는 중",say:["이 책 재밌나?","흠…"]}]},armchair:{name:"안락의자",size:()=>[3,4],build({box:h}){h(0,0,1,2,0,2,3836096),h(0,1,1,2,3,1,4890840),h(0,1,2,2,3,2,5945576)},slots:()=>[{kind:"read",walk:[1,4],at:[1,2],face:[0,1],pose:"sit",y:1.25,txt:"책 읽는 중",say:["…","한 장만 더"]}]},rug:{name:"러그",size:h=>[h.w,h.d],noBlock:!0,floor:!0}},Oe=Object.keys(ne),_e=[{type:"counter",i:-23,j:-16,p:{w:2}},{type:"sink",i:-21,j:-16},{type:"counter",i:-18,j:-16,p:{w:2,items:[{x:0,z:1,k:3.7,col:16051420,sc:.35}]}},{type:"stove",i:-16,j:-16},{type:"counter",i:-13,j:-16,p:{w:10,items:[{x:7,z:1,k:4,col:14172206,sc:.8},{x:4,z:1,k:3.75,col:15764010,sc:.45},{x:5,z:1,k:3.75,col:14172206,sc:.4}]}},{type:"upper_cabinet",i:-23,j:-16,p:{w:12}},{type:"fridge",i:-24,j:-13,rot:3},{type:"table",i:-12,j:-9,p:{w:6,d:4}},{type:"chair",i:-11,j:-11,rot:0,p:{backH:3,side:-1}},{type:"chair",i:-8,j:-11,rot:0,p:{backH:3,side:1}},{type:"chair",i:-11,j:-5,rot:2,p:{backH:2,side:1}},{type:"chair",i:-8,j:-5,rot:2,p:{backH:2,side:-1}},{type:"plant",i:-3,j:-15},{type:"rug",i:-13,j:-11,p:{w:8,d:8,a:15235162,b:12865596}},{type:"bed",i:16,j:-12},{type:"nightstand",i:22,j:-14},{type:"nightstand",i:22,j:-6},{type:"wardrobe",i:5,j:-16},{type:"dresser",i:10,j:-16},{type:"curtain",i:13,j:-16},{type:"curtain",i:20,j:-16},{type:"plant",i:5,j:-4,p:{seed:3}},{type:"rug",i:9,j:-11,p:{w:8,d:8,a:15771840,b:14188700}},{type:"bathtub",i:16,j:1},{type:"toilet",i:21,j:9,rot:1},{type:"vanity",i:21,j:12,rot:1},{type:"washer",i:6,j:13},{type:"basket",i:11,j:14},{type:"rug",i:17,j:7,p:{w:5,d:3,a:9097448,b:5941448}},{type:"tv_unit",i:-24,j:5,rot:3,p:{w:7}},{type:"sofa",i:-16,j:3,rot:1},{type:"coffee_table",i:-20,j:6},{type:"floor_lamp",i:-11,j:14},{type:"bookshelf",i:0,j:1},{type:"armchair",i:-6,j:11,rot:1},{type:"plant",i:1,j:12,p:{seed:7}},{type:"rug",i:-22,j:3,p:{w:12,d:11,a:3840676,b:2781050}},{type:"rug",i:-9,j:13,p:{w:4,d:3,a:8018492,b:5914408}}];_e.forEach((h,g)=>{h.id=h.id||h.type+"-"+g,h.rot=h.rot||0,h.p=h.p||{}});function pe(h,g,_){let T=(h.rot||0)&3;return{W:T&1?_:g,D:T&1?g:_,pt:(v,B)=>T===0?[v,B]:T===1?[_-1-B,v]:T===2?[g-1-v,_-1-B]:[B,g-1-v],fc:(v,B)=>T===0?[v,B]:T===1?[-B,v]:T===2?[-v,-B]:[B,-v]}}let Ge=h=>{let g=ne[h.type],[_,T]=g.size(h.p),v=pe(h,_,T);return{i0:h.i,j0:h.j,i1:h.i+v.W-1,j1:h.j+v.D-1}};function _n(){let h=[{kind:"out",walk:[-8,15],at:[-8,15],face:[0,1],pose:"stand",txt:"외출 중",say:["다녀올게!","금방 올게~"],arch:!0}];for(let g of Ut){let _=Math.floor((g.a0+g.a1)/2),T,v,B;if(g.ax==="j")T=_,v=g.pos+2,B=[0,-1];else{let it=g.pos===Ct-1;T=it?g.pos+2:g.pos-2,v=_,B=[it?-1:1,0]}!Mt.has(st(T,v))&&P(T,Ct,It)&&P(v,Tt,kt)&&h.push({kind:"view",walk:[T,v],at:[T,v],face:B,pose:"stand",txt:"창밖 구경 중",say:["노을 예쁘다","구름이다","저 구름 봐!","…"],arch:!0})}return h}let Ti=[],Ai=null,Yn=null,Ci=null;function Fn(){let h=new L,g=new L,_=new L;Mt=new Set(Et),Ti.length=0;let T=[];for(let v of _e){let B=ne[v.type];if(!B)continue;let[it,et]=B.size(v.p),St=pe(v,it,et),dt=(ae,Ce)=>{let[Be,Je]=St.pt(ae,Ce);return[v.i+Be,v.j+Je]},D=ae=>(Ce,Be,Je,he,ze=1)=>{let[At,Ae]=dt(Ce,Be);ae.add(At,Ae,Je,he,ze)},zt=D(h),le=D(g),de=D(_),Ie={P:zt,G:le,T:de,box:(ae,Ce,Be,Je,he,ze,At)=>{for(let Ae=ae;Ae<=Je;Ae++)for(let Vn=Ce;Vn<=he;Vn++)for(let un=Be;un<=ze;un++)zt(Ae,Vn,un,typeof At=="function"?At(Ae,Vn,un):At)},w:it,d:et,p:v.p};if(B.build&&B.build(Ie),!B.noBlock)for(let ae=0;ae<it;ae++)for(let Ce=0;Ce<et;Ce++)Mt.add(st(...dt(ae,Ce)));if(B.slots)for(let ae of B.slots(Ie)){let Ce=St.fc(...ae.face);T.push({...ae,walk:dt(...ae.walk),at:dt(...ae.at),face:Ce,owner:v.id})}if(B.emit)for(let ae of B.emit(Ie)){let[Ce,Be]=St.pt(ae.x,ae.z);Ti.push({type:ae.type,x:(v.i+Ce)*c,z:(v.j+Be)*c,y:ae.k*c,owner:v.id})}}if(qn=T.concat(_n()),Ai){Ot.remove(Ai,Yn,Ci);for(let v of[Ai,Yn,Ci])v.geometry.dispose(),v.dispose()}Ai=h.build(M,{jit:.04}),Yn=g.build(X,{shadow:!1,jit:0}),Ci=_.build(lt,{shadow:!1,jit:0}),Ot.add(Ai,Yn,Ci),pt(),Sn();for(let v of ht)if(ts(v),v.plan=null,v.path=null,v.state="idle",v.timer=.4,!ue(...Qi(v))){let[B,it]=Qi(v),et=Le.reduce((St,dt)=>Math.hypot(dt[0]-B,dt[1]-it)<Math.hypot(St[0]-B,St[1]-it)?dt:St,Le[0]);v.pos.set(et[0]*c,0,et[1]*c)}}function Vs(h,g){let _=Ge(h),T=ne[h.type];if(!(P(_.i0,Ct,It)&&P(_.i1,Ct,It)&&P(_.j0,Tt,kt)&&P(_.j1,Tt,kt)))return!1;if(T.noBlock)return!0;for(let v=_.i0;v<=_.i1;v++)for(let B=_.j0;B<=_.j1;B++)if(Et.has(st(v,B)))return!1;for(let v of _e){if(v.id===g||v===h||ne[v.type].noBlock)continue;let B=Ge(v);if(_.i0<=B.i1&&_.i1>=B.i0&&_.j0<=B.j1&&_.j1>=B.j0)return!1}return!0}function Sr(h,g,_,T){let v=_e.find(it=>it.id===h);if(!v)return!1;let B={...v,i:g,j:_,rot:T??v.rot};return Vs(B,h)?(Object.assign(v,{i:g,j:_,rot:B.rot}),Fn(),!0):!1}function Xa(h,g,_,T=0,v={}){let B={id:h+"-"+Math.random().toString(36).slice(2,6),type:h,i:g,j:_,rot:T,p:v};return!ne[h]||!Vs(B)?null:(_e.push(B),Fn(),B.id)}function Ya(h){let g=_e.findIndex(_=>_.id===h);return g<0?!1:(_e.splice(g,1),Fn(),!0)}Ot.add(Yt.build(M,{jit:.025})),Ot.add(se.build(ut,{shadow:!1,jit:0})),Ot.add(at.build(X,{shadow:!1,jit:0}));let ji={kitchen:[-13,-8],bedroom:[14,-9],living:[-10,8],bath:[14,8]},E={};for(let h in ji){let g=document.createElement("div");g.className="rt",g.textContent=me[h],s("#roomtags").appendChild(g),E[h]=g}let H=(()=>{let h=document.createElement("canvas");h.width=h.height=64;let g=h.getContext("2d"),_=g.createRadialGradient(32,32,0,32,32,32);_.addColorStop(0,"rgba(255,255,255,1)"),_.addColorStop(.35,"rgba(255,255,255,.55)"),_.addColorStop(1,"rgba(255,255,255,0)"),g.fillStyle=_,g.fillRect(0,0,64,64);let T=new Os(h);return T.colorSpace=Re,T})();function Y(h,g,_,T,v=1){let B=new hn;B.setAttribute("position",new sn(new Float32Array(h*3),3));let it=new mr(B,new Ns({map:H,size:g,color:_,transparent:!0,opacity:v,blending:T,depthWrite:!1}));return it.frustumCulled=!1,S.add(it),it}let Z=Y(18,.8,16777215,ii,.35),q=Array.from({length:18},()=>({t:Math.random()*3})),wt=Y(50,.14,16773320,Rs,.6),Bt=Array.from({length:50},()=>({x:(Math.random()-.5)*22,y:.8+Math.random()*3,z:(Math.random()-.5)*14,ph:Math.random()*6,sp:.2+Math.random()*.4})),Xt=Y(10,.3,16777215,ii,.7),Zt=Array.from({length:10},()=>({t:Math.random()*4})),Vt=30,Wt=64,Jt=new Uint8Array(Wt*Wt),ue=(h,g)=>h+Vt>=0&&g+Vt>=0&&h+Vt<Wt&&g+Vt<Wt&&Jt[(h+Vt)*Wt+g+Vt]===1,Le=[],Ee={kitchen:[],bedroom:[],living:[],bath:[]};function Sn(){Jt.fill(0),Le.length=0;for(let h in Ee)Ee[h].length=0;for(let h=Ct;h<=It;h++)for(let g=Tt;g<=kt;g++)Mt.has(st(h,g))||(Jt[(h+Vt)*Wt+g+Vt]=1);for(let h of[-8,-7])Jt[(h+Vt)*Wt+kt+1+Vt]=1;for(let h=Ct;h<=It;h++)for(let g=Tt;g<=kt;g++)ue(h,g)&&(Le.push([h,g]),Ee[Rt(h,g)].push([h,g]))}function xe(h,g,_,T){if(!ue(_,T)||!ue(h,g))return null;let v=(dt,D)=>(dt+Vt)*Wt+D+Vt,B=new Map([[v(h,g),0]]),it=new Map,et=new Set,St=[[0,h,g]];for(;St.length;){let dt=0;for(let de=1;de<St.length;de++)St[de][0]<St[dt][0]&&(dt=de);let[,D,zt]=St.splice(dt,1)[0],le=v(D,zt);if(!et.has(le)){if(et.add(le),D===_&&zt===T){let de=[[D,zt]],ie=le;for(;it.has(ie);){let Ie=it.get(ie);de.push([Ie[0],Ie[1]]),ie=v(Ie[0],Ie[1])}return de.reverse()}for(let de=-1;de<=1;de++)for(let ie=-1;ie<=1;ie++){if(!de&&!ie)continue;let Ie=D+de,ae=zt+ie;if(!ue(Ie,ae)||de&&ie&&(!ue(D+de,zt)||!ue(D,zt+ie)))continue;let Ce=B.get(le)+(de&&ie?1.414:1),Be=v(Ie,ae);if(B.has(Be)&&B.get(Be)<=Ce)continue;B.set(Be,Ce),it.set(Be,[D,zt]);let Je=Math.abs(_-Ie),he=Math.abs(T-ae);St.push([Ce+(Je+he)+(1.414-2)*Math.min(Je,he),Ie,ae])}}}return null}let jt=.25,qn=[];Fn();let ye=["cook","eat","sleep","view","dress","bath","wash","tv","read","out"],Bn={sleep:"잠자기",tv:"TV 보기",cook:"요리",eat:"식사",bath:"목욕",wash:"씻기·빨래",read:"독서",view:"창밖 구경",dress:"옷 고르기",out:"외출",chat:"대화",intimate:"19♥"},Gs={kitchen:"주방",living:"거실",bedroom:"안방",bath:"화장실"},Ri={sleep:["잠","자다","침대","꿈","sleep"],tv:["tv","티비","텔레비전","소파"],cook:["요리","부엌","주방","cook"],eat:["식사","밥","먹","eat"],bath:["목욕","욕조","bath"],wash:["씻","세수","양치","빨래"],read:["책","독서"],view:["창밖","창문"],out:["외출","나가","산책"],chat:["대화","수다","이야기"]},Ws=[["sleep",["잠","자러","자고","자는","잔다","잤","졸","침대에 누","눕","꿈나라","취침","낮잠","sleep"]],["tv",["tv","티비","텔레비전","시청","드라마","영화"]],["cook",["요리","조리","끓","볶","설거지","cook"]],["eat",["식사","밥","먹","식탁","간식","점심","저녁을","아침을"]],["bath",["목욕","샤워","욕조","bath"]],["wash",["세수","양치","씻","빨래","세탁"]],["read",["독서","책을","책장","읽"]],["dress",["갈아입","옷장","옷을"]],["view",["창밖","창문","노을","구경"]],["out",["외출","나갔","나가","산책","집을 나","장보"]],["chat",["대화","수다","얘기","말을 걸","이야기를 나","속삭"]]],We=[["sleep",["침대","이불"]],["tv",["소파"]],["eat",["식탁"]],["cook",["싱크대","가스레인지","레인지"]],["bath",["욕조"]],["wash",["세면대","세탁기"]],["read",["책장","서재"]],["view",["창가"]]],Zn=["섹스","성관계","정사","잠자리를","몸을 섞","애무","알몸","나체","옷을 벗","벗겼","절정","삽입","쾌감","오르가","sex","nsfw","naked","orgasm","moan"],Xs=[["goto_kitchen",["주방","부엌"]],["goto_living",["거실"]],["goto_bedroom",["안방","침실"]],["goto_bath",["화장실","욕실"]]];function an(h){let g=[];for(let _ of String(h).matchAll(/[^.!?\n]+[.!?]?/g)){let T=_[0].trim();if(!T)continue;let v=T.toLowerCase(),B=null,it=null,et=Zn.find(dt=>v.includes(dt));if(et&&(B="intimate",it=et),!B)for(let[dt,D]of Ws){let zt=D.find(le=>v.includes(le));if(zt){B=dt,it=zt;break}}if(!B)for(let[dt,D]of We){let zt=D.find(le=>v.includes(le));if(zt){B=dt,it=zt;break}}if(!B)for(let[dt,D]of Xs){let zt=D.find(le=>v.includes(le));if(zt){B=dt,it=zt;break}}let St=ht.filter(dt=>T.includes(dt.def.name)).map(dt=>dt.def.name);g.push({sentence:T,who:St.length?St:["*"],action:B,keyword:it})}return g}function Pi(h){let g=an(h);for(let _ of g)if(_.action)if(_.action==="intimate")_.who[0]!=="*"&&es(_.who[0],"intimate",_.who[1]);else if(_.action==="chat"&&_.who.length>=2)es(_.who[0],"chat",_.who[1]);else for(let T of _.who)es(T,_.action);return g}let qa=h=>h.startsWith("goto_")?Gs[h.slice(5)]+"(으)로 이동":Bn[h]||h,Te=18,Fe=22,Ki=.088,Za=[43,29,51];function hu(h,g,_,T,v,B){let it=document.createElement("canvas");it.width=Te,it.height=Fe;let et=it.getContext("2d"),St=v===1||v===2?1:0,dt=v===3,D=(oe,be,Xe,on,An,hi=1)=>{et.fillStyle=U(An),et.fillRect(1+oe,1+be+(hi?St:0),Xe,on)},{skin:zt,hair:le,eye:de,top:ie,topC:Ie,bottom:ae,botC:Ce,hat:Be,hatC:Je,hairStyle:he}=B,ze=z(zt,.88),At=U(le),Ae=z(le,.75),Vn=z(le,1.25),un=U(Ie),$e=z(Ie,.78),dn=U(Ce),Rr=z(Ce,.75),Pr="#3a2a30",io="#2a1d2a",so=U(de),Js=z(Je,.78),Tu=z(Je,1.15),tc="#c85a64",li="#f06a9a",ci=ie==="dress",ec=ie==="hood"||ie==="shirt",nc=oe=>v===1&&oe==="l"||v===2&&oe==="r"?1:0,ro=(oe,be,Xe,on)=>{ae==="pants"&&!ci?D(oe,15,be,4-Xe,on?Rr:dn,0):ae==="shorts"&&!ci?(D(oe,15,be,2,on?Rr:dn,0),D(oe,17,be,2-Xe,zt,0)):D(oe,15,be,4-Xe,zt,0),D(oe,19-Xe,be,1,Pr,0)},ao=oe=>{Be==="cap"?(D(5,2,6,2,Je),D(6,1,4,1,Je),oe==="f"?D(4,4,8,1,Js):oe==="s"?D(9,4,3,1,Js):D(5,4,6,1,Js)):Be==="straw"&&(D(6,1,4,2,Je),D(6,2,4,1,Js),D(3,3,10,1,Tu),oe!=="b"&&D(4,4,8,1,Js))};if(T<2){if(dt){let An=(ae==="pants"||ae==="shorts")&&!ci?dn:U(zt);D(5,15,6,1,An,0),D(7,16,2,1,An,0),D(5,16,2,1,Pr,0),D(9,16,2,1,Pr,0)}else ro(5,3,nc("l"),!1),ro(8,3,nc("r"),!0);let oe=v===1?1:v===2?-1:0,be=oe>0?1:0,Xe=oe<0?1:0,on=(An,hi,ic)=>{ec?(D(An,10+hi,1,3,ic),D(An,13+hi,1,1,zt)):(D(An,10+hi,1,2,ic),D(An,12+hi,1,2,zt))};on(3,be,un),on(12,Xe,$e),D(4,9,8,6,un),D(10,10,2,5,$e),ci?(D(3,15,10,2,un),D(3,16,10,1,$e)):ae==="skirt"?(D(4,14,8,1,dn),D(3,15,10,2,dn),D(3,16,10,1,Rr)):D(4,14,8,1,dn),T===0?((ie==="tee"||ci)&&D(7,9,2,1,zt),ie==="hood"&&(D(5,9,6,1,$e),D(7,10,1,2,"#f4f0e8"),D(9,10,1,2,"#f4f0e8"),D(6,12,4,2,$e)),ie==="shirt"&&(D(6,9,4,1,"#f4f4f8"),D(8,11,1,1,"#f4f4f8"),D(8,13,1,1,"#f4f4f8")),ci&&D(7,10,2,1,$e)):ie==="hood"&&D(5,9,6,2,$e),D(5,3,6,6,zt),T===0&&(D(6,6,1,1,io),D(6,7,1,1,so),D(9,6,1,1,io),D(9,7,1,1,so),D(5,7,1,1,"#f09a9a"),D(10,7,1,1,"#f09a9a"),D(8,8,1,1,tc)),T===0?(he!=="spiky"&&(D(6,2,4,1,At),D(5,3,6,1,At)),(he==="short"||he==="pony"||he==="twin"||he==="bun")&&(D(5,4,2,1,At),D(9,4,2,1,At),D(5,5,1,1,At),D(10,5,1,1,At),D(7,4,1,1,At)),he==="bob"&&(D(5,4,6,1,At),D(4,3,1,6,At),D(11,3,1,6,At),D(5,5,1,3,At),D(10,5,1,3,At),D(7,3,2,1,Vn)),he==="long"&&(D(5,4,2,1,At),D(9,4,2,1,At),D(5,5,1,4,At),D(10,5,1,4,At),D(4,9,2,5,At),D(10,9,2,5,At),D(4,13,2,1,Ae),D(10,13,2,1,Ae)),he==="twin"&&(D(3,5,2,5,At),D(11,5,2,5,At),D(3,5,2,1,li),D(11,5,2,1,li),D(3,9,2,1,Ae),D(11,9,2,1,Ae)),he==="spiky"&&(D(5,2,6,2,At),D(5,1,1,1,At),D(7,0,1,2,At),D(9,1,1,1,At),D(10,0,1,1,At),D(5,4,1,2,At),D(10,4,1,2,At),D(7,4,1,1,At)),he==="bun"&&D(7,0,2,2,At),he==="pony"&&D(11,3,1,2,li),ao("f")):(D(5,2,6,6,At),D(5,8,6,1,Ae),he==="long"&&(D(5,8,6,5,At),D(5,12,6,1,Ae)),he==="bob"&&(D(4,2,8,7,At),D(4,8,8,1,Ae)),he==="twin"&&(D(4,2,8,6,At),D(3,5,2,5,At),D(11,5,2,5,At),D(3,5,2,1,li),D(11,5,2,1,li)),he==="pony"&&(D(7,5,2,1,li),D(7,6,2,6,At),D(7,12,2,1,Ae)),he==="spiky"&&(D(5,1,1,1,At),D(7,0,1,2,At),D(9,1,1,1,At),D(10,0,1,1,At)),he==="bun"&&D(7,0,2,2,At),ao("b"))}else{let oe=v===1?1:v===2?-1:0,be=v===0?[[6,0,!0],[8,0,!1]]:v===1?[[4,1,!0],[9,0,!1]]:[[9,1,!0],[4,0,!1]];if(dt){let on=(ae==="pants"||ae==="shorts")&&!ci?dn:U(zt);D(6,15,5,2,on,0),D(11,15,2,2,Pr,0)}else for(let[on,An,hi]of be)ro(on,2,An,hi);D(5,9,6,6,un),D(5,9,1,6,$e),ci?(D(4,15,8,2,un),D(4,16,8,1,$e)):ae==="skirt"?(D(5,14,6,1,dn),D(4,15,8,2,dn),D(4,16,8,1,Rr)):D(5,14,6,1,dn);let Xe=7+oe;if(ec?(D(Xe,10,2,3,$e),D(Xe,13,2,1,zt)):(D(Xe,10,2,2,$e),D(Xe,12,2,2,zt)),he==="long"&&(D(4,3,3,10,At),D(4,12,3,1,Ae)),D(5,3,6,6,zt),D(9,6,1,1,io),D(9,7,1,1,so),D(10,7,1,1,ze),D(9,8,1,1,tc),he!=="spiky"&&(D(5,2,6,2,At),D(5,3,4,3,At),D(5,6,2,2,Ae),D(9,4,1,1,At)),he==="bob"&&(D(4,3,4,6,At),D(4,8,4,1,Ae)),he==="twin"&&(D(4,5,2,5,At),D(4,5,2,1,li)),he==="pony"){let on=v?2:3;D(on,4,2,1,li),D(on,5,2,6,At),D(on,10,2,1,Ae)}he==="spiky"&&(D(5,2,6,2,At),D(5,3,4,3,At),D(5,1,1,1,At),D(7,0,1,2,At),D(9,1,1,1,At),D(5,6,2,2,Ae)),he==="bun"&&D(4,1,3,2,At),ao("s")}let Au=et.getImageData(0,0,Te,Fe),Lr=Au.data,rs=new Uint8ClampedArray(Lr),$s=(oe,be)=>oe<0||be<0||oe>=Te||be>=Fe?0:Lr[(be*Te+oe)*4+3];for(let oe=0;oe<Fe;oe++)for(let be=0;be<Te;be++)if(!$s(be,oe)&&($s(be-1,oe)||$s(be+1,oe)||$s(be,oe-1)||$s(be,oe+1))){let Xe=(oe*Te+be)*4;rs[Xe]=Za[0],rs[Xe+1]=Za[1],rs[Xe+2]=Za[2],rs[Xe+3]=255}for(let oe=3;oe<Lr.length;oe+=4)Lr[oe]&&(rs[oe]=255);et.putImageData(new ImageData(rs,Te,Fe),0,0),h.drawImage(it,g,_)}function Ja(h){let g=document.createElement("canvas");g.width=Te*4,g.height=Fe*3;let _=g.getContext("2d");for(let T=0;T<3;T++)for(let v=0;v<4;v++)hu(_,v*Te,T*Fe,T,v,h);return g}function Ul(h){let g=new Os(Ja(h));return g.magFilter=qe,g.minFilter=qe,g.generateMipmaps=!1,g.colorSpace=Re,g.repeat.set(1/4,1/3),g}let wn={hairStyle:[["short","짧은머리"],["bob","단발"],["long","긴머리"],["twin","양갈래"],["pony","포니테일"],["spiky","뾰족머리"],["bun","올림머리"]],top:[["tee","티셔츠"],["hood","후드티"],["shirt","셔츠"],["dress","원피스"]],bottom:[["pants","긴바지"],["shorts","반바지"],["skirt","치마"]],hat:[["none","없음"],["cap","캡모자"],["straw","밀짚모자"]]},Me={hair:[2499120,5913128,9067066,15253594,12865582,15235752,5929696,10124008,15262960,4173962],eye:[2759978,6963752,3832536,4173962,10115808,15226698,15251514,8030872],skin:[16769224,16176048,15185039,13209190,9263676,5913130],cloth:[15226698,15764042,16046170,6995818,5947568,4890840,10124008,15769792,16052456,3885690,4864602,2499120]},Nl=[{id:"c1",name:"모리",skin:16176048,hair:5913128,eye:6963752,hairStyle:"short",top:"hood",topC:15226698,bottom:"pants",botC:3885690,hat:"none",hatC:16046170},{id:"c2",name:"별이",skin:16769224,hair:15235752,eye:10115808,hairStyle:"twin",top:"dress",topC:16046170,bottom:"skirt",botC:6965898,hat:"none",hatC:16046170},{id:"c3",name:"하루",skin:15185039,hair:2499120,eye:3832536,hairStyle:"spiky",top:"tee",topC:4890840,bottom:"shorts",botC:4864602,hat:"cap",hatC:15226698},{id:"c4",name:"루나",skin:16176048,hair:5929696,eye:4173962,hairStyle:"long",top:"shirt",topC:16052456,bottom:"skirt",botC:3885690,hat:"none",hatC:16046170}],zn=N.get("house.cast.v1",null)||Nl.map(h=>({...h})),Ol=s("#bubbles"),uu=.3,du=new fr(1,1).translate(0,.5,0),fu=new gr(.34,14).rotateX(-Math.PI/2),$a={chat:["안녕!","오늘 뭐 했어?","♪","배고파…","후후","♥","이리 와봐!","같이 TV 볼래?"],wander:["♪","흠~","…!","뭐 하지?"]},wr={idle:"멍하니 있는 중",chat:"수다 떠는 중",wander:"집 안을 거니는 중"},Fl=()=>"c"+Math.random().toString(36).slice(2,8);function Er(h,g){let _=Ul(h),T=new gn({map:_,alphaTest:.5,color:16777215,side:In}),v=new ke(du,T);v.rotation.order="YXZ",v.scale.set(Te*Ki,Fe*Ki,1),S.add(v);let B=new ke(fu,new gn({color:0,transparent:!0,opacity:.3,depthWrite:!1,polygonOffset:!0,polygonOffsetFactor:-2}));S.add(B);let it=document.createElement("div");it.className="bubble",Ol.appendChild(it);let et=document.createElement("div");et.className="name",et.textContent=h.name,Ol.appendChild(et);let[St,dt]=g||p(Le),D={def:h,sp:v,sh:B,tex:_,mat:T,el:it,nm:et,pos:new F(St*c,0,dt*c),path:null,pi:0,state:"idle",timer:.5+Math.random()*2,kind:"wander",spot:null,pose:"stand",spotY:jt,face:new Pt(0,1),phase:Math.random()*5,say:"",sayT:0,chatCd:3+Math.random()*6,speed:1.2+Math.random()*.3,hidden:!1,act:wr.idle,forced:!1};return v.userData.char=D,ht.push(D),D}function ja(h){S.remove(h.sp),S.remove(h.sh),h.el.remove(),h.nm.remove(),h.tex.dispose(),ht.splice(ht.indexOf(h),1),Tn===h&&(Tn=null)}function pu(h){h.tex.dispose(),h.tex=Ul(h.def),h.mat.map=h.tex,h.mat.needsUpdate=!0,h.nm.textContent=h.def.name}let Bl=h=>Math.round(h/c),Qi=h=>[Bl(h.pos.x),Bl(h.pos.z)];function ts(h){h.spot&&(h.pose!=="stand"||h.hidden)&&h.pos.set(h.spot.walk[0]*c,0,h.spot.walk[1]*c),h.pose="stand",h.hidden=!1,h.spot=null}function zl(h,g){return ht.some(_=>_!==g&&(_.spot===h||_.plan&&_.plan.spot===h))}function kl(h,g,_=!1){ts(h);let[T,v]=Qi(h),B=xe(T,v,g.walk[0],g.walk[1]);return B?(h.plan={spot:g},h.path=B,h.pi=1,h.state=(B.length<2,"walk"),h.kind=g.kind,h.act=g.txt,h.forced=_,B.length<2&&(h.path=[B[0],B[0]],h.pi=1),!0):(h.state="idle",h.timer=1,!1)}function Tr(h,g,_,T=wr.wander,v=!1){ts(h);let[B,it]=Qi(h),et=xe(B,it,g,_);return!et||et.length<2?(h.state="idle",h.timer=.6,!1):(h.plan={spot:null},h.path=et,h.pi=1,h.state="walk",h.kind="wander",h.act=T,h.forced=v,!0)}function mu(h){let g={dusk:{tv:3,cook:2,eat:2,read:1.2,view:1.2,wash:1,bath:1,sleep:.4,dress:.6,wander:1.5,out:.5},night:{tv:2,cook:.4,eat:.4,read:1,view:.6,wash:1.5,bath:1.5,sleep:5,dress:.6,wander:.5,out:.1},day:{tv:1.5,cook:2.5,eat:2.5,read:1.5,view:1.5,wash:1,bath:.5,sleep:.3,dress:.8,wander:2,out:1.5}}[G],_=0;for(let it in g)_+=g[it];let T=Math.random()*_,v="wander";for(let it in g)if(T-=g[it],T<=0){v=it;break}if(v==="wander"){let[it,et]=Qi(h),St=Le.filter(([zt,le])=>Math.hypot(zt-it,le-et)>4&&Math.hypot(zt-it,le-et)<14),[dt,D]=p(St.length?St:Le);Tr(h,dt,D);return}let B=qn.filter(it=>it.kind===v&&!zl(it,h));if(!B.length){h.state="idle",h.timer=1.5;return}kl(h,p(B))}function Hl(h,g,_){let T=g-h.pos.x,v=_-h.pos.z,B=Math.hypot(T,v)||1;h.face.set(T/B,v/B)}function Li(h,g){h.say=p(g),h.sayT=2.8}function Vl(h){let g=h.plan&&h.plan.spot;h.state="act",h.path=null,g?(h.spot=g,h.pose=g.pose,h.spotY=g.y??jt,h.pos.set(g.at[0]*c,0,g.at[1]*c),h.face.set(g.face[0],g.face[1]),g.kind==="out"?(h.hidden=!0,h.timer=10+Math.random()*14):h.timer=g.kind==="sleep"?22+Math.random()*20:g.kind==="bath"?14+Math.random()*10:10+Math.random()*14,Math.random()<.85&&Li(h,g.say)):h.kind==="intimate"?(h.timer=20+Math.random()*8,h.say="19♥",h.sayT=h.timer,h.act="둘만의 시간 (19♥)",h.partner&&Hl(h,h.partner.pos.x,h.partner.pos.z)):(h.timer=.8+Math.random()*2,Math.random()<.3&&Li(h,$a.wander))}function Gl(h,g){for(let[_,T]of[[h,g],[g,h]])ts(_),_.state="chat",_.path=null,_.timer=4+Math.random()*2,_.chatCd=16+Math.random()*10,_.act=wr.chat,_.forced=!1,Hl(_,T.pos.x,T.pos.z);Li(h,$a.chat),g.sayT=-1.2}let kn=new F,Ys=new F,En=new F,gu=new F(0,1,0);function Wl(h,g){R.getWorldDirection(kn),kn.y=0,kn.normalize(),Ys.crossVectors(kn,gu).normalize();let _=Math.atan2(-kn.x,-kn.z),T=(Math.PI/2-V.getPolarAngle())*uu;for(let v of ht){v.chatCd-=g,v.sayT-=g;let B=!1;if(v.state==="idle")v.timer-=g,v.timer<=0&&k.auto&&mu(v);else if(v.state==="walk"){let ze=v.path[v.pi],At=ze[0]*c,Ae=ze[1]*c,Vn=At-v.pos.x,un=Ae-v.pos.z,$e=Math.hypot(Vn,un),dn=v.speed*k.speed*g;$e<=dn?(v.pos.x=At,v.pos.z=Ae,v.pi++,v.pi>=v.path.length&&Vl(v)):(v.pos.x+=Vn/$e*dn,v.pos.z+=un/$e*dn,v.face.set(Vn/$e,un/$e),B=!0)}else if(v.state==="act")if(v.timer-=g,v.timer<=0){let ze=v.hidden;ts(v),v.state="idle",v.timer=.3+Math.random()*1.5,v.act=wr.idle,v.forced=!1,ze&&Li(v,["다녀왔어!","밖에 좋더라"])}else v.spot&&v.spot.kind!=="sleep"&&Math.random()<g*.1&&Li(v,v.spot.say);else v.state==="chat"&&(v.timer-=g,v.timer<=0?(v.state="idle",v.timer=.3):v.sayT<=0&&Li(v,$a.chat));if((v.state==="walk"||v.state==="idle")&&v.chatCd<=0&&!v.hidden&&k.auto){for(let ze of ht)if(!(ze===v||ze.hidden||ze.state!=="walk"&&ze.state!=="idle"||ze.chatCd>0)&&Math.hypot(ze.pos.x-v.pos.x,ze.pos.z-v.pos.z)<1.1){Gl(v,ze);break}}v.state==="walk"&&v.kind==="chat"&&v.partner&&Math.hypot(v.partner.pos.x-v.pos.x,v.partner.pos.z-v.pos.z)<1.4&&!v.partner.hidden&&(Gl(v,v.partner),v.partner=null),v.phase+=B?g*v.speed*k.speed*4.2:0;let it=B?Math.floor(v.phase)%2===0?1:2:0,et=v.face.x*kn.x+v.face.y*kn.z,St=v.face.x*Ys.x+v.face.y*Ys.z,dt,D=1,zt=it;Math.abs(St)>Math.abs(et)?(dt=2,D=St>=0?1:-1):dt=et>0?1:0;let le=1,de=0,ie=jt,Ie=!1;v.pose==="sit"?(le=.82,ie=v.spotY,zt=3):v.pose==="bath"?(le=.55,ie=v.spotY,zt=0,dt=0,D=1):v.pose==="lie"&&(Ie=!0,de=-Math.PI/2,ie=v.spotY+.28,zt=0,dt=0,D=1);let ae=v.tex,Ce=1-(dt+1)/3;ae.repeat.set(D/4,le/3),ae.offset.x=(D>0?zt:zt+1)/4,ae.offset.y=Ce+(1-le)/3;let Be=Fe*Ki*le;v.sp.scale.set(Te*Ki,Be,1),v.mat.color.copy(I.tint),v.sp.rotation.set(-T,_,de);let Je=-kn.x*.12,he=-kn.z*.12;Ie?v.sp.position.set(v.pos.x-Ys.x*Be/2+Je,ie,v.pos.z-Ys.z*Be/2+he):v.sp.position.set(v.pos.x+Je,ie-(le<1?0:Ki),v.pos.z+he),v.sp.visible=!v.hidden,v.sh.position.set(v.pos.x,jt+.03,v.pos.z),v.sh.visible=!v.hidden&&v.pose==="stand",v.topY=Ie?ie+.7:ie+Fe*Ki*le+.1}}function Ka(h){return!h||h==="*"||h==="all"?ht.slice():ht.filter(g=>g.def.name===h||g.def.id===h)}function es(h,g,_){let T=Ka(h);if(!T.length)return!1;for(let v of T)if(g==="chat"){let B=_&&Ka(_)[0]||ht.filter(dt=>dt!==v&&!dt.hidden).sort((dt,D)=>Math.hypot(dt.pos.x-v.pos.x,dt.pos.z-v.pos.z)-Math.hypot(D.pos.x-v.pos.x,D.pos.z-v.pos.z))[0];if(!B)continue;ts(B),B.state="idle",B.timer=3;let[it,et]=Qi(B),St=[[1,0],[-1,0],[0,1],[0,-1],[1,1],[-1,-1]].map(([dt,D])=>[it+dt,et+D]).filter(([dt,D])=>ue(dt,D));St.length&&Tr(v,...St[0],"대화하러 가는 중",!0)&&(v.kind="chat",v.partner=B,v.chatCd=0,B.chatCd=0)}else if(g==="intimate"){if(v.kind==="intimate"&&v.state!=="idle")continue;let B=_&&Ka(_)[0]||ht.filter(dt=>dt!==v&&!dt.hidden).sort((dt,D)=>Math.hypot(dt.pos.x-v.pos.x,dt.pos.z-v.pos.z)-Math.hypot(D.pos.x-v.pos.x,D.pos.z-v.pos.z))[0];if(!B||B===v)continue;let it=qn.find(dt=>dt.kind==="sleep"),et=it?it.walk:[0,3],St=[[0,0],[1,0],[-1,0],[0,1],[0,-1],[1,1],[-1,1]].map(([dt,D])=>[et[0]+dt,et[1]+D]).filter(([dt,D])=>ue(dt,D));if(St.length<2)continue;for(let[dt,D,zt]of[[v,St[0],B],[B,St[1],v]]){let le=Tr(dt,D[0],D[1],"둘만의 시간 (19♥)",!0);dt.kind="intimate",dt.partner=zt,dt.chatCd=90,le||(dt.plan={spot:null},Vl(dt))}}else if(g.startsWith("goto_")){let B=g.slice(5),it=Ee[B];if(!it)continue;let[et,St]=p(it);Tr(v,et,St,me[B]+"(으)로 이동 중",!0)}else if(ye.includes(g)){let B=qn.filter(et=>et.kind===g),it=B.filter(et=>!zl(et,v));kl(v,p(it.length?it:B),!0)}return!0}let Xl=h=>{let g=h.data;g&&g.type==="scene"&&typeof g.action=="string"?es(g.who,g.action):g&&g.type==="story"&&typeof g.text=="string"&&Pi(g.text)};window.addEventListener("message",Xl);let W0=null,Tn=null;function xu(){let h=o(),g=a();for(let _ of ht){En.set(_.pos.x,_.topY??2.2,_.pos.z).project(R);let T=!_.hidden&&En.z<1&&Math.abs(En.x)<1.1&&Math.abs(En.y)<1.1,v=(En.x*.5+.5)*h,B=(-En.y*.5+.5)*g;_.el.style.left=v+"px",_.el.style.top=B-2+"px",_.el.textContent!==_.say&&(_.el.textContent=_.say),_.el.classList.toggle("show",T&&_.sayT>0),_.nm.style.left=v+"px",_.nm.style.top=B+2+"px",_.nm.classList.toggle("show",T&&(k.names||_===Tn))}if(k.roomtag)for(let _ in ji)En.set(ji[_][0]*c,.4,ji[_][1]*c).project(R),E[_].style.left=(En.x*.5+.5)*h+"px",E[_].style.top=(-En.y*.5+.5)*g+"px"}let Yl=new Ua,ql=new Pt,Ar=null;j.domElement.addEventListener("pointerdown",h=>{Ar=[h.clientX,h.clientY]}),j.domElement.addEventListener("pointerup",h=>{if(!Ar||Math.hypot(h.clientX-Ar[0],h.clientY-Ar[1])>5)return;let g=j.domElement.getBoundingClientRect();ql.set((h.clientX-g.left)/g.width*2-1,-((h.clientY-g.top)/g.height)*2+1),Yl.setFromCamera(ql,R);let _=Yl.intersectObjects(ht.filter(T=>!T.hidden).map(T=>T.sp),!1)[0];Tn=_?_.object.userData.char:null,Di()});function ai(h){let g=s("#toast");g.textContent=h,g.style.opacity=1,clearTimeout(ai.h),ai.h=setTimeout(()=>g.style.opacity=0,1800)}let oi=null;function Ii(h){oi===h&&(h=null),oi=h,s("#panel").classList.toggle("open",!!h),r("#rail button").forEach(g=>g.classList.toggle("on",g.dataset.p===h||h==="create"&&g.dataset.p==="create")),r(".sec").forEach(g=>g.classList.toggle("on",g.id==="s-"+h)),h==="cast"&&Di(),h==="create"&&(Hn||to(null)),h==="scene"&&Zs()}r("#rail button").forEach(h=>h.addEventListener("click",()=>{h.dataset.p==="create"&&(Hn=Hn),Ii(h.dataset.p)}));function _u(h){let g=document.createElement("canvas");g.width=Te,g.height=Fe;let _=g.getContext("2d");return _.imageSmoothingEnabled=!1,_.drawImage(Ja(h),0,0,Te,Fe,0,0,Te,Fe),g}function Di(){let h=s("#castList");h.innerHTML="",ht.forEach(g=>{let _=document.createElement("div");_.className="card"+(g===Tn?" sel":""),_.appendChild(_u(g.def));let T=document.createElement("div");T.className="t",T.innerHTML=`${g.def.name}<small>${g.act}</small>`,_.appendChild(T);let v=document.createElement("button");v.textContent="수정",v.onclick=it=>{it.stopPropagation(),to(g),Ii("create"),oi==="create"||Ii("create")},_.appendChild(v);let B=document.createElement("button");B.textContent="삭제",B.onclick=it=>{if(it.stopPropagation(),ht.length<=1)return ai("최소 1명은 있어야 해요");ja(g),zn=ht.map(et=>et.def),N.set("house.cast.v1",zn),Di(),Zs()},_.appendChild(B),_.onclick=()=>{Tn=Tn===g?null:g,Di()},h.appendChild(_)}),s("#newChar").style.display=ht.length>=8?"none":""}let vu=setInterval(()=>{oi==="cast"&&Di()},1500);s("#newChar").onclick=()=>{to(null),oi=null,Ii("create")};let De=null,Hn=null,Qa=!0,Zl=null,Jl={};function yu(h){let g=s("#o-"+h);g.innerHTML="",wn[h].forEach(([_,T])=>{let v=document.createElement("button");v.className="chip",v.textContent=T,v.dataset.v=_,v.onclick=()=>{De[h]=_,qs()},g.appendChild(v)})}function ns(h,g){let _=s("#o-"+h);_.innerHTML="",g.forEach(v=>{let B=document.createElement("button");B.className="sw",B.style.background=U(v),B.dataset.v=v,B.onclick=()=>{De[h]=v,qs()},_.appendChild(B)});let T=document.createElement("input");T.type="color",T.oninput=()=>{De[h]=parseInt(T.value.slice(1),16),qs(!0)},_.appendChild(T),Jl[h]=T}["hairStyle","top","bottom","hat"].forEach(yu),ns("hair",Me.hair),ns("eye",Me.eye),ns("skin",Me.skin),ns("topC",Me.cloth),ns("botC",Me.cloth),ns("hatC",Me.cloth);function qs(h){for(let _ of["hairStyle","top","bottom","hat"])r("#o-"+_+" .chip").forEach(T=>T.classList.toggle("on",T.dataset.v===De[_]));for(let _ of["hair","eye","skin","topC","botC","hatC"])r("#o-"+_+" .sw").forEach(T=>T.classList.toggle("on",+T.dataset.v===De[_])),h||(Jl[_].value=U(De[_]));let g=De.top==="dress";s("#o-bottom").classList.toggle("dis",g),s("#o-botC").classList.toggle("dis",g),s("#dressNote").textContent=g?"(원피스는 하의가 없어요)":"",r("#o-bottom .chip").forEach(_=>_.classList.toggle("dis",g)),s("#o-hatC").style.opacity=De.hat==="none"?.35:1,Qa=!0}function to(h){Hn=h,De=h?{...h.def}:{id:Fl(),name:"",skin:p(Me.skin),hair:p(Me.hair),eye:p(Me.eye),hairStyle:p(wn.hairStyle)[0],top:p(wn.top)[0],topC:p(Me.cloth),bottom:p(wn.bottom)[0],botC:p(Me.cloth),hat:"none",hatC:p(Me.cloth)},s("#cName").value=De.name,s("#createTitle").textContent=h?"✏️ 캐릭터 수정":"✨ 캐릭터 만들기",s("#cSave").textContent=h?"저장하기":"집에 추가하기",qs()}s("#cName").oninput=h=>{De.name=h.target.value},s("#cRand").onclick=()=>{let h=De.name;De={id:De.id,name:h,skin:p(Me.skin),hair:p(Me.hair),eye:p(Me.eye),hairStyle:p(wn.hairStyle)[0],top:p(wn.top)[0],topC:p(Me.cloth),bottom:p(wn.bottom)[0],botC:p(Me.cloth),hat:Math.random()<.25?p(wn.hat.slice(1))[0]:"none",hatC:p(Me.cloth)},qs()},s("#cCancel").onclick=()=>{Hn=null,oi="create",Ii("create")},s("#cSave").onclick=()=>{let h=(De.name||"").trim();if(!h)return ai("이름을 입력해 주세요");if(ht.some(g=>g!==Hn&&g.def.name===h))return ai("같은 이름이 이미 있어요");if(De.name=h,Hn)Hn.def={...De},pu(Hn),ai(h+" 저장했어요");else{if(ht.length>=8)return ai("최대 8명까지예요");let g=Er({...De},[-7,14]);g.state="idle",g.timer=.4,Li(g,["안녕! 잘 부탁해","여기가 우리 집이구나!"]),ai(h+" 입주 완료!")}zn=ht.map(g=>g.def),N.set("house.cast.v1",zn),Hn=null,oi="create",Ii("cast"),Zs()};let Mu=[0,1,2].map(h=>{let g=s("#pv"+h);return g.width=Te*5,g.height=Fe*5,g.getContext("2d")});function $l(h){if(!l||(requestAnimationFrame($l),oi!=="create"||!De))return;Qa&&(Zl=Ja(De),Qa=!1),[[0,0],[Math.floor(h/200)%2+1,2],[0,1]].forEach(([_,T],v)=>{let B=Mu[v];B.imageSmoothingEnabled=!1,B.clearRect(0,0,Te*5,Fe*5),B.fillStyle="rgba(255,255,255,.07)",B.fillRect(0,0,Te*5,Fe*5),B.drawImage(Zl,_*Te,T*Fe,Te,Fe,0,0,Te*5,Fe*5)})}requestAnimationFrame($l);function Zs(){let h=s("#sceneWho"),g=h.value;h.innerHTML='<option value="*">모두</option>'+ht.map(T=>`<option value="${T.def.id}">${T.def.name}</option>`).join(""),[...h.options].some(T=>T.value===g)&&(h.value=g);let _=(T,v,B)=>{T.innerHTML="";for(let it in v){let et=document.createElement("button");et.className="chip",et.textContent=v[it],et.onclick=()=>es(h.value,B+it),T.appendChild(et)}};_(s("#sceneGo"),Gs,"goto_"),_(s("#sceneAct"),Bn,"")}s("#storyEx").onclick=()=>{s("#storyIn").value=ht.slice(0,3).map((h,g)=>[h.def.name+"는 소파에 앉아 TV를 봤다.",h.def.name+"는 졸려서 침대로 가서 잠들었다.",h.def.name+"는 주방에서 요리를 시작했다."][g]).join(`
`)},s("#storyGo").onclick=()=>{let h=Pi(s("#storyIn").value),g=s("#storyOut");if(g.innerHTML="",!h.length){g.textContent="읽을 문장이 없어요.";return}for(let _ of h){let T=document.createElement("div");T.style.cssText="padding:4px 0;border-top:1px solid rgba(255,255,255,.15)",T.textContent=_.action?`✔ "${_.sentence}" → ${_.who.join(", ")==="*"?"모두":_.who.join(", ")}: ${qa(_.action)} (키워드 '${_.keyword}')`:`— "${_.sentence}" → 반응 없음`,g.appendChild(T)}};function bu(h){if(h=String(h||"").trim().slice(0,16),!h||ht.some(_=>_.def.name===h)||ht.length>=8)return!1;let g={id:Fl(),name:h,skin:p(Me.skin),hair:p(Me.hair),eye:p(Me.eye),hairStyle:p(wn.hairStyle)[0],top:p(wn.top)[0],topC:p(Me.cloth),bottom:p(wn.bottom)[0],botC:p(Me.cloth),hat:"none",hatC:p(Me.cloth)};return Er(g,[-7,14]),zn=ht.map(_=>_.def),N.set("house.cast.v1",zn),Di(),Zs(),!0}function Cr(){n.classList.toggle("nobubble",!k.bubble),n.classList.toggle("noroomtag",!k.roomtag),eo.enabled=k.bloom,V.autoRotate=k.rotate,s("#spdVal").textContent=(+k.speed).toFixed(1),r("#setTod .chip").forEach(h=>h.classList.toggle("on",h.dataset.m===G)),N.set("house.settings.v1",{...k,mode:G})}{let h=s("#setTod");[["dusk","🌇 노을"],["night","🌙 밤"],["day","☀️ 낮"]].forEach(([g,_])=>{let T=document.createElement("button");T.className="chip",T.dataset.m=g,T.textContent=_,T.onclick=()=>{G=g,Cr()},h.appendChild(T)})}let Ui=(h,g,_)=>{let T=s(h);T.type==="checkbox"?T.checked=!!k[g]:T.value=k[g],T.oninput=()=>{k[g]=T.type==="checkbox"?T.checked:+T.value,Cr()}};Ui("#setBubble","bubble"),Ui("#setRoomTag","roomtag"),Ui("#setNames","names"),Ui("#setBloom","bloom"),Ui("#setAuto","auto"),Ui("#setRotate","rotate"),Ui("#setSpeed","speed"),s("#resetCast").onclick=()=>{confirm("캐릭터를 기본 4명으로 되돌릴까요?")&&([...ht].forEach(ja),zn=Nl.map(h=>({...h})),N.set("house.cast.v1",zn),zn.forEach(h=>Er({...h})),Di(),Zs())};let Su=new je(o()*j.getPixelRatio(),a()*j.getPixelRatio(),{type:mn,samples:4}),is=new Va(j,Su);is.addPass(new Ga(S,R));let eo=new Hs(new Pt(o(),a()),.45,.55,.62);is.addPass(eo);let no=new ks(ou);no.uniforms.offset.value=1,no.uniforms.darkness.value=1,is.addPass(no),is.addPass(new Wa),zn.forEach(h=>Er({...h})),Cr();function wu(){Q.uniforms.discK.value=I.discK,S.fog.color.copy(I.fog),S.fog.density=I.den,vt.color.copy(I.keyCol),vt.intensity=I.keyInt,vt.position.copy(I.key).normalize().multiplyScalar(50),vt.target.position.set(0,0,0),Lt.color.copy(I.hSky),Lt.groundColor.copy(I.hGnd),Lt.intensity=I.hInt,X.color.setScalar(I.glow),ut.color.copy(I.win),nt.opacity=I.stars,eo.strength=I.bloom,j.toneMappingExposure=I.expo,bt.color.copy(I.fog).multiplyScalar(1.12).lerp(I.hor,.08);for(let h of Nt)h.intensity=9*I.lamp}let jl=performance.now()/1e3,Jn=0;function Eu(){let h=performance.now()/1e3,g=Math.min(.05,h-jl);jl=h,Jn+=g,K(g),wu();let _=ht.some(et=>et.spot&&et.spot.kind==="tv"&&et.state==="act");lt.color.set(_?d(5943551,16765088,(Math.sin(Jn*3)*.5+.5)*(Math.sin(Jn*1.3)*.5+.5)):1315868).multiplyScalar(_?1.2+I.glow*.3:1),ot.forEach(et=>{et.m.position.x+=et.sp*g,et.m.position.x>160&&(et.m.position.x=-160)});let T=Z.geometry.attributes.position,v=Ti.find(et=>et.type==="steam"),B=!!v&&ht.some(et=>et.spot&&et.spot.steam&&et.state==="act");q.forEach((et,St)=>{et.t+=g*(B?.6:0),et.t>3&&(et.t=0),T.setXYZ(St,v?v.x+Math.sin(et.t*2+St)*.2:0,B?v.y+et.t*.6:-50,v?v.z+Math.cos(et.t+St)*.15:0)}),T.needsUpdate=!0,T=wt.geometry.attributes.position,Bt.forEach((et,St)=>T.setXYZ(St,et.x+Math.sin(Jn*et.sp+et.ph)*.8,et.y+Math.sin(Jn*et.sp*1.4+et.ph)*.4,et.z+Math.cos(Jn*et.sp*.7+et.ph)*.6)),T.needsUpdate=!0;let it=Ti.find(et=>et.type==="bubbles");T=Xt.geometry.attributes.position,Zt.forEach((et,St)=>{et.t=(et.t+g*.5)%2,T.setXYZ(St,it?it.x+Math.sin(St*5+et.t)*1.4+St%3*.3-.4:0,it?it.y-.8+et.t*.3:-50,it?it.z+St%4*.25-.3:0)}),T.needsUpdate=!0,Wl(Jn,g),xu(),Tn&&!Tn.hidden?V.target.lerp(En.set(Tn.pos.x,1.2,Tn.pos.z),.05):V.target.lerp(En.set(0,1.5,.5),.04),V.update(),is.render()}j.setAnimationLoop(Eu);let Kl=()=>{!o()||!a()||(j.setSize(o(),a()),is.setSize(o(),a()),R.aspect=o()/a(),R.updateProjectionMatrix())},Ql=new ResizeObserver(Kl);Ql.observe(n);let ss={addByName:bu,do:es,chars:ht,setMode:h=>{G=h,K(0,!0),Cr()},KEYWORDS:Ri,interpret:an,applyStory:Pi,tick:(h,g=.05)=>{for(let _=0;_<h/g;_++)Jn+=g,Wl(Jn,g);return ht.map(_=>_.def.name+":"+_.state+":"+_.kind+":"+_.pos.x.toFixed(1)+","+_.pos.z.toFixed(1)).join(" ")},camera:R,controls:V,showPanel:Ii,layout:_e,catalog:ne,rebuild:Fn,move:Sr,add:Xa,remove:Ya,spots:()=>qn};return ss.destroy=()=>{l=!1,j.setAnimationLoop(null),Ql.disconnect(),clearInterval(vu),window.removeEventListener("message",Xl);for(let h of[...ht])ja(h);j.dispose(),e.innerHTML="",t.global&&window[t.global]===ss&&delete window[t.global]},ss.resize=Kl,t.global&&(window[t.global]=ss),requestAnimationFrame(()=>requestAnimationFrame(()=>{ss.ready=!0,window.__ready=!0})),ss}(function(){if(window.__pixelWorldExt)try{window.__pixelWorldExt.destroy()}catch{}let i="pixelworld.ext.v1",e=Object.assign({field:"자세,행동,posture,pose,action,activity",chatId:"",poll:!0,sec:3,autoAdd:!0,w:760,h:480},(()=>{try{return JSON.parse(localStorage.getItem(i))||{}}catch{return{}}})()),n=()=>{try{localStorage.setItem(i,JSON.stringify(e))}catch{}},s=(...S)=>{try{(window.marinara&&window.marinara.log?window.marinara.log.info:console.log)("[pixel-world]",...S)}catch{console.log("[pixel-world]",...S)}},r=document.createElement("div");r.id="pixel-world-ext",r.style.cssText=`position:fixed;right:16px;bottom:16px;width:${e.w}px;height:${e.h}px;min-width:380px;min-height:280px;max-width:98vw;max-height:96vh;z-index:2147483000;display:flex;flex-direction:column;background:#2a1d4a;border:2px solid #fff;box-shadow:0 6px 24px rgba(0,0,0,.55);resize:both;overflow:hidden;font:12px sans-serif;color:#fff;box-sizing:border-box`;let o="cursor:pointer;background:rgba(255,255,255,.12);color:#fff;border:1px solid rgba(255,255,255,.4);padding:1px 7px;font:inherit";r.innerHTML=`
    <div id="pw-head" style="display:flex;align-items:center;gap:6px;padding:4px 8px;background:#3a2a5e;cursor:move;user-select:none;flex:none">
      <b>Pixel World</b><span id="pw-dot" style="opacity:.8;flex:1;overflow:hidden;text-overflow:ellipsis;white-space:nowrap">트래커 대기 중…</span>
      <button id="pw-set" style="${o}" title="트래커 연결 설정">⚙</button>
      <button id="pw-full" style="${o}" title="크게/작게">⛶</button>
      <button id="pw-min" style="${o}" title="접기">–</button>
      <button id="pw-x" style="${o}" title="닫기">✕</button>
    </div>
    <div id="pw-cfg" style="display:none;padding:8px;background:#33244f;border-bottom:1px solid rgba(255,255,255,.25);flex:none;line-height:1.9">
      <label>읽을 트래커 필드 이름 (콤마로 여러 개) <input id="pw-field" style="width:100%;box-sizing:border-box"></label>
      <label>채팅 ID (비우면 자동) <input id="pw-chat" style="width:100%;box-sizing:border-box" placeholder="자동"></label>
      <label><input type="checkbox" id="pw-poll"> 트래커 자동으로 읽기</label> &nbsp;
      <label>주기 <input id="pw-sec" type="number" min="1" max="30" style="width:48px"> 초</label> &nbsp;
      <label><input type="checkbox" id="pw-add"> 섬에 없는 이름은 자동 추가</label>
      <div><button id="pw-now" style="${o}">지금 읽기</button></div>
    </div>
    <div id="pw-island" style="flex:1;min-height:0;position:relative"></div>
    <div id="pw-log" style="flex:none;padding:3px 8px;background:#33244f;font-size:11px;opacity:.9;max-height:54px;overflow:auto"></div>`,document.body.appendChild(r);let a=S=>r.querySelector(S),l=cu(a("#pw-island"),{global:"pixelWorld"}),c=[],u=S=>{c.unshift(`${new Date().toLocaleTimeString()} ${S}`),c.length=Math.min(c.length,4),a("#pw-log").innerHTML=c.map(R=>`<div>${R.replace(/</g,"&lt;")}</div>`).join("")},f=S=>{a("#pw-dot").textContent=S};a("#pw-head").addEventListener("mousedown",S=>{if(S.target.tagName==="BUTTON")return;let R=r.getBoundingClientRect(),V=S.clientX-R.left,tt=S.clientY-R.top;r.style.left=R.left+"px",r.style.top=R.top+"px",r.style.right="auto",r.style.bottom="auto";let ft=k=>{r.style.left=Math.max(0,Math.min(innerWidth-80,k.clientX-V))+"px",r.style.top=Math.max(0,Math.min(innerHeight-30,k.clientY-tt))+"px"},I=()=>{removeEventListener("mousemove",ft),removeEventListener("mouseup",I)};addEventListener("mousemove",ft),addEventListener("mouseup",I)});let p=!1,x=null,y=!1;a("#pw-full").onclick=()=>{p=!p,p?(x=r.style.cssText,r.style.cssText+=";left:24px;top:24px;right:24px;bottom:24px;width:auto;height:auto;resize:none"):r.style.cssText=x,l.resize()},a("#pw-min").onclick=()=>{y=!y,a("#pw-island").style.display=y?"none":"",a("#pw-log").style.display=y?"none":"",r.style.height=y?"auto":e.h+"px",r.style.minHeight=y?"0":"280px",r.style.resize=y?"none":"both"},a("#pw-set").onclick=()=>{let S=a("#pw-cfg");S.style.display=S.style.display==="none"?"block":"none"},a("#pw-x").onclick=()=>j(),a("#pw-field").value=e.field,a("#pw-chat").value=e.chatId,a("#pw-poll").checked=e.poll,a("#pw-sec").value=e.sec,a("#pw-add").checked=e.autoAdd;let b=()=>{e.field=a("#pw-field").value,e.chatId=a("#pw-chat").value.trim(),e.poll=a("#pw-poll").checked,e.sec=Math.max(1,+a("#pw-sec").value||3),e.autoAdd=a("#pw-add").checked,n(),L()};for(let S of["#pw-field","#pw-chat","#pw-poll","#pw-sec","#pw-add"])a(S).addEventListener("change",b);a("#pw-now").onclick=()=>{C.clear(),N(!0)};let m=new Set("·:：/|()[]-–—,".split("")),d=S=>S.split("").map(R=>m.has(R)?" ":R).join("").split(" ").filter(Boolean).join(" ").slice(0,16),C=new Map,w=!1,U=null;async function z(){if(e.chatId)return e.chatId;try{let ft=window.marinara&&window.marinara.context&&window.marinara.context.get&&window.marinara.context.get();if(ft&&ft.chatId)return ft.chatId}catch{}let S=location.href.match(/[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}/i);if(S)return S[0];let R=await fetch("/api/chats",{credentials:"same-origin"});if(!R.ok)throw new Error("채팅 목록 "+R.status);let V=await R.json(),tt=Array.isArray(V)?V:V.chats||V.items||[];return tt.sort((ft,I)=>String(I.updatedAt||I.createdAt||"").localeCompare(String(ft.updatedAt||ft.createdAt||""))),tt[0]&&tt[0].id}async function N(S){if(!w){w=!0;try{let R=await z();if(!R){f("채팅을 찾지 못했어요");return}let V=await fetch("/api/chats/"+encodeURIComponent(R)+"/game-state",{credentials:"same-origin"});if(!V.ok){f("트래커 읽기 실패 ("+V.status+")");return}let tt=await V.json();if(!tt){f("트래커 데이터가 아직 없어요 (트래커 에이전트를 켜 주세요)");return}let ft=e.field.split(",").map(G=>G.trim().toLowerCase()).filter(Boolean),I=[];for(let G of tt.presentCharacters||[])for(let K of Object.keys(G.customFields||{}))I.push({owner:G.name,key:K,value:G.customFields[K]});for(let G of tt.playerStats&&tt.playerStats.customTrackerFields||[])I.push({owner:null,key:G.name,value:G.value});for(let G of tt.worldCustomFields||[])I.push({owner:null,key:G.name,value:G.value});let k=new Map;for(let G of I){let K=String(G.key||""),Q=K.toLowerCase(),$=G.value==null?"":String(G.value),nt=ft.find(bt=>Q.includes(bt));if(!nt||!$)continue;let ct=G.owner;if(!ct){let bt=Q.indexOf(nt);ct=d(K.slice(0,bt)+" "+K.slice(bt+nt.length))}ct&&k.set(ct,(k.get(ct)?k.get(ct)+". ":"")+$)}for(let[G,K]of k){if(C.get(G)===K)continue;if(C.set(G,K),!l.chars.some(nt=>nt.def.name===G))if(e.autoAdd&&l.addByName(G))u("섬에 "+G+" 추가");else{u("섬에 '"+G+"'이(가) 없어요");continue}let Q=l.interpret(K).filter(nt=>nt.action),$=Q[Q.length-1];$?(l.do(G,$.action,$.action==="intimate"?$.who.find(nt=>nt!==G&&nt!=="*"):void 0),u(G+' ← "'+K.slice(0,30)+'" → '+$.action+" ('"+$.keyword+"')"),s("tracker",G,K,$.action)):u(G+' ← "'+K.slice(0,30)+'" → 해당 행동 없음')}f("트래커 연결됨 · 필드 "+I.length+"개 중 행동 "+k.size+"명"),S&&!k.size&&u("'"+e.field+"' 단어가 들어간 필드가 없어요. 찾은 필드: "+I.map(G=>G.key).slice(0,12).join(", "))}catch(R){f("트래커 읽기 오류: "+R.message)}finally{w=!1}}}function L(){clearInterval(U),e.poll&&(U=setInterval(()=>{document.hidden||N(!1)},e.sec*1e3))}L(),setTimeout(()=>N(!0),1500);function j(){clearInterval(U);try{l.destroy()}catch{}r.remove(),delete window.__pixelWorldExt}window.__pixelWorldExt={destroy:j,app:l,readTracker:N},window.marinara&&window.marinara.onCleanup&&window.marinara.onCleanup(j)})();})();
