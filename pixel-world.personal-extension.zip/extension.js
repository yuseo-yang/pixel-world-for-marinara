/* Pixel World for Marinara - bundled (three.js MIT). Source: https://github.com/yuseo-yang/pixel-world-for-marinara */
(()=>{var $i={LEFT:0,MIDDLE:1,RIGHT:2,ROTATE:0,DOLLY:1,PAN:2},Ki={ROTATE:0,PAN:1,DOLLY_PAN:2,DOLLY_ROTATE:3},Vu=0,pc=1,Gu=2;var Wh=1,Cl=2,si=3,Ti=0,pn=1,Un=2;var Zn=0,oi=1,Ds=2,mc=3,gc=4,Rl=5,ri=100,Wu=101,Xu=102,xc=103,_c=104,Pl=200,ka=201,Yu=202,qu=203,pr=204,qo=205,Zu=206,Ju=207,ju=208,$u=209,Ku=210,Qu=211,td=212,ed=213,nd=214,id=0,sd=1,rd=2,la=3,ad=4,od=5,ld=6,cd=7,Xh=0,hd=1,ud=2,wi=0,Ll=1,Il=2,Dl=3,Er=4,dd=5,Ul=6;var Yh=300,Us=301,Ns=302,Zo=303,Jo=304,Ha=306,mr=1e3,Nn=1001,jo=1002,Ye=1003,vc=1004;var go=1005;var Mn=1006,fd=1007;var Yi=1008;var Ei=1009,pd=1010,md=1011,Nl=1012,qh=1013,bi=1014,Mi=1015,xn=1016,Zh=1017,Jh=1018,Gi=1020,gd=1021,On=1023,xd=1024,_d=1025,Wi=1026,Os=1027,vd=1028,jh=1029,yd=1030,$h=1031,Kh=1033,xo=33776,_o=33777,vo=33778,yo=33779,yc=35840,bc=35841,Mc=35842,Sc=35843,Qh=36196,wc=37492,Ec=37496,Tc=37808,Ac=37809,Cc=37810,Rc=37811,Pc=37812,Lc=37813,Ic=37814,Dc=37815,Uc=37816,Nc=37817,Oc=37818,Fc=37819,Bc=37820,zc=37821,bo=36492,kc=36494,Hc=36495,bd=36283,Vc=36284,Gc=36285,Wc=36286;var ca=2300,ha=2301,Mo=2302,Xc=2400,Yc=2401,qc=2402;var tu=3e3,Xi=3001,Md=3200,Sd=3201,eu=0,wd=1,fn="",Re="srgb",li="srgb-linear",Ol="display-p3",Va="display-p3-linear",ua="linear",me="srgb",da="rec709",fa="p3";var hs=7680;var Zc=519,Ed=512,Td=513,Ad=514,nu=515,Cd=516,Rd=517,Pd=518,Ld=519,Jc=35044;var jc="300 es",$o=1035,ai=2e3,pa=2001,Jn=class{addEventListener(t,e){this._listeners===void 0&&(this._listeners={});let n=this._listeners;n[t]===void 0&&(n[t]=[]),n[t].indexOf(e)===-1&&n[t].push(e)}hasEventListener(t,e){if(this._listeners===void 0)return!1;let n=this._listeners;return n[t]!==void 0&&n[t].indexOf(e)!==-1}removeEventListener(t,e){if(this._listeners===void 0)return;let s=this._listeners[t];if(s!==void 0){let r=s.indexOf(e);r!==-1&&s.splice(r,1)}}dispatchEvent(t){if(this._listeners===void 0)return;let n=this._listeners[t.type];if(n!==void 0){t.target=this;let s=n.slice(0);for(let r=0,o=s.length;r<o;r++)s[r].call(this,t);t.target=null}}},Ke=["00","01","02","03","04","05","06","07","08","09","0a","0b","0c","0d","0e","0f","10","11","12","13","14","15","16","17","18","19","1a","1b","1c","1d","1e","1f","20","21","22","23","24","25","26","27","28","29","2a","2b","2c","2d","2e","2f","30","31","32","33","34","35","36","37","38","39","3a","3b","3c","3d","3e","3f","40","41","42","43","44","45","46","47","48","49","4a","4b","4c","4d","4e","4f","50","51","52","53","54","55","56","57","58","59","5a","5b","5c","5d","5e","5f","60","61","62","63","64","65","66","67","68","69","6a","6b","6c","6d","6e","6f","70","71","72","73","74","75","76","77","78","79","7a","7b","7c","7d","7e","7f","80","81","82","83","84","85","86","87","88","89","8a","8b","8c","8d","8e","8f","90","91","92","93","94","95","96","97","98","99","9a","9b","9c","9d","9e","9f","a0","a1","a2","a3","a4","a5","a6","a7","a8","a9","aa","ab","ac","ad","ae","af","b0","b1","b2","b3","b4","b5","b6","b7","b8","b9","ba","bb","bc","bd","be","bf","c0","c1","c2","c3","c4","c5","c6","c7","c8","c9","ca","cb","cc","cd","ce","cf","d0","d1","d2","d3","d4","d5","d6","d7","d8","d9","da","db","dc","dd","de","df","e0","e1","e2","e3","e4","e5","e6","e7","e8","e9","ea","eb","ec","ed","ee","ef","f0","f1","f2","f3","f4","f5","f6","f7","f8","f9","fa","fb","fc","fd","fe","ff"],$c=1234567,hr=Math.PI/180,gr=180/Math.PI;function Hs(){let i=Math.random()*4294967295|0,t=Math.random()*4294967295|0,e=Math.random()*4294967295|0,n=Math.random()*4294967295|0;return(Ke[i&255]+Ke[i>>8&255]+Ke[i>>16&255]+Ke[i>>24&255]+"-"+Ke[t&255]+Ke[t>>8&255]+"-"+Ke[t>>16&15|64]+Ke[t>>24&255]+"-"+Ke[e&63|128]+Ke[e>>8&255]+"-"+Ke[e>>16&255]+Ke[e>>24&255]+Ke[n&255]+Ke[n>>8&255]+Ke[n>>16&255]+Ke[n>>24&255]).toLowerCase()}function tn(i,t,e){return Math.max(t,Math.min(e,i))}function Fl(i,t){return(i%t+t)%t}function Id(i,t,e,n,s){return n+(i-t)*(s-n)/(e-t)}function Dd(i,t,e){return i!==t?(e-i)/(t-i):0}function ur(i,t,e){return(1-e)*i+e*t}function Ud(i,t,e,n){return ur(i,t,1-Math.exp(-e*n))}function Nd(i,t=1){return t-Math.abs(Fl(i,t*2)-t)}function Od(i,t,e){return i<=t?0:i>=e?1:(i=(i-t)/(e-t),i*i*(3-2*i))}function Fd(i,t,e){return i<=t?0:i>=e?1:(i=(i-t)/(e-t),i*i*i*(i*(i*6-15)+10))}function Bd(i,t){return i+Math.floor(Math.random()*(t-i+1))}function zd(i,t){return i+Math.random()*(t-i)}function kd(i){return i*(.5-Math.random())}function Hd(i){i!==void 0&&($c=i);let t=$c+=1831565813;return t=Math.imul(t^t>>>15,t|1),t^=t+Math.imul(t^t>>>7,t|61),((t^t>>>14)>>>0)/4294967296}function Vd(i){return i*hr}function Gd(i){return i*gr}function Ko(i){return(i&i-1)===0&&i!==0}function Wd(i){return Math.pow(2,Math.ceil(Math.log(i)/Math.LN2))}function ma(i){return Math.pow(2,Math.floor(Math.log(i)/Math.LN2))}function Xd(i,t,e,n,s){let r=Math.cos,o=Math.sin,a=r(e/2),l=o(e/2),h=r((t+n)/2),u=o((t+n)/2),d=r((t-n)/2),m=o((t-n)/2),x=r((n-t)/2),v=o((n-t)/2);switch(s){case"XYX":i.set(a*u,l*d,l*m,a*h);break;case"YZY":i.set(l*m,a*u,l*d,a*h);break;case"ZXZ":i.set(l*d,l*m,a*u,a*h);break;case"XZX":i.set(a*u,l*v,l*x,a*h);break;case"YXY":i.set(l*x,a*u,l*v,a*h);break;case"ZYZ":i.set(l*v,l*x,a*u,a*h);break;default:console.warn("THREE.MathUtils: .setQuaternionFromProperEuler() encountered an unknown order: "+s)}}function As(i,t){switch(t.constructor){case Float32Array:return i;case Uint32Array:return i/4294967295;case Uint16Array:return i/65535;case Uint8Array:return i/255;case Int32Array:return Math.max(i/2147483647,-1);case Int16Array:return Math.max(i/32767,-1);case Int8Array:return Math.max(i/127,-1);default:throw new Error("Invalid component type.")}}function on(i,t){switch(t.constructor){case Float32Array:return i;case Uint32Array:return Math.round(i*4294967295);case Uint16Array:return Math.round(i*65535);case Uint8Array:return Math.round(i*255);case Int32Array:return Math.round(i*2147483647);case Int16Array:return Math.round(i*32767);case Int8Array:return Math.round(i*127);default:throw new Error("Invalid component type.")}}var iu={DEG2RAD:hr,RAD2DEG:gr,generateUUID:Hs,clamp:tn,euclideanModulo:Fl,mapLinear:Id,inverseLerp:Dd,lerp:ur,damp:Ud,pingpong:Nd,smoothstep:Od,smootherstep:Fd,randInt:Bd,randFloat:zd,randFloatSpread:kd,seededRandom:Hd,degToRad:Vd,radToDeg:Gd,isPowerOfTwo:Ko,ceilPowerOfTwo:Wd,floorPowerOfTwo:ma,setQuaternionFromProperEuler:Xd,normalize:on,denormalize:As},At=class i{constructor(t=0,e=0){i.prototype.isVector2=!0,this.x=t,this.y=e}get width(){return this.x}set width(t){this.x=t}get height(){return this.y}set height(t){this.y=t}set(t,e){return this.x=t,this.y=e,this}setScalar(t){return this.x=t,this.y=t,this}setX(t){return this.x=t,this}setY(t){return this.y=t,this}setComponent(t,e){switch(t){case 0:this.x=e;break;case 1:this.y=e;break;default:throw new Error("index is out of range: "+t)}return this}getComponent(t){switch(t){case 0:return this.x;case 1:return this.y;default:throw new Error("index is out of range: "+t)}}clone(){return new this.constructor(this.x,this.y)}copy(t){return this.x=t.x,this.y=t.y,this}add(t){return this.x+=t.x,this.y+=t.y,this}addScalar(t){return this.x+=t,this.y+=t,this}addVectors(t,e){return this.x=t.x+e.x,this.y=t.y+e.y,this}addScaledVector(t,e){return this.x+=t.x*e,this.y+=t.y*e,this}sub(t){return this.x-=t.x,this.y-=t.y,this}subScalar(t){return this.x-=t,this.y-=t,this}subVectors(t,e){return this.x=t.x-e.x,this.y=t.y-e.y,this}multiply(t){return this.x*=t.x,this.y*=t.y,this}multiplyScalar(t){return this.x*=t,this.y*=t,this}divide(t){return this.x/=t.x,this.y/=t.y,this}divideScalar(t){return this.multiplyScalar(1/t)}applyMatrix3(t){let e=this.x,n=this.y,s=t.elements;return this.x=s[0]*e+s[3]*n+s[6],this.y=s[1]*e+s[4]*n+s[7],this}min(t){return this.x=Math.min(this.x,t.x),this.y=Math.min(this.y,t.y),this}max(t){return this.x=Math.max(this.x,t.x),this.y=Math.max(this.y,t.y),this}clamp(t,e){return this.x=Math.max(t.x,Math.min(e.x,this.x)),this.y=Math.max(t.y,Math.min(e.y,this.y)),this}clampScalar(t,e){return this.x=Math.max(t,Math.min(e,this.x)),this.y=Math.max(t,Math.min(e,this.y)),this}clampLength(t,e){let n=this.length();return this.divideScalar(n||1).multiplyScalar(Math.max(t,Math.min(e,n)))}floor(){return this.x=Math.floor(this.x),this.y=Math.floor(this.y),this}ceil(){return this.x=Math.ceil(this.x),this.y=Math.ceil(this.y),this}round(){return this.x=Math.round(this.x),this.y=Math.round(this.y),this}roundToZero(){return this.x=Math.trunc(this.x),this.y=Math.trunc(this.y),this}negate(){return this.x=-this.x,this.y=-this.y,this}dot(t){return this.x*t.x+this.y*t.y}cross(t){return this.x*t.y-this.y*t.x}lengthSq(){return this.x*this.x+this.y*this.y}length(){return Math.sqrt(this.x*this.x+this.y*this.y)}manhattanLength(){return Math.abs(this.x)+Math.abs(this.y)}normalize(){return this.divideScalar(this.length()||1)}angle(){return Math.atan2(-this.y,-this.x)+Math.PI}angleTo(t){let e=Math.sqrt(this.lengthSq()*t.lengthSq());if(e===0)return Math.PI/2;let n=this.dot(t)/e;return Math.acos(tn(n,-1,1))}distanceTo(t){return Math.sqrt(this.distanceToSquared(t))}distanceToSquared(t){let e=this.x-t.x,n=this.y-t.y;return e*e+n*n}manhattanDistanceTo(t){return Math.abs(this.x-t.x)+Math.abs(this.y-t.y)}setLength(t){return this.normalize().multiplyScalar(t)}lerp(t,e){return this.x+=(t.x-this.x)*e,this.y+=(t.y-this.y)*e,this}lerpVectors(t,e,n){return this.x=t.x+(e.x-t.x)*n,this.y=t.y+(e.y-t.y)*n,this}equals(t){return t.x===this.x&&t.y===this.y}fromArray(t,e=0){return this.x=t[e],this.y=t[e+1],this}toArray(t=[],e=0){return t[e]=this.x,t[e+1]=this.y,t}fromBufferAttribute(t,e){return this.x=t.getX(e),this.y=t.getY(e),this}rotateAround(t,e){let n=Math.cos(e),s=Math.sin(e),r=this.x-t.x,o=this.y-t.y;return this.x=r*n-o*s+t.x,this.y=r*s+o*n+t.y,this}random(){return this.x=Math.random(),this.y=Math.random(),this}*[Symbol.iterator](){yield this.x,yield this.y}},se=class i{constructor(t,e,n,s,r,o,a,l,h){i.prototype.isMatrix3=!0,this.elements=[1,0,0,0,1,0,0,0,1],t!==void 0&&this.set(t,e,n,s,r,o,a,l,h)}set(t,e,n,s,r,o,a,l,h){let u=this.elements;return u[0]=t,u[1]=s,u[2]=a,u[3]=e,u[4]=r,u[5]=l,u[6]=n,u[7]=o,u[8]=h,this}identity(){return this.set(1,0,0,0,1,0,0,0,1),this}copy(t){let e=this.elements,n=t.elements;return e[0]=n[0],e[1]=n[1],e[2]=n[2],e[3]=n[3],e[4]=n[4],e[5]=n[5],e[6]=n[6],e[7]=n[7],e[8]=n[8],this}extractBasis(t,e,n){return t.setFromMatrix3Column(this,0),e.setFromMatrix3Column(this,1),n.setFromMatrix3Column(this,2),this}setFromMatrix4(t){let e=t.elements;return this.set(e[0],e[4],e[8],e[1],e[5],e[9],e[2],e[6],e[10]),this}multiply(t){return this.multiplyMatrices(this,t)}premultiply(t){return this.multiplyMatrices(t,this)}multiplyMatrices(t,e){let n=t.elements,s=e.elements,r=this.elements,o=n[0],a=n[3],l=n[6],h=n[1],u=n[4],d=n[7],m=n[2],x=n[5],v=n[8],M=s[0],g=s[3],f=s[6],R=s[1],E=s[4],L=s[7],z=s[2],N=s[5],I=s[8];return r[0]=o*M+a*R+l*z,r[3]=o*g+a*E+l*N,r[6]=o*f+a*L+l*I,r[1]=h*M+u*R+d*z,r[4]=h*g+u*E+d*N,r[7]=h*f+u*L+d*I,r[2]=m*M+x*R+v*z,r[5]=m*g+x*E+v*N,r[8]=m*f+x*L+v*I,this}multiplyScalar(t){let e=this.elements;return e[0]*=t,e[3]*=t,e[6]*=t,e[1]*=t,e[4]*=t,e[7]*=t,e[2]*=t,e[5]*=t,e[8]*=t,this}determinant(){let t=this.elements,e=t[0],n=t[1],s=t[2],r=t[3],o=t[4],a=t[5],l=t[6],h=t[7],u=t[8];return e*o*u-e*a*h-n*r*u+n*a*l+s*r*h-s*o*l}invert(){let t=this.elements,e=t[0],n=t[1],s=t[2],r=t[3],o=t[4],a=t[5],l=t[6],h=t[7],u=t[8],d=u*o-a*h,m=a*l-u*r,x=h*r-o*l,v=e*d+n*m+s*x;if(v===0)return this.set(0,0,0,0,0,0,0,0,0);let M=1/v;return t[0]=d*M,t[1]=(s*h-u*n)*M,t[2]=(a*n-s*o)*M,t[3]=m*M,t[4]=(u*e-s*l)*M,t[5]=(s*r-a*e)*M,t[6]=x*M,t[7]=(n*l-h*e)*M,t[8]=(o*e-n*r)*M,this}transpose(){let t,e=this.elements;return t=e[1],e[1]=e[3],e[3]=t,t=e[2],e[2]=e[6],e[6]=t,t=e[5],e[5]=e[7],e[7]=t,this}getNormalMatrix(t){return this.setFromMatrix4(t).invert().transpose()}transposeIntoArray(t){let e=this.elements;return t[0]=e[0],t[1]=e[3],t[2]=e[6],t[3]=e[1],t[4]=e[4],t[5]=e[7],t[6]=e[2],t[7]=e[5],t[8]=e[8],this}setUvTransform(t,e,n,s,r,o,a){let l=Math.cos(r),h=Math.sin(r);return this.set(n*l,n*h,-n*(l*o+h*a)+o+t,-s*h,s*l,-s*(-h*o+l*a)+a+e,0,0,1),this}scale(t,e){return this.premultiply(So.makeScale(t,e)),this}rotate(t){return this.premultiply(So.makeRotation(-t)),this}translate(t,e){return this.premultiply(So.makeTranslation(t,e)),this}makeTranslation(t,e){return t.isVector2?this.set(1,0,t.x,0,1,t.y,0,0,1):this.set(1,0,t,0,1,e,0,0,1),this}makeRotation(t){let e=Math.cos(t),n=Math.sin(t);return this.set(e,-n,0,n,e,0,0,0,1),this}makeScale(t,e){return this.set(t,0,0,0,e,0,0,0,1),this}equals(t){let e=this.elements,n=t.elements;for(let s=0;s<9;s++)if(e[s]!==n[s])return!1;return!0}fromArray(t,e=0){for(let n=0;n<9;n++)this.elements[n]=t[n+e];return this}toArray(t=[],e=0){let n=this.elements;return t[e]=n[0],t[e+1]=n[1],t[e+2]=n[2],t[e+3]=n[3],t[e+4]=n[4],t[e+5]=n[5],t[e+6]=n[6],t[e+7]=n[7],t[e+8]=n[8],t}clone(){return new this.constructor().fromArray(this.elements)}},So=new se;function su(i){for(let t=i.length-1;t>=0;--t)if(i[t]>=65535)return!0;return!1}function ga(i){return document.createElementNS("http://www.w3.org/1999/xhtml",i)}function Yd(){let i=ga("canvas");return i.style.display="block",i}var Kc={};function dr(i){i in Kc||(Kc[i]=!0,console.warn(i))}var Qc=new se().set(.8224621,.177538,0,.0331941,.9668058,0,.0170827,.0723974,.9105199),th=new se().set(1.2249401,-.2249404,0,-.0420569,1.0420571,0,-.0196376,-.0786361,1.0982735),Or={[li]:{transfer:ua,primaries:da,toReference:i=>i,fromReference:i=>i},[Re]:{transfer:me,primaries:da,toReference:i=>i.convertSRGBToLinear(),fromReference:i=>i.convertLinearToSRGB()},[Va]:{transfer:ua,primaries:fa,toReference:i=>i.applyMatrix3(th),fromReference:i=>i.applyMatrix3(Qc)},[Ol]:{transfer:me,primaries:fa,toReference:i=>i.convertSRGBToLinear().applyMatrix3(th),fromReference:i=>i.applyMatrix3(Qc).convertLinearToSRGB()}},qd=new Set([li,Va]),fe={enabled:!0,_workingColorSpace:li,get workingColorSpace(){return this._workingColorSpace},set workingColorSpace(i){if(!qd.has(i))throw new Error(`Unsupported working color space, "${i}".`);this._workingColorSpace=i},convert:function(i,t,e){if(this.enabled===!1||t===e||!t||!e)return i;let n=Or[t].toReference,s=Or[e].fromReference;return s(n(i))},fromWorkingColorSpace:function(i,t){return this.convert(i,this._workingColorSpace,t)},toWorkingColorSpace:function(i,t){return this.convert(i,t,this._workingColorSpace)},getPrimaries:function(i){return Or[i].primaries},getTransfer:function(i){return i===fn?ua:Or[i].transfer}};function Ls(i){return i<.04045?i*.0773993808:Math.pow(i*.9478672986+.0521327014,2.4)}function wo(i){return i<.0031308?i*12.92:1.055*Math.pow(i,.41666)-.055}var us,xa=class{static getDataURL(t){if(/^data:/i.test(t.src)||typeof HTMLCanvasElement>"u")return t.src;let e;if(t instanceof HTMLCanvasElement)e=t;else{us===void 0&&(us=ga("canvas")),us.width=t.width,us.height=t.height;let n=us.getContext("2d");t instanceof ImageData?n.putImageData(t,0,0):n.drawImage(t,0,0,t.width,t.height),e=us}return e.width>2048||e.height>2048?(console.warn("THREE.ImageUtils.getDataURL: Image converted to jpg for performance reasons",t),e.toDataURL("image/jpeg",.6)):e.toDataURL("image/png")}static sRGBToLinear(t){if(typeof HTMLImageElement<"u"&&t instanceof HTMLImageElement||typeof HTMLCanvasElement<"u"&&t instanceof HTMLCanvasElement||typeof ImageBitmap<"u"&&t instanceof ImageBitmap){let e=ga("canvas");e.width=t.width,e.height=t.height;let n=e.getContext("2d");n.drawImage(t,0,0,t.width,t.height);let s=n.getImageData(0,0,t.width,t.height),r=s.data;for(let o=0;o<r.length;o++)r[o]=Ls(r[o]/255)*255;return n.putImageData(s,0,0),e}else if(t.data){let e=t.data.slice(0);for(let n=0;n<e.length;n++)e instanceof Uint8Array||e instanceof Uint8ClampedArray?e[n]=Math.floor(Ls(e[n]/255)*255):e[n]=Ls(e[n]);return{data:e,width:t.width,height:t.height}}else return console.warn("THREE.ImageUtils.sRGBToLinear(): Unsupported image type. No color space conversion applied."),t}},Zd=0,_a=class{constructor(t=null){this.isSource=!0,Object.defineProperty(this,"id",{value:Zd++}),this.uuid=Hs(),this.data=t,this.version=0}set needsUpdate(t){t===!0&&this.version++}toJSON(t){let e=t===void 0||typeof t=="string";if(!e&&t.images[this.uuid]!==void 0)return t.images[this.uuid];let n={uuid:this.uuid,url:""},s=this.data;if(s!==null){let r;if(Array.isArray(s)){r=[];for(let o=0,a=s.length;o<a;o++)s[o].isDataTexture?r.push(Eo(s[o].image)):r.push(Eo(s[o]))}else r=Eo(s);n.url=r}return e||(t.images[this.uuid]=n),n}};function Eo(i){return typeof HTMLImageElement<"u"&&i instanceof HTMLImageElement||typeof HTMLCanvasElement<"u"&&i instanceof HTMLCanvasElement||typeof ImageBitmap<"u"&&i instanceof ImageBitmap?xa.getDataURL(i):i.data?{data:Array.from(i.data),width:i.width,height:i.height,type:i.data.constructor.name}:(console.warn("THREE.Texture: Unable to serialize Texture."),{})}var Jd=0,Sn=class i extends Jn{constructor(t=i.DEFAULT_IMAGE,e=i.DEFAULT_MAPPING,n=Nn,s=Nn,r=Mn,o=Yi,a=On,l=Ei,h=i.DEFAULT_ANISOTROPY,u=fn){super(),this.isTexture=!0,Object.defineProperty(this,"id",{value:Jd++}),this.uuid=Hs(),this.name="",this.source=new _a(t),this.mipmaps=[],this.mapping=e,this.channel=0,this.wrapS=n,this.wrapT=s,this.magFilter=r,this.minFilter=o,this.anisotropy=h,this.format=a,this.internalFormat=null,this.type=l,this.offset=new At(0,0),this.repeat=new At(1,1),this.center=new At(0,0),this.rotation=0,this.matrixAutoUpdate=!0,this.matrix=new se,this.generateMipmaps=!0,this.premultiplyAlpha=!1,this.flipY=!0,this.unpackAlignment=4,typeof u=="string"?this.colorSpace=u:(dr("THREE.Texture: Property .encoding has been replaced by .colorSpace."),this.colorSpace=u===Xi?Re:fn),this.userData={},this.version=0,this.onUpdate=null,this.isRenderTargetTexture=!1,this.needsPMREMUpdate=!1}get image(){return this.source.data}set image(t=null){this.source.data=t}updateMatrix(){this.matrix.setUvTransform(this.offset.x,this.offset.y,this.repeat.x,this.repeat.y,this.rotation,this.center.x,this.center.y)}clone(){return new this.constructor().copy(this)}copy(t){return this.name=t.name,this.source=t.source,this.mipmaps=t.mipmaps.slice(0),this.mapping=t.mapping,this.channel=t.channel,this.wrapS=t.wrapS,this.wrapT=t.wrapT,this.magFilter=t.magFilter,this.minFilter=t.minFilter,this.anisotropy=t.anisotropy,this.format=t.format,this.internalFormat=t.internalFormat,this.type=t.type,this.offset.copy(t.offset),this.repeat.copy(t.repeat),this.center.copy(t.center),this.rotation=t.rotation,this.matrixAutoUpdate=t.matrixAutoUpdate,this.matrix.copy(t.matrix),this.generateMipmaps=t.generateMipmaps,this.premultiplyAlpha=t.premultiplyAlpha,this.flipY=t.flipY,this.unpackAlignment=t.unpackAlignment,this.colorSpace=t.colorSpace,this.userData=JSON.parse(JSON.stringify(t.userData)),this.needsUpdate=!0,this}toJSON(t){let e=t===void 0||typeof t=="string";if(!e&&t.textures[this.uuid]!==void 0)return t.textures[this.uuid];let n={metadata:{version:4.6,type:"Texture",generator:"Texture.toJSON"},uuid:this.uuid,name:this.name,image:this.source.toJSON(t).uuid,mapping:this.mapping,channel:this.channel,repeat:[this.repeat.x,this.repeat.y],offset:[this.offset.x,this.offset.y],center:[this.center.x,this.center.y],rotation:this.rotation,wrap:[this.wrapS,this.wrapT],format:this.format,internalFormat:this.internalFormat,type:this.type,colorSpace:this.colorSpace,minFilter:this.minFilter,magFilter:this.magFilter,anisotropy:this.anisotropy,flipY:this.flipY,generateMipmaps:this.generateMipmaps,premultiplyAlpha:this.premultiplyAlpha,unpackAlignment:this.unpackAlignment};return Object.keys(this.userData).length>0&&(n.userData=this.userData),e||(t.textures[this.uuid]=n),n}dispose(){this.dispatchEvent({type:"dispose"})}transformUv(t){if(this.mapping!==Yh)return t;if(t.applyMatrix3(this.matrix),t.x<0||t.x>1)switch(this.wrapS){case mr:t.x=t.x-Math.floor(t.x);break;case Nn:t.x=t.x<0?0:1;break;case jo:Math.abs(Math.floor(t.x)%2)===1?t.x=Math.ceil(t.x)-t.x:t.x=t.x-Math.floor(t.x);break}if(t.y<0||t.y>1)switch(this.wrapT){case mr:t.y=t.y-Math.floor(t.y);break;case Nn:t.y=t.y<0?0:1;break;case jo:Math.abs(Math.floor(t.y)%2)===1?t.y=Math.ceil(t.y)-t.y:t.y=t.y-Math.floor(t.y);break}return this.flipY&&(t.y=1-t.y),t}set needsUpdate(t){t===!0&&(this.version++,this.source.needsUpdate=!0)}get encoding(){return dr("THREE.Texture: Property .encoding has been replaced by .colorSpace."),this.colorSpace===Re?Xi:tu}set encoding(t){dr("THREE.Texture: Property .encoding has been replaced by .colorSpace."),this.colorSpace=t===Xi?Re:fn}};Sn.DEFAULT_IMAGE=null;Sn.DEFAULT_MAPPING=Yh;Sn.DEFAULT_ANISOTROPY=1;var Se=class i{constructor(t=0,e=0,n=0,s=1){i.prototype.isVector4=!0,this.x=t,this.y=e,this.z=n,this.w=s}get width(){return this.z}set width(t){this.z=t}get height(){return this.w}set height(t){this.w=t}set(t,e,n,s){return this.x=t,this.y=e,this.z=n,this.w=s,this}setScalar(t){return this.x=t,this.y=t,this.z=t,this.w=t,this}setX(t){return this.x=t,this}setY(t){return this.y=t,this}setZ(t){return this.z=t,this}setW(t){return this.w=t,this}setComponent(t,e){switch(t){case 0:this.x=e;break;case 1:this.y=e;break;case 2:this.z=e;break;case 3:this.w=e;break;default:throw new Error("index is out of range: "+t)}return this}getComponent(t){switch(t){case 0:return this.x;case 1:return this.y;case 2:return this.z;case 3:return this.w;default:throw new Error("index is out of range: "+t)}}clone(){return new this.constructor(this.x,this.y,this.z,this.w)}copy(t){return this.x=t.x,this.y=t.y,this.z=t.z,this.w=t.w!==void 0?t.w:1,this}add(t){return this.x+=t.x,this.y+=t.y,this.z+=t.z,this.w+=t.w,this}addScalar(t){return this.x+=t,this.y+=t,this.z+=t,this.w+=t,this}addVectors(t,e){return this.x=t.x+e.x,this.y=t.y+e.y,this.z=t.z+e.z,this.w=t.w+e.w,this}addScaledVector(t,e){return this.x+=t.x*e,this.y+=t.y*e,this.z+=t.z*e,this.w+=t.w*e,this}sub(t){return this.x-=t.x,this.y-=t.y,this.z-=t.z,this.w-=t.w,this}subScalar(t){return this.x-=t,this.y-=t,this.z-=t,this.w-=t,this}subVectors(t,e){return this.x=t.x-e.x,this.y=t.y-e.y,this.z=t.z-e.z,this.w=t.w-e.w,this}multiply(t){return this.x*=t.x,this.y*=t.y,this.z*=t.z,this.w*=t.w,this}multiplyScalar(t){return this.x*=t,this.y*=t,this.z*=t,this.w*=t,this}applyMatrix4(t){let e=this.x,n=this.y,s=this.z,r=this.w,o=t.elements;return this.x=o[0]*e+o[4]*n+o[8]*s+o[12]*r,this.y=o[1]*e+o[5]*n+o[9]*s+o[13]*r,this.z=o[2]*e+o[6]*n+o[10]*s+o[14]*r,this.w=o[3]*e+o[7]*n+o[11]*s+o[15]*r,this}divideScalar(t){return this.multiplyScalar(1/t)}setAxisAngleFromQuaternion(t){this.w=2*Math.acos(t.w);let e=Math.sqrt(1-t.w*t.w);return e<1e-4?(this.x=1,this.y=0,this.z=0):(this.x=t.x/e,this.y=t.y/e,this.z=t.z/e),this}setAxisAngleFromRotationMatrix(t){let e,n,s,r,l=t.elements,h=l[0],u=l[4],d=l[8],m=l[1],x=l[5],v=l[9],M=l[2],g=l[6],f=l[10];if(Math.abs(u-m)<.01&&Math.abs(d-M)<.01&&Math.abs(v-g)<.01){if(Math.abs(u+m)<.1&&Math.abs(d+M)<.1&&Math.abs(v+g)<.1&&Math.abs(h+x+f-3)<.1)return this.set(1,0,0,0),this;e=Math.PI;let E=(h+1)/2,L=(x+1)/2,z=(f+1)/2,N=(u+m)/4,I=(d+M)/4,it=(v+g)/4;return E>L&&E>z?E<.01?(n=0,s=.707106781,r=.707106781):(n=Math.sqrt(E),s=N/n,r=I/n):L>z?L<.01?(n=.707106781,s=0,r=.707106781):(s=Math.sqrt(L),n=N/s,r=it/s):z<.01?(n=.707106781,s=.707106781,r=0):(r=Math.sqrt(z),n=I/r,s=it/r),this.set(n,s,r,e),this}let R=Math.sqrt((g-v)*(g-v)+(d-M)*(d-M)+(m-u)*(m-u));return Math.abs(R)<.001&&(R=1),this.x=(g-v)/R,this.y=(d-M)/R,this.z=(m-u)/R,this.w=Math.acos((h+x+f-1)/2),this}min(t){return this.x=Math.min(this.x,t.x),this.y=Math.min(this.y,t.y),this.z=Math.min(this.z,t.z),this.w=Math.min(this.w,t.w),this}max(t){return this.x=Math.max(this.x,t.x),this.y=Math.max(this.y,t.y),this.z=Math.max(this.z,t.z),this.w=Math.max(this.w,t.w),this}clamp(t,e){return this.x=Math.max(t.x,Math.min(e.x,this.x)),this.y=Math.max(t.y,Math.min(e.y,this.y)),this.z=Math.max(t.z,Math.min(e.z,this.z)),this.w=Math.max(t.w,Math.min(e.w,this.w)),this}clampScalar(t,e){return this.x=Math.max(t,Math.min(e,this.x)),this.y=Math.max(t,Math.min(e,this.y)),this.z=Math.max(t,Math.min(e,this.z)),this.w=Math.max(t,Math.min(e,this.w)),this}clampLength(t,e){let n=this.length();return this.divideScalar(n||1).multiplyScalar(Math.max(t,Math.min(e,n)))}floor(){return this.x=Math.floor(this.x),this.y=Math.floor(this.y),this.z=Math.floor(this.z),this.w=Math.floor(this.w),this}ceil(){return this.x=Math.ceil(this.x),this.y=Math.ceil(this.y),this.z=Math.ceil(this.z),this.w=Math.ceil(this.w),this}round(){return this.x=Math.round(this.x),this.y=Math.round(this.y),this.z=Math.round(this.z),this.w=Math.round(this.w),this}roundToZero(){return this.x=Math.trunc(this.x),this.y=Math.trunc(this.y),this.z=Math.trunc(this.z),this.w=Math.trunc(this.w),this}negate(){return this.x=-this.x,this.y=-this.y,this.z=-this.z,this.w=-this.w,this}dot(t){return this.x*t.x+this.y*t.y+this.z*t.z+this.w*t.w}lengthSq(){return this.x*this.x+this.y*this.y+this.z*this.z+this.w*this.w}length(){return Math.sqrt(this.x*this.x+this.y*this.y+this.z*this.z+this.w*this.w)}manhattanLength(){return Math.abs(this.x)+Math.abs(this.y)+Math.abs(this.z)+Math.abs(this.w)}normalize(){return this.divideScalar(this.length()||1)}setLength(t){return this.normalize().multiplyScalar(t)}lerp(t,e){return this.x+=(t.x-this.x)*e,this.y+=(t.y-this.y)*e,this.z+=(t.z-this.z)*e,this.w+=(t.w-this.w)*e,this}lerpVectors(t,e,n){return this.x=t.x+(e.x-t.x)*n,this.y=t.y+(e.y-t.y)*n,this.z=t.z+(e.z-t.z)*n,this.w=t.w+(e.w-t.w)*n,this}equals(t){return t.x===this.x&&t.y===this.y&&t.z===this.z&&t.w===this.w}fromArray(t,e=0){return this.x=t[e],this.y=t[e+1],this.z=t[e+2],this.w=t[e+3],this}toArray(t=[],e=0){return t[e]=this.x,t[e+1]=this.y,t[e+2]=this.z,t[e+3]=this.w,t}fromBufferAttribute(t,e){return this.x=t.getX(e),this.y=t.getY(e),this.z=t.getZ(e),this.w=t.getW(e),this}random(){return this.x=Math.random(),this.y=Math.random(),this.z=Math.random(),this.w=Math.random(),this}*[Symbol.iterator](){yield this.x,yield this.y,yield this.z,yield this.w}},Qo=class extends Jn{constructor(t=1,e=1,n={}){super(),this.isRenderTarget=!0,this.width=t,this.height=e,this.depth=1,this.scissor=new Se(0,0,t,e),this.scissorTest=!1,this.viewport=new Se(0,0,t,e);let s={width:t,height:e,depth:1};n.encoding!==void 0&&(dr("THREE.WebGLRenderTarget: option.encoding has been replaced by option.colorSpace."),n.colorSpace=n.encoding===Xi?Re:fn),n=Object.assign({generateMipmaps:!1,internalFormat:null,minFilter:Mn,depthBuffer:!0,stencilBuffer:!1,depthTexture:null,samples:0},n),this.texture=new Sn(s,n.mapping,n.wrapS,n.wrapT,n.magFilter,n.minFilter,n.format,n.type,n.anisotropy,n.colorSpace),this.texture.isRenderTargetTexture=!0,this.texture.flipY=!1,this.texture.generateMipmaps=n.generateMipmaps,this.texture.internalFormat=n.internalFormat,this.depthBuffer=n.depthBuffer,this.stencilBuffer=n.stencilBuffer,this.depthTexture=n.depthTexture,this.samples=n.samples}setSize(t,e,n=1){(this.width!==t||this.height!==e||this.depth!==n)&&(this.width=t,this.height=e,this.depth=n,this.texture.image.width=t,this.texture.image.height=e,this.texture.image.depth=n,this.dispose()),this.viewport.set(0,0,t,e),this.scissor.set(0,0,t,e)}clone(){return new this.constructor().copy(this)}copy(t){this.width=t.width,this.height=t.height,this.depth=t.depth,this.scissor.copy(t.scissor),this.scissorTest=t.scissorTest,this.viewport.copy(t.viewport),this.texture=t.texture.clone(),this.texture.isRenderTargetTexture=!0;let e=Object.assign({},t.texture.image);return this.texture.source=new _a(e),this.depthBuffer=t.depthBuffer,this.stencilBuffer=t.stencilBuffer,t.depthTexture!==null&&(this.depthTexture=t.depthTexture.clone()),this.samples=t.samples,this}dispose(){this.dispatchEvent({type:"dispose"})}},je=class extends Qo{constructor(t=1,e=1,n={}){super(t,e,n),this.isWebGLRenderTarget=!0}},va=class extends Sn{constructor(t=null,e=1,n=1,s=1){super(null),this.isDataArrayTexture=!0,this.image={data:t,width:e,height:n,depth:s},this.magFilter=Ye,this.minFilter=Ye,this.wrapR=Nn,this.generateMipmaps=!1,this.flipY=!1,this.unpackAlignment=1}};var tl=class extends Sn{constructor(t=null,e=1,n=1,s=1){super(null),this.isData3DTexture=!0,this.image={data:t,width:e,height:n,depth:s},this.magFilter=Ye,this.minFilter=Ye,this.wrapR=Nn,this.generateMipmaps=!1,this.flipY=!1,this.unpackAlignment=1}};var Fn=class{constructor(t=0,e=0,n=0,s=1){this.isQuaternion=!0,this._x=t,this._y=e,this._z=n,this._w=s}static slerpFlat(t,e,n,s,r,o,a){let l=n[s+0],h=n[s+1],u=n[s+2],d=n[s+3],m=r[o+0],x=r[o+1],v=r[o+2],M=r[o+3];if(a===0){t[e+0]=l,t[e+1]=h,t[e+2]=u,t[e+3]=d;return}if(a===1){t[e+0]=m,t[e+1]=x,t[e+2]=v,t[e+3]=M;return}if(d!==M||l!==m||h!==x||u!==v){let g=1-a,f=l*m+h*x+u*v+d*M,R=f>=0?1:-1,E=1-f*f;if(E>Number.EPSILON){let z=Math.sqrt(E),N=Math.atan2(z,f*R);g=Math.sin(g*N)/z,a=Math.sin(a*N)/z}let L=a*R;if(l=l*g+m*L,h=h*g+x*L,u=u*g+v*L,d=d*g+M*L,g===1-a){let z=1/Math.sqrt(l*l+h*h+u*u+d*d);l*=z,h*=z,u*=z,d*=z}}t[e]=l,t[e+1]=h,t[e+2]=u,t[e+3]=d}static multiplyQuaternionsFlat(t,e,n,s,r,o){let a=n[s],l=n[s+1],h=n[s+2],u=n[s+3],d=r[o],m=r[o+1],x=r[o+2],v=r[o+3];return t[e]=a*v+u*d+l*x-h*m,t[e+1]=l*v+u*m+h*d-a*x,t[e+2]=h*v+u*x+a*m-l*d,t[e+3]=u*v-a*d-l*m-h*x,t}get x(){return this._x}set x(t){this._x=t,this._onChangeCallback()}get y(){return this._y}set y(t){this._y=t,this._onChangeCallback()}get z(){return this._z}set z(t){this._z=t,this._onChangeCallback()}get w(){return this._w}set w(t){this._w=t,this._onChangeCallback()}set(t,e,n,s){return this._x=t,this._y=e,this._z=n,this._w=s,this._onChangeCallback(),this}clone(){return new this.constructor(this._x,this._y,this._z,this._w)}copy(t){return this._x=t.x,this._y=t.y,this._z=t.z,this._w=t.w,this._onChangeCallback(),this}setFromEuler(t,e=!0){let n=t._x,s=t._y,r=t._z,o=t._order,a=Math.cos,l=Math.sin,h=a(n/2),u=a(s/2),d=a(r/2),m=l(n/2),x=l(s/2),v=l(r/2);switch(o){case"XYZ":this._x=m*u*d+h*x*v,this._y=h*x*d-m*u*v,this._z=h*u*v+m*x*d,this._w=h*u*d-m*x*v;break;case"YXZ":this._x=m*u*d+h*x*v,this._y=h*x*d-m*u*v,this._z=h*u*v-m*x*d,this._w=h*u*d+m*x*v;break;case"ZXY":this._x=m*u*d-h*x*v,this._y=h*x*d+m*u*v,this._z=h*u*v+m*x*d,this._w=h*u*d-m*x*v;break;case"ZYX":this._x=m*u*d-h*x*v,this._y=h*x*d+m*u*v,this._z=h*u*v-m*x*d,this._w=h*u*d+m*x*v;break;case"YZX":this._x=m*u*d+h*x*v,this._y=h*x*d+m*u*v,this._z=h*u*v-m*x*d,this._w=h*u*d-m*x*v;break;case"XZY":this._x=m*u*d-h*x*v,this._y=h*x*d-m*u*v,this._z=h*u*v+m*x*d,this._w=h*u*d+m*x*v;break;default:console.warn("THREE.Quaternion: .setFromEuler() encountered an unknown order: "+o)}return e===!0&&this._onChangeCallback(),this}setFromAxisAngle(t,e){let n=e/2,s=Math.sin(n);return this._x=t.x*s,this._y=t.y*s,this._z=t.z*s,this._w=Math.cos(n),this._onChangeCallback(),this}setFromRotationMatrix(t){let e=t.elements,n=e[0],s=e[4],r=e[8],o=e[1],a=e[5],l=e[9],h=e[2],u=e[6],d=e[10],m=n+a+d;if(m>0){let x=.5/Math.sqrt(m+1);this._w=.25/x,this._x=(u-l)*x,this._y=(r-h)*x,this._z=(o-s)*x}else if(n>a&&n>d){let x=2*Math.sqrt(1+n-a-d);this._w=(u-l)/x,this._x=.25*x,this._y=(s+o)/x,this._z=(r+h)/x}else if(a>d){let x=2*Math.sqrt(1+a-n-d);this._w=(r-h)/x,this._x=(s+o)/x,this._y=.25*x,this._z=(l+u)/x}else{let x=2*Math.sqrt(1+d-n-a);this._w=(o-s)/x,this._x=(r+h)/x,this._y=(l+u)/x,this._z=.25*x}return this._onChangeCallback(),this}setFromUnitVectors(t,e){let n=t.dot(e)+1;return n<Number.EPSILON?(n=0,Math.abs(t.x)>Math.abs(t.z)?(this._x=-t.y,this._y=t.x,this._z=0,this._w=n):(this._x=0,this._y=-t.z,this._z=t.y,this._w=n)):(this._x=t.y*e.z-t.z*e.y,this._y=t.z*e.x-t.x*e.z,this._z=t.x*e.y-t.y*e.x,this._w=n),this.normalize()}angleTo(t){return 2*Math.acos(Math.abs(tn(this.dot(t),-1,1)))}rotateTowards(t,e){let n=this.angleTo(t);if(n===0)return this;let s=Math.min(1,e/n);return this.slerp(t,s),this}identity(){return this.set(0,0,0,1)}invert(){return this.conjugate()}conjugate(){return this._x*=-1,this._y*=-1,this._z*=-1,this._onChangeCallback(),this}dot(t){return this._x*t._x+this._y*t._y+this._z*t._z+this._w*t._w}lengthSq(){return this._x*this._x+this._y*this._y+this._z*this._z+this._w*this._w}length(){return Math.sqrt(this._x*this._x+this._y*this._y+this._z*this._z+this._w*this._w)}normalize(){let t=this.length();return t===0?(this._x=0,this._y=0,this._z=0,this._w=1):(t=1/t,this._x=this._x*t,this._y=this._y*t,this._z=this._z*t,this._w=this._w*t),this._onChangeCallback(),this}multiply(t){return this.multiplyQuaternions(this,t)}premultiply(t){return this.multiplyQuaternions(t,this)}multiplyQuaternions(t,e){let n=t._x,s=t._y,r=t._z,o=t._w,a=e._x,l=e._y,h=e._z,u=e._w;return this._x=n*u+o*a+s*h-r*l,this._y=s*u+o*l+r*a-n*h,this._z=r*u+o*h+n*l-s*a,this._w=o*u-n*a-s*l-r*h,this._onChangeCallback(),this}slerp(t,e){if(e===0)return this;if(e===1)return this.copy(t);let n=this._x,s=this._y,r=this._z,o=this._w,a=o*t._w+n*t._x+s*t._y+r*t._z;if(a<0?(this._w=-t._w,this._x=-t._x,this._y=-t._y,this._z=-t._z,a=-a):this.copy(t),a>=1)return this._w=o,this._x=n,this._y=s,this._z=r,this;let l=1-a*a;if(l<=Number.EPSILON){let x=1-e;return this._w=x*o+e*this._w,this._x=x*n+e*this._x,this._y=x*s+e*this._y,this._z=x*r+e*this._z,this.normalize(),this}let h=Math.sqrt(l),u=Math.atan2(h,a),d=Math.sin((1-e)*u)/h,m=Math.sin(e*u)/h;return this._w=o*d+this._w*m,this._x=n*d+this._x*m,this._y=s*d+this._y*m,this._z=r*d+this._z*m,this._onChangeCallback(),this}slerpQuaternions(t,e,n){return this.copy(t).slerp(e,n)}random(){let t=Math.random(),e=Math.sqrt(1-t),n=Math.sqrt(t),s=2*Math.PI*Math.random(),r=2*Math.PI*Math.random();return this.set(e*Math.cos(s),n*Math.sin(r),n*Math.cos(r),e*Math.sin(s))}equals(t){return t._x===this._x&&t._y===this._y&&t._z===this._z&&t._w===this._w}fromArray(t,e=0){return this._x=t[e],this._y=t[e+1],this._z=t[e+2],this._w=t[e+3],this._onChangeCallback(),this}toArray(t=[],e=0){return t[e]=this._x,t[e+1]=this._y,t[e+2]=this._z,t[e+3]=this._w,t}fromBufferAttribute(t,e){return this._x=t.getX(e),this._y=t.getY(e),this._z=t.getZ(e),this._w=t.getW(e),this._onChangeCallback(),this}toJSON(){return this.toArray()}_onChange(t){return this._onChangeCallback=t,this}_onChangeCallback(){}*[Symbol.iterator](){yield this._x,yield this._y,yield this._z,yield this._w}},B=class i{constructor(t=0,e=0,n=0){i.prototype.isVector3=!0,this.x=t,this.y=e,this.z=n}set(t,e,n){return n===void 0&&(n=this.z),this.x=t,this.y=e,this.z=n,this}setScalar(t){return this.x=t,this.y=t,this.z=t,this}setX(t){return this.x=t,this}setY(t){return this.y=t,this}setZ(t){return this.z=t,this}setComponent(t,e){switch(t){case 0:this.x=e;break;case 1:this.y=e;break;case 2:this.z=e;break;default:throw new Error("index is out of range: "+t)}return this}getComponent(t){switch(t){case 0:return this.x;case 1:return this.y;case 2:return this.z;default:throw new Error("index is out of range: "+t)}}clone(){return new this.constructor(this.x,this.y,this.z)}copy(t){return this.x=t.x,this.y=t.y,this.z=t.z,this}add(t){return this.x+=t.x,this.y+=t.y,this.z+=t.z,this}addScalar(t){return this.x+=t,this.y+=t,this.z+=t,this}addVectors(t,e){return this.x=t.x+e.x,this.y=t.y+e.y,this.z=t.z+e.z,this}addScaledVector(t,e){return this.x+=t.x*e,this.y+=t.y*e,this.z+=t.z*e,this}sub(t){return this.x-=t.x,this.y-=t.y,this.z-=t.z,this}subScalar(t){return this.x-=t,this.y-=t,this.z-=t,this}subVectors(t,e){return this.x=t.x-e.x,this.y=t.y-e.y,this.z=t.z-e.z,this}multiply(t){return this.x*=t.x,this.y*=t.y,this.z*=t.z,this}multiplyScalar(t){return this.x*=t,this.y*=t,this.z*=t,this}multiplyVectors(t,e){return this.x=t.x*e.x,this.y=t.y*e.y,this.z=t.z*e.z,this}applyEuler(t){return this.applyQuaternion(eh.setFromEuler(t))}applyAxisAngle(t,e){return this.applyQuaternion(eh.setFromAxisAngle(t,e))}applyMatrix3(t){let e=this.x,n=this.y,s=this.z,r=t.elements;return this.x=r[0]*e+r[3]*n+r[6]*s,this.y=r[1]*e+r[4]*n+r[7]*s,this.z=r[2]*e+r[5]*n+r[8]*s,this}applyNormalMatrix(t){return this.applyMatrix3(t).normalize()}applyMatrix4(t){let e=this.x,n=this.y,s=this.z,r=t.elements,o=1/(r[3]*e+r[7]*n+r[11]*s+r[15]);return this.x=(r[0]*e+r[4]*n+r[8]*s+r[12])*o,this.y=(r[1]*e+r[5]*n+r[9]*s+r[13])*o,this.z=(r[2]*e+r[6]*n+r[10]*s+r[14])*o,this}applyQuaternion(t){let e=this.x,n=this.y,s=this.z,r=t.x,o=t.y,a=t.z,l=t.w,h=2*(o*s-a*n),u=2*(a*e-r*s),d=2*(r*n-o*e);return this.x=e+l*h+o*d-a*u,this.y=n+l*u+a*h-r*d,this.z=s+l*d+r*u-o*h,this}project(t){return this.applyMatrix4(t.matrixWorldInverse).applyMatrix4(t.projectionMatrix)}unproject(t){return this.applyMatrix4(t.projectionMatrixInverse).applyMatrix4(t.matrixWorld)}transformDirection(t){let e=this.x,n=this.y,s=this.z,r=t.elements;return this.x=r[0]*e+r[4]*n+r[8]*s,this.y=r[1]*e+r[5]*n+r[9]*s,this.z=r[2]*e+r[6]*n+r[10]*s,this.normalize()}divide(t){return this.x/=t.x,this.y/=t.y,this.z/=t.z,this}divideScalar(t){return this.multiplyScalar(1/t)}min(t){return this.x=Math.min(this.x,t.x),this.y=Math.min(this.y,t.y),this.z=Math.min(this.z,t.z),this}max(t){return this.x=Math.max(this.x,t.x),this.y=Math.max(this.y,t.y),this.z=Math.max(this.z,t.z),this}clamp(t,e){return this.x=Math.max(t.x,Math.min(e.x,this.x)),this.y=Math.max(t.y,Math.min(e.y,this.y)),this.z=Math.max(t.z,Math.min(e.z,this.z)),this}clampScalar(t,e){return this.x=Math.max(t,Math.min(e,this.x)),this.y=Math.max(t,Math.min(e,this.y)),this.z=Math.max(t,Math.min(e,this.z)),this}clampLength(t,e){let n=this.length();return this.divideScalar(n||1).multiplyScalar(Math.max(t,Math.min(e,n)))}floor(){return this.x=Math.floor(this.x),this.y=Math.floor(this.y),this.z=Math.floor(this.z),this}ceil(){return this.x=Math.ceil(this.x),this.y=Math.ceil(this.y),this.z=Math.ceil(this.z),this}round(){return this.x=Math.round(this.x),this.y=Math.round(this.y),this.z=Math.round(this.z),this}roundToZero(){return this.x=Math.trunc(this.x),this.y=Math.trunc(this.y),this.z=Math.trunc(this.z),this}negate(){return this.x=-this.x,this.y=-this.y,this.z=-this.z,this}dot(t){return this.x*t.x+this.y*t.y+this.z*t.z}lengthSq(){return this.x*this.x+this.y*this.y+this.z*this.z}length(){return Math.sqrt(this.x*this.x+this.y*this.y+this.z*this.z)}manhattanLength(){return Math.abs(this.x)+Math.abs(this.y)+Math.abs(this.z)}normalize(){return this.divideScalar(this.length()||1)}setLength(t){return this.normalize().multiplyScalar(t)}lerp(t,e){return this.x+=(t.x-this.x)*e,this.y+=(t.y-this.y)*e,this.z+=(t.z-this.z)*e,this}lerpVectors(t,e,n){return this.x=t.x+(e.x-t.x)*n,this.y=t.y+(e.y-t.y)*n,this.z=t.z+(e.z-t.z)*n,this}cross(t){return this.crossVectors(this,t)}crossVectors(t,e){let n=t.x,s=t.y,r=t.z,o=e.x,a=e.y,l=e.z;return this.x=s*l-r*a,this.y=r*o-n*l,this.z=n*a-s*o,this}projectOnVector(t){let e=t.lengthSq();if(e===0)return this.set(0,0,0);let n=t.dot(this)/e;return this.copy(t).multiplyScalar(n)}projectOnPlane(t){return To.copy(this).projectOnVector(t),this.sub(To)}reflect(t){return this.sub(To.copy(t).multiplyScalar(2*this.dot(t)))}angleTo(t){let e=Math.sqrt(this.lengthSq()*t.lengthSq());if(e===0)return Math.PI/2;let n=this.dot(t)/e;return Math.acos(tn(n,-1,1))}distanceTo(t){return Math.sqrt(this.distanceToSquared(t))}distanceToSquared(t){let e=this.x-t.x,n=this.y-t.y,s=this.z-t.z;return e*e+n*n+s*s}manhattanDistanceTo(t){return Math.abs(this.x-t.x)+Math.abs(this.y-t.y)+Math.abs(this.z-t.z)}setFromSpherical(t){return this.setFromSphericalCoords(t.radius,t.phi,t.theta)}setFromSphericalCoords(t,e,n){let s=Math.sin(e)*t;return this.x=s*Math.sin(n),this.y=Math.cos(e)*t,this.z=s*Math.cos(n),this}setFromCylindrical(t){return this.setFromCylindricalCoords(t.radius,t.theta,t.y)}setFromCylindricalCoords(t,e,n){return this.x=t*Math.sin(e),this.y=n,this.z=t*Math.cos(e),this}setFromMatrixPosition(t){let e=t.elements;return this.x=e[12],this.y=e[13],this.z=e[14],this}setFromMatrixScale(t){let e=this.setFromMatrixColumn(t,0).length(),n=this.setFromMatrixColumn(t,1).length(),s=this.setFromMatrixColumn(t,2).length();return this.x=e,this.y=n,this.z=s,this}setFromMatrixColumn(t,e){return this.fromArray(t.elements,e*4)}setFromMatrix3Column(t,e){return this.fromArray(t.elements,e*3)}setFromEuler(t){return this.x=t._x,this.y=t._y,this.z=t._z,this}setFromColor(t){return this.x=t.r,this.y=t.g,this.z=t.b,this}equals(t){return t.x===this.x&&t.y===this.y&&t.z===this.z}fromArray(t,e=0){return this.x=t[e],this.y=t[e+1],this.z=t[e+2],this}toArray(t=[],e=0){return t[e]=this.x,t[e+1]=this.y,t[e+2]=this.z,t}fromBufferAttribute(t,e){return this.x=t.getX(e),this.y=t.getY(e),this.z=t.getZ(e),this}random(){return this.x=Math.random(),this.y=Math.random(),this.z=Math.random(),this}randomDirection(){let t=(Math.random()-.5)*2,e=Math.random()*Math.PI*2,n=Math.sqrt(1-t**2);return this.x=n*Math.cos(e),this.y=n*Math.sin(e),this.z=t,this}*[Symbol.iterator](){yield this.x,yield this.y,yield this.z}},To=new B,eh=new Fn,ci=class{constructor(t=new B(1/0,1/0,1/0),e=new B(-1/0,-1/0,-1/0)){this.isBox3=!0,this.min=t,this.max=e}set(t,e){return this.min.copy(t),this.max.copy(e),this}setFromArray(t){this.makeEmpty();for(let e=0,n=t.length;e<n;e+=3)this.expandByPoint(Pn.fromArray(t,e));return this}setFromBufferAttribute(t){this.makeEmpty();for(let e=0,n=t.count;e<n;e++)this.expandByPoint(Pn.fromBufferAttribute(t,e));return this}setFromPoints(t){this.makeEmpty();for(let e=0,n=t.length;e<n;e++)this.expandByPoint(t[e]);return this}setFromCenterAndSize(t,e){let n=Pn.copy(e).multiplyScalar(.5);return this.min.copy(t).sub(n),this.max.copy(t).add(n),this}setFromObject(t,e=!1){return this.makeEmpty(),this.expandByObject(t,e)}clone(){return new this.constructor().copy(this)}copy(t){return this.min.copy(t.min),this.max.copy(t.max),this}makeEmpty(){return this.min.x=this.min.y=this.min.z=1/0,this.max.x=this.max.y=this.max.z=-1/0,this}isEmpty(){return this.max.x<this.min.x||this.max.y<this.min.y||this.max.z<this.min.z}getCenter(t){return this.isEmpty()?t.set(0,0,0):t.addVectors(this.min,this.max).multiplyScalar(.5)}getSize(t){return this.isEmpty()?t.set(0,0,0):t.subVectors(this.max,this.min)}expandByPoint(t){return this.min.min(t),this.max.max(t),this}expandByVector(t){return this.min.sub(t),this.max.add(t),this}expandByScalar(t){return this.min.addScalar(-t),this.max.addScalar(t),this}expandByObject(t,e=!1){t.updateWorldMatrix(!1,!1);let n=t.geometry;if(n!==void 0){let r=n.getAttribute("position");if(e===!0&&r!==void 0&&t.isInstancedMesh!==!0)for(let o=0,a=r.count;o<a;o++)t.isMesh===!0?t.getVertexPosition(o,Pn):Pn.fromBufferAttribute(r,o),Pn.applyMatrix4(t.matrixWorld),this.expandByPoint(Pn);else t.boundingBox!==void 0?(t.boundingBox===null&&t.computeBoundingBox(),Fr.copy(t.boundingBox)):(n.boundingBox===null&&n.computeBoundingBox(),Fr.copy(n.boundingBox)),Fr.applyMatrix4(t.matrixWorld),this.union(Fr)}let s=t.children;for(let r=0,o=s.length;r<o;r++)this.expandByObject(s[r],e);return this}containsPoint(t){return!(t.x<this.min.x||t.x>this.max.x||t.y<this.min.y||t.y>this.max.y||t.z<this.min.z||t.z>this.max.z)}containsBox(t){return this.min.x<=t.min.x&&t.max.x<=this.max.x&&this.min.y<=t.min.y&&t.max.y<=this.max.y&&this.min.z<=t.min.z&&t.max.z<=this.max.z}getParameter(t,e){return e.set((t.x-this.min.x)/(this.max.x-this.min.x),(t.y-this.min.y)/(this.max.y-this.min.y),(t.z-this.min.z)/(this.max.z-this.min.z))}intersectsBox(t){return!(t.max.x<this.min.x||t.min.x>this.max.x||t.max.y<this.min.y||t.min.y>this.max.y||t.max.z<this.min.z||t.min.z>this.max.z)}intersectsSphere(t){return this.clampPoint(t.center,Pn),Pn.distanceToSquared(t.center)<=t.radius*t.radius}intersectsPlane(t){let e,n;return t.normal.x>0?(e=t.normal.x*this.min.x,n=t.normal.x*this.max.x):(e=t.normal.x*this.max.x,n=t.normal.x*this.min.x),t.normal.y>0?(e+=t.normal.y*this.min.y,n+=t.normal.y*this.max.y):(e+=t.normal.y*this.max.y,n+=t.normal.y*this.min.y),t.normal.z>0?(e+=t.normal.z*this.min.z,n+=t.normal.z*this.max.z):(e+=t.normal.z*this.max.z,n+=t.normal.z*this.min.z),e<=-t.constant&&n>=-t.constant}intersectsTriangle(t){if(this.isEmpty())return!1;this.getCenter(ir),Br.subVectors(this.max,ir),ds.subVectors(t.a,ir),fs.subVectors(t.b,ir),ps.subVectors(t.c,ir),gi.subVectors(fs,ds),xi.subVectors(ps,fs),Fi.subVectors(ds,ps);let e=[0,-gi.z,gi.y,0,-xi.z,xi.y,0,-Fi.z,Fi.y,gi.z,0,-gi.x,xi.z,0,-xi.x,Fi.z,0,-Fi.x,-gi.y,gi.x,0,-xi.y,xi.x,0,-Fi.y,Fi.x,0];return!Ao(e,ds,fs,ps,Br)||(e=[1,0,0,0,1,0,0,0,1],!Ao(e,ds,fs,ps,Br))?!1:(zr.crossVectors(gi,xi),e=[zr.x,zr.y,zr.z],Ao(e,ds,fs,ps,Br))}clampPoint(t,e){return e.copy(t).clamp(this.min,this.max)}distanceToPoint(t){return this.clampPoint(t,Pn).distanceTo(t)}getBoundingSphere(t){return this.isEmpty()?t.makeEmpty():(this.getCenter(t.center),t.radius=this.getSize(Pn).length()*.5),t}intersect(t){return this.min.max(t.min),this.max.min(t.max),this.isEmpty()&&this.makeEmpty(),this}union(t){return this.min.min(t.min),this.max.max(t.max),this}applyMatrix4(t){return this.isEmpty()?this:(Qn[0].set(this.min.x,this.min.y,this.min.z).applyMatrix4(t),Qn[1].set(this.min.x,this.min.y,this.max.z).applyMatrix4(t),Qn[2].set(this.min.x,this.max.y,this.min.z).applyMatrix4(t),Qn[3].set(this.min.x,this.max.y,this.max.z).applyMatrix4(t),Qn[4].set(this.max.x,this.min.y,this.min.z).applyMatrix4(t),Qn[5].set(this.max.x,this.min.y,this.max.z).applyMatrix4(t),Qn[6].set(this.max.x,this.max.y,this.min.z).applyMatrix4(t),Qn[7].set(this.max.x,this.max.y,this.max.z).applyMatrix4(t),this.setFromPoints(Qn),this)}translate(t){return this.min.add(t),this.max.add(t),this}equals(t){return t.min.equals(this.min)&&t.max.equals(this.max)}},Qn=[new B,new B,new B,new B,new B,new B,new B,new B],Pn=new B,Fr=new ci,ds=new B,fs=new B,ps=new B,gi=new B,xi=new B,Fi=new B,ir=new B,Br=new B,zr=new B,Bi=new B;function Ao(i,t,e,n,s){for(let r=0,o=i.length-3;r<=o;r+=3){Bi.fromArray(i,r);let a=s.x*Math.abs(Bi.x)+s.y*Math.abs(Bi.y)+s.z*Math.abs(Bi.z),l=t.dot(Bi),h=e.dot(Bi),u=n.dot(Bi);if(Math.max(-Math.max(l,h,u),Math.min(l,h,u))>a)return!1}return!0}var jd=new ci,sr=new B,Co=new B,Ai=class{constructor(t=new B,e=-1){this.isSphere=!0,this.center=t,this.radius=e}set(t,e){return this.center.copy(t),this.radius=e,this}setFromPoints(t,e){let n=this.center;e!==void 0?n.copy(e):jd.setFromPoints(t).getCenter(n);let s=0;for(let r=0,o=t.length;r<o;r++)s=Math.max(s,n.distanceToSquared(t[r]));return this.radius=Math.sqrt(s),this}copy(t){return this.center.copy(t.center),this.radius=t.radius,this}isEmpty(){return this.radius<0}makeEmpty(){return this.center.set(0,0,0),this.radius=-1,this}containsPoint(t){return t.distanceToSquared(this.center)<=this.radius*this.radius}distanceToPoint(t){return t.distanceTo(this.center)-this.radius}intersectsSphere(t){let e=this.radius+t.radius;return t.center.distanceToSquared(this.center)<=e*e}intersectsBox(t){return t.intersectsSphere(this)}intersectsPlane(t){return Math.abs(t.distanceToPoint(this.center))<=this.radius}clampPoint(t,e){let n=this.center.distanceToSquared(t);return e.copy(t),n>this.radius*this.radius&&(e.sub(this.center).normalize(),e.multiplyScalar(this.radius).add(this.center)),e}getBoundingBox(t){return this.isEmpty()?(t.makeEmpty(),t):(t.set(this.center,this.center),t.expandByScalar(this.radius),t)}applyMatrix4(t){return this.center.applyMatrix4(t),this.radius=this.radius*t.getMaxScaleOnAxis(),this}translate(t){return this.center.add(t),this}expandByPoint(t){if(this.isEmpty())return this.center.copy(t),this.radius=0,this;sr.subVectors(t,this.center);let e=sr.lengthSq();if(e>this.radius*this.radius){let n=Math.sqrt(e),s=(n-this.radius)*.5;this.center.addScaledVector(sr,s/n),this.radius+=s}return this}union(t){return t.isEmpty()?this:this.isEmpty()?(this.copy(t),this):(this.center.equals(t.center)===!0?this.radius=Math.max(this.radius,t.radius):(Co.subVectors(t.center,this.center).setLength(t.radius),this.expandByPoint(sr.copy(t.center).add(Co)),this.expandByPoint(sr.copy(t.center).sub(Co))),this)}equals(t){return t.center.equals(this.center)&&t.radius===this.radius}clone(){return new this.constructor().copy(this)}},ti=new B,Ro=new B,kr=new B,_i=new B,Po=new B,Hr=new B,Lo=new B,qi=class{constructor(t=new B,e=new B(0,0,-1)){this.origin=t,this.direction=e}set(t,e){return this.origin.copy(t),this.direction.copy(e),this}copy(t){return this.origin.copy(t.origin),this.direction.copy(t.direction),this}at(t,e){return e.copy(this.origin).addScaledVector(this.direction,t)}lookAt(t){return this.direction.copy(t).sub(this.origin).normalize(),this}recast(t){return this.origin.copy(this.at(t,ti)),this}closestPointToPoint(t,e){e.subVectors(t,this.origin);let n=e.dot(this.direction);return n<0?e.copy(this.origin):e.copy(this.origin).addScaledVector(this.direction,n)}distanceToPoint(t){return Math.sqrt(this.distanceSqToPoint(t))}distanceSqToPoint(t){let e=ti.subVectors(t,this.origin).dot(this.direction);return e<0?this.origin.distanceToSquared(t):(ti.copy(this.origin).addScaledVector(this.direction,e),ti.distanceToSquared(t))}distanceSqToSegment(t,e,n,s){Ro.copy(t).add(e).multiplyScalar(.5),kr.copy(e).sub(t).normalize(),_i.copy(this.origin).sub(Ro);let r=t.distanceTo(e)*.5,o=-this.direction.dot(kr),a=_i.dot(this.direction),l=-_i.dot(kr),h=_i.lengthSq(),u=Math.abs(1-o*o),d,m,x,v;if(u>0)if(d=o*l-a,m=o*a-l,v=r*u,d>=0)if(m>=-v)if(m<=v){let M=1/u;d*=M,m*=M,x=d*(d+o*m+2*a)+m*(o*d+m+2*l)+h}else m=r,d=Math.max(0,-(o*m+a)),x=-d*d+m*(m+2*l)+h;else m=-r,d=Math.max(0,-(o*m+a)),x=-d*d+m*(m+2*l)+h;else m<=-v?(d=Math.max(0,-(-o*r+a)),m=d>0?-r:Math.min(Math.max(-r,-l),r),x=-d*d+m*(m+2*l)+h):m<=v?(d=0,m=Math.min(Math.max(-r,-l),r),x=m*(m+2*l)+h):(d=Math.max(0,-(o*r+a)),m=d>0?r:Math.min(Math.max(-r,-l),r),x=-d*d+m*(m+2*l)+h);else m=o>0?-r:r,d=Math.max(0,-(o*m+a)),x=-d*d+m*(m+2*l)+h;return n&&n.copy(this.origin).addScaledVector(this.direction,d),s&&s.copy(Ro).addScaledVector(kr,m),x}intersectSphere(t,e){ti.subVectors(t.center,this.origin);let n=ti.dot(this.direction),s=ti.dot(ti)-n*n,r=t.radius*t.radius;if(s>r)return null;let o=Math.sqrt(r-s),a=n-o,l=n+o;return l<0?null:a<0?this.at(l,e):this.at(a,e)}intersectsSphere(t){return this.distanceSqToPoint(t.center)<=t.radius*t.radius}distanceToPlane(t){let e=t.normal.dot(this.direction);if(e===0)return t.distanceToPoint(this.origin)===0?0:null;let n=-(this.origin.dot(t.normal)+t.constant)/e;return n>=0?n:null}intersectPlane(t,e){let n=this.distanceToPlane(t);return n===null?null:this.at(n,e)}intersectsPlane(t){let e=t.distanceToPoint(this.origin);return e===0||t.normal.dot(this.direction)*e<0}intersectBox(t,e){let n,s,r,o,a,l,h=1/this.direction.x,u=1/this.direction.y,d=1/this.direction.z,m=this.origin;return h>=0?(n=(t.min.x-m.x)*h,s=(t.max.x-m.x)*h):(n=(t.max.x-m.x)*h,s=(t.min.x-m.x)*h),u>=0?(r=(t.min.y-m.y)*u,o=(t.max.y-m.y)*u):(r=(t.max.y-m.y)*u,o=(t.min.y-m.y)*u),n>o||r>s||((r>n||isNaN(n))&&(n=r),(o<s||isNaN(s))&&(s=o),d>=0?(a=(t.min.z-m.z)*d,l=(t.max.z-m.z)*d):(a=(t.max.z-m.z)*d,l=(t.min.z-m.z)*d),n>l||a>s)||((a>n||n!==n)&&(n=a),(l<s||s!==s)&&(s=l),s<0)?null:this.at(n>=0?n:s,e)}intersectsBox(t){return this.intersectBox(t,ti)!==null}intersectTriangle(t,e,n,s,r){Po.subVectors(e,t),Hr.subVectors(n,t),Lo.crossVectors(Po,Hr);let o=this.direction.dot(Lo),a;if(o>0){if(s)return null;a=1}else if(o<0)a=-1,o=-o;else return null;_i.subVectors(this.origin,t);let l=a*this.direction.dot(Hr.crossVectors(_i,Hr));if(l<0)return null;let h=a*this.direction.dot(Po.cross(_i));if(h<0||l+h>o)return null;let u=-a*_i.dot(Lo);return u<0?null:this.at(u/o,r)}applyMatrix4(t){return this.origin.applyMatrix4(t),this.direction.transformDirection(t),this}equals(t){return t.origin.equals(this.origin)&&t.direction.equals(this.direction)}clone(){return new this.constructor().copy(this)}},_e=class i{constructor(t,e,n,s,r,o,a,l,h,u,d,m,x,v,M,g){i.prototype.isMatrix4=!0,this.elements=[1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1],t!==void 0&&this.set(t,e,n,s,r,o,a,l,h,u,d,m,x,v,M,g)}set(t,e,n,s,r,o,a,l,h,u,d,m,x,v,M,g){let f=this.elements;return f[0]=t,f[4]=e,f[8]=n,f[12]=s,f[1]=r,f[5]=o,f[9]=a,f[13]=l,f[2]=h,f[6]=u,f[10]=d,f[14]=m,f[3]=x,f[7]=v,f[11]=M,f[15]=g,this}identity(){return this.set(1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1),this}clone(){return new i().fromArray(this.elements)}copy(t){let e=this.elements,n=t.elements;return e[0]=n[0],e[1]=n[1],e[2]=n[2],e[3]=n[3],e[4]=n[4],e[5]=n[5],e[6]=n[6],e[7]=n[7],e[8]=n[8],e[9]=n[9],e[10]=n[10],e[11]=n[11],e[12]=n[12],e[13]=n[13],e[14]=n[14],e[15]=n[15],this}copyPosition(t){let e=this.elements,n=t.elements;return e[12]=n[12],e[13]=n[13],e[14]=n[14],this}setFromMatrix3(t){let e=t.elements;return this.set(e[0],e[3],e[6],0,e[1],e[4],e[7],0,e[2],e[5],e[8],0,0,0,0,1),this}extractBasis(t,e,n){return t.setFromMatrixColumn(this,0),e.setFromMatrixColumn(this,1),n.setFromMatrixColumn(this,2),this}makeBasis(t,e,n){return this.set(t.x,e.x,n.x,0,t.y,e.y,n.y,0,t.z,e.z,n.z,0,0,0,0,1),this}extractRotation(t){let e=this.elements,n=t.elements,s=1/ms.setFromMatrixColumn(t,0).length(),r=1/ms.setFromMatrixColumn(t,1).length(),o=1/ms.setFromMatrixColumn(t,2).length();return e[0]=n[0]*s,e[1]=n[1]*s,e[2]=n[2]*s,e[3]=0,e[4]=n[4]*r,e[5]=n[5]*r,e[6]=n[6]*r,e[7]=0,e[8]=n[8]*o,e[9]=n[9]*o,e[10]=n[10]*o,e[11]=0,e[12]=0,e[13]=0,e[14]=0,e[15]=1,this}makeRotationFromEuler(t){let e=this.elements,n=t.x,s=t.y,r=t.z,o=Math.cos(n),a=Math.sin(n),l=Math.cos(s),h=Math.sin(s),u=Math.cos(r),d=Math.sin(r);if(t.order==="XYZ"){let m=o*u,x=o*d,v=a*u,M=a*d;e[0]=l*u,e[4]=-l*d,e[8]=h,e[1]=x+v*h,e[5]=m-M*h,e[9]=-a*l,e[2]=M-m*h,e[6]=v+x*h,e[10]=o*l}else if(t.order==="YXZ"){let m=l*u,x=l*d,v=h*u,M=h*d;e[0]=m+M*a,e[4]=v*a-x,e[8]=o*h,e[1]=o*d,e[5]=o*u,e[9]=-a,e[2]=x*a-v,e[6]=M+m*a,e[10]=o*l}else if(t.order==="ZXY"){let m=l*u,x=l*d,v=h*u,M=h*d;e[0]=m-M*a,e[4]=-o*d,e[8]=v+x*a,e[1]=x+v*a,e[5]=o*u,e[9]=M-m*a,e[2]=-o*h,e[6]=a,e[10]=o*l}else if(t.order==="ZYX"){let m=o*u,x=o*d,v=a*u,M=a*d;e[0]=l*u,e[4]=v*h-x,e[8]=m*h+M,e[1]=l*d,e[5]=M*h+m,e[9]=x*h-v,e[2]=-h,e[6]=a*l,e[10]=o*l}else if(t.order==="YZX"){let m=o*l,x=o*h,v=a*l,M=a*h;e[0]=l*u,e[4]=M-m*d,e[8]=v*d+x,e[1]=d,e[5]=o*u,e[9]=-a*u,e[2]=-h*u,e[6]=x*d+v,e[10]=m-M*d}else if(t.order==="XZY"){let m=o*l,x=o*h,v=a*l,M=a*h;e[0]=l*u,e[4]=-d,e[8]=h*u,e[1]=m*d+M,e[5]=o*u,e[9]=x*d-v,e[2]=v*d-x,e[6]=a*u,e[10]=M*d+m}return e[3]=0,e[7]=0,e[11]=0,e[12]=0,e[13]=0,e[14]=0,e[15]=1,this}makeRotationFromQuaternion(t){return this.compose($d,t,Kd)}lookAt(t,e,n){let s=this.elements;return mn.subVectors(t,e),mn.lengthSq()===0&&(mn.z=1),mn.normalize(),vi.crossVectors(n,mn),vi.lengthSq()===0&&(Math.abs(n.z)===1?mn.x+=1e-4:mn.z+=1e-4,mn.normalize(),vi.crossVectors(n,mn)),vi.normalize(),Vr.crossVectors(mn,vi),s[0]=vi.x,s[4]=Vr.x,s[8]=mn.x,s[1]=vi.y,s[5]=Vr.y,s[9]=mn.y,s[2]=vi.z,s[6]=Vr.z,s[10]=mn.z,this}multiply(t){return this.multiplyMatrices(this,t)}premultiply(t){return this.multiplyMatrices(t,this)}multiplyMatrices(t,e){let n=t.elements,s=e.elements,r=this.elements,o=n[0],a=n[4],l=n[8],h=n[12],u=n[1],d=n[5],m=n[9],x=n[13],v=n[2],M=n[6],g=n[10],f=n[14],R=n[3],E=n[7],L=n[11],z=n[15],N=s[0],I=s[4],it=s[8],w=s[12],A=s[1],X=s[5],tt=s[9],at=s[13],F=s[2],V=s[6],Z=s[10],k=s[14],$=s[3],K=s[7],et=s[11],rt=s[15];return r[0]=o*N+a*A+l*F+h*$,r[4]=o*I+a*X+l*V+h*K,r[8]=o*it+a*tt+l*Z+h*et,r[12]=o*w+a*at+l*k+h*rt,r[1]=u*N+d*A+m*F+x*$,r[5]=u*I+d*X+m*V+x*K,r[9]=u*it+d*tt+m*Z+x*et,r[13]=u*w+d*at+m*k+x*rt,r[2]=v*N+M*A+g*F+f*$,r[6]=v*I+M*X+g*V+f*K,r[10]=v*it+M*tt+g*Z+f*et,r[14]=v*w+M*at+g*k+f*rt,r[3]=R*N+E*A+L*F+z*$,r[7]=R*I+E*X+L*V+z*K,r[11]=R*it+E*tt+L*Z+z*et,r[15]=R*w+E*at+L*k+z*rt,this}multiplyScalar(t){let e=this.elements;return e[0]*=t,e[4]*=t,e[8]*=t,e[12]*=t,e[1]*=t,e[5]*=t,e[9]*=t,e[13]*=t,e[2]*=t,e[6]*=t,e[10]*=t,e[14]*=t,e[3]*=t,e[7]*=t,e[11]*=t,e[15]*=t,this}determinant(){let t=this.elements,e=t[0],n=t[4],s=t[8],r=t[12],o=t[1],a=t[5],l=t[9],h=t[13],u=t[2],d=t[6],m=t[10],x=t[14],v=t[3],M=t[7],g=t[11],f=t[15];return v*(+r*l*d-s*h*d-r*a*m+n*h*m+s*a*x-n*l*x)+M*(+e*l*x-e*h*m+r*o*m-s*o*x+s*h*u-r*l*u)+g*(+e*h*d-e*a*x-r*o*d+n*o*x+r*a*u-n*h*u)+f*(-s*a*u-e*l*d+e*a*m+s*o*d-n*o*m+n*l*u)}transpose(){let t=this.elements,e;return e=t[1],t[1]=t[4],t[4]=e,e=t[2],t[2]=t[8],t[8]=e,e=t[6],t[6]=t[9],t[9]=e,e=t[3],t[3]=t[12],t[12]=e,e=t[7],t[7]=t[13],t[13]=e,e=t[11],t[11]=t[14],t[14]=e,this}setPosition(t,e,n){let s=this.elements;return t.isVector3?(s[12]=t.x,s[13]=t.y,s[14]=t.z):(s[12]=t,s[13]=e,s[14]=n),this}invert(){let t=this.elements,e=t[0],n=t[1],s=t[2],r=t[3],o=t[4],a=t[5],l=t[6],h=t[7],u=t[8],d=t[9],m=t[10],x=t[11],v=t[12],M=t[13],g=t[14],f=t[15],R=d*g*h-M*m*h+M*l*x-a*g*x-d*l*f+a*m*f,E=v*m*h-u*g*h-v*l*x+o*g*x+u*l*f-o*m*f,L=u*M*h-v*d*h+v*a*x-o*M*x-u*a*f+o*d*f,z=v*d*l-u*M*l-v*a*m+o*M*m+u*a*g-o*d*g,N=e*R+n*E+s*L+r*z;if(N===0)return this.set(0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0);let I=1/N;return t[0]=R*I,t[1]=(M*m*r-d*g*r-M*s*x+n*g*x+d*s*f-n*m*f)*I,t[2]=(a*g*r-M*l*r+M*s*h-n*g*h-a*s*f+n*l*f)*I,t[3]=(d*l*r-a*m*r-d*s*h+n*m*h+a*s*x-n*l*x)*I,t[4]=E*I,t[5]=(u*g*r-v*m*r+v*s*x-e*g*x-u*s*f+e*m*f)*I,t[6]=(v*l*r-o*g*r-v*s*h+e*g*h+o*s*f-e*l*f)*I,t[7]=(o*m*r-u*l*r+u*s*h-e*m*h-o*s*x+e*l*x)*I,t[8]=L*I,t[9]=(v*d*r-u*M*r-v*n*x+e*M*x+u*n*f-e*d*f)*I,t[10]=(o*M*r-v*a*r+v*n*h-e*M*h-o*n*f+e*a*f)*I,t[11]=(u*a*r-o*d*r-u*n*h+e*d*h+o*n*x-e*a*x)*I,t[12]=z*I,t[13]=(u*M*s-v*d*s+v*n*m-e*M*m-u*n*g+e*d*g)*I,t[14]=(v*a*s-o*M*s-v*n*l+e*M*l+o*n*g-e*a*g)*I,t[15]=(o*d*s-u*a*s+u*n*l-e*d*l-o*n*m+e*a*m)*I,this}scale(t){let e=this.elements,n=t.x,s=t.y,r=t.z;return e[0]*=n,e[4]*=s,e[8]*=r,e[1]*=n,e[5]*=s,e[9]*=r,e[2]*=n,e[6]*=s,e[10]*=r,e[3]*=n,e[7]*=s,e[11]*=r,this}getMaxScaleOnAxis(){let t=this.elements,e=t[0]*t[0]+t[1]*t[1]+t[2]*t[2],n=t[4]*t[4]+t[5]*t[5]+t[6]*t[6],s=t[8]*t[8]+t[9]*t[9]+t[10]*t[10];return Math.sqrt(Math.max(e,n,s))}makeTranslation(t,e,n){return t.isVector3?this.set(1,0,0,t.x,0,1,0,t.y,0,0,1,t.z,0,0,0,1):this.set(1,0,0,t,0,1,0,e,0,0,1,n,0,0,0,1),this}makeRotationX(t){let e=Math.cos(t),n=Math.sin(t);return this.set(1,0,0,0,0,e,-n,0,0,n,e,0,0,0,0,1),this}makeRotationY(t){let e=Math.cos(t),n=Math.sin(t);return this.set(e,0,n,0,0,1,0,0,-n,0,e,0,0,0,0,1),this}makeRotationZ(t){let e=Math.cos(t),n=Math.sin(t);return this.set(e,-n,0,0,n,e,0,0,0,0,1,0,0,0,0,1),this}makeRotationAxis(t,e){let n=Math.cos(e),s=Math.sin(e),r=1-n,o=t.x,a=t.y,l=t.z,h=r*o,u=r*a;return this.set(h*o+n,h*a-s*l,h*l+s*a,0,h*a+s*l,u*a+n,u*l-s*o,0,h*l-s*a,u*l+s*o,r*l*l+n,0,0,0,0,1),this}makeScale(t,e,n){return this.set(t,0,0,0,0,e,0,0,0,0,n,0,0,0,0,1),this}makeShear(t,e,n,s,r,o){return this.set(1,n,r,0,t,1,o,0,e,s,1,0,0,0,0,1),this}compose(t,e,n){let s=this.elements,r=e._x,o=e._y,a=e._z,l=e._w,h=r+r,u=o+o,d=a+a,m=r*h,x=r*u,v=r*d,M=o*u,g=o*d,f=a*d,R=l*h,E=l*u,L=l*d,z=n.x,N=n.y,I=n.z;return s[0]=(1-(M+f))*z,s[1]=(x+L)*z,s[2]=(v-E)*z,s[3]=0,s[4]=(x-L)*N,s[5]=(1-(m+f))*N,s[6]=(g+R)*N,s[7]=0,s[8]=(v+E)*I,s[9]=(g-R)*I,s[10]=(1-(m+M))*I,s[11]=0,s[12]=t.x,s[13]=t.y,s[14]=t.z,s[15]=1,this}decompose(t,e,n){let s=this.elements,r=ms.set(s[0],s[1],s[2]).length(),o=ms.set(s[4],s[5],s[6]).length(),a=ms.set(s[8],s[9],s[10]).length();this.determinant()<0&&(r=-r),t.x=s[12],t.y=s[13],t.z=s[14],Ln.copy(this);let h=1/r,u=1/o,d=1/a;return Ln.elements[0]*=h,Ln.elements[1]*=h,Ln.elements[2]*=h,Ln.elements[4]*=u,Ln.elements[5]*=u,Ln.elements[6]*=u,Ln.elements[8]*=d,Ln.elements[9]*=d,Ln.elements[10]*=d,e.setFromRotationMatrix(Ln),n.x=r,n.y=o,n.z=a,this}makePerspective(t,e,n,s,r,o,a=ai){let l=this.elements,h=2*r/(e-t),u=2*r/(n-s),d=(e+t)/(e-t),m=(n+s)/(n-s),x,v;if(a===ai)x=-(o+r)/(o-r),v=-2*o*r/(o-r);else if(a===pa)x=-o/(o-r),v=-o*r/(o-r);else throw new Error("THREE.Matrix4.makePerspective(): Invalid coordinate system: "+a);return l[0]=h,l[4]=0,l[8]=d,l[12]=0,l[1]=0,l[5]=u,l[9]=m,l[13]=0,l[2]=0,l[6]=0,l[10]=x,l[14]=v,l[3]=0,l[7]=0,l[11]=-1,l[15]=0,this}makeOrthographic(t,e,n,s,r,o,a=ai){let l=this.elements,h=1/(e-t),u=1/(n-s),d=1/(o-r),m=(e+t)*h,x=(n+s)*u,v,M;if(a===ai)v=(o+r)*d,M=-2*d;else if(a===pa)v=r*d,M=-1*d;else throw new Error("THREE.Matrix4.makeOrthographic(): Invalid coordinate system: "+a);return l[0]=2*h,l[4]=0,l[8]=0,l[12]=-m,l[1]=0,l[5]=2*u,l[9]=0,l[13]=-x,l[2]=0,l[6]=0,l[10]=M,l[14]=-v,l[3]=0,l[7]=0,l[11]=0,l[15]=1,this}equals(t){let e=this.elements,n=t.elements;for(let s=0;s<16;s++)if(e[s]!==n[s])return!1;return!0}fromArray(t,e=0){for(let n=0;n<16;n++)this.elements[n]=t[n+e];return this}toArray(t=[],e=0){let n=this.elements;return t[e]=n[0],t[e+1]=n[1],t[e+2]=n[2],t[e+3]=n[3],t[e+4]=n[4],t[e+5]=n[5],t[e+6]=n[6],t[e+7]=n[7],t[e+8]=n[8],t[e+9]=n[9],t[e+10]=n[10],t[e+11]=n[11],t[e+12]=n[12],t[e+13]=n[13],t[e+14]=n[14],t[e+15]=n[15],t}},ms=new B,Ln=new _e,$d=new B(0,0,0),Kd=new B(1,1,1),vi=new B,Vr=new B,mn=new B,nh=new _e,ih=new Fn,ya=class i{constructor(t=0,e=0,n=0,s=i.DEFAULT_ORDER){this.isEuler=!0,this._x=t,this._y=e,this._z=n,this._order=s}get x(){return this._x}set x(t){this._x=t,this._onChangeCallback()}get y(){return this._y}set y(t){this._y=t,this._onChangeCallback()}get z(){return this._z}set z(t){this._z=t,this._onChangeCallback()}get order(){return this._order}set order(t){this._order=t,this._onChangeCallback()}set(t,e,n,s=this._order){return this._x=t,this._y=e,this._z=n,this._order=s,this._onChangeCallback(),this}clone(){return new this.constructor(this._x,this._y,this._z,this._order)}copy(t){return this._x=t._x,this._y=t._y,this._z=t._z,this._order=t._order,this._onChangeCallback(),this}setFromRotationMatrix(t,e=this._order,n=!0){let s=t.elements,r=s[0],o=s[4],a=s[8],l=s[1],h=s[5],u=s[9],d=s[2],m=s[6],x=s[10];switch(e){case"XYZ":this._y=Math.asin(tn(a,-1,1)),Math.abs(a)<.9999999?(this._x=Math.atan2(-u,x),this._z=Math.atan2(-o,r)):(this._x=Math.atan2(m,h),this._z=0);break;case"YXZ":this._x=Math.asin(-tn(u,-1,1)),Math.abs(u)<.9999999?(this._y=Math.atan2(a,x),this._z=Math.atan2(l,h)):(this._y=Math.atan2(-d,r),this._z=0);break;case"ZXY":this._x=Math.asin(tn(m,-1,1)),Math.abs(m)<.9999999?(this._y=Math.atan2(-d,x),this._z=Math.atan2(-o,h)):(this._y=0,this._z=Math.atan2(l,r));break;case"ZYX":this._y=Math.asin(-tn(d,-1,1)),Math.abs(d)<.9999999?(this._x=Math.atan2(m,x),this._z=Math.atan2(l,r)):(this._x=0,this._z=Math.atan2(-o,h));break;case"YZX":this._z=Math.asin(tn(l,-1,1)),Math.abs(l)<.9999999?(this._x=Math.atan2(-u,h),this._y=Math.atan2(-d,r)):(this._x=0,this._y=Math.atan2(a,x));break;case"XZY":this._z=Math.asin(-tn(o,-1,1)),Math.abs(o)<.9999999?(this._x=Math.atan2(m,h),this._y=Math.atan2(a,r)):(this._x=Math.atan2(-u,x),this._y=0);break;default:console.warn("THREE.Euler: .setFromRotationMatrix() encountered an unknown order: "+e)}return this._order=e,n===!0&&this._onChangeCallback(),this}setFromQuaternion(t,e,n){return nh.makeRotationFromQuaternion(t),this.setFromRotationMatrix(nh,e,n)}setFromVector3(t,e=this._order){return this.set(t.x,t.y,t.z,e)}reorder(t){return ih.setFromEuler(this),this.setFromQuaternion(ih,t)}equals(t){return t._x===this._x&&t._y===this._y&&t._z===this._z&&t._order===this._order}fromArray(t){return this._x=t[0],this._y=t[1],this._z=t[2],t[3]!==void 0&&(this._order=t[3]),this._onChangeCallback(),this}toArray(t=[],e=0){return t[e]=this._x,t[e+1]=this._y,t[e+2]=this._z,t[e+3]=this._order,t}_onChange(t){return this._onChangeCallback=t,this}_onChangeCallback(){}*[Symbol.iterator](){yield this._x,yield this._y,yield this._z,yield this._order}};ya.DEFAULT_ORDER="XYZ";var xr=class{constructor(){this.mask=1}set(t){this.mask=(1<<t|0)>>>0}enable(t){this.mask|=1<<t|0}enableAll(){this.mask=-1}toggle(t){this.mask^=1<<t|0}disable(t){this.mask&=~(1<<t|0)}disableAll(){this.mask=0}test(t){return(this.mask&t.mask)!==0}isEnabled(t){return(this.mask&(1<<t|0))!==0}},Qd=0,sh=new B,gs=new Fn,ei=new _e,Gr=new B,rr=new B,tf=new B,ef=new Fn,rh=new B(1,0,0),ah=new B(0,1,0),oh=new B(0,0,1),nf={type:"added"},sf={type:"removed"},nn=class i extends Jn{constructor(){super(),this.isObject3D=!0,Object.defineProperty(this,"id",{value:Qd++}),this.uuid=Hs(),this.name="",this.type="Object3D",this.parent=null,this.children=[],this.up=i.DEFAULT_UP.clone();let t=new B,e=new ya,n=new Fn,s=new B(1,1,1);function r(){n.setFromEuler(e,!1)}function o(){e.setFromQuaternion(n,void 0,!1)}e._onChange(r),n._onChange(o),Object.defineProperties(this,{position:{configurable:!0,enumerable:!0,value:t},rotation:{configurable:!0,enumerable:!0,value:e},quaternion:{configurable:!0,enumerable:!0,value:n},scale:{configurable:!0,enumerable:!0,value:s},modelViewMatrix:{value:new _e},normalMatrix:{value:new se}}),this.matrix=new _e,this.matrixWorld=new _e,this.matrixAutoUpdate=i.DEFAULT_MATRIX_AUTO_UPDATE,this.matrixWorldAutoUpdate=i.DEFAULT_MATRIX_WORLD_AUTO_UPDATE,this.matrixWorldNeedsUpdate=!1,this.layers=new xr,this.visible=!0,this.castShadow=!1,this.receiveShadow=!1,this.frustumCulled=!0,this.renderOrder=0,this.animations=[],this.userData={}}onBeforeShadow(){}onAfterShadow(){}onBeforeRender(){}onAfterRender(){}applyMatrix4(t){this.matrixAutoUpdate&&this.updateMatrix(),this.matrix.premultiply(t),this.matrix.decompose(this.position,this.quaternion,this.scale)}applyQuaternion(t){return this.quaternion.premultiply(t),this}setRotationFromAxisAngle(t,e){this.quaternion.setFromAxisAngle(t,e)}setRotationFromEuler(t){this.quaternion.setFromEuler(t,!0)}setRotationFromMatrix(t){this.quaternion.setFromRotationMatrix(t)}setRotationFromQuaternion(t){this.quaternion.copy(t)}rotateOnAxis(t,e){return gs.setFromAxisAngle(t,e),this.quaternion.multiply(gs),this}rotateOnWorldAxis(t,e){return gs.setFromAxisAngle(t,e),this.quaternion.premultiply(gs),this}rotateX(t){return this.rotateOnAxis(rh,t)}rotateY(t){return this.rotateOnAxis(ah,t)}rotateZ(t){return this.rotateOnAxis(oh,t)}translateOnAxis(t,e){return sh.copy(t).applyQuaternion(this.quaternion),this.position.add(sh.multiplyScalar(e)),this}translateX(t){return this.translateOnAxis(rh,t)}translateY(t){return this.translateOnAxis(ah,t)}translateZ(t){return this.translateOnAxis(oh,t)}localToWorld(t){return this.updateWorldMatrix(!0,!1),t.applyMatrix4(this.matrixWorld)}worldToLocal(t){return this.updateWorldMatrix(!0,!1),t.applyMatrix4(ei.copy(this.matrixWorld).invert())}lookAt(t,e,n){t.isVector3?Gr.copy(t):Gr.set(t,e,n);let s=this.parent;this.updateWorldMatrix(!0,!1),rr.setFromMatrixPosition(this.matrixWorld),this.isCamera||this.isLight?ei.lookAt(rr,Gr,this.up):ei.lookAt(Gr,rr,this.up),this.quaternion.setFromRotationMatrix(ei),s&&(ei.extractRotation(s.matrixWorld),gs.setFromRotationMatrix(ei),this.quaternion.premultiply(gs.invert()))}add(t){if(arguments.length>1){for(let e=0;e<arguments.length;e++)this.add(arguments[e]);return this}return t===this?(console.error("THREE.Object3D.add: object can't be added as a child of itself.",t),this):(t&&t.isObject3D?(t.parent!==null&&t.parent.remove(t),t.parent=this,this.children.push(t),t.dispatchEvent(nf)):console.error("THREE.Object3D.add: object not an instance of THREE.Object3D.",t),this)}remove(t){if(arguments.length>1){for(let n=0;n<arguments.length;n++)this.remove(arguments[n]);return this}let e=this.children.indexOf(t);return e!==-1&&(t.parent=null,this.children.splice(e,1),t.dispatchEvent(sf)),this}removeFromParent(){let t=this.parent;return t!==null&&t.remove(this),this}clear(){return this.remove(...this.children)}attach(t){return this.updateWorldMatrix(!0,!1),ei.copy(this.matrixWorld).invert(),t.parent!==null&&(t.parent.updateWorldMatrix(!0,!1),ei.multiply(t.parent.matrixWorld)),t.applyMatrix4(ei),this.add(t),t.updateWorldMatrix(!1,!0),this}getObjectById(t){return this.getObjectByProperty("id",t)}getObjectByName(t){return this.getObjectByProperty("name",t)}getObjectByProperty(t,e){if(this[t]===e)return this;for(let n=0,s=this.children.length;n<s;n++){let o=this.children[n].getObjectByProperty(t,e);if(o!==void 0)return o}}getObjectsByProperty(t,e,n=[]){this[t]===e&&n.push(this);let s=this.children;for(let r=0,o=s.length;r<o;r++)s[r].getObjectsByProperty(t,e,n);return n}getWorldPosition(t){return this.updateWorldMatrix(!0,!1),t.setFromMatrixPosition(this.matrixWorld)}getWorldQuaternion(t){return this.updateWorldMatrix(!0,!1),this.matrixWorld.decompose(rr,t,tf),t}getWorldScale(t){return this.updateWorldMatrix(!0,!1),this.matrixWorld.decompose(rr,ef,t),t}getWorldDirection(t){this.updateWorldMatrix(!0,!1);let e=this.matrixWorld.elements;return t.set(e[8],e[9],e[10]).normalize()}raycast(){}traverse(t){t(this);let e=this.children;for(let n=0,s=e.length;n<s;n++)e[n].traverse(t)}traverseVisible(t){if(this.visible===!1)return;t(this);let e=this.children;for(let n=0,s=e.length;n<s;n++)e[n].traverseVisible(t)}traverseAncestors(t){let e=this.parent;e!==null&&(t(e),e.traverseAncestors(t))}updateMatrix(){this.matrix.compose(this.position,this.quaternion,this.scale),this.matrixWorldNeedsUpdate=!0}updateMatrixWorld(t){this.matrixAutoUpdate&&this.updateMatrix(),(this.matrixWorldNeedsUpdate||t)&&(this.parent===null?this.matrixWorld.copy(this.matrix):this.matrixWorld.multiplyMatrices(this.parent.matrixWorld,this.matrix),this.matrixWorldNeedsUpdate=!1,t=!0);let e=this.children;for(let n=0,s=e.length;n<s;n++){let r=e[n];(r.matrixWorldAutoUpdate===!0||t===!0)&&r.updateMatrixWorld(t)}}updateWorldMatrix(t,e){let n=this.parent;if(t===!0&&n!==null&&n.matrixWorldAutoUpdate===!0&&n.updateWorldMatrix(!0,!1),this.matrixAutoUpdate&&this.updateMatrix(),this.parent===null?this.matrixWorld.copy(this.matrix):this.matrixWorld.multiplyMatrices(this.parent.matrixWorld,this.matrix),e===!0){let s=this.children;for(let r=0,o=s.length;r<o;r++){let a=s[r];a.matrixWorldAutoUpdate===!0&&a.updateWorldMatrix(!1,!0)}}}toJSON(t){let e=t===void 0||typeof t=="string",n={};e&&(t={geometries:{},materials:{},textures:{},images:{},shapes:{},skeletons:{},animations:{},nodes:{}},n.metadata={version:4.6,type:"Object",generator:"Object3D.toJSON"});let s={};s.uuid=this.uuid,s.type=this.type,this.name!==""&&(s.name=this.name),this.castShadow===!0&&(s.castShadow=!0),this.receiveShadow===!0&&(s.receiveShadow=!0),this.visible===!1&&(s.visible=!1),this.frustumCulled===!1&&(s.frustumCulled=!1),this.renderOrder!==0&&(s.renderOrder=this.renderOrder),Object.keys(this.userData).length>0&&(s.userData=this.userData),s.layers=this.layers.mask,s.matrix=this.matrix.toArray(),s.up=this.up.toArray(),this.matrixAutoUpdate===!1&&(s.matrixAutoUpdate=!1),this.isInstancedMesh&&(s.type="InstancedMesh",s.count=this.count,s.instanceMatrix=this.instanceMatrix.toJSON(),this.instanceColor!==null&&(s.instanceColor=this.instanceColor.toJSON())),this.isBatchedMesh&&(s.type="BatchedMesh",s.perObjectFrustumCulled=this.perObjectFrustumCulled,s.sortObjects=this.sortObjects,s.drawRanges=this._drawRanges,s.reservedRanges=this._reservedRanges,s.visibility=this._visibility,s.active=this._active,s.bounds=this._bounds.map(a=>({boxInitialized:a.boxInitialized,boxMin:a.box.min.toArray(),boxMax:a.box.max.toArray(),sphereInitialized:a.sphereInitialized,sphereRadius:a.sphere.radius,sphereCenter:a.sphere.center.toArray()})),s.maxGeometryCount=this._maxGeometryCount,s.maxVertexCount=this._maxVertexCount,s.maxIndexCount=this._maxIndexCount,s.geometryInitialized=this._geometryInitialized,s.geometryCount=this._geometryCount,s.matricesTexture=this._matricesTexture.toJSON(t),this.boundingSphere!==null&&(s.boundingSphere={center:s.boundingSphere.center.toArray(),radius:s.boundingSphere.radius}),this.boundingBox!==null&&(s.boundingBox={min:s.boundingBox.min.toArray(),max:s.boundingBox.max.toArray()}));function r(a,l){return a[l.uuid]===void 0&&(a[l.uuid]=l.toJSON(t)),l.uuid}if(this.isScene)this.background&&(this.background.isColor?s.background=this.background.toJSON():this.background.isTexture&&(s.background=this.background.toJSON(t).uuid)),this.environment&&this.environment.isTexture&&this.environment.isRenderTargetTexture!==!0&&(s.environment=this.environment.toJSON(t).uuid);else if(this.isMesh||this.isLine||this.isPoints){s.geometry=r(t.geometries,this.geometry);let a=this.geometry.parameters;if(a!==void 0&&a.shapes!==void 0){let l=a.shapes;if(Array.isArray(l))for(let h=0,u=l.length;h<u;h++){let d=l[h];r(t.shapes,d)}else r(t.shapes,l)}}if(this.isSkinnedMesh&&(s.bindMode=this.bindMode,s.bindMatrix=this.bindMatrix.toArray(),this.skeleton!==void 0&&(r(t.skeletons,this.skeleton),s.skeleton=this.skeleton.uuid)),this.material!==void 0)if(Array.isArray(this.material)){let a=[];for(let l=0,h=this.material.length;l<h;l++)a.push(r(t.materials,this.material[l]));s.material=a}else s.material=r(t.materials,this.material);if(this.children.length>0){s.children=[];for(let a=0;a<this.children.length;a++)s.children.push(this.children[a].toJSON(t).object)}if(this.animations.length>0){s.animations=[];for(let a=0;a<this.animations.length;a++){let l=this.animations[a];s.animations.push(r(t.animations,l))}}if(e){let a=o(t.geometries),l=o(t.materials),h=o(t.textures),u=o(t.images),d=o(t.shapes),m=o(t.skeletons),x=o(t.animations),v=o(t.nodes);a.length>0&&(n.geometries=a),l.length>0&&(n.materials=l),h.length>0&&(n.textures=h),u.length>0&&(n.images=u),d.length>0&&(n.shapes=d),m.length>0&&(n.skeletons=m),x.length>0&&(n.animations=x),v.length>0&&(n.nodes=v)}return n.object=s,n;function o(a){let l=[];for(let h in a){let u=a[h];delete u.metadata,l.push(u)}return l}}clone(t){return new this.constructor().copy(this,t)}copy(t,e=!0){if(this.name=t.name,this.up.copy(t.up),this.position.copy(t.position),this.rotation.order=t.rotation.order,this.quaternion.copy(t.quaternion),this.scale.copy(t.scale),this.matrix.copy(t.matrix),this.matrixWorld.copy(t.matrixWorld),this.matrixAutoUpdate=t.matrixAutoUpdate,this.matrixWorldAutoUpdate=t.matrixWorldAutoUpdate,this.matrixWorldNeedsUpdate=t.matrixWorldNeedsUpdate,this.layers.mask=t.layers.mask,this.visible=t.visible,this.castShadow=t.castShadow,this.receiveShadow=t.receiveShadow,this.frustumCulled=t.frustumCulled,this.renderOrder=t.renderOrder,this.animations=t.animations.slice(),this.userData=JSON.parse(JSON.stringify(t.userData)),e===!0)for(let n=0;n<t.children.length;n++){let s=t.children[n];this.add(s.clone())}return this}};nn.DEFAULT_UP=new B(0,1,0);nn.DEFAULT_MATRIX_AUTO_UPDATE=!0;nn.DEFAULT_MATRIX_WORLD_AUTO_UPDATE=!0;var In=new B,ni=new B,Io=new B,ii=new B,xs=new B,_s=new B,lh=new B,Do=new B,Uo=new B,No=new B,Wr=!1,Cs=class i{constructor(t=new B,e=new B,n=new B){this.a=t,this.b=e,this.c=n}static getNormal(t,e,n,s){s.subVectors(n,e),In.subVectors(t,e),s.cross(In);let r=s.lengthSq();return r>0?s.multiplyScalar(1/Math.sqrt(r)):s.set(0,0,0)}static getBarycoord(t,e,n,s,r){In.subVectors(s,e),ni.subVectors(n,e),Io.subVectors(t,e);let o=In.dot(In),a=In.dot(ni),l=In.dot(Io),h=ni.dot(ni),u=ni.dot(Io),d=o*h-a*a;if(d===0)return r.set(0,0,0),null;let m=1/d,x=(h*l-a*u)*m,v=(o*u-a*l)*m;return r.set(1-x-v,v,x)}static containsPoint(t,e,n,s){return this.getBarycoord(t,e,n,s,ii)===null?!1:ii.x>=0&&ii.y>=0&&ii.x+ii.y<=1}static getUV(t,e,n,s,r,o,a,l){return Wr===!1&&(console.warn("THREE.Triangle.getUV() has been renamed to THREE.Triangle.getInterpolation()."),Wr=!0),this.getInterpolation(t,e,n,s,r,o,a,l)}static getInterpolation(t,e,n,s,r,o,a,l){return this.getBarycoord(t,e,n,s,ii)===null?(l.x=0,l.y=0,"z"in l&&(l.z=0),"w"in l&&(l.w=0),null):(l.setScalar(0),l.addScaledVector(r,ii.x),l.addScaledVector(o,ii.y),l.addScaledVector(a,ii.z),l)}static isFrontFacing(t,e,n,s){return In.subVectors(n,e),ni.subVectors(t,e),In.cross(ni).dot(s)<0}set(t,e,n){return this.a.copy(t),this.b.copy(e),this.c.copy(n),this}setFromPointsAndIndices(t,e,n,s){return this.a.copy(t[e]),this.b.copy(t[n]),this.c.copy(t[s]),this}setFromAttributeAndIndices(t,e,n,s){return this.a.fromBufferAttribute(t,e),this.b.fromBufferAttribute(t,n),this.c.fromBufferAttribute(t,s),this}clone(){return new this.constructor().copy(this)}copy(t){return this.a.copy(t.a),this.b.copy(t.b),this.c.copy(t.c),this}getArea(){return In.subVectors(this.c,this.b),ni.subVectors(this.a,this.b),In.cross(ni).length()*.5}getMidpoint(t){return t.addVectors(this.a,this.b).add(this.c).multiplyScalar(1/3)}getNormal(t){return i.getNormal(this.a,this.b,this.c,t)}getPlane(t){return t.setFromCoplanarPoints(this.a,this.b,this.c)}getBarycoord(t,e){return i.getBarycoord(t,this.a,this.b,this.c,e)}getUV(t,e,n,s,r){return Wr===!1&&(console.warn("THREE.Triangle.getUV() has been renamed to THREE.Triangle.getInterpolation()."),Wr=!0),i.getInterpolation(t,this.a,this.b,this.c,e,n,s,r)}getInterpolation(t,e,n,s,r){return i.getInterpolation(t,this.a,this.b,this.c,e,n,s,r)}containsPoint(t){return i.containsPoint(t,this.a,this.b,this.c)}isFrontFacing(t){return i.isFrontFacing(this.a,this.b,this.c,t)}intersectsBox(t){return t.intersectsTriangle(this)}closestPointToPoint(t,e){let n=this.a,s=this.b,r=this.c,o,a;xs.subVectors(s,n),_s.subVectors(r,n),Do.subVectors(t,n);let l=xs.dot(Do),h=_s.dot(Do);if(l<=0&&h<=0)return e.copy(n);Uo.subVectors(t,s);let u=xs.dot(Uo),d=_s.dot(Uo);if(u>=0&&d<=u)return e.copy(s);let m=l*d-u*h;if(m<=0&&l>=0&&u<=0)return o=l/(l-u),e.copy(n).addScaledVector(xs,o);No.subVectors(t,r);let x=xs.dot(No),v=_s.dot(No);if(v>=0&&x<=v)return e.copy(r);let M=x*h-l*v;if(M<=0&&h>=0&&v<=0)return a=h/(h-v),e.copy(n).addScaledVector(_s,a);let g=u*v-x*d;if(g<=0&&d-u>=0&&x-v>=0)return lh.subVectors(r,s),a=(d-u)/(d-u+(x-v)),e.copy(s).addScaledVector(lh,a);let f=1/(g+M+m);return o=M*f,a=m*f,e.copy(n).addScaledVector(xs,o).addScaledVector(_s,a)}equals(t){return t.a.equals(this.a)&&t.b.equals(this.b)&&t.c.equals(this.c)}},ru={aliceblue:15792383,antiquewhite:16444375,aqua:65535,aquamarine:8388564,azure:15794175,beige:16119260,bisque:16770244,black:0,blanchedalmond:16772045,blue:255,blueviolet:9055202,brown:10824234,burlywood:14596231,cadetblue:6266528,chartreuse:8388352,chocolate:13789470,coral:16744272,cornflowerblue:6591981,cornsilk:16775388,crimson:14423100,cyan:65535,darkblue:139,darkcyan:35723,darkgoldenrod:12092939,darkgray:11119017,darkgreen:25600,darkgrey:11119017,darkkhaki:12433259,darkmagenta:9109643,darkolivegreen:5597999,darkorange:16747520,darkorchid:10040012,darkred:9109504,darksalmon:15308410,darkseagreen:9419919,darkslateblue:4734347,darkslategray:3100495,darkslategrey:3100495,darkturquoise:52945,darkviolet:9699539,deeppink:16716947,deepskyblue:49151,dimgray:6908265,dimgrey:6908265,dodgerblue:2003199,firebrick:11674146,floralwhite:16775920,forestgreen:2263842,fuchsia:16711935,gainsboro:14474460,ghostwhite:16316671,gold:16766720,goldenrod:14329120,gray:8421504,green:32768,greenyellow:11403055,grey:8421504,honeydew:15794160,hotpink:16738740,indianred:13458524,indigo:4915330,ivory:16777200,khaki:15787660,lavender:15132410,lavenderblush:16773365,lawngreen:8190976,lemonchiffon:16775885,lightblue:11393254,lightcoral:15761536,lightcyan:14745599,lightgoldenrodyellow:16448210,lightgray:13882323,lightgreen:9498256,lightgrey:13882323,lightpink:16758465,lightsalmon:16752762,lightseagreen:2142890,lightskyblue:8900346,lightslategray:7833753,lightslategrey:7833753,lightsteelblue:11584734,lightyellow:16777184,lime:65280,limegreen:3329330,linen:16445670,magenta:16711935,maroon:8388608,mediumaquamarine:6737322,mediumblue:205,mediumorchid:12211667,mediumpurple:9662683,mediumseagreen:3978097,mediumslateblue:8087790,mediumspringgreen:64154,mediumturquoise:4772300,mediumvioletred:13047173,midnightblue:1644912,mintcream:16121850,mistyrose:16770273,moccasin:16770229,navajowhite:16768685,navy:128,oldlace:16643558,olive:8421376,olivedrab:7048739,orange:16753920,orangered:16729344,orchid:14315734,palegoldenrod:15657130,palegreen:10025880,paleturquoise:11529966,palevioletred:14381203,papayawhip:16773077,peachpuff:16767673,peru:13468991,pink:16761035,plum:14524637,powderblue:11591910,purple:8388736,rebeccapurple:6697881,red:16711680,rosybrown:12357519,royalblue:4286945,saddlebrown:9127187,salmon:16416882,sandybrown:16032864,seagreen:3050327,seashell:16774638,sienna:10506797,silver:12632256,skyblue:8900331,slateblue:6970061,slategray:7372944,slategrey:7372944,snow:16775930,springgreen:65407,steelblue:4620980,tan:13808780,teal:32896,thistle:14204888,tomato:16737095,turquoise:4251856,violet:15631086,wheat:16113331,white:16777215,whitesmoke:16119285,yellow:16776960,yellowgreen:10145074},yi={h:0,s:0,l:0},Xr={h:0,s:0,l:0};function Oo(i,t,e){return e<0&&(e+=1),e>1&&(e-=1),e<1/6?i+(t-i)*6*e:e<1/2?t:e<2/3?i+(t-i)*6*(2/3-e):i}var Xt=class{constructor(t,e,n){return this.isColor=!0,this.r=1,this.g=1,this.b=1,this.set(t,e,n)}set(t,e,n){if(e===void 0&&n===void 0){let s=t;s&&s.isColor?this.copy(s):typeof s=="number"?this.setHex(s):typeof s=="string"&&this.setStyle(s)}else this.setRGB(t,e,n);return this}setScalar(t){return this.r=t,this.g=t,this.b=t,this}setHex(t,e=Re){return t=Math.floor(t),this.r=(t>>16&255)/255,this.g=(t>>8&255)/255,this.b=(t&255)/255,fe.toWorkingColorSpace(this,e),this}setRGB(t,e,n,s=fe.workingColorSpace){return this.r=t,this.g=e,this.b=n,fe.toWorkingColorSpace(this,s),this}setHSL(t,e,n,s=fe.workingColorSpace){if(t=Fl(t,1),e=tn(e,0,1),n=tn(n,0,1),e===0)this.r=this.g=this.b=n;else{let r=n<=.5?n*(1+e):n+e-n*e,o=2*n-r;this.r=Oo(o,r,t+1/3),this.g=Oo(o,r,t),this.b=Oo(o,r,t-1/3)}return fe.toWorkingColorSpace(this,s),this}setStyle(t,e=Re){function n(r){r!==void 0&&parseFloat(r)<1&&console.warn("THREE.Color: Alpha component of "+t+" will be ignored.")}let s;if(s=/^(\w+)\(([^\)]*)\)/.exec(t)){let r,o=s[1],a=s[2];switch(o){case"rgb":case"rgba":if(r=/^\s*(\d+)\s*,\s*(\d+)\s*,\s*(\d+)\s*(?:,\s*(\d*\.?\d+)\s*)?$/.exec(a))return n(r[4]),this.setRGB(Math.min(255,parseInt(r[1],10))/255,Math.min(255,parseInt(r[2],10))/255,Math.min(255,parseInt(r[3],10))/255,e);if(r=/^\s*(\d+)\%\s*,\s*(\d+)\%\s*,\s*(\d+)\%\s*(?:,\s*(\d*\.?\d+)\s*)?$/.exec(a))return n(r[4]),this.setRGB(Math.min(100,parseInt(r[1],10))/100,Math.min(100,parseInt(r[2],10))/100,Math.min(100,parseInt(r[3],10))/100,e);break;case"hsl":case"hsla":if(r=/^\s*(\d*\.?\d+)\s*,\s*(\d*\.?\d+)\%\s*,\s*(\d*\.?\d+)\%\s*(?:,\s*(\d*\.?\d+)\s*)?$/.exec(a))return n(r[4]),this.setHSL(parseFloat(r[1])/360,parseFloat(r[2])/100,parseFloat(r[3])/100,e);break;default:console.warn("THREE.Color: Unknown color model "+t)}}else if(s=/^\#([A-Fa-f\d]+)$/.exec(t)){let r=s[1],o=r.length;if(o===3)return this.setRGB(parseInt(r.charAt(0),16)/15,parseInt(r.charAt(1),16)/15,parseInt(r.charAt(2),16)/15,e);if(o===6)return this.setHex(parseInt(r,16),e);console.warn("THREE.Color: Invalid hex color "+t)}else if(t&&t.length>0)return this.setColorName(t,e);return this}setColorName(t,e=Re){let n=ru[t.toLowerCase()];return n!==void 0?this.setHex(n,e):console.warn("THREE.Color: Unknown color "+t),this}clone(){return new this.constructor(this.r,this.g,this.b)}copy(t){return this.r=t.r,this.g=t.g,this.b=t.b,this}copySRGBToLinear(t){return this.r=Ls(t.r),this.g=Ls(t.g),this.b=Ls(t.b),this}copyLinearToSRGB(t){return this.r=wo(t.r),this.g=wo(t.g),this.b=wo(t.b),this}convertSRGBToLinear(){return this.copySRGBToLinear(this),this}convertLinearToSRGB(){return this.copyLinearToSRGB(this),this}getHex(t=Re){return fe.fromWorkingColorSpace(Qe.copy(this),t),Math.round(tn(Qe.r*255,0,255))*65536+Math.round(tn(Qe.g*255,0,255))*256+Math.round(tn(Qe.b*255,0,255))}getHexString(t=Re){return("000000"+this.getHex(t).toString(16)).slice(-6)}getHSL(t,e=fe.workingColorSpace){fe.fromWorkingColorSpace(Qe.copy(this),e);let n=Qe.r,s=Qe.g,r=Qe.b,o=Math.max(n,s,r),a=Math.min(n,s,r),l,h,u=(a+o)/2;if(a===o)l=0,h=0;else{let d=o-a;switch(h=u<=.5?d/(o+a):d/(2-o-a),o){case n:l=(s-r)/d+(s<r?6:0);break;case s:l=(r-n)/d+2;break;case r:l=(n-s)/d+4;break}l/=6}return t.h=l,t.s=h,t.l=u,t}getRGB(t,e=fe.workingColorSpace){return fe.fromWorkingColorSpace(Qe.copy(this),e),t.r=Qe.r,t.g=Qe.g,t.b=Qe.b,t}getStyle(t=Re){fe.fromWorkingColorSpace(Qe.copy(this),t);let e=Qe.r,n=Qe.g,s=Qe.b;return t!==Re?`color(${t} ${e.toFixed(3)} ${n.toFixed(3)} ${s.toFixed(3)})`:`rgb(${Math.round(e*255)},${Math.round(n*255)},${Math.round(s*255)})`}offsetHSL(t,e,n){return this.getHSL(yi),this.setHSL(yi.h+t,yi.s+e,yi.l+n)}add(t){return this.r+=t.r,this.g+=t.g,this.b+=t.b,this}addColors(t,e){return this.r=t.r+e.r,this.g=t.g+e.g,this.b=t.b+e.b,this}addScalar(t){return this.r+=t,this.g+=t,this.b+=t,this}sub(t){return this.r=Math.max(0,this.r-t.r),this.g=Math.max(0,this.g-t.g),this.b=Math.max(0,this.b-t.b),this}multiply(t){return this.r*=t.r,this.g*=t.g,this.b*=t.b,this}multiplyScalar(t){return this.r*=t,this.g*=t,this.b*=t,this}lerp(t,e){return this.r+=(t.r-this.r)*e,this.g+=(t.g-this.g)*e,this.b+=(t.b-this.b)*e,this}lerpColors(t,e,n){return this.r=t.r+(e.r-t.r)*n,this.g=t.g+(e.g-t.g)*n,this.b=t.b+(e.b-t.b)*n,this}lerpHSL(t,e){this.getHSL(yi),t.getHSL(Xr);let n=ur(yi.h,Xr.h,e),s=ur(yi.s,Xr.s,e),r=ur(yi.l,Xr.l,e);return this.setHSL(n,s,r),this}setFromVector3(t){return this.r=t.x,this.g=t.y,this.b=t.z,this}applyMatrix3(t){let e=this.r,n=this.g,s=this.b,r=t.elements;return this.r=r[0]*e+r[3]*n+r[6]*s,this.g=r[1]*e+r[4]*n+r[7]*s,this.b=r[2]*e+r[5]*n+r[8]*s,this}equals(t){return t.r===this.r&&t.g===this.g&&t.b===this.b}fromArray(t,e=0){return this.r=t[e],this.g=t[e+1],this.b=t[e+2],this}toArray(t=[],e=0){return t[e]=this.r,t[e+1]=this.g,t[e+2]=this.b,t}fromBufferAttribute(t,e){return this.r=t.getX(e),this.g=t.getY(e),this.b=t.getZ(e),this}toJSON(){return this.getHex()}*[Symbol.iterator](){yield this.r,yield this.g,yield this.b}},Qe=new Xt;Xt.NAMES=ru;var rf=0,Ci=class extends Jn{constructor(){super(),this.isMaterial=!0,Object.defineProperty(this,"id",{value:rf++}),this.uuid=Hs(),this.name="",this.type="Material",this.blending=oi,this.side=Ti,this.vertexColors=!1,this.opacity=1,this.transparent=!1,this.alphaHash=!1,this.blendSrc=pr,this.blendDst=qo,this.blendEquation=ri,this.blendSrcAlpha=null,this.blendDstAlpha=null,this.blendEquationAlpha=null,this.blendColor=new Xt(0,0,0),this.blendAlpha=0,this.depthFunc=la,this.depthTest=!0,this.depthWrite=!0,this.stencilWriteMask=255,this.stencilFunc=Zc,this.stencilRef=0,this.stencilFuncMask=255,this.stencilFail=hs,this.stencilZFail=hs,this.stencilZPass=hs,this.stencilWrite=!1,this.clippingPlanes=null,this.clipIntersection=!1,this.clipShadows=!1,this.shadowSide=null,this.colorWrite=!0,this.precision=null,this.polygonOffset=!1,this.polygonOffsetFactor=0,this.polygonOffsetUnits=0,this.dithering=!1,this.alphaToCoverage=!1,this.premultipliedAlpha=!1,this.forceSinglePass=!1,this.visible=!0,this.toneMapped=!0,this.userData={},this.version=0,this._alphaTest=0}get alphaTest(){return this._alphaTest}set alphaTest(t){this._alphaTest>0!=t>0&&this.version++,this._alphaTest=t}onBuild(){}onBeforeRender(){}onBeforeCompile(){}customProgramCacheKey(){return this.onBeforeCompile.toString()}setValues(t){if(t!==void 0)for(let e in t){let n=t[e];if(n===void 0){console.warn(`THREE.Material: parameter '${e}' has value of undefined.`);continue}let s=this[e];if(s===void 0){console.warn(`THREE.Material: '${e}' is not a property of THREE.${this.type}.`);continue}s&&s.isColor?s.set(n):s&&s.isVector3&&n&&n.isVector3?s.copy(n):this[e]=n}}toJSON(t){let e=t===void 0||typeof t=="string";e&&(t={textures:{},images:{}});let n={metadata:{version:4.6,type:"Material",generator:"Material.toJSON"}};n.uuid=this.uuid,n.type=this.type,this.name!==""&&(n.name=this.name),this.color&&this.color.isColor&&(n.color=this.color.getHex()),this.roughness!==void 0&&(n.roughness=this.roughness),this.metalness!==void 0&&(n.metalness=this.metalness),this.sheen!==void 0&&(n.sheen=this.sheen),this.sheenColor&&this.sheenColor.isColor&&(n.sheenColor=this.sheenColor.getHex()),this.sheenRoughness!==void 0&&(n.sheenRoughness=this.sheenRoughness),this.emissive&&this.emissive.isColor&&(n.emissive=this.emissive.getHex()),this.emissiveIntensity&&this.emissiveIntensity!==1&&(n.emissiveIntensity=this.emissiveIntensity),this.specular&&this.specular.isColor&&(n.specular=this.specular.getHex()),this.specularIntensity!==void 0&&(n.specularIntensity=this.specularIntensity),this.specularColor&&this.specularColor.isColor&&(n.specularColor=this.specularColor.getHex()),this.shininess!==void 0&&(n.shininess=this.shininess),this.clearcoat!==void 0&&(n.clearcoat=this.clearcoat),this.clearcoatRoughness!==void 0&&(n.clearcoatRoughness=this.clearcoatRoughness),this.clearcoatMap&&this.clearcoatMap.isTexture&&(n.clearcoatMap=this.clearcoatMap.toJSON(t).uuid),this.clearcoatRoughnessMap&&this.clearcoatRoughnessMap.isTexture&&(n.clearcoatRoughnessMap=this.clearcoatRoughnessMap.toJSON(t).uuid),this.clearcoatNormalMap&&this.clearcoatNormalMap.isTexture&&(n.clearcoatNormalMap=this.clearcoatNormalMap.toJSON(t).uuid,n.clearcoatNormalScale=this.clearcoatNormalScale.toArray()),this.iridescence!==void 0&&(n.iridescence=this.iridescence),this.iridescenceIOR!==void 0&&(n.iridescenceIOR=this.iridescenceIOR),this.iridescenceThicknessRange!==void 0&&(n.iridescenceThicknessRange=this.iridescenceThicknessRange),this.iridescenceMap&&this.iridescenceMap.isTexture&&(n.iridescenceMap=this.iridescenceMap.toJSON(t).uuid),this.iridescenceThicknessMap&&this.iridescenceThicknessMap.isTexture&&(n.iridescenceThicknessMap=this.iridescenceThicknessMap.toJSON(t).uuid),this.anisotropy!==void 0&&(n.anisotropy=this.anisotropy),this.anisotropyRotation!==void 0&&(n.anisotropyRotation=this.anisotropyRotation),this.anisotropyMap&&this.anisotropyMap.isTexture&&(n.anisotropyMap=this.anisotropyMap.toJSON(t).uuid),this.map&&this.map.isTexture&&(n.map=this.map.toJSON(t).uuid),this.matcap&&this.matcap.isTexture&&(n.matcap=this.matcap.toJSON(t).uuid),this.alphaMap&&this.alphaMap.isTexture&&(n.alphaMap=this.alphaMap.toJSON(t).uuid),this.lightMap&&this.lightMap.isTexture&&(n.lightMap=this.lightMap.toJSON(t).uuid,n.lightMapIntensity=this.lightMapIntensity),this.aoMap&&this.aoMap.isTexture&&(n.aoMap=this.aoMap.toJSON(t).uuid,n.aoMapIntensity=this.aoMapIntensity),this.bumpMap&&this.bumpMap.isTexture&&(n.bumpMap=this.bumpMap.toJSON(t).uuid,n.bumpScale=this.bumpScale),this.normalMap&&this.normalMap.isTexture&&(n.normalMap=this.normalMap.toJSON(t).uuid,n.normalMapType=this.normalMapType,n.normalScale=this.normalScale.toArray()),this.displacementMap&&this.displacementMap.isTexture&&(n.displacementMap=this.displacementMap.toJSON(t).uuid,n.displacementScale=this.displacementScale,n.displacementBias=this.displacementBias),this.roughnessMap&&this.roughnessMap.isTexture&&(n.roughnessMap=this.roughnessMap.toJSON(t).uuid),this.metalnessMap&&this.metalnessMap.isTexture&&(n.metalnessMap=this.metalnessMap.toJSON(t).uuid),this.emissiveMap&&this.emissiveMap.isTexture&&(n.emissiveMap=this.emissiveMap.toJSON(t).uuid),this.specularMap&&this.specularMap.isTexture&&(n.specularMap=this.specularMap.toJSON(t).uuid),this.specularIntensityMap&&this.specularIntensityMap.isTexture&&(n.specularIntensityMap=this.specularIntensityMap.toJSON(t).uuid),this.specularColorMap&&this.specularColorMap.isTexture&&(n.specularColorMap=this.specularColorMap.toJSON(t).uuid),this.envMap&&this.envMap.isTexture&&(n.envMap=this.envMap.toJSON(t).uuid,this.combine!==void 0&&(n.combine=this.combine)),this.envMapIntensity!==void 0&&(n.envMapIntensity=this.envMapIntensity),this.reflectivity!==void 0&&(n.reflectivity=this.reflectivity),this.refractionRatio!==void 0&&(n.refractionRatio=this.refractionRatio),this.gradientMap&&this.gradientMap.isTexture&&(n.gradientMap=this.gradientMap.toJSON(t).uuid),this.transmission!==void 0&&(n.transmission=this.transmission),this.transmissionMap&&this.transmissionMap.isTexture&&(n.transmissionMap=this.transmissionMap.toJSON(t).uuid),this.thickness!==void 0&&(n.thickness=this.thickness),this.thicknessMap&&this.thicknessMap.isTexture&&(n.thicknessMap=this.thicknessMap.toJSON(t).uuid),this.attenuationDistance!==void 0&&this.attenuationDistance!==1/0&&(n.attenuationDistance=this.attenuationDistance),this.attenuationColor!==void 0&&(n.attenuationColor=this.attenuationColor.getHex()),this.size!==void 0&&(n.size=this.size),this.shadowSide!==null&&(n.shadowSide=this.shadowSide),this.sizeAttenuation!==void 0&&(n.sizeAttenuation=this.sizeAttenuation),this.blending!==oi&&(n.blending=this.blending),this.side!==Ti&&(n.side=this.side),this.vertexColors===!0&&(n.vertexColors=!0),this.opacity<1&&(n.opacity=this.opacity),this.transparent===!0&&(n.transparent=!0),this.blendSrc!==pr&&(n.blendSrc=this.blendSrc),this.blendDst!==qo&&(n.blendDst=this.blendDst),this.blendEquation!==ri&&(n.blendEquation=this.blendEquation),this.blendSrcAlpha!==null&&(n.blendSrcAlpha=this.blendSrcAlpha),this.blendDstAlpha!==null&&(n.blendDstAlpha=this.blendDstAlpha),this.blendEquationAlpha!==null&&(n.blendEquationAlpha=this.blendEquationAlpha),this.blendColor&&this.blendColor.isColor&&(n.blendColor=this.blendColor.getHex()),this.blendAlpha!==0&&(n.blendAlpha=this.blendAlpha),this.depthFunc!==la&&(n.depthFunc=this.depthFunc),this.depthTest===!1&&(n.depthTest=this.depthTest),this.depthWrite===!1&&(n.depthWrite=this.depthWrite),this.colorWrite===!1&&(n.colorWrite=this.colorWrite),this.stencilWriteMask!==255&&(n.stencilWriteMask=this.stencilWriteMask),this.stencilFunc!==Zc&&(n.stencilFunc=this.stencilFunc),this.stencilRef!==0&&(n.stencilRef=this.stencilRef),this.stencilFuncMask!==255&&(n.stencilFuncMask=this.stencilFuncMask),this.stencilFail!==hs&&(n.stencilFail=this.stencilFail),this.stencilZFail!==hs&&(n.stencilZFail=this.stencilZFail),this.stencilZPass!==hs&&(n.stencilZPass=this.stencilZPass),this.stencilWrite===!0&&(n.stencilWrite=this.stencilWrite),this.rotation!==void 0&&this.rotation!==0&&(n.rotation=this.rotation),this.polygonOffset===!0&&(n.polygonOffset=!0),this.polygonOffsetFactor!==0&&(n.polygonOffsetFactor=this.polygonOffsetFactor),this.polygonOffsetUnits!==0&&(n.polygonOffsetUnits=this.polygonOffsetUnits),this.linewidth!==void 0&&this.linewidth!==1&&(n.linewidth=this.linewidth),this.dashSize!==void 0&&(n.dashSize=this.dashSize),this.gapSize!==void 0&&(n.gapSize=this.gapSize),this.scale!==void 0&&(n.scale=this.scale),this.dithering===!0&&(n.dithering=!0),this.alphaTest>0&&(n.alphaTest=this.alphaTest),this.alphaHash===!0&&(n.alphaHash=!0),this.alphaToCoverage===!0&&(n.alphaToCoverage=!0),this.premultipliedAlpha===!0&&(n.premultipliedAlpha=!0),this.forceSinglePass===!0&&(n.forceSinglePass=!0),this.wireframe===!0&&(n.wireframe=!0),this.wireframeLinewidth>1&&(n.wireframeLinewidth=this.wireframeLinewidth),this.wireframeLinecap!=="round"&&(n.wireframeLinecap=this.wireframeLinecap),this.wireframeLinejoin!=="round"&&(n.wireframeLinejoin=this.wireframeLinejoin),this.flatShading===!0&&(n.flatShading=!0),this.visible===!1&&(n.visible=!1),this.toneMapped===!1&&(n.toneMapped=!1),this.fog===!1&&(n.fog=!1),Object.keys(this.userData).length>0&&(n.userData=this.userData);function s(r){let o=[];for(let a in r){let l=r[a];delete l.metadata,o.push(l)}return o}if(e){let r=s(t.textures),o=s(t.images);r.length>0&&(n.textures=r),o.length>0&&(n.images=o)}return n}clone(){return new this.constructor().copy(this)}copy(t){this.name=t.name,this.blending=t.blending,this.side=t.side,this.vertexColors=t.vertexColors,this.opacity=t.opacity,this.transparent=t.transparent,this.blendSrc=t.blendSrc,this.blendDst=t.blendDst,this.blendEquation=t.blendEquation,this.blendSrcAlpha=t.blendSrcAlpha,this.blendDstAlpha=t.blendDstAlpha,this.blendEquationAlpha=t.blendEquationAlpha,this.blendColor.copy(t.blendColor),this.blendAlpha=t.blendAlpha,this.depthFunc=t.depthFunc,this.depthTest=t.depthTest,this.depthWrite=t.depthWrite,this.stencilWriteMask=t.stencilWriteMask,this.stencilFunc=t.stencilFunc,this.stencilRef=t.stencilRef,this.stencilFuncMask=t.stencilFuncMask,this.stencilFail=t.stencilFail,this.stencilZFail=t.stencilZFail,this.stencilZPass=t.stencilZPass,this.stencilWrite=t.stencilWrite;let e=t.clippingPlanes,n=null;if(e!==null){let s=e.length;n=new Array(s);for(let r=0;r!==s;++r)n[r]=e[r].clone()}return this.clippingPlanes=n,this.clipIntersection=t.clipIntersection,this.clipShadows=t.clipShadows,this.shadowSide=t.shadowSide,this.colorWrite=t.colorWrite,this.precision=t.precision,this.polygonOffset=t.polygonOffset,this.polygonOffsetFactor=t.polygonOffsetFactor,this.polygonOffsetUnits=t.polygonOffsetUnits,this.dithering=t.dithering,this.alphaTest=t.alphaTest,this.alphaHash=t.alphaHash,this.alphaToCoverage=t.alphaToCoverage,this.premultipliedAlpha=t.premultipliedAlpha,this.forceSinglePass=t.forceSinglePass,this.visible=t.visible,this.toneMapped=t.toneMapped,this.userData=JSON.parse(JSON.stringify(t.userData)),this}dispose(){this.dispatchEvent({type:"dispose"})}set needsUpdate(t){t===!0&&this.version++}},wn=class extends Ci{constructor(t){super(),this.isMeshBasicMaterial=!0,this.type="MeshBasicMaterial",this.color=new Xt(16777215),this.map=null,this.lightMap=null,this.lightMapIntensity=1,this.aoMap=null,this.aoMapIntensity=1,this.specularMap=null,this.alphaMap=null,this.envMap=null,this.combine=Xh,this.reflectivity=1,this.refractionRatio=.98,this.wireframe=!1,this.wireframeLinewidth=1,this.wireframeLinecap="round",this.wireframeLinejoin="round",this.fog=!0,this.setValues(t)}copy(t){return super.copy(t),this.color.copy(t.color),this.map=t.map,this.lightMap=t.lightMap,this.lightMapIntensity=t.lightMapIntensity,this.aoMap=t.aoMap,this.aoMapIntensity=t.aoMapIntensity,this.specularMap=t.specularMap,this.alphaMap=t.alphaMap,this.envMap=t.envMap,this.combine=t.combine,this.reflectivity=t.reflectivity,this.refractionRatio=t.refractionRatio,this.wireframe=t.wireframe,this.wireframeLinewidth=t.wireframeLinewidth,this.wireframeLinecap=t.wireframeLinecap,this.wireframeLinejoin=t.wireframeLinejoin,this.fog=t.fog,this}};var Fe=new B,Yr=new At,cn=class{constructor(t,e,n=!1){if(Array.isArray(t))throw new TypeError("THREE.BufferAttribute: array should be a Typed Array.");this.isBufferAttribute=!0,this.name="",this.array=t,this.itemSize=e,this.count=t!==void 0?t.length/e:0,this.normalized=n,this.usage=Jc,this._updateRange={offset:0,count:-1},this.updateRanges=[],this.gpuType=Mi,this.version=0}onUploadCallback(){}set needsUpdate(t){t===!0&&this.version++}get updateRange(){return console.warn("THREE.BufferAttribute: updateRange() is deprecated and will be removed in r169. Use addUpdateRange() instead."),this._updateRange}setUsage(t){return this.usage=t,this}addUpdateRange(t,e){this.updateRanges.push({start:t,count:e})}clearUpdateRanges(){this.updateRanges.length=0}copy(t){return this.name=t.name,this.array=new t.array.constructor(t.array),this.itemSize=t.itemSize,this.count=t.count,this.normalized=t.normalized,this.usage=t.usage,this.gpuType=t.gpuType,this}copyAt(t,e,n){t*=this.itemSize,n*=e.itemSize;for(let s=0,r=this.itemSize;s<r;s++)this.array[t+s]=e.array[n+s];return this}copyArray(t){return this.array.set(t),this}applyMatrix3(t){if(this.itemSize===2)for(let e=0,n=this.count;e<n;e++)Yr.fromBufferAttribute(this,e),Yr.applyMatrix3(t),this.setXY(e,Yr.x,Yr.y);else if(this.itemSize===3)for(let e=0,n=this.count;e<n;e++)Fe.fromBufferAttribute(this,e),Fe.applyMatrix3(t),this.setXYZ(e,Fe.x,Fe.y,Fe.z);return this}applyMatrix4(t){for(let e=0,n=this.count;e<n;e++)Fe.fromBufferAttribute(this,e),Fe.applyMatrix4(t),this.setXYZ(e,Fe.x,Fe.y,Fe.z);return this}applyNormalMatrix(t){for(let e=0,n=this.count;e<n;e++)Fe.fromBufferAttribute(this,e),Fe.applyNormalMatrix(t),this.setXYZ(e,Fe.x,Fe.y,Fe.z);return this}transformDirection(t){for(let e=0,n=this.count;e<n;e++)Fe.fromBufferAttribute(this,e),Fe.transformDirection(t),this.setXYZ(e,Fe.x,Fe.y,Fe.z);return this}set(t,e=0){return this.array.set(t,e),this}getComponent(t,e){let n=this.array[t*this.itemSize+e];return this.normalized&&(n=As(n,this.array)),n}setComponent(t,e,n){return this.normalized&&(n=on(n,this.array)),this.array[t*this.itemSize+e]=n,this}getX(t){let e=this.array[t*this.itemSize];return this.normalized&&(e=As(e,this.array)),e}setX(t,e){return this.normalized&&(e=on(e,this.array)),this.array[t*this.itemSize]=e,this}getY(t){let e=this.array[t*this.itemSize+1];return this.normalized&&(e=As(e,this.array)),e}setY(t,e){return this.normalized&&(e=on(e,this.array)),this.array[t*this.itemSize+1]=e,this}getZ(t){let e=this.array[t*this.itemSize+2];return this.normalized&&(e=As(e,this.array)),e}setZ(t,e){return this.normalized&&(e=on(e,this.array)),this.array[t*this.itemSize+2]=e,this}getW(t){let e=this.array[t*this.itemSize+3];return this.normalized&&(e=As(e,this.array)),e}setW(t,e){return this.normalized&&(e=on(e,this.array)),this.array[t*this.itemSize+3]=e,this}setXY(t,e,n){return t*=this.itemSize,this.normalized&&(e=on(e,this.array),n=on(n,this.array)),this.array[t+0]=e,this.array[t+1]=n,this}setXYZ(t,e,n,s){return t*=this.itemSize,this.normalized&&(e=on(e,this.array),n=on(n,this.array),s=on(s,this.array)),this.array[t+0]=e,this.array[t+1]=n,this.array[t+2]=s,this}setXYZW(t,e,n,s,r){return t*=this.itemSize,this.normalized&&(e=on(e,this.array),n=on(n,this.array),s=on(s,this.array),r=on(r,this.array)),this.array[t+0]=e,this.array[t+1]=n,this.array[t+2]=s,this.array[t+3]=r,this}onUpload(t){return this.onUploadCallback=t,this}clone(){return new this.constructor(this.array,this.itemSize).copy(this)}toJSON(){let t={itemSize:this.itemSize,type:this.array.constructor.name,array:Array.from(this.array),normalized:this.normalized};return this.name!==""&&(t.name=this.name),this.usage!==Jc&&(t.usage=this.usage),t}};var ba=class extends cn{constructor(t,e,n){super(new Uint16Array(t),e,n)}};var Ma=class extends cn{constructor(t,e,n){super(new Uint32Array(t),e,n)}};var hn=class extends cn{constructor(t,e,n){super(new Float32Array(t),e,n)}};var af=0,bn=new _e,Fo=new nn,vs=new B,gn=new ci,ar=new ci,Xe=new B,_n=class i extends Jn{constructor(){super(),this.isBufferGeometry=!0,Object.defineProperty(this,"id",{value:af++}),this.uuid=Hs(),this.name="",this.type="BufferGeometry",this.index=null,this.attributes={},this.morphAttributes={},this.morphTargetsRelative=!1,this.groups=[],this.boundingBox=null,this.boundingSphere=null,this.drawRange={start:0,count:1/0},this.userData={}}getIndex(){return this.index}setIndex(t){return Array.isArray(t)?this.index=new(su(t)?Ma:ba)(t,1):this.index=t,this}getAttribute(t){return this.attributes[t]}setAttribute(t,e){return this.attributes[t]=e,this}deleteAttribute(t){return delete this.attributes[t],this}hasAttribute(t){return this.attributes[t]!==void 0}addGroup(t,e,n=0){this.groups.push({start:t,count:e,materialIndex:n})}clearGroups(){this.groups=[]}setDrawRange(t,e){this.drawRange.start=t,this.drawRange.count=e}applyMatrix4(t){let e=this.attributes.position;e!==void 0&&(e.applyMatrix4(t),e.needsUpdate=!0);let n=this.attributes.normal;if(n!==void 0){let r=new se().getNormalMatrix(t);n.applyNormalMatrix(r),n.needsUpdate=!0}let s=this.attributes.tangent;return s!==void 0&&(s.transformDirection(t),s.needsUpdate=!0),this.boundingBox!==null&&this.computeBoundingBox(),this.boundingSphere!==null&&this.computeBoundingSphere(),this}applyQuaternion(t){return bn.makeRotationFromQuaternion(t),this.applyMatrix4(bn),this}rotateX(t){return bn.makeRotationX(t),this.applyMatrix4(bn),this}rotateY(t){return bn.makeRotationY(t),this.applyMatrix4(bn),this}rotateZ(t){return bn.makeRotationZ(t),this.applyMatrix4(bn),this}translate(t,e,n){return bn.makeTranslation(t,e,n),this.applyMatrix4(bn),this}scale(t,e,n){return bn.makeScale(t,e,n),this.applyMatrix4(bn),this}lookAt(t){return Fo.lookAt(t),Fo.updateMatrix(),this.applyMatrix4(Fo.matrix),this}center(){return this.computeBoundingBox(),this.boundingBox.getCenter(vs).negate(),this.translate(vs.x,vs.y,vs.z),this}setFromPoints(t){let e=[];for(let n=0,s=t.length;n<s;n++){let r=t[n];e.push(r.x,r.y,r.z||0)}return this.setAttribute("position",new hn(e,3)),this}computeBoundingBox(){this.boundingBox===null&&(this.boundingBox=new ci);let t=this.attributes.position,e=this.morphAttributes.position;if(t&&t.isGLBufferAttribute){console.error('THREE.BufferGeometry.computeBoundingBox(): GLBufferAttribute requires a manual bounding box. Alternatively set "mesh.frustumCulled" to "false".',this),this.boundingBox.set(new B(-1/0,-1/0,-1/0),new B(1/0,1/0,1/0));return}if(t!==void 0){if(this.boundingBox.setFromBufferAttribute(t),e)for(let n=0,s=e.length;n<s;n++){let r=e[n];gn.setFromBufferAttribute(r),this.morphTargetsRelative?(Xe.addVectors(this.boundingBox.min,gn.min),this.boundingBox.expandByPoint(Xe),Xe.addVectors(this.boundingBox.max,gn.max),this.boundingBox.expandByPoint(Xe)):(this.boundingBox.expandByPoint(gn.min),this.boundingBox.expandByPoint(gn.max))}}else this.boundingBox.makeEmpty();(isNaN(this.boundingBox.min.x)||isNaN(this.boundingBox.min.y)||isNaN(this.boundingBox.min.z))&&console.error('THREE.BufferGeometry.computeBoundingBox(): Computed min/max have NaN values. The "position" attribute is likely to have NaN values.',this)}computeBoundingSphere(){this.boundingSphere===null&&(this.boundingSphere=new Ai);let t=this.attributes.position,e=this.morphAttributes.position;if(t&&t.isGLBufferAttribute){console.error('THREE.BufferGeometry.computeBoundingSphere(): GLBufferAttribute requires a manual bounding sphere. Alternatively set "mesh.frustumCulled" to "false".',this),this.boundingSphere.set(new B,1/0);return}if(t){let n=this.boundingSphere.center;if(gn.setFromBufferAttribute(t),e)for(let r=0,o=e.length;r<o;r++){let a=e[r];ar.setFromBufferAttribute(a),this.morphTargetsRelative?(Xe.addVectors(gn.min,ar.min),gn.expandByPoint(Xe),Xe.addVectors(gn.max,ar.max),gn.expandByPoint(Xe)):(gn.expandByPoint(ar.min),gn.expandByPoint(ar.max))}gn.getCenter(n);let s=0;for(let r=0,o=t.count;r<o;r++)Xe.fromBufferAttribute(t,r),s=Math.max(s,n.distanceToSquared(Xe));if(e)for(let r=0,o=e.length;r<o;r++){let a=e[r],l=this.morphTargetsRelative;for(let h=0,u=a.count;h<u;h++)Xe.fromBufferAttribute(a,h),l&&(vs.fromBufferAttribute(t,h),Xe.add(vs)),s=Math.max(s,n.distanceToSquared(Xe))}this.boundingSphere.radius=Math.sqrt(s),isNaN(this.boundingSphere.radius)&&console.error('THREE.BufferGeometry.computeBoundingSphere(): Computed radius is NaN. The "position" attribute is likely to have NaN values.',this)}}computeTangents(){let t=this.index,e=this.attributes;if(t===null||e.position===void 0||e.normal===void 0||e.uv===void 0){console.error("THREE.BufferGeometry: .computeTangents() failed. Missing required attributes (index, position, normal or uv)");return}let n=t.array,s=e.position.array,r=e.normal.array,o=e.uv.array,a=s.length/3;this.hasAttribute("tangent")===!1&&this.setAttribute("tangent",new cn(new Float32Array(4*a),4));let l=this.getAttribute("tangent").array,h=[],u=[];for(let A=0;A<a;A++)h[A]=new B,u[A]=new B;let d=new B,m=new B,x=new B,v=new At,M=new At,g=new At,f=new B,R=new B;function E(A,X,tt){d.fromArray(s,A*3),m.fromArray(s,X*3),x.fromArray(s,tt*3),v.fromArray(o,A*2),M.fromArray(o,X*2),g.fromArray(o,tt*2),m.sub(d),x.sub(d),M.sub(v),g.sub(v);let at=1/(M.x*g.y-g.x*M.y);isFinite(at)&&(f.copy(m).multiplyScalar(g.y).addScaledVector(x,-M.y).multiplyScalar(at),R.copy(x).multiplyScalar(M.x).addScaledVector(m,-g.x).multiplyScalar(at),h[A].add(f),h[X].add(f),h[tt].add(f),u[A].add(R),u[X].add(R),u[tt].add(R))}let L=this.groups;L.length===0&&(L=[{start:0,count:n.length}]);for(let A=0,X=L.length;A<X;++A){let tt=L[A],at=tt.start,F=tt.count;for(let V=at,Z=at+F;V<Z;V+=3)E(n[V+0],n[V+1],n[V+2])}let z=new B,N=new B,I=new B,it=new B;function w(A){I.fromArray(r,A*3),it.copy(I);let X=h[A];z.copy(X),z.sub(I.multiplyScalar(I.dot(X))).normalize(),N.crossVectors(it,X);let at=N.dot(u[A])<0?-1:1;l[A*4]=z.x,l[A*4+1]=z.y,l[A*4+2]=z.z,l[A*4+3]=at}for(let A=0,X=L.length;A<X;++A){let tt=L[A],at=tt.start,F=tt.count;for(let V=at,Z=at+F;V<Z;V+=3)w(n[V+0]),w(n[V+1]),w(n[V+2])}}computeVertexNormals(){let t=this.index,e=this.getAttribute("position");if(e!==void 0){let n=this.getAttribute("normal");if(n===void 0)n=new cn(new Float32Array(e.count*3),3),this.setAttribute("normal",n);else for(let m=0,x=n.count;m<x;m++)n.setXYZ(m,0,0,0);let s=new B,r=new B,o=new B,a=new B,l=new B,h=new B,u=new B,d=new B;if(t)for(let m=0,x=t.count;m<x;m+=3){let v=t.getX(m+0),M=t.getX(m+1),g=t.getX(m+2);s.fromBufferAttribute(e,v),r.fromBufferAttribute(e,M),o.fromBufferAttribute(e,g),u.subVectors(o,r),d.subVectors(s,r),u.cross(d),a.fromBufferAttribute(n,v),l.fromBufferAttribute(n,M),h.fromBufferAttribute(n,g),a.add(u),l.add(u),h.add(u),n.setXYZ(v,a.x,a.y,a.z),n.setXYZ(M,l.x,l.y,l.z),n.setXYZ(g,h.x,h.y,h.z)}else for(let m=0,x=e.count;m<x;m+=3)s.fromBufferAttribute(e,m+0),r.fromBufferAttribute(e,m+1),o.fromBufferAttribute(e,m+2),u.subVectors(o,r),d.subVectors(s,r),u.cross(d),n.setXYZ(m+0,u.x,u.y,u.z),n.setXYZ(m+1,u.x,u.y,u.z),n.setXYZ(m+2,u.x,u.y,u.z);this.normalizeNormals(),n.needsUpdate=!0}}normalizeNormals(){let t=this.attributes.normal;for(let e=0,n=t.count;e<n;e++)Xe.fromBufferAttribute(t,e),Xe.normalize(),t.setXYZ(e,Xe.x,Xe.y,Xe.z)}toNonIndexed(){function t(a,l){let h=a.array,u=a.itemSize,d=a.normalized,m=new h.constructor(l.length*u),x=0,v=0;for(let M=0,g=l.length;M<g;M++){a.isInterleavedBufferAttribute?x=l[M]*a.data.stride+a.offset:x=l[M]*u;for(let f=0;f<u;f++)m[v++]=h[x++]}return new cn(m,u,d)}if(this.index===null)return console.warn("THREE.BufferGeometry.toNonIndexed(): BufferGeometry is already non-indexed."),this;let e=new i,n=this.index.array,s=this.attributes;for(let a in s){let l=s[a],h=t(l,n);e.setAttribute(a,h)}let r=this.morphAttributes;for(let a in r){let l=[],h=r[a];for(let u=0,d=h.length;u<d;u++){let m=h[u],x=t(m,n);l.push(x)}e.morphAttributes[a]=l}e.morphTargetsRelative=this.morphTargetsRelative;let o=this.groups;for(let a=0,l=o.length;a<l;a++){let h=o[a];e.addGroup(h.start,h.count,h.materialIndex)}return e}toJSON(){let t={metadata:{version:4.6,type:"BufferGeometry",generator:"BufferGeometry.toJSON"}};if(t.uuid=this.uuid,t.type=this.type,this.name!==""&&(t.name=this.name),Object.keys(this.userData).length>0&&(t.userData=this.userData),this.parameters!==void 0){let l=this.parameters;for(let h in l)l[h]!==void 0&&(t[h]=l[h]);return t}t.data={attributes:{}};let e=this.index;e!==null&&(t.data.index={type:e.array.constructor.name,array:Array.prototype.slice.call(e.array)});let n=this.attributes;for(let l in n){let h=n[l];t.data.attributes[l]=h.toJSON(t.data)}let s={},r=!1;for(let l in this.morphAttributes){let h=this.morphAttributes[l],u=[];for(let d=0,m=h.length;d<m;d++){let x=h[d];u.push(x.toJSON(t.data))}u.length>0&&(s[l]=u,r=!0)}r&&(t.data.morphAttributes=s,t.data.morphTargetsRelative=this.morphTargetsRelative);let o=this.groups;o.length>0&&(t.data.groups=JSON.parse(JSON.stringify(o)));let a=this.boundingSphere;return a!==null&&(t.data.boundingSphere={center:a.center.toArray(),radius:a.radius}),t}clone(){return new this.constructor().copy(this)}copy(t){this.index=null,this.attributes={},this.morphAttributes={},this.groups=[],this.boundingBox=null,this.boundingSphere=null;let e={};this.name=t.name;let n=t.index;n!==null&&this.setIndex(n.clone(e));let s=t.attributes;for(let h in s){let u=s[h];this.setAttribute(h,u.clone(e))}let r=t.morphAttributes;for(let h in r){let u=[],d=r[h];for(let m=0,x=d.length;m<x;m++)u.push(d[m].clone(e));this.morphAttributes[h]=u}this.morphTargetsRelative=t.morphTargetsRelative;let o=t.groups;for(let h=0,u=o.length;h<u;h++){let d=o[h];this.addGroup(d.start,d.count,d.materialIndex)}let a=t.boundingBox;a!==null&&(this.boundingBox=a.clone());let l=t.boundingSphere;return l!==null&&(this.boundingSphere=l.clone()),this.drawRange.start=t.drawRange.start,this.drawRange.count=t.drawRange.count,this.userData=t.userData,this}dispose(){this.dispatchEvent({type:"dispose"})}},ch=new _e,zi=new qi,qr=new Ai,hh=new B,ys=new B,bs=new B,Ms=new B,Bo=new B,Zr=new B,Jr=new At,jr=new At,$r=new At,uh=new B,dh=new B,fh=new B,Kr=new B,Qr=new B,Je=class extends nn{constructor(t=new _n,e=new wn){super(),this.isMesh=!0,this.type="Mesh",this.geometry=t,this.material=e,this.updateMorphTargets()}copy(t,e){return super.copy(t,e),t.morphTargetInfluences!==void 0&&(this.morphTargetInfluences=t.morphTargetInfluences.slice()),t.morphTargetDictionary!==void 0&&(this.morphTargetDictionary=Object.assign({},t.morphTargetDictionary)),this.material=Array.isArray(t.material)?t.material.slice():t.material,this.geometry=t.geometry,this}updateMorphTargets(){let e=this.geometry.morphAttributes,n=Object.keys(e);if(n.length>0){let s=e[n[0]];if(s!==void 0){this.morphTargetInfluences=[],this.morphTargetDictionary={};for(let r=0,o=s.length;r<o;r++){let a=s[r].name||String(r);this.morphTargetInfluences.push(0),this.morphTargetDictionary[a]=r}}}}getVertexPosition(t,e){let n=this.geometry,s=n.attributes.position,r=n.morphAttributes.position,o=n.morphTargetsRelative;e.fromBufferAttribute(s,t);let a=this.morphTargetInfluences;if(r&&a){Zr.set(0,0,0);for(let l=0,h=r.length;l<h;l++){let u=a[l],d=r[l];u!==0&&(Bo.fromBufferAttribute(d,t),o?Zr.addScaledVector(Bo,u):Zr.addScaledVector(Bo.sub(e),u))}e.add(Zr)}return e}raycast(t,e){let n=this.geometry,s=this.material,r=this.matrixWorld;s!==void 0&&(n.boundingSphere===null&&n.computeBoundingSphere(),qr.copy(n.boundingSphere),qr.applyMatrix4(r),zi.copy(t.ray).recast(t.near),!(qr.containsPoint(zi.origin)===!1&&(zi.intersectSphere(qr,hh)===null||zi.origin.distanceToSquared(hh)>(t.far-t.near)**2))&&(ch.copy(r).invert(),zi.copy(t.ray).applyMatrix4(ch),!(n.boundingBox!==null&&zi.intersectsBox(n.boundingBox)===!1)&&this._computeIntersections(t,e,zi)))}_computeIntersections(t,e,n){let s,r=this.geometry,o=this.material,a=r.index,l=r.attributes.position,h=r.attributes.uv,u=r.attributes.uv1,d=r.attributes.normal,m=r.groups,x=r.drawRange;if(a!==null)if(Array.isArray(o))for(let v=0,M=m.length;v<M;v++){let g=m[v],f=o[g.materialIndex],R=Math.max(g.start,x.start),E=Math.min(a.count,Math.min(g.start+g.count,x.start+x.count));for(let L=R,z=E;L<z;L+=3){let N=a.getX(L),I=a.getX(L+1),it=a.getX(L+2);s=ta(this,f,t,n,h,u,d,N,I,it),s&&(s.faceIndex=Math.floor(L/3),s.face.materialIndex=g.materialIndex,e.push(s))}}else{let v=Math.max(0,x.start),M=Math.min(a.count,x.start+x.count);for(let g=v,f=M;g<f;g+=3){let R=a.getX(g),E=a.getX(g+1),L=a.getX(g+2);s=ta(this,o,t,n,h,u,d,R,E,L),s&&(s.faceIndex=Math.floor(g/3),e.push(s))}}else if(l!==void 0)if(Array.isArray(o))for(let v=0,M=m.length;v<M;v++){let g=m[v],f=o[g.materialIndex],R=Math.max(g.start,x.start),E=Math.min(l.count,Math.min(g.start+g.count,x.start+x.count));for(let L=R,z=E;L<z;L+=3){let N=L,I=L+1,it=L+2;s=ta(this,f,t,n,h,u,d,N,I,it),s&&(s.faceIndex=Math.floor(L/3),s.face.materialIndex=g.materialIndex,e.push(s))}}else{let v=Math.max(0,x.start),M=Math.min(l.count,x.start+x.count);for(let g=v,f=M;g<f;g+=3){let R=g,E=g+1,L=g+2;s=ta(this,o,t,n,h,u,d,R,E,L),s&&(s.faceIndex=Math.floor(g/3),e.push(s))}}}};function of(i,t,e,n,s,r,o,a){let l;if(t.side===pn?l=n.intersectTriangle(o,r,s,!0,a):l=n.intersectTriangle(s,r,o,t.side===Ti,a),l===null)return null;Qr.copy(a),Qr.applyMatrix4(i.matrixWorld);let h=e.ray.origin.distanceTo(Qr);return h<e.near||h>e.far?null:{distance:h,point:Qr.clone(),object:i}}function ta(i,t,e,n,s,r,o,a,l,h){i.getVertexPosition(a,ys),i.getVertexPosition(l,bs),i.getVertexPosition(h,Ms);let u=of(i,t,e,n,ys,bs,Ms,Kr);if(u){s&&(Jr.fromBufferAttribute(s,a),jr.fromBufferAttribute(s,l),$r.fromBufferAttribute(s,h),u.uv=Cs.getInterpolation(Kr,ys,bs,Ms,Jr,jr,$r,new At)),r&&(Jr.fromBufferAttribute(r,a),jr.fromBufferAttribute(r,l),$r.fromBufferAttribute(r,h),u.uv1=Cs.getInterpolation(Kr,ys,bs,Ms,Jr,jr,$r,new At),u.uv2=u.uv1),o&&(uh.fromBufferAttribute(o,a),dh.fromBufferAttribute(o,l),fh.fromBufferAttribute(o,h),u.normal=Cs.getInterpolation(Kr,ys,bs,Ms,uh,dh,fh,new B),u.normal.dot(n.direction)>0&&u.normal.multiplyScalar(-1));let d={a,b:l,c:h,normal:new B,materialIndex:0};Cs.getNormal(ys,bs,Ms,d.normal),u.face=d}return u}var Zi=class i extends _n{constructor(t=1,e=1,n=1,s=1,r=1,o=1){super(),this.type="BoxGeometry",this.parameters={width:t,height:e,depth:n,widthSegments:s,heightSegments:r,depthSegments:o};let a=this;s=Math.floor(s),r=Math.floor(r),o=Math.floor(o);let l=[],h=[],u=[],d=[],m=0,x=0;v("z","y","x",-1,-1,n,e,t,o,r,0),v("z","y","x",1,-1,n,e,-t,o,r,1),v("x","z","y",1,1,t,n,e,s,o,2),v("x","z","y",1,-1,t,n,-e,s,o,3),v("x","y","z",1,-1,t,e,n,s,r,4),v("x","y","z",-1,-1,t,e,-n,s,r,5),this.setIndex(l),this.setAttribute("position",new hn(h,3)),this.setAttribute("normal",new hn(u,3)),this.setAttribute("uv",new hn(d,2));function v(M,g,f,R,E,L,z,N,I,it,w){let A=L/I,X=z/it,tt=L/2,at=z/2,F=N/2,V=I+1,Z=it+1,k=0,$=0,K=new B;for(let et=0;et<Z;et++){let rt=et*X-at;for(let vt=0;vt<V;vt++){let G=vt*A-tt;K[M]=G*R,K[g]=rt*E,K[f]=F,h.push(K.x,K.y,K.z),K[M]=0,K[g]=0,K[f]=N>0?1:-1,u.push(K.x,K.y,K.z),d.push(vt/I),d.push(1-et/it),k+=1}}for(let et=0;et<it;et++)for(let rt=0;rt<I;rt++){let vt=m+rt+V*et,G=m+rt+V*(et+1),nt=m+(rt+1)+V*(et+1),mt=m+(rt+1)+V*et;l.push(vt,G,mt),l.push(G,nt,mt),$+=6}a.addGroup(x,$,w),x+=$,m+=k}}copy(t){return super.copy(t),this.parameters=Object.assign({},t.parameters),this}static fromJSON(t){return new i(t.width,t.height,t.depth,t.widthSegments,t.heightSegments,t.depthSegments)}};function Fs(i){let t={};for(let e in i){t[e]={};for(let n in i[e]){let s=i[e][n];s&&(s.isColor||s.isMatrix3||s.isMatrix4||s.isVector2||s.isVector3||s.isVector4||s.isTexture||s.isQuaternion)?s.isRenderTargetTexture?(console.warn("UniformsUtils: Textures of render targets cannot be cloned via cloneUniforms() or mergeUniforms()."),t[e][n]=null):t[e][n]=s.clone():Array.isArray(s)?t[e][n]=s.slice():t[e][n]=s}}return t}function ln(i){let t={};for(let e=0;e<i.length;e++){let n=Fs(i[e]);for(let s in n)t[s]=n[s]}return t}function lf(i){let t=[];for(let e=0;e<i.length;e++)t.push(i[e].clone());return t}function au(i){return i.getRenderTarget()===null?i.outputColorSpace:fe.workingColorSpace}var Ri={clone:Fs,merge:ln},cf=`void main() {
	gl_Position = projectionMatrix * modelViewMatrix * vec4( position, 1.0 );
}`,hf=`void main() {
	gl_FragColor = vec4( 1.0, 0.0, 0.0, 1.0 );
}`,Be=class extends Ci{constructor(t){super(),this.isShaderMaterial=!0,this.type="ShaderMaterial",this.defines={},this.uniforms={},this.uniformsGroups=[],this.vertexShader=cf,this.fragmentShader=hf,this.linewidth=1,this.wireframe=!1,this.wireframeLinewidth=1,this.fog=!1,this.lights=!1,this.clipping=!1,this.forceSinglePass=!0,this.extensions={derivatives:!1,fragDepth:!1,drawBuffers:!1,shaderTextureLOD:!1,clipCullDistance:!1},this.defaultAttributeValues={color:[1,1,1],uv:[0,0],uv1:[0,0]},this.index0AttributeName=void 0,this.uniformsNeedUpdate=!1,this.glslVersion=null,t!==void 0&&this.setValues(t)}copy(t){return super.copy(t),this.fragmentShader=t.fragmentShader,this.vertexShader=t.vertexShader,this.uniforms=Fs(t.uniforms),this.uniformsGroups=lf(t.uniformsGroups),this.defines=Object.assign({},t.defines),this.wireframe=t.wireframe,this.wireframeLinewidth=t.wireframeLinewidth,this.fog=t.fog,this.lights=t.lights,this.clipping=t.clipping,this.extensions=Object.assign({},t.extensions),this.glslVersion=t.glslVersion,this}toJSON(t){let e=super.toJSON(t);e.glslVersion=this.glslVersion,e.uniforms={};for(let s in this.uniforms){let o=this.uniforms[s].value;o&&o.isTexture?e.uniforms[s]={type:"t",value:o.toJSON(t).uuid}:o&&o.isColor?e.uniforms[s]={type:"c",value:o.getHex()}:o&&o.isVector2?e.uniforms[s]={type:"v2",value:o.toArray()}:o&&o.isVector3?e.uniforms[s]={type:"v3",value:o.toArray()}:o&&o.isVector4?e.uniforms[s]={type:"v4",value:o.toArray()}:o&&o.isMatrix3?e.uniforms[s]={type:"m3",value:o.toArray()}:o&&o.isMatrix4?e.uniforms[s]={type:"m4",value:o.toArray()}:e.uniforms[s]={value:o}}Object.keys(this.defines).length>0&&(e.defines=this.defines),e.vertexShader=this.vertexShader,e.fragmentShader=this.fragmentShader,e.lights=this.lights,e.clipping=this.clipping;let n={};for(let s in this.extensions)this.extensions[s]===!0&&(n[s]=!0);return Object.keys(n).length>0&&(e.extensions=n),e}},Sa=class extends nn{constructor(){super(),this.isCamera=!0,this.type="Camera",this.matrixWorldInverse=new _e,this.projectionMatrix=new _e,this.projectionMatrixInverse=new _e,this.coordinateSystem=ai}copy(t,e){return super.copy(t,e),this.matrixWorldInverse.copy(t.matrixWorldInverse),this.projectionMatrix.copy(t.projectionMatrix),this.projectionMatrixInverse.copy(t.projectionMatrixInverse),this.coordinateSystem=t.coordinateSystem,this}getWorldDirection(t){return super.getWorldDirection(t).negate()}updateMatrixWorld(t){super.updateMatrixWorld(t),this.matrixWorldInverse.copy(this.matrixWorld).invert()}updateWorldMatrix(t,e){super.updateWorldMatrix(t,e),this.matrixWorldInverse.copy(this.matrixWorld).invert()}clone(){return new this.constructor().copy(this)}},en=class extends Sa{constructor(t=50,e=1,n=.1,s=2e3){super(),this.isPerspectiveCamera=!0,this.type="PerspectiveCamera",this.fov=t,this.zoom=1,this.near=n,this.far=s,this.focus=10,this.aspect=e,this.view=null,this.filmGauge=35,this.filmOffset=0,this.updateProjectionMatrix()}copy(t,e){return super.copy(t,e),this.fov=t.fov,this.zoom=t.zoom,this.near=t.near,this.far=t.far,this.focus=t.focus,this.aspect=t.aspect,this.view=t.view===null?null:Object.assign({},t.view),this.filmGauge=t.filmGauge,this.filmOffset=t.filmOffset,this}setFocalLength(t){let e=.5*this.getFilmHeight()/t;this.fov=gr*2*Math.atan(e),this.updateProjectionMatrix()}getFocalLength(){let t=Math.tan(hr*.5*this.fov);return .5*this.getFilmHeight()/t}getEffectiveFOV(){return gr*2*Math.atan(Math.tan(hr*.5*this.fov)/this.zoom)}getFilmWidth(){return this.filmGauge*Math.min(this.aspect,1)}getFilmHeight(){return this.filmGauge/Math.max(this.aspect,1)}setViewOffset(t,e,n,s,r,o){this.aspect=t/e,this.view===null&&(this.view={enabled:!0,fullWidth:1,fullHeight:1,offsetX:0,offsetY:0,width:1,height:1}),this.view.enabled=!0,this.view.fullWidth=t,this.view.fullHeight=e,this.view.offsetX=n,this.view.offsetY=s,this.view.width=r,this.view.height=o,this.updateProjectionMatrix()}clearViewOffset(){this.view!==null&&(this.view.enabled=!1),this.updateProjectionMatrix()}updateProjectionMatrix(){let t=this.near,e=t*Math.tan(hr*.5*this.fov)/this.zoom,n=2*e,s=this.aspect*n,r=-.5*s,o=this.view;if(this.view!==null&&this.view.enabled){let l=o.fullWidth,h=o.fullHeight;r+=o.offsetX*s/l,e-=o.offsetY*n/h,s*=o.width/l,n*=o.height/h}let a=this.filmOffset;a!==0&&(r+=t*a/this.getFilmWidth()),this.projectionMatrix.makePerspective(r,r+s,e,e-n,t,this.far,this.coordinateSystem),this.projectionMatrixInverse.copy(this.projectionMatrix).invert()}toJSON(t){let e=super.toJSON(t);return e.object.fov=this.fov,e.object.zoom=this.zoom,e.object.near=this.near,e.object.far=this.far,e.object.focus=this.focus,e.object.aspect=this.aspect,this.view!==null&&(e.object.view=Object.assign({},this.view)),e.object.filmGauge=this.filmGauge,e.object.filmOffset=this.filmOffset,e}},Ss=-90,ws=1,el=class extends nn{constructor(t,e,n){super(),this.type="CubeCamera",this.renderTarget=n,this.coordinateSystem=null,this.activeMipmapLevel=0;let s=new en(Ss,ws,t,e);s.layers=this.layers,this.add(s);let r=new en(Ss,ws,t,e);r.layers=this.layers,this.add(r);let o=new en(Ss,ws,t,e);o.layers=this.layers,this.add(o);let a=new en(Ss,ws,t,e);a.layers=this.layers,this.add(a);let l=new en(Ss,ws,t,e);l.layers=this.layers,this.add(l);let h=new en(Ss,ws,t,e);h.layers=this.layers,this.add(h)}updateCoordinateSystem(){let t=this.coordinateSystem,e=this.children.concat(),[n,s,r,o,a,l]=e;for(let h of e)this.remove(h);if(t===ai)n.up.set(0,1,0),n.lookAt(1,0,0),s.up.set(0,1,0),s.lookAt(-1,0,0),r.up.set(0,0,-1),r.lookAt(0,1,0),o.up.set(0,0,1),o.lookAt(0,-1,0),a.up.set(0,1,0),a.lookAt(0,0,1),l.up.set(0,1,0),l.lookAt(0,0,-1);else if(t===pa)n.up.set(0,-1,0),n.lookAt(-1,0,0),s.up.set(0,-1,0),s.lookAt(1,0,0),r.up.set(0,0,1),r.lookAt(0,1,0),o.up.set(0,0,-1),o.lookAt(0,-1,0),a.up.set(0,-1,0),a.lookAt(0,0,1),l.up.set(0,-1,0),l.lookAt(0,0,-1);else throw new Error("THREE.CubeCamera.updateCoordinateSystem(): Invalid coordinate system: "+t);for(let h of e)this.add(h),h.updateMatrixWorld()}update(t,e){this.parent===null&&this.updateMatrixWorld();let{renderTarget:n,activeMipmapLevel:s}=this;this.coordinateSystem!==t.coordinateSystem&&(this.coordinateSystem=t.coordinateSystem,this.updateCoordinateSystem());let[r,o,a,l,h,u]=this.children,d=t.getRenderTarget(),m=t.getActiveCubeFace(),x=t.getActiveMipmapLevel(),v=t.xr.enabled;t.xr.enabled=!1;let M=n.texture.generateMipmaps;n.texture.generateMipmaps=!1,t.setRenderTarget(n,0,s),t.render(e,r),t.setRenderTarget(n,1,s),t.render(e,o),t.setRenderTarget(n,2,s),t.render(e,a),t.setRenderTarget(n,3,s),t.render(e,l),t.setRenderTarget(n,4,s),t.render(e,h),n.texture.generateMipmaps=M,t.setRenderTarget(n,5,s),t.render(e,u),t.setRenderTarget(d,m,x),t.xr.enabled=v,n.texture.needsPMREMUpdate=!0}},wa=class extends Sn{constructor(t,e,n,s,r,o,a,l,h,u){t=t!==void 0?t:[],e=e!==void 0?e:Us,super(t,e,n,s,r,o,a,l,h,u),this.isCubeTexture=!0,this.flipY=!1}get images(){return this.image}set images(t){this.image=t}},nl=class extends je{constructor(t=1,e={}){super(t,t,e),this.isWebGLCubeRenderTarget=!0;let n={width:t,height:t,depth:1},s=[n,n,n,n,n,n];e.encoding!==void 0&&(dr("THREE.WebGLCubeRenderTarget: option.encoding has been replaced by option.colorSpace."),e.colorSpace=e.encoding===Xi?Re:fn),this.texture=new wa(s,e.mapping,e.wrapS,e.wrapT,e.magFilter,e.minFilter,e.format,e.type,e.anisotropy,e.colorSpace),this.texture.isRenderTargetTexture=!0,this.texture.generateMipmaps=e.generateMipmaps!==void 0?e.generateMipmaps:!1,this.texture.minFilter=e.minFilter!==void 0?e.minFilter:Mn}fromEquirectangularTexture(t,e){this.texture.type=e.type,this.texture.colorSpace=e.colorSpace,this.texture.generateMipmaps=e.generateMipmaps,this.texture.minFilter=e.minFilter,this.texture.magFilter=e.magFilter;let n={uniforms:{tEquirect:{value:null}},vertexShader:`

				varying vec3 vWorldDirection;

				vec3 transformDirection( in vec3 dir, in mat4 matrix ) {

					return normalize( ( matrix * vec4( dir, 0.0 ) ).xyz );

				}

				void main() {

					vWorldDirection = transformDirection( position, modelMatrix );

					#include <begin_vertex>
					#include <project_vertex>

				}
			`,fragmentShader:`

				uniform sampler2D tEquirect;

				varying vec3 vWorldDirection;

				#include <common>

				void main() {

					vec3 direction = normalize( vWorldDirection );

					vec2 sampleUV = equirectUv( direction );

					gl_FragColor = texture2D( tEquirect, sampleUV );

				}
			`},s=new Zi(5,5,5),r=new Be({name:"CubemapFromEquirect",uniforms:Fs(n.uniforms),vertexShader:n.vertexShader,fragmentShader:n.fragmentShader,side:pn,blending:Zn});r.uniforms.tEquirect.value=e;let o=new Je(s,r),a=e.minFilter;return e.minFilter===Yi&&(e.minFilter=Mn),new el(1,10,this).update(t,o),e.minFilter=a,o.geometry.dispose(),o.material.dispose(),this}clear(t,e,n,s){let r=t.getRenderTarget();for(let o=0;o<6;o++)t.setRenderTarget(this,o),t.clear(e,n,s);t.setRenderTarget(r)}},zo=new B,uf=new B,df=new se,Dn=class{constructor(t=new B(1,0,0),e=0){this.isPlane=!0,this.normal=t,this.constant=e}set(t,e){return this.normal.copy(t),this.constant=e,this}setComponents(t,e,n,s){return this.normal.set(t,e,n),this.constant=s,this}setFromNormalAndCoplanarPoint(t,e){return this.normal.copy(t),this.constant=-e.dot(this.normal),this}setFromCoplanarPoints(t,e,n){let s=zo.subVectors(n,e).cross(uf.subVectors(t,e)).normalize();return this.setFromNormalAndCoplanarPoint(s,t),this}copy(t){return this.normal.copy(t.normal),this.constant=t.constant,this}normalize(){let t=1/this.normal.length();return this.normal.multiplyScalar(t),this.constant*=t,this}negate(){return this.constant*=-1,this.normal.negate(),this}distanceToPoint(t){return this.normal.dot(t)+this.constant}distanceToSphere(t){return this.distanceToPoint(t.center)-t.radius}projectPoint(t,e){return e.copy(t).addScaledVector(this.normal,-this.distanceToPoint(t))}intersectLine(t,e){let n=t.delta(zo),s=this.normal.dot(n);if(s===0)return this.distanceToPoint(t.start)===0?e.copy(t.start):null;let r=-(t.start.dot(this.normal)+this.constant)/s;return r<0||r>1?null:e.copy(t.start).addScaledVector(n,r)}intersectsLine(t){let e=this.distanceToPoint(t.start),n=this.distanceToPoint(t.end);return e<0&&n>0||n<0&&e>0}intersectsBox(t){return t.intersectsPlane(this)}intersectsSphere(t){return t.intersectsPlane(this)}coplanarPoint(t){return t.copy(this.normal).multiplyScalar(-this.constant)}applyMatrix4(t,e){let n=e||df.getNormalMatrix(t),s=this.coplanarPoint(zo).applyMatrix4(t),r=this.normal.applyMatrix3(n).normalize();return this.constant=-s.dot(r),this}translate(t){return this.constant-=t.dot(this.normal),this}equals(t){return t.normal.equals(this.normal)&&t.constant===this.constant}clone(){return new this.constructor().copy(this)}},ki=new Ai,ea=new B,_r=class{constructor(t=new Dn,e=new Dn,n=new Dn,s=new Dn,r=new Dn,o=new Dn){this.planes=[t,e,n,s,r,o]}set(t,e,n,s,r,o){let a=this.planes;return a[0].copy(t),a[1].copy(e),a[2].copy(n),a[3].copy(s),a[4].copy(r),a[5].copy(o),this}copy(t){let e=this.planes;for(let n=0;n<6;n++)e[n].copy(t.planes[n]);return this}setFromProjectionMatrix(t,e=ai){let n=this.planes,s=t.elements,r=s[0],o=s[1],a=s[2],l=s[3],h=s[4],u=s[5],d=s[6],m=s[7],x=s[8],v=s[9],M=s[10],g=s[11],f=s[12],R=s[13],E=s[14],L=s[15];if(n[0].setComponents(l-r,m-h,g-x,L-f).normalize(),n[1].setComponents(l+r,m+h,g+x,L+f).normalize(),n[2].setComponents(l+o,m+u,g+v,L+R).normalize(),n[3].setComponents(l-o,m-u,g-v,L-R).normalize(),n[4].setComponents(l-a,m-d,g-M,L-E).normalize(),e===ai)n[5].setComponents(l+a,m+d,g+M,L+E).normalize();else if(e===pa)n[5].setComponents(a,d,M,E).normalize();else throw new Error("THREE.Frustum.setFromProjectionMatrix(): Invalid coordinate system: "+e);return this}intersectsObject(t){if(t.boundingSphere!==void 0)t.boundingSphere===null&&t.computeBoundingSphere(),ki.copy(t.boundingSphere).applyMatrix4(t.matrixWorld);else{let e=t.geometry;e.boundingSphere===null&&e.computeBoundingSphere(),ki.copy(e.boundingSphere).applyMatrix4(t.matrixWorld)}return this.intersectsSphere(ki)}intersectsSprite(t){return ki.center.set(0,0,0),ki.radius=.7071067811865476,ki.applyMatrix4(t.matrixWorld),this.intersectsSphere(ki)}intersectsSphere(t){let e=this.planes,n=t.center,s=-t.radius;for(let r=0;r<6;r++)if(e[r].distanceToPoint(n)<s)return!1;return!0}intersectsBox(t){let e=this.planes;for(let n=0;n<6;n++){let s=e[n];if(ea.x=s.normal.x>0?t.max.x:t.min.x,ea.y=s.normal.y>0?t.max.y:t.min.y,ea.z=s.normal.z>0?t.max.z:t.min.z,s.distanceToPoint(ea)<0)return!1}return!0}containsPoint(t){let e=this.planes;for(let n=0;n<6;n++)if(e[n].distanceToPoint(t)<0)return!1;return!0}clone(){return new this.constructor().copy(this)}};function ou(){let i=null,t=!1,e=null,n=null;function s(r,o){e(r,o),n=i.requestAnimationFrame(s)}return{start:function(){t!==!0&&e!==null&&(n=i.requestAnimationFrame(s),t=!0)},stop:function(){i.cancelAnimationFrame(n),t=!1},setAnimationLoop:function(r){e=r},setContext:function(r){i=r}}}function ff(i,t){let e=t.isWebGL2,n=new WeakMap;function s(h,u){let d=h.array,m=h.usage,x=d.byteLength,v=i.createBuffer();i.bindBuffer(u,v),i.bufferData(u,d,m),h.onUploadCallback();let M;if(d instanceof Float32Array)M=i.FLOAT;else if(d instanceof Uint16Array)if(h.isFloat16BufferAttribute)if(e)M=i.HALF_FLOAT;else throw new Error("THREE.WebGLAttributes: Usage of Float16BufferAttribute requires WebGL2.");else M=i.UNSIGNED_SHORT;else if(d instanceof Int16Array)M=i.SHORT;else if(d instanceof Uint32Array)M=i.UNSIGNED_INT;else if(d instanceof Int32Array)M=i.INT;else if(d instanceof Int8Array)M=i.BYTE;else if(d instanceof Uint8Array)M=i.UNSIGNED_BYTE;else if(d instanceof Uint8ClampedArray)M=i.UNSIGNED_BYTE;else throw new Error("THREE.WebGLAttributes: Unsupported buffer data format: "+d);return{buffer:v,type:M,bytesPerElement:d.BYTES_PER_ELEMENT,version:h.version,size:x}}function r(h,u,d){let m=u.array,x=u._updateRange,v=u.updateRanges;if(i.bindBuffer(d,h),x.count===-1&&v.length===0&&i.bufferSubData(d,0,m),v.length!==0){for(let M=0,g=v.length;M<g;M++){let f=v[M];e?i.bufferSubData(d,f.start*m.BYTES_PER_ELEMENT,m,f.start,f.count):i.bufferSubData(d,f.start*m.BYTES_PER_ELEMENT,m.subarray(f.start,f.start+f.count))}u.clearUpdateRanges()}x.count!==-1&&(e?i.bufferSubData(d,x.offset*m.BYTES_PER_ELEMENT,m,x.offset,x.count):i.bufferSubData(d,x.offset*m.BYTES_PER_ELEMENT,m.subarray(x.offset,x.offset+x.count)),x.count=-1),u.onUploadCallback()}function o(h){return h.isInterleavedBufferAttribute&&(h=h.data),n.get(h)}function a(h){h.isInterleavedBufferAttribute&&(h=h.data);let u=n.get(h);u&&(i.deleteBuffer(u.buffer),n.delete(h))}function l(h,u){if(h.isGLBufferAttribute){let m=n.get(h);(!m||m.version<h.version)&&n.set(h,{buffer:h.buffer,type:h.type,bytesPerElement:h.elementSize,version:h.version});return}h.isInterleavedBufferAttribute&&(h=h.data);let d=n.get(h);if(d===void 0)n.set(h,s(h,u));else if(d.version<h.version){if(d.size!==h.array.byteLength)throw new Error("THREE.WebGLAttributes: The size of the buffer attribute's array buffer does not match the original size. Resizing buffer attributes is not supported.");r(d.buffer,h,u),d.version=h.version}}return{get:o,remove:a,update:l}}var vr=class i extends _n{constructor(t=1,e=1,n=1,s=1){super(),this.type="PlaneGeometry",this.parameters={width:t,height:e,widthSegments:n,heightSegments:s};let r=t/2,o=e/2,a=Math.floor(n),l=Math.floor(s),h=a+1,u=l+1,d=t/a,m=e/l,x=[],v=[],M=[],g=[];for(let f=0;f<u;f++){let R=f*m-o;for(let E=0;E<h;E++){let L=E*d-r;v.push(L,-R,0),M.push(0,0,1),g.push(E/a),g.push(1-f/l)}}for(let f=0;f<l;f++)for(let R=0;R<a;R++){let E=R+h*f,L=R+h*(f+1),z=R+1+h*(f+1),N=R+1+h*f;x.push(E,L,N),x.push(L,z,N)}this.setIndex(x),this.setAttribute("position",new hn(v,3)),this.setAttribute("normal",new hn(M,3)),this.setAttribute("uv",new hn(g,2))}copy(t){return super.copy(t),this.parameters=Object.assign({},t.parameters),this}static fromJSON(t){return new i(t.width,t.height,t.widthSegments,t.heightSegments)}},pf=`#ifdef USE_ALPHAHASH
	if ( diffuseColor.a < getAlphaHashThreshold( vPosition ) ) discard;
#endif`,mf=`#ifdef USE_ALPHAHASH
	const float ALPHA_HASH_SCALE = 0.05;
	float hash2D( vec2 value ) {
		return fract( 1.0e4 * sin( 17.0 * value.x + 0.1 * value.y ) * ( 0.1 + abs( sin( 13.0 * value.y + value.x ) ) ) );
	}
	float hash3D( vec3 value ) {
		return hash2D( vec2( hash2D( value.xy ), value.z ) );
	}
	float getAlphaHashThreshold( vec3 position ) {
		float maxDeriv = max(
			length( dFdx( position.xyz ) ),
			length( dFdy( position.xyz ) )
		);
		float pixScale = 1.0 / ( ALPHA_HASH_SCALE * maxDeriv );
		vec2 pixScales = vec2(
			exp2( floor( log2( pixScale ) ) ),
			exp2( ceil( log2( pixScale ) ) )
		);
		vec2 alpha = vec2(
			hash3D( floor( pixScales.x * position.xyz ) ),
			hash3D( floor( pixScales.y * position.xyz ) )
		);
		float lerpFactor = fract( log2( pixScale ) );
		float x = ( 1.0 - lerpFactor ) * alpha.x + lerpFactor * alpha.y;
		float a = min( lerpFactor, 1.0 - lerpFactor );
		vec3 cases = vec3(
			x * x / ( 2.0 * a * ( 1.0 - a ) ),
			( x - 0.5 * a ) / ( 1.0 - a ),
			1.0 - ( ( 1.0 - x ) * ( 1.0 - x ) / ( 2.0 * a * ( 1.0 - a ) ) )
		);
		float threshold = ( x < ( 1.0 - a ) )
			? ( ( x < a ) ? cases.x : cases.y )
			: cases.z;
		return clamp( threshold , 1.0e-6, 1.0 );
	}
#endif`,gf=`#ifdef USE_ALPHAMAP
	diffuseColor.a *= texture2D( alphaMap, vAlphaMapUv ).g;
#endif`,xf=`#ifdef USE_ALPHAMAP
	uniform sampler2D alphaMap;
#endif`,_f=`#ifdef USE_ALPHATEST
	if ( diffuseColor.a < alphaTest ) discard;
#endif`,vf=`#ifdef USE_ALPHATEST
	uniform float alphaTest;
#endif`,yf=`#ifdef USE_AOMAP
	float ambientOcclusion = ( texture2D( aoMap, vAoMapUv ).r - 1.0 ) * aoMapIntensity + 1.0;
	reflectedLight.indirectDiffuse *= ambientOcclusion;
	#if defined( USE_CLEARCOAT ) 
		clearcoatSpecularIndirect *= ambientOcclusion;
	#endif
	#if defined( USE_SHEEN ) 
		sheenSpecularIndirect *= ambientOcclusion;
	#endif
	#if defined( USE_ENVMAP ) && defined( STANDARD )
		float dotNV = saturate( dot( geometryNormal, geometryViewDir ) );
		reflectedLight.indirectSpecular *= computeSpecularOcclusion( dotNV, ambientOcclusion, material.roughness );
	#endif
#endif`,bf=`#ifdef USE_AOMAP
	uniform sampler2D aoMap;
	uniform float aoMapIntensity;
#endif`,Mf=`#ifdef USE_BATCHING
	attribute float batchId;
	uniform highp sampler2D batchingTexture;
	mat4 getBatchingMatrix( const in float i ) {
		int size = textureSize( batchingTexture, 0 ).x;
		int j = int( i ) * 4;
		int x = j % size;
		int y = j / size;
		vec4 v1 = texelFetch( batchingTexture, ivec2( x, y ), 0 );
		vec4 v2 = texelFetch( batchingTexture, ivec2( x + 1, y ), 0 );
		vec4 v3 = texelFetch( batchingTexture, ivec2( x + 2, y ), 0 );
		vec4 v4 = texelFetch( batchingTexture, ivec2( x + 3, y ), 0 );
		return mat4( v1, v2, v3, v4 );
	}
#endif`,Sf=`#ifdef USE_BATCHING
	mat4 batchingMatrix = getBatchingMatrix( batchId );
#endif`,wf=`vec3 transformed = vec3( position );
#ifdef USE_ALPHAHASH
	vPosition = vec3( position );
#endif`,Ef=`vec3 objectNormal = vec3( normal );
#ifdef USE_TANGENT
	vec3 objectTangent = vec3( tangent.xyz );
#endif`,Tf=`float G_BlinnPhong_Implicit( ) {
	return 0.25;
}
float D_BlinnPhong( const in float shininess, const in float dotNH ) {
	return RECIPROCAL_PI * ( shininess * 0.5 + 1.0 ) * pow( dotNH, shininess );
}
vec3 BRDF_BlinnPhong( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, const in vec3 specularColor, const in float shininess ) {
	vec3 halfDir = normalize( lightDir + viewDir );
	float dotNH = saturate( dot( normal, halfDir ) );
	float dotVH = saturate( dot( viewDir, halfDir ) );
	vec3 F = F_Schlick( specularColor, 1.0, dotVH );
	float G = G_BlinnPhong_Implicit( );
	float D = D_BlinnPhong( shininess, dotNH );
	return F * ( G * D );
} // validated`,Af=`#ifdef USE_IRIDESCENCE
	const mat3 XYZ_TO_REC709 = mat3(
		 3.2404542, -0.9692660,  0.0556434,
		-1.5371385,  1.8760108, -0.2040259,
		-0.4985314,  0.0415560,  1.0572252
	);
	vec3 Fresnel0ToIor( vec3 fresnel0 ) {
		vec3 sqrtF0 = sqrt( fresnel0 );
		return ( vec3( 1.0 ) + sqrtF0 ) / ( vec3( 1.0 ) - sqrtF0 );
	}
	vec3 IorToFresnel0( vec3 transmittedIor, float incidentIor ) {
		return pow2( ( transmittedIor - vec3( incidentIor ) ) / ( transmittedIor + vec3( incidentIor ) ) );
	}
	float IorToFresnel0( float transmittedIor, float incidentIor ) {
		return pow2( ( transmittedIor - incidentIor ) / ( transmittedIor + incidentIor ));
	}
	vec3 evalSensitivity( float OPD, vec3 shift ) {
		float phase = 2.0 * PI * OPD * 1.0e-9;
		vec3 val = vec3( 5.4856e-13, 4.4201e-13, 5.2481e-13 );
		vec3 pos = vec3( 1.6810e+06, 1.7953e+06, 2.2084e+06 );
		vec3 var = vec3( 4.3278e+09, 9.3046e+09, 6.6121e+09 );
		vec3 xyz = val * sqrt( 2.0 * PI * var ) * cos( pos * phase + shift ) * exp( - pow2( phase ) * var );
		xyz.x += 9.7470e-14 * sqrt( 2.0 * PI * 4.5282e+09 ) * cos( 2.2399e+06 * phase + shift[ 0 ] ) * exp( - 4.5282e+09 * pow2( phase ) );
		xyz /= 1.0685e-7;
		vec3 rgb = XYZ_TO_REC709 * xyz;
		return rgb;
	}
	vec3 evalIridescence( float outsideIOR, float eta2, float cosTheta1, float thinFilmThickness, vec3 baseF0 ) {
		vec3 I;
		float iridescenceIOR = mix( outsideIOR, eta2, smoothstep( 0.0, 0.03, thinFilmThickness ) );
		float sinTheta2Sq = pow2( outsideIOR / iridescenceIOR ) * ( 1.0 - pow2( cosTheta1 ) );
		float cosTheta2Sq = 1.0 - sinTheta2Sq;
		if ( cosTheta2Sq < 0.0 ) {
			return vec3( 1.0 );
		}
		float cosTheta2 = sqrt( cosTheta2Sq );
		float R0 = IorToFresnel0( iridescenceIOR, outsideIOR );
		float R12 = F_Schlick( R0, 1.0, cosTheta1 );
		float T121 = 1.0 - R12;
		float phi12 = 0.0;
		if ( iridescenceIOR < outsideIOR ) phi12 = PI;
		float phi21 = PI - phi12;
		vec3 baseIOR = Fresnel0ToIor( clamp( baseF0, 0.0, 0.9999 ) );		vec3 R1 = IorToFresnel0( baseIOR, iridescenceIOR );
		vec3 R23 = F_Schlick( R1, 1.0, cosTheta2 );
		vec3 phi23 = vec3( 0.0 );
		if ( baseIOR[ 0 ] < iridescenceIOR ) phi23[ 0 ] = PI;
		if ( baseIOR[ 1 ] < iridescenceIOR ) phi23[ 1 ] = PI;
		if ( baseIOR[ 2 ] < iridescenceIOR ) phi23[ 2 ] = PI;
		float OPD = 2.0 * iridescenceIOR * thinFilmThickness * cosTheta2;
		vec3 phi = vec3( phi21 ) + phi23;
		vec3 R123 = clamp( R12 * R23, 1e-5, 0.9999 );
		vec3 r123 = sqrt( R123 );
		vec3 Rs = pow2( T121 ) * R23 / ( vec3( 1.0 ) - R123 );
		vec3 C0 = R12 + Rs;
		I = C0;
		vec3 Cm = Rs - T121;
		for ( int m = 1; m <= 2; ++ m ) {
			Cm *= r123;
			vec3 Sm = 2.0 * evalSensitivity( float( m ) * OPD, float( m ) * phi );
			I += Cm * Sm;
		}
		return max( I, vec3( 0.0 ) );
	}
#endif`,Cf=`#ifdef USE_BUMPMAP
	uniform sampler2D bumpMap;
	uniform float bumpScale;
	vec2 dHdxy_fwd() {
		vec2 dSTdx = dFdx( vBumpMapUv );
		vec2 dSTdy = dFdy( vBumpMapUv );
		float Hll = bumpScale * texture2D( bumpMap, vBumpMapUv ).x;
		float dBx = bumpScale * texture2D( bumpMap, vBumpMapUv + dSTdx ).x - Hll;
		float dBy = bumpScale * texture2D( bumpMap, vBumpMapUv + dSTdy ).x - Hll;
		return vec2( dBx, dBy );
	}
	vec3 perturbNormalArb( vec3 surf_pos, vec3 surf_norm, vec2 dHdxy, float faceDirection ) {
		vec3 vSigmaX = normalize( dFdx( surf_pos.xyz ) );
		vec3 vSigmaY = normalize( dFdy( surf_pos.xyz ) );
		vec3 vN = surf_norm;
		vec3 R1 = cross( vSigmaY, vN );
		vec3 R2 = cross( vN, vSigmaX );
		float fDet = dot( vSigmaX, R1 ) * faceDirection;
		vec3 vGrad = sign( fDet ) * ( dHdxy.x * R1 + dHdxy.y * R2 );
		return normalize( abs( fDet ) * surf_norm - vGrad );
	}
#endif`,Rf=`#if NUM_CLIPPING_PLANES > 0
	vec4 plane;
	#pragma unroll_loop_start
	for ( int i = 0; i < UNION_CLIPPING_PLANES; i ++ ) {
		plane = clippingPlanes[ i ];
		if ( dot( vClipPosition, plane.xyz ) > plane.w ) discard;
	}
	#pragma unroll_loop_end
	#if UNION_CLIPPING_PLANES < NUM_CLIPPING_PLANES
		bool clipped = true;
		#pragma unroll_loop_start
		for ( int i = UNION_CLIPPING_PLANES; i < NUM_CLIPPING_PLANES; i ++ ) {
			plane = clippingPlanes[ i ];
			clipped = ( dot( vClipPosition, plane.xyz ) > plane.w ) && clipped;
		}
		#pragma unroll_loop_end
		if ( clipped ) discard;
	#endif
#endif`,Pf=`#if NUM_CLIPPING_PLANES > 0
	varying vec3 vClipPosition;
	uniform vec4 clippingPlanes[ NUM_CLIPPING_PLANES ];
#endif`,Lf=`#if NUM_CLIPPING_PLANES > 0
	varying vec3 vClipPosition;
#endif`,If=`#if NUM_CLIPPING_PLANES > 0
	vClipPosition = - mvPosition.xyz;
#endif`,Df=`#if defined( USE_COLOR_ALPHA )
	diffuseColor *= vColor;
#elif defined( USE_COLOR )
	diffuseColor.rgb *= vColor;
#endif`,Uf=`#if defined( USE_COLOR_ALPHA )
	varying vec4 vColor;
#elif defined( USE_COLOR )
	varying vec3 vColor;
#endif`,Nf=`#if defined( USE_COLOR_ALPHA )
	varying vec4 vColor;
#elif defined( USE_COLOR ) || defined( USE_INSTANCING_COLOR )
	varying vec3 vColor;
#endif`,Of=`#if defined( USE_COLOR_ALPHA )
	vColor = vec4( 1.0 );
#elif defined( USE_COLOR ) || defined( USE_INSTANCING_COLOR )
	vColor = vec3( 1.0 );
#endif
#ifdef USE_COLOR
	vColor *= color;
#endif
#ifdef USE_INSTANCING_COLOR
	vColor.xyz *= instanceColor.xyz;
#endif`,Ff=`#define PI 3.141592653589793
#define PI2 6.283185307179586
#define PI_HALF 1.5707963267948966
#define RECIPROCAL_PI 0.3183098861837907
#define RECIPROCAL_PI2 0.15915494309189535
#define EPSILON 1e-6
#ifndef saturate
#define saturate( a ) clamp( a, 0.0, 1.0 )
#endif
#define whiteComplement( a ) ( 1.0 - saturate( a ) )
float pow2( const in float x ) { return x*x; }
vec3 pow2( const in vec3 x ) { return x*x; }
float pow3( const in float x ) { return x*x*x; }
float pow4( const in float x ) { float x2 = x*x; return x2*x2; }
float max3( const in vec3 v ) { return max( max( v.x, v.y ), v.z ); }
float average( const in vec3 v ) { return dot( v, vec3( 0.3333333 ) ); }
highp float rand( const in vec2 uv ) {
	const highp float a = 12.9898, b = 78.233, c = 43758.5453;
	highp float dt = dot( uv.xy, vec2( a,b ) ), sn = mod( dt, PI );
	return fract( sin( sn ) * c );
}
#ifdef HIGH_PRECISION
	float precisionSafeLength( vec3 v ) { return length( v ); }
#else
	float precisionSafeLength( vec3 v ) {
		float maxComponent = max3( abs( v ) );
		return length( v / maxComponent ) * maxComponent;
	}
#endif
struct IncidentLight {
	vec3 color;
	vec3 direction;
	bool visible;
};
struct ReflectedLight {
	vec3 directDiffuse;
	vec3 directSpecular;
	vec3 indirectDiffuse;
	vec3 indirectSpecular;
};
#ifdef USE_ALPHAHASH
	varying vec3 vPosition;
#endif
vec3 transformDirection( in vec3 dir, in mat4 matrix ) {
	return normalize( ( matrix * vec4( dir, 0.0 ) ).xyz );
}
vec3 inverseTransformDirection( in vec3 dir, in mat4 matrix ) {
	return normalize( ( vec4( dir, 0.0 ) * matrix ).xyz );
}
mat3 transposeMat3( const in mat3 m ) {
	mat3 tmp;
	tmp[ 0 ] = vec3( m[ 0 ].x, m[ 1 ].x, m[ 2 ].x );
	tmp[ 1 ] = vec3( m[ 0 ].y, m[ 1 ].y, m[ 2 ].y );
	tmp[ 2 ] = vec3( m[ 0 ].z, m[ 1 ].z, m[ 2 ].z );
	return tmp;
}
float luminance( const in vec3 rgb ) {
	const vec3 weights = vec3( 0.2126729, 0.7151522, 0.0721750 );
	return dot( weights, rgb );
}
bool isPerspectiveMatrix( mat4 m ) {
	return m[ 2 ][ 3 ] == - 1.0;
}
vec2 equirectUv( in vec3 dir ) {
	float u = atan( dir.z, dir.x ) * RECIPROCAL_PI2 + 0.5;
	float v = asin( clamp( dir.y, - 1.0, 1.0 ) ) * RECIPROCAL_PI + 0.5;
	return vec2( u, v );
}
vec3 BRDF_Lambert( const in vec3 diffuseColor ) {
	return RECIPROCAL_PI * diffuseColor;
}
vec3 F_Schlick( const in vec3 f0, const in float f90, const in float dotVH ) {
	float fresnel = exp2( ( - 5.55473 * dotVH - 6.98316 ) * dotVH );
	return f0 * ( 1.0 - fresnel ) + ( f90 * fresnel );
}
float F_Schlick( const in float f0, const in float f90, const in float dotVH ) {
	float fresnel = exp2( ( - 5.55473 * dotVH - 6.98316 ) * dotVH );
	return f0 * ( 1.0 - fresnel ) + ( f90 * fresnel );
} // validated`,Bf=`#ifdef ENVMAP_TYPE_CUBE_UV
	#define cubeUV_minMipLevel 4.0
	#define cubeUV_minTileSize 16.0
	float getFace( vec3 direction ) {
		vec3 absDirection = abs( direction );
		float face = - 1.0;
		if ( absDirection.x > absDirection.z ) {
			if ( absDirection.x > absDirection.y )
				face = direction.x > 0.0 ? 0.0 : 3.0;
			else
				face = direction.y > 0.0 ? 1.0 : 4.0;
		} else {
			if ( absDirection.z > absDirection.y )
				face = direction.z > 0.0 ? 2.0 : 5.0;
			else
				face = direction.y > 0.0 ? 1.0 : 4.0;
		}
		return face;
	}
	vec2 getUV( vec3 direction, float face ) {
		vec2 uv;
		if ( face == 0.0 ) {
			uv = vec2( direction.z, direction.y ) / abs( direction.x );
		} else if ( face == 1.0 ) {
			uv = vec2( - direction.x, - direction.z ) / abs( direction.y );
		} else if ( face == 2.0 ) {
			uv = vec2( - direction.x, direction.y ) / abs( direction.z );
		} else if ( face == 3.0 ) {
			uv = vec2( - direction.z, direction.y ) / abs( direction.x );
		} else if ( face == 4.0 ) {
			uv = vec2( - direction.x, direction.z ) / abs( direction.y );
		} else {
			uv = vec2( direction.x, direction.y ) / abs( direction.z );
		}
		return 0.5 * ( uv + 1.0 );
	}
	vec3 bilinearCubeUV( sampler2D envMap, vec3 direction, float mipInt ) {
		float face = getFace( direction );
		float filterInt = max( cubeUV_minMipLevel - mipInt, 0.0 );
		mipInt = max( mipInt, cubeUV_minMipLevel );
		float faceSize = exp2( mipInt );
		highp vec2 uv = getUV( direction, face ) * ( faceSize - 2.0 ) + 1.0;
		if ( face > 2.0 ) {
			uv.y += faceSize;
			face -= 3.0;
		}
		uv.x += face * faceSize;
		uv.x += filterInt * 3.0 * cubeUV_minTileSize;
		uv.y += 4.0 * ( exp2( CUBEUV_MAX_MIP ) - faceSize );
		uv.x *= CUBEUV_TEXEL_WIDTH;
		uv.y *= CUBEUV_TEXEL_HEIGHT;
		#ifdef texture2DGradEXT
			return texture2DGradEXT( envMap, uv, vec2( 0.0 ), vec2( 0.0 ) ).rgb;
		#else
			return texture2D( envMap, uv ).rgb;
		#endif
	}
	#define cubeUV_r0 1.0
	#define cubeUV_m0 - 2.0
	#define cubeUV_r1 0.8
	#define cubeUV_m1 - 1.0
	#define cubeUV_r4 0.4
	#define cubeUV_m4 2.0
	#define cubeUV_r5 0.305
	#define cubeUV_m5 3.0
	#define cubeUV_r6 0.21
	#define cubeUV_m6 4.0
	float roughnessToMip( float roughness ) {
		float mip = 0.0;
		if ( roughness >= cubeUV_r1 ) {
			mip = ( cubeUV_r0 - roughness ) * ( cubeUV_m1 - cubeUV_m0 ) / ( cubeUV_r0 - cubeUV_r1 ) + cubeUV_m0;
		} else if ( roughness >= cubeUV_r4 ) {
			mip = ( cubeUV_r1 - roughness ) * ( cubeUV_m4 - cubeUV_m1 ) / ( cubeUV_r1 - cubeUV_r4 ) + cubeUV_m1;
		} else if ( roughness >= cubeUV_r5 ) {
			mip = ( cubeUV_r4 - roughness ) * ( cubeUV_m5 - cubeUV_m4 ) / ( cubeUV_r4 - cubeUV_r5 ) + cubeUV_m4;
		} else if ( roughness >= cubeUV_r6 ) {
			mip = ( cubeUV_r5 - roughness ) * ( cubeUV_m6 - cubeUV_m5 ) / ( cubeUV_r5 - cubeUV_r6 ) + cubeUV_m5;
		} else {
			mip = - 2.0 * log2( 1.16 * roughness );		}
		return mip;
	}
	vec4 textureCubeUV( sampler2D envMap, vec3 sampleDir, float roughness ) {
		float mip = clamp( roughnessToMip( roughness ), cubeUV_m0, CUBEUV_MAX_MIP );
		float mipF = fract( mip );
		float mipInt = floor( mip );
		vec3 color0 = bilinearCubeUV( envMap, sampleDir, mipInt );
		if ( mipF == 0.0 ) {
			return vec4( color0, 1.0 );
		} else {
			vec3 color1 = bilinearCubeUV( envMap, sampleDir, mipInt + 1.0 );
			return vec4( mix( color0, color1, mipF ), 1.0 );
		}
	}
#endif`,zf=`vec3 transformedNormal = objectNormal;
#ifdef USE_TANGENT
	vec3 transformedTangent = objectTangent;
#endif
#ifdef USE_BATCHING
	mat3 bm = mat3( batchingMatrix );
	transformedNormal /= vec3( dot( bm[ 0 ], bm[ 0 ] ), dot( bm[ 1 ], bm[ 1 ] ), dot( bm[ 2 ], bm[ 2 ] ) );
	transformedNormal = bm * transformedNormal;
	#ifdef USE_TANGENT
		transformedTangent = bm * transformedTangent;
	#endif
#endif
#ifdef USE_INSTANCING
	mat3 im = mat3( instanceMatrix );
	transformedNormal /= vec3( dot( im[ 0 ], im[ 0 ] ), dot( im[ 1 ], im[ 1 ] ), dot( im[ 2 ], im[ 2 ] ) );
	transformedNormal = im * transformedNormal;
	#ifdef USE_TANGENT
		transformedTangent = im * transformedTangent;
	#endif
#endif
transformedNormal = normalMatrix * transformedNormal;
#ifdef FLIP_SIDED
	transformedNormal = - transformedNormal;
#endif
#ifdef USE_TANGENT
	transformedTangent = ( modelViewMatrix * vec4( transformedTangent, 0.0 ) ).xyz;
	#ifdef FLIP_SIDED
		transformedTangent = - transformedTangent;
	#endif
#endif`,kf=`#ifdef USE_DISPLACEMENTMAP
	uniform sampler2D displacementMap;
	uniform float displacementScale;
	uniform float displacementBias;
#endif`,Hf=`#ifdef USE_DISPLACEMENTMAP
	transformed += normalize( objectNormal ) * ( texture2D( displacementMap, vDisplacementMapUv ).x * displacementScale + displacementBias );
#endif`,Vf=`#ifdef USE_EMISSIVEMAP
	vec4 emissiveColor = texture2D( emissiveMap, vEmissiveMapUv );
	totalEmissiveRadiance *= emissiveColor.rgb;
#endif`,Gf=`#ifdef USE_EMISSIVEMAP
	uniform sampler2D emissiveMap;
#endif`,Wf="gl_FragColor = linearToOutputTexel( gl_FragColor );",Xf=`
const mat3 LINEAR_SRGB_TO_LINEAR_DISPLAY_P3 = mat3(
	vec3( 0.8224621, 0.177538, 0.0 ),
	vec3( 0.0331941, 0.9668058, 0.0 ),
	vec3( 0.0170827, 0.0723974, 0.9105199 )
);
const mat3 LINEAR_DISPLAY_P3_TO_LINEAR_SRGB = mat3(
	vec3( 1.2249401, - 0.2249404, 0.0 ),
	vec3( - 0.0420569, 1.0420571, 0.0 ),
	vec3( - 0.0196376, - 0.0786361, 1.0982735 )
);
vec4 LinearSRGBToLinearDisplayP3( in vec4 value ) {
	return vec4( value.rgb * LINEAR_SRGB_TO_LINEAR_DISPLAY_P3, value.a );
}
vec4 LinearDisplayP3ToLinearSRGB( in vec4 value ) {
	return vec4( value.rgb * LINEAR_DISPLAY_P3_TO_LINEAR_SRGB, value.a );
}
vec4 LinearTransferOETF( in vec4 value ) {
	return value;
}
vec4 sRGBTransferOETF( in vec4 value ) {
	return vec4( mix( pow( value.rgb, vec3( 0.41666 ) ) * 1.055 - vec3( 0.055 ), value.rgb * 12.92, vec3( lessThanEqual( value.rgb, vec3( 0.0031308 ) ) ) ), value.a );
}
vec4 LinearToLinear( in vec4 value ) {
	return value;
}
vec4 LinearTosRGB( in vec4 value ) {
	return sRGBTransferOETF( value );
}`,Yf=`#ifdef USE_ENVMAP
	#ifdef ENV_WORLDPOS
		vec3 cameraToFrag;
		if ( isOrthographic ) {
			cameraToFrag = normalize( vec3( - viewMatrix[ 0 ][ 2 ], - viewMatrix[ 1 ][ 2 ], - viewMatrix[ 2 ][ 2 ] ) );
		} else {
			cameraToFrag = normalize( vWorldPosition - cameraPosition );
		}
		vec3 worldNormal = inverseTransformDirection( normal, viewMatrix );
		#ifdef ENVMAP_MODE_REFLECTION
			vec3 reflectVec = reflect( cameraToFrag, worldNormal );
		#else
			vec3 reflectVec = refract( cameraToFrag, worldNormal, refractionRatio );
		#endif
	#else
		vec3 reflectVec = vReflect;
	#endif
	#ifdef ENVMAP_TYPE_CUBE
		vec4 envColor = textureCube( envMap, vec3( flipEnvMap * reflectVec.x, reflectVec.yz ) );
	#else
		vec4 envColor = vec4( 0.0 );
	#endif
	#ifdef ENVMAP_BLENDING_MULTIPLY
		outgoingLight = mix( outgoingLight, outgoingLight * envColor.xyz, specularStrength * reflectivity );
	#elif defined( ENVMAP_BLENDING_MIX )
		outgoingLight = mix( outgoingLight, envColor.xyz, specularStrength * reflectivity );
	#elif defined( ENVMAP_BLENDING_ADD )
		outgoingLight += envColor.xyz * specularStrength * reflectivity;
	#endif
#endif`,qf=`#ifdef USE_ENVMAP
	uniform float envMapIntensity;
	uniform float flipEnvMap;
	#ifdef ENVMAP_TYPE_CUBE
		uniform samplerCube envMap;
	#else
		uniform sampler2D envMap;
	#endif
	
#endif`,Zf=`#ifdef USE_ENVMAP
	uniform float reflectivity;
	#if defined( USE_BUMPMAP ) || defined( USE_NORMALMAP ) || defined( PHONG ) || defined( LAMBERT )
		#define ENV_WORLDPOS
	#endif
	#ifdef ENV_WORLDPOS
		varying vec3 vWorldPosition;
		uniform float refractionRatio;
	#else
		varying vec3 vReflect;
	#endif
#endif`,Jf=`#ifdef USE_ENVMAP
	#if defined( USE_BUMPMAP ) || defined( USE_NORMALMAP ) || defined( PHONG ) || defined( LAMBERT )
		#define ENV_WORLDPOS
	#endif
	#ifdef ENV_WORLDPOS
		
		varying vec3 vWorldPosition;
	#else
		varying vec3 vReflect;
		uniform float refractionRatio;
	#endif
#endif`,jf=`#ifdef USE_ENVMAP
	#ifdef ENV_WORLDPOS
		vWorldPosition = worldPosition.xyz;
	#else
		vec3 cameraToVertex;
		if ( isOrthographic ) {
			cameraToVertex = normalize( vec3( - viewMatrix[ 0 ][ 2 ], - viewMatrix[ 1 ][ 2 ], - viewMatrix[ 2 ][ 2 ] ) );
		} else {
			cameraToVertex = normalize( worldPosition.xyz - cameraPosition );
		}
		vec3 worldNormal = inverseTransformDirection( transformedNormal, viewMatrix );
		#ifdef ENVMAP_MODE_REFLECTION
			vReflect = reflect( cameraToVertex, worldNormal );
		#else
			vReflect = refract( cameraToVertex, worldNormal, refractionRatio );
		#endif
	#endif
#endif`,$f=`#ifdef USE_FOG
	vFogDepth = - mvPosition.z;
#endif`,Kf=`#ifdef USE_FOG
	varying float vFogDepth;
#endif`,Qf=`#ifdef USE_FOG
	#ifdef FOG_EXP2
		float fogFactor = 1.0 - exp( - fogDensity * fogDensity * vFogDepth * vFogDepth );
	#else
		float fogFactor = smoothstep( fogNear, fogFar, vFogDepth );
	#endif
	gl_FragColor.rgb = mix( gl_FragColor.rgb, fogColor, fogFactor );
#endif`,tp=`#ifdef USE_FOG
	uniform vec3 fogColor;
	varying float vFogDepth;
	#ifdef FOG_EXP2
		uniform float fogDensity;
	#else
		uniform float fogNear;
		uniform float fogFar;
	#endif
#endif`,ep=`#ifdef USE_GRADIENTMAP
	uniform sampler2D gradientMap;
#endif
vec3 getGradientIrradiance( vec3 normal, vec3 lightDirection ) {
	float dotNL = dot( normal, lightDirection );
	vec2 coord = vec2( dotNL * 0.5 + 0.5, 0.0 );
	#ifdef USE_GRADIENTMAP
		return vec3( texture2D( gradientMap, coord ).r );
	#else
		vec2 fw = fwidth( coord ) * 0.5;
		return mix( vec3( 0.7 ), vec3( 1.0 ), smoothstep( 0.7 - fw.x, 0.7 + fw.x, coord.x ) );
	#endif
}`,np=`#ifdef USE_LIGHTMAP
	vec4 lightMapTexel = texture2D( lightMap, vLightMapUv );
	vec3 lightMapIrradiance = lightMapTexel.rgb * lightMapIntensity;
	reflectedLight.indirectDiffuse += lightMapIrradiance;
#endif`,ip=`#ifdef USE_LIGHTMAP
	uniform sampler2D lightMap;
	uniform float lightMapIntensity;
#endif`,sp=`LambertMaterial material;
material.diffuseColor = diffuseColor.rgb;
material.specularStrength = specularStrength;`,rp=`varying vec3 vViewPosition;
struct LambertMaterial {
	vec3 diffuseColor;
	float specularStrength;
};
void RE_Direct_Lambert( const in IncidentLight directLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in LambertMaterial material, inout ReflectedLight reflectedLight ) {
	float dotNL = saturate( dot( geometryNormal, directLight.direction ) );
	vec3 irradiance = dotNL * directLight.color;
	reflectedLight.directDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
void RE_IndirectDiffuse_Lambert( const in vec3 irradiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in LambertMaterial material, inout ReflectedLight reflectedLight ) {
	reflectedLight.indirectDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
#define RE_Direct				RE_Direct_Lambert
#define RE_IndirectDiffuse		RE_IndirectDiffuse_Lambert`,ap=`uniform bool receiveShadow;
uniform vec3 ambientLightColor;
#if defined( USE_LIGHT_PROBES )
	uniform vec3 lightProbe[ 9 ];
#endif
vec3 shGetIrradianceAt( in vec3 normal, in vec3 shCoefficients[ 9 ] ) {
	float x = normal.x, y = normal.y, z = normal.z;
	vec3 result = shCoefficients[ 0 ] * 0.886227;
	result += shCoefficients[ 1 ] * 2.0 * 0.511664 * y;
	result += shCoefficients[ 2 ] * 2.0 * 0.511664 * z;
	result += shCoefficients[ 3 ] * 2.0 * 0.511664 * x;
	result += shCoefficients[ 4 ] * 2.0 * 0.429043 * x * y;
	result += shCoefficients[ 5 ] * 2.0 * 0.429043 * y * z;
	result += shCoefficients[ 6 ] * ( 0.743125 * z * z - 0.247708 );
	result += shCoefficients[ 7 ] * 2.0 * 0.429043 * x * z;
	result += shCoefficients[ 8 ] * 0.429043 * ( x * x - y * y );
	return result;
}
vec3 getLightProbeIrradiance( const in vec3 lightProbe[ 9 ], const in vec3 normal ) {
	vec3 worldNormal = inverseTransformDirection( normal, viewMatrix );
	vec3 irradiance = shGetIrradianceAt( worldNormal, lightProbe );
	return irradiance;
}
vec3 getAmbientLightIrradiance( const in vec3 ambientLightColor ) {
	vec3 irradiance = ambientLightColor;
	return irradiance;
}
float getDistanceAttenuation( const in float lightDistance, const in float cutoffDistance, const in float decayExponent ) {
	#if defined ( LEGACY_LIGHTS )
		if ( cutoffDistance > 0.0 && decayExponent > 0.0 ) {
			return pow( saturate( - lightDistance / cutoffDistance + 1.0 ), decayExponent );
		}
		return 1.0;
	#else
		float distanceFalloff = 1.0 / max( pow( lightDistance, decayExponent ), 0.01 );
		if ( cutoffDistance > 0.0 ) {
			distanceFalloff *= pow2( saturate( 1.0 - pow4( lightDistance / cutoffDistance ) ) );
		}
		return distanceFalloff;
	#endif
}
float getSpotAttenuation( const in float coneCosine, const in float penumbraCosine, const in float angleCosine ) {
	return smoothstep( coneCosine, penumbraCosine, angleCosine );
}
#if NUM_DIR_LIGHTS > 0
	struct DirectionalLight {
		vec3 direction;
		vec3 color;
	};
	uniform DirectionalLight directionalLights[ NUM_DIR_LIGHTS ];
	void getDirectionalLightInfo( const in DirectionalLight directionalLight, out IncidentLight light ) {
		light.color = directionalLight.color;
		light.direction = directionalLight.direction;
		light.visible = true;
	}
#endif
#if NUM_POINT_LIGHTS > 0
	struct PointLight {
		vec3 position;
		vec3 color;
		float distance;
		float decay;
	};
	uniform PointLight pointLights[ NUM_POINT_LIGHTS ];
	void getPointLightInfo( const in PointLight pointLight, const in vec3 geometryPosition, out IncidentLight light ) {
		vec3 lVector = pointLight.position - geometryPosition;
		light.direction = normalize( lVector );
		float lightDistance = length( lVector );
		light.color = pointLight.color;
		light.color *= getDistanceAttenuation( lightDistance, pointLight.distance, pointLight.decay );
		light.visible = ( light.color != vec3( 0.0 ) );
	}
#endif
#if NUM_SPOT_LIGHTS > 0
	struct SpotLight {
		vec3 position;
		vec3 direction;
		vec3 color;
		float distance;
		float decay;
		float coneCos;
		float penumbraCos;
	};
	uniform SpotLight spotLights[ NUM_SPOT_LIGHTS ];
	void getSpotLightInfo( const in SpotLight spotLight, const in vec3 geometryPosition, out IncidentLight light ) {
		vec3 lVector = spotLight.position - geometryPosition;
		light.direction = normalize( lVector );
		float angleCos = dot( light.direction, spotLight.direction );
		float spotAttenuation = getSpotAttenuation( spotLight.coneCos, spotLight.penumbraCos, angleCos );
		if ( spotAttenuation > 0.0 ) {
			float lightDistance = length( lVector );
			light.color = spotLight.color * spotAttenuation;
			light.color *= getDistanceAttenuation( lightDistance, spotLight.distance, spotLight.decay );
			light.visible = ( light.color != vec3( 0.0 ) );
		} else {
			light.color = vec3( 0.0 );
			light.visible = false;
		}
	}
#endif
#if NUM_RECT_AREA_LIGHTS > 0
	struct RectAreaLight {
		vec3 color;
		vec3 position;
		vec3 halfWidth;
		vec3 halfHeight;
	};
	uniform sampler2D ltc_1;	uniform sampler2D ltc_2;
	uniform RectAreaLight rectAreaLights[ NUM_RECT_AREA_LIGHTS ];
#endif
#if NUM_HEMI_LIGHTS > 0
	struct HemisphereLight {
		vec3 direction;
		vec3 skyColor;
		vec3 groundColor;
	};
	uniform HemisphereLight hemisphereLights[ NUM_HEMI_LIGHTS ];
	vec3 getHemisphereLightIrradiance( const in HemisphereLight hemiLight, const in vec3 normal ) {
		float dotNL = dot( normal, hemiLight.direction );
		float hemiDiffuseWeight = 0.5 * dotNL + 0.5;
		vec3 irradiance = mix( hemiLight.groundColor, hemiLight.skyColor, hemiDiffuseWeight );
		return irradiance;
	}
#endif`,op=`#ifdef USE_ENVMAP
	vec3 getIBLIrradiance( const in vec3 normal ) {
		#ifdef ENVMAP_TYPE_CUBE_UV
			vec3 worldNormal = inverseTransformDirection( normal, viewMatrix );
			vec4 envMapColor = textureCubeUV( envMap, worldNormal, 1.0 );
			return PI * envMapColor.rgb * envMapIntensity;
		#else
			return vec3( 0.0 );
		#endif
	}
	vec3 getIBLRadiance( const in vec3 viewDir, const in vec3 normal, const in float roughness ) {
		#ifdef ENVMAP_TYPE_CUBE_UV
			vec3 reflectVec = reflect( - viewDir, normal );
			reflectVec = normalize( mix( reflectVec, normal, roughness * roughness) );
			reflectVec = inverseTransformDirection( reflectVec, viewMatrix );
			vec4 envMapColor = textureCubeUV( envMap, reflectVec, roughness );
			return envMapColor.rgb * envMapIntensity;
		#else
			return vec3( 0.0 );
		#endif
	}
	#ifdef USE_ANISOTROPY
		vec3 getIBLAnisotropyRadiance( const in vec3 viewDir, const in vec3 normal, const in float roughness, const in vec3 bitangent, const in float anisotropy ) {
			#ifdef ENVMAP_TYPE_CUBE_UV
				vec3 bentNormal = cross( bitangent, viewDir );
				bentNormal = normalize( cross( bentNormal, bitangent ) );
				bentNormal = normalize( mix( bentNormal, normal, pow2( pow2( 1.0 - anisotropy * ( 1.0 - roughness ) ) ) ) );
				return getIBLRadiance( viewDir, bentNormal, roughness );
			#else
				return vec3( 0.0 );
			#endif
		}
	#endif
#endif`,lp=`ToonMaterial material;
material.diffuseColor = diffuseColor.rgb;`,cp=`varying vec3 vViewPosition;
struct ToonMaterial {
	vec3 diffuseColor;
};
void RE_Direct_Toon( const in IncidentLight directLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in ToonMaterial material, inout ReflectedLight reflectedLight ) {
	vec3 irradiance = getGradientIrradiance( geometryNormal, directLight.direction ) * directLight.color;
	reflectedLight.directDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
void RE_IndirectDiffuse_Toon( const in vec3 irradiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in ToonMaterial material, inout ReflectedLight reflectedLight ) {
	reflectedLight.indirectDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
#define RE_Direct				RE_Direct_Toon
#define RE_IndirectDiffuse		RE_IndirectDiffuse_Toon`,hp=`BlinnPhongMaterial material;
material.diffuseColor = diffuseColor.rgb;
material.specularColor = specular;
material.specularShininess = shininess;
material.specularStrength = specularStrength;`,up=`varying vec3 vViewPosition;
struct BlinnPhongMaterial {
	vec3 diffuseColor;
	vec3 specularColor;
	float specularShininess;
	float specularStrength;
};
void RE_Direct_BlinnPhong( const in IncidentLight directLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in BlinnPhongMaterial material, inout ReflectedLight reflectedLight ) {
	float dotNL = saturate( dot( geometryNormal, directLight.direction ) );
	vec3 irradiance = dotNL * directLight.color;
	reflectedLight.directDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
	reflectedLight.directSpecular += irradiance * BRDF_BlinnPhong( directLight.direction, geometryViewDir, geometryNormal, material.specularColor, material.specularShininess ) * material.specularStrength;
}
void RE_IndirectDiffuse_BlinnPhong( const in vec3 irradiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in BlinnPhongMaterial material, inout ReflectedLight reflectedLight ) {
	reflectedLight.indirectDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
#define RE_Direct				RE_Direct_BlinnPhong
#define RE_IndirectDiffuse		RE_IndirectDiffuse_BlinnPhong`,dp=`PhysicalMaterial material;
material.diffuseColor = diffuseColor.rgb * ( 1.0 - metalnessFactor );
vec3 dxy = max( abs( dFdx( nonPerturbedNormal ) ), abs( dFdy( nonPerturbedNormal ) ) );
float geometryRoughness = max( max( dxy.x, dxy.y ), dxy.z );
material.roughness = max( roughnessFactor, 0.0525 );material.roughness += geometryRoughness;
material.roughness = min( material.roughness, 1.0 );
#ifdef IOR
	material.ior = ior;
	#ifdef USE_SPECULAR
		float specularIntensityFactor = specularIntensity;
		vec3 specularColorFactor = specularColor;
		#ifdef USE_SPECULAR_COLORMAP
			specularColorFactor *= texture2D( specularColorMap, vSpecularColorMapUv ).rgb;
		#endif
		#ifdef USE_SPECULAR_INTENSITYMAP
			specularIntensityFactor *= texture2D( specularIntensityMap, vSpecularIntensityMapUv ).a;
		#endif
		material.specularF90 = mix( specularIntensityFactor, 1.0, metalnessFactor );
	#else
		float specularIntensityFactor = 1.0;
		vec3 specularColorFactor = vec3( 1.0 );
		material.specularF90 = 1.0;
	#endif
	material.specularColor = mix( min( pow2( ( material.ior - 1.0 ) / ( material.ior + 1.0 ) ) * specularColorFactor, vec3( 1.0 ) ) * specularIntensityFactor, diffuseColor.rgb, metalnessFactor );
#else
	material.specularColor = mix( vec3( 0.04 ), diffuseColor.rgb, metalnessFactor );
	material.specularF90 = 1.0;
#endif
#ifdef USE_CLEARCOAT
	material.clearcoat = clearcoat;
	material.clearcoatRoughness = clearcoatRoughness;
	material.clearcoatF0 = vec3( 0.04 );
	material.clearcoatF90 = 1.0;
	#ifdef USE_CLEARCOATMAP
		material.clearcoat *= texture2D( clearcoatMap, vClearcoatMapUv ).x;
	#endif
	#ifdef USE_CLEARCOAT_ROUGHNESSMAP
		material.clearcoatRoughness *= texture2D( clearcoatRoughnessMap, vClearcoatRoughnessMapUv ).y;
	#endif
	material.clearcoat = saturate( material.clearcoat );	material.clearcoatRoughness = max( material.clearcoatRoughness, 0.0525 );
	material.clearcoatRoughness += geometryRoughness;
	material.clearcoatRoughness = min( material.clearcoatRoughness, 1.0 );
#endif
#ifdef USE_IRIDESCENCE
	material.iridescence = iridescence;
	material.iridescenceIOR = iridescenceIOR;
	#ifdef USE_IRIDESCENCEMAP
		material.iridescence *= texture2D( iridescenceMap, vIridescenceMapUv ).r;
	#endif
	#ifdef USE_IRIDESCENCE_THICKNESSMAP
		material.iridescenceThickness = (iridescenceThicknessMaximum - iridescenceThicknessMinimum) * texture2D( iridescenceThicknessMap, vIridescenceThicknessMapUv ).g + iridescenceThicknessMinimum;
	#else
		material.iridescenceThickness = iridescenceThicknessMaximum;
	#endif
#endif
#ifdef USE_SHEEN
	material.sheenColor = sheenColor;
	#ifdef USE_SHEEN_COLORMAP
		material.sheenColor *= texture2D( sheenColorMap, vSheenColorMapUv ).rgb;
	#endif
	material.sheenRoughness = clamp( sheenRoughness, 0.07, 1.0 );
	#ifdef USE_SHEEN_ROUGHNESSMAP
		material.sheenRoughness *= texture2D( sheenRoughnessMap, vSheenRoughnessMapUv ).a;
	#endif
#endif
#ifdef USE_ANISOTROPY
	#ifdef USE_ANISOTROPYMAP
		mat2 anisotropyMat = mat2( anisotropyVector.x, anisotropyVector.y, - anisotropyVector.y, anisotropyVector.x );
		vec3 anisotropyPolar = texture2D( anisotropyMap, vAnisotropyMapUv ).rgb;
		vec2 anisotropyV = anisotropyMat * normalize( 2.0 * anisotropyPolar.rg - vec2( 1.0 ) ) * anisotropyPolar.b;
	#else
		vec2 anisotropyV = anisotropyVector;
	#endif
	material.anisotropy = length( anisotropyV );
	if( material.anisotropy == 0.0 ) {
		anisotropyV = vec2( 1.0, 0.0 );
	} else {
		anisotropyV /= material.anisotropy;
		material.anisotropy = saturate( material.anisotropy );
	}
	material.alphaT = mix( pow2( material.roughness ), 1.0, pow2( material.anisotropy ) );
	material.anisotropyT = tbn[ 0 ] * anisotropyV.x + tbn[ 1 ] * anisotropyV.y;
	material.anisotropyB = tbn[ 1 ] * anisotropyV.x - tbn[ 0 ] * anisotropyV.y;
#endif`,fp=`struct PhysicalMaterial {
	vec3 diffuseColor;
	float roughness;
	vec3 specularColor;
	float specularF90;
	#ifdef USE_CLEARCOAT
		float clearcoat;
		float clearcoatRoughness;
		vec3 clearcoatF0;
		float clearcoatF90;
	#endif
	#ifdef USE_IRIDESCENCE
		float iridescence;
		float iridescenceIOR;
		float iridescenceThickness;
		vec3 iridescenceFresnel;
		vec3 iridescenceF0;
	#endif
	#ifdef USE_SHEEN
		vec3 sheenColor;
		float sheenRoughness;
	#endif
	#ifdef IOR
		float ior;
	#endif
	#ifdef USE_TRANSMISSION
		float transmission;
		float transmissionAlpha;
		float thickness;
		float attenuationDistance;
		vec3 attenuationColor;
	#endif
	#ifdef USE_ANISOTROPY
		float anisotropy;
		float alphaT;
		vec3 anisotropyT;
		vec3 anisotropyB;
	#endif
};
vec3 clearcoatSpecularDirect = vec3( 0.0 );
vec3 clearcoatSpecularIndirect = vec3( 0.0 );
vec3 sheenSpecularDirect = vec3( 0.0 );
vec3 sheenSpecularIndirect = vec3(0.0 );
vec3 Schlick_to_F0( const in vec3 f, const in float f90, const in float dotVH ) {
    float x = clamp( 1.0 - dotVH, 0.0, 1.0 );
    float x2 = x * x;
    float x5 = clamp( x * x2 * x2, 0.0, 0.9999 );
    return ( f - vec3( f90 ) * x5 ) / ( 1.0 - x5 );
}
float V_GGX_SmithCorrelated( const in float alpha, const in float dotNL, const in float dotNV ) {
	float a2 = pow2( alpha );
	float gv = dotNL * sqrt( a2 + ( 1.0 - a2 ) * pow2( dotNV ) );
	float gl = dotNV * sqrt( a2 + ( 1.0 - a2 ) * pow2( dotNL ) );
	return 0.5 / max( gv + gl, EPSILON );
}
float D_GGX( const in float alpha, const in float dotNH ) {
	float a2 = pow2( alpha );
	float denom = pow2( dotNH ) * ( a2 - 1.0 ) + 1.0;
	return RECIPROCAL_PI * a2 / pow2( denom );
}
#ifdef USE_ANISOTROPY
	float V_GGX_SmithCorrelated_Anisotropic( const in float alphaT, const in float alphaB, const in float dotTV, const in float dotBV, const in float dotTL, const in float dotBL, const in float dotNV, const in float dotNL ) {
		float gv = dotNL * length( vec3( alphaT * dotTV, alphaB * dotBV, dotNV ) );
		float gl = dotNV * length( vec3( alphaT * dotTL, alphaB * dotBL, dotNL ) );
		float v = 0.5 / ( gv + gl );
		return saturate(v);
	}
	float D_GGX_Anisotropic( const in float alphaT, const in float alphaB, const in float dotNH, const in float dotTH, const in float dotBH ) {
		float a2 = alphaT * alphaB;
		highp vec3 v = vec3( alphaB * dotTH, alphaT * dotBH, a2 * dotNH );
		highp float v2 = dot( v, v );
		float w2 = a2 / v2;
		return RECIPROCAL_PI * a2 * pow2 ( w2 );
	}
#endif
#ifdef USE_CLEARCOAT
	vec3 BRDF_GGX_Clearcoat( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, const in PhysicalMaterial material) {
		vec3 f0 = material.clearcoatF0;
		float f90 = material.clearcoatF90;
		float roughness = material.clearcoatRoughness;
		float alpha = pow2( roughness );
		vec3 halfDir = normalize( lightDir + viewDir );
		float dotNL = saturate( dot( normal, lightDir ) );
		float dotNV = saturate( dot( normal, viewDir ) );
		float dotNH = saturate( dot( normal, halfDir ) );
		float dotVH = saturate( dot( viewDir, halfDir ) );
		vec3 F = F_Schlick( f0, f90, dotVH );
		float V = V_GGX_SmithCorrelated( alpha, dotNL, dotNV );
		float D = D_GGX( alpha, dotNH );
		return F * ( V * D );
	}
#endif
vec3 BRDF_GGX( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, const in PhysicalMaterial material ) {
	vec3 f0 = material.specularColor;
	float f90 = material.specularF90;
	float roughness = material.roughness;
	float alpha = pow2( roughness );
	vec3 halfDir = normalize( lightDir + viewDir );
	float dotNL = saturate( dot( normal, lightDir ) );
	float dotNV = saturate( dot( normal, viewDir ) );
	float dotNH = saturate( dot( normal, halfDir ) );
	float dotVH = saturate( dot( viewDir, halfDir ) );
	vec3 F = F_Schlick( f0, f90, dotVH );
	#ifdef USE_IRIDESCENCE
		F = mix( F, material.iridescenceFresnel, material.iridescence );
	#endif
	#ifdef USE_ANISOTROPY
		float dotTL = dot( material.anisotropyT, lightDir );
		float dotTV = dot( material.anisotropyT, viewDir );
		float dotTH = dot( material.anisotropyT, halfDir );
		float dotBL = dot( material.anisotropyB, lightDir );
		float dotBV = dot( material.anisotropyB, viewDir );
		float dotBH = dot( material.anisotropyB, halfDir );
		float V = V_GGX_SmithCorrelated_Anisotropic( material.alphaT, alpha, dotTV, dotBV, dotTL, dotBL, dotNV, dotNL );
		float D = D_GGX_Anisotropic( material.alphaT, alpha, dotNH, dotTH, dotBH );
	#else
		float V = V_GGX_SmithCorrelated( alpha, dotNL, dotNV );
		float D = D_GGX( alpha, dotNH );
	#endif
	return F * ( V * D );
}
vec2 LTC_Uv( const in vec3 N, const in vec3 V, const in float roughness ) {
	const float LUT_SIZE = 64.0;
	const float LUT_SCALE = ( LUT_SIZE - 1.0 ) / LUT_SIZE;
	const float LUT_BIAS = 0.5 / LUT_SIZE;
	float dotNV = saturate( dot( N, V ) );
	vec2 uv = vec2( roughness, sqrt( 1.0 - dotNV ) );
	uv = uv * LUT_SCALE + LUT_BIAS;
	return uv;
}
float LTC_ClippedSphereFormFactor( const in vec3 f ) {
	float l = length( f );
	return max( ( l * l + f.z ) / ( l + 1.0 ), 0.0 );
}
vec3 LTC_EdgeVectorFormFactor( const in vec3 v1, const in vec3 v2 ) {
	float x = dot( v1, v2 );
	float y = abs( x );
	float a = 0.8543985 + ( 0.4965155 + 0.0145206 * y ) * y;
	float b = 3.4175940 + ( 4.1616724 + y ) * y;
	float v = a / b;
	float theta_sintheta = ( x > 0.0 ) ? v : 0.5 * inversesqrt( max( 1.0 - x * x, 1e-7 ) ) - v;
	return cross( v1, v2 ) * theta_sintheta;
}
vec3 LTC_Evaluate( const in vec3 N, const in vec3 V, const in vec3 P, const in mat3 mInv, const in vec3 rectCoords[ 4 ] ) {
	vec3 v1 = rectCoords[ 1 ] - rectCoords[ 0 ];
	vec3 v2 = rectCoords[ 3 ] - rectCoords[ 0 ];
	vec3 lightNormal = cross( v1, v2 );
	if( dot( lightNormal, P - rectCoords[ 0 ] ) < 0.0 ) return vec3( 0.0 );
	vec3 T1, T2;
	T1 = normalize( V - N * dot( V, N ) );
	T2 = - cross( N, T1 );
	mat3 mat = mInv * transposeMat3( mat3( T1, T2, N ) );
	vec3 coords[ 4 ];
	coords[ 0 ] = mat * ( rectCoords[ 0 ] - P );
	coords[ 1 ] = mat * ( rectCoords[ 1 ] - P );
	coords[ 2 ] = mat * ( rectCoords[ 2 ] - P );
	coords[ 3 ] = mat * ( rectCoords[ 3 ] - P );
	coords[ 0 ] = normalize( coords[ 0 ] );
	coords[ 1 ] = normalize( coords[ 1 ] );
	coords[ 2 ] = normalize( coords[ 2 ] );
	coords[ 3 ] = normalize( coords[ 3 ] );
	vec3 vectorFormFactor = vec3( 0.0 );
	vectorFormFactor += LTC_EdgeVectorFormFactor( coords[ 0 ], coords[ 1 ] );
	vectorFormFactor += LTC_EdgeVectorFormFactor( coords[ 1 ], coords[ 2 ] );
	vectorFormFactor += LTC_EdgeVectorFormFactor( coords[ 2 ], coords[ 3 ] );
	vectorFormFactor += LTC_EdgeVectorFormFactor( coords[ 3 ], coords[ 0 ] );
	float result = LTC_ClippedSphereFormFactor( vectorFormFactor );
	return vec3( result );
}
#if defined( USE_SHEEN )
float D_Charlie( float roughness, float dotNH ) {
	float alpha = pow2( roughness );
	float invAlpha = 1.0 / alpha;
	float cos2h = dotNH * dotNH;
	float sin2h = max( 1.0 - cos2h, 0.0078125 );
	return ( 2.0 + invAlpha ) * pow( sin2h, invAlpha * 0.5 ) / ( 2.0 * PI );
}
float V_Neubelt( float dotNV, float dotNL ) {
	return saturate( 1.0 / ( 4.0 * ( dotNL + dotNV - dotNL * dotNV ) ) );
}
vec3 BRDF_Sheen( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, vec3 sheenColor, const in float sheenRoughness ) {
	vec3 halfDir = normalize( lightDir + viewDir );
	float dotNL = saturate( dot( normal, lightDir ) );
	float dotNV = saturate( dot( normal, viewDir ) );
	float dotNH = saturate( dot( normal, halfDir ) );
	float D = D_Charlie( sheenRoughness, dotNH );
	float V = V_Neubelt( dotNV, dotNL );
	return sheenColor * ( D * V );
}
#endif
float IBLSheenBRDF( const in vec3 normal, const in vec3 viewDir, const in float roughness ) {
	float dotNV = saturate( dot( normal, viewDir ) );
	float r2 = roughness * roughness;
	float a = roughness < 0.25 ? -339.2 * r2 + 161.4 * roughness - 25.9 : -8.48 * r2 + 14.3 * roughness - 9.95;
	float b = roughness < 0.25 ? 44.0 * r2 - 23.7 * roughness + 3.26 : 1.97 * r2 - 3.27 * roughness + 0.72;
	float DG = exp( a * dotNV + b ) + ( roughness < 0.25 ? 0.0 : 0.1 * ( roughness - 0.25 ) );
	return saturate( DG * RECIPROCAL_PI );
}
vec2 DFGApprox( const in vec3 normal, const in vec3 viewDir, const in float roughness ) {
	float dotNV = saturate( dot( normal, viewDir ) );
	const vec4 c0 = vec4( - 1, - 0.0275, - 0.572, 0.022 );
	const vec4 c1 = vec4( 1, 0.0425, 1.04, - 0.04 );
	vec4 r = roughness * c0 + c1;
	float a004 = min( r.x * r.x, exp2( - 9.28 * dotNV ) ) * r.x + r.y;
	vec2 fab = vec2( - 1.04, 1.04 ) * a004 + r.zw;
	return fab;
}
vec3 EnvironmentBRDF( const in vec3 normal, const in vec3 viewDir, const in vec3 specularColor, const in float specularF90, const in float roughness ) {
	vec2 fab = DFGApprox( normal, viewDir, roughness );
	return specularColor * fab.x + specularF90 * fab.y;
}
#ifdef USE_IRIDESCENCE
void computeMultiscatteringIridescence( const in vec3 normal, const in vec3 viewDir, const in vec3 specularColor, const in float specularF90, const in float iridescence, const in vec3 iridescenceF0, const in float roughness, inout vec3 singleScatter, inout vec3 multiScatter ) {
#else
void computeMultiscattering( const in vec3 normal, const in vec3 viewDir, const in vec3 specularColor, const in float specularF90, const in float roughness, inout vec3 singleScatter, inout vec3 multiScatter ) {
#endif
	vec2 fab = DFGApprox( normal, viewDir, roughness );
	#ifdef USE_IRIDESCENCE
		vec3 Fr = mix( specularColor, iridescenceF0, iridescence );
	#else
		vec3 Fr = specularColor;
	#endif
	vec3 FssEss = Fr * fab.x + specularF90 * fab.y;
	float Ess = fab.x + fab.y;
	float Ems = 1.0 - Ess;
	vec3 Favg = Fr + ( 1.0 - Fr ) * 0.047619;	vec3 Fms = FssEss * Favg / ( 1.0 - Ems * Favg );
	singleScatter += FssEss;
	multiScatter += Fms * Ems;
}
#if NUM_RECT_AREA_LIGHTS > 0
	void RE_Direct_RectArea_Physical( const in RectAreaLight rectAreaLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in PhysicalMaterial material, inout ReflectedLight reflectedLight ) {
		vec3 normal = geometryNormal;
		vec3 viewDir = geometryViewDir;
		vec3 position = geometryPosition;
		vec3 lightPos = rectAreaLight.position;
		vec3 halfWidth = rectAreaLight.halfWidth;
		vec3 halfHeight = rectAreaLight.halfHeight;
		vec3 lightColor = rectAreaLight.color;
		float roughness = material.roughness;
		vec3 rectCoords[ 4 ];
		rectCoords[ 0 ] = lightPos + halfWidth - halfHeight;		rectCoords[ 1 ] = lightPos - halfWidth - halfHeight;
		rectCoords[ 2 ] = lightPos - halfWidth + halfHeight;
		rectCoords[ 3 ] = lightPos + halfWidth + halfHeight;
		vec2 uv = LTC_Uv( normal, viewDir, roughness );
		vec4 t1 = texture2D( ltc_1, uv );
		vec4 t2 = texture2D( ltc_2, uv );
		mat3 mInv = mat3(
			vec3( t1.x, 0, t1.y ),
			vec3(    0, 1,    0 ),
			vec3( t1.z, 0, t1.w )
		);
		vec3 fresnel = ( material.specularColor * t2.x + ( vec3( 1.0 ) - material.specularColor ) * t2.y );
		reflectedLight.directSpecular += lightColor * fresnel * LTC_Evaluate( normal, viewDir, position, mInv, rectCoords );
		reflectedLight.directDiffuse += lightColor * material.diffuseColor * LTC_Evaluate( normal, viewDir, position, mat3( 1.0 ), rectCoords );
	}
#endif
void RE_Direct_Physical( const in IncidentLight directLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in PhysicalMaterial material, inout ReflectedLight reflectedLight ) {
	float dotNL = saturate( dot( geometryNormal, directLight.direction ) );
	vec3 irradiance = dotNL * directLight.color;
	#ifdef USE_CLEARCOAT
		float dotNLcc = saturate( dot( geometryClearcoatNormal, directLight.direction ) );
		vec3 ccIrradiance = dotNLcc * directLight.color;
		clearcoatSpecularDirect += ccIrradiance * BRDF_GGX_Clearcoat( directLight.direction, geometryViewDir, geometryClearcoatNormal, material );
	#endif
	#ifdef USE_SHEEN
		sheenSpecularDirect += irradiance * BRDF_Sheen( directLight.direction, geometryViewDir, geometryNormal, material.sheenColor, material.sheenRoughness );
	#endif
	reflectedLight.directSpecular += irradiance * BRDF_GGX( directLight.direction, geometryViewDir, geometryNormal, material );
	reflectedLight.directDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
void RE_IndirectDiffuse_Physical( const in vec3 irradiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in PhysicalMaterial material, inout ReflectedLight reflectedLight ) {
	reflectedLight.indirectDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
void RE_IndirectSpecular_Physical( const in vec3 radiance, const in vec3 irradiance, const in vec3 clearcoatRadiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in PhysicalMaterial material, inout ReflectedLight reflectedLight) {
	#ifdef USE_CLEARCOAT
		clearcoatSpecularIndirect += clearcoatRadiance * EnvironmentBRDF( geometryClearcoatNormal, geometryViewDir, material.clearcoatF0, material.clearcoatF90, material.clearcoatRoughness );
	#endif
	#ifdef USE_SHEEN
		sheenSpecularIndirect += irradiance * material.sheenColor * IBLSheenBRDF( geometryNormal, geometryViewDir, material.sheenRoughness );
	#endif
	vec3 singleScattering = vec3( 0.0 );
	vec3 multiScattering = vec3( 0.0 );
	vec3 cosineWeightedIrradiance = irradiance * RECIPROCAL_PI;
	#ifdef USE_IRIDESCENCE
		computeMultiscatteringIridescence( geometryNormal, geometryViewDir, material.specularColor, material.specularF90, material.iridescence, material.iridescenceFresnel, material.roughness, singleScattering, multiScattering );
	#else
		computeMultiscattering( geometryNormal, geometryViewDir, material.specularColor, material.specularF90, material.roughness, singleScattering, multiScattering );
	#endif
	vec3 totalScattering = singleScattering + multiScattering;
	vec3 diffuse = material.diffuseColor * ( 1.0 - max( max( totalScattering.r, totalScattering.g ), totalScattering.b ) );
	reflectedLight.indirectSpecular += radiance * singleScattering;
	reflectedLight.indirectSpecular += multiScattering * cosineWeightedIrradiance;
	reflectedLight.indirectDiffuse += diffuse * cosineWeightedIrradiance;
}
#define RE_Direct				RE_Direct_Physical
#define RE_Direct_RectArea		RE_Direct_RectArea_Physical
#define RE_IndirectDiffuse		RE_IndirectDiffuse_Physical
#define RE_IndirectSpecular		RE_IndirectSpecular_Physical
float computeSpecularOcclusion( const in float dotNV, const in float ambientOcclusion, const in float roughness ) {
	return saturate( pow( dotNV + ambientOcclusion, exp2( - 16.0 * roughness - 1.0 ) ) - 1.0 + ambientOcclusion );
}`,pp=`
vec3 geometryPosition = - vViewPosition;
vec3 geometryNormal = normal;
vec3 geometryViewDir = ( isOrthographic ) ? vec3( 0, 0, 1 ) : normalize( vViewPosition );
vec3 geometryClearcoatNormal = vec3( 0.0 );
#ifdef USE_CLEARCOAT
	geometryClearcoatNormal = clearcoatNormal;
#endif
#ifdef USE_IRIDESCENCE
	float dotNVi = saturate( dot( normal, geometryViewDir ) );
	if ( material.iridescenceThickness == 0.0 ) {
		material.iridescence = 0.0;
	} else {
		material.iridescence = saturate( material.iridescence );
	}
	if ( material.iridescence > 0.0 ) {
		material.iridescenceFresnel = evalIridescence( 1.0, material.iridescenceIOR, dotNVi, material.iridescenceThickness, material.specularColor );
		material.iridescenceF0 = Schlick_to_F0( material.iridescenceFresnel, 1.0, dotNVi );
	}
#endif
IncidentLight directLight;
#if ( NUM_POINT_LIGHTS > 0 ) && defined( RE_Direct )
	PointLight pointLight;
	#if defined( USE_SHADOWMAP ) && NUM_POINT_LIGHT_SHADOWS > 0
	PointLightShadow pointLightShadow;
	#endif
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_POINT_LIGHTS; i ++ ) {
		pointLight = pointLights[ i ];
		getPointLightInfo( pointLight, geometryPosition, directLight );
		#if defined( USE_SHADOWMAP ) && ( UNROLLED_LOOP_INDEX < NUM_POINT_LIGHT_SHADOWS )
		pointLightShadow = pointLightShadows[ i ];
		directLight.color *= ( directLight.visible && receiveShadow ) ? getPointShadow( pointShadowMap[ i ], pointLightShadow.shadowMapSize, pointLightShadow.shadowBias, pointLightShadow.shadowRadius, vPointShadowCoord[ i ], pointLightShadow.shadowCameraNear, pointLightShadow.shadowCameraFar ) : 1.0;
		#endif
		RE_Direct( directLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
	}
	#pragma unroll_loop_end
#endif
#if ( NUM_SPOT_LIGHTS > 0 ) && defined( RE_Direct )
	SpotLight spotLight;
	vec4 spotColor;
	vec3 spotLightCoord;
	bool inSpotLightMap;
	#if defined( USE_SHADOWMAP ) && NUM_SPOT_LIGHT_SHADOWS > 0
	SpotLightShadow spotLightShadow;
	#endif
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_SPOT_LIGHTS; i ++ ) {
		spotLight = spotLights[ i ];
		getSpotLightInfo( spotLight, geometryPosition, directLight );
		#if ( UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS_WITH_MAPS )
		#define SPOT_LIGHT_MAP_INDEX UNROLLED_LOOP_INDEX
		#elif ( UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS )
		#define SPOT_LIGHT_MAP_INDEX NUM_SPOT_LIGHT_MAPS
		#else
		#define SPOT_LIGHT_MAP_INDEX ( UNROLLED_LOOP_INDEX - NUM_SPOT_LIGHT_SHADOWS + NUM_SPOT_LIGHT_SHADOWS_WITH_MAPS )
		#endif
		#if ( SPOT_LIGHT_MAP_INDEX < NUM_SPOT_LIGHT_MAPS )
			spotLightCoord = vSpotLightCoord[ i ].xyz / vSpotLightCoord[ i ].w;
			inSpotLightMap = all( lessThan( abs( spotLightCoord * 2. - 1. ), vec3( 1.0 ) ) );
			spotColor = texture2D( spotLightMap[ SPOT_LIGHT_MAP_INDEX ], spotLightCoord.xy );
			directLight.color = inSpotLightMap ? directLight.color * spotColor.rgb : directLight.color;
		#endif
		#undef SPOT_LIGHT_MAP_INDEX
		#if defined( USE_SHADOWMAP ) && ( UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS )
		spotLightShadow = spotLightShadows[ i ];
		directLight.color *= ( directLight.visible && receiveShadow ) ? getShadow( spotShadowMap[ i ], spotLightShadow.shadowMapSize, spotLightShadow.shadowBias, spotLightShadow.shadowRadius, vSpotLightCoord[ i ] ) : 1.0;
		#endif
		RE_Direct( directLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
	}
	#pragma unroll_loop_end
#endif
#if ( NUM_DIR_LIGHTS > 0 ) && defined( RE_Direct )
	DirectionalLight directionalLight;
	#if defined( USE_SHADOWMAP ) && NUM_DIR_LIGHT_SHADOWS > 0
	DirectionalLightShadow directionalLightShadow;
	#endif
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_DIR_LIGHTS; i ++ ) {
		directionalLight = directionalLights[ i ];
		getDirectionalLightInfo( directionalLight, directLight );
		#if defined( USE_SHADOWMAP ) && ( UNROLLED_LOOP_INDEX < NUM_DIR_LIGHT_SHADOWS )
		directionalLightShadow = directionalLightShadows[ i ];
		directLight.color *= ( directLight.visible && receiveShadow ) ? getShadow( directionalShadowMap[ i ], directionalLightShadow.shadowMapSize, directionalLightShadow.shadowBias, directionalLightShadow.shadowRadius, vDirectionalShadowCoord[ i ] ) : 1.0;
		#endif
		RE_Direct( directLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
	}
	#pragma unroll_loop_end
#endif
#if ( NUM_RECT_AREA_LIGHTS > 0 ) && defined( RE_Direct_RectArea )
	RectAreaLight rectAreaLight;
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_RECT_AREA_LIGHTS; i ++ ) {
		rectAreaLight = rectAreaLights[ i ];
		RE_Direct_RectArea( rectAreaLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
	}
	#pragma unroll_loop_end
#endif
#if defined( RE_IndirectDiffuse )
	vec3 iblIrradiance = vec3( 0.0 );
	vec3 irradiance = getAmbientLightIrradiance( ambientLightColor );
	#if defined( USE_LIGHT_PROBES )
		irradiance += getLightProbeIrradiance( lightProbe, geometryNormal );
	#endif
	#if ( NUM_HEMI_LIGHTS > 0 )
		#pragma unroll_loop_start
		for ( int i = 0; i < NUM_HEMI_LIGHTS; i ++ ) {
			irradiance += getHemisphereLightIrradiance( hemisphereLights[ i ], geometryNormal );
		}
		#pragma unroll_loop_end
	#endif
#endif
#if defined( RE_IndirectSpecular )
	vec3 radiance = vec3( 0.0 );
	vec3 clearcoatRadiance = vec3( 0.0 );
#endif`,mp=`#if defined( RE_IndirectDiffuse )
	#ifdef USE_LIGHTMAP
		vec4 lightMapTexel = texture2D( lightMap, vLightMapUv );
		vec3 lightMapIrradiance = lightMapTexel.rgb * lightMapIntensity;
		irradiance += lightMapIrradiance;
	#endif
	#if defined( USE_ENVMAP ) && defined( STANDARD ) && defined( ENVMAP_TYPE_CUBE_UV )
		iblIrradiance += getIBLIrradiance( geometryNormal );
	#endif
#endif
#if defined( USE_ENVMAP ) && defined( RE_IndirectSpecular )
	#ifdef USE_ANISOTROPY
		radiance += getIBLAnisotropyRadiance( geometryViewDir, geometryNormal, material.roughness, material.anisotropyB, material.anisotropy );
	#else
		radiance += getIBLRadiance( geometryViewDir, geometryNormal, material.roughness );
	#endif
	#ifdef USE_CLEARCOAT
		clearcoatRadiance += getIBLRadiance( geometryViewDir, geometryClearcoatNormal, material.clearcoatRoughness );
	#endif
#endif`,gp=`#if defined( RE_IndirectDiffuse )
	RE_IndirectDiffuse( irradiance, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
#endif
#if defined( RE_IndirectSpecular )
	RE_IndirectSpecular( radiance, iblIrradiance, clearcoatRadiance, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
#endif`,xp=`#if defined( USE_LOGDEPTHBUF ) && defined( USE_LOGDEPTHBUF_EXT )
	gl_FragDepthEXT = vIsPerspective == 0.0 ? gl_FragCoord.z : log2( vFragDepth ) * logDepthBufFC * 0.5;
#endif`,_p=`#if defined( USE_LOGDEPTHBUF ) && defined( USE_LOGDEPTHBUF_EXT )
	uniform float logDepthBufFC;
	varying float vFragDepth;
	varying float vIsPerspective;
#endif`,vp=`#ifdef USE_LOGDEPTHBUF
	#ifdef USE_LOGDEPTHBUF_EXT
		varying float vFragDepth;
		varying float vIsPerspective;
	#else
		uniform float logDepthBufFC;
	#endif
#endif`,yp=`#ifdef USE_LOGDEPTHBUF
	#ifdef USE_LOGDEPTHBUF_EXT
		vFragDepth = 1.0 + gl_Position.w;
		vIsPerspective = float( isPerspectiveMatrix( projectionMatrix ) );
	#else
		if ( isPerspectiveMatrix( projectionMatrix ) ) {
			gl_Position.z = log2( max( EPSILON, gl_Position.w + 1.0 ) ) * logDepthBufFC - 1.0;
			gl_Position.z *= gl_Position.w;
		}
	#endif
#endif`,bp=`#ifdef USE_MAP
	vec4 sampledDiffuseColor = texture2D( map, vMapUv );
	#ifdef DECODE_VIDEO_TEXTURE
		sampledDiffuseColor = vec4( mix( pow( sampledDiffuseColor.rgb * 0.9478672986 + vec3( 0.0521327014 ), vec3( 2.4 ) ), sampledDiffuseColor.rgb * 0.0773993808, vec3( lessThanEqual( sampledDiffuseColor.rgb, vec3( 0.04045 ) ) ) ), sampledDiffuseColor.w );
	
	#endif
	diffuseColor *= sampledDiffuseColor;
#endif`,Mp=`#ifdef USE_MAP
	uniform sampler2D map;
#endif`,Sp=`#if defined( USE_MAP ) || defined( USE_ALPHAMAP )
	#if defined( USE_POINTS_UV )
		vec2 uv = vUv;
	#else
		vec2 uv = ( uvTransform * vec3( gl_PointCoord.x, 1.0 - gl_PointCoord.y, 1 ) ).xy;
	#endif
#endif
#ifdef USE_MAP
	diffuseColor *= texture2D( map, uv );
#endif
#ifdef USE_ALPHAMAP
	diffuseColor.a *= texture2D( alphaMap, uv ).g;
#endif`,wp=`#if defined( USE_POINTS_UV )
	varying vec2 vUv;
#else
	#if defined( USE_MAP ) || defined( USE_ALPHAMAP )
		uniform mat3 uvTransform;
	#endif
#endif
#ifdef USE_MAP
	uniform sampler2D map;
#endif
#ifdef USE_ALPHAMAP
	uniform sampler2D alphaMap;
#endif`,Ep=`float metalnessFactor = metalness;
#ifdef USE_METALNESSMAP
	vec4 texelMetalness = texture2D( metalnessMap, vMetalnessMapUv );
	metalnessFactor *= texelMetalness.b;
#endif`,Tp=`#ifdef USE_METALNESSMAP
	uniform sampler2D metalnessMap;
#endif`,Ap=`#if defined( USE_MORPHCOLORS ) && defined( MORPHTARGETS_TEXTURE )
	vColor *= morphTargetBaseInfluence;
	for ( int i = 0; i < MORPHTARGETS_COUNT; i ++ ) {
		#if defined( USE_COLOR_ALPHA )
			if ( morphTargetInfluences[ i ] != 0.0 ) vColor += getMorph( gl_VertexID, i, 2 ) * morphTargetInfluences[ i ];
		#elif defined( USE_COLOR )
			if ( morphTargetInfluences[ i ] != 0.0 ) vColor += getMorph( gl_VertexID, i, 2 ).rgb * morphTargetInfluences[ i ];
		#endif
	}
#endif`,Cp=`#ifdef USE_MORPHNORMALS
	objectNormal *= morphTargetBaseInfluence;
	#ifdef MORPHTARGETS_TEXTURE
		for ( int i = 0; i < MORPHTARGETS_COUNT; i ++ ) {
			if ( morphTargetInfluences[ i ] != 0.0 ) objectNormal += getMorph( gl_VertexID, i, 1 ).xyz * morphTargetInfluences[ i ];
		}
	#else
		objectNormal += morphNormal0 * morphTargetInfluences[ 0 ];
		objectNormal += morphNormal1 * morphTargetInfluences[ 1 ];
		objectNormal += morphNormal2 * morphTargetInfluences[ 2 ];
		objectNormal += morphNormal3 * morphTargetInfluences[ 3 ];
	#endif
#endif`,Rp=`#ifdef USE_MORPHTARGETS
	uniform float morphTargetBaseInfluence;
	#ifdef MORPHTARGETS_TEXTURE
		uniform float morphTargetInfluences[ MORPHTARGETS_COUNT ];
		uniform sampler2DArray morphTargetsTexture;
		uniform ivec2 morphTargetsTextureSize;
		vec4 getMorph( const in int vertexIndex, const in int morphTargetIndex, const in int offset ) {
			int texelIndex = vertexIndex * MORPHTARGETS_TEXTURE_STRIDE + offset;
			int y = texelIndex / morphTargetsTextureSize.x;
			int x = texelIndex - y * morphTargetsTextureSize.x;
			ivec3 morphUV = ivec3( x, y, morphTargetIndex );
			return texelFetch( morphTargetsTexture, morphUV, 0 );
		}
	#else
		#ifndef USE_MORPHNORMALS
			uniform float morphTargetInfluences[ 8 ];
		#else
			uniform float morphTargetInfluences[ 4 ];
		#endif
	#endif
#endif`,Pp=`#ifdef USE_MORPHTARGETS
	transformed *= morphTargetBaseInfluence;
	#ifdef MORPHTARGETS_TEXTURE
		for ( int i = 0; i < MORPHTARGETS_COUNT; i ++ ) {
			if ( morphTargetInfluences[ i ] != 0.0 ) transformed += getMorph( gl_VertexID, i, 0 ).xyz * morphTargetInfluences[ i ];
		}
	#else
		transformed += morphTarget0 * morphTargetInfluences[ 0 ];
		transformed += morphTarget1 * morphTargetInfluences[ 1 ];
		transformed += morphTarget2 * morphTargetInfluences[ 2 ];
		transformed += morphTarget3 * morphTargetInfluences[ 3 ];
		#ifndef USE_MORPHNORMALS
			transformed += morphTarget4 * morphTargetInfluences[ 4 ];
			transformed += morphTarget5 * morphTargetInfluences[ 5 ];
			transformed += morphTarget6 * morphTargetInfluences[ 6 ];
			transformed += morphTarget7 * morphTargetInfluences[ 7 ];
		#endif
	#endif
#endif`,Lp=`float faceDirection = gl_FrontFacing ? 1.0 : - 1.0;
#ifdef FLAT_SHADED
	vec3 fdx = dFdx( vViewPosition );
	vec3 fdy = dFdy( vViewPosition );
	vec3 normal = normalize( cross( fdx, fdy ) );
#else
	vec3 normal = normalize( vNormal );
	#ifdef DOUBLE_SIDED
		normal *= faceDirection;
	#endif
#endif
#if defined( USE_NORMALMAP_TANGENTSPACE ) || defined( USE_CLEARCOAT_NORMALMAP ) || defined( USE_ANISOTROPY )
	#ifdef USE_TANGENT
		mat3 tbn = mat3( normalize( vTangent ), normalize( vBitangent ), normal );
	#else
		mat3 tbn = getTangentFrame( - vViewPosition, normal,
		#if defined( USE_NORMALMAP )
			vNormalMapUv
		#elif defined( USE_CLEARCOAT_NORMALMAP )
			vClearcoatNormalMapUv
		#else
			vUv
		#endif
		);
	#endif
	#if defined( DOUBLE_SIDED ) && ! defined( FLAT_SHADED )
		tbn[0] *= faceDirection;
		tbn[1] *= faceDirection;
	#endif
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	#ifdef USE_TANGENT
		mat3 tbn2 = mat3( normalize( vTangent ), normalize( vBitangent ), normal );
	#else
		mat3 tbn2 = getTangentFrame( - vViewPosition, normal, vClearcoatNormalMapUv );
	#endif
	#if defined( DOUBLE_SIDED ) && ! defined( FLAT_SHADED )
		tbn2[0] *= faceDirection;
		tbn2[1] *= faceDirection;
	#endif
#endif
vec3 nonPerturbedNormal = normal;`,Ip=`#ifdef USE_NORMALMAP_OBJECTSPACE
	normal = texture2D( normalMap, vNormalMapUv ).xyz * 2.0 - 1.0;
	#ifdef FLIP_SIDED
		normal = - normal;
	#endif
	#ifdef DOUBLE_SIDED
		normal = normal * faceDirection;
	#endif
	normal = normalize( normalMatrix * normal );
#elif defined( USE_NORMALMAP_TANGENTSPACE )
	vec3 mapN = texture2D( normalMap, vNormalMapUv ).xyz * 2.0 - 1.0;
	mapN.xy *= normalScale;
	normal = normalize( tbn * mapN );
#elif defined( USE_BUMPMAP )
	normal = perturbNormalArb( - vViewPosition, normal, dHdxy_fwd(), faceDirection );
#endif`,Dp=`#ifndef FLAT_SHADED
	varying vec3 vNormal;
	#ifdef USE_TANGENT
		varying vec3 vTangent;
		varying vec3 vBitangent;
	#endif
#endif`,Up=`#ifndef FLAT_SHADED
	varying vec3 vNormal;
	#ifdef USE_TANGENT
		varying vec3 vTangent;
		varying vec3 vBitangent;
	#endif
#endif`,Np=`#ifndef FLAT_SHADED
	vNormal = normalize( transformedNormal );
	#ifdef USE_TANGENT
		vTangent = normalize( transformedTangent );
		vBitangent = normalize( cross( vNormal, vTangent ) * tangent.w );
	#endif
#endif`,Op=`#ifdef USE_NORMALMAP
	uniform sampler2D normalMap;
	uniform vec2 normalScale;
#endif
#ifdef USE_NORMALMAP_OBJECTSPACE
	uniform mat3 normalMatrix;
#endif
#if ! defined ( USE_TANGENT ) && ( defined ( USE_NORMALMAP_TANGENTSPACE ) || defined ( USE_CLEARCOAT_NORMALMAP ) || defined( USE_ANISOTROPY ) )
	mat3 getTangentFrame( vec3 eye_pos, vec3 surf_norm, vec2 uv ) {
		vec3 q0 = dFdx( eye_pos.xyz );
		vec3 q1 = dFdy( eye_pos.xyz );
		vec2 st0 = dFdx( uv.st );
		vec2 st1 = dFdy( uv.st );
		vec3 N = surf_norm;
		vec3 q1perp = cross( q1, N );
		vec3 q0perp = cross( N, q0 );
		vec3 T = q1perp * st0.x + q0perp * st1.x;
		vec3 B = q1perp * st0.y + q0perp * st1.y;
		float det = max( dot( T, T ), dot( B, B ) );
		float scale = ( det == 0.0 ) ? 0.0 : inversesqrt( det );
		return mat3( T * scale, B * scale, N );
	}
#endif`,Fp=`#ifdef USE_CLEARCOAT
	vec3 clearcoatNormal = nonPerturbedNormal;
#endif`,Bp=`#ifdef USE_CLEARCOAT_NORMALMAP
	vec3 clearcoatMapN = texture2D( clearcoatNormalMap, vClearcoatNormalMapUv ).xyz * 2.0 - 1.0;
	clearcoatMapN.xy *= clearcoatNormalScale;
	clearcoatNormal = normalize( tbn2 * clearcoatMapN );
#endif`,zp=`#ifdef USE_CLEARCOATMAP
	uniform sampler2D clearcoatMap;
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	uniform sampler2D clearcoatNormalMap;
	uniform vec2 clearcoatNormalScale;
#endif
#ifdef USE_CLEARCOAT_ROUGHNESSMAP
	uniform sampler2D clearcoatRoughnessMap;
#endif`,kp=`#ifdef USE_IRIDESCENCEMAP
	uniform sampler2D iridescenceMap;
#endif
#ifdef USE_IRIDESCENCE_THICKNESSMAP
	uniform sampler2D iridescenceThicknessMap;
#endif`,Hp=`#ifdef OPAQUE
diffuseColor.a = 1.0;
#endif
#ifdef USE_TRANSMISSION
diffuseColor.a *= material.transmissionAlpha;
#endif
gl_FragColor = vec4( outgoingLight, diffuseColor.a );`,Vp=`vec3 packNormalToRGB( const in vec3 normal ) {
	return normalize( normal ) * 0.5 + 0.5;
}
vec3 unpackRGBToNormal( const in vec3 rgb ) {
	return 2.0 * rgb.xyz - 1.0;
}
const float PackUpscale = 256. / 255.;const float UnpackDownscale = 255. / 256.;
const vec3 PackFactors = vec3( 256. * 256. * 256., 256. * 256., 256. );
const vec4 UnpackFactors = UnpackDownscale / vec4( PackFactors, 1. );
const float ShiftRight8 = 1. / 256.;
vec4 packDepthToRGBA( const in float v ) {
	vec4 r = vec4( fract( v * PackFactors ), v );
	r.yzw -= r.xyz * ShiftRight8;	return r * PackUpscale;
}
float unpackRGBAToDepth( const in vec4 v ) {
	return dot( v, UnpackFactors );
}
vec2 packDepthToRG( in highp float v ) {
	return packDepthToRGBA( v ).yx;
}
float unpackRGToDepth( const in highp vec2 v ) {
	return unpackRGBAToDepth( vec4( v.xy, 0.0, 0.0 ) );
}
vec4 pack2HalfToRGBA( vec2 v ) {
	vec4 r = vec4( v.x, fract( v.x * 255.0 ), v.y, fract( v.y * 255.0 ) );
	return vec4( r.x - r.y / 255.0, r.y, r.z - r.w / 255.0, r.w );
}
vec2 unpackRGBATo2Half( vec4 v ) {
	return vec2( v.x + ( v.y / 255.0 ), v.z + ( v.w / 255.0 ) );
}
float viewZToOrthographicDepth( const in float viewZ, const in float near, const in float far ) {
	return ( viewZ + near ) / ( near - far );
}
float orthographicDepthToViewZ( const in float depth, const in float near, const in float far ) {
	return depth * ( near - far ) - near;
}
float viewZToPerspectiveDepth( const in float viewZ, const in float near, const in float far ) {
	return ( ( near + viewZ ) * far ) / ( ( far - near ) * viewZ );
}
float perspectiveDepthToViewZ( const in float depth, const in float near, const in float far ) {
	return ( near * far ) / ( ( far - near ) * depth - far );
}`,Gp=`#ifdef PREMULTIPLIED_ALPHA
	gl_FragColor.rgb *= gl_FragColor.a;
#endif`,Wp=`vec4 mvPosition = vec4( transformed, 1.0 );
#ifdef USE_BATCHING
	mvPosition = batchingMatrix * mvPosition;
#endif
#ifdef USE_INSTANCING
	mvPosition = instanceMatrix * mvPosition;
#endif
mvPosition = modelViewMatrix * mvPosition;
gl_Position = projectionMatrix * mvPosition;`,Xp=`#ifdef DITHERING
	gl_FragColor.rgb = dithering( gl_FragColor.rgb );
#endif`,Yp=`#ifdef DITHERING
	vec3 dithering( vec3 color ) {
		float grid_position = rand( gl_FragCoord.xy );
		vec3 dither_shift_RGB = vec3( 0.25 / 255.0, -0.25 / 255.0, 0.25 / 255.0 );
		dither_shift_RGB = mix( 2.0 * dither_shift_RGB, -2.0 * dither_shift_RGB, grid_position );
		return color + dither_shift_RGB;
	}
#endif`,qp=`float roughnessFactor = roughness;
#ifdef USE_ROUGHNESSMAP
	vec4 texelRoughness = texture2D( roughnessMap, vRoughnessMapUv );
	roughnessFactor *= texelRoughness.g;
#endif`,Zp=`#ifdef USE_ROUGHNESSMAP
	uniform sampler2D roughnessMap;
#endif`,Jp=`#if NUM_SPOT_LIGHT_COORDS > 0
	varying vec4 vSpotLightCoord[ NUM_SPOT_LIGHT_COORDS ];
#endif
#if NUM_SPOT_LIGHT_MAPS > 0
	uniform sampler2D spotLightMap[ NUM_SPOT_LIGHT_MAPS ];
#endif
#ifdef USE_SHADOWMAP
	#if NUM_DIR_LIGHT_SHADOWS > 0
		uniform sampler2D directionalShadowMap[ NUM_DIR_LIGHT_SHADOWS ];
		varying vec4 vDirectionalShadowCoord[ NUM_DIR_LIGHT_SHADOWS ];
		struct DirectionalLightShadow {
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};
		uniform DirectionalLightShadow directionalLightShadows[ NUM_DIR_LIGHT_SHADOWS ];
	#endif
	#if NUM_SPOT_LIGHT_SHADOWS > 0
		uniform sampler2D spotShadowMap[ NUM_SPOT_LIGHT_SHADOWS ];
		struct SpotLightShadow {
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};
		uniform SpotLightShadow spotLightShadows[ NUM_SPOT_LIGHT_SHADOWS ];
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0
		uniform sampler2D pointShadowMap[ NUM_POINT_LIGHT_SHADOWS ];
		varying vec4 vPointShadowCoord[ NUM_POINT_LIGHT_SHADOWS ];
		struct PointLightShadow {
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
			float shadowCameraNear;
			float shadowCameraFar;
		};
		uniform PointLightShadow pointLightShadows[ NUM_POINT_LIGHT_SHADOWS ];
	#endif
	float texture2DCompare( sampler2D depths, vec2 uv, float compare ) {
		return step( compare, unpackRGBAToDepth( texture2D( depths, uv ) ) );
	}
	vec2 texture2DDistribution( sampler2D shadow, vec2 uv ) {
		return unpackRGBATo2Half( texture2D( shadow, uv ) );
	}
	float VSMShadow (sampler2D shadow, vec2 uv, float compare ){
		float occlusion = 1.0;
		vec2 distribution = texture2DDistribution( shadow, uv );
		float hard_shadow = step( compare , distribution.x );
		if (hard_shadow != 1.0 ) {
			float distance = compare - distribution.x ;
			float variance = max( 0.00000, distribution.y * distribution.y );
			float softness_probability = variance / (variance + distance * distance );			softness_probability = clamp( ( softness_probability - 0.3 ) / ( 0.95 - 0.3 ), 0.0, 1.0 );			occlusion = clamp( max( hard_shadow, softness_probability ), 0.0, 1.0 );
		}
		return occlusion;
	}
	float getShadow( sampler2D shadowMap, vec2 shadowMapSize, float shadowBias, float shadowRadius, vec4 shadowCoord ) {
		float shadow = 1.0;
		shadowCoord.xyz /= shadowCoord.w;
		shadowCoord.z += shadowBias;
		bool inFrustum = shadowCoord.x >= 0.0 && shadowCoord.x <= 1.0 && shadowCoord.y >= 0.0 && shadowCoord.y <= 1.0;
		bool frustumTest = inFrustum && shadowCoord.z <= 1.0;
		if ( frustumTest ) {
		#if defined( SHADOWMAP_TYPE_PCF )
			vec2 texelSize = vec2( 1.0 ) / shadowMapSize;
			float dx0 = - texelSize.x * shadowRadius;
			float dy0 = - texelSize.y * shadowRadius;
			float dx1 = + texelSize.x * shadowRadius;
			float dy1 = + texelSize.y * shadowRadius;
			float dx2 = dx0 / 2.0;
			float dy2 = dy0 / 2.0;
			float dx3 = dx1 / 2.0;
			float dy3 = dy1 / 2.0;
			shadow = (
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx0, dy0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( 0.0, dy0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx1, dy0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx2, dy2 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( 0.0, dy2 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx3, dy2 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx0, 0.0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx2, 0.0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy, shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx3, 0.0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx1, 0.0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx2, dy3 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( 0.0, dy3 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx3, dy3 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx0, dy1 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( 0.0, dy1 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx1, dy1 ), shadowCoord.z )
			) * ( 1.0 / 17.0 );
		#elif defined( SHADOWMAP_TYPE_PCF_SOFT )
			vec2 texelSize = vec2( 1.0 ) / shadowMapSize;
			float dx = texelSize.x;
			float dy = texelSize.y;
			vec2 uv = shadowCoord.xy;
			vec2 f = fract( uv * shadowMapSize + 0.5 );
			uv -= f * texelSize;
			shadow = (
				texture2DCompare( shadowMap, uv, shadowCoord.z ) +
				texture2DCompare( shadowMap, uv + vec2( dx, 0.0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, uv + vec2( 0.0, dy ), shadowCoord.z ) +
				texture2DCompare( shadowMap, uv + texelSize, shadowCoord.z ) +
				mix( texture2DCompare( shadowMap, uv + vec2( -dx, 0.0 ), shadowCoord.z ),
					 texture2DCompare( shadowMap, uv + vec2( 2.0 * dx, 0.0 ), shadowCoord.z ),
					 f.x ) +
				mix( texture2DCompare( shadowMap, uv + vec2( -dx, dy ), shadowCoord.z ),
					 texture2DCompare( shadowMap, uv + vec2( 2.0 * dx, dy ), shadowCoord.z ),
					 f.x ) +
				mix( texture2DCompare( shadowMap, uv + vec2( 0.0, -dy ), shadowCoord.z ),
					 texture2DCompare( shadowMap, uv + vec2( 0.0, 2.0 * dy ), shadowCoord.z ),
					 f.y ) +
				mix( texture2DCompare( shadowMap, uv + vec2( dx, -dy ), shadowCoord.z ),
					 texture2DCompare( shadowMap, uv + vec2( dx, 2.0 * dy ), shadowCoord.z ),
					 f.y ) +
				mix( mix( texture2DCompare( shadowMap, uv + vec2( -dx, -dy ), shadowCoord.z ),
						  texture2DCompare( shadowMap, uv + vec2( 2.0 * dx, -dy ), shadowCoord.z ),
						  f.x ),
					 mix( texture2DCompare( shadowMap, uv + vec2( -dx, 2.0 * dy ), shadowCoord.z ),
						  texture2DCompare( shadowMap, uv + vec2( 2.0 * dx, 2.0 * dy ), shadowCoord.z ),
						  f.x ),
					 f.y )
			) * ( 1.0 / 9.0 );
		#elif defined( SHADOWMAP_TYPE_VSM )
			shadow = VSMShadow( shadowMap, shadowCoord.xy, shadowCoord.z );
		#else
			shadow = texture2DCompare( shadowMap, shadowCoord.xy, shadowCoord.z );
		#endif
		}
		return shadow;
	}
	vec2 cubeToUV( vec3 v, float texelSizeY ) {
		vec3 absV = abs( v );
		float scaleToCube = 1.0 / max( absV.x, max( absV.y, absV.z ) );
		absV *= scaleToCube;
		v *= scaleToCube * ( 1.0 - 2.0 * texelSizeY );
		vec2 planar = v.xy;
		float almostATexel = 1.5 * texelSizeY;
		float almostOne = 1.0 - almostATexel;
		if ( absV.z >= almostOne ) {
			if ( v.z > 0.0 )
				planar.x = 4.0 - v.x;
		} else if ( absV.x >= almostOne ) {
			float signX = sign( v.x );
			planar.x = v.z * signX + 2.0 * signX;
		} else if ( absV.y >= almostOne ) {
			float signY = sign( v.y );
			planar.x = v.x + 2.0 * signY + 2.0;
			planar.y = v.z * signY - 2.0;
		}
		return vec2( 0.125, 0.25 ) * planar + vec2( 0.375, 0.75 );
	}
	float getPointShadow( sampler2D shadowMap, vec2 shadowMapSize, float shadowBias, float shadowRadius, vec4 shadowCoord, float shadowCameraNear, float shadowCameraFar ) {
		vec2 texelSize = vec2( 1.0 ) / ( shadowMapSize * vec2( 4.0, 2.0 ) );
		vec3 lightToPosition = shadowCoord.xyz;
		float dp = ( length( lightToPosition ) - shadowCameraNear ) / ( shadowCameraFar - shadowCameraNear );		dp += shadowBias;
		vec3 bd3D = normalize( lightToPosition );
		#if defined( SHADOWMAP_TYPE_PCF ) || defined( SHADOWMAP_TYPE_PCF_SOFT ) || defined( SHADOWMAP_TYPE_VSM )
			vec2 offset = vec2( - 1, 1 ) * shadowRadius * texelSize.y;
			return (
				texture2DCompare( shadowMap, cubeToUV( bd3D + offset.xyy, texelSize.y ), dp ) +
				texture2DCompare( shadowMap, cubeToUV( bd3D + offset.yyy, texelSize.y ), dp ) +
				texture2DCompare( shadowMap, cubeToUV( bd3D + offset.xyx, texelSize.y ), dp ) +
				texture2DCompare( shadowMap, cubeToUV( bd3D + offset.yyx, texelSize.y ), dp ) +
				texture2DCompare( shadowMap, cubeToUV( bd3D, texelSize.y ), dp ) +
				texture2DCompare( shadowMap, cubeToUV( bd3D + offset.xxy, texelSize.y ), dp ) +
				texture2DCompare( shadowMap, cubeToUV( bd3D + offset.yxy, texelSize.y ), dp ) +
				texture2DCompare( shadowMap, cubeToUV( bd3D + offset.xxx, texelSize.y ), dp ) +
				texture2DCompare( shadowMap, cubeToUV( bd3D + offset.yxx, texelSize.y ), dp )
			) * ( 1.0 / 9.0 );
		#else
			return texture2DCompare( shadowMap, cubeToUV( bd3D, texelSize.y ), dp );
		#endif
	}
#endif`,jp=`#if NUM_SPOT_LIGHT_COORDS > 0
	uniform mat4 spotLightMatrix[ NUM_SPOT_LIGHT_COORDS ];
	varying vec4 vSpotLightCoord[ NUM_SPOT_LIGHT_COORDS ];
#endif
#ifdef USE_SHADOWMAP
	#if NUM_DIR_LIGHT_SHADOWS > 0
		uniform mat4 directionalShadowMatrix[ NUM_DIR_LIGHT_SHADOWS ];
		varying vec4 vDirectionalShadowCoord[ NUM_DIR_LIGHT_SHADOWS ];
		struct DirectionalLightShadow {
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};
		uniform DirectionalLightShadow directionalLightShadows[ NUM_DIR_LIGHT_SHADOWS ];
	#endif
	#if NUM_SPOT_LIGHT_SHADOWS > 0
		struct SpotLightShadow {
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};
		uniform SpotLightShadow spotLightShadows[ NUM_SPOT_LIGHT_SHADOWS ];
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0
		uniform mat4 pointShadowMatrix[ NUM_POINT_LIGHT_SHADOWS ];
		varying vec4 vPointShadowCoord[ NUM_POINT_LIGHT_SHADOWS ];
		struct PointLightShadow {
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
			float shadowCameraNear;
			float shadowCameraFar;
		};
		uniform PointLightShadow pointLightShadows[ NUM_POINT_LIGHT_SHADOWS ];
	#endif
#endif`,$p=`#if ( defined( USE_SHADOWMAP ) && ( NUM_DIR_LIGHT_SHADOWS > 0 || NUM_POINT_LIGHT_SHADOWS > 0 ) ) || ( NUM_SPOT_LIGHT_COORDS > 0 )
	vec3 shadowWorldNormal = inverseTransformDirection( transformedNormal, viewMatrix );
	vec4 shadowWorldPosition;
#endif
#if defined( USE_SHADOWMAP )
	#if NUM_DIR_LIGHT_SHADOWS > 0
		#pragma unroll_loop_start
		for ( int i = 0; i < NUM_DIR_LIGHT_SHADOWS; i ++ ) {
			shadowWorldPosition = worldPosition + vec4( shadowWorldNormal * directionalLightShadows[ i ].shadowNormalBias, 0 );
			vDirectionalShadowCoord[ i ] = directionalShadowMatrix[ i ] * shadowWorldPosition;
		}
		#pragma unroll_loop_end
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0
		#pragma unroll_loop_start
		for ( int i = 0; i < NUM_POINT_LIGHT_SHADOWS; i ++ ) {
			shadowWorldPosition = worldPosition + vec4( shadowWorldNormal * pointLightShadows[ i ].shadowNormalBias, 0 );
			vPointShadowCoord[ i ] = pointShadowMatrix[ i ] * shadowWorldPosition;
		}
		#pragma unroll_loop_end
	#endif
#endif
#if NUM_SPOT_LIGHT_COORDS > 0
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_SPOT_LIGHT_COORDS; i ++ ) {
		shadowWorldPosition = worldPosition;
		#if ( defined( USE_SHADOWMAP ) && UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS )
			shadowWorldPosition.xyz += shadowWorldNormal * spotLightShadows[ i ].shadowNormalBias;
		#endif
		vSpotLightCoord[ i ] = spotLightMatrix[ i ] * shadowWorldPosition;
	}
	#pragma unroll_loop_end
#endif`,Kp=`float getShadowMask() {
	float shadow = 1.0;
	#ifdef USE_SHADOWMAP
	#if NUM_DIR_LIGHT_SHADOWS > 0
	DirectionalLightShadow directionalLight;
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_DIR_LIGHT_SHADOWS; i ++ ) {
		directionalLight = directionalLightShadows[ i ];
		shadow *= receiveShadow ? getShadow( directionalShadowMap[ i ], directionalLight.shadowMapSize, directionalLight.shadowBias, directionalLight.shadowRadius, vDirectionalShadowCoord[ i ] ) : 1.0;
	}
	#pragma unroll_loop_end
	#endif
	#if NUM_SPOT_LIGHT_SHADOWS > 0
	SpotLightShadow spotLight;
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_SPOT_LIGHT_SHADOWS; i ++ ) {
		spotLight = spotLightShadows[ i ];
		shadow *= receiveShadow ? getShadow( spotShadowMap[ i ], spotLight.shadowMapSize, spotLight.shadowBias, spotLight.shadowRadius, vSpotLightCoord[ i ] ) : 1.0;
	}
	#pragma unroll_loop_end
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0
	PointLightShadow pointLight;
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_POINT_LIGHT_SHADOWS; i ++ ) {
		pointLight = pointLightShadows[ i ];
		shadow *= receiveShadow ? getPointShadow( pointShadowMap[ i ], pointLight.shadowMapSize, pointLight.shadowBias, pointLight.shadowRadius, vPointShadowCoord[ i ], pointLight.shadowCameraNear, pointLight.shadowCameraFar ) : 1.0;
	}
	#pragma unroll_loop_end
	#endif
	#endif
	return shadow;
}`,Qp=`#ifdef USE_SKINNING
	mat4 boneMatX = getBoneMatrix( skinIndex.x );
	mat4 boneMatY = getBoneMatrix( skinIndex.y );
	mat4 boneMatZ = getBoneMatrix( skinIndex.z );
	mat4 boneMatW = getBoneMatrix( skinIndex.w );
#endif`,tm=`#ifdef USE_SKINNING
	uniform mat4 bindMatrix;
	uniform mat4 bindMatrixInverse;
	uniform highp sampler2D boneTexture;
	mat4 getBoneMatrix( const in float i ) {
		int size = textureSize( boneTexture, 0 ).x;
		int j = int( i ) * 4;
		int x = j % size;
		int y = j / size;
		vec4 v1 = texelFetch( boneTexture, ivec2( x, y ), 0 );
		vec4 v2 = texelFetch( boneTexture, ivec2( x + 1, y ), 0 );
		vec4 v3 = texelFetch( boneTexture, ivec2( x + 2, y ), 0 );
		vec4 v4 = texelFetch( boneTexture, ivec2( x + 3, y ), 0 );
		return mat4( v1, v2, v3, v4 );
	}
#endif`,em=`#ifdef USE_SKINNING
	vec4 skinVertex = bindMatrix * vec4( transformed, 1.0 );
	vec4 skinned = vec4( 0.0 );
	skinned += boneMatX * skinVertex * skinWeight.x;
	skinned += boneMatY * skinVertex * skinWeight.y;
	skinned += boneMatZ * skinVertex * skinWeight.z;
	skinned += boneMatW * skinVertex * skinWeight.w;
	transformed = ( bindMatrixInverse * skinned ).xyz;
#endif`,nm=`#ifdef USE_SKINNING
	mat4 skinMatrix = mat4( 0.0 );
	skinMatrix += skinWeight.x * boneMatX;
	skinMatrix += skinWeight.y * boneMatY;
	skinMatrix += skinWeight.z * boneMatZ;
	skinMatrix += skinWeight.w * boneMatW;
	skinMatrix = bindMatrixInverse * skinMatrix * bindMatrix;
	objectNormal = vec4( skinMatrix * vec4( objectNormal, 0.0 ) ).xyz;
	#ifdef USE_TANGENT
		objectTangent = vec4( skinMatrix * vec4( objectTangent, 0.0 ) ).xyz;
	#endif
#endif`,im=`float specularStrength;
#ifdef USE_SPECULARMAP
	vec4 texelSpecular = texture2D( specularMap, vSpecularMapUv );
	specularStrength = texelSpecular.r;
#else
	specularStrength = 1.0;
#endif`,sm=`#ifdef USE_SPECULARMAP
	uniform sampler2D specularMap;
#endif`,rm=`#if defined( TONE_MAPPING )
	gl_FragColor.rgb = toneMapping( gl_FragColor.rgb );
#endif`,am=`#ifndef saturate
#define saturate( a ) clamp( a, 0.0, 1.0 )
#endif
uniform float toneMappingExposure;
vec3 LinearToneMapping( vec3 color ) {
	return saturate( toneMappingExposure * color );
}
vec3 ReinhardToneMapping( vec3 color ) {
	color *= toneMappingExposure;
	return saturate( color / ( vec3( 1.0 ) + color ) );
}
vec3 OptimizedCineonToneMapping( vec3 color ) {
	color *= toneMappingExposure;
	color = max( vec3( 0.0 ), color - 0.004 );
	return pow( ( color * ( 6.2 * color + 0.5 ) ) / ( color * ( 6.2 * color + 1.7 ) + 0.06 ), vec3( 2.2 ) );
}
vec3 RRTAndODTFit( vec3 v ) {
	vec3 a = v * ( v + 0.0245786 ) - 0.000090537;
	vec3 b = v * ( 0.983729 * v + 0.4329510 ) + 0.238081;
	return a / b;
}
vec3 ACESFilmicToneMapping( vec3 color ) {
	const mat3 ACESInputMat = mat3(
		vec3( 0.59719, 0.07600, 0.02840 ),		vec3( 0.35458, 0.90834, 0.13383 ),
		vec3( 0.04823, 0.01566, 0.83777 )
	);
	const mat3 ACESOutputMat = mat3(
		vec3(  1.60475, -0.10208, -0.00327 ),		vec3( -0.53108,  1.10813, -0.07276 ),
		vec3( -0.07367, -0.00605,  1.07602 )
	);
	color *= toneMappingExposure / 0.6;
	color = ACESInputMat * color;
	color = RRTAndODTFit( color );
	color = ACESOutputMat * color;
	return saturate( color );
}
const mat3 LINEAR_REC2020_TO_LINEAR_SRGB = mat3(
	vec3( 1.6605, - 0.1246, - 0.0182 ),
	vec3( - 0.5876, 1.1329, - 0.1006 ),
	vec3( - 0.0728, - 0.0083, 1.1187 )
);
const mat3 LINEAR_SRGB_TO_LINEAR_REC2020 = mat3(
	vec3( 0.6274, 0.0691, 0.0164 ),
	vec3( 0.3293, 0.9195, 0.0880 ),
	vec3( 0.0433, 0.0113, 0.8956 )
);
vec3 agxDefaultContrastApprox( vec3 x ) {
	vec3 x2 = x * x;
	vec3 x4 = x2 * x2;
	return + 15.5 * x4 * x2
		- 40.14 * x4 * x
		+ 31.96 * x4
		- 6.868 * x2 * x
		+ 0.4298 * x2
		+ 0.1191 * x
		- 0.00232;
}
vec3 AgXToneMapping( vec3 color ) {
	const mat3 AgXInsetMatrix = mat3(
		vec3( 0.856627153315983, 0.137318972929847, 0.11189821299995 ),
		vec3( 0.0951212405381588, 0.761241990602591, 0.0767994186031903 ),
		vec3( 0.0482516061458583, 0.101439036467562, 0.811302368396859 )
	);
	const mat3 AgXOutsetMatrix = mat3(
		vec3( 1.1271005818144368, - 0.1413297634984383, - 0.14132976349843826 ),
		vec3( - 0.11060664309660323, 1.157823702216272, - 0.11060664309660294 ),
		vec3( - 0.016493938717834573, - 0.016493938717834257, 1.2519364065950405 )
	);
	const float AgxMinEv = - 12.47393;	const float AgxMaxEv = 4.026069;
	color = LINEAR_SRGB_TO_LINEAR_REC2020 * color;
	color *= toneMappingExposure;
	color = AgXInsetMatrix * color;
	color = max( color, 1e-10 );	color = log2( color );
	color = ( color - AgxMinEv ) / ( AgxMaxEv - AgxMinEv );
	color = clamp( color, 0.0, 1.0 );
	color = agxDefaultContrastApprox( color );
	color = AgXOutsetMatrix * color;
	color = pow( max( vec3( 0.0 ), color ), vec3( 2.2 ) );
	color = LINEAR_REC2020_TO_LINEAR_SRGB * color;
	return color;
}
vec3 CustomToneMapping( vec3 color ) { return color; }`,om=`#ifdef USE_TRANSMISSION
	material.transmission = transmission;
	material.transmissionAlpha = 1.0;
	material.thickness = thickness;
	material.attenuationDistance = attenuationDistance;
	material.attenuationColor = attenuationColor;
	#ifdef USE_TRANSMISSIONMAP
		material.transmission *= texture2D( transmissionMap, vTransmissionMapUv ).r;
	#endif
	#ifdef USE_THICKNESSMAP
		material.thickness *= texture2D( thicknessMap, vThicknessMapUv ).g;
	#endif
	vec3 pos = vWorldPosition;
	vec3 v = normalize( cameraPosition - pos );
	vec3 n = inverseTransformDirection( normal, viewMatrix );
	vec4 transmitted = getIBLVolumeRefraction(
		n, v, material.roughness, material.diffuseColor, material.specularColor, material.specularF90,
		pos, modelMatrix, viewMatrix, projectionMatrix, material.ior, material.thickness,
		material.attenuationColor, material.attenuationDistance );
	material.transmissionAlpha = mix( material.transmissionAlpha, transmitted.a, material.transmission );
	totalDiffuse = mix( totalDiffuse, transmitted.rgb, material.transmission );
#endif`,lm=`#ifdef USE_TRANSMISSION
	uniform float transmission;
	uniform float thickness;
	uniform float attenuationDistance;
	uniform vec3 attenuationColor;
	#ifdef USE_TRANSMISSIONMAP
		uniform sampler2D transmissionMap;
	#endif
	#ifdef USE_THICKNESSMAP
		uniform sampler2D thicknessMap;
	#endif
	uniform vec2 transmissionSamplerSize;
	uniform sampler2D transmissionSamplerMap;
	uniform mat4 modelMatrix;
	uniform mat4 projectionMatrix;
	varying vec3 vWorldPosition;
	float w0( float a ) {
		return ( 1.0 / 6.0 ) * ( a * ( a * ( - a + 3.0 ) - 3.0 ) + 1.0 );
	}
	float w1( float a ) {
		return ( 1.0 / 6.0 ) * ( a *  a * ( 3.0 * a - 6.0 ) + 4.0 );
	}
	float w2( float a ){
		return ( 1.0 / 6.0 ) * ( a * ( a * ( - 3.0 * a + 3.0 ) + 3.0 ) + 1.0 );
	}
	float w3( float a ) {
		return ( 1.0 / 6.0 ) * ( a * a * a );
	}
	float g0( float a ) {
		return w0( a ) + w1( a );
	}
	float g1( float a ) {
		return w2( a ) + w3( a );
	}
	float h0( float a ) {
		return - 1.0 + w1( a ) / ( w0( a ) + w1( a ) );
	}
	float h1( float a ) {
		return 1.0 + w3( a ) / ( w2( a ) + w3( a ) );
	}
	vec4 bicubic( sampler2D tex, vec2 uv, vec4 texelSize, float lod ) {
		uv = uv * texelSize.zw + 0.5;
		vec2 iuv = floor( uv );
		vec2 fuv = fract( uv );
		float g0x = g0( fuv.x );
		float g1x = g1( fuv.x );
		float h0x = h0( fuv.x );
		float h1x = h1( fuv.x );
		float h0y = h0( fuv.y );
		float h1y = h1( fuv.y );
		vec2 p0 = ( vec2( iuv.x + h0x, iuv.y + h0y ) - 0.5 ) * texelSize.xy;
		vec2 p1 = ( vec2( iuv.x + h1x, iuv.y + h0y ) - 0.5 ) * texelSize.xy;
		vec2 p2 = ( vec2( iuv.x + h0x, iuv.y + h1y ) - 0.5 ) * texelSize.xy;
		vec2 p3 = ( vec2( iuv.x + h1x, iuv.y + h1y ) - 0.5 ) * texelSize.xy;
		return g0( fuv.y ) * ( g0x * textureLod( tex, p0, lod ) + g1x * textureLod( tex, p1, lod ) ) +
			g1( fuv.y ) * ( g0x * textureLod( tex, p2, lod ) + g1x * textureLod( tex, p3, lod ) );
	}
	vec4 textureBicubic( sampler2D sampler, vec2 uv, float lod ) {
		vec2 fLodSize = vec2( textureSize( sampler, int( lod ) ) );
		vec2 cLodSize = vec2( textureSize( sampler, int( lod + 1.0 ) ) );
		vec2 fLodSizeInv = 1.0 / fLodSize;
		vec2 cLodSizeInv = 1.0 / cLodSize;
		vec4 fSample = bicubic( sampler, uv, vec4( fLodSizeInv, fLodSize ), floor( lod ) );
		vec4 cSample = bicubic( sampler, uv, vec4( cLodSizeInv, cLodSize ), ceil( lod ) );
		return mix( fSample, cSample, fract( lod ) );
	}
	vec3 getVolumeTransmissionRay( const in vec3 n, const in vec3 v, const in float thickness, const in float ior, const in mat4 modelMatrix ) {
		vec3 refractionVector = refract( - v, normalize( n ), 1.0 / ior );
		vec3 modelScale;
		modelScale.x = length( vec3( modelMatrix[ 0 ].xyz ) );
		modelScale.y = length( vec3( modelMatrix[ 1 ].xyz ) );
		modelScale.z = length( vec3( modelMatrix[ 2 ].xyz ) );
		return normalize( refractionVector ) * thickness * modelScale;
	}
	float applyIorToRoughness( const in float roughness, const in float ior ) {
		return roughness * clamp( ior * 2.0 - 2.0, 0.0, 1.0 );
	}
	vec4 getTransmissionSample( const in vec2 fragCoord, const in float roughness, const in float ior ) {
		float lod = log2( transmissionSamplerSize.x ) * applyIorToRoughness( roughness, ior );
		return textureBicubic( transmissionSamplerMap, fragCoord.xy, lod );
	}
	vec3 volumeAttenuation( const in float transmissionDistance, const in vec3 attenuationColor, const in float attenuationDistance ) {
		if ( isinf( attenuationDistance ) ) {
			return vec3( 1.0 );
		} else {
			vec3 attenuationCoefficient = -log( attenuationColor ) / attenuationDistance;
			vec3 transmittance = exp( - attenuationCoefficient * transmissionDistance );			return transmittance;
		}
	}
	vec4 getIBLVolumeRefraction( const in vec3 n, const in vec3 v, const in float roughness, const in vec3 diffuseColor,
		const in vec3 specularColor, const in float specularF90, const in vec3 position, const in mat4 modelMatrix,
		const in mat4 viewMatrix, const in mat4 projMatrix, const in float ior, const in float thickness,
		const in vec3 attenuationColor, const in float attenuationDistance ) {
		vec3 transmissionRay = getVolumeTransmissionRay( n, v, thickness, ior, modelMatrix );
		vec3 refractedRayExit = position + transmissionRay;
		vec4 ndcPos = projMatrix * viewMatrix * vec4( refractedRayExit, 1.0 );
		vec2 refractionCoords = ndcPos.xy / ndcPos.w;
		refractionCoords += 1.0;
		refractionCoords /= 2.0;
		vec4 transmittedLight = getTransmissionSample( refractionCoords, roughness, ior );
		vec3 transmittance = diffuseColor * volumeAttenuation( length( transmissionRay ), attenuationColor, attenuationDistance );
		vec3 attenuatedColor = transmittance * transmittedLight.rgb;
		vec3 F = EnvironmentBRDF( n, v, specularColor, specularF90, roughness );
		float transmittanceFactor = ( transmittance.r + transmittance.g + transmittance.b ) / 3.0;
		return vec4( ( 1.0 - F ) * attenuatedColor, 1.0 - ( 1.0 - transmittedLight.a ) * transmittanceFactor );
	}
#endif`,cm=`#if defined( USE_UV ) || defined( USE_ANISOTROPY )
	varying vec2 vUv;
#endif
#ifdef USE_MAP
	varying vec2 vMapUv;
#endif
#ifdef USE_ALPHAMAP
	varying vec2 vAlphaMapUv;
#endif
#ifdef USE_LIGHTMAP
	varying vec2 vLightMapUv;
#endif
#ifdef USE_AOMAP
	varying vec2 vAoMapUv;
#endif
#ifdef USE_BUMPMAP
	varying vec2 vBumpMapUv;
#endif
#ifdef USE_NORMALMAP
	varying vec2 vNormalMapUv;
#endif
#ifdef USE_EMISSIVEMAP
	varying vec2 vEmissiveMapUv;
#endif
#ifdef USE_METALNESSMAP
	varying vec2 vMetalnessMapUv;
#endif
#ifdef USE_ROUGHNESSMAP
	varying vec2 vRoughnessMapUv;
#endif
#ifdef USE_ANISOTROPYMAP
	varying vec2 vAnisotropyMapUv;
#endif
#ifdef USE_CLEARCOATMAP
	varying vec2 vClearcoatMapUv;
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	varying vec2 vClearcoatNormalMapUv;
#endif
#ifdef USE_CLEARCOAT_ROUGHNESSMAP
	varying vec2 vClearcoatRoughnessMapUv;
#endif
#ifdef USE_IRIDESCENCEMAP
	varying vec2 vIridescenceMapUv;
#endif
#ifdef USE_IRIDESCENCE_THICKNESSMAP
	varying vec2 vIridescenceThicknessMapUv;
#endif
#ifdef USE_SHEEN_COLORMAP
	varying vec2 vSheenColorMapUv;
#endif
#ifdef USE_SHEEN_ROUGHNESSMAP
	varying vec2 vSheenRoughnessMapUv;
#endif
#ifdef USE_SPECULARMAP
	varying vec2 vSpecularMapUv;
#endif
#ifdef USE_SPECULAR_COLORMAP
	varying vec2 vSpecularColorMapUv;
#endif
#ifdef USE_SPECULAR_INTENSITYMAP
	varying vec2 vSpecularIntensityMapUv;
#endif
#ifdef USE_TRANSMISSIONMAP
	uniform mat3 transmissionMapTransform;
	varying vec2 vTransmissionMapUv;
#endif
#ifdef USE_THICKNESSMAP
	uniform mat3 thicknessMapTransform;
	varying vec2 vThicknessMapUv;
#endif`,hm=`#if defined( USE_UV ) || defined( USE_ANISOTROPY )
	varying vec2 vUv;
#endif
#ifdef USE_MAP
	uniform mat3 mapTransform;
	varying vec2 vMapUv;
#endif
#ifdef USE_ALPHAMAP
	uniform mat3 alphaMapTransform;
	varying vec2 vAlphaMapUv;
#endif
#ifdef USE_LIGHTMAP
	uniform mat3 lightMapTransform;
	varying vec2 vLightMapUv;
#endif
#ifdef USE_AOMAP
	uniform mat3 aoMapTransform;
	varying vec2 vAoMapUv;
#endif
#ifdef USE_BUMPMAP
	uniform mat3 bumpMapTransform;
	varying vec2 vBumpMapUv;
#endif
#ifdef USE_NORMALMAP
	uniform mat3 normalMapTransform;
	varying vec2 vNormalMapUv;
#endif
#ifdef USE_DISPLACEMENTMAP
	uniform mat3 displacementMapTransform;
	varying vec2 vDisplacementMapUv;
#endif
#ifdef USE_EMISSIVEMAP
	uniform mat3 emissiveMapTransform;
	varying vec2 vEmissiveMapUv;
#endif
#ifdef USE_METALNESSMAP
	uniform mat3 metalnessMapTransform;
	varying vec2 vMetalnessMapUv;
#endif
#ifdef USE_ROUGHNESSMAP
	uniform mat3 roughnessMapTransform;
	varying vec2 vRoughnessMapUv;
#endif
#ifdef USE_ANISOTROPYMAP
	uniform mat3 anisotropyMapTransform;
	varying vec2 vAnisotropyMapUv;
#endif
#ifdef USE_CLEARCOATMAP
	uniform mat3 clearcoatMapTransform;
	varying vec2 vClearcoatMapUv;
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	uniform mat3 clearcoatNormalMapTransform;
	varying vec2 vClearcoatNormalMapUv;
#endif
#ifdef USE_CLEARCOAT_ROUGHNESSMAP
	uniform mat3 clearcoatRoughnessMapTransform;
	varying vec2 vClearcoatRoughnessMapUv;
#endif
#ifdef USE_SHEEN_COLORMAP
	uniform mat3 sheenColorMapTransform;
	varying vec2 vSheenColorMapUv;
#endif
#ifdef USE_SHEEN_ROUGHNESSMAP
	uniform mat3 sheenRoughnessMapTransform;
	varying vec2 vSheenRoughnessMapUv;
#endif
#ifdef USE_IRIDESCENCEMAP
	uniform mat3 iridescenceMapTransform;
	varying vec2 vIridescenceMapUv;
#endif
#ifdef USE_IRIDESCENCE_THICKNESSMAP
	uniform mat3 iridescenceThicknessMapTransform;
	varying vec2 vIridescenceThicknessMapUv;
#endif
#ifdef USE_SPECULARMAP
	uniform mat3 specularMapTransform;
	varying vec2 vSpecularMapUv;
#endif
#ifdef USE_SPECULAR_COLORMAP
	uniform mat3 specularColorMapTransform;
	varying vec2 vSpecularColorMapUv;
#endif
#ifdef USE_SPECULAR_INTENSITYMAP
	uniform mat3 specularIntensityMapTransform;
	varying vec2 vSpecularIntensityMapUv;
#endif
#ifdef USE_TRANSMISSIONMAP
	uniform mat3 transmissionMapTransform;
	varying vec2 vTransmissionMapUv;
#endif
#ifdef USE_THICKNESSMAP
	uniform mat3 thicknessMapTransform;
	varying vec2 vThicknessMapUv;
#endif`,um=`#if defined( USE_UV ) || defined( USE_ANISOTROPY )
	vUv = vec3( uv, 1 ).xy;
#endif
#ifdef USE_MAP
	vMapUv = ( mapTransform * vec3( MAP_UV, 1 ) ).xy;
#endif
#ifdef USE_ALPHAMAP
	vAlphaMapUv = ( alphaMapTransform * vec3( ALPHAMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_LIGHTMAP
	vLightMapUv = ( lightMapTransform * vec3( LIGHTMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_AOMAP
	vAoMapUv = ( aoMapTransform * vec3( AOMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_BUMPMAP
	vBumpMapUv = ( bumpMapTransform * vec3( BUMPMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_NORMALMAP
	vNormalMapUv = ( normalMapTransform * vec3( NORMALMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_DISPLACEMENTMAP
	vDisplacementMapUv = ( displacementMapTransform * vec3( DISPLACEMENTMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_EMISSIVEMAP
	vEmissiveMapUv = ( emissiveMapTransform * vec3( EMISSIVEMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_METALNESSMAP
	vMetalnessMapUv = ( metalnessMapTransform * vec3( METALNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_ROUGHNESSMAP
	vRoughnessMapUv = ( roughnessMapTransform * vec3( ROUGHNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_ANISOTROPYMAP
	vAnisotropyMapUv = ( anisotropyMapTransform * vec3( ANISOTROPYMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_CLEARCOATMAP
	vClearcoatMapUv = ( clearcoatMapTransform * vec3( CLEARCOATMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	vClearcoatNormalMapUv = ( clearcoatNormalMapTransform * vec3( CLEARCOAT_NORMALMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_CLEARCOAT_ROUGHNESSMAP
	vClearcoatRoughnessMapUv = ( clearcoatRoughnessMapTransform * vec3( CLEARCOAT_ROUGHNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_IRIDESCENCEMAP
	vIridescenceMapUv = ( iridescenceMapTransform * vec3( IRIDESCENCEMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_IRIDESCENCE_THICKNESSMAP
	vIridescenceThicknessMapUv = ( iridescenceThicknessMapTransform * vec3( IRIDESCENCE_THICKNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SHEEN_COLORMAP
	vSheenColorMapUv = ( sheenColorMapTransform * vec3( SHEEN_COLORMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SHEEN_ROUGHNESSMAP
	vSheenRoughnessMapUv = ( sheenRoughnessMapTransform * vec3( SHEEN_ROUGHNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SPECULARMAP
	vSpecularMapUv = ( specularMapTransform * vec3( SPECULARMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SPECULAR_COLORMAP
	vSpecularColorMapUv = ( specularColorMapTransform * vec3( SPECULAR_COLORMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SPECULAR_INTENSITYMAP
	vSpecularIntensityMapUv = ( specularIntensityMapTransform * vec3( SPECULAR_INTENSITYMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_TRANSMISSIONMAP
	vTransmissionMapUv = ( transmissionMapTransform * vec3( TRANSMISSIONMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_THICKNESSMAP
	vThicknessMapUv = ( thicknessMapTransform * vec3( THICKNESSMAP_UV, 1 ) ).xy;
#endif`,dm=`#if defined( USE_ENVMAP ) || defined( DISTANCE ) || defined ( USE_SHADOWMAP ) || defined ( USE_TRANSMISSION ) || NUM_SPOT_LIGHT_COORDS > 0
	vec4 worldPosition = vec4( transformed, 1.0 );
	#ifdef USE_BATCHING
		worldPosition = batchingMatrix * worldPosition;
	#endif
	#ifdef USE_INSTANCING
		worldPosition = instanceMatrix * worldPosition;
	#endif
	worldPosition = modelMatrix * worldPosition;
#endif`,fm=`varying vec2 vUv;
uniform mat3 uvTransform;
void main() {
	vUv = ( uvTransform * vec3( uv, 1 ) ).xy;
	gl_Position = vec4( position.xy, 1.0, 1.0 );
}`,pm=`uniform sampler2D t2D;
uniform float backgroundIntensity;
varying vec2 vUv;
void main() {
	vec4 texColor = texture2D( t2D, vUv );
	#ifdef DECODE_VIDEO_TEXTURE
		texColor = vec4( mix( pow( texColor.rgb * 0.9478672986 + vec3( 0.0521327014 ), vec3( 2.4 ) ), texColor.rgb * 0.0773993808, vec3( lessThanEqual( texColor.rgb, vec3( 0.04045 ) ) ) ), texColor.w );
	#endif
	texColor.rgb *= backgroundIntensity;
	gl_FragColor = texColor;
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
}`,mm=`varying vec3 vWorldDirection;
#include <common>
void main() {
	vWorldDirection = transformDirection( position, modelMatrix );
	#include <begin_vertex>
	#include <project_vertex>
	gl_Position.z = gl_Position.w;
}`,gm=`#ifdef ENVMAP_TYPE_CUBE
	uniform samplerCube envMap;
#elif defined( ENVMAP_TYPE_CUBE_UV )
	uniform sampler2D envMap;
#endif
uniform float flipEnvMap;
uniform float backgroundBlurriness;
uniform float backgroundIntensity;
varying vec3 vWorldDirection;
#include <cube_uv_reflection_fragment>
void main() {
	#ifdef ENVMAP_TYPE_CUBE
		vec4 texColor = textureCube( envMap, vec3( flipEnvMap * vWorldDirection.x, vWorldDirection.yz ) );
	#elif defined( ENVMAP_TYPE_CUBE_UV )
		vec4 texColor = textureCubeUV( envMap, vWorldDirection, backgroundBlurriness );
	#else
		vec4 texColor = vec4( 0.0, 0.0, 0.0, 1.0 );
	#endif
	texColor.rgb *= backgroundIntensity;
	gl_FragColor = texColor;
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
}`,xm=`varying vec3 vWorldDirection;
#include <common>
void main() {
	vWorldDirection = transformDirection( position, modelMatrix );
	#include <begin_vertex>
	#include <project_vertex>
	gl_Position.z = gl_Position.w;
}`,_m=`uniform samplerCube tCube;
uniform float tFlip;
uniform float opacity;
varying vec3 vWorldDirection;
void main() {
	vec4 texColor = textureCube( tCube, vec3( tFlip * vWorldDirection.x, vWorldDirection.yz ) );
	gl_FragColor = texColor;
	gl_FragColor.a *= opacity;
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
}`,vm=`#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
varying vec2 vHighPrecisionZW;
void main() {
	#include <uv_vertex>
	#include <batching_vertex>
	#include <skinbase_vertex>
	#ifdef USE_DISPLACEMENTMAP
		#include <beginnormal_vertex>
		#include <morphnormal_vertex>
		#include <skinnormal_vertex>
	#endif
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vHighPrecisionZW = gl_Position.zw;
}`,ym=`#if DEPTH_PACKING == 3200
	uniform float opacity;
#endif
#include <common>
#include <packing>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
varying vec2 vHighPrecisionZW;
void main() {
	#include <clipping_planes_fragment>
	vec4 diffuseColor = vec4( 1.0 );
	#if DEPTH_PACKING == 3200
		diffuseColor.a = opacity;
	#endif
	#include <map_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <logdepthbuf_fragment>
	float fragCoordZ = 0.5 * vHighPrecisionZW[0] / vHighPrecisionZW[1] + 0.5;
	#if DEPTH_PACKING == 3200
		gl_FragColor = vec4( vec3( 1.0 - fragCoordZ ), opacity );
	#elif DEPTH_PACKING == 3201
		gl_FragColor = packDepthToRGBA( fragCoordZ );
	#endif
}`,bm=`#define DISTANCE
varying vec3 vWorldPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <batching_vertex>
	#include <skinbase_vertex>
	#ifdef USE_DISPLACEMENTMAP
		#include <beginnormal_vertex>
		#include <morphnormal_vertex>
		#include <skinnormal_vertex>
	#endif
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <worldpos_vertex>
	#include <clipping_planes_vertex>
	vWorldPosition = worldPosition.xyz;
}`,Mm=`#define DISTANCE
uniform vec3 referencePosition;
uniform float nearDistance;
uniform float farDistance;
varying vec3 vWorldPosition;
#include <common>
#include <packing>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <clipping_planes_pars_fragment>
void main () {
	#include <clipping_planes_fragment>
	vec4 diffuseColor = vec4( 1.0 );
	#include <map_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	float dist = length( vWorldPosition - referencePosition );
	dist = ( dist - nearDistance ) / ( farDistance - nearDistance );
	dist = saturate( dist );
	gl_FragColor = packDepthToRGBA( dist );
}`,Sm=`varying vec3 vWorldDirection;
#include <common>
void main() {
	vWorldDirection = transformDirection( position, modelMatrix );
	#include <begin_vertex>
	#include <project_vertex>
}`,wm=`uniform sampler2D tEquirect;
varying vec3 vWorldDirection;
#include <common>
void main() {
	vec3 direction = normalize( vWorldDirection );
	vec2 sampleUV = equirectUv( direction );
	gl_FragColor = texture2D( tEquirect, sampleUV );
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
}`,Em=`uniform float scale;
attribute float lineDistance;
varying float vLineDistance;
#include <common>
#include <uv_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <morphtarget_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	vLineDistance = scale * lineDistance;
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphcolor_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <fog_vertex>
}`,Tm=`uniform vec3 diffuse;
uniform float opacity;
uniform float dashSize;
uniform float totalSize;
varying float vLineDistance;
#include <common>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <fog_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	#include <clipping_planes_fragment>
	if ( mod( vLineDistance, totalSize ) > dashSize ) {
		discard;
	}
	vec3 outgoingLight = vec3( 0.0 );
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	outgoingLight = diffuseColor.rgb;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
}`,Am=`#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <envmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#if defined ( USE_ENVMAP ) || defined ( USE_SKINNING )
		#include <beginnormal_vertex>
		#include <morphnormal_vertex>
		#include <skinbase_vertex>
		#include <skinnormal_vertex>
		#include <defaultnormal_vertex>
	#endif
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <worldpos_vertex>
	#include <envmap_vertex>
	#include <fog_vertex>
}`,Cm=`uniform vec3 diffuse;
uniform float opacity;
#ifndef FLAT_SHADED
	varying vec3 vNormal;
#endif
#include <common>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <envmap_common_pars_fragment>
#include <envmap_pars_fragment>
#include <fog_pars_fragment>
#include <specularmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	#include <clipping_planes_fragment>
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <specularmap_fragment>
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	#ifdef USE_LIGHTMAP
		vec4 lightMapTexel = texture2D( lightMap, vLightMapUv );
		reflectedLight.indirectDiffuse += lightMapTexel.rgb * lightMapIntensity * RECIPROCAL_PI;
	#else
		reflectedLight.indirectDiffuse += vec3( 1.0 );
	#endif
	#include <aomap_fragment>
	reflectedLight.indirectDiffuse *= diffuseColor.rgb;
	vec3 outgoingLight = reflectedLight.indirectDiffuse;
	#include <envmap_fragment>
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,Rm=`#define LAMBERT
varying vec3 vViewPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <envmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <shadowmap_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vViewPosition = - mvPosition.xyz;
	#include <worldpos_vertex>
	#include <envmap_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
}`,Pm=`#define LAMBERT
uniform vec3 diffuse;
uniform vec3 emissive;
uniform float opacity;
#include <common>
#include <packing>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <emissivemap_pars_fragment>
#include <envmap_common_pars_fragment>
#include <envmap_pars_fragment>
#include <fog_pars_fragment>
#include <bsdfs>
#include <lights_pars_begin>
#include <normal_pars_fragment>
#include <lights_lambert_pars_fragment>
#include <shadowmap_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <specularmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	#include <clipping_planes_fragment>
	vec4 diffuseColor = vec4( diffuse, opacity );
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	vec3 totalEmissiveRadiance = emissive;
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <specularmap_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	#include <emissivemap_fragment>
	#include <lights_lambert_fragment>
	#include <lights_fragment_begin>
	#include <lights_fragment_maps>
	#include <lights_fragment_end>
	#include <aomap_fragment>
	vec3 outgoingLight = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse + totalEmissiveRadiance;
	#include <envmap_fragment>
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,Lm=`#define MATCAP
varying vec3 vViewPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <color_pars_vertex>
#include <displacementmap_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <fog_vertex>
	vViewPosition = - mvPosition.xyz;
}`,Im=`#define MATCAP
uniform vec3 diffuse;
uniform float opacity;
uniform sampler2D matcap;
varying vec3 vViewPosition;
#include <common>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <fog_pars_fragment>
#include <normal_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	#include <clipping_planes_fragment>
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	vec3 viewDir = normalize( vViewPosition );
	vec3 x = normalize( vec3( viewDir.z, 0.0, - viewDir.x ) );
	vec3 y = cross( viewDir, x );
	vec2 uv = vec2( dot( x, normal ), dot( y, normal ) ) * 0.495 + 0.5;
	#ifdef USE_MATCAP
		vec4 matcapColor = texture2D( matcap, uv );
	#else
		vec4 matcapColor = vec4( vec3( mix( 0.2, 0.8, uv.y ) ), 1.0 );
	#endif
	vec3 outgoingLight = diffuseColor.rgb * matcapColor.rgb;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,Dm=`#define NORMAL
#if defined( FLAT_SHADED ) || defined( USE_BUMPMAP ) || defined( USE_NORMALMAP_TANGENTSPACE )
	varying vec3 vViewPosition;
#endif
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
#if defined( FLAT_SHADED ) || defined( USE_BUMPMAP ) || defined( USE_NORMALMAP_TANGENTSPACE )
	vViewPosition = - mvPosition.xyz;
#endif
}`,Um=`#define NORMAL
uniform float opacity;
#if defined( FLAT_SHADED ) || defined( USE_BUMPMAP ) || defined( USE_NORMALMAP_TANGENTSPACE )
	varying vec3 vViewPosition;
#endif
#include <packing>
#include <uv_pars_fragment>
#include <normal_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	#include <clipping_planes_fragment>
	#include <logdepthbuf_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	gl_FragColor = vec4( packNormalToRGB( normal ), opacity );
	#ifdef OPAQUE
		gl_FragColor.a = 1.0;
	#endif
}`,Nm=`#define PHONG
varying vec3 vViewPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <envmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <shadowmap_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vViewPosition = - mvPosition.xyz;
	#include <worldpos_vertex>
	#include <envmap_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
}`,Om=`#define PHONG
uniform vec3 diffuse;
uniform vec3 emissive;
uniform vec3 specular;
uniform float shininess;
uniform float opacity;
#include <common>
#include <packing>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <emissivemap_pars_fragment>
#include <envmap_common_pars_fragment>
#include <envmap_pars_fragment>
#include <fog_pars_fragment>
#include <bsdfs>
#include <lights_pars_begin>
#include <normal_pars_fragment>
#include <lights_phong_pars_fragment>
#include <shadowmap_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <specularmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	#include <clipping_planes_fragment>
	vec4 diffuseColor = vec4( diffuse, opacity );
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	vec3 totalEmissiveRadiance = emissive;
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <specularmap_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	#include <emissivemap_fragment>
	#include <lights_phong_fragment>
	#include <lights_fragment_begin>
	#include <lights_fragment_maps>
	#include <lights_fragment_end>
	#include <aomap_fragment>
	vec3 outgoingLight = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse + reflectedLight.directSpecular + reflectedLight.indirectSpecular + totalEmissiveRadiance;
	#include <envmap_fragment>
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,Fm=`#define STANDARD
varying vec3 vViewPosition;
#ifdef USE_TRANSMISSION
	varying vec3 vWorldPosition;
#endif
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <shadowmap_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vViewPosition = - mvPosition.xyz;
	#include <worldpos_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
#ifdef USE_TRANSMISSION
	vWorldPosition = worldPosition.xyz;
#endif
}`,Bm=`#define STANDARD
#ifdef PHYSICAL
	#define IOR
	#define USE_SPECULAR
#endif
uniform vec3 diffuse;
uniform vec3 emissive;
uniform float roughness;
uniform float metalness;
uniform float opacity;
#ifdef IOR
	uniform float ior;
#endif
#ifdef USE_SPECULAR
	uniform float specularIntensity;
	uniform vec3 specularColor;
	#ifdef USE_SPECULAR_COLORMAP
		uniform sampler2D specularColorMap;
	#endif
	#ifdef USE_SPECULAR_INTENSITYMAP
		uniform sampler2D specularIntensityMap;
	#endif
#endif
#ifdef USE_CLEARCOAT
	uniform float clearcoat;
	uniform float clearcoatRoughness;
#endif
#ifdef USE_IRIDESCENCE
	uniform float iridescence;
	uniform float iridescenceIOR;
	uniform float iridescenceThicknessMinimum;
	uniform float iridescenceThicknessMaximum;
#endif
#ifdef USE_SHEEN
	uniform vec3 sheenColor;
	uniform float sheenRoughness;
	#ifdef USE_SHEEN_COLORMAP
		uniform sampler2D sheenColorMap;
	#endif
	#ifdef USE_SHEEN_ROUGHNESSMAP
		uniform sampler2D sheenRoughnessMap;
	#endif
#endif
#ifdef USE_ANISOTROPY
	uniform vec2 anisotropyVector;
	#ifdef USE_ANISOTROPYMAP
		uniform sampler2D anisotropyMap;
	#endif
#endif
varying vec3 vViewPosition;
#include <common>
#include <packing>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <emissivemap_pars_fragment>
#include <iridescence_fragment>
#include <cube_uv_reflection_fragment>
#include <envmap_common_pars_fragment>
#include <envmap_physical_pars_fragment>
#include <fog_pars_fragment>
#include <lights_pars_begin>
#include <normal_pars_fragment>
#include <lights_physical_pars_fragment>
#include <transmission_pars_fragment>
#include <shadowmap_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <clearcoat_pars_fragment>
#include <iridescence_pars_fragment>
#include <roughnessmap_pars_fragment>
#include <metalnessmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	#include <clipping_planes_fragment>
	vec4 diffuseColor = vec4( diffuse, opacity );
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	vec3 totalEmissiveRadiance = emissive;
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <roughnessmap_fragment>
	#include <metalnessmap_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	#include <clearcoat_normal_fragment_begin>
	#include <clearcoat_normal_fragment_maps>
	#include <emissivemap_fragment>
	#include <lights_physical_fragment>
	#include <lights_fragment_begin>
	#include <lights_fragment_maps>
	#include <lights_fragment_end>
	#include <aomap_fragment>
	vec3 totalDiffuse = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse;
	vec3 totalSpecular = reflectedLight.directSpecular + reflectedLight.indirectSpecular;
	#include <transmission_fragment>
	vec3 outgoingLight = totalDiffuse + totalSpecular + totalEmissiveRadiance;
	#ifdef USE_SHEEN
		float sheenEnergyComp = 1.0 - 0.157 * max3( material.sheenColor );
		outgoingLight = outgoingLight * sheenEnergyComp + sheenSpecularDirect + sheenSpecularIndirect;
	#endif
	#ifdef USE_CLEARCOAT
		float dotNVcc = saturate( dot( geometryClearcoatNormal, geometryViewDir ) );
		vec3 Fcc = F_Schlick( material.clearcoatF0, material.clearcoatF90, dotNVcc );
		outgoingLight = outgoingLight * ( 1.0 - material.clearcoat * Fcc ) + ( clearcoatSpecularDirect + clearcoatSpecularIndirect ) * material.clearcoat;
	#endif
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,zm=`#define TOON
varying vec3 vViewPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <shadowmap_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vViewPosition = - mvPosition.xyz;
	#include <worldpos_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
}`,km=`#define TOON
uniform vec3 diffuse;
uniform vec3 emissive;
uniform float opacity;
#include <common>
#include <packing>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <emissivemap_pars_fragment>
#include <gradientmap_pars_fragment>
#include <fog_pars_fragment>
#include <bsdfs>
#include <lights_pars_begin>
#include <normal_pars_fragment>
#include <lights_toon_pars_fragment>
#include <shadowmap_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	#include <clipping_planes_fragment>
	vec4 diffuseColor = vec4( diffuse, opacity );
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	vec3 totalEmissiveRadiance = emissive;
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	#include <emissivemap_fragment>
	#include <lights_toon_fragment>
	#include <lights_fragment_begin>
	#include <lights_fragment_maps>
	#include <lights_fragment_end>
	#include <aomap_fragment>
	vec3 outgoingLight = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse + totalEmissiveRadiance;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,Hm=`uniform float size;
uniform float scale;
#include <common>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <morphtarget_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
#ifdef USE_POINTS_UV
	varying vec2 vUv;
	uniform mat3 uvTransform;
#endif
void main() {
	#ifdef USE_POINTS_UV
		vUv = ( uvTransform * vec3( uv, 1 ) ).xy;
	#endif
	#include <color_vertex>
	#include <morphcolor_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <project_vertex>
	gl_PointSize = size;
	#ifdef USE_SIZEATTENUATION
		bool isPerspective = isPerspectiveMatrix( projectionMatrix );
		if ( isPerspective ) gl_PointSize *= ( scale / - mvPosition.z );
	#endif
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <worldpos_vertex>
	#include <fog_vertex>
}`,Vm=`uniform vec3 diffuse;
uniform float opacity;
#include <common>
#include <color_pars_fragment>
#include <map_particle_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <fog_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	#include <clipping_planes_fragment>
	vec3 outgoingLight = vec3( 0.0 );
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <logdepthbuf_fragment>
	#include <map_particle_fragment>
	#include <color_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	outgoingLight = diffuseColor.rgb;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
}`,Gm=`#include <common>
#include <batching_pars_vertex>
#include <fog_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <shadowmap_pars_vertex>
void main() {
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <worldpos_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
}`,Wm=`uniform vec3 color;
uniform float opacity;
#include <common>
#include <packing>
#include <fog_pars_fragment>
#include <bsdfs>
#include <lights_pars_begin>
#include <logdepthbuf_pars_fragment>
#include <shadowmap_pars_fragment>
#include <shadowmask_pars_fragment>
void main() {
	#include <logdepthbuf_fragment>
	gl_FragColor = vec4( color, opacity * ( 1.0 - getShadowMask() ) );
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
}`,Xm=`uniform float rotation;
uniform vec2 center;
#include <common>
#include <uv_pars_vertex>
#include <fog_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	vec4 mvPosition = modelViewMatrix * vec4( 0.0, 0.0, 0.0, 1.0 );
	vec2 scale;
	scale.x = length( vec3( modelMatrix[ 0 ].x, modelMatrix[ 0 ].y, modelMatrix[ 0 ].z ) );
	scale.y = length( vec3( modelMatrix[ 1 ].x, modelMatrix[ 1 ].y, modelMatrix[ 1 ].z ) );
	#ifndef USE_SIZEATTENUATION
		bool isPerspective = isPerspectiveMatrix( projectionMatrix );
		if ( isPerspective ) scale *= - mvPosition.z;
	#endif
	vec2 alignedPosition = ( position.xy - ( center - vec2( 0.5 ) ) ) * scale;
	vec2 rotatedPosition;
	rotatedPosition.x = cos( rotation ) * alignedPosition.x - sin( rotation ) * alignedPosition.y;
	rotatedPosition.y = sin( rotation ) * alignedPosition.x + cos( rotation ) * alignedPosition.y;
	mvPosition.xy += rotatedPosition;
	gl_Position = projectionMatrix * mvPosition;
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <fog_vertex>
}`,Ym=`uniform vec3 diffuse;
uniform float opacity;
#include <common>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <fog_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	#include <clipping_planes_fragment>
	vec3 outgoingLight = vec3( 0.0 );
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	outgoingLight = diffuseColor.rgb;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
}`,te={alphahash_fragment:pf,alphahash_pars_fragment:mf,alphamap_fragment:gf,alphamap_pars_fragment:xf,alphatest_fragment:_f,alphatest_pars_fragment:vf,aomap_fragment:yf,aomap_pars_fragment:bf,batching_pars_vertex:Mf,batching_vertex:Sf,begin_vertex:wf,beginnormal_vertex:Ef,bsdfs:Tf,iridescence_fragment:Af,bumpmap_pars_fragment:Cf,clipping_planes_fragment:Rf,clipping_planes_pars_fragment:Pf,clipping_planes_pars_vertex:Lf,clipping_planes_vertex:If,color_fragment:Df,color_pars_fragment:Uf,color_pars_vertex:Nf,color_vertex:Of,common:Ff,cube_uv_reflection_fragment:Bf,defaultnormal_vertex:zf,displacementmap_pars_vertex:kf,displacementmap_vertex:Hf,emissivemap_fragment:Vf,emissivemap_pars_fragment:Gf,colorspace_fragment:Wf,colorspace_pars_fragment:Xf,envmap_fragment:Yf,envmap_common_pars_fragment:qf,envmap_pars_fragment:Zf,envmap_pars_vertex:Jf,envmap_physical_pars_fragment:op,envmap_vertex:jf,fog_vertex:$f,fog_pars_vertex:Kf,fog_fragment:Qf,fog_pars_fragment:tp,gradientmap_pars_fragment:ep,lightmap_fragment:np,lightmap_pars_fragment:ip,lights_lambert_fragment:sp,lights_lambert_pars_fragment:rp,lights_pars_begin:ap,lights_toon_fragment:lp,lights_toon_pars_fragment:cp,lights_phong_fragment:hp,lights_phong_pars_fragment:up,lights_physical_fragment:dp,lights_physical_pars_fragment:fp,lights_fragment_begin:pp,lights_fragment_maps:mp,lights_fragment_end:gp,logdepthbuf_fragment:xp,logdepthbuf_pars_fragment:_p,logdepthbuf_pars_vertex:vp,logdepthbuf_vertex:yp,map_fragment:bp,map_pars_fragment:Mp,map_particle_fragment:Sp,map_particle_pars_fragment:wp,metalnessmap_fragment:Ep,metalnessmap_pars_fragment:Tp,morphcolor_vertex:Ap,morphnormal_vertex:Cp,morphtarget_pars_vertex:Rp,morphtarget_vertex:Pp,normal_fragment_begin:Lp,normal_fragment_maps:Ip,normal_pars_fragment:Dp,normal_pars_vertex:Up,normal_vertex:Np,normalmap_pars_fragment:Op,clearcoat_normal_fragment_begin:Fp,clearcoat_normal_fragment_maps:Bp,clearcoat_pars_fragment:zp,iridescence_pars_fragment:kp,opaque_fragment:Hp,packing:Vp,premultiplied_alpha_fragment:Gp,project_vertex:Wp,dithering_fragment:Xp,dithering_pars_fragment:Yp,roughnessmap_fragment:qp,roughnessmap_pars_fragment:Zp,shadowmap_pars_fragment:Jp,shadowmap_pars_vertex:jp,shadowmap_vertex:$p,shadowmask_pars_fragment:Kp,skinbase_vertex:Qp,skinning_pars_vertex:tm,skinning_vertex:em,skinnormal_vertex:nm,specularmap_fragment:im,specularmap_pars_fragment:sm,tonemapping_fragment:rm,tonemapping_pars_fragment:am,transmission_fragment:om,transmission_pars_fragment:lm,uv_pars_fragment:cm,uv_pars_vertex:hm,uv_vertex:um,worldpos_vertex:dm,background_vert:fm,background_frag:pm,backgroundCube_vert:mm,backgroundCube_frag:gm,cube_vert:xm,cube_frag:_m,depth_vert:vm,depth_frag:ym,distanceRGBA_vert:bm,distanceRGBA_frag:Mm,equirect_vert:Sm,equirect_frag:wm,linedashed_vert:Em,linedashed_frag:Tm,meshbasic_vert:Am,meshbasic_frag:Cm,meshlambert_vert:Rm,meshlambert_frag:Pm,meshmatcap_vert:Lm,meshmatcap_frag:Im,meshnormal_vert:Dm,meshnormal_frag:Um,meshphong_vert:Nm,meshphong_frag:Om,meshphysical_vert:Fm,meshphysical_frag:Bm,meshtoon_vert:zm,meshtoon_frag:km,points_vert:Hm,points_frag:Vm,shadow_vert:Gm,shadow_frag:Wm,sprite_vert:Xm,sprite_frag:Ym},Mt={common:{diffuse:{value:new Xt(16777215)},opacity:{value:1},map:{value:null},mapTransform:{value:new se},alphaMap:{value:null},alphaMapTransform:{value:new se},alphaTest:{value:0}},specularmap:{specularMap:{value:null},specularMapTransform:{value:new se}},envmap:{envMap:{value:null},flipEnvMap:{value:-1},reflectivity:{value:1},ior:{value:1.5},refractionRatio:{value:.98}},aomap:{aoMap:{value:null},aoMapIntensity:{value:1},aoMapTransform:{value:new se}},lightmap:{lightMap:{value:null},lightMapIntensity:{value:1},lightMapTransform:{value:new se}},bumpmap:{bumpMap:{value:null},bumpMapTransform:{value:new se},bumpScale:{value:1}},normalmap:{normalMap:{value:null},normalMapTransform:{value:new se},normalScale:{value:new At(1,1)}},displacementmap:{displacementMap:{value:null},displacementMapTransform:{value:new se},displacementScale:{value:1},displacementBias:{value:0}},emissivemap:{emissiveMap:{value:null},emissiveMapTransform:{value:new se}},metalnessmap:{metalnessMap:{value:null},metalnessMapTransform:{value:new se}},roughnessmap:{roughnessMap:{value:null},roughnessMapTransform:{value:new se}},gradientmap:{gradientMap:{value:null}},fog:{fogDensity:{value:25e-5},fogNear:{value:1},fogFar:{value:2e3},fogColor:{value:new Xt(16777215)}},lights:{ambientLightColor:{value:[]},lightProbe:{value:[]},directionalLights:{value:[],properties:{direction:{},color:{}}},directionalLightShadows:{value:[],properties:{shadowBias:{},shadowNormalBias:{},shadowRadius:{},shadowMapSize:{}}},directionalShadowMap:{value:[]},directionalShadowMatrix:{value:[]},spotLights:{value:[],properties:{color:{},position:{},direction:{},distance:{},coneCos:{},penumbraCos:{},decay:{}}},spotLightShadows:{value:[],properties:{shadowBias:{},shadowNormalBias:{},shadowRadius:{},shadowMapSize:{}}},spotLightMap:{value:[]},spotShadowMap:{value:[]},spotLightMatrix:{value:[]},pointLights:{value:[],properties:{color:{},position:{},decay:{},distance:{}}},pointLightShadows:{value:[],properties:{shadowBias:{},shadowNormalBias:{},shadowRadius:{},shadowMapSize:{},shadowCameraNear:{},shadowCameraFar:{}}},pointShadowMap:{value:[]},pointShadowMatrix:{value:[]},hemisphereLights:{value:[],properties:{direction:{},skyColor:{},groundColor:{}}},rectAreaLights:{value:[],properties:{color:{},position:{},width:{},height:{}}},ltc_1:{value:null},ltc_2:{value:null}},points:{diffuse:{value:new Xt(16777215)},opacity:{value:1},size:{value:1},scale:{value:1},map:{value:null},alphaMap:{value:null},alphaMapTransform:{value:new se},alphaTest:{value:0},uvTransform:{value:new se}},sprite:{diffuse:{value:new Xt(16777215)},opacity:{value:1},center:{value:new At(.5,.5)},rotation:{value:0},map:{value:null},mapTransform:{value:new se},alphaMap:{value:null},alphaMapTransform:{value:new se},alphaTest:{value:0}}},qn={basic:{uniforms:ln([Mt.common,Mt.specularmap,Mt.envmap,Mt.aomap,Mt.lightmap,Mt.fog]),vertexShader:te.meshbasic_vert,fragmentShader:te.meshbasic_frag},lambert:{uniforms:ln([Mt.common,Mt.specularmap,Mt.envmap,Mt.aomap,Mt.lightmap,Mt.emissivemap,Mt.bumpmap,Mt.normalmap,Mt.displacementmap,Mt.fog,Mt.lights,{emissive:{value:new Xt(0)}}]),vertexShader:te.meshlambert_vert,fragmentShader:te.meshlambert_frag},phong:{uniforms:ln([Mt.common,Mt.specularmap,Mt.envmap,Mt.aomap,Mt.lightmap,Mt.emissivemap,Mt.bumpmap,Mt.normalmap,Mt.displacementmap,Mt.fog,Mt.lights,{emissive:{value:new Xt(0)},specular:{value:new Xt(1118481)},shininess:{value:30}}]),vertexShader:te.meshphong_vert,fragmentShader:te.meshphong_frag},standard:{uniforms:ln([Mt.common,Mt.envmap,Mt.aomap,Mt.lightmap,Mt.emissivemap,Mt.bumpmap,Mt.normalmap,Mt.displacementmap,Mt.roughnessmap,Mt.metalnessmap,Mt.fog,Mt.lights,{emissive:{value:new Xt(0)},roughness:{value:1},metalness:{value:0},envMapIntensity:{value:1}}]),vertexShader:te.meshphysical_vert,fragmentShader:te.meshphysical_frag},toon:{uniforms:ln([Mt.common,Mt.aomap,Mt.lightmap,Mt.emissivemap,Mt.bumpmap,Mt.normalmap,Mt.displacementmap,Mt.gradientmap,Mt.fog,Mt.lights,{emissive:{value:new Xt(0)}}]),vertexShader:te.meshtoon_vert,fragmentShader:te.meshtoon_frag},matcap:{uniforms:ln([Mt.common,Mt.bumpmap,Mt.normalmap,Mt.displacementmap,Mt.fog,{matcap:{value:null}}]),vertexShader:te.meshmatcap_vert,fragmentShader:te.meshmatcap_frag},points:{uniforms:ln([Mt.points,Mt.fog]),vertexShader:te.points_vert,fragmentShader:te.points_frag},dashed:{uniforms:ln([Mt.common,Mt.fog,{scale:{value:1},dashSize:{value:1},totalSize:{value:2}}]),vertexShader:te.linedashed_vert,fragmentShader:te.linedashed_frag},depth:{uniforms:ln([Mt.common,Mt.displacementmap]),vertexShader:te.depth_vert,fragmentShader:te.depth_frag},normal:{uniforms:ln([Mt.common,Mt.bumpmap,Mt.normalmap,Mt.displacementmap,{opacity:{value:1}}]),vertexShader:te.meshnormal_vert,fragmentShader:te.meshnormal_frag},sprite:{uniforms:ln([Mt.sprite,Mt.fog]),vertexShader:te.sprite_vert,fragmentShader:te.sprite_frag},background:{uniforms:{uvTransform:{value:new se},t2D:{value:null},backgroundIntensity:{value:1}},vertexShader:te.background_vert,fragmentShader:te.background_frag},backgroundCube:{uniforms:{envMap:{value:null},flipEnvMap:{value:-1},backgroundBlurriness:{value:0},backgroundIntensity:{value:1}},vertexShader:te.backgroundCube_vert,fragmentShader:te.backgroundCube_frag},cube:{uniforms:{tCube:{value:null},tFlip:{value:-1},opacity:{value:1}},vertexShader:te.cube_vert,fragmentShader:te.cube_frag},equirect:{uniforms:{tEquirect:{value:null}},vertexShader:te.equirect_vert,fragmentShader:te.equirect_frag},distanceRGBA:{uniforms:ln([Mt.common,Mt.displacementmap,{referencePosition:{value:new B},nearDistance:{value:1},farDistance:{value:1e3}}]),vertexShader:te.distanceRGBA_vert,fragmentShader:te.distanceRGBA_frag},shadow:{uniforms:ln([Mt.lights,Mt.fog,{color:{value:new Xt(0)},opacity:{value:1}}]),vertexShader:te.shadow_vert,fragmentShader:te.shadow_frag}};qn.physical={uniforms:ln([qn.standard.uniforms,{clearcoat:{value:0},clearcoatMap:{value:null},clearcoatMapTransform:{value:new se},clearcoatNormalMap:{value:null},clearcoatNormalMapTransform:{value:new se},clearcoatNormalScale:{value:new At(1,1)},clearcoatRoughness:{value:0},clearcoatRoughnessMap:{value:null},clearcoatRoughnessMapTransform:{value:new se},iridescence:{value:0},iridescenceMap:{value:null},iridescenceMapTransform:{value:new se},iridescenceIOR:{value:1.3},iridescenceThicknessMinimum:{value:100},iridescenceThicknessMaximum:{value:400},iridescenceThicknessMap:{value:null},iridescenceThicknessMapTransform:{value:new se},sheen:{value:0},sheenColor:{value:new Xt(0)},sheenColorMap:{value:null},sheenColorMapTransform:{value:new se},sheenRoughness:{value:1},sheenRoughnessMap:{value:null},sheenRoughnessMapTransform:{value:new se},transmission:{value:0},transmissionMap:{value:null},transmissionMapTransform:{value:new se},transmissionSamplerSize:{value:new At},transmissionSamplerMap:{value:null},thickness:{value:0},thicknessMap:{value:null},thicknessMapTransform:{value:new se},attenuationDistance:{value:0},attenuationColor:{value:new Xt(0)},specularColor:{value:new Xt(1,1,1)},specularColorMap:{value:null},specularColorMapTransform:{value:new se},specularIntensity:{value:1},specularIntensityMap:{value:null},specularIntensityMapTransform:{value:new se},anisotropyVector:{value:new At},anisotropyMap:{value:null},anisotropyMapTransform:{value:new se}}]),vertexShader:te.meshphysical_vert,fragmentShader:te.meshphysical_frag};var na={r:0,b:0,g:0};function qm(i,t,e,n,s,r,o){let a=new Xt(0),l=r===!0?0:1,h,u,d=null,m=0,x=null;function v(g,f){let R=!1,E=f.isScene===!0?f.background:null;E&&E.isTexture&&(E=(f.backgroundBlurriness>0?e:t).get(E)),E===null?M(a,l):E&&E.isColor&&(M(E,1),R=!0);let L=i.xr.getEnvironmentBlendMode();L==="additive"?n.buffers.color.setClear(0,0,0,1,o):L==="alpha-blend"&&n.buffers.color.setClear(0,0,0,0,o),(i.autoClear||R)&&i.clear(i.autoClearColor,i.autoClearDepth,i.autoClearStencil),E&&(E.isCubeTexture||E.mapping===Ha)?(u===void 0&&(u=new Je(new Zi(1,1,1),new Be({name:"BackgroundCubeMaterial",uniforms:Fs(qn.backgroundCube.uniforms),vertexShader:qn.backgroundCube.vertexShader,fragmentShader:qn.backgroundCube.fragmentShader,side:pn,depthTest:!1,depthWrite:!1,fog:!1})),u.geometry.deleteAttribute("normal"),u.geometry.deleteAttribute("uv"),u.onBeforeRender=function(z,N,I){this.matrixWorld.copyPosition(I.matrixWorld)},Object.defineProperty(u.material,"envMap",{get:function(){return this.uniforms.envMap.value}}),s.update(u)),u.material.uniforms.envMap.value=E,u.material.uniforms.flipEnvMap.value=E.isCubeTexture&&E.isRenderTargetTexture===!1?-1:1,u.material.uniforms.backgroundBlurriness.value=f.backgroundBlurriness,u.material.uniforms.backgroundIntensity.value=f.backgroundIntensity,u.material.toneMapped=fe.getTransfer(E.colorSpace)!==me,(d!==E||m!==E.version||x!==i.toneMapping)&&(u.material.needsUpdate=!0,d=E,m=E.version,x=i.toneMapping),u.layers.enableAll(),g.unshift(u,u.geometry,u.material,0,0,null)):E&&E.isTexture&&(h===void 0&&(h=new Je(new vr(2,2),new Be({name:"BackgroundMaterial",uniforms:Fs(qn.background.uniforms),vertexShader:qn.background.vertexShader,fragmentShader:qn.background.fragmentShader,side:Ti,depthTest:!1,depthWrite:!1,fog:!1})),h.geometry.deleteAttribute("normal"),Object.defineProperty(h.material,"map",{get:function(){return this.uniforms.t2D.value}}),s.update(h)),h.material.uniforms.t2D.value=E,h.material.uniforms.backgroundIntensity.value=f.backgroundIntensity,h.material.toneMapped=fe.getTransfer(E.colorSpace)!==me,E.matrixAutoUpdate===!0&&E.updateMatrix(),h.material.uniforms.uvTransform.value.copy(E.matrix),(d!==E||m!==E.version||x!==i.toneMapping)&&(h.material.needsUpdate=!0,d=E,m=E.version,x=i.toneMapping),h.layers.enableAll(),g.unshift(h,h.geometry,h.material,0,0,null))}function M(g,f){g.getRGB(na,au(i)),n.buffers.color.setClear(na.r,na.g,na.b,f,o)}return{getClearColor:function(){return a},setClearColor:function(g,f=1){a.set(g),l=f,M(a,l)},getClearAlpha:function(){return l},setClearAlpha:function(g){l=g,M(a,l)},render:v}}function Zm(i,t,e,n){let s=i.getParameter(i.MAX_VERTEX_ATTRIBS),r=n.isWebGL2?null:t.get("OES_vertex_array_object"),o=n.isWebGL2||r!==null,a={},l=g(null),h=l,u=!1;function d(F,V,Z,k,$){let K=!1;if(o){let et=M(k,Z,V);h!==et&&(h=et,x(h.object)),K=f(F,k,Z,$),K&&R(F,k,Z,$)}else{let et=V.wireframe===!0;(h.geometry!==k.id||h.program!==Z.id||h.wireframe!==et)&&(h.geometry=k.id,h.program=Z.id,h.wireframe=et,K=!0)}$!==null&&e.update($,i.ELEMENT_ARRAY_BUFFER),(K||u)&&(u=!1,it(F,V,Z,k),$!==null&&i.bindBuffer(i.ELEMENT_ARRAY_BUFFER,e.get($).buffer))}function m(){return n.isWebGL2?i.createVertexArray():r.createVertexArrayOES()}function x(F){return n.isWebGL2?i.bindVertexArray(F):r.bindVertexArrayOES(F)}function v(F){return n.isWebGL2?i.deleteVertexArray(F):r.deleteVertexArrayOES(F)}function M(F,V,Z){let k=Z.wireframe===!0,$=a[F.id];$===void 0&&($={},a[F.id]=$);let K=$[V.id];K===void 0&&(K={},$[V.id]=K);let et=K[k];return et===void 0&&(et=g(m()),K[k]=et),et}function g(F){let V=[],Z=[],k=[];for(let $=0;$<s;$++)V[$]=0,Z[$]=0,k[$]=0;return{geometry:null,program:null,wireframe:!1,newAttributes:V,enabledAttributes:Z,attributeDivisors:k,object:F,attributes:{},index:null}}function f(F,V,Z,k){let $=h.attributes,K=V.attributes,et=0,rt=Z.getAttributes();for(let vt in rt)if(rt[vt].location>=0){let nt=$[vt],mt=K[vt];if(mt===void 0&&(vt==="instanceMatrix"&&F.instanceMatrix&&(mt=F.instanceMatrix),vt==="instanceColor"&&F.instanceColor&&(mt=F.instanceColor)),nt===void 0||nt.attribute!==mt||mt&&nt.data!==mt.data)return!0;et++}return h.attributesNum!==et||h.index!==k}function R(F,V,Z,k){let $={},K=V.attributes,et=0,rt=Z.getAttributes();for(let vt in rt)if(rt[vt].location>=0){let nt=K[vt];nt===void 0&&(vt==="instanceMatrix"&&F.instanceMatrix&&(nt=F.instanceMatrix),vt==="instanceColor"&&F.instanceColor&&(nt=F.instanceColor));let mt={};mt.attribute=nt,nt&&nt.data&&(mt.data=nt.data),$[vt]=mt,et++}h.attributes=$,h.attributesNum=et,h.index=k}function E(){let F=h.newAttributes;for(let V=0,Z=F.length;V<Z;V++)F[V]=0}function L(F){z(F,0)}function z(F,V){let Z=h.newAttributes,k=h.enabledAttributes,$=h.attributeDivisors;Z[F]=1,k[F]===0&&(i.enableVertexAttribArray(F),k[F]=1),$[F]!==V&&((n.isWebGL2?i:t.get("ANGLE_instanced_arrays"))[n.isWebGL2?"vertexAttribDivisor":"vertexAttribDivisorANGLE"](F,V),$[F]=V)}function N(){let F=h.newAttributes,V=h.enabledAttributes;for(let Z=0,k=V.length;Z<k;Z++)V[Z]!==F[Z]&&(i.disableVertexAttribArray(Z),V[Z]=0)}function I(F,V,Z,k,$,K,et){et===!0?i.vertexAttribIPointer(F,V,Z,$,K):i.vertexAttribPointer(F,V,Z,k,$,K)}function it(F,V,Z,k){if(n.isWebGL2===!1&&(F.isInstancedMesh||k.isInstancedBufferGeometry)&&t.get("ANGLE_instanced_arrays")===null)return;E();let $=k.attributes,K=Z.getAttributes(),et=V.defaultAttributeValues;for(let rt in K){let vt=K[rt];if(vt.location>=0){let G=$[rt];if(G===void 0&&(rt==="instanceMatrix"&&F.instanceMatrix&&(G=F.instanceMatrix),rt==="instanceColor"&&F.instanceColor&&(G=F.instanceColor)),G!==void 0){let nt=G.normalized,mt=G.itemSize,Tt=e.get(G);if(Tt===void 0)continue;let It=Tt.buffer,Wt=Tt.type,Ht=Tt.bytesPerElement,Bt=n.isWebGL2===!0&&(Wt===i.INT||Wt===i.UNSIGNED_INT||G.gpuType===qh);if(G.isInterleavedBufferAttribute){let ee=G.data,q=ee.stride,Pe=G.offset;if(ee.isInstancedInterleavedBuffer){for(let Ft=0;Ft<vt.locationSize;Ft++)z(vt.location+Ft,ee.meshPerAttribute);F.isInstancedMesh!==!0&&k._maxInstanceCount===void 0&&(k._maxInstanceCount=ee.meshPerAttribute*ee.count)}else for(let Ft=0;Ft<vt.locationSize;Ft++)L(vt.location+Ft);i.bindBuffer(i.ARRAY_BUFFER,It);for(let Ft=0;Ft<vt.locationSize;Ft++)I(vt.location+Ft,mt/vt.locationSize,Wt,nt,q*Ht,(Pe+mt/vt.locationSize*Ft)*Ht,Bt)}else{if(G.isInstancedBufferAttribute){for(let ee=0;ee<vt.locationSize;ee++)z(vt.location+ee,G.meshPerAttribute);F.isInstancedMesh!==!0&&k._maxInstanceCount===void 0&&(k._maxInstanceCount=G.meshPerAttribute*G.count)}else for(let ee=0;ee<vt.locationSize;ee++)L(vt.location+ee);i.bindBuffer(i.ARRAY_BUFFER,It);for(let ee=0;ee<vt.locationSize;ee++)I(vt.location+ee,mt/vt.locationSize,Wt,nt,mt*Ht,mt/vt.locationSize*ee*Ht,Bt)}}else if(et!==void 0){let nt=et[rt];if(nt!==void 0)switch(nt.length){case 2:i.vertexAttrib2fv(vt.location,nt);break;case 3:i.vertexAttrib3fv(vt.location,nt);break;case 4:i.vertexAttrib4fv(vt.location,nt);break;default:i.vertexAttrib1fv(vt.location,nt)}}}}N()}function w(){tt();for(let F in a){let V=a[F];for(let Z in V){let k=V[Z];for(let $ in k)v(k[$].object),delete k[$];delete V[Z]}delete a[F]}}function A(F){if(a[F.id]===void 0)return;let V=a[F.id];for(let Z in V){let k=V[Z];for(let $ in k)v(k[$].object),delete k[$];delete V[Z]}delete a[F.id]}function X(F){for(let V in a){let Z=a[V];if(Z[F.id]===void 0)continue;let k=Z[F.id];for(let $ in k)v(k[$].object),delete k[$];delete Z[F.id]}}function tt(){at(),u=!0,h!==l&&(h=l,x(h.object))}function at(){l.geometry=null,l.program=null,l.wireframe=!1}return{setup:d,reset:tt,resetDefaultState:at,dispose:w,releaseStatesOfGeometry:A,releaseStatesOfProgram:X,initAttributes:E,enableAttribute:L,disableUnusedAttributes:N}}function Jm(i,t,e,n){let s=n.isWebGL2,r;function o(u){r=u}function a(u,d){i.drawArrays(r,u,d),e.update(d,r,1)}function l(u,d,m){if(m===0)return;let x,v;if(s)x=i,v="drawArraysInstanced";else if(x=t.get("ANGLE_instanced_arrays"),v="drawArraysInstancedANGLE",x===null){console.error("THREE.WebGLBufferRenderer: using THREE.InstancedBufferGeometry but hardware does not support extension ANGLE_instanced_arrays.");return}x[v](r,u,d,m),e.update(d,r,m)}function h(u,d,m){if(m===0)return;let x=t.get("WEBGL_multi_draw");if(x===null)for(let v=0;v<m;v++)this.render(u[v],d[v]);else{x.multiDrawArraysWEBGL(r,u,0,d,0,m);let v=0;for(let M=0;M<m;M++)v+=d[M];e.update(v,r,1)}}this.setMode=o,this.render=a,this.renderInstances=l,this.renderMultiDraw=h}function jm(i,t,e){let n;function s(){if(n!==void 0)return n;if(t.has("EXT_texture_filter_anisotropic")===!0){let I=t.get("EXT_texture_filter_anisotropic");n=i.getParameter(I.MAX_TEXTURE_MAX_ANISOTROPY_EXT)}else n=0;return n}function r(I){if(I==="highp"){if(i.getShaderPrecisionFormat(i.VERTEX_SHADER,i.HIGH_FLOAT).precision>0&&i.getShaderPrecisionFormat(i.FRAGMENT_SHADER,i.HIGH_FLOAT).precision>0)return"highp";I="mediump"}return I==="mediump"&&i.getShaderPrecisionFormat(i.VERTEX_SHADER,i.MEDIUM_FLOAT).precision>0&&i.getShaderPrecisionFormat(i.FRAGMENT_SHADER,i.MEDIUM_FLOAT).precision>0?"mediump":"lowp"}let o=typeof WebGL2RenderingContext<"u"&&i.constructor.name==="WebGL2RenderingContext",a=e.precision!==void 0?e.precision:"highp",l=r(a);l!==a&&(console.warn("THREE.WebGLRenderer:",a,"not supported, using",l,"instead."),a=l);let h=o||t.has("WEBGL_draw_buffers"),u=e.logarithmicDepthBuffer===!0,d=i.getParameter(i.MAX_TEXTURE_IMAGE_UNITS),m=i.getParameter(i.MAX_VERTEX_TEXTURE_IMAGE_UNITS),x=i.getParameter(i.MAX_TEXTURE_SIZE),v=i.getParameter(i.MAX_CUBE_MAP_TEXTURE_SIZE),M=i.getParameter(i.MAX_VERTEX_ATTRIBS),g=i.getParameter(i.MAX_VERTEX_UNIFORM_VECTORS),f=i.getParameter(i.MAX_VARYING_VECTORS),R=i.getParameter(i.MAX_FRAGMENT_UNIFORM_VECTORS),E=m>0,L=o||t.has("OES_texture_float"),z=E&&L,N=o?i.getParameter(i.MAX_SAMPLES):0;return{isWebGL2:o,drawBuffers:h,getMaxAnisotropy:s,getMaxPrecision:r,precision:a,logarithmicDepthBuffer:u,maxTextures:d,maxVertexTextures:m,maxTextureSize:x,maxCubemapSize:v,maxAttributes:M,maxVertexUniforms:g,maxVaryings:f,maxFragmentUniforms:R,vertexTextures:E,floatFragmentTextures:L,floatVertexTextures:z,maxSamples:N}}function $m(i){let t=this,e=null,n=0,s=!1,r=!1,o=new Dn,a=new se,l={value:null,needsUpdate:!1};this.uniform=l,this.numPlanes=0,this.numIntersection=0,this.init=function(d,m){let x=d.length!==0||m||n!==0||s;return s=m,n=d.length,x},this.beginShadows=function(){r=!0,u(null)},this.endShadows=function(){r=!1},this.setGlobalState=function(d,m){e=u(d,m,0)},this.setState=function(d,m,x){let v=d.clippingPlanes,M=d.clipIntersection,g=d.clipShadows,f=i.get(d);if(!s||v===null||v.length===0||r&&!g)r?u(null):h();else{let R=r?0:n,E=R*4,L=f.clippingState||null;l.value=L,L=u(v,m,E,x);for(let z=0;z!==E;++z)L[z]=e[z];f.clippingState=L,this.numIntersection=M?this.numPlanes:0,this.numPlanes+=R}};function h(){l.value!==e&&(l.value=e,l.needsUpdate=n>0),t.numPlanes=n,t.numIntersection=0}function u(d,m,x,v){let M=d!==null?d.length:0,g=null;if(M!==0){if(g=l.value,v!==!0||g===null){let f=x+M*4,R=m.matrixWorldInverse;a.getNormalMatrix(R),(g===null||g.length<f)&&(g=new Float32Array(f));for(let E=0,L=x;E!==M;++E,L+=4)o.copy(d[E]).applyMatrix4(R,a),o.normal.toArray(g,L),g[L+3]=o.constant}l.value=g,l.needsUpdate=!0}return t.numPlanes=M,t.numIntersection=0,g}}function Km(i){let t=new WeakMap;function e(o,a){return a===Zo?o.mapping=Us:a===Jo&&(o.mapping=Ns),o}function n(o){if(o&&o.isTexture){let a=o.mapping;if(a===Zo||a===Jo)if(t.has(o)){let l=t.get(o).texture;return e(l,o.mapping)}else{let l=o.image;if(l&&l.height>0){let h=new nl(l.height/2);return h.fromEquirectangularTexture(i,o),t.set(o,h),o.addEventListener("dispose",s),e(h.texture,o.mapping)}else return null}}return o}function s(o){let a=o.target;a.removeEventListener("dispose",s);let l=t.get(a);l!==void 0&&(t.delete(a),l.dispose())}function r(){t=new WeakMap}return{get:n,dispose:r}}var Bs=class extends Sa{constructor(t=-1,e=1,n=1,s=-1,r=.1,o=2e3){super(),this.isOrthographicCamera=!0,this.type="OrthographicCamera",this.zoom=1,this.view=null,this.left=t,this.right=e,this.top=n,this.bottom=s,this.near=r,this.far=o,this.updateProjectionMatrix()}copy(t,e){return super.copy(t,e),this.left=t.left,this.right=t.right,this.top=t.top,this.bottom=t.bottom,this.near=t.near,this.far=t.far,this.zoom=t.zoom,this.view=t.view===null?null:Object.assign({},t.view),this}setViewOffset(t,e,n,s,r,o){this.view===null&&(this.view={enabled:!0,fullWidth:1,fullHeight:1,offsetX:0,offsetY:0,width:1,height:1}),this.view.enabled=!0,this.view.fullWidth=t,this.view.fullHeight=e,this.view.offsetX=n,this.view.offsetY=s,this.view.width=r,this.view.height=o,this.updateProjectionMatrix()}clearViewOffset(){this.view!==null&&(this.view.enabled=!1),this.updateProjectionMatrix()}updateProjectionMatrix(){let t=(this.right-this.left)/(2*this.zoom),e=(this.top-this.bottom)/(2*this.zoom),n=(this.right+this.left)/2,s=(this.top+this.bottom)/2,r=n-t,o=n+t,a=s+e,l=s-e;if(this.view!==null&&this.view.enabled){let h=(this.right-this.left)/this.view.fullWidth/this.zoom,u=(this.top-this.bottom)/this.view.fullHeight/this.zoom;r+=h*this.view.offsetX,o=r+h*this.view.width,a-=u*this.view.offsetY,l=a-u*this.view.height}this.projectionMatrix.makeOrthographic(r,o,a,l,this.near,this.far,this.coordinateSystem),this.projectionMatrixInverse.copy(this.projectionMatrix).invert()}toJSON(t){let e=super.toJSON(t);return e.object.zoom=this.zoom,e.object.left=this.left,e.object.right=this.right,e.object.top=this.top,e.object.bottom=this.bottom,e.object.near=this.near,e.object.far=this.far,this.view!==null&&(e.object.view=Object.assign({},this.view)),e}},Rs=4,ph=[.125,.215,.35,.446,.526,.582],Vi=20,ko=new Bs,mh=new Xt,Ho=null,Vo=0,Go=0,Hi=(1+Math.sqrt(5))/2,Es=1/Hi,gh=[new B(1,1,1),new B(-1,1,1),new B(1,1,-1),new B(-1,1,-1),new B(0,Hi,Es),new B(0,Hi,-Es),new B(Es,0,Hi),new B(-Es,0,Hi),new B(Hi,Es,0),new B(-Hi,Es,0)],Ea=class{constructor(t){this._renderer=t,this._pingPongRenderTarget=null,this._lodMax=0,this._cubeSize=0,this._lodPlanes=[],this._sizeLods=[],this._sigmas=[],this._blurMaterial=null,this._cubemapMaterial=null,this._equirectMaterial=null,this._compileMaterial(this._blurMaterial)}fromScene(t,e=0,n=.1,s=100){Ho=this._renderer.getRenderTarget(),Vo=this._renderer.getActiveCubeFace(),Go=this._renderer.getActiveMipmapLevel(),this._setSize(256);let r=this._allocateTargets();return r.depthBuffer=!0,this._sceneToCubeUV(t,n,s,r),e>0&&this._blur(r,0,0,e),this._applyPMREM(r),this._cleanup(r),r}fromEquirectangular(t,e=null){return this._fromTexture(t,e)}fromCubemap(t,e=null){return this._fromTexture(t,e)}compileCubemapShader(){this._cubemapMaterial===null&&(this._cubemapMaterial=vh(),this._compileMaterial(this._cubemapMaterial))}compileEquirectangularShader(){this._equirectMaterial===null&&(this._equirectMaterial=_h(),this._compileMaterial(this._equirectMaterial))}dispose(){this._dispose(),this._cubemapMaterial!==null&&this._cubemapMaterial.dispose(),this._equirectMaterial!==null&&this._equirectMaterial.dispose()}_setSize(t){this._lodMax=Math.floor(Math.log2(t)),this._cubeSize=Math.pow(2,this._lodMax)}_dispose(){this._blurMaterial!==null&&this._blurMaterial.dispose(),this._pingPongRenderTarget!==null&&this._pingPongRenderTarget.dispose();for(let t=0;t<this._lodPlanes.length;t++)this._lodPlanes[t].dispose()}_cleanup(t){this._renderer.setRenderTarget(Ho,Vo,Go),t.scissorTest=!1,ia(t,0,0,t.width,t.height)}_fromTexture(t,e){t.mapping===Us||t.mapping===Ns?this._setSize(t.image.length===0?16:t.image[0].width||t.image[0].image.width):this._setSize(t.image.width/4),Ho=this._renderer.getRenderTarget(),Vo=this._renderer.getActiveCubeFace(),Go=this._renderer.getActiveMipmapLevel();let n=e||this._allocateTargets();return this._textureToCubeUV(t,n),this._applyPMREM(n),this._cleanup(n),n}_allocateTargets(){let t=3*Math.max(this._cubeSize,112),e=4*this._cubeSize,n={magFilter:Mn,minFilter:Mn,generateMipmaps:!1,type:xn,format:On,colorSpace:li,depthBuffer:!1},s=xh(t,e,n);if(this._pingPongRenderTarget===null||this._pingPongRenderTarget.width!==t||this._pingPongRenderTarget.height!==e){this._pingPongRenderTarget!==null&&this._dispose(),this._pingPongRenderTarget=xh(t,e,n);let{_lodMax:r}=this;({sizeLods:this._sizeLods,lodPlanes:this._lodPlanes,sigmas:this._sigmas}=Qm(r)),this._blurMaterial=tg(r,t,e)}return s}_compileMaterial(t){let e=new Je(this._lodPlanes[0],t);this._renderer.compile(e,ko)}_sceneToCubeUV(t,e,n,s){let a=new en(90,1,e,n),l=[1,-1,1,1,1,1],h=[1,1,1,-1,-1,-1],u=this._renderer,d=u.autoClear,m=u.toneMapping;u.getClearColor(mh),u.toneMapping=wi,u.autoClear=!1;let x=new wn({name:"PMREM.Background",side:pn,depthWrite:!1,depthTest:!1}),v=new Je(new Zi,x),M=!1,g=t.background;g?g.isColor&&(x.color.copy(g),t.background=null,M=!0):(x.color.copy(mh),M=!0);for(let f=0;f<6;f++){let R=f%3;R===0?(a.up.set(0,l[f],0),a.lookAt(h[f],0,0)):R===1?(a.up.set(0,0,l[f]),a.lookAt(0,h[f],0)):(a.up.set(0,l[f],0),a.lookAt(0,0,h[f]));let E=this._cubeSize;ia(s,R*E,f>2?E:0,E,E),u.setRenderTarget(s),M&&u.render(v,a),u.render(t,a)}v.geometry.dispose(),v.material.dispose(),u.toneMapping=m,u.autoClear=d,t.background=g}_textureToCubeUV(t,e){let n=this._renderer,s=t.mapping===Us||t.mapping===Ns;s?(this._cubemapMaterial===null&&(this._cubemapMaterial=vh()),this._cubemapMaterial.uniforms.flipEnvMap.value=t.isRenderTargetTexture===!1?-1:1):this._equirectMaterial===null&&(this._equirectMaterial=_h());let r=s?this._cubemapMaterial:this._equirectMaterial,o=new Je(this._lodPlanes[0],r),a=r.uniforms;a.envMap.value=t;let l=this._cubeSize;ia(e,0,0,3*l,2*l),n.setRenderTarget(e),n.render(o,ko)}_applyPMREM(t){let e=this._renderer,n=e.autoClear;e.autoClear=!1;for(let s=1;s<this._lodPlanes.length;s++){let r=Math.sqrt(this._sigmas[s]*this._sigmas[s]-this._sigmas[s-1]*this._sigmas[s-1]),o=gh[(s-1)%gh.length];this._blur(t,s-1,s,r,o)}e.autoClear=n}_blur(t,e,n,s,r){let o=this._pingPongRenderTarget;this._halfBlur(t,o,e,n,s,"latitudinal",r),this._halfBlur(o,t,n,n,s,"longitudinal",r)}_halfBlur(t,e,n,s,r,o,a){let l=this._renderer,h=this._blurMaterial;o!=="latitudinal"&&o!=="longitudinal"&&console.error("blur direction must be either latitudinal or longitudinal!");let u=3,d=new Je(this._lodPlanes[s],h),m=h.uniforms,x=this._sizeLods[n]-1,v=isFinite(r)?Math.PI/(2*x):2*Math.PI/(2*Vi-1),M=r/v,g=isFinite(r)?1+Math.floor(u*M):Vi;g>Vi&&console.warn(`sigmaRadians, ${r}, is too large and will clip, as it requested ${g} samples when the maximum is set to ${Vi}`);let f=[],R=0;for(let I=0;I<Vi;++I){let it=I/M,w=Math.exp(-it*it/2);f.push(w),I===0?R+=w:I<g&&(R+=2*w)}for(let I=0;I<f.length;I++)f[I]=f[I]/R;m.envMap.value=t.texture,m.samples.value=g,m.weights.value=f,m.latitudinal.value=o==="latitudinal",a&&(m.poleAxis.value=a);let{_lodMax:E}=this;m.dTheta.value=v,m.mipInt.value=E-n;let L=this._sizeLods[s],z=3*L*(s>E-Rs?s-E+Rs:0),N=4*(this._cubeSize-L);ia(e,z,N,3*L,2*L),l.setRenderTarget(e),l.render(d,ko)}};function Qm(i){let t=[],e=[],n=[],s=i,r=i-Rs+1+ph.length;for(let o=0;o<r;o++){let a=Math.pow(2,s);e.push(a);let l=1/a;o>i-Rs?l=ph[o-i+Rs-1]:o===0&&(l=0),n.push(l);let h=1/(a-2),u=-h,d=1+h,m=[u,u,d,u,d,d,u,u,d,d,u,d],x=6,v=6,M=3,g=2,f=1,R=new Float32Array(M*v*x),E=new Float32Array(g*v*x),L=new Float32Array(f*v*x);for(let N=0;N<x;N++){let I=N%3*2/3-1,it=N>2?0:-1,w=[I,it,0,I+2/3,it,0,I+2/3,it+1,0,I,it,0,I+2/3,it+1,0,I,it+1,0];R.set(w,M*v*N),E.set(m,g*v*N);let A=[N,N,N,N,N,N];L.set(A,f*v*N)}let z=new _n;z.setAttribute("position",new cn(R,M)),z.setAttribute("uv",new cn(E,g)),z.setAttribute("faceIndex",new cn(L,f)),t.push(z),s>Rs&&s--}return{lodPlanes:t,sizeLods:e,sigmas:n}}function xh(i,t,e){let n=new je(i,t,e);return n.texture.mapping=Ha,n.texture.name="PMREM.cubeUv",n.scissorTest=!0,n}function ia(i,t,e,n,s){i.viewport.set(t,e,n,s),i.scissor.set(t,e,n,s)}function tg(i,t,e){let n=new Float32Array(Vi),s=new B(0,1,0);return new Be({name:"SphericalGaussianBlur",defines:{n:Vi,CUBEUV_TEXEL_WIDTH:1/t,CUBEUV_TEXEL_HEIGHT:1/e,CUBEUV_MAX_MIP:`${i}.0`},uniforms:{envMap:{value:null},samples:{value:1},weights:{value:n},latitudinal:{value:!1},dTheta:{value:0},mipInt:{value:0},poleAxis:{value:s}},vertexShader:Bl(),fragmentShader:`

			precision mediump float;
			precision mediump int;

			varying vec3 vOutputDirection;

			uniform sampler2D envMap;
			uniform int samples;
			uniform float weights[ n ];
			uniform bool latitudinal;
			uniform float dTheta;
			uniform float mipInt;
			uniform vec3 poleAxis;

			#define ENVMAP_TYPE_CUBE_UV
			#include <cube_uv_reflection_fragment>

			vec3 getSample( float theta, vec3 axis ) {

				float cosTheta = cos( theta );
				// Rodrigues' axis-angle rotation
				vec3 sampleDirection = vOutputDirection * cosTheta
					+ cross( axis, vOutputDirection ) * sin( theta )
					+ axis * dot( axis, vOutputDirection ) * ( 1.0 - cosTheta );

				return bilinearCubeUV( envMap, sampleDirection, mipInt );

			}

			void main() {

				vec3 axis = latitudinal ? poleAxis : cross( poleAxis, vOutputDirection );

				if ( all( equal( axis, vec3( 0.0 ) ) ) ) {

					axis = vec3( vOutputDirection.z, 0.0, - vOutputDirection.x );

				}

				axis = normalize( axis );

				gl_FragColor = vec4( 0.0, 0.0, 0.0, 1.0 );
				gl_FragColor.rgb += weights[ 0 ] * getSample( 0.0, axis );

				for ( int i = 1; i < n; i++ ) {

					if ( i >= samples ) {

						break;

					}

					float theta = dTheta * float( i );
					gl_FragColor.rgb += weights[ i ] * getSample( -1.0 * theta, axis );
					gl_FragColor.rgb += weights[ i ] * getSample( theta, axis );

				}

			}
		`,blending:Zn,depthTest:!1,depthWrite:!1})}function _h(){return new Be({name:"EquirectangularToCubeUV",uniforms:{envMap:{value:null}},vertexShader:Bl(),fragmentShader:`

			precision mediump float;
			precision mediump int;

			varying vec3 vOutputDirection;

			uniform sampler2D envMap;

			#include <common>

			void main() {

				vec3 outputDirection = normalize( vOutputDirection );
				vec2 uv = equirectUv( outputDirection );

				gl_FragColor = vec4( texture2D ( envMap, uv ).rgb, 1.0 );

			}
		`,blending:Zn,depthTest:!1,depthWrite:!1})}function vh(){return new Be({name:"CubemapToCubeUV",uniforms:{envMap:{value:null},flipEnvMap:{value:-1}},vertexShader:Bl(),fragmentShader:`

			precision mediump float;
			precision mediump int;

			uniform float flipEnvMap;

			varying vec3 vOutputDirection;

			uniform samplerCube envMap;

			void main() {

				gl_FragColor = textureCube( envMap, vec3( flipEnvMap * vOutputDirection.x, vOutputDirection.yz ) );

			}
		`,blending:Zn,depthTest:!1,depthWrite:!1})}function Bl(){return`

		precision mediump float;
		precision mediump int;

		attribute float faceIndex;

		varying vec3 vOutputDirection;

		// RH coordinate system; PMREM face-indexing convention
		vec3 getDirection( vec2 uv, float face ) {

			uv = 2.0 * uv - 1.0;

			vec3 direction = vec3( uv, 1.0 );

			if ( face == 0.0 ) {

				direction = direction.zyx; // ( 1, v, u ) pos x

			} else if ( face == 1.0 ) {

				direction = direction.xzy;
				direction.xz *= -1.0; // ( -u, 1, -v ) pos y

			} else if ( face == 2.0 ) {

				direction.x *= -1.0; // ( -u, v, 1 ) pos z

			} else if ( face == 3.0 ) {

				direction = direction.zyx;
				direction.xz *= -1.0; // ( -1, v, -u ) neg x

			} else if ( face == 4.0 ) {

				direction = direction.xzy;
				direction.xy *= -1.0; // ( -u, -1, v ) neg y

			} else if ( face == 5.0 ) {

				direction.z *= -1.0; // ( u, v, -1 ) neg z

			}

			return direction;

		}

		void main() {

			vOutputDirection = getDirection( uv, faceIndex );
			gl_Position = vec4( position, 1.0 );

		}
	`}function eg(i){let t=new WeakMap,e=null;function n(a){if(a&&a.isTexture){let l=a.mapping,h=l===Zo||l===Jo,u=l===Us||l===Ns;if(h||u)if(a.isRenderTargetTexture&&a.needsPMREMUpdate===!0){a.needsPMREMUpdate=!1;let d=t.get(a);return e===null&&(e=new Ea(i)),d=h?e.fromEquirectangular(a,d):e.fromCubemap(a,d),t.set(a,d),d.texture}else{if(t.has(a))return t.get(a).texture;{let d=a.image;if(h&&d&&d.height>0||u&&d&&s(d)){e===null&&(e=new Ea(i));let m=h?e.fromEquirectangular(a):e.fromCubemap(a);return t.set(a,m),a.addEventListener("dispose",r),m.texture}else return null}}}return a}function s(a){let l=0,h=6;for(let u=0;u<h;u++)a[u]!==void 0&&l++;return l===h}function r(a){let l=a.target;l.removeEventListener("dispose",r);let h=t.get(l);h!==void 0&&(t.delete(l),h.dispose())}function o(){t=new WeakMap,e!==null&&(e.dispose(),e=null)}return{get:n,dispose:o}}function ng(i){let t={};function e(n){if(t[n]!==void 0)return t[n];let s;switch(n){case"WEBGL_depth_texture":s=i.getExtension("WEBGL_depth_texture")||i.getExtension("MOZ_WEBGL_depth_texture")||i.getExtension("WEBKIT_WEBGL_depth_texture");break;case"EXT_texture_filter_anisotropic":s=i.getExtension("EXT_texture_filter_anisotropic")||i.getExtension("MOZ_EXT_texture_filter_anisotropic")||i.getExtension("WEBKIT_EXT_texture_filter_anisotropic");break;case"WEBGL_compressed_texture_s3tc":s=i.getExtension("WEBGL_compressed_texture_s3tc")||i.getExtension("MOZ_WEBGL_compressed_texture_s3tc")||i.getExtension("WEBKIT_WEBGL_compressed_texture_s3tc");break;case"WEBGL_compressed_texture_pvrtc":s=i.getExtension("WEBGL_compressed_texture_pvrtc")||i.getExtension("WEBKIT_WEBGL_compressed_texture_pvrtc");break;default:s=i.getExtension(n)}return t[n]=s,s}return{has:function(n){return e(n)!==null},init:function(n){n.isWebGL2?(e("EXT_color_buffer_float"),e("WEBGL_clip_cull_distance")):(e("WEBGL_depth_texture"),e("OES_texture_float"),e("OES_texture_half_float"),e("OES_texture_half_float_linear"),e("OES_standard_derivatives"),e("OES_element_index_uint"),e("OES_vertex_array_object"),e("ANGLE_instanced_arrays")),e("OES_texture_float_linear"),e("EXT_color_buffer_half_float"),e("WEBGL_multisampled_render_to_texture")},get:function(n){let s=e(n);return s===null&&console.warn("THREE.WebGLRenderer: "+n+" extension not supported."),s}}}function ig(i,t,e,n){let s={},r=new WeakMap;function o(d){let m=d.target;m.index!==null&&t.remove(m.index);for(let v in m.attributes)t.remove(m.attributes[v]);for(let v in m.morphAttributes){let M=m.morphAttributes[v];for(let g=0,f=M.length;g<f;g++)t.remove(M[g])}m.removeEventListener("dispose",o),delete s[m.id];let x=r.get(m);x&&(t.remove(x),r.delete(m)),n.releaseStatesOfGeometry(m),m.isInstancedBufferGeometry===!0&&delete m._maxInstanceCount,e.memory.geometries--}function a(d,m){return s[m.id]===!0||(m.addEventListener("dispose",o),s[m.id]=!0,e.memory.geometries++),m}function l(d){let m=d.attributes;for(let v in m)t.update(m[v],i.ARRAY_BUFFER);let x=d.morphAttributes;for(let v in x){let M=x[v];for(let g=0,f=M.length;g<f;g++)t.update(M[g],i.ARRAY_BUFFER)}}function h(d){let m=[],x=d.index,v=d.attributes.position,M=0;if(x!==null){let R=x.array;M=x.version;for(let E=0,L=R.length;E<L;E+=3){let z=R[E+0],N=R[E+1],I=R[E+2];m.push(z,N,N,I,I,z)}}else if(v!==void 0){let R=v.array;M=v.version;for(let E=0,L=R.length/3-1;E<L;E+=3){let z=E+0,N=E+1,I=E+2;m.push(z,N,N,I,I,z)}}else return;let g=new(su(m)?Ma:ba)(m,1);g.version=M;let f=r.get(d);f&&t.remove(f),r.set(d,g)}function u(d){let m=r.get(d);if(m){let x=d.index;x!==null&&m.version<x.version&&h(d)}else h(d);return r.get(d)}return{get:a,update:l,getWireframeAttribute:u}}function sg(i,t,e,n){let s=n.isWebGL2,r;function o(x){r=x}let a,l;function h(x){a=x.type,l=x.bytesPerElement}function u(x,v){i.drawElements(r,v,a,x*l),e.update(v,r,1)}function d(x,v,M){if(M===0)return;let g,f;if(s)g=i,f="drawElementsInstanced";else if(g=t.get("ANGLE_instanced_arrays"),f="drawElementsInstancedANGLE",g===null){console.error("THREE.WebGLIndexedBufferRenderer: using THREE.InstancedBufferGeometry but hardware does not support extension ANGLE_instanced_arrays.");return}g[f](r,v,a,x*l,M),e.update(v,r,M)}function m(x,v,M){if(M===0)return;let g=t.get("WEBGL_multi_draw");if(g===null)for(let f=0;f<M;f++)this.render(x[f]/l,v[f]);else{g.multiDrawElementsWEBGL(r,v,0,a,x,0,M);let f=0;for(let R=0;R<M;R++)f+=v[R];e.update(f,r,1)}}this.setMode=o,this.setIndex=h,this.render=u,this.renderInstances=d,this.renderMultiDraw=m}function rg(i){let t={geometries:0,textures:0},e={frame:0,calls:0,triangles:0,points:0,lines:0};function n(r,o,a){switch(e.calls++,o){case i.TRIANGLES:e.triangles+=a*(r/3);break;case i.LINES:e.lines+=a*(r/2);break;case i.LINE_STRIP:e.lines+=a*(r-1);break;case i.LINE_LOOP:e.lines+=a*r;break;case i.POINTS:e.points+=a*r;break;default:console.error("THREE.WebGLInfo: Unknown draw mode:",o);break}}function s(){e.calls=0,e.triangles=0,e.points=0,e.lines=0}return{memory:t,render:e,programs:null,autoReset:!0,reset:s,update:n}}function ag(i,t){return i[0]-t[0]}function og(i,t){return Math.abs(t[1])-Math.abs(i[1])}function lg(i,t,e){let n={},s=new Float32Array(8),r=new WeakMap,o=new Se,a=[];for(let h=0;h<8;h++)a[h]=[h,0];function l(h,u,d){let m=h.morphTargetInfluences;if(t.isWebGL2===!0){let x=u.morphAttributes.position||u.morphAttributes.normal||u.morphAttributes.color,v=x!==void 0?x.length:0,M=r.get(u);if(M===void 0||M.count!==v){let F=function(){tt.dispose(),r.delete(u),u.removeEventListener("dispose",F)};M!==void 0&&M.texture.dispose();let R=u.morphAttributes.position!==void 0,E=u.morphAttributes.normal!==void 0,L=u.morphAttributes.color!==void 0,z=u.morphAttributes.position||[],N=u.morphAttributes.normal||[],I=u.morphAttributes.color||[],it=0;R===!0&&(it=1),E===!0&&(it=2),L===!0&&(it=3);let w=u.attributes.position.count*it,A=1;w>t.maxTextureSize&&(A=Math.ceil(w/t.maxTextureSize),w=t.maxTextureSize);let X=new Float32Array(w*A*4*v),tt=new va(X,w,A,v);tt.type=Mi,tt.needsUpdate=!0;let at=it*4;for(let V=0;V<v;V++){let Z=z[V],k=N[V],$=I[V],K=w*A*4*V;for(let et=0;et<Z.count;et++){let rt=et*at;R===!0&&(o.fromBufferAttribute(Z,et),X[K+rt+0]=o.x,X[K+rt+1]=o.y,X[K+rt+2]=o.z,X[K+rt+3]=0),E===!0&&(o.fromBufferAttribute(k,et),X[K+rt+4]=o.x,X[K+rt+5]=o.y,X[K+rt+6]=o.z,X[K+rt+7]=0),L===!0&&(o.fromBufferAttribute($,et),X[K+rt+8]=o.x,X[K+rt+9]=o.y,X[K+rt+10]=o.z,X[K+rt+11]=$.itemSize===4?o.w:1)}}M={count:v,texture:tt,size:new At(w,A)},r.set(u,M),u.addEventListener("dispose",F)}let g=0;for(let R=0;R<m.length;R++)g+=m[R];let f=u.morphTargetsRelative?1:1-g;d.getUniforms().setValue(i,"morphTargetBaseInfluence",f),d.getUniforms().setValue(i,"morphTargetInfluences",m),d.getUniforms().setValue(i,"morphTargetsTexture",M.texture,e),d.getUniforms().setValue(i,"morphTargetsTextureSize",M.size)}else{let x=m===void 0?0:m.length,v=n[u.id];if(v===void 0||v.length!==x){v=[];for(let E=0;E<x;E++)v[E]=[E,0];n[u.id]=v}for(let E=0;E<x;E++){let L=v[E];L[0]=E,L[1]=m[E]}v.sort(og);for(let E=0;E<8;E++)E<x&&v[E][1]?(a[E][0]=v[E][0],a[E][1]=v[E][1]):(a[E][0]=Number.MAX_SAFE_INTEGER,a[E][1]=0);a.sort(ag);let M=u.morphAttributes.position,g=u.morphAttributes.normal,f=0;for(let E=0;E<8;E++){let L=a[E],z=L[0],N=L[1];z!==Number.MAX_SAFE_INTEGER&&N?(M&&u.getAttribute("morphTarget"+E)!==M[z]&&u.setAttribute("morphTarget"+E,M[z]),g&&u.getAttribute("morphNormal"+E)!==g[z]&&u.setAttribute("morphNormal"+E,g[z]),s[E]=N,f+=N):(M&&u.hasAttribute("morphTarget"+E)===!0&&u.deleteAttribute("morphTarget"+E),g&&u.hasAttribute("morphNormal"+E)===!0&&u.deleteAttribute("morphNormal"+E),s[E]=0)}let R=u.morphTargetsRelative?1:1-f;d.getUniforms().setValue(i,"morphTargetBaseInfluence",R),d.getUniforms().setValue(i,"morphTargetInfluences",s)}}return{update:l}}function cg(i,t,e,n){let s=new WeakMap;function r(l){let h=n.render.frame,u=l.geometry,d=t.get(l,u);if(s.get(d)!==h&&(t.update(d),s.set(d,h)),l.isInstancedMesh&&(l.hasEventListener("dispose",a)===!1&&l.addEventListener("dispose",a),s.get(l)!==h&&(e.update(l.instanceMatrix,i.ARRAY_BUFFER),l.instanceColor!==null&&e.update(l.instanceColor,i.ARRAY_BUFFER),s.set(l,h))),l.isSkinnedMesh){let m=l.skeleton;s.get(m)!==h&&(m.update(),s.set(m,h))}return d}function o(){s=new WeakMap}function a(l){let h=l.target;h.removeEventListener("dispose",a),e.remove(h.instanceMatrix),h.instanceColor!==null&&e.remove(h.instanceColor)}return{update:r,dispose:o}}var Ta=class extends Sn{constructor(t,e,n,s,r,o,a,l,h,u){if(u=u!==void 0?u:Wi,u!==Wi&&u!==Os)throw new Error("DepthTexture format must be either THREE.DepthFormat or THREE.DepthStencilFormat");n===void 0&&u===Wi&&(n=bi),n===void 0&&u===Os&&(n=Gi),super(null,s,r,o,a,l,u,n,h),this.isDepthTexture=!0,this.image={width:t,height:e},this.magFilter=a!==void 0?a:Ye,this.minFilter=l!==void 0?l:Ye,this.flipY=!1,this.generateMipmaps=!1,this.compareFunction=null}copy(t){return super.copy(t),this.compareFunction=t.compareFunction,this}toJSON(t){let e=super.toJSON(t);return this.compareFunction!==null&&(e.compareFunction=this.compareFunction),e}},lu=new Sn,cu=new Ta(1,1);cu.compareFunction=nu;var hu=new va,uu=new tl,du=new wa,yh=[],bh=[],Mh=new Float32Array(16),Sh=new Float32Array(9),wh=new Float32Array(4);function Vs(i,t,e){let n=i[0];if(n<=0||n>0)return i;let s=t*e,r=yh[s];if(r===void 0&&(r=new Float32Array(s),yh[s]=r),t!==0){n.toArray(r,0);for(let o=1,a=0;o!==t;++o)a+=e,i[o].toArray(r,a)}return r}function Ve(i,t){if(i.length!==t.length)return!1;for(let e=0,n=i.length;e<n;e++)if(i[e]!==t[e])return!1;return!0}function Ge(i,t){for(let e=0,n=t.length;e<n;e++)i[e]=t[e]}function Ga(i,t){let e=bh[t];e===void 0&&(e=new Int32Array(t),bh[t]=e);for(let n=0;n!==t;++n)e[n]=i.allocateTextureUnit();return e}function hg(i,t){let e=this.cache;e[0]!==t&&(i.uniform1f(this.addr,t),e[0]=t)}function ug(i,t){let e=this.cache;if(t.x!==void 0)(e[0]!==t.x||e[1]!==t.y)&&(i.uniform2f(this.addr,t.x,t.y),e[0]=t.x,e[1]=t.y);else{if(Ve(e,t))return;i.uniform2fv(this.addr,t),Ge(e,t)}}function dg(i,t){let e=this.cache;if(t.x!==void 0)(e[0]!==t.x||e[1]!==t.y||e[2]!==t.z)&&(i.uniform3f(this.addr,t.x,t.y,t.z),e[0]=t.x,e[1]=t.y,e[2]=t.z);else if(t.r!==void 0)(e[0]!==t.r||e[1]!==t.g||e[2]!==t.b)&&(i.uniform3f(this.addr,t.r,t.g,t.b),e[0]=t.r,e[1]=t.g,e[2]=t.b);else{if(Ve(e,t))return;i.uniform3fv(this.addr,t),Ge(e,t)}}function fg(i,t){let e=this.cache;if(t.x!==void 0)(e[0]!==t.x||e[1]!==t.y||e[2]!==t.z||e[3]!==t.w)&&(i.uniform4f(this.addr,t.x,t.y,t.z,t.w),e[0]=t.x,e[1]=t.y,e[2]=t.z,e[3]=t.w);else{if(Ve(e,t))return;i.uniform4fv(this.addr,t),Ge(e,t)}}function pg(i,t){let e=this.cache,n=t.elements;if(n===void 0){if(Ve(e,t))return;i.uniformMatrix2fv(this.addr,!1,t),Ge(e,t)}else{if(Ve(e,n))return;wh.set(n),i.uniformMatrix2fv(this.addr,!1,wh),Ge(e,n)}}function mg(i,t){let e=this.cache,n=t.elements;if(n===void 0){if(Ve(e,t))return;i.uniformMatrix3fv(this.addr,!1,t),Ge(e,t)}else{if(Ve(e,n))return;Sh.set(n),i.uniformMatrix3fv(this.addr,!1,Sh),Ge(e,n)}}function gg(i,t){let e=this.cache,n=t.elements;if(n===void 0){if(Ve(e,t))return;i.uniformMatrix4fv(this.addr,!1,t),Ge(e,t)}else{if(Ve(e,n))return;Mh.set(n),i.uniformMatrix4fv(this.addr,!1,Mh),Ge(e,n)}}function xg(i,t){let e=this.cache;e[0]!==t&&(i.uniform1i(this.addr,t),e[0]=t)}function _g(i,t){let e=this.cache;if(t.x!==void 0)(e[0]!==t.x||e[1]!==t.y)&&(i.uniform2i(this.addr,t.x,t.y),e[0]=t.x,e[1]=t.y);else{if(Ve(e,t))return;i.uniform2iv(this.addr,t),Ge(e,t)}}function vg(i,t){let e=this.cache;if(t.x!==void 0)(e[0]!==t.x||e[1]!==t.y||e[2]!==t.z)&&(i.uniform3i(this.addr,t.x,t.y,t.z),e[0]=t.x,e[1]=t.y,e[2]=t.z);else{if(Ve(e,t))return;i.uniform3iv(this.addr,t),Ge(e,t)}}function yg(i,t){let e=this.cache;if(t.x!==void 0)(e[0]!==t.x||e[1]!==t.y||e[2]!==t.z||e[3]!==t.w)&&(i.uniform4i(this.addr,t.x,t.y,t.z,t.w),e[0]=t.x,e[1]=t.y,e[2]=t.z,e[3]=t.w);else{if(Ve(e,t))return;i.uniform4iv(this.addr,t),Ge(e,t)}}function bg(i,t){let e=this.cache;e[0]!==t&&(i.uniform1ui(this.addr,t),e[0]=t)}function Mg(i,t){let e=this.cache;if(t.x!==void 0)(e[0]!==t.x||e[1]!==t.y)&&(i.uniform2ui(this.addr,t.x,t.y),e[0]=t.x,e[1]=t.y);else{if(Ve(e,t))return;i.uniform2uiv(this.addr,t),Ge(e,t)}}function Sg(i,t){let e=this.cache;if(t.x!==void 0)(e[0]!==t.x||e[1]!==t.y||e[2]!==t.z)&&(i.uniform3ui(this.addr,t.x,t.y,t.z),e[0]=t.x,e[1]=t.y,e[2]=t.z);else{if(Ve(e,t))return;i.uniform3uiv(this.addr,t),Ge(e,t)}}function wg(i,t){let e=this.cache;if(t.x!==void 0)(e[0]!==t.x||e[1]!==t.y||e[2]!==t.z||e[3]!==t.w)&&(i.uniform4ui(this.addr,t.x,t.y,t.z,t.w),e[0]=t.x,e[1]=t.y,e[2]=t.z,e[3]=t.w);else{if(Ve(e,t))return;i.uniform4uiv(this.addr,t),Ge(e,t)}}function Eg(i,t,e){let n=this.cache,s=e.allocateTextureUnit();n[0]!==s&&(i.uniform1i(this.addr,s),n[0]=s);let r=this.type===i.SAMPLER_2D_SHADOW?cu:lu;e.setTexture2D(t||r,s)}function Tg(i,t,e){let n=this.cache,s=e.allocateTextureUnit();n[0]!==s&&(i.uniform1i(this.addr,s),n[0]=s),e.setTexture3D(t||uu,s)}function Ag(i,t,e){let n=this.cache,s=e.allocateTextureUnit();n[0]!==s&&(i.uniform1i(this.addr,s),n[0]=s),e.setTextureCube(t||du,s)}function Cg(i,t,e){let n=this.cache,s=e.allocateTextureUnit();n[0]!==s&&(i.uniform1i(this.addr,s),n[0]=s),e.setTexture2DArray(t||hu,s)}function Rg(i){switch(i){case 5126:return hg;case 35664:return ug;case 35665:return dg;case 35666:return fg;case 35674:return pg;case 35675:return mg;case 35676:return gg;case 5124:case 35670:return xg;case 35667:case 35671:return _g;case 35668:case 35672:return vg;case 35669:case 35673:return yg;case 5125:return bg;case 36294:return Mg;case 36295:return Sg;case 36296:return wg;case 35678:case 36198:case 36298:case 36306:case 35682:return Eg;case 35679:case 36299:case 36307:return Tg;case 35680:case 36300:case 36308:case 36293:return Ag;case 36289:case 36303:case 36311:case 36292:return Cg}}function Pg(i,t){i.uniform1fv(this.addr,t)}function Lg(i,t){let e=Vs(t,this.size,2);i.uniform2fv(this.addr,e)}function Ig(i,t){let e=Vs(t,this.size,3);i.uniform3fv(this.addr,e)}function Dg(i,t){let e=Vs(t,this.size,4);i.uniform4fv(this.addr,e)}function Ug(i,t){let e=Vs(t,this.size,4);i.uniformMatrix2fv(this.addr,!1,e)}function Ng(i,t){let e=Vs(t,this.size,9);i.uniformMatrix3fv(this.addr,!1,e)}function Og(i,t){let e=Vs(t,this.size,16);i.uniformMatrix4fv(this.addr,!1,e)}function Fg(i,t){i.uniform1iv(this.addr,t)}function Bg(i,t){i.uniform2iv(this.addr,t)}function zg(i,t){i.uniform3iv(this.addr,t)}function kg(i,t){i.uniform4iv(this.addr,t)}function Hg(i,t){i.uniform1uiv(this.addr,t)}function Vg(i,t){i.uniform2uiv(this.addr,t)}function Gg(i,t){i.uniform3uiv(this.addr,t)}function Wg(i,t){i.uniform4uiv(this.addr,t)}function Xg(i,t,e){let n=this.cache,s=t.length,r=Ga(e,s);Ve(n,r)||(i.uniform1iv(this.addr,r),Ge(n,r));for(let o=0;o!==s;++o)e.setTexture2D(t[o]||lu,r[o])}function Yg(i,t,e){let n=this.cache,s=t.length,r=Ga(e,s);Ve(n,r)||(i.uniform1iv(this.addr,r),Ge(n,r));for(let o=0;o!==s;++o)e.setTexture3D(t[o]||uu,r[o])}function qg(i,t,e){let n=this.cache,s=t.length,r=Ga(e,s);Ve(n,r)||(i.uniform1iv(this.addr,r),Ge(n,r));for(let o=0;o!==s;++o)e.setTextureCube(t[o]||du,r[o])}function Zg(i,t,e){let n=this.cache,s=t.length,r=Ga(e,s);Ve(n,r)||(i.uniform1iv(this.addr,r),Ge(n,r));for(let o=0;o!==s;++o)e.setTexture2DArray(t[o]||hu,r[o])}function Jg(i){switch(i){case 5126:return Pg;case 35664:return Lg;case 35665:return Ig;case 35666:return Dg;case 35674:return Ug;case 35675:return Ng;case 35676:return Og;case 5124:case 35670:return Fg;case 35667:case 35671:return Bg;case 35668:case 35672:return zg;case 35669:case 35673:return kg;case 5125:return Hg;case 36294:return Vg;case 36295:return Gg;case 36296:return Wg;case 35678:case 36198:case 36298:case 36306:case 35682:return Xg;case 35679:case 36299:case 36307:return Yg;case 35680:case 36300:case 36308:case 36293:return qg;case 36289:case 36303:case 36311:case 36292:return Zg}}var il=class{constructor(t,e,n){this.id=t,this.addr=n,this.cache=[],this.type=e.type,this.setValue=Rg(e.type)}},sl=class{constructor(t,e,n){this.id=t,this.addr=n,this.cache=[],this.type=e.type,this.size=e.size,this.setValue=Jg(e.type)}},rl=class{constructor(t){this.id=t,this.seq=[],this.map={}}setValue(t,e,n){let s=this.seq;for(let r=0,o=s.length;r!==o;++r){let a=s[r];a.setValue(t,e[a.id],n)}}},Wo=/(\w+)(\])?(\[|\.)?/g;function Eh(i,t){i.seq.push(t),i.map[t.id]=t}function jg(i,t,e){let n=i.name,s=n.length;for(Wo.lastIndex=0;;){let r=Wo.exec(n),o=Wo.lastIndex,a=r[1],l=r[2]==="]",h=r[3];if(l&&(a=a|0),h===void 0||h==="["&&o+2===s){Eh(e,h===void 0?new il(a,i,t):new sl(a,i,t));break}else{let d=e.map[a];d===void 0&&(d=new rl(a),Eh(e,d)),e=d}}}var Is=class{constructor(t,e){this.seq=[],this.map={};let n=t.getProgramParameter(e,t.ACTIVE_UNIFORMS);for(let s=0;s<n;++s){let r=t.getActiveUniform(e,s),o=t.getUniformLocation(e,r.name);jg(r,o,this)}}setValue(t,e,n,s){let r=this.map[e];r!==void 0&&r.setValue(t,n,s)}setOptional(t,e,n){let s=e[n];s!==void 0&&this.setValue(t,n,s)}static upload(t,e,n,s){for(let r=0,o=e.length;r!==o;++r){let a=e[r],l=n[a.id];l.needsUpdate!==!1&&a.setValue(t,l.value,s)}}static seqWithValue(t,e){let n=[];for(let s=0,r=t.length;s!==r;++s){let o=t[s];o.id in e&&n.push(o)}return n}};function Th(i,t,e){let n=i.createShader(t);return i.shaderSource(n,e),i.compileShader(n),n}var $g=37297,Kg=0;function Qg(i,t){let e=i.split(`
`),n=[],s=Math.max(t-6,0),r=Math.min(t+6,e.length);for(let o=s;o<r;o++){let a=o+1;n.push(`${a===t?">":" "} ${a}: ${e[o]}`)}return n.join(`
`)}function t0(i){let t=fe.getPrimaries(fe.workingColorSpace),e=fe.getPrimaries(i),n;switch(t===e?n="":t===fa&&e===da?n="LinearDisplayP3ToLinearSRGB":t===da&&e===fa&&(n="LinearSRGBToLinearDisplayP3"),i){case li:case Va:return[n,"LinearTransferOETF"];case Re:case Ol:return[n,"sRGBTransferOETF"];default:return console.warn("THREE.WebGLProgram: Unsupported color space:",i),[n,"LinearTransferOETF"]}}function Ah(i,t,e){let n=i.getShaderParameter(t,i.COMPILE_STATUS),s=i.getShaderInfoLog(t).trim();if(n&&s==="")return"";let r=/ERROR: 0:(\d+)/.exec(s);if(r){let o=parseInt(r[1]);return e.toUpperCase()+`

`+s+`

`+Qg(i.getShaderSource(t),o)}else return s}function e0(i,t){let e=t0(t);return`vec4 ${i}( vec4 value ) { return ${e[0]}( ${e[1]}( value ) ); }`}function n0(i,t){let e;switch(t){case Ll:e="Linear";break;case Il:e="Reinhard";break;case Dl:e="OptimizedCineon";break;case Er:e="ACESFilmic";break;case Ul:e="AgX";break;case dd:e="Custom";break;default:console.warn("THREE.WebGLProgram: Unsupported toneMapping:",t),e="Linear"}return"vec3 "+i+"( vec3 color ) { return "+e+"ToneMapping( color ); }"}function i0(i){return[i.extensionDerivatives||i.envMapCubeUVHeight||i.bumpMap||i.normalMapTangentSpace||i.clearcoatNormalMap||i.flatShading||i.shaderID==="physical"?"#extension GL_OES_standard_derivatives : enable":"",(i.extensionFragDepth||i.logarithmicDepthBuffer)&&i.rendererExtensionFragDepth?"#extension GL_EXT_frag_depth : enable":"",i.extensionDrawBuffers&&i.rendererExtensionDrawBuffers?"#extension GL_EXT_draw_buffers : require":"",(i.extensionShaderTextureLOD||i.envMap||i.transmission)&&i.rendererExtensionShaderTextureLod?"#extension GL_EXT_shader_texture_lod : enable":""].filter(Ps).join(`
`)}function s0(i){return[i.extensionClipCullDistance?"#extension GL_ANGLE_clip_cull_distance : require":""].filter(Ps).join(`
`)}function r0(i){let t=[];for(let e in i){let n=i[e];n!==!1&&t.push("#define "+e+" "+n)}return t.join(`
`)}function a0(i,t){let e={},n=i.getProgramParameter(t,i.ACTIVE_ATTRIBUTES);for(let s=0;s<n;s++){let r=i.getActiveAttrib(t,s),o=r.name,a=1;r.type===i.FLOAT_MAT2&&(a=2),r.type===i.FLOAT_MAT3&&(a=3),r.type===i.FLOAT_MAT4&&(a=4),e[o]={type:r.type,location:i.getAttribLocation(t,o),locationSize:a}}return e}function Ps(i){return i!==""}function Ch(i,t){let e=t.numSpotLightShadows+t.numSpotLightMaps-t.numSpotLightShadowsWithMaps;return i.replace(/NUM_DIR_LIGHTS/g,t.numDirLights).replace(/NUM_SPOT_LIGHTS/g,t.numSpotLights).replace(/NUM_SPOT_LIGHT_MAPS/g,t.numSpotLightMaps).replace(/NUM_SPOT_LIGHT_COORDS/g,e).replace(/NUM_RECT_AREA_LIGHTS/g,t.numRectAreaLights).replace(/NUM_POINT_LIGHTS/g,t.numPointLights).replace(/NUM_HEMI_LIGHTS/g,t.numHemiLights).replace(/NUM_DIR_LIGHT_SHADOWS/g,t.numDirLightShadows).replace(/NUM_SPOT_LIGHT_SHADOWS_WITH_MAPS/g,t.numSpotLightShadowsWithMaps).replace(/NUM_SPOT_LIGHT_SHADOWS/g,t.numSpotLightShadows).replace(/NUM_POINT_LIGHT_SHADOWS/g,t.numPointLightShadows)}function Rh(i,t){return i.replace(/NUM_CLIPPING_PLANES/g,t.numClippingPlanes).replace(/UNION_CLIPPING_PLANES/g,t.numClippingPlanes-t.numClipIntersection)}var o0=/^[ \t]*#include +<([\w\d./]+)>/gm;function al(i){return i.replace(o0,c0)}var l0=new Map([["encodings_fragment","colorspace_fragment"],["encodings_pars_fragment","colorspace_pars_fragment"],["output_fragment","opaque_fragment"]]);function c0(i,t){let e=te[t];if(e===void 0){let n=l0.get(t);if(n!==void 0)e=te[n],console.warn('THREE.WebGLRenderer: Shader chunk "%s" has been deprecated. Use "%s" instead.',t,n);else throw new Error("Can not resolve #include <"+t+">")}return al(e)}var h0=/#pragma unroll_loop_start\s+for\s*\(\s*int\s+i\s*=\s*(\d+)\s*;\s*i\s*<\s*(\d+)\s*;\s*i\s*\+\+\s*\)\s*{([\s\S]+?)}\s+#pragma unroll_loop_end/g;function Ph(i){return i.replace(h0,u0)}function u0(i,t,e,n){let s="";for(let r=parseInt(t);r<parseInt(e);r++)s+=n.replace(/\[\s*i\s*\]/g,"[ "+r+" ]").replace(/UNROLLED_LOOP_INDEX/g,r);return s}function Lh(i){let t="precision "+i.precision+` float;
precision `+i.precision+" int;";return i.precision==="highp"?t+=`
#define HIGH_PRECISION`:i.precision==="mediump"?t+=`
#define MEDIUM_PRECISION`:i.precision==="lowp"&&(t+=`
#define LOW_PRECISION`),t}function d0(i){let t="SHADOWMAP_TYPE_BASIC";return i.shadowMapType===Wh?t="SHADOWMAP_TYPE_PCF":i.shadowMapType===Cl?t="SHADOWMAP_TYPE_PCF_SOFT":i.shadowMapType===si&&(t="SHADOWMAP_TYPE_VSM"),t}function f0(i){let t="ENVMAP_TYPE_CUBE";if(i.envMap)switch(i.envMapMode){case Us:case Ns:t="ENVMAP_TYPE_CUBE";break;case Ha:t="ENVMAP_TYPE_CUBE_UV";break}return t}function p0(i){let t="ENVMAP_MODE_REFLECTION";return i.envMap&&i.envMapMode===Ns&&(t="ENVMAP_MODE_REFRACTION"),t}function m0(i){let t="ENVMAP_BLENDING_NONE";if(i.envMap)switch(i.combine){case Xh:t="ENVMAP_BLENDING_MULTIPLY";break;case hd:t="ENVMAP_BLENDING_MIX";break;case ud:t="ENVMAP_BLENDING_ADD";break}return t}function g0(i){let t=i.envMapCubeUVHeight;if(t===null)return null;let e=Math.log2(t)-2,n=1/t;return{texelWidth:1/(3*Math.max(Math.pow(2,e),112)),texelHeight:n,maxMip:e}}function x0(i,t,e,n){let s=i.getContext(),r=e.defines,o=e.vertexShader,a=e.fragmentShader,l=d0(e),h=f0(e),u=p0(e),d=m0(e),m=g0(e),x=e.isWebGL2?"":i0(e),v=s0(e),M=r0(r),g=s.createProgram(),f,R,E=e.glslVersion?"#version "+e.glslVersion+`
`:"";e.isRawShaderMaterial?(f=["#define SHADER_TYPE "+e.shaderType,"#define SHADER_NAME "+e.shaderName,M].filter(Ps).join(`
`),f.length>0&&(f+=`
`),R=[x,"#define SHADER_TYPE "+e.shaderType,"#define SHADER_NAME "+e.shaderName,M].filter(Ps).join(`
`),R.length>0&&(R+=`
`)):(f=[Lh(e),"#define SHADER_TYPE "+e.shaderType,"#define SHADER_NAME "+e.shaderName,M,e.extensionClipCullDistance?"#define USE_CLIP_DISTANCE":"",e.batching?"#define USE_BATCHING":"",e.instancing?"#define USE_INSTANCING":"",e.instancingColor?"#define USE_INSTANCING_COLOR":"",e.useFog&&e.fog?"#define USE_FOG":"",e.useFog&&e.fogExp2?"#define FOG_EXP2":"",e.map?"#define USE_MAP":"",e.envMap?"#define USE_ENVMAP":"",e.envMap?"#define "+u:"",e.lightMap?"#define USE_LIGHTMAP":"",e.aoMap?"#define USE_AOMAP":"",e.bumpMap?"#define USE_BUMPMAP":"",e.normalMap?"#define USE_NORMALMAP":"",e.normalMapObjectSpace?"#define USE_NORMALMAP_OBJECTSPACE":"",e.normalMapTangentSpace?"#define USE_NORMALMAP_TANGENTSPACE":"",e.displacementMap?"#define USE_DISPLACEMENTMAP":"",e.emissiveMap?"#define USE_EMISSIVEMAP":"",e.anisotropy?"#define USE_ANISOTROPY":"",e.anisotropyMap?"#define USE_ANISOTROPYMAP":"",e.clearcoatMap?"#define USE_CLEARCOATMAP":"",e.clearcoatRoughnessMap?"#define USE_CLEARCOAT_ROUGHNESSMAP":"",e.clearcoatNormalMap?"#define USE_CLEARCOAT_NORMALMAP":"",e.iridescenceMap?"#define USE_IRIDESCENCEMAP":"",e.iridescenceThicknessMap?"#define USE_IRIDESCENCE_THICKNESSMAP":"",e.specularMap?"#define USE_SPECULARMAP":"",e.specularColorMap?"#define USE_SPECULAR_COLORMAP":"",e.specularIntensityMap?"#define USE_SPECULAR_INTENSITYMAP":"",e.roughnessMap?"#define USE_ROUGHNESSMAP":"",e.metalnessMap?"#define USE_METALNESSMAP":"",e.alphaMap?"#define USE_ALPHAMAP":"",e.alphaHash?"#define USE_ALPHAHASH":"",e.transmission?"#define USE_TRANSMISSION":"",e.transmissionMap?"#define USE_TRANSMISSIONMAP":"",e.thicknessMap?"#define USE_THICKNESSMAP":"",e.sheenColorMap?"#define USE_SHEEN_COLORMAP":"",e.sheenRoughnessMap?"#define USE_SHEEN_ROUGHNESSMAP":"",e.mapUv?"#define MAP_UV "+e.mapUv:"",e.alphaMapUv?"#define ALPHAMAP_UV "+e.alphaMapUv:"",e.lightMapUv?"#define LIGHTMAP_UV "+e.lightMapUv:"",e.aoMapUv?"#define AOMAP_UV "+e.aoMapUv:"",e.emissiveMapUv?"#define EMISSIVEMAP_UV "+e.emissiveMapUv:"",e.bumpMapUv?"#define BUMPMAP_UV "+e.bumpMapUv:"",e.normalMapUv?"#define NORMALMAP_UV "+e.normalMapUv:"",e.displacementMapUv?"#define DISPLACEMENTMAP_UV "+e.displacementMapUv:"",e.metalnessMapUv?"#define METALNESSMAP_UV "+e.metalnessMapUv:"",e.roughnessMapUv?"#define ROUGHNESSMAP_UV "+e.roughnessMapUv:"",e.anisotropyMapUv?"#define ANISOTROPYMAP_UV "+e.anisotropyMapUv:"",e.clearcoatMapUv?"#define CLEARCOATMAP_UV "+e.clearcoatMapUv:"",e.clearcoatNormalMapUv?"#define CLEARCOAT_NORMALMAP_UV "+e.clearcoatNormalMapUv:"",e.clearcoatRoughnessMapUv?"#define CLEARCOAT_ROUGHNESSMAP_UV "+e.clearcoatRoughnessMapUv:"",e.iridescenceMapUv?"#define IRIDESCENCEMAP_UV "+e.iridescenceMapUv:"",e.iridescenceThicknessMapUv?"#define IRIDESCENCE_THICKNESSMAP_UV "+e.iridescenceThicknessMapUv:"",e.sheenColorMapUv?"#define SHEEN_COLORMAP_UV "+e.sheenColorMapUv:"",e.sheenRoughnessMapUv?"#define SHEEN_ROUGHNESSMAP_UV "+e.sheenRoughnessMapUv:"",e.specularMapUv?"#define SPECULARMAP_UV "+e.specularMapUv:"",e.specularColorMapUv?"#define SPECULAR_COLORMAP_UV "+e.specularColorMapUv:"",e.specularIntensityMapUv?"#define SPECULAR_INTENSITYMAP_UV "+e.specularIntensityMapUv:"",e.transmissionMapUv?"#define TRANSMISSIONMAP_UV "+e.transmissionMapUv:"",e.thicknessMapUv?"#define THICKNESSMAP_UV "+e.thicknessMapUv:"",e.vertexTangents&&e.flatShading===!1?"#define USE_TANGENT":"",e.vertexColors?"#define USE_COLOR":"",e.vertexAlphas?"#define USE_COLOR_ALPHA":"",e.vertexUv1s?"#define USE_UV1":"",e.vertexUv2s?"#define USE_UV2":"",e.vertexUv3s?"#define USE_UV3":"",e.pointsUvs?"#define USE_POINTS_UV":"",e.flatShading?"#define FLAT_SHADED":"",e.skinning?"#define USE_SKINNING":"",e.morphTargets?"#define USE_MORPHTARGETS":"",e.morphNormals&&e.flatShading===!1?"#define USE_MORPHNORMALS":"",e.morphColors&&e.isWebGL2?"#define USE_MORPHCOLORS":"",e.morphTargetsCount>0&&e.isWebGL2?"#define MORPHTARGETS_TEXTURE":"",e.morphTargetsCount>0&&e.isWebGL2?"#define MORPHTARGETS_TEXTURE_STRIDE "+e.morphTextureStride:"",e.morphTargetsCount>0&&e.isWebGL2?"#define MORPHTARGETS_COUNT "+e.morphTargetsCount:"",e.doubleSided?"#define DOUBLE_SIDED":"",e.flipSided?"#define FLIP_SIDED":"",e.shadowMapEnabled?"#define USE_SHADOWMAP":"",e.shadowMapEnabled?"#define "+l:"",e.sizeAttenuation?"#define USE_SIZEATTENUATION":"",e.numLightProbes>0?"#define USE_LIGHT_PROBES":"",e.useLegacyLights?"#define LEGACY_LIGHTS":"",e.logarithmicDepthBuffer?"#define USE_LOGDEPTHBUF":"",e.logarithmicDepthBuffer&&e.rendererExtensionFragDepth?"#define USE_LOGDEPTHBUF_EXT":"","uniform mat4 modelMatrix;","uniform mat4 modelViewMatrix;","uniform mat4 projectionMatrix;","uniform mat4 viewMatrix;","uniform mat3 normalMatrix;","uniform vec3 cameraPosition;","uniform bool isOrthographic;","#ifdef USE_INSTANCING","	attribute mat4 instanceMatrix;","#endif","#ifdef USE_INSTANCING_COLOR","	attribute vec3 instanceColor;","#endif","attribute vec3 position;","attribute vec3 normal;","attribute vec2 uv;","#ifdef USE_UV1","	attribute vec2 uv1;","#endif","#ifdef USE_UV2","	attribute vec2 uv2;","#endif","#ifdef USE_UV3","	attribute vec2 uv3;","#endif","#ifdef USE_TANGENT","	attribute vec4 tangent;","#endif","#if defined( USE_COLOR_ALPHA )","	attribute vec4 color;","#elif defined( USE_COLOR )","	attribute vec3 color;","#endif","#if ( defined( USE_MORPHTARGETS ) && ! defined( MORPHTARGETS_TEXTURE ) )","	attribute vec3 morphTarget0;","	attribute vec3 morphTarget1;","	attribute vec3 morphTarget2;","	attribute vec3 morphTarget3;","	#ifdef USE_MORPHNORMALS","		attribute vec3 morphNormal0;","		attribute vec3 morphNormal1;","		attribute vec3 morphNormal2;","		attribute vec3 morphNormal3;","	#else","		attribute vec3 morphTarget4;","		attribute vec3 morphTarget5;","		attribute vec3 morphTarget6;","		attribute vec3 morphTarget7;","	#endif","#endif","#ifdef USE_SKINNING","	attribute vec4 skinIndex;","	attribute vec4 skinWeight;","#endif",`
`].filter(Ps).join(`
`),R=[x,Lh(e),"#define SHADER_TYPE "+e.shaderType,"#define SHADER_NAME "+e.shaderName,M,e.useFog&&e.fog?"#define USE_FOG":"",e.useFog&&e.fogExp2?"#define FOG_EXP2":"",e.map?"#define USE_MAP":"",e.matcap?"#define USE_MATCAP":"",e.envMap?"#define USE_ENVMAP":"",e.envMap?"#define "+h:"",e.envMap?"#define "+u:"",e.envMap?"#define "+d:"",m?"#define CUBEUV_TEXEL_WIDTH "+m.texelWidth:"",m?"#define CUBEUV_TEXEL_HEIGHT "+m.texelHeight:"",m?"#define CUBEUV_MAX_MIP "+m.maxMip+".0":"",e.lightMap?"#define USE_LIGHTMAP":"",e.aoMap?"#define USE_AOMAP":"",e.bumpMap?"#define USE_BUMPMAP":"",e.normalMap?"#define USE_NORMALMAP":"",e.normalMapObjectSpace?"#define USE_NORMALMAP_OBJECTSPACE":"",e.normalMapTangentSpace?"#define USE_NORMALMAP_TANGENTSPACE":"",e.emissiveMap?"#define USE_EMISSIVEMAP":"",e.anisotropy?"#define USE_ANISOTROPY":"",e.anisotropyMap?"#define USE_ANISOTROPYMAP":"",e.clearcoat?"#define USE_CLEARCOAT":"",e.clearcoatMap?"#define USE_CLEARCOATMAP":"",e.clearcoatRoughnessMap?"#define USE_CLEARCOAT_ROUGHNESSMAP":"",e.clearcoatNormalMap?"#define USE_CLEARCOAT_NORMALMAP":"",e.iridescence?"#define USE_IRIDESCENCE":"",e.iridescenceMap?"#define USE_IRIDESCENCEMAP":"",e.iridescenceThicknessMap?"#define USE_IRIDESCENCE_THICKNESSMAP":"",e.specularMap?"#define USE_SPECULARMAP":"",e.specularColorMap?"#define USE_SPECULAR_COLORMAP":"",e.specularIntensityMap?"#define USE_SPECULAR_INTENSITYMAP":"",e.roughnessMap?"#define USE_ROUGHNESSMAP":"",e.metalnessMap?"#define USE_METALNESSMAP":"",e.alphaMap?"#define USE_ALPHAMAP":"",e.alphaTest?"#define USE_ALPHATEST":"",e.alphaHash?"#define USE_ALPHAHASH":"",e.sheen?"#define USE_SHEEN":"",e.sheenColorMap?"#define USE_SHEEN_COLORMAP":"",e.sheenRoughnessMap?"#define USE_SHEEN_ROUGHNESSMAP":"",e.transmission?"#define USE_TRANSMISSION":"",e.transmissionMap?"#define USE_TRANSMISSIONMAP":"",e.thicknessMap?"#define USE_THICKNESSMAP":"",e.vertexTangents&&e.flatShading===!1?"#define USE_TANGENT":"",e.vertexColors||e.instancingColor?"#define USE_COLOR":"",e.vertexAlphas?"#define USE_COLOR_ALPHA":"",e.vertexUv1s?"#define USE_UV1":"",e.vertexUv2s?"#define USE_UV2":"",e.vertexUv3s?"#define USE_UV3":"",e.pointsUvs?"#define USE_POINTS_UV":"",e.gradientMap?"#define USE_GRADIENTMAP":"",e.flatShading?"#define FLAT_SHADED":"",e.doubleSided?"#define DOUBLE_SIDED":"",e.flipSided?"#define FLIP_SIDED":"",e.shadowMapEnabled?"#define USE_SHADOWMAP":"",e.shadowMapEnabled?"#define "+l:"",e.premultipliedAlpha?"#define PREMULTIPLIED_ALPHA":"",e.numLightProbes>0?"#define USE_LIGHT_PROBES":"",e.useLegacyLights?"#define LEGACY_LIGHTS":"",e.decodeVideoTexture?"#define DECODE_VIDEO_TEXTURE":"",e.logarithmicDepthBuffer?"#define USE_LOGDEPTHBUF":"",e.logarithmicDepthBuffer&&e.rendererExtensionFragDepth?"#define USE_LOGDEPTHBUF_EXT":"","uniform mat4 viewMatrix;","uniform vec3 cameraPosition;","uniform bool isOrthographic;",e.toneMapping!==wi?"#define TONE_MAPPING":"",e.toneMapping!==wi?te.tonemapping_pars_fragment:"",e.toneMapping!==wi?n0("toneMapping",e.toneMapping):"",e.dithering?"#define DITHERING":"",e.opaque?"#define OPAQUE":"",te.colorspace_pars_fragment,e0("linearToOutputTexel",e.outputColorSpace),e.useDepthPacking?"#define DEPTH_PACKING "+e.depthPacking:"",`
`].filter(Ps).join(`
`)),o=al(o),o=Ch(o,e),o=Rh(o,e),a=al(a),a=Ch(a,e),a=Rh(a,e),o=Ph(o),a=Ph(a),e.isWebGL2&&e.isRawShaderMaterial!==!0&&(E=`#version 300 es
`,f=[v,"precision mediump sampler2DArray;","#define attribute in","#define varying out","#define texture2D texture"].join(`
`)+`
`+f,R=["precision mediump sampler2DArray;","#define varying in",e.glslVersion===jc?"":"layout(location = 0) out highp vec4 pc_fragColor;",e.glslVersion===jc?"":"#define gl_FragColor pc_fragColor","#define gl_FragDepthEXT gl_FragDepth","#define texture2D texture","#define textureCube texture","#define texture2DProj textureProj","#define texture2DLodEXT textureLod","#define texture2DProjLodEXT textureProjLod","#define textureCubeLodEXT textureLod","#define texture2DGradEXT textureGrad","#define texture2DProjGradEXT textureProjGrad","#define textureCubeGradEXT textureGrad"].join(`
`)+`
`+R);let L=E+f+o,z=E+R+a,N=Th(s,s.VERTEX_SHADER,L),I=Th(s,s.FRAGMENT_SHADER,z);s.attachShader(g,N),s.attachShader(g,I),e.index0AttributeName!==void 0?s.bindAttribLocation(g,0,e.index0AttributeName):e.morphTargets===!0&&s.bindAttribLocation(g,0,"position"),s.linkProgram(g);function it(tt){if(i.debug.checkShaderErrors){let at=s.getProgramInfoLog(g).trim(),F=s.getShaderInfoLog(N).trim(),V=s.getShaderInfoLog(I).trim(),Z=!0,k=!0;if(s.getProgramParameter(g,s.LINK_STATUS)===!1)if(Z=!1,typeof i.debug.onShaderError=="function")i.debug.onShaderError(s,g,N,I);else{let $=Ah(s,N,"vertex"),K=Ah(s,I,"fragment");console.error("THREE.WebGLProgram: Shader Error "+s.getError()+" - VALIDATE_STATUS "+s.getProgramParameter(g,s.VALIDATE_STATUS)+`

Program Info Log: `+at+`
`+$+`
`+K)}else at!==""?console.warn("THREE.WebGLProgram: Program Info Log:",at):(F===""||V==="")&&(k=!1);k&&(tt.diagnostics={runnable:Z,programLog:at,vertexShader:{log:F,prefix:f},fragmentShader:{log:V,prefix:R}})}s.deleteShader(N),s.deleteShader(I),w=new Is(s,g),A=a0(s,g)}let w;this.getUniforms=function(){return w===void 0&&it(this),w};let A;this.getAttributes=function(){return A===void 0&&it(this),A};let X=e.rendererExtensionParallelShaderCompile===!1;return this.isReady=function(){return X===!1&&(X=s.getProgramParameter(g,$g)),X},this.destroy=function(){n.releaseStatesOfProgram(this),s.deleteProgram(g),this.program=void 0},this.type=e.shaderType,this.name=e.shaderName,this.id=Kg++,this.cacheKey=t,this.usedTimes=1,this.program=g,this.vertexShader=N,this.fragmentShader=I,this}var _0=0,ol=class{constructor(){this.shaderCache=new Map,this.materialCache=new Map}update(t){let e=t.vertexShader,n=t.fragmentShader,s=this._getShaderStage(e),r=this._getShaderStage(n),o=this._getShaderCacheForMaterial(t);return o.has(s)===!1&&(o.add(s),s.usedTimes++),o.has(r)===!1&&(o.add(r),r.usedTimes++),this}remove(t){let e=this.materialCache.get(t);for(let n of e)n.usedTimes--,n.usedTimes===0&&this.shaderCache.delete(n.code);return this.materialCache.delete(t),this}getVertexShaderID(t){return this._getShaderStage(t.vertexShader).id}getFragmentShaderID(t){return this._getShaderStage(t.fragmentShader).id}dispose(){this.shaderCache.clear(),this.materialCache.clear()}_getShaderCacheForMaterial(t){let e=this.materialCache,n=e.get(t);return n===void 0&&(n=new Set,e.set(t,n)),n}_getShaderStage(t){let e=this.shaderCache,n=e.get(t);return n===void 0&&(n=new ll(t),e.set(t,n)),n}},ll=class{constructor(t){this.id=_0++,this.code=t,this.usedTimes=0}};function v0(i,t,e,n,s,r,o){let a=new xr,l=new ol,h=[],u=s.isWebGL2,d=s.logarithmicDepthBuffer,m=s.vertexTextures,x=s.precision,v={MeshDepthMaterial:"depth",MeshDistanceMaterial:"distanceRGBA",MeshNormalMaterial:"normal",MeshBasicMaterial:"basic",MeshLambertMaterial:"lambert",MeshPhongMaterial:"phong",MeshToonMaterial:"toon",MeshStandardMaterial:"physical",MeshPhysicalMaterial:"physical",MeshMatcapMaterial:"matcap",LineBasicMaterial:"basic",LineDashedMaterial:"dashed",PointsMaterial:"points",ShadowMaterial:"shadow",SpriteMaterial:"sprite"};function M(w){return w===0?"uv":`uv${w}`}function g(w,A,X,tt,at){let F=tt.fog,V=at.geometry,Z=w.isMeshStandardMaterial?tt.environment:null,k=(w.isMeshStandardMaterial?e:t).get(w.envMap||Z),$=k&&k.mapping===Ha?k.image.height:null,K=v[w.type];w.precision!==null&&(x=s.getMaxPrecision(w.precision),x!==w.precision&&console.warn("THREE.WebGLProgram.getParameters:",w.precision,"not supported, using",x,"instead."));let et=V.morphAttributes.position||V.morphAttributes.normal||V.morphAttributes.color,rt=et!==void 0?et.length:0,vt=0;V.morphAttributes.position!==void 0&&(vt=1),V.morphAttributes.normal!==void 0&&(vt=2),V.morphAttributes.color!==void 0&&(vt=3);let G,nt,mt,Tt;if(K){let Ce=qn[K];G=Ce.vertexShader,nt=Ce.fragmentShader}else G=w.vertexShader,nt=w.fragmentShader,l.update(w),mt=l.getVertexShaderID(w),Tt=l.getFragmentShaderID(w);let It=i.getRenderTarget(),Wt=at.isInstancedMesh===!0,Ht=at.isBatchedMesh===!0,Bt=!!w.map,ee=!!w.matcap,q=!!k,Pe=!!w.aoMap,Ft=!!w.lightMap,Vt=!!w.bumpMap,Rt=!!w.normalMap,pe=!!w.displacementMap,Yt=!!w.emissiveMap,C=!!w.metalnessMap,b=!!w.roughnessMap,Y=w.anisotropy>0,Q=w.clearcoat>0,ot=w.iridescence>0,ct=w.sheen>0,Lt=w.transmission>0,St=Y&&!!w.anisotropyMap,yt=Q&&!!w.clearcoatMap,kt=Q&&!!w.clearcoatNormalMap,Gt=Q&&!!w.clearcoatRoughnessMap,ht=ot&&!!w.iridescenceMap,ne=ot&&!!w.iridescenceThicknessMap,P=ct&&!!w.sheenColorMap,lt=ct&&!!w.sheenRoughnessMap,_t=!!w.specularMap,dt=!!w.specularColorMap,Nt=!!w.specularIntensityMap,$t=Lt&&!!w.transmissionMap,re=Lt&&!!w.thicknessMap,jt=!!w.gradientMap,gt=!!w.alphaMap,U=w.alphaTest>0,ft=!!w.alphaHash,xt=!!w.extensions,Pt=!!V.attributes.uv1,Ot=!!V.attributes.uv2,le=!!V.attributes.uv3,he=wi;return w.toneMapped&&(It===null||It.isXRRenderTarget===!0)&&(he=i.toneMapping),{isWebGL2:u,shaderID:K,shaderType:w.type,shaderName:w.name,vertexShader:G,fragmentShader:nt,defines:w.defines,customVertexShaderID:mt,customFragmentShaderID:Tt,isRawShaderMaterial:w.isRawShaderMaterial===!0,glslVersion:w.glslVersion,precision:x,batching:Ht,instancing:Wt,instancingColor:Wt&&at.instanceColor!==null,supportsVertexTextures:m,outputColorSpace:It===null?i.outputColorSpace:It.isXRRenderTarget===!0?It.texture.colorSpace:li,map:Bt,matcap:ee,envMap:q,envMapMode:q&&k.mapping,envMapCubeUVHeight:$,aoMap:Pe,lightMap:Ft,bumpMap:Vt,normalMap:Rt,displacementMap:m&&pe,emissiveMap:Yt,normalMapObjectSpace:Rt&&w.normalMapType===wd,normalMapTangentSpace:Rt&&w.normalMapType===eu,metalnessMap:C,roughnessMap:b,anisotropy:Y,anisotropyMap:St,clearcoat:Q,clearcoatMap:yt,clearcoatNormalMap:kt,clearcoatRoughnessMap:Gt,iridescence:ot,iridescenceMap:ht,iridescenceThicknessMap:ne,sheen:ct,sheenColorMap:P,sheenRoughnessMap:lt,specularMap:_t,specularColorMap:dt,specularIntensityMap:Nt,transmission:Lt,transmissionMap:$t,thicknessMap:re,gradientMap:jt,opaque:w.transparent===!1&&w.blending===oi,alphaMap:gt,alphaTest:U,alphaHash:ft,combine:w.combine,mapUv:Bt&&M(w.map.channel),aoMapUv:Pe&&M(w.aoMap.channel),lightMapUv:Ft&&M(w.lightMap.channel),bumpMapUv:Vt&&M(w.bumpMap.channel),normalMapUv:Rt&&M(w.normalMap.channel),displacementMapUv:pe&&M(w.displacementMap.channel),emissiveMapUv:Yt&&M(w.emissiveMap.channel),metalnessMapUv:C&&M(w.metalnessMap.channel),roughnessMapUv:b&&M(w.roughnessMap.channel),anisotropyMapUv:St&&M(w.anisotropyMap.channel),clearcoatMapUv:yt&&M(w.clearcoatMap.channel),clearcoatNormalMapUv:kt&&M(w.clearcoatNormalMap.channel),clearcoatRoughnessMapUv:Gt&&M(w.clearcoatRoughnessMap.channel),iridescenceMapUv:ht&&M(w.iridescenceMap.channel),iridescenceThicknessMapUv:ne&&M(w.iridescenceThicknessMap.channel),sheenColorMapUv:P&&M(w.sheenColorMap.channel),sheenRoughnessMapUv:lt&&M(w.sheenRoughnessMap.channel),specularMapUv:_t&&M(w.specularMap.channel),specularColorMapUv:dt&&M(w.specularColorMap.channel),specularIntensityMapUv:Nt&&M(w.specularIntensityMap.channel),transmissionMapUv:$t&&M(w.transmissionMap.channel),thicknessMapUv:re&&M(w.thicknessMap.channel),alphaMapUv:gt&&M(w.alphaMap.channel),vertexTangents:!!V.attributes.tangent&&(Rt||Y),vertexColors:w.vertexColors,vertexAlphas:w.vertexColors===!0&&!!V.attributes.color&&V.attributes.color.itemSize===4,vertexUv1s:Pt,vertexUv2s:Ot,vertexUv3s:le,pointsUvs:at.isPoints===!0&&!!V.attributes.uv&&(Bt||gt),fog:!!F,useFog:w.fog===!0,fogExp2:F&&F.isFogExp2,flatShading:w.flatShading===!0,sizeAttenuation:w.sizeAttenuation===!0,logarithmicDepthBuffer:d,skinning:at.isSkinnedMesh===!0,morphTargets:V.morphAttributes.position!==void 0,morphNormals:V.morphAttributes.normal!==void 0,morphColors:V.morphAttributes.color!==void 0,morphTargetsCount:rt,morphTextureStride:vt,numDirLights:A.directional.length,numPointLights:A.point.length,numSpotLights:A.spot.length,numSpotLightMaps:A.spotLightMap.length,numRectAreaLights:A.rectArea.length,numHemiLights:A.hemi.length,numDirLightShadows:A.directionalShadowMap.length,numPointLightShadows:A.pointShadowMap.length,numSpotLightShadows:A.spotShadowMap.length,numSpotLightShadowsWithMaps:A.numSpotLightShadowsWithMaps,numLightProbes:A.numLightProbes,numClippingPlanes:o.numPlanes,numClipIntersection:o.numIntersection,dithering:w.dithering,shadowMapEnabled:i.shadowMap.enabled&&X.length>0,shadowMapType:i.shadowMap.type,toneMapping:he,useLegacyLights:i._useLegacyLights,decodeVideoTexture:Bt&&w.map.isVideoTexture===!0&&fe.getTransfer(w.map.colorSpace)===me,premultipliedAlpha:w.premultipliedAlpha,doubleSided:w.side===Un,flipSided:w.side===pn,useDepthPacking:w.depthPacking>=0,depthPacking:w.depthPacking||0,index0AttributeName:w.index0AttributeName,extensionDerivatives:xt&&w.extensions.derivatives===!0,extensionFragDepth:xt&&w.extensions.fragDepth===!0,extensionDrawBuffers:xt&&w.extensions.drawBuffers===!0,extensionShaderTextureLOD:xt&&w.extensions.shaderTextureLOD===!0,extensionClipCullDistance:xt&&w.extensions.clipCullDistance&&n.has("WEBGL_clip_cull_distance"),rendererExtensionFragDepth:u||n.has("EXT_frag_depth"),rendererExtensionDrawBuffers:u||n.has("WEBGL_draw_buffers"),rendererExtensionShaderTextureLod:u||n.has("EXT_shader_texture_lod"),rendererExtensionParallelShaderCompile:n.has("KHR_parallel_shader_compile"),customProgramCacheKey:w.customProgramCacheKey()}}function f(w){let A=[];if(w.shaderID?A.push(w.shaderID):(A.push(w.customVertexShaderID),A.push(w.customFragmentShaderID)),w.defines!==void 0)for(let X in w.defines)A.push(X),A.push(w.defines[X]);return w.isRawShaderMaterial===!1&&(R(A,w),E(A,w),A.push(i.outputColorSpace)),A.push(w.customProgramCacheKey),A.join()}function R(w,A){w.push(A.precision),w.push(A.outputColorSpace),w.push(A.envMapMode),w.push(A.envMapCubeUVHeight),w.push(A.mapUv),w.push(A.alphaMapUv),w.push(A.lightMapUv),w.push(A.aoMapUv),w.push(A.bumpMapUv),w.push(A.normalMapUv),w.push(A.displacementMapUv),w.push(A.emissiveMapUv),w.push(A.metalnessMapUv),w.push(A.roughnessMapUv),w.push(A.anisotropyMapUv),w.push(A.clearcoatMapUv),w.push(A.clearcoatNormalMapUv),w.push(A.clearcoatRoughnessMapUv),w.push(A.iridescenceMapUv),w.push(A.iridescenceThicknessMapUv),w.push(A.sheenColorMapUv),w.push(A.sheenRoughnessMapUv),w.push(A.specularMapUv),w.push(A.specularColorMapUv),w.push(A.specularIntensityMapUv),w.push(A.transmissionMapUv),w.push(A.thicknessMapUv),w.push(A.combine),w.push(A.fogExp2),w.push(A.sizeAttenuation),w.push(A.morphTargetsCount),w.push(A.morphAttributeCount),w.push(A.numDirLights),w.push(A.numPointLights),w.push(A.numSpotLights),w.push(A.numSpotLightMaps),w.push(A.numHemiLights),w.push(A.numRectAreaLights),w.push(A.numDirLightShadows),w.push(A.numPointLightShadows),w.push(A.numSpotLightShadows),w.push(A.numSpotLightShadowsWithMaps),w.push(A.numLightProbes),w.push(A.shadowMapType),w.push(A.toneMapping),w.push(A.numClippingPlanes),w.push(A.numClipIntersection),w.push(A.depthPacking)}function E(w,A){a.disableAll(),A.isWebGL2&&a.enable(0),A.supportsVertexTextures&&a.enable(1),A.instancing&&a.enable(2),A.instancingColor&&a.enable(3),A.matcap&&a.enable(4),A.envMap&&a.enable(5),A.normalMapObjectSpace&&a.enable(6),A.normalMapTangentSpace&&a.enable(7),A.clearcoat&&a.enable(8),A.iridescence&&a.enable(9),A.alphaTest&&a.enable(10),A.vertexColors&&a.enable(11),A.vertexAlphas&&a.enable(12),A.vertexUv1s&&a.enable(13),A.vertexUv2s&&a.enable(14),A.vertexUv3s&&a.enable(15),A.vertexTangents&&a.enable(16),A.anisotropy&&a.enable(17),A.alphaHash&&a.enable(18),A.batching&&a.enable(19),w.push(a.mask),a.disableAll(),A.fog&&a.enable(0),A.useFog&&a.enable(1),A.flatShading&&a.enable(2),A.logarithmicDepthBuffer&&a.enable(3),A.skinning&&a.enable(4),A.morphTargets&&a.enable(5),A.morphNormals&&a.enable(6),A.morphColors&&a.enable(7),A.premultipliedAlpha&&a.enable(8),A.shadowMapEnabled&&a.enable(9),A.useLegacyLights&&a.enable(10),A.doubleSided&&a.enable(11),A.flipSided&&a.enable(12),A.useDepthPacking&&a.enable(13),A.dithering&&a.enable(14),A.transmission&&a.enable(15),A.sheen&&a.enable(16),A.opaque&&a.enable(17),A.pointsUvs&&a.enable(18),A.decodeVideoTexture&&a.enable(19),w.push(a.mask)}function L(w){let A=v[w.type],X;if(A){let tt=qn[A];X=Ri.clone(tt.uniforms)}else X=w.uniforms;return X}function z(w,A){let X;for(let tt=0,at=h.length;tt<at;tt++){let F=h[tt];if(F.cacheKey===A){X=F,++X.usedTimes;break}}return X===void 0&&(X=new x0(i,A,w,r),h.push(X)),X}function N(w){if(--w.usedTimes===0){let A=h.indexOf(w);h[A]=h[h.length-1],h.pop(),w.destroy()}}function I(w){l.remove(w)}function it(){l.dispose()}return{getParameters:g,getProgramCacheKey:f,getUniforms:L,acquireProgram:z,releaseProgram:N,releaseShaderCache:I,programs:h,dispose:it}}function y0(){let i=new WeakMap;function t(r){let o=i.get(r);return o===void 0&&(o={},i.set(r,o)),o}function e(r){i.delete(r)}function n(r,o,a){i.get(r)[o]=a}function s(){i=new WeakMap}return{get:t,remove:e,update:n,dispose:s}}function b0(i,t){return i.groupOrder!==t.groupOrder?i.groupOrder-t.groupOrder:i.renderOrder!==t.renderOrder?i.renderOrder-t.renderOrder:i.material.id!==t.material.id?i.material.id-t.material.id:i.z!==t.z?i.z-t.z:i.id-t.id}function Ih(i,t){return i.groupOrder!==t.groupOrder?i.groupOrder-t.groupOrder:i.renderOrder!==t.renderOrder?i.renderOrder-t.renderOrder:i.z!==t.z?t.z-i.z:i.id-t.id}function Dh(){let i=[],t=0,e=[],n=[],s=[];function r(){t=0,e.length=0,n.length=0,s.length=0}function o(d,m,x,v,M,g){let f=i[t];return f===void 0?(f={id:d.id,object:d,geometry:m,material:x,groupOrder:v,renderOrder:d.renderOrder,z:M,group:g},i[t]=f):(f.id=d.id,f.object=d,f.geometry=m,f.material=x,f.groupOrder=v,f.renderOrder=d.renderOrder,f.z=M,f.group=g),t++,f}function a(d,m,x,v,M,g){let f=o(d,m,x,v,M,g);x.transmission>0?n.push(f):x.transparent===!0?s.push(f):e.push(f)}function l(d,m,x,v,M,g){let f=o(d,m,x,v,M,g);x.transmission>0?n.unshift(f):x.transparent===!0?s.unshift(f):e.unshift(f)}function h(d,m){e.length>1&&e.sort(d||b0),n.length>1&&n.sort(m||Ih),s.length>1&&s.sort(m||Ih)}function u(){for(let d=t,m=i.length;d<m;d++){let x=i[d];if(x.id===null)break;x.id=null,x.object=null,x.geometry=null,x.material=null,x.group=null}}return{opaque:e,transmissive:n,transparent:s,init:r,push:a,unshift:l,finish:u,sort:h}}function M0(){let i=new WeakMap;function t(n,s){let r=i.get(n),o;return r===void 0?(o=new Dh,i.set(n,[o])):s>=r.length?(o=new Dh,r.push(o)):o=r[s],o}function e(){i=new WeakMap}return{get:t,dispose:e}}function S0(){let i={};return{get:function(t){if(i[t.id]!==void 0)return i[t.id];let e;switch(t.type){case"DirectionalLight":e={direction:new B,color:new Xt};break;case"SpotLight":e={position:new B,direction:new B,color:new Xt,distance:0,coneCos:0,penumbraCos:0,decay:0};break;case"PointLight":e={position:new B,color:new Xt,distance:0,decay:0};break;case"HemisphereLight":e={direction:new B,skyColor:new Xt,groundColor:new Xt};break;case"RectAreaLight":e={color:new Xt,position:new B,halfWidth:new B,halfHeight:new B};break}return i[t.id]=e,e}}}function w0(){let i={};return{get:function(t){if(i[t.id]!==void 0)return i[t.id];let e;switch(t.type){case"DirectionalLight":e={shadowBias:0,shadowNormalBias:0,shadowRadius:1,shadowMapSize:new At};break;case"SpotLight":e={shadowBias:0,shadowNormalBias:0,shadowRadius:1,shadowMapSize:new At};break;case"PointLight":e={shadowBias:0,shadowNormalBias:0,shadowRadius:1,shadowMapSize:new At,shadowCameraNear:1,shadowCameraFar:1e3};break}return i[t.id]=e,e}}}var E0=0;function T0(i,t){return(t.castShadow?2:0)-(i.castShadow?2:0)+(t.map?1:0)-(i.map?1:0)}function A0(i,t){let e=new S0,n=w0(),s={version:0,hash:{directionalLength:-1,pointLength:-1,spotLength:-1,rectAreaLength:-1,hemiLength:-1,numDirectionalShadows:-1,numPointShadows:-1,numSpotShadows:-1,numSpotMaps:-1,numLightProbes:-1},ambient:[0,0,0],probe:[],directional:[],directionalShadow:[],directionalShadowMap:[],directionalShadowMatrix:[],spot:[],spotLightMap:[],spotShadow:[],spotShadowMap:[],spotLightMatrix:[],rectArea:[],rectAreaLTC1:null,rectAreaLTC2:null,point:[],pointShadow:[],pointShadowMap:[],pointShadowMatrix:[],hemi:[],numSpotLightShadowsWithMaps:0,numLightProbes:0};for(let u=0;u<9;u++)s.probe.push(new B);let r=new B,o=new _e,a=new _e;function l(u,d){let m=0,x=0,v=0;for(let tt=0;tt<9;tt++)s.probe[tt].set(0,0,0);let M=0,g=0,f=0,R=0,E=0,L=0,z=0,N=0,I=0,it=0,w=0;u.sort(T0);let A=d===!0?Math.PI:1;for(let tt=0,at=u.length;tt<at;tt++){let F=u[tt],V=F.color,Z=F.intensity,k=F.distance,$=F.shadow&&F.shadow.map?F.shadow.map.texture:null;if(F.isAmbientLight)m+=V.r*Z*A,x+=V.g*Z*A,v+=V.b*Z*A;else if(F.isLightProbe){for(let K=0;K<9;K++)s.probe[K].addScaledVector(F.sh.coefficients[K],Z);w++}else if(F.isDirectionalLight){let K=e.get(F);if(K.color.copy(F.color).multiplyScalar(F.intensity*A),F.castShadow){let et=F.shadow,rt=n.get(F);rt.shadowBias=et.bias,rt.shadowNormalBias=et.normalBias,rt.shadowRadius=et.radius,rt.shadowMapSize=et.mapSize,s.directionalShadow[M]=rt,s.directionalShadowMap[M]=$,s.directionalShadowMatrix[M]=F.shadow.matrix,L++}s.directional[M]=K,M++}else if(F.isSpotLight){let K=e.get(F);K.position.setFromMatrixPosition(F.matrixWorld),K.color.copy(V).multiplyScalar(Z*A),K.distance=k,K.coneCos=Math.cos(F.angle),K.penumbraCos=Math.cos(F.angle*(1-F.penumbra)),K.decay=F.decay,s.spot[f]=K;let et=F.shadow;if(F.map&&(s.spotLightMap[I]=F.map,I++,et.updateMatrices(F),F.castShadow&&it++),s.spotLightMatrix[f]=et.matrix,F.castShadow){let rt=n.get(F);rt.shadowBias=et.bias,rt.shadowNormalBias=et.normalBias,rt.shadowRadius=et.radius,rt.shadowMapSize=et.mapSize,s.spotShadow[f]=rt,s.spotShadowMap[f]=$,N++}f++}else if(F.isRectAreaLight){let K=e.get(F);K.color.copy(V).multiplyScalar(Z),K.halfWidth.set(F.width*.5,0,0),K.halfHeight.set(0,F.height*.5,0),s.rectArea[R]=K,R++}else if(F.isPointLight){let K=e.get(F);if(K.color.copy(F.color).multiplyScalar(F.intensity*A),K.distance=F.distance,K.decay=F.decay,F.castShadow){let et=F.shadow,rt=n.get(F);rt.shadowBias=et.bias,rt.shadowNormalBias=et.normalBias,rt.shadowRadius=et.radius,rt.shadowMapSize=et.mapSize,rt.shadowCameraNear=et.camera.near,rt.shadowCameraFar=et.camera.far,s.pointShadow[g]=rt,s.pointShadowMap[g]=$,s.pointShadowMatrix[g]=F.shadow.matrix,z++}s.point[g]=K,g++}else if(F.isHemisphereLight){let K=e.get(F);K.skyColor.copy(F.color).multiplyScalar(Z*A),K.groundColor.copy(F.groundColor).multiplyScalar(Z*A),s.hemi[E]=K,E++}}R>0&&(t.isWebGL2?i.has("OES_texture_float_linear")===!0?(s.rectAreaLTC1=Mt.LTC_FLOAT_1,s.rectAreaLTC2=Mt.LTC_FLOAT_2):(s.rectAreaLTC1=Mt.LTC_HALF_1,s.rectAreaLTC2=Mt.LTC_HALF_2):i.has("OES_texture_float_linear")===!0?(s.rectAreaLTC1=Mt.LTC_FLOAT_1,s.rectAreaLTC2=Mt.LTC_FLOAT_2):i.has("OES_texture_half_float_linear")===!0?(s.rectAreaLTC1=Mt.LTC_HALF_1,s.rectAreaLTC2=Mt.LTC_HALF_2):console.error("THREE.WebGLRenderer: Unable to use RectAreaLight. Missing WebGL extensions.")),s.ambient[0]=m,s.ambient[1]=x,s.ambient[2]=v;let X=s.hash;(X.directionalLength!==M||X.pointLength!==g||X.spotLength!==f||X.rectAreaLength!==R||X.hemiLength!==E||X.numDirectionalShadows!==L||X.numPointShadows!==z||X.numSpotShadows!==N||X.numSpotMaps!==I||X.numLightProbes!==w)&&(s.directional.length=M,s.spot.length=f,s.rectArea.length=R,s.point.length=g,s.hemi.length=E,s.directionalShadow.length=L,s.directionalShadowMap.length=L,s.pointShadow.length=z,s.pointShadowMap.length=z,s.spotShadow.length=N,s.spotShadowMap.length=N,s.directionalShadowMatrix.length=L,s.pointShadowMatrix.length=z,s.spotLightMatrix.length=N+I-it,s.spotLightMap.length=I,s.numSpotLightShadowsWithMaps=it,s.numLightProbes=w,X.directionalLength=M,X.pointLength=g,X.spotLength=f,X.rectAreaLength=R,X.hemiLength=E,X.numDirectionalShadows=L,X.numPointShadows=z,X.numSpotShadows=N,X.numSpotMaps=I,X.numLightProbes=w,s.version=E0++)}function h(u,d){let m=0,x=0,v=0,M=0,g=0,f=d.matrixWorldInverse;for(let R=0,E=u.length;R<E;R++){let L=u[R];if(L.isDirectionalLight){let z=s.directional[m];z.direction.setFromMatrixPosition(L.matrixWorld),r.setFromMatrixPosition(L.target.matrixWorld),z.direction.sub(r),z.direction.transformDirection(f),m++}else if(L.isSpotLight){let z=s.spot[v];z.position.setFromMatrixPosition(L.matrixWorld),z.position.applyMatrix4(f),z.direction.setFromMatrixPosition(L.matrixWorld),r.setFromMatrixPosition(L.target.matrixWorld),z.direction.sub(r),z.direction.transformDirection(f),v++}else if(L.isRectAreaLight){let z=s.rectArea[M];z.position.setFromMatrixPosition(L.matrixWorld),z.position.applyMatrix4(f),a.identity(),o.copy(L.matrixWorld),o.premultiply(f),a.extractRotation(o),z.halfWidth.set(L.width*.5,0,0),z.halfHeight.set(0,L.height*.5,0),z.halfWidth.applyMatrix4(a),z.halfHeight.applyMatrix4(a),M++}else if(L.isPointLight){let z=s.point[x];z.position.setFromMatrixPosition(L.matrixWorld),z.position.applyMatrix4(f),x++}else if(L.isHemisphereLight){let z=s.hemi[g];z.direction.setFromMatrixPosition(L.matrixWorld),z.direction.transformDirection(f),g++}}}return{setup:l,setupView:h,state:s}}function Uh(i,t){let e=new A0(i,t),n=[],s=[];function r(){n.length=0,s.length=0}function o(d){n.push(d)}function a(d){s.push(d)}function l(d){e.setup(n,d)}function h(d){e.setupView(n,d)}return{init:r,state:{lightsArray:n,shadowsArray:s,lights:e},setupLights:l,setupLightsView:h,pushLight:o,pushShadow:a}}function C0(i,t){let e=new WeakMap;function n(r,o=0){let a=e.get(r),l;return a===void 0?(l=new Uh(i,t),e.set(r,[l])):o>=a.length?(l=new Uh(i,t),a.push(l)):l=a[o],l}function s(){e=new WeakMap}return{get:n,dispose:s}}var cl=class extends Ci{constructor(t){super(),this.isMeshDepthMaterial=!0,this.type="MeshDepthMaterial",this.depthPacking=Md,this.map=null,this.alphaMap=null,this.displacementMap=null,this.displacementScale=1,this.displacementBias=0,this.wireframe=!1,this.wireframeLinewidth=1,this.setValues(t)}copy(t){return super.copy(t),this.depthPacking=t.depthPacking,this.map=t.map,this.alphaMap=t.alphaMap,this.displacementMap=t.displacementMap,this.displacementScale=t.displacementScale,this.displacementBias=t.displacementBias,this.wireframe=t.wireframe,this.wireframeLinewidth=t.wireframeLinewidth,this}},hl=class extends Ci{constructor(t){super(),this.isMeshDistanceMaterial=!0,this.type="MeshDistanceMaterial",this.map=null,this.alphaMap=null,this.displacementMap=null,this.displacementScale=1,this.displacementBias=0,this.setValues(t)}copy(t){return super.copy(t),this.map=t.map,this.alphaMap=t.alphaMap,this.displacementMap=t.displacementMap,this.displacementScale=t.displacementScale,this.displacementBias=t.displacementBias,this}},R0=`void main() {
	gl_Position = vec4( position, 1.0 );
}`,P0=`uniform sampler2D shadow_pass;
uniform vec2 resolution;
uniform float radius;
#include <packing>
void main() {
	const float samples = float( VSM_SAMPLES );
	float mean = 0.0;
	float squared_mean = 0.0;
	float uvStride = samples <= 1.0 ? 0.0 : 2.0 / ( samples - 1.0 );
	float uvStart = samples <= 1.0 ? 0.0 : - 1.0;
	for ( float i = 0.0; i < samples; i ++ ) {
		float uvOffset = uvStart + i * uvStride;
		#ifdef HORIZONTAL_PASS
			vec2 distribution = unpackRGBATo2Half( texture2D( shadow_pass, ( gl_FragCoord.xy + vec2( uvOffset, 0.0 ) * radius ) / resolution ) );
			mean += distribution.x;
			squared_mean += distribution.y * distribution.y + distribution.x * distribution.x;
		#else
			float depth = unpackRGBAToDepth( texture2D( shadow_pass, ( gl_FragCoord.xy + vec2( 0.0, uvOffset ) * radius ) / resolution ) );
			mean += depth;
			squared_mean += depth * depth;
		#endif
	}
	mean = mean / samples;
	squared_mean = squared_mean / samples;
	float std_dev = sqrt( squared_mean - mean * mean );
	gl_FragColor = pack2HalfToRGBA( vec2( mean, std_dev ) );
}`;function L0(i,t,e){let n=new _r,s=new At,r=new At,o=new Se,a=new cl({depthPacking:Sd}),l=new hl,h={},u=e.maxTextureSize,d={[Ti]:pn,[pn]:Ti,[Un]:Un},m=new Be({defines:{VSM_SAMPLES:8},uniforms:{shadow_pass:{value:null},resolution:{value:new At},radius:{value:4}},vertexShader:R0,fragmentShader:P0}),x=m.clone();x.defines.HORIZONTAL_PASS=1;let v=new _n;v.setAttribute("position",new cn(new Float32Array([-1,-1,.5,3,-1,.5,-1,3,.5]),3));let M=new Je(v,m),g=this;this.enabled=!1,this.autoUpdate=!0,this.needsUpdate=!1,this.type=Wh;let f=this.type;this.render=function(N,I,it){if(g.enabled===!1||g.autoUpdate===!1&&g.needsUpdate===!1||N.length===0)return;let w=i.getRenderTarget(),A=i.getActiveCubeFace(),X=i.getActiveMipmapLevel(),tt=i.state;tt.setBlending(Zn),tt.buffers.color.setClear(1,1,1,1),tt.buffers.depth.setTest(!0),tt.setScissorTest(!1);let at=f!==si&&this.type===si,F=f===si&&this.type!==si;for(let V=0,Z=N.length;V<Z;V++){let k=N[V],$=k.shadow;if($===void 0){console.warn("THREE.WebGLShadowMap:",k,"has no shadow.");continue}if($.autoUpdate===!1&&$.needsUpdate===!1)continue;s.copy($.mapSize);let K=$.getFrameExtents();if(s.multiply(K),r.copy($.mapSize),(s.x>u||s.y>u)&&(s.x>u&&(r.x=Math.floor(u/K.x),s.x=r.x*K.x,$.mapSize.x=r.x),s.y>u&&(r.y=Math.floor(u/K.y),s.y=r.y*K.y,$.mapSize.y=r.y)),$.map===null||at===!0||F===!0){let rt=this.type!==si?{minFilter:Ye,magFilter:Ye}:{};$.map!==null&&$.map.dispose(),$.map=new je(s.x,s.y,rt),$.map.texture.name=k.name+".shadowMap",$.camera.updateProjectionMatrix()}i.setRenderTarget($.map),i.clear();let et=$.getViewportCount();for(let rt=0;rt<et;rt++){let vt=$.getViewport(rt);o.set(r.x*vt.x,r.y*vt.y,r.x*vt.z,r.y*vt.w),tt.viewport(o),$.updateMatrices(k,rt),n=$.getFrustum(),L(I,it,$.camera,k,this.type)}$.isPointLightShadow!==!0&&this.type===si&&R($,it),$.needsUpdate=!1}f=this.type,g.needsUpdate=!1,i.setRenderTarget(w,A,X)};function R(N,I){let it=t.update(M);m.defines.VSM_SAMPLES!==N.blurSamples&&(m.defines.VSM_SAMPLES=N.blurSamples,x.defines.VSM_SAMPLES=N.blurSamples,m.needsUpdate=!0,x.needsUpdate=!0),N.mapPass===null&&(N.mapPass=new je(s.x,s.y)),m.uniforms.shadow_pass.value=N.map.texture,m.uniforms.resolution.value=N.mapSize,m.uniforms.radius.value=N.radius,i.setRenderTarget(N.mapPass),i.clear(),i.renderBufferDirect(I,null,it,m,M,null),x.uniforms.shadow_pass.value=N.mapPass.texture,x.uniforms.resolution.value=N.mapSize,x.uniforms.radius.value=N.radius,i.setRenderTarget(N.map),i.clear(),i.renderBufferDirect(I,null,it,x,M,null)}function E(N,I,it,w){let A=null,X=it.isPointLight===!0?N.customDistanceMaterial:N.customDepthMaterial;if(X!==void 0)A=X;else if(A=it.isPointLight===!0?l:a,i.localClippingEnabled&&I.clipShadows===!0&&Array.isArray(I.clippingPlanes)&&I.clippingPlanes.length!==0||I.displacementMap&&I.displacementScale!==0||I.alphaMap&&I.alphaTest>0||I.map&&I.alphaTest>0){let tt=A.uuid,at=I.uuid,F=h[tt];F===void 0&&(F={},h[tt]=F);let V=F[at];V===void 0&&(V=A.clone(),F[at]=V,I.addEventListener("dispose",z)),A=V}if(A.visible=I.visible,A.wireframe=I.wireframe,w===si?A.side=I.shadowSide!==null?I.shadowSide:I.side:A.side=I.shadowSide!==null?I.shadowSide:d[I.side],A.alphaMap=I.alphaMap,A.alphaTest=I.alphaTest,A.map=I.map,A.clipShadows=I.clipShadows,A.clippingPlanes=I.clippingPlanes,A.clipIntersection=I.clipIntersection,A.displacementMap=I.displacementMap,A.displacementScale=I.displacementScale,A.displacementBias=I.displacementBias,A.wireframeLinewidth=I.wireframeLinewidth,A.linewidth=I.linewidth,it.isPointLight===!0&&A.isMeshDistanceMaterial===!0){let tt=i.properties.get(A);tt.light=it}return A}function L(N,I,it,w,A){if(N.visible===!1)return;if(N.layers.test(I.layers)&&(N.isMesh||N.isLine||N.isPoints)&&(N.castShadow||N.receiveShadow&&A===si)&&(!N.frustumCulled||n.intersectsObject(N))){N.modelViewMatrix.multiplyMatrices(it.matrixWorldInverse,N.matrixWorld);let at=t.update(N),F=N.material;if(Array.isArray(F)){let V=at.groups;for(let Z=0,k=V.length;Z<k;Z++){let $=V[Z],K=F[$.materialIndex];if(K&&K.visible){let et=E(N,K,w,A);N.onBeforeShadow(i,N,I,it,at,et,$),i.renderBufferDirect(it,null,at,et,N,$),N.onAfterShadow(i,N,I,it,at,et,$)}}}else if(F.visible){let V=E(N,F,w,A);N.onBeforeShadow(i,N,I,it,at,V,null),i.renderBufferDirect(it,null,at,V,N,null),N.onAfterShadow(i,N,I,it,at,V,null)}}let tt=N.children;for(let at=0,F=tt.length;at<F;at++)L(tt[at],I,it,w,A)}function z(N){N.target.removeEventListener("dispose",z);for(let it in h){let w=h[it],A=N.target.uuid;A in w&&(w[A].dispose(),delete w[A])}}}function I0(i,t,e){let n=e.isWebGL2;function s(){let U=!1,ft=new Se,xt=null,Pt=new Se(0,0,0,0);return{setMask:function(Ot){xt!==Ot&&!U&&(i.colorMask(Ot,Ot,Ot,Ot),xt=Ot)},setLocked:function(Ot){U=Ot},setClear:function(Ot,le,he,we,Ce){Ce===!0&&(Ot*=we,le*=we,he*=we),ft.set(Ot,le,he,we),Pt.equals(ft)===!1&&(i.clearColor(Ot,le,he,we),Pt.copy(ft))},reset:function(){U=!1,xt=null,Pt.set(-1,0,0,0)}}}function r(){let U=!1,ft=null,xt=null,Pt=null;return{setTest:function(Ot){Ot?Ht(i.DEPTH_TEST):Bt(i.DEPTH_TEST)},setMask:function(Ot){ft!==Ot&&!U&&(i.depthMask(Ot),ft=Ot)},setFunc:function(Ot){if(xt!==Ot){switch(Ot){case id:i.depthFunc(i.NEVER);break;case sd:i.depthFunc(i.ALWAYS);break;case rd:i.depthFunc(i.LESS);break;case la:i.depthFunc(i.LEQUAL);break;case ad:i.depthFunc(i.EQUAL);break;case od:i.depthFunc(i.GEQUAL);break;case ld:i.depthFunc(i.GREATER);break;case cd:i.depthFunc(i.NOTEQUAL);break;default:i.depthFunc(i.LEQUAL)}xt=Ot}},setLocked:function(Ot){U=Ot},setClear:function(Ot){Pt!==Ot&&(i.clearDepth(Ot),Pt=Ot)},reset:function(){U=!1,ft=null,xt=null,Pt=null}}}function o(){let U=!1,ft=null,xt=null,Pt=null,Ot=null,le=null,he=null,we=null,Ce=null;return{setTest:function(de){U||(de?Ht(i.STENCIL_TEST):Bt(i.STENCIL_TEST))},setMask:function(de){ft!==de&&!U&&(i.stencilMask(de),ft=de)},setFunc:function(de,Le,$e){(xt!==de||Pt!==Le||Ot!==$e)&&(i.stencilFunc(de,Le,$e),xt=de,Pt=Le,Ot=$e)},setOp:function(de,Le,$e){(le!==de||he!==Le||we!==$e)&&(i.stencilOp(de,Le,$e),le=de,he=Le,we=$e)},setLocked:function(de){U=de},setClear:function(de){Ce!==de&&(i.clearStencil(de),Ce=de)},reset:function(){U=!1,ft=null,xt=null,Pt=null,Ot=null,le=null,he=null,we=null,Ce=null}}}let a=new s,l=new r,h=new o,u=new WeakMap,d=new WeakMap,m={},x={},v=new WeakMap,M=[],g=null,f=!1,R=null,E=null,L=null,z=null,N=null,I=null,it=null,w=new Xt(0,0,0),A=0,X=!1,tt=null,at=null,F=null,V=null,Z=null,k=i.getParameter(i.MAX_COMBINED_TEXTURE_IMAGE_UNITS),$=!1,K=0,et=i.getParameter(i.VERSION);et.indexOf("WebGL")!==-1?(K=parseFloat(/^WebGL (\d)/.exec(et)[1]),$=K>=1):et.indexOf("OpenGL ES")!==-1&&(K=parseFloat(/^OpenGL ES (\d)/.exec(et)[1]),$=K>=2);let rt=null,vt={},G=i.getParameter(i.SCISSOR_BOX),nt=i.getParameter(i.VIEWPORT),mt=new Se().fromArray(G),Tt=new Se().fromArray(nt);function It(U,ft,xt,Pt){let Ot=new Uint8Array(4),le=i.createTexture();i.bindTexture(U,le),i.texParameteri(U,i.TEXTURE_MIN_FILTER,i.NEAREST),i.texParameteri(U,i.TEXTURE_MAG_FILTER,i.NEAREST);for(let he=0;he<xt;he++)n&&(U===i.TEXTURE_3D||U===i.TEXTURE_2D_ARRAY)?i.texImage3D(ft,0,i.RGBA,1,1,Pt,0,i.RGBA,i.UNSIGNED_BYTE,Ot):i.texImage2D(ft+he,0,i.RGBA,1,1,0,i.RGBA,i.UNSIGNED_BYTE,Ot);return le}let Wt={};Wt[i.TEXTURE_2D]=It(i.TEXTURE_2D,i.TEXTURE_2D,1),Wt[i.TEXTURE_CUBE_MAP]=It(i.TEXTURE_CUBE_MAP,i.TEXTURE_CUBE_MAP_POSITIVE_X,6),n&&(Wt[i.TEXTURE_2D_ARRAY]=It(i.TEXTURE_2D_ARRAY,i.TEXTURE_2D_ARRAY,1,1),Wt[i.TEXTURE_3D]=It(i.TEXTURE_3D,i.TEXTURE_3D,1,1)),a.setClear(0,0,0,1),l.setClear(1),h.setClear(0),Ht(i.DEPTH_TEST),l.setFunc(la),Yt(!1),C(pc),Ht(i.CULL_FACE),Rt(Zn);function Ht(U){m[U]!==!0&&(i.enable(U),m[U]=!0)}function Bt(U){m[U]!==!1&&(i.disable(U),m[U]=!1)}function ee(U,ft){return x[U]!==ft?(i.bindFramebuffer(U,ft),x[U]=ft,n&&(U===i.DRAW_FRAMEBUFFER&&(x[i.FRAMEBUFFER]=ft),U===i.FRAMEBUFFER&&(x[i.DRAW_FRAMEBUFFER]=ft)),!0):!1}function q(U,ft){let xt=M,Pt=!1;if(U)if(xt=v.get(ft),xt===void 0&&(xt=[],v.set(ft,xt)),U.isWebGLMultipleRenderTargets){let Ot=U.texture;if(xt.length!==Ot.length||xt[0]!==i.COLOR_ATTACHMENT0){for(let le=0,he=Ot.length;le<he;le++)xt[le]=i.COLOR_ATTACHMENT0+le;xt.length=Ot.length,Pt=!0}}else xt[0]!==i.COLOR_ATTACHMENT0&&(xt[0]=i.COLOR_ATTACHMENT0,Pt=!0);else xt[0]!==i.BACK&&(xt[0]=i.BACK,Pt=!0);Pt&&(e.isWebGL2?i.drawBuffers(xt):t.get("WEBGL_draw_buffers").drawBuffersWEBGL(xt))}function Pe(U){return g!==U?(i.useProgram(U),g=U,!0):!1}let Ft={[ri]:i.FUNC_ADD,[Wu]:i.FUNC_SUBTRACT,[Xu]:i.FUNC_REVERSE_SUBTRACT};if(n)Ft[xc]=i.MIN,Ft[_c]=i.MAX;else{let U=t.get("EXT_blend_minmax");U!==null&&(Ft[xc]=U.MIN_EXT,Ft[_c]=U.MAX_EXT)}let Vt={[Pl]:i.ZERO,[ka]:i.ONE,[Yu]:i.SRC_COLOR,[pr]:i.SRC_ALPHA,[Ku]:i.SRC_ALPHA_SATURATE,[ju]:i.DST_COLOR,[Zu]:i.DST_ALPHA,[qu]:i.ONE_MINUS_SRC_COLOR,[qo]:i.ONE_MINUS_SRC_ALPHA,[$u]:i.ONE_MINUS_DST_COLOR,[Ju]:i.ONE_MINUS_DST_ALPHA,[Qu]:i.CONSTANT_COLOR,[td]:i.ONE_MINUS_CONSTANT_COLOR,[ed]:i.CONSTANT_ALPHA,[nd]:i.ONE_MINUS_CONSTANT_ALPHA};function Rt(U,ft,xt,Pt,Ot,le,he,we,Ce,de){if(U===Zn){f===!0&&(Bt(i.BLEND),f=!1);return}if(f===!1&&(Ht(i.BLEND),f=!0),U!==Rl){if(U!==R||de!==X){if((E!==ri||N!==ri)&&(i.blendEquation(i.FUNC_ADD),E=ri,N=ri),de)switch(U){case oi:i.blendFuncSeparate(i.ONE,i.ONE_MINUS_SRC_ALPHA,i.ONE,i.ONE_MINUS_SRC_ALPHA);break;case Ds:i.blendFunc(i.ONE,i.ONE);break;case mc:i.blendFuncSeparate(i.ZERO,i.ONE_MINUS_SRC_COLOR,i.ZERO,i.ONE);break;case gc:i.blendFuncSeparate(i.ZERO,i.SRC_COLOR,i.ZERO,i.SRC_ALPHA);break;default:console.error("THREE.WebGLState: Invalid blending: ",U);break}else switch(U){case oi:i.blendFuncSeparate(i.SRC_ALPHA,i.ONE_MINUS_SRC_ALPHA,i.ONE,i.ONE_MINUS_SRC_ALPHA);break;case Ds:i.blendFunc(i.SRC_ALPHA,i.ONE);break;case mc:i.blendFuncSeparate(i.ZERO,i.ONE_MINUS_SRC_COLOR,i.ZERO,i.ONE);break;case gc:i.blendFunc(i.ZERO,i.SRC_COLOR);break;default:console.error("THREE.WebGLState: Invalid blending: ",U);break}L=null,z=null,I=null,it=null,w.set(0,0,0),A=0,R=U,X=de}return}Ot=Ot||ft,le=le||xt,he=he||Pt,(ft!==E||Ot!==N)&&(i.blendEquationSeparate(Ft[ft],Ft[Ot]),E=ft,N=Ot),(xt!==L||Pt!==z||le!==I||he!==it)&&(i.blendFuncSeparate(Vt[xt],Vt[Pt],Vt[le],Vt[he]),L=xt,z=Pt,I=le,it=he),(we.equals(w)===!1||Ce!==A)&&(i.blendColor(we.r,we.g,we.b,Ce),w.copy(we),A=Ce),R=U,X=!1}function pe(U,ft){U.side===Un?Bt(i.CULL_FACE):Ht(i.CULL_FACE);let xt=U.side===pn;ft&&(xt=!xt),Yt(xt),U.blending===oi&&U.transparent===!1?Rt(Zn):Rt(U.blending,U.blendEquation,U.blendSrc,U.blendDst,U.blendEquationAlpha,U.blendSrcAlpha,U.blendDstAlpha,U.blendColor,U.blendAlpha,U.premultipliedAlpha),l.setFunc(U.depthFunc),l.setTest(U.depthTest),l.setMask(U.depthWrite),a.setMask(U.colorWrite);let Pt=U.stencilWrite;h.setTest(Pt),Pt&&(h.setMask(U.stencilWriteMask),h.setFunc(U.stencilFunc,U.stencilRef,U.stencilFuncMask),h.setOp(U.stencilFail,U.stencilZFail,U.stencilZPass)),Y(U.polygonOffset,U.polygonOffsetFactor,U.polygonOffsetUnits),U.alphaToCoverage===!0?Ht(i.SAMPLE_ALPHA_TO_COVERAGE):Bt(i.SAMPLE_ALPHA_TO_COVERAGE)}function Yt(U){tt!==U&&(U?i.frontFace(i.CW):i.frontFace(i.CCW),tt=U)}function C(U){U!==Vu?(Ht(i.CULL_FACE),U!==at&&(U===pc?i.cullFace(i.BACK):U===Gu?i.cullFace(i.FRONT):i.cullFace(i.FRONT_AND_BACK))):Bt(i.CULL_FACE),at=U}function b(U){U!==F&&($&&i.lineWidth(U),F=U)}function Y(U,ft,xt){U?(Ht(i.POLYGON_OFFSET_FILL),(V!==ft||Z!==xt)&&(i.polygonOffset(ft,xt),V=ft,Z=xt)):Bt(i.POLYGON_OFFSET_FILL)}function Q(U){U?Ht(i.SCISSOR_TEST):Bt(i.SCISSOR_TEST)}function ot(U){U===void 0&&(U=i.TEXTURE0+k-1),rt!==U&&(i.activeTexture(U),rt=U)}function ct(U,ft,xt){xt===void 0&&(rt===null?xt=i.TEXTURE0+k-1:xt=rt);let Pt=vt[xt];Pt===void 0&&(Pt={type:void 0,texture:void 0},vt[xt]=Pt),(Pt.type!==U||Pt.texture!==ft)&&(rt!==xt&&(i.activeTexture(xt),rt=xt),i.bindTexture(U,ft||Wt[U]),Pt.type=U,Pt.texture=ft)}function Lt(){let U=vt[rt];U!==void 0&&U.type!==void 0&&(i.bindTexture(U.type,null),U.type=void 0,U.texture=void 0)}function St(){try{i.compressedTexImage2D.apply(i,arguments)}catch(U){console.error("THREE.WebGLState:",U)}}function yt(){try{i.compressedTexImage3D.apply(i,arguments)}catch(U){console.error("THREE.WebGLState:",U)}}function kt(){try{i.texSubImage2D.apply(i,arguments)}catch(U){console.error("THREE.WebGLState:",U)}}function Gt(){try{i.texSubImage3D.apply(i,arguments)}catch(U){console.error("THREE.WebGLState:",U)}}function ht(){try{i.compressedTexSubImage2D.apply(i,arguments)}catch(U){console.error("THREE.WebGLState:",U)}}function ne(){try{i.compressedTexSubImage3D.apply(i,arguments)}catch(U){console.error("THREE.WebGLState:",U)}}function P(){try{i.texStorage2D.apply(i,arguments)}catch(U){console.error("THREE.WebGLState:",U)}}function lt(){try{i.texStorage3D.apply(i,arguments)}catch(U){console.error("THREE.WebGLState:",U)}}function _t(){try{i.texImage2D.apply(i,arguments)}catch(U){console.error("THREE.WebGLState:",U)}}function dt(){try{i.texImage3D.apply(i,arguments)}catch(U){console.error("THREE.WebGLState:",U)}}function Nt(U){mt.equals(U)===!1&&(i.scissor(U.x,U.y,U.z,U.w),mt.copy(U))}function $t(U){Tt.equals(U)===!1&&(i.viewport(U.x,U.y,U.z,U.w),Tt.copy(U))}function re(U,ft){let xt=d.get(ft);xt===void 0&&(xt=new WeakMap,d.set(ft,xt));let Pt=xt.get(U);Pt===void 0&&(Pt=i.getUniformBlockIndex(ft,U.name),xt.set(U,Pt))}function jt(U,ft){let Pt=d.get(ft).get(U);u.get(ft)!==Pt&&(i.uniformBlockBinding(ft,Pt,U.__bindingPointIndex),u.set(ft,Pt))}function gt(){i.disable(i.BLEND),i.disable(i.CULL_FACE),i.disable(i.DEPTH_TEST),i.disable(i.POLYGON_OFFSET_FILL),i.disable(i.SCISSOR_TEST),i.disable(i.STENCIL_TEST),i.disable(i.SAMPLE_ALPHA_TO_COVERAGE),i.blendEquation(i.FUNC_ADD),i.blendFunc(i.ONE,i.ZERO),i.blendFuncSeparate(i.ONE,i.ZERO,i.ONE,i.ZERO),i.blendColor(0,0,0,0),i.colorMask(!0,!0,!0,!0),i.clearColor(0,0,0,0),i.depthMask(!0),i.depthFunc(i.LESS),i.clearDepth(1),i.stencilMask(4294967295),i.stencilFunc(i.ALWAYS,0,4294967295),i.stencilOp(i.KEEP,i.KEEP,i.KEEP),i.clearStencil(0),i.cullFace(i.BACK),i.frontFace(i.CCW),i.polygonOffset(0,0),i.activeTexture(i.TEXTURE0),i.bindFramebuffer(i.FRAMEBUFFER,null),n===!0&&(i.bindFramebuffer(i.DRAW_FRAMEBUFFER,null),i.bindFramebuffer(i.READ_FRAMEBUFFER,null)),i.useProgram(null),i.lineWidth(1),i.scissor(0,0,i.canvas.width,i.canvas.height),i.viewport(0,0,i.canvas.width,i.canvas.height),m={},rt=null,vt={},x={},v=new WeakMap,M=[],g=null,f=!1,R=null,E=null,L=null,z=null,N=null,I=null,it=null,w=new Xt(0,0,0),A=0,X=!1,tt=null,at=null,F=null,V=null,Z=null,mt.set(0,0,i.canvas.width,i.canvas.height),Tt.set(0,0,i.canvas.width,i.canvas.height),a.reset(),l.reset(),h.reset()}return{buffers:{color:a,depth:l,stencil:h},enable:Ht,disable:Bt,bindFramebuffer:ee,drawBuffers:q,useProgram:Pe,setBlending:Rt,setMaterial:pe,setFlipSided:Yt,setCullFace:C,setLineWidth:b,setPolygonOffset:Y,setScissorTest:Q,activeTexture:ot,bindTexture:ct,unbindTexture:Lt,compressedTexImage2D:St,compressedTexImage3D:yt,texImage2D:_t,texImage3D:dt,updateUBOMapping:re,uniformBlockBinding:jt,texStorage2D:P,texStorage3D:lt,texSubImage2D:kt,texSubImage3D:Gt,compressedTexSubImage2D:ht,compressedTexSubImage3D:ne,scissor:Nt,viewport:$t,reset:gt}}function D0(i,t,e,n,s,r,o){let a=s.isWebGL2,l=t.has("WEBGL_multisampled_render_to_texture")?t.get("WEBGL_multisampled_render_to_texture"):null,h=typeof navigator>"u"?!1:/OculusBrowser/g.test(navigator.userAgent),u=new WeakMap,d,m=new WeakMap,x=!1;try{x=typeof OffscreenCanvas<"u"&&new OffscreenCanvas(1,1).getContext("2d")!==null}catch{}function v(C,b){return x?new OffscreenCanvas(C,b):ga("canvas")}function M(C,b,Y,Q){let ot=1;if((C.width>Q||C.height>Q)&&(ot=Q/Math.max(C.width,C.height)),ot<1||b===!0)if(typeof HTMLImageElement<"u"&&C instanceof HTMLImageElement||typeof HTMLCanvasElement<"u"&&C instanceof HTMLCanvasElement||typeof ImageBitmap<"u"&&C instanceof ImageBitmap){let ct=b?ma:Math.floor,Lt=ct(ot*C.width),St=ct(ot*C.height);d===void 0&&(d=v(Lt,St));let yt=Y?v(Lt,St):d;return yt.width=Lt,yt.height=St,yt.getContext("2d").drawImage(C,0,0,Lt,St),console.warn("THREE.WebGLRenderer: Texture has been resized from ("+C.width+"x"+C.height+") to ("+Lt+"x"+St+")."),yt}else return"data"in C&&console.warn("THREE.WebGLRenderer: Image in DataTexture is too big ("+C.width+"x"+C.height+")."),C;return C}function g(C){return Ko(C.width)&&Ko(C.height)}function f(C){return a?!1:C.wrapS!==Nn||C.wrapT!==Nn||C.minFilter!==Ye&&C.minFilter!==Mn}function R(C,b){return C.generateMipmaps&&b&&C.minFilter!==Ye&&C.minFilter!==Mn}function E(C){i.generateMipmap(C)}function L(C,b,Y,Q,ot=!1){if(a===!1)return b;if(C!==null){if(i[C]!==void 0)return i[C];console.warn("THREE.WebGLRenderer: Attempt to use non-existing WebGL internal format '"+C+"'")}let ct=b;if(b===i.RED&&(Y===i.FLOAT&&(ct=i.R32F),Y===i.HALF_FLOAT&&(ct=i.R16F),Y===i.UNSIGNED_BYTE&&(ct=i.R8)),b===i.RED_INTEGER&&(Y===i.UNSIGNED_BYTE&&(ct=i.R8UI),Y===i.UNSIGNED_SHORT&&(ct=i.R16UI),Y===i.UNSIGNED_INT&&(ct=i.R32UI),Y===i.BYTE&&(ct=i.R8I),Y===i.SHORT&&(ct=i.R16I),Y===i.INT&&(ct=i.R32I)),b===i.RG&&(Y===i.FLOAT&&(ct=i.RG32F),Y===i.HALF_FLOAT&&(ct=i.RG16F),Y===i.UNSIGNED_BYTE&&(ct=i.RG8)),b===i.RGBA){let Lt=ot?ua:fe.getTransfer(Q);Y===i.FLOAT&&(ct=i.RGBA32F),Y===i.HALF_FLOAT&&(ct=i.RGBA16F),Y===i.UNSIGNED_BYTE&&(ct=Lt===me?i.SRGB8_ALPHA8:i.RGBA8),Y===i.UNSIGNED_SHORT_4_4_4_4&&(ct=i.RGBA4),Y===i.UNSIGNED_SHORT_5_5_5_1&&(ct=i.RGB5_A1)}return(ct===i.R16F||ct===i.R32F||ct===i.RG16F||ct===i.RG32F||ct===i.RGBA16F||ct===i.RGBA32F)&&t.get("EXT_color_buffer_float"),ct}function z(C,b,Y){return R(C,Y)===!0||C.isFramebufferTexture&&C.minFilter!==Ye&&C.minFilter!==Mn?Math.log2(Math.max(b.width,b.height))+1:C.mipmaps!==void 0&&C.mipmaps.length>0?C.mipmaps.length:C.isCompressedTexture&&Array.isArray(C.image)?b.mipmaps.length:1}function N(C){return C===Ye||C===vc||C===go?i.NEAREST:i.LINEAR}function I(C){let b=C.target;b.removeEventListener("dispose",I),w(b),b.isVideoTexture&&u.delete(b)}function it(C){let b=C.target;b.removeEventListener("dispose",it),X(b)}function w(C){let b=n.get(C);if(b.__webglInit===void 0)return;let Y=C.source,Q=m.get(Y);if(Q){let ot=Q[b.__cacheKey];ot.usedTimes--,ot.usedTimes===0&&A(C),Object.keys(Q).length===0&&m.delete(Y)}n.remove(C)}function A(C){let b=n.get(C);i.deleteTexture(b.__webglTexture);let Y=C.source,Q=m.get(Y);delete Q[b.__cacheKey],o.memory.textures--}function X(C){let b=C.texture,Y=n.get(C),Q=n.get(b);if(Q.__webglTexture!==void 0&&(i.deleteTexture(Q.__webglTexture),o.memory.textures--),C.depthTexture&&C.depthTexture.dispose(),C.isWebGLCubeRenderTarget)for(let ot=0;ot<6;ot++){if(Array.isArray(Y.__webglFramebuffer[ot]))for(let ct=0;ct<Y.__webglFramebuffer[ot].length;ct++)i.deleteFramebuffer(Y.__webglFramebuffer[ot][ct]);else i.deleteFramebuffer(Y.__webglFramebuffer[ot]);Y.__webglDepthbuffer&&i.deleteRenderbuffer(Y.__webglDepthbuffer[ot])}else{if(Array.isArray(Y.__webglFramebuffer))for(let ot=0;ot<Y.__webglFramebuffer.length;ot++)i.deleteFramebuffer(Y.__webglFramebuffer[ot]);else i.deleteFramebuffer(Y.__webglFramebuffer);if(Y.__webglDepthbuffer&&i.deleteRenderbuffer(Y.__webglDepthbuffer),Y.__webglMultisampledFramebuffer&&i.deleteFramebuffer(Y.__webglMultisampledFramebuffer),Y.__webglColorRenderbuffer)for(let ot=0;ot<Y.__webglColorRenderbuffer.length;ot++)Y.__webglColorRenderbuffer[ot]&&i.deleteRenderbuffer(Y.__webglColorRenderbuffer[ot]);Y.__webglDepthRenderbuffer&&i.deleteRenderbuffer(Y.__webglDepthRenderbuffer)}if(C.isWebGLMultipleRenderTargets)for(let ot=0,ct=b.length;ot<ct;ot++){let Lt=n.get(b[ot]);Lt.__webglTexture&&(i.deleteTexture(Lt.__webglTexture),o.memory.textures--),n.remove(b[ot])}n.remove(b),n.remove(C)}let tt=0;function at(){tt=0}function F(){let C=tt;return C>=s.maxTextures&&console.warn("THREE.WebGLTextures: Trying to use "+C+" texture units while this GPU supports only "+s.maxTextures),tt+=1,C}function V(C){let b=[];return b.push(C.wrapS),b.push(C.wrapT),b.push(C.wrapR||0),b.push(C.magFilter),b.push(C.minFilter),b.push(C.anisotropy),b.push(C.internalFormat),b.push(C.format),b.push(C.type),b.push(C.generateMipmaps),b.push(C.premultiplyAlpha),b.push(C.flipY),b.push(C.unpackAlignment),b.push(C.colorSpace),b.join()}function Z(C,b){let Y=n.get(C);if(C.isVideoTexture&&pe(C),C.isRenderTargetTexture===!1&&C.version>0&&Y.__version!==C.version){let Q=C.image;if(Q===null)console.warn("THREE.WebGLRenderer: Texture marked for update but no image data found.");else if(Q.complete===!1)console.warn("THREE.WebGLRenderer: Texture marked for update but image is incomplete");else{mt(Y,C,b);return}}e.bindTexture(i.TEXTURE_2D,Y.__webglTexture,i.TEXTURE0+b)}function k(C,b){let Y=n.get(C);if(C.version>0&&Y.__version!==C.version){mt(Y,C,b);return}e.bindTexture(i.TEXTURE_2D_ARRAY,Y.__webglTexture,i.TEXTURE0+b)}function $(C,b){let Y=n.get(C);if(C.version>0&&Y.__version!==C.version){mt(Y,C,b);return}e.bindTexture(i.TEXTURE_3D,Y.__webglTexture,i.TEXTURE0+b)}function K(C,b){let Y=n.get(C);if(C.version>0&&Y.__version!==C.version){Tt(Y,C,b);return}e.bindTexture(i.TEXTURE_CUBE_MAP,Y.__webglTexture,i.TEXTURE0+b)}let et={[mr]:i.REPEAT,[Nn]:i.CLAMP_TO_EDGE,[jo]:i.MIRRORED_REPEAT},rt={[Ye]:i.NEAREST,[vc]:i.NEAREST_MIPMAP_NEAREST,[go]:i.NEAREST_MIPMAP_LINEAR,[Mn]:i.LINEAR,[fd]:i.LINEAR_MIPMAP_NEAREST,[Yi]:i.LINEAR_MIPMAP_LINEAR},vt={[Ed]:i.NEVER,[Ld]:i.ALWAYS,[Td]:i.LESS,[nu]:i.LEQUAL,[Ad]:i.EQUAL,[Pd]:i.GEQUAL,[Cd]:i.GREATER,[Rd]:i.NOTEQUAL};function G(C,b,Y){if(Y?(i.texParameteri(C,i.TEXTURE_WRAP_S,et[b.wrapS]),i.texParameteri(C,i.TEXTURE_WRAP_T,et[b.wrapT]),(C===i.TEXTURE_3D||C===i.TEXTURE_2D_ARRAY)&&i.texParameteri(C,i.TEXTURE_WRAP_R,et[b.wrapR]),i.texParameteri(C,i.TEXTURE_MAG_FILTER,rt[b.magFilter]),i.texParameteri(C,i.TEXTURE_MIN_FILTER,rt[b.minFilter])):(i.texParameteri(C,i.TEXTURE_WRAP_S,i.CLAMP_TO_EDGE),i.texParameteri(C,i.TEXTURE_WRAP_T,i.CLAMP_TO_EDGE),(C===i.TEXTURE_3D||C===i.TEXTURE_2D_ARRAY)&&i.texParameteri(C,i.TEXTURE_WRAP_R,i.CLAMP_TO_EDGE),(b.wrapS!==Nn||b.wrapT!==Nn)&&console.warn("THREE.WebGLRenderer: Texture is not power of two. Texture.wrapS and Texture.wrapT should be set to THREE.ClampToEdgeWrapping."),i.texParameteri(C,i.TEXTURE_MAG_FILTER,N(b.magFilter)),i.texParameteri(C,i.TEXTURE_MIN_FILTER,N(b.minFilter)),b.minFilter!==Ye&&b.minFilter!==Mn&&console.warn("THREE.WebGLRenderer: Texture is not power of two. Texture.minFilter should be set to THREE.NearestFilter or THREE.LinearFilter.")),b.compareFunction&&(i.texParameteri(C,i.TEXTURE_COMPARE_MODE,i.COMPARE_REF_TO_TEXTURE),i.texParameteri(C,i.TEXTURE_COMPARE_FUNC,vt[b.compareFunction])),t.has("EXT_texture_filter_anisotropic")===!0){let Q=t.get("EXT_texture_filter_anisotropic");if(b.magFilter===Ye||b.minFilter!==go&&b.minFilter!==Yi||b.type===Mi&&t.has("OES_texture_float_linear")===!1||a===!1&&b.type===xn&&t.has("OES_texture_half_float_linear")===!1)return;(b.anisotropy>1||n.get(b).__currentAnisotropy)&&(i.texParameterf(C,Q.TEXTURE_MAX_ANISOTROPY_EXT,Math.min(b.anisotropy,s.getMaxAnisotropy())),n.get(b).__currentAnisotropy=b.anisotropy)}}function nt(C,b){let Y=!1;C.__webglInit===void 0&&(C.__webglInit=!0,b.addEventListener("dispose",I));let Q=b.source,ot=m.get(Q);ot===void 0&&(ot={},m.set(Q,ot));let ct=V(b);if(ct!==C.__cacheKey){ot[ct]===void 0&&(ot[ct]={texture:i.createTexture(),usedTimes:0},o.memory.textures++,Y=!0),ot[ct].usedTimes++;let Lt=ot[C.__cacheKey];Lt!==void 0&&(ot[C.__cacheKey].usedTimes--,Lt.usedTimes===0&&A(b)),C.__cacheKey=ct,C.__webglTexture=ot[ct].texture}return Y}function mt(C,b,Y){let Q=i.TEXTURE_2D;(b.isDataArrayTexture||b.isCompressedArrayTexture)&&(Q=i.TEXTURE_2D_ARRAY),b.isData3DTexture&&(Q=i.TEXTURE_3D);let ot=nt(C,b),ct=b.source;e.bindTexture(Q,C.__webglTexture,i.TEXTURE0+Y);let Lt=n.get(ct);if(ct.version!==Lt.__version||ot===!0){e.activeTexture(i.TEXTURE0+Y);let St=fe.getPrimaries(fe.workingColorSpace),yt=b.colorSpace===fn?null:fe.getPrimaries(b.colorSpace),kt=b.colorSpace===fn||St===yt?i.NONE:i.BROWSER_DEFAULT_WEBGL;i.pixelStorei(i.UNPACK_FLIP_Y_WEBGL,b.flipY),i.pixelStorei(i.UNPACK_PREMULTIPLY_ALPHA_WEBGL,b.premultiplyAlpha),i.pixelStorei(i.UNPACK_ALIGNMENT,b.unpackAlignment),i.pixelStorei(i.UNPACK_COLORSPACE_CONVERSION_WEBGL,kt);let Gt=f(b)&&g(b.image)===!1,ht=M(b.image,Gt,!1,s.maxTextureSize);ht=Yt(b,ht);let ne=g(ht)||a,P=r.convert(b.format,b.colorSpace),lt=r.convert(b.type),_t=L(b.internalFormat,P,lt,b.colorSpace,b.isVideoTexture);G(Q,b,ne);let dt,Nt=b.mipmaps,$t=a&&b.isVideoTexture!==!0&&_t!==Qh,re=Lt.__version===void 0||ot===!0,jt=z(b,ht,ne);if(b.isDepthTexture)_t=i.DEPTH_COMPONENT,a?b.type===Mi?_t=i.DEPTH_COMPONENT32F:b.type===bi?_t=i.DEPTH_COMPONENT24:b.type===Gi?_t=i.DEPTH24_STENCIL8:_t=i.DEPTH_COMPONENT16:b.type===Mi&&console.error("WebGLRenderer: Floating point depth texture requires WebGL2."),b.format===Wi&&_t===i.DEPTH_COMPONENT&&b.type!==Nl&&b.type!==bi&&(console.warn("THREE.WebGLRenderer: Use UnsignedShortType or UnsignedIntType for DepthFormat DepthTexture."),b.type=bi,lt=r.convert(b.type)),b.format===Os&&_t===i.DEPTH_COMPONENT&&(_t=i.DEPTH_STENCIL,b.type!==Gi&&(console.warn("THREE.WebGLRenderer: Use UnsignedInt248Type for DepthStencilFormat DepthTexture."),b.type=Gi,lt=r.convert(b.type))),re&&($t?e.texStorage2D(i.TEXTURE_2D,1,_t,ht.width,ht.height):e.texImage2D(i.TEXTURE_2D,0,_t,ht.width,ht.height,0,P,lt,null));else if(b.isDataTexture)if(Nt.length>0&&ne){$t&&re&&e.texStorage2D(i.TEXTURE_2D,jt,_t,Nt[0].width,Nt[0].height);for(let gt=0,U=Nt.length;gt<U;gt++)dt=Nt[gt],$t?e.texSubImage2D(i.TEXTURE_2D,gt,0,0,dt.width,dt.height,P,lt,dt.data):e.texImage2D(i.TEXTURE_2D,gt,_t,dt.width,dt.height,0,P,lt,dt.data);b.generateMipmaps=!1}else $t?(re&&e.texStorage2D(i.TEXTURE_2D,jt,_t,ht.width,ht.height),e.texSubImage2D(i.TEXTURE_2D,0,0,0,ht.width,ht.height,P,lt,ht.data)):e.texImage2D(i.TEXTURE_2D,0,_t,ht.width,ht.height,0,P,lt,ht.data);else if(b.isCompressedTexture)if(b.isCompressedArrayTexture){$t&&re&&e.texStorage3D(i.TEXTURE_2D_ARRAY,jt,_t,Nt[0].width,Nt[0].height,ht.depth);for(let gt=0,U=Nt.length;gt<U;gt++)dt=Nt[gt],b.format!==On?P!==null?$t?e.compressedTexSubImage3D(i.TEXTURE_2D_ARRAY,gt,0,0,0,dt.width,dt.height,ht.depth,P,dt.data,0,0):e.compressedTexImage3D(i.TEXTURE_2D_ARRAY,gt,_t,dt.width,dt.height,ht.depth,0,dt.data,0,0):console.warn("THREE.WebGLRenderer: Attempt to load unsupported compressed texture format in .uploadTexture()"):$t?e.texSubImage3D(i.TEXTURE_2D_ARRAY,gt,0,0,0,dt.width,dt.height,ht.depth,P,lt,dt.data):e.texImage3D(i.TEXTURE_2D_ARRAY,gt,_t,dt.width,dt.height,ht.depth,0,P,lt,dt.data)}else{$t&&re&&e.texStorage2D(i.TEXTURE_2D,jt,_t,Nt[0].width,Nt[0].height);for(let gt=0,U=Nt.length;gt<U;gt++)dt=Nt[gt],b.format!==On?P!==null?$t?e.compressedTexSubImage2D(i.TEXTURE_2D,gt,0,0,dt.width,dt.height,P,dt.data):e.compressedTexImage2D(i.TEXTURE_2D,gt,_t,dt.width,dt.height,0,dt.data):console.warn("THREE.WebGLRenderer: Attempt to load unsupported compressed texture format in .uploadTexture()"):$t?e.texSubImage2D(i.TEXTURE_2D,gt,0,0,dt.width,dt.height,P,lt,dt.data):e.texImage2D(i.TEXTURE_2D,gt,_t,dt.width,dt.height,0,P,lt,dt.data)}else if(b.isDataArrayTexture)$t?(re&&e.texStorage3D(i.TEXTURE_2D_ARRAY,jt,_t,ht.width,ht.height,ht.depth),e.texSubImage3D(i.TEXTURE_2D_ARRAY,0,0,0,0,ht.width,ht.height,ht.depth,P,lt,ht.data)):e.texImage3D(i.TEXTURE_2D_ARRAY,0,_t,ht.width,ht.height,ht.depth,0,P,lt,ht.data);else if(b.isData3DTexture)$t?(re&&e.texStorage3D(i.TEXTURE_3D,jt,_t,ht.width,ht.height,ht.depth),e.texSubImage3D(i.TEXTURE_3D,0,0,0,0,ht.width,ht.height,ht.depth,P,lt,ht.data)):e.texImage3D(i.TEXTURE_3D,0,_t,ht.width,ht.height,ht.depth,0,P,lt,ht.data);else if(b.isFramebufferTexture){if(re)if($t)e.texStorage2D(i.TEXTURE_2D,jt,_t,ht.width,ht.height);else{let gt=ht.width,U=ht.height;for(let ft=0;ft<jt;ft++)e.texImage2D(i.TEXTURE_2D,ft,_t,gt,U,0,P,lt,null),gt>>=1,U>>=1}}else if(Nt.length>0&&ne){$t&&re&&e.texStorage2D(i.TEXTURE_2D,jt,_t,Nt[0].width,Nt[0].height);for(let gt=0,U=Nt.length;gt<U;gt++)dt=Nt[gt],$t?e.texSubImage2D(i.TEXTURE_2D,gt,0,0,P,lt,dt):e.texImage2D(i.TEXTURE_2D,gt,_t,P,lt,dt);b.generateMipmaps=!1}else $t?(re&&e.texStorage2D(i.TEXTURE_2D,jt,_t,ht.width,ht.height),e.texSubImage2D(i.TEXTURE_2D,0,0,0,P,lt,ht)):e.texImage2D(i.TEXTURE_2D,0,_t,P,lt,ht);R(b,ne)&&E(Q),Lt.__version=ct.version,b.onUpdate&&b.onUpdate(b)}C.__version=b.version}function Tt(C,b,Y){if(b.image.length!==6)return;let Q=nt(C,b),ot=b.source;e.bindTexture(i.TEXTURE_CUBE_MAP,C.__webglTexture,i.TEXTURE0+Y);let ct=n.get(ot);if(ot.version!==ct.__version||Q===!0){e.activeTexture(i.TEXTURE0+Y);let Lt=fe.getPrimaries(fe.workingColorSpace),St=b.colorSpace===fn?null:fe.getPrimaries(b.colorSpace),yt=b.colorSpace===fn||Lt===St?i.NONE:i.BROWSER_DEFAULT_WEBGL;i.pixelStorei(i.UNPACK_FLIP_Y_WEBGL,b.flipY),i.pixelStorei(i.UNPACK_PREMULTIPLY_ALPHA_WEBGL,b.premultiplyAlpha),i.pixelStorei(i.UNPACK_ALIGNMENT,b.unpackAlignment),i.pixelStorei(i.UNPACK_COLORSPACE_CONVERSION_WEBGL,yt);let kt=b.isCompressedTexture||b.image[0].isCompressedTexture,Gt=b.image[0]&&b.image[0].isDataTexture,ht=[];for(let gt=0;gt<6;gt++)!kt&&!Gt?ht[gt]=M(b.image[gt],!1,!0,s.maxCubemapSize):ht[gt]=Gt?b.image[gt].image:b.image[gt],ht[gt]=Yt(b,ht[gt]);let ne=ht[0],P=g(ne)||a,lt=r.convert(b.format,b.colorSpace),_t=r.convert(b.type),dt=L(b.internalFormat,lt,_t,b.colorSpace),Nt=a&&b.isVideoTexture!==!0,$t=ct.__version===void 0||Q===!0,re=z(b,ne,P);G(i.TEXTURE_CUBE_MAP,b,P);let jt;if(kt){Nt&&$t&&e.texStorage2D(i.TEXTURE_CUBE_MAP,re,dt,ne.width,ne.height);for(let gt=0;gt<6;gt++){jt=ht[gt].mipmaps;for(let U=0;U<jt.length;U++){let ft=jt[U];b.format!==On?lt!==null?Nt?e.compressedTexSubImage2D(i.TEXTURE_CUBE_MAP_POSITIVE_X+gt,U,0,0,ft.width,ft.height,lt,ft.data):e.compressedTexImage2D(i.TEXTURE_CUBE_MAP_POSITIVE_X+gt,U,dt,ft.width,ft.height,0,ft.data):console.warn("THREE.WebGLRenderer: Attempt to load unsupported compressed texture format in .setTextureCube()"):Nt?e.texSubImage2D(i.TEXTURE_CUBE_MAP_POSITIVE_X+gt,U,0,0,ft.width,ft.height,lt,_t,ft.data):e.texImage2D(i.TEXTURE_CUBE_MAP_POSITIVE_X+gt,U,dt,ft.width,ft.height,0,lt,_t,ft.data)}}}else{jt=b.mipmaps,Nt&&$t&&(jt.length>0&&re++,e.texStorage2D(i.TEXTURE_CUBE_MAP,re,dt,ht[0].width,ht[0].height));for(let gt=0;gt<6;gt++)if(Gt){Nt?e.texSubImage2D(i.TEXTURE_CUBE_MAP_POSITIVE_X+gt,0,0,0,ht[gt].width,ht[gt].height,lt,_t,ht[gt].data):e.texImage2D(i.TEXTURE_CUBE_MAP_POSITIVE_X+gt,0,dt,ht[gt].width,ht[gt].height,0,lt,_t,ht[gt].data);for(let U=0;U<jt.length;U++){let xt=jt[U].image[gt].image;Nt?e.texSubImage2D(i.TEXTURE_CUBE_MAP_POSITIVE_X+gt,U+1,0,0,xt.width,xt.height,lt,_t,xt.data):e.texImage2D(i.TEXTURE_CUBE_MAP_POSITIVE_X+gt,U+1,dt,xt.width,xt.height,0,lt,_t,xt.data)}}else{Nt?e.texSubImage2D(i.TEXTURE_CUBE_MAP_POSITIVE_X+gt,0,0,0,lt,_t,ht[gt]):e.texImage2D(i.TEXTURE_CUBE_MAP_POSITIVE_X+gt,0,dt,lt,_t,ht[gt]);for(let U=0;U<jt.length;U++){let ft=jt[U];Nt?e.texSubImage2D(i.TEXTURE_CUBE_MAP_POSITIVE_X+gt,U+1,0,0,lt,_t,ft.image[gt]):e.texImage2D(i.TEXTURE_CUBE_MAP_POSITIVE_X+gt,U+1,dt,lt,_t,ft.image[gt])}}}R(b,P)&&E(i.TEXTURE_CUBE_MAP),ct.__version=ot.version,b.onUpdate&&b.onUpdate(b)}C.__version=b.version}function It(C,b,Y,Q,ot,ct){let Lt=r.convert(Y.format,Y.colorSpace),St=r.convert(Y.type),yt=L(Y.internalFormat,Lt,St,Y.colorSpace);if(!n.get(b).__hasExternalTextures){let Gt=Math.max(1,b.width>>ct),ht=Math.max(1,b.height>>ct);ot===i.TEXTURE_3D||ot===i.TEXTURE_2D_ARRAY?e.texImage3D(ot,ct,yt,Gt,ht,b.depth,0,Lt,St,null):e.texImage2D(ot,ct,yt,Gt,ht,0,Lt,St,null)}e.bindFramebuffer(i.FRAMEBUFFER,C),Rt(b)?l.framebufferTexture2DMultisampleEXT(i.FRAMEBUFFER,Q,ot,n.get(Y).__webglTexture,0,Vt(b)):(ot===i.TEXTURE_2D||ot>=i.TEXTURE_CUBE_MAP_POSITIVE_X&&ot<=i.TEXTURE_CUBE_MAP_NEGATIVE_Z)&&i.framebufferTexture2D(i.FRAMEBUFFER,Q,ot,n.get(Y).__webglTexture,ct),e.bindFramebuffer(i.FRAMEBUFFER,null)}function Wt(C,b,Y){if(i.bindRenderbuffer(i.RENDERBUFFER,C),b.depthBuffer&&!b.stencilBuffer){let Q=a===!0?i.DEPTH_COMPONENT24:i.DEPTH_COMPONENT16;if(Y||Rt(b)){let ot=b.depthTexture;ot&&ot.isDepthTexture&&(ot.type===Mi?Q=i.DEPTH_COMPONENT32F:ot.type===bi&&(Q=i.DEPTH_COMPONENT24));let ct=Vt(b);Rt(b)?l.renderbufferStorageMultisampleEXT(i.RENDERBUFFER,ct,Q,b.width,b.height):i.renderbufferStorageMultisample(i.RENDERBUFFER,ct,Q,b.width,b.height)}else i.renderbufferStorage(i.RENDERBUFFER,Q,b.width,b.height);i.framebufferRenderbuffer(i.FRAMEBUFFER,i.DEPTH_ATTACHMENT,i.RENDERBUFFER,C)}else if(b.depthBuffer&&b.stencilBuffer){let Q=Vt(b);Y&&Rt(b)===!1?i.renderbufferStorageMultisample(i.RENDERBUFFER,Q,i.DEPTH24_STENCIL8,b.width,b.height):Rt(b)?l.renderbufferStorageMultisampleEXT(i.RENDERBUFFER,Q,i.DEPTH24_STENCIL8,b.width,b.height):i.renderbufferStorage(i.RENDERBUFFER,i.DEPTH_STENCIL,b.width,b.height),i.framebufferRenderbuffer(i.FRAMEBUFFER,i.DEPTH_STENCIL_ATTACHMENT,i.RENDERBUFFER,C)}else{let Q=b.isWebGLMultipleRenderTargets===!0?b.texture:[b.texture];for(let ot=0;ot<Q.length;ot++){let ct=Q[ot],Lt=r.convert(ct.format,ct.colorSpace),St=r.convert(ct.type),yt=L(ct.internalFormat,Lt,St,ct.colorSpace),kt=Vt(b);Y&&Rt(b)===!1?i.renderbufferStorageMultisample(i.RENDERBUFFER,kt,yt,b.width,b.height):Rt(b)?l.renderbufferStorageMultisampleEXT(i.RENDERBUFFER,kt,yt,b.width,b.height):i.renderbufferStorage(i.RENDERBUFFER,yt,b.width,b.height)}}i.bindRenderbuffer(i.RENDERBUFFER,null)}function Ht(C,b){if(b&&b.isWebGLCubeRenderTarget)throw new Error("Depth Texture with cube render targets is not supported");if(e.bindFramebuffer(i.FRAMEBUFFER,C),!(b.depthTexture&&b.depthTexture.isDepthTexture))throw new Error("renderTarget.depthTexture must be an instance of THREE.DepthTexture");(!n.get(b.depthTexture).__webglTexture||b.depthTexture.image.width!==b.width||b.depthTexture.image.height!==b.height)&&(b.depthTexture.image.width=b.width,b.depthTexture.image.height=b.height,b.depthTexture.needsUpdate=!0),Z(b.depthTexture,0);let Q=n.get(b.depthTexture).__webglTexture,ot=Vt(b);if(b.depthTexture.format===Wi)Rt(b)?l.framebufferTexture2DMultisampleEXT(i.FRAMEBUFFER,i.DEPTH_ATTACHMENT,i.TEXTURE_2D,Q,0,ot):i.framebufferTexture2D(i.FRAMEBUFFER,i.DEPTH_ATTACHMENT,i.TEXTURE_2D,Q,0);else if(b.depthTexture.format===Os)Rt(b)?l.framebufferTexture2DMultisampleEXT(i.FRAMEBUFFER,i.DEPTH_STENCIL_ATTACHMENT,i.TEXTURE_2D,Q,0,ot):i.framebufferTexture2D(i.FRAMEBUFFER,i.DEPTH_STENCIL_ATTACHMENT,i.TEXTURE_2D,Q,0);else throw new Error("Unknown depthTexture format")}function Bt(C){let b=n.get(C),Y=C.isWebGLCubeRenderTarget===!0;if(C.depthTexture&&!b.__autoAllocateDepthBuffer){if(Y)throw new Error("target.depthTexture not supported in Cube render targets");Ht(b.__webglFramebuffer,C)}else if(Y){b.__webglDepthbuffer=[];for(let Q=0;Q<6;Q++)e.bindFramebuffer(i.FRAMEBUFFER,b.__webglFramebuffer[Q]),b.__webglDepthbuffer[Q]=i.createRenderbuffer(),Wt(b.__webglDepthbuffer[Q],C,!1)}else e.bindFramebuffer(i.FRAMEBUFFER,b.__webglFramebuffer),b.__webglDepthbuffer=i.createRenderbuffer(),Wt(b.__webglDepthbuffer,C,!1);e.bindFramebuffer(i.FRAMEBUFFER,null)}function ee(C,b,Y){let Q=n.get(C);b!==void 0&&It(Q.__webglFramebuffer,C,C.texture,i.COLOR_ATTACHMENT0,i.TEXTURE_2D,0),Y!==void 0&&Bt(C)}function q(C){let b=C.texture,Y=n.get(C),Q=n.get(b);C.addEventListener("dispose",it),C.isWebGLMultipleRenderTargets!==!0&&(Q.__webglTexture===void 0&&(Q.__webglTexture=i.createTexture()),Q.__version=b.version,o.memory.textures++);let ot=C.isWebGLCubeRenderTarget===!0,ct=C.isWebGLMultipleRenderTargets===!0,Lt=g(C)||a;if(ot){Y.__webglFramebuffer=[];for(let St=0;St<6;St++)if(a&&b.mipmaps&&b.mipmaps.length>0){Y.__webglFramebuffer[St]=[];for(let yt=0;yt<b.mipmaps.length;yt++)Y.__webglFramebuffer[St][yt]=i.createFramebuffer()}else Y.__webglFramebuffer[St]=i.createFramebuffer()}else{if(a&&b.mipmaps&&b.mipmaps.length>0){Y.__webglFramebuffer=[];for(let St=0;St<b.mipmaps.length;St++)Y.__webglFramebuffer[St]=i.createFramebuffer()}else Y.__webglFramebuffer=i.createFramebuffer();if(ct)if(s.drawBuffers){let St=C.texture;for(let yt=0,kt=St.length;yt<kt;yt++){let Gt=n.get(St[yt]);Gt.__webglTexture===void 0&&(Gt.__webglTexture=i.createTexture(),o.memory.textures++)}}else console.warn("THREE.WebGLRenderer: WebGLMultipleRenderTargets can only be used with WebGL2 or WEBGL_draw_buffers extension.");if(a&&C.samples>0&&Rt(C)===!1){let St=ct?b:[b];Y.__webglMultisampledFramebuffer=i.createFramebuffer(),Y.__webglColorRenderbuffer=[],e.bindFramebuffer(i.FRAMEBUFFER,Y.__webglMultisampledFramebuffer);for(let yt=0;yt<St.length;yt++){let kt=St[yt];Y.__webglColorRenderbuffer[yt]=i.createRenderbuffer(),i.bindRenderbuffer(i.RENDERBUFFER,Y.__webglColorRenderbuffer[yt]);let Gt=r.convert(kt.format,kt.colorSpace),ht=r.convert(kt.type),ne=L(kt.internalFormat,Gt,ht,kt.colorSpace,C.isXRRenderTarget===!0),P=Vt(C);i.renderbufferStorageMultisample(i.RENDERBUFFER,P,ne,C.width,C.height),i.framebufferRenderbuffer(i.FRAMEBUFFER,i.COLOR_ATTACHMENT0+yt,i.RENDERBUFFER,Y.__webglColorRenderbuffer[yt])}i.bindRenderbuffer(i.RENDERBUFFER,null),C.depthBuffer&&(Y.__webglDepthRenderbuffer=i.createRenderbuffer(),Wt(Y.__webglDepthRenderbuffer,C,!0)),e.bindFramebuffer(i.FRAMEBUFFER,null)}}if(ot){e.bindTexture(i.TEXTURE_CUBE_MAP,Q.__webglTexture),G(i.TEXTURE_CUBE_MAP,b,Lt);for(let St=0;St<6;St++)if(a&&b.mipmaps&&b.mipmaps.length>0)for(let yt=0;yt<b.mipmaps.length;yt++)It(Y.__webglFramebuffer[St][yt],C,b,i.COLOR_ATTACHMENT0,i.TEXTURE_CUBE_MAP_POSITIVE_X+St,yt);else It(Y.__webglFramebuffer[St],C,b,i.COLOR_ATTACHMENT0,i.TEXTURE_CUBE_MAP_POSITIVE_X+St,0);R(b,Lt)&&E(i.TEXTURE_CUBE_MAP),e.unbindTexture()}else if(ct){let St=C.texture;for(let yt=0,kt=St.length;yt<kt;yt++){let Gt=St[yt],ht=n.get(Gt);e.bindTexture(i.TEXTURE_2D,ht.__webglTexture),G(i.TEXTURE_2D,Gt,Lt),It(Y.__webglFramebuffer,C,Gt,i.COLOR_ATTACHMENT0+yt,i.TEXTURE_2D,0),R(Gt,Lt)&&E(i.TEXTURE_2D)}e.unbindTexture()}else{let St=i.TEXTURE_2D;if((C.isWebGL3DRenderTarget||C.isWebGLArrayRenderTarget)&&(a?St=C.isWebGL3DRenderTarget?i.TEXTURE_3D:i.TEXTURE_2D_ARRAY:console.error("THREE.WebGLTextures: THREE.Data3DTexture and THREE.DataArrayTexture only supported with WebGL2.")),e.bindTexture(St,Q.__webglTexture),G(St,b,Lt),a&&b.mipmaps&&b.mipmaps.length>0)for(let yt=0;yt<b.mipmaps.length;yt++)It(Y.__webglFramebuffer[yt],C,b,i.COLOR_ATTACHMENT0,St,yt);else It(Y.__webglFramebuffer,C,b,i.COLOR_ATTACHMENT0,St,0);R(b,Lt)&&E(St),e.unbindTexture()}C.depthBuffer&&Bt(C)}function Pe(C){let b=g(C)||a,Y=C.isWebGLMultipleRenderTargets===!0?C.texture:[C.texture];for(let Q=0,ot=Y.length;Q<ot;Q++){let ct=Y[Q];if(R(ct,b)){let Lt=C.isWebGLCubeRenderTarget?i.TEXTURE_CUBE_MAP:i.TEXTURE_2D,St=n.get(ct).__webglTexture;e.bindTexture(Lt,St),E(Lt),e.unbindTexture()}}}function Ft(C){if(a&&C.samples>0&&Rt(C)===!1){let b=C.isWebGLMultipleRenderTargets?C.texture:[C.texture],Y=C.width,Q=C.height,ot=i.COLOR_BUFFER_BIT,ct=[],Lt=C.stencilBuffer?i.DEPTH_STENCIL_ATTACHMENT:i.DEPTH_ATTACHMENT,St=n.get(C),yt=C.isWebGLMultipleRenderTargets===!0;if(yt)for(let kt=0;kt<b.length;kt++)e.bindFramebuffer(i.FRAMEBUFFER,St.__webglMultisampledFramebuffer),i.framebufferRenderbuffer(i.FRAMEBUFFER,i.COLOR_ATTACHMENT0+kt,i.RENDERBUFFER,null),e.bindFramebuffer(i.FRAMEBUFFER,St.__webglFramebuffer),i.framebufferTexture2D(i.DRAW_FRAMEBUFFER,i.COLOR_ATTACHMENT0+kt,i.TEXTURE_2D,null,0);e.bindFramebuffer(i.READ_FRAMEBUFFER,St.__webglMultisampledFramebuffer),e.bindFramebuffer(i.DRAW_FRAMEBUFFER,St.__webglFramebuffer);for(let kt=0;kt<b.length;kt++){ct.push(i.COLOR_ATTACHMENT0+kt),C.depthBuffer&&ct.push(Lt);let Gt=St.__ignoreDepthValues!==void 0?St.__ignoreDepthValues:!1;if(Gt===!1&&(C.depthBuffer&&(ot|=i.DEPTH_BUFFER_BIT),C.stencilBuffer&&(ot|=i.STENCIL_BUFFER_BIT)),yt&&i.framebufferRenderbuffer(i.READ_FRAMEBUFFER,i.COLOR_ATTACHMENT0,i.RENDERBUFFER,St.__webglColorRenderbuffer[kt]),Gt===!0&&(i.invalidateFramebuffer(i.READ_FRAMEBUFFER,[Lt]),i.invalidateFramebuffer(i.DRAW_FRAMEBUFFER,[Lt])),yt){let ht=n.get(b[kt]).__webglTexture;i.framebufferTexture2D(i.DRAW_FRAMEBUFFER,i.COLOR_ATTACHMENT0,i.TEXTURE_2D,ht,0)}i.blitFramebuffer(0,0,Y,Q,0,0,Y,Q,ot,i.NEAREST),h&&i.invalidateFramebuffer(i.READ_FRAMEBUFFER,ct)}if(e.bindFramebuffer(i.READ_FRAMEBUFFER,null),e.bindFramebuffer(i.DRAW_FRAMEBUFFER,null),yt)for(let kt=0;kt<b.length;kt++){e.bindFramebuffer(i.FRAMEBUFFER,St.__webglMultisampledFramebuffer),i.framebufferRenderbuffer(i.FRAMEBUFFER,i.COLOR_ATTACHMENT0+kt,i.RENDERBUFFER,St.__webglColorRenderbuffer[kt]);let Gt=n.get(b[kt]).__webglTexture;e.bindFramebuffer(i.FRAMEBUFFER,St.__webglFramebuffer),i.framebufferTexture2D(i.DRAW_FRAMEBUFFER,i.COLOR_ATTACHMENT0+kt,i.TEXTURE_2D,Gt,0)}e.bindFramebuffer(i.DRAW_FRAMEBUFFER,St.__webglMultisampledFramebuffer)}}function Vt(C){return Math.min(s.maxSamples,C.samples)}function Rt(C){let b=n.get(C);return a&&C.samples>0&&t.has("WEBGL_multisampled_render_to_texture")===!0&&b.__useRenderToTexture!==!1}function pe(C){let b=o.render.frame;u.get(C)!==b&&(u.set(C,b),C.update())}function Yt(C,b){let Y=C.colorSpace,Q=C.format,ot=C.type;return C.isCompressedTexture===!0||C.isVideoTexture===!0||C.format===$o||Y!==li&&Y!==fn&&(fe.getTransfer(Y)===me?a===!1?t.has("EXT_sRGB")===!0&&Q===On?(C.format=$o,C.minFilter=Mn,C.generateMipmaps=!1):b=xa.sRGBToLinear(b):(Q!==On||ot!==Ei)&&console.warn("THREE.WebGLTextures: sRGB encoded textures have to use RGBAFormat and UnsignedByteType."):console.error("THREE.WebGLTextures: Unsupported texture color space:",Y)),b}this.allocateTextureUnit=F,this.resetTextureUnits=at,this.setTexture2D=Z,this.setTexture2DArray=k,this.setTexture3D=$,this.setTextureCube=K,this.rebindTextures=ee,this.setupRenderTarget=q,this.updateRenderTargetMipmap=Pe,this.updateMultisampleRenderTarget=Ft,this.setupDepthRenderbuffer=Bt,this.setupFrameBufferTexture=It,this.useMultisampledRTT=Rt}function U0(i,t,e){let n=e.isWebGL2;function s(r,o=fn){let a,l=fe.getTransfer(o);if(r===Ei)return i.UNSIGNED_BYTE;if(r===Zh)return i.UNSIGNED_SHORT_4_4_4_4;if(r===Jh)return i.UNSIGNED_SHORT_5_5_5_1;if(r===pd)return i.BYTE;if(r===md)return i.SHORT;if(r===Nl)return i.UNSIGNED_SHORT;if(r===qh)return i.INT;if(r===bi)return i.UNSIGNED_INT;if(r===Mi)return i.FLOAT;if(r===xn)return n?i.HALF_FLOAT:(a=t.get("OES_texture_half_float"),a!==null?a.HALF_FLOAT_OES:null);if(r===gd)return i.ALPHA;if(r===On)return i.RGBA;if(r===xd)return i.LUMINANCE;if(r===_d)return i.LUMINANCE_ALPHA;if(r===Wi)return i.DEPTH_COMPONENT;if(r===Os)return i.DEPTH_STENCIL;if(r===$o)return a=t.get("EXT_sRGB"),a!==null?a.SRGB_ALPHA_EXT:null;if(r===vd)return i.RED;if(r===jh)return i.RED_INTEGER;if(r===yd)return i.RG;if(r===$h)return i.RG_INTEGER;if(r===Kh)return i.RGBA_INTEGER;if(r===xo||r===_o||r===vo||r===yo)if(l===me)if(a=t.get("WEBGL_compressed_texture_s3tc_srgb"),a!==null){if(r===xo)return a.COMPRESSED_SRGB_S3TC_DXT1_EXT;if(r===_o)return a.COMPRESSED_SRGB_ALPHA_S3TC_DXT1_EXT;if(r===vo)return a.COMPRESSED_SRGB_ALPHA_S3TC_DXT3_EXT;if(r===yo)return a.COMPRESSED_SRGB_ALPHA_S3TC_DXT5_EXT}else return null;else if(a=t.get("WEBGL_compressed_texture_s3tc"),a!==null){if(r===xo)return a.COMPRESSED_RGB_S3TC_DXT1_EXT;if(r===_o)return a.COMPRESSED_RGBA_S3TC_DXT1_EXT;if(r===vo)return a.COMPRESSED_RGBA_S3TC_DXT3_EXT;if(r===yo)return a.COMPRESSED_RGBA_S3TC_DXT5_EXT}else return null;if(r===yc||r===bc||r===Mc||r===Sc)if(a=t.get("WEBGL_compressed_texture_pvrtc"),a!==null){if(r===yc)return a.COMPRESSED_RGB_PVRTC_4BPPV1_IMG;if(r===bc)return a.COMPRESSED_RGB_PVRTC_2BPPV1_IMG;if(r===Mc)return a.COMPRESSED_RGBA_PVRTC_4BPPV1_IMG;if(r===Sc)return a.COMPRESSED_RGBA_PVRTC_2BPPV1_IMG}else return null;if(r===Qh)return a=t.get("WEBGL_compressed_texture_etc1"),a!==null?a.COMPRESSED_RGB_ETC1_WEBGL:null;if(r===wc||r===Ec)if(a=t.get("WEBGL_compressed_texture_etc"),a!==null){if(r===wc)return l===me?a.COMPRESSED_SRGB8_ETC2:a.COMPRESSED_RGB8_ETC2;if(r===Ec)return l===me?a.COMPRESSED_SRGB8_ALPHA8_ETC2_EAC:a.COMPRESSED_RGBA8_ETC2_EAC}else return null;if(r===Tc||r===Ac||r===Cc||r===Rc||r===Pc||r===Lc||r===Ic||r===Dc||r===Uc||r===Nc||r===Oc||r===Fc||r===Bc||r===zc)if(a=t.get("WEBGL_compressed_texture_astc"),a!==null){if(r===Tc)return l===me?a.COMPRESSED_SRGB8_ALPHA8_ASTC_4x4_KHR:a.COMPRESSED_RGBA_ASTC_4x4_KHR;if(r===Ac)return l===me?a.COMPRESSED_SRGB8_ALPHA8_ASTC_5x4_KHR:a.COMPRESSED_RGBA_ASTC_5x4_KHR;if(r===Cc)return l===me?a.COMPRESSED_SRGB8_ALPHA8_ASTC_5x5_KHR:a.COMPRESSED_RGBA_ASTC_5x5_KHR;if(r===Rc)return l===me?a.COMPRESSED_SRGB8_ALPHA8_ASTC_6x5_KHR:a.COMPRESSED_RGBA_ASTC_6x5_KHR;if(r===Pc)return l===me?a.COMPRESSED_SRGB8_ALPHA8_ASTC_6x6_KHR:a.COMPRESSED_RGBA_ASTC_6x6_KHR;if(r===Lc)return l===me?a.COMPRESSED_SRGB8_ALPHA8_ASTC_8x5_KHR:a.COMPRESSED_RGBA_ASTC_8x5_KHR;if(r===Ic)return l===me?a.COMPRESSED_SRGB8_ALPHA8_ASTC_8x6_KHR:a.COMPRESSED_RGBA_ASTC_8x6_KHR;if(r===Dc)return l===me?a.COMPRESSED_SRGB8_ALPHA8_ASTC_8x8_KHR:a.COMPRESSED_RGBA_ASTC_8x8_KHR;if(r===Uc)return l===me?a.COMPRESSED_SRGB8_ALPHA8_ASTC_10x5_KHR:a.COMPRESSED_RGBA_ASTC_10x5_KHR;if(r===Nc)return l===me?a.COMPRESSED_SRGB8_ALPHA8_ASTC_10x6_KHR:a.COMPRESSED_RGBA_ASTC_10x6_KHR;if(r===Oc)return l===me?a.COMPRESSED_SRGB8_ALPHA8_ASTC_10x8_KHR:a.COMPRESSED_RGBA_ASTC_10x8_KHR;if(r===Fc)return l===me?a.COMPRESSED_SRGB8_ALPHA8_ASTC_10x10_KHR:a.COMPRESSED_RGBA_ASTC_10x10_KHR;if(r===Bc)return l===me?a.COMPRESSED_SRGB8_ALPHA8_ASTC_12x10_KHR:a.COMPRESSED_RGBA_ASTC_12x10_KHR;if(r===zc)return l===me?a.COMPRESSED_SRGB8_ALPHA8_ASTC_12x12_KHR:a.COMPRESSED_RGBA_ASTC_12x12_KHR}else return null;if(r===bo||r===kc||r===Hc)if(a=t.get("EXT_texture_compression_bptc"),a!==null){if(r===bo)return l===me?a.COMPRESSED_SRGB_ALPHA_BPTC_UNORM_EXT:a.COMPRESSED_RGBA_BPTC_UNORM_EXT;if(r===kc)return a.COMPRESSED_RGB_BPTC_SIGNED_FLOAT_EXT;if(r===Hc)return a.COMPRESSED_RGB_BPTC_UNSIGNED_FLOAT_EXT}else return null;if(r===bd||r===Vc||r===Gc||r===Wc)if(a=t.get("EXT_texture_compression_rgtc"),a!==null){if(r===bo)return a.COMPRESSED_RED_RGTC1_EXT;if(r===Vc)return a.COMPRESSED_SIGNED_RED_RGTC1_EXT;if(r===Gc)return a.COMPRESSED_RED_GREEN_RGTC2_EXT;if(r===Wc)return a.COMPRESSED_SIGNED_RED_GREEN_RGTC2_EXT}else return null;return r===Gi?n?i.UNSIGNED_INT_24_8:(a=t.get("WEBGL_depth_texture"),a!==null?a.UNSIGNED_INT_24_8_WEBGL:null):i[r]!==void 0?i[r]:null}return{convert:s}}var ul=class extends en{constructor(t=[]){super(),this.isArrayCamera=!0,this.cameras=t}},Si=class extends nn{constructor(){super(),this.isGroup=!0,this.type="Group"}},N0={type:"move"},fr=class{constructor(){this._targetRay=null,this._grip=null,this._hand=null}getHandSpace(){return this._hand===null&&(this._hand=new Si,this._hand.matrixAutoUpdate=!1,this._hand.visible=!1,this._hand.joints={},this._hand.inputState={pinching:!1}),this._hand}getTargetRaySpace(){return this._targetRay===null&&(this._targetRay=new Si,this._targetRay.matrixAutoUpdate=!1,this._targetRay.visible=!1,this._targetRay.hasLinearVelocity=!1,this._targetRay.linearVelocity=new B,this._targetRay.hasAngularVelocity=!1,this._targetRay.angularVelocity=new B),this._targetRay}getGripSpace(){return this._grip===null&&(this._grip=new Si,this._grip.matrixAutoUpdate=!1,this._grip.visible=!1,this._grip.hasLinearVelocity=!1,this._grip.linearVelocity=new B,this._grip.hasAngularVelocity=!1,this._grip.angularVelocity=new B),this._grip}dispatchEvent(t){return this._targetRay!==null&&this._targetRay.dispatchEvent(t),this._grip!==null&&this._grip.dispatchEvent(t),this._hand!==null&&this._hand.dispatchEvent(t),this}connect(t){if(t&&t.hand){let e=this._hand;if(e)for(let n of t.hand.values())this._getHandJoint(e,n)}return this.dispatchEvent({type:"connected",data:t}),this}disconnect(t){return this.dispatchEvent({type:"disconnected",data:t}),this._targetRay!==null&&(this._targetRay.visible=!1),this._grip!==null&&(this._grip.visible=!1),this._hand!==null&&(this._hand.visible=!1),this}update(t,e,n){let s=null,r=null,o=null,a=this._targetRay,l=this._grip,h=this._hand;if(t&&e.session.visibilityState!=="visible-blurred"){if(h&&t.hand){o=!0;for(let M of t.hand.values()){let g=e.getJointPose(M,n),f=this._getHandJoint(h,M);g!==null&&(f.matrix.fromArray(g.transform.matrix),f.matrix.decompose(f.position,f.rotation,f.scale),f.matrixWorldNeedsUpdate=!0,f.jointRadius=g.radius),f.visible=g!==null}let u=h.joints["index-finger-tip"],d=h.joints["thumb-tip"],m=u.position.distanceTo(d.position),x=.02,v=.005;h.inputState.pinching&&m>x+v?(h.inputState.pinching=!1,this.dispatchEvent({type:"pinchend",handedness:t.handedness,target:this})):!h.inputState.pinching&&m<=x-v&&(h.inputState.pinching=!0,this.dispatchEvent({type:"pinchstart",handedness:t.handedness,target:this}))}else l!==null&&t.gripSpace&&(r=e.getPose(t.gripSpace,n),r!==null&&(l.matrix.fromArray(r.transform.matrix),l.matrix.decompose(l.position,l.rotation,l.scale),l.matrixWorldNeedsUpdate=!0,r.linearVelocity?(l.hasLinearVelocity=!0,l.linearVelocity.copy(r.linearVelocity)):l.hasLinearVelocity=!1,r.angularVelocity?(l.hasAngularVelocity=!0,l.angularVelocity.copy(r.angularVelocity)):l.hasAngularVelocity=!1));a!==null&&(s=e.getPose(t.targetRaySpace,n),s===null&&r!==null&&(s=r),s!==null&&(a.matrix.fromArray(s.transform.matrix),a.matrix.decompose(a.position,a.rotation,a.scale),a.matrixWorldNeedsUpdate=!0,s.linearVelocity?(a.hasLinearVelocity=!0,a.linearVelocity.copy(s.linearVelocity)):a.hasLinearVelocity=!1,s.angularVelocity?(a.hasAngularVelocity=!0,a.angularVelocity.copy(s.angularVelocity)):a.hasAngularVelocity=!1,this.dispatchEvent(N0)))}return a!==null&&(a.visible=s!==null),l!==null&&(l.visible=r!==null),h!==null&&(h.visible=o!==null),this}_getHandJoint(t,e){if(t.joints[e.jointName]===void 0){let n=new Si;n.matrixAutoUpdate=!1,n.visible=!1,t.joints[e.jointName]=n,t.add(n)}return t.joints[e.jointName]}},dl=class extends Jn{constructor(t,e){super();let n=this,s=null,r=1,o=null,a="local-floor",l=1,h=null,u=null,d=null,m=null,x=null,v=null,M=e.getContextAttributes(),g=null,f=null,R=[],E=[],L=new At,z=null,N=new en;N.layers.enable(1),N.viewport=new Se;let I=new en;I.layers.enable(2),I.viewport=new Se;let it=[N,I],w=new ul;w.layers.enable(1),w.layers.enable(2);let A=null,X=null;this.cameraAutoUpdate=!0,this.enabled=!1,this.isPresenting=!1,this.getController=function(G){let nt=R[G];return nt===void 0&&(nt=new fr,R[G]=nt),nt.getTargetRaySpace()},this.getControllerGrip=function(G){let nt=R[G];return nt===void 0&&(nt=new fr,R[G]=nt),nt.getGripSpace()},this.getHand=function(G){let nt=R[G];return nt===void 0&&(nt=new fr,R[G]=nt),nt.getHandSpace()};function tt(G){let nt=E.indexOf(G.inputSource);if(nt===-1)return;let mt=R[nt];mt!==void 0&&(mt.update(G.inputSource,G.frame,h||o),mt.dispatchEvent({type:G.type,data:G.inputSource}))}function at(){s.removeEventListener("select",tt),s.removeEventListener("selectstart",tt),s.removeEventListener("selectend",tt),s.removeEventListener("squeeze",tt),s.removeEventListener("squeezestart",tt),s.removeEventListener("squeezeend",tt),s.removeEventListener("end",at),s.removeEventListener("inputsourceschange",F);for(let G=0;G<R.length;G++){let nt=E[G];nt!==null&&(E[G]=null,R[G].disconnect(nt))}A=null,X=null,t.setRenderTarget(g),x=null,m=null,d=null,s=null,f=null,vt.stop(),n.isPresenting=!1,t.setPixelRatio(z),t.setSize(L.width,L.height,!1),n.dispatchEvent({type:"sessionend"})}this.setFramebufferScaleFactor=function(G){r=G,n.isPresenting===!0&&console.warn("THREE.WebXRManager: Cannot change framebuffer scale while presenting.")},this.setReferenceSpaceType=function(G){a=G,n.isPresenting===!0&&console.warn("THREE.WebXRManager: Cannot change reference space type while presenting.")},this.getReferenceSpace=function(){return h||o},this.setReferenceSpace=function(G){h=G},this.getBaseLayer=function(){return m!==null?m:x},this.getBinding=function(){return d},this.getFrame=function(){return v},this.getSession=function(){return s},this.setSession=async function(G){if(s=G,s!==null){if(g=t.getRenderTarget(),s.addEventListener("select",tt),s.addEventListener("selectstart",tt),s.addEventListener("selectend",tt),s.addEventListener("squeeze",tt),s.addEventListener("squeezestart",tt),s.addEventListener("squeezeend",tt),s.addEventListener("end",at),s.addEventListener("inputsourceschange",F),M.xrCompatible!==!0&&await e.makeXRCompatible(),z=t.getPixelRatio(),t.getSize(L),s.renderState.layers===void 0||t.capabilities.isWebGL2===!1){let nt={antialias:s.renderState.layers===void 0?M.antialias:!0,alpha:!0,depth:M.depth,stencil:M.stencil,framebufferScaleFactor:r};x=new XRWebGLLayer(s,e,nt),s.updateRenderState({baseLayer:x}),t.setPixelRatio(1),t.setSize(x.framebufferWidth,x.framebufferHeight,!1),f=new je(x.framebufferWidth,x.framebufferHeight,{format:On,type:Ei,colorSpace:t.outputColorSpace,stencilBuffer:M.stencil})}else{let nt=null,mt=null,Tt=null;M.depth&&(Tt=M.stencil?e.DEPTH24_STENCIL8:e.DEPTH_COMPONENT24,nt=M.stencil?Os:Wi,mt=M.stencil?Gi:bi);let It={colorFormat:e.RGBA8,depthFormat:Tt,scaleFactor:r};d=new XRWebGLBinding(s,e),m=d.createProjectionLayer(It),s.updateRenderState({layers:[m]}),t.setPixelRatio(1),t.setSize(m.textureWidth,m.textureHeight,!1),f=new je(m.textureWidth,m.textureHeight,{format:On,type:Ei,depthTexture:new Ta(m.textureWidth,m.textureHeight,mt,void 0,void 0,void 0,void 0,void 0,void 0,nt),stencilBuffer:M.stencil,colorSpace:t.outputColorSpace,samples:M.antialias?4:0});let Wt=t.properties.get(f);Wt.__ignoreDepthValues=m.ignoreDepthValues}f.isXRRenderTarget=!0,this.setFoveation(l),h=null,o=await s.requestReferenceSpace(a),vt.setContext(s),vt.start(),n.isPresenting=!0,n.dispatchEvent({type:"sessionstart"})}},this.getEnvironmentBlendMode=function(){if(s!==null)return s.environmentBlendMode};function F(G){for(let nt=0;nt<G.removed.length;nt++){let mt=G.removed[nt],Tt=E.indexOf(mt);Tt>=0&&(E[Tt]=null,R[Tt].disconnect(mt))}for(let nt=0;nt<G.added.length;nt++){let mt=G.added[nt],Tt=E.indexOf(mt);if(Tt===-1){for(let Wt=0;Wt<R.length;Wt++)if(Wt>=E.length){E.push(mt),Tt=Wt;break}else if(E[Wt]===null){E[Wt]=mt,Tt=Wt;break}if(Tt===-1)break}let It=R[Tt];It&&It.connect(mt)}}let V=new B,Z=new B;function k(G,nt,mt){V.setFromMatrixPosition(nt.matrixWorld),Z.setFromMatrixPosition(mt.matrixWorld);let Tt=V.distanceTo(Z),It=nt.projectionMatrix.elements,Wt=mt.projectionMatrix.elements,Ht=It[14]/(It[10]-1),Bt=It[14]/(It[10]+1),ee=(It[9]+1)/It[5],q=(It[9]-1)/It[5],Pe=(It[8]-1)/It[0],Ft=(Wt[8]+1)/Wt[0],Vt=Ht*Pe,Rt=Ht*Ft,pe=Tt/(-Pe+Ft),Yt=pe*-Pe;nt.matrixWorld.decompose(G.position,G.quaternion,G.scale),G.translateX(Yt),G.translateZ(pe),G.matrixWorld.compose(G.position,G.quaternion,G.scale),G.matrixWorldInverse.copy(G.matrixWorld).invert();let C=Ht+pe,b=Bt+pe,Y=Vt-Yt,Q=Rt+(Tt-Yt),ot=ee*Bt/b*C,ct=q*Bt/b*C;G.projectionMatrix.makePerspective(Y,Q,ot,ct,C,b),G.projectionMatrixInverse.copy(G.projectionMatrix).invert()}function $(G,nt){nt===null?G.matrixWorld.copy(G.matrix):G.matrixWorld.multiplyMatrices(nt.matrixWorld,G.matrix),G.matrixWorldInverse.copy(G.matrixWorld).invert()}this.updateCamera=function(G){if(s===null)return;w.near=I.near=N.near=G.near,w.far=I.far=N.far=G.far,(A!==w.near||X!==w.far)&&(s.updateRenderState({depthNear:w.near,depthFar:w.far}),A=w.near,X=w.far);let nt=G.parent,mt=w.cameras;$(w,nt);for(let Tt=0;Tt<mt.length;Tt++)$(mt[Tt],nt);mt.length===2?k(w,N,I):w.projectionMatrix.copy(N.projectionMatrix),K(G,w,nt)};function K(G,nt,mt){mt===null?G.matrix.copy(nt.matrixWorld):(G.matrix.copy(mt.matrixWorld),G.matrix.invert(),G.matrix.multiply(nt.matrixWorld)),G.matrix.decompose(G.position,G.quaternion,G.scale),G.updateMatrixWorld(!0),G.projectionMatrix.copy(nt.projectionMatrix),G.projectionMatrixInverse.copy(nt.projectionMatrixInverse),G.isPerspectiveCamera&&(G.fov=gr*2*Math.atan(1/G.projectionMatrix.elements[5]),G.zoom=1)}this.getCamera=function(){return w},this.getFoveation=function(){if(!(m===null&&x===null))return l},this.setFoveation=function(G){l=G,m!==null&&(m.fixedFoveation=G),x!==null&&x.fixedFoveation!==void 0&&(x.fixedFoveation=G)};let et=null;function rt(G,nt){if(u=nt.getViewerPose(h||o),v=nt,u!==null){let mt=u.views;x!==null&&(t.setRenderTargetFramebuffer(f,x.framebuffer),t.setRenderTarget(f));let Tt=!1;mt.length!==w.cameras.length&&(w.cameras.length=0,Tt=!0);for(let It=0;It<mt.length;It++){let Wt=mt[It],Ht=null;if(x!==null)Ht=x.getViewport(Wt);else{let ee=d.getViewSubImage(m,Wt);Ht=ee.viewport,It===0&&(t.setRenderTargetTextures(f,ee.colorTexture,m.ignoreDepthValues?void 0:ee.depthStencilTexture),t.setRenderTarget(f))}let Bt=it[It];Bt===void 0&&(Bt=new en,Bt.layers.enable(It),Bt.viewport=new Se,it[It]=Bt),Bt.matrix.fromArray(Wt.transform.matrix),Bt.matrix.decompose(Bt.position,Bt.quaternion,Bt.scale),Bt.projectionMatrix.fromArray(Wt.projectionMatrix),Bt.projectionMatrixInverse.copy(Bt.projectionMatrix).invert(),Bt.viewport.set(Ht.x,Ht.y,Ht.width,Ht.height),It===0&&(w.matrix.copy(Bt.matrix),w.matrix.decompose(w.position,w.quaternion,w.scale)),Tt===!0&&w.cameras.push(Bt)}}for(let mt=0;mt<R.length;mt++){let Tt=E[mt],It=R[mt];Tt!==null&&It!==void 0&&It.update(Tt,nt,h||o)}et&&et(G,nt),nt.detectedPlanes&&n.dispatchEvent({type:"planesdetected",data:nt}),v=null}let vt=new ou;vt.setAnimationLoop(rt),this.setAnimationLoop=function(G){et=G},this.dispose=function(){}}};function O0(i,t){function e(g,f){g.matrixAutoUpdate===!0&&g.updateMatrix(),f.value.copy(g.matrix)}function n(g,f){f.color.getRGB(g.fogColor.value,au(i)),f.isFog?(g.fogNear.value=f.near,g.fogFar.value=f.far):f.isFogExp2&&(g.fogDensity.value=f.density)}function s(g,f,R,E,L){f.isMeshBasicMaterial||f.isMeshLambertMaterial?r(g,f):f.isMeshToonMaterial?(r(g,f),d(g,f)):f.isMeshPhongMaterial?(r(g,f),u(g,f)):f.isMeshStandardMaterial?(r(g,f),m(g,f),f.isMeshPhysicalMaterial&&x(g,f,L)):f.isMeshMatcapMaterial?(r(g,f),v(g,f)):f.isMeshDepthMaterial?r(g,f):f.isMeshDistanceMaterial?(r(g,f),M(g,f)):f.isMeshNormalMaterial?r(g,f):f.isLineBasicMaterial?(o(g,f),f.isLineDashedMaterial&&a(g,f)):f.isPointsMaterial?l(g,f,R,E):f.isSpriteMaterial?h(g,f):f.isShadowMaterial?(g.color.value.copy(f.color),g.opacity.value=f.opacity):f.isShaderMaterial&&(f.uniformsNeedUpdate=!1)}function r(g,f){g.opacity.value=f.opacity,f.color&&g.diffuse.value.copy(f.color),f.emissive&&g.emissive.value.copy(f.emissive).multiplyScalar(f.emissiveIntensity),f.map&&(g.map.value=f.map,e(f.map,g.mapTransform)),f.alphaMap&&(g.alphaMap.value=f.alphaMap,e(f.alphaMap,g.alphaMapTransform)),f.bumpMap&&(g.bumpMap.value=f.bumpMap,e(f.bumpMap,g.bumpMapTransform),g.bumpScale.value=f.bumpScale,f.side===pn&&(g.bumpScale.value*=-1)),f.normalMap&&(g.normalMap.value=f.normalMap,e(f.normalMap,g.normalMapTransform),g.normalScale.value.copy(f.normalScale),f.side===pn&&g.normalScale.value.negate()),f.displacementMap&&(g.displacementMap.value=f.displacementMap,e(f.displacementMap,g.displacementMapTransform),g.displacementScale.value=f.displacementScale,g.displacementBias.value=f.displacementBias),f.emissiveMap&&(g.emissiveMap.value=f.emissiveMap,e(f.emissiveMap,g.emissiveMapTransform)),f.specularMap&&(g.specularMap.value=f.specularMap,e(f.specularMap,g.specularMapTransform)),f.alphaTest>0&&(g.alphaTest.value=f.alphaTest);let R=t.get(f).envMap;if(R&&(g.envMap.value=R,g.flipEnvMap.value=R.isCubeTexture&&R.isRenderTargetTexture===!1?-1:1,g.reflectivity.value=f.reflectivity,g.ior.value=f.ior,g.refractionRatio.value=f.refractionRatio),f.lightMap){g.lightMap.value=f.lightMap;let E=i._useLegacyLights===!0?Math.PI:1;g.lightMapIntensity.value=f.lightMapIntensity*E,e(f.lightMap,g.lightMapTransform)}f.aoMap&&(g.aoMap.value=f.aoMap,g.aoMapIntensity.value=f.aoMapIntensity,e(f.aoMap,g.aoMapTransform))}function o(g,f){g.diffuse.value.copy(f.color),g.opacity.value=f.opacity,f.map&&(g.map.value=f.map,e(f.map,g.mapTransform))}function a(g,f){g.dashSize.value=f.dashSize,g.totalSize.value=f.dashSize+f.gapSize,g.scale.value=f.scale}function l(g,f,R,E){g.diffuse.value.copy(f.color),g.opacity.value=f.opacity,g.size.value=f.size*R,g.scale.value=E*.5,f.map&&(g.map.value=f.map,e(f.map,g.uvTransform)),f.alphaMap&&(g.alphaMap.value=f.alphaMap,e(f.alphaMap,g.alphaMapTransform)),f.alphaTest>0&&(g.alphaTest.value=f.alphaTest)}function h(g,f){g.diffuse.value.copy(f.color),g.opacity.value=f.opacity,g.rotation.value=f.rotation,f.map&&(g.map.value=f.map,e(f.map,g.mapTransform)),f.alphaMap&&(g.alphaMap.value=f.alphaMap,e(f.alphaMap,g.alphaMapTransform)),f.alphaTest>0&&(g.alphaTest.value=f.alphaTest)}function u(g,f){g.specular.value.copy(f.specular),g.shininess.value=Math.max(f.shininess,1e-4)}function d(g,f){f.gradientMap&&(g.gradientMap.value=f.gradientMap)}function m(g,f){g.metalness.value=f.metalness,f.metalnessMap&&(g.metalnessMap.value=f.metalnessMap,e(f.metalnessMap,g.metalnessMapTransform)),g.roughness.value=f.roughness,f.roughnessMap&&(g.roughnessMap.value=f.roughnessMap,e(f.roughnessMap,g.roughnessMapTransform)),t.get(f).envMap&&(g.envMapIntensity.value=f.envMapIntensity)}function x(g,f,R){g.ior.value=f.ior,f.sheen>0&&(g.sheenColor.value.copy(f.sheenColor).multiplyScalar(f.sheen),g.sheenRoughness.value=f.sheenRoughness,f.sheenColorMap&&(g.sheenColorMap.value=f.sheenColorMap,e(f.sheenColorMap,g.sheenColorMapTransform)),f.sheenRoughnessMap&&(g.sheenRoughnessMap.value=f.sheenRoughnessMap,e(f.sheenRoughnessMap,g.sheenRoughnessMapTransform))),f.clearcoat>0&&(g.clearcoat.value=f.clearcoat,g.clearcoatRoughness.value=f.clearcoatRoughness,f.clearcoatMap&&(g.clearcoatMap.value=f.clearcoatMap,e(f.clearcoatMap,g.clearcoatMapTransform)),f.clearcoatRoughnessMap&&(g.clearcoatRoughnessMap.value=f.clearcoatRoughnessMap,e(f.clearcoatRoughnessMap,g.clearcoatRoughnessMapTransform)),f.clearcoatNormalMap&&(g.clearcoatNormalMap.value=f.clearcoatNormalMap,e(f.clearcoatNormalMap,g.clearcoatNormalMapTransform),g.clearcoatNormalScale.value.copy(f.clearcoatNormalScale),f.side===pn&&g.clearcoatNormalScale.value.negate())),f.iridescence>0&&(g.iridescence.value=f.iridescence,g.iridescenceIOR.value=f.iridescenceIOR,g.iridescenceThicknessMinimum.value=f.iridescenceThicknessRange[0],g.iridescenceThicknessMaximum.value=f.iridescenceThicknessRange[1],f.iridescenceMap&&(g.iridescenceMap.value=f.iridescenceMap,e(f.iridescenceMap,g.iridescenceMapTransform)),f.iridescenceThicknessMap&&(g.iridescenceThicknessMap.value=f.iridescenceThicknessMap,e(f.iridescenceThicknessMap,g.iridescenceThicknessMapTransform))),f.transmission>0&&(g.transmission.value=f.transmission,g.transmissionSamplerMap.value=R.texture,g.transmissionSamplerSize.value.set(R.width,R.height),f.transmissionMap&&(g.transmissionMap.value=f.transmissionMap,e(f.transmissionMap,g.transmissionMapTransform)),g.thickness.value=f.thickness,f.thicknessMap&&(g.thicknessMap.value=f.thicknessMap,e(f.thicknessMap,g.thicknessMapTransform)),g.attenuationDistance.value=f.attenuationDistance,g.attenuationColor.value.copy(f.attenuationColor)),f.anisotropy>0&&(g.anisotropyVector.value.set(f.anisotropy*Math.cos(f.anisotropyRotation),f.anisotropy*Math.sin(f.anisotropyRotation)),f.anisotropyMap&&(g.anisotropyMap.value=f.anisotropyMap,e(f.anisotropyMap,g.anisotropyMapTransform))),g.specularIntensity.value=f.specularIntensity,g.specularColor.value.copy(f.specularColor),f.specularColorMap&&(g.specularColorMap.value=f.specularColorMap,e(f.specularColorMap,g.specularColorMapTransform)),f.specularIntensityMap&&(g.specularIntensityMap.value=f.specularIntensityMap,e(f.specularIntensityMap,g.specularIntensityMapTransform))}function v(g,f){f.matcap&&(g.matcap.value=f.matcap)}function M(g,f){let R=t.get(f).light;g.referencePosition.value.setFromMatrixPosition(R.matrixWorld),g.nearDistance.value=R.shadow.camera.near,g.farDistance.value=R.shadow.camera.far}return{refreshFogUniforms:n,refreshMaterialUniforms:s}}function F0(i,t,e,n){let s={},r={},o=[],a=e.isWebGL2?i.getParameter(i.MAX_UNIFORM_BUFFER_BINDINGS):0;function l(R,E){let L=E.program;n.uniformBlockBinding(R,L)}function h(R,E){let L=s[R.id];L===void 0&&(v(R),L=u(R),s[R.id]=L,R.addEventListener("dispose",g));let z=E.program;n.updateUBOMapping(R,z);let N=t.render.frame;r[R.id]!==N&&(m(R),r[R.id]=N)}function u(R){let E=d();R.__bindingPointIndex=E;let L=i.createBuffer(),z=R.__size,N=R.usage;return i.bindBuffer(i.UNIFORM_BUFFER,L),i.bufferData(i.UNIFORM_BUFFER,z,N),i.bindBuffer(i.UNIFORM_BUFFER,null),i.bindBufferBase(i.UNIFORM_BUFFER,E,L),L}function d(){for(let R=0;R<a;R++)if(o.indexOf(R)===-1)return o.push(R),R;return console.error("THREE.WebGLRenderer: Maximum number of simultaneously usable uniforms groups reached."),0}function m(R){let E=s[R.id],L=R.uniforms,z=R.__cache;i.bindBuffer(i.UNIFORM_BUFFER,E);for(let N=0,I=L.length;N<I;N++){let it=Array.isArray(L[N])?L[N]:[L[N]];for(let w=0,A=it.length;w<A;w++){let X=it[w];if(x(X,N,w,z)===!0){let tt=X.__offset,at=Array.isArray(X.value)?X.value:[X.value],F=0;for(let V=0;V<at.length;V++){let Z=at[V],k=M(Z);typeof Z=="number"||typeof Z=="boolean"?(X.__data[0]=Z,i.bufferSubData(i.UNIFORM_BUFFER,tt+F,X.__data)):Z.isMatrix3?(X.__data[0]=Z.elements[0],X.__data[1]=Z.elements[1],X.__data[2]=Z.elements[2],X.__data[3]=0,X.__data[4]=Z.elements[3],X.__data[5]=Z.elements[4],X.__data[6]=Z.elements[5],X.__data[7]=0,X.__data[8]=Z.elements[6],X.__data[9]=Z.elements[7],X.__data[10]=Z.elements[8],X.__data[11]=0):(Z.toArray(X.__data,F),F+=k.storage/Float32Array.BYTES_PER_ELEMENT)}i.bufferSubData(i.UNIFORM_BUFFER,tt,X.__data)}}}i.bindBuffer(i.UNIFORM_BUFFER,null)}function x(R,E,L,z){let N=R.value,I=E+"_"+L;if(z[I]===void 0)return typeof N=="number"||typeof N=="boolean"?z[I]=N:z[I]=N.clone(),!0;{let it=z[I];if(typeof N=="number"||typeof N=="boolean"){if(it!==N)return z[I]=N,!0}else if(it.equals(N)===!1)return it.copy(N),!0}return!1}function v(R){let E=R.uniforms,L=0,z=16;for(let I=0,it=E.length;I<it;I++){let w=Array.isArray(E[I])?E[I]:[E[I]];for(let A=0,X=w.length;A<X;A++){let tt=w[A],at=Array.isArray(tt.value)?tt.value:[tt.value];for(let F=0,V=at.length;F<V;F++){let Z=at[F],k=M(Z),$=L%z;$!==0&&z-$<k.boundary&&(L+=z-$),tt.__data=new Float32Array(k.storage/Float32Array.BYTES_PER_ELEMENT),tt.__offset=L,L+=k.storage}}}let N=L%z;return N>0&&(L+=z-N),R.__size=L,R.__cache={},this}function M(R){let E={boundary:0,storage:0};return typeof R=="number"||typeof R=="boolean"?(E.boundary=4,E.storage=4):R.isVector2?(E.boundary=8,E.storage=8):R.isVector3||R.isColor?(E.boundary=16,E.storage=12):R.isVector4?(E.boundary=16,E.storage=16):R.isMatrix3?(E.boundary=48,E.storage=48):R.isMatrix4?(E.boundary=64,E.storage=64):R.isTexture?console.warn("THREE.WebGLRenderer: Texture samplers can not be part of an uniforms group."):console.warn("THREE.WebGLRenderer: Unsupported uniform value type.",R),E}function g(R){let E=R.target;E.removeEventListener("dispose",g);let L=o.indexOf(E.__bindingPointIndex);o.splice(L,1),i.deleteBuffer(s[E.id]),delete s[E.id],delete r[E.id]}function f(){for(let R in s)i.deleteBuffer(s[R]);o=[],s={},r={}}return{bind:l,update:h,dispose:f}}var yr=class{constructor(t={}){let{canvas:e=Yd(),context:n=null,depth:s=!0,stencil:r=!0,alpha:o=!1,antialias:a=!1,premultipliedAlpha:l=!0,preserveDrawingBuffer:h=!1,powerPreference:u="default",failIfMajorPerformanceCaveat:d=!1}=t;this.isWebGLRenderer=!0;let m;n!==null?m=n.getContextAttributes().alpha:m=o;let x=new Uint32Array(4),v=new Int32Array(4),M=null,g=null,f=[],R=[];this.domElement=e,this.debug={checkShaderErrors:!0,onShaderError:null},this.autoClear=!0,this.autoClearColor=!0,this.autoClearDepth=!0,this.autoClearStencil=!0,this.sortObjects=!0,this.clippingPlanes=[],this.localClippingEnabled=!1,this._outputColorSpace=Re,this._useLegacyLights=!1,this.toneMapping=wi,this.toneMappingExposure=1;let E=this,L=!1,z=0,N=0,I=null,it=-1,w=null,A=new Se,X=new Se,tt=null,at=new Xt(0),F=0,V=e.width,Z=e.height,k=1,$=null,K=null,et=new Se(0,0,V,Z),rt=new Se(0,0,V,Z),vt=!1,G=new _r,nt=!1,mt=!1,Tt=null,It=new _e,Wt=new At,Ht=new B,Bt={background:null,fog:null,environment:null,overrideMaterial:null,isScene:!0};function ee(){return I===null?k:1}let q=n;function Pe(T,H){for(let J=0;J<T.length;J++){let j=T[J],W=e.getContext(j,H);if(W!==null)return W}return null}try{let T={alpha:!0,depth:s,stencil:r,antialias:a,premultipliedAlpha:l,preserveDrawingBuffer:h,powerPreference:u,failIfMajorPerformanceCaveat:d};if("setAttribute"in e&&e.setAttribute("data-engine","three.js r160"),e.addEventListener("webglcontextlost",gt,!1),e.addEventListener("webglcontextrestored",U,!1),e.addEventListener("webglcontextcreationerror",ft,!1),q===null){let H=["webgl2","webgl","experimental-webgl"];if(E.isWebGL1Renderer===!0&&H.shift(),q=Pe(H,T),q===null)throw Pe(H)?new Error("Error creating WebGL context with your selected attributes."):new Error("Error creating WebGL context.")}typeof WebGLRenderingContext<"u"&&q instanceof WebGLRenderingContext&&console.warn("THREE.WebGLRenderer: WebGL 1 support was deprecated in r153 and will be removed in r163."),q.getShaderPrecisionFormat===void 0&&(q.getShaderPrecisionFormat=function(){return{rangeMin:1,rangeMax:1,precision:1}})}catch(T){throw console.error("THREE.WebGLRenderer: "+T.message),T}let Ft,Vt,Rt,pe,Yt,C,b,Y,Q,ot,ct,Lt,St,yt,kt,Gt,ht,ne,P,lt,_t,dt,Nt,$t;function re(){Ft=new ng(q),Vt=new jm(q,Ft,t),Ft.init(Vt),dt=new U0(q,Ft,Vt),Rt=new I0(q,Ft,Vt),pe=new rg(q),Yt=new y0,C=new D0(q,Ft,Rt,Yt,Vt,dt,pe),b=new Km(E),Y=new eg(E),Q=new ff(q,Vt),Nt=new Zm(q,Ft,Q,Vt),ot=new ig(q,Q,pe,Nt),ct=new cg(q,ot,Q,pe),P=new lg(q,Vt,C),Gt=new $m(Yt),Lt=new v0(E,b,Y,Ft,Vt,Nt,Gt),St=new O0(E,Yt),yt=new M0,kt=new C0(Ft,Vt),ne=new qm(E,b,Y,Rt,ct,m,l),ht=new L0(E,ct,Vt),$t=new F0(q,pe,Vt,Rt),lt=new Jm(q,Ft,pe,Vt),_t=new sg(q,Ft,pe,Vt),pe.programs=Lt.programs,E.capabilities=Vt,E.extensions=Ft,E.properties=Yt,E.renderLists=yt,E.shadowMap=ht,E.state=Rt,E.info=pe}re();let jt=new dl(E,q);this.xr=jt,this.getContext=function(){return q},this.getContextAttributes=function(){return q.getContextAttributes()},this.forceContextLoss=function(){let T=Ft.get("WEBGL_lose_context");T&&T.loseContext()},this.forceContextRestore=function(){let T=Ft.get("WEBGL_lose_context");T&&T.restoreContext()},this.getPixelRatio=function(){return k},this.setPixelRatio=function(T){T!==void 0&&(k=T,this.setSize(V,Z,!1))},this.getSize=function(T){return T.set(V,Z)},this.setSize=function(T,H,J=!0){if(jt.isPresenting){console.warn("THREE.WebGLRenderer: Can't change size while VR device is presenting.");return}V=T,Z=H,e.width=Math.floor(T*k),e.height=Math.floor(H*k),J===!0&&(e.style.width=T+"px",e.style.height=H+"px"),this.setViewport(0,0,T,H)},this.getDrawingBufferSize=function(T){return T.set(V*k,Z*k).floor()},this.setDrawingBufferSize=function(T,H,J){V=T,Z=H,k=J,e.width=Math.floor(T*J),e.height=Math.floor(H*J),this.setViewport(0,0,T,H)},this.getCurrentViewport=function(T){return T.copy(A)},this.getViewport=function(T){return T.copy(et)},this.setViewport=function(T,H,J,j){T.isVector4?et.set(T.x,T.y,T.z,T.w):et.set(T,H,J,j),Rt.viewport(A.copy(et).multiplyScalar(k).floor())},this.getScissor=function(T){return T.copy(rt)},this.setScissor=function(T,H,J,j){T.isVector4?rt.set(T.x,T.y,T.z,T.w):rt.set(T,H,J,j),Rt.scissor(X.copy(rt).multiplyScalar(k).floor())},this.getScissorTest=function(){return vt},this.setScissorTest=function(T){Rt.setScissorTest(vt=T)},this.setOpaqueSort=function(T){$=T},this.setTransparentSort=function(T){K=T},this.getClearColor=function(T){return T.copy(ne.getClearColor())},this.setClearColor=function(){ne.setClearColor.apply(ne,arguments)},this.getClearAlpha=function(){return ne.getClearAlpha()},this.setClearAlpha=function(){ne.setClearAlpha.apply(ne,arguments)},this.clear=function(T=!0,H=!0,J=!0){let j=0;if(T){let W=!1;if(I!==null){let wt=I.texture.format;W=wt===Kh||wt===$h||wt===jh}if(W){let wt=I.texture.type,Dt=wt===Ei||wt===bi||wt===Nl||wt===Gi||wt===Zh||wt===Jh,Ut=ne.getClearColor(),zt=ne.getClearAlpha(),qt=Ut.r,Zt=Ut.g,Jt=Ut.b;Dt?(x[0]=qt,x[1]=Zt,x[2]=Jt,x[3]=zt,q.clearBufferuiv(q.COLOR,0,x)):(v[0]=qt,v[1]=Zt,v[2]=Jt,v[3]=zt,q.clearBufferiv(q.COLOR,0,v))}else j|=q.COLOR_BUFFER_BIT}H&&(j|=q.DEPTH_BUFFER_BIT),J&&(j|=q.STENCIL_BUFFER_BIT,this.state.buffers.stencil.setMask(4294967295)),q.clear(j)},this.clearColor=function(){this.clear(!0,!1,!1)},this.clearDepth=function(){this.clear(!1,!0,!1)},this.clearStencil=function(){this.clear(!1,!1,!0)},this.dispose=function(){e.removeEventListener("webglcontextlost",gt,!1),e.removeEventListener("webglcontextrestored",U,!1),e.removeEventListener("webglcontextcreationerror",ft,!1),yt.dispose(),kt.dispose(),Yt.dispose(),b.dispose(),Y.dispose(),ct.dispose(),Nt.dispose(),$t.dispose(),Lt.dispose(),jt.dispose(),jt.removeEventListener("sessionstart",Ce),jt.removeEventListener("sessionend",de),Tt&&(Tt.dispose(),Tt=null),Le.stop()};function gt(T){T.preventDefault(),console.log("THREE.WebGLRenderer: Context Lost."),L=!0}function U(){console.log("THREE.WebGLRenderer: Context Restored."),L=!1;let T=pe.autoReset,H=ht.enabled,J=ht.autoUpdate,j=ht.needsUpdate,W=ht.type;re(),pe.autoReset=T,ht.enabled=H,ht.autoUpdate=J,ht.needsUpdate=j,ht.type=W}function ft(T){console.error("THREE.WebGLRenderer: A WebGL context could not be created. Reason: ",T.statusMessage)}function xt(T){let H=T.target;H.removeEventListener("dispose",xt),Pt(H)}function Pt(T){Ot(T),Yt.remove(T)}function Ot(T){let H=Yt.get(T).programs;H!==void 0&&(H.forEach(function(J){Lt.releaseProgram(J)}),T.isShaderMaterial&&Lt.releaseShaderCache(T))}this.renderBufferDirect=function(T,H,J,j,W,wt){H===null&&(H=Bt);let Dt=W.isMesh&&W.matrixWorld.determinant()<0,Ut=Ys(T,H,J,j,W);Rt.setMaterial(j,Dt);let zt=J.index,qt=1;if(j.wireframe===!0){if(zt=ot.getWireframeAttribute(J),zt===void 0)return;qt=2}let Zt=J.drawRange,Jt=J.attributes.position,ge=Zt.start*qt,Ee=(Zt.start+Zt.count)*qt;wt!==null&&(ge=Math.max(ge,wt.start*qt),Ee=Math.min(Ee,(wt.start+wt.count)*qt)),zt!==null?(ge=Math.max(ge,0),Ee=Math.min(Ee,zt.count)):Jt!=null&&(ge=Math.max(ge,0),Ee=Math.min(Ee,Jt.count));let Ie=Ee-ge;if(Ie<0||Ie===1/0)return;Nt.setup(W,j,Ut,J,zt);let yn,xe=lt;if(zt!==null&&(yn=Q.get(zt),xe=_t,xe.setIndex(yn)),W.isMesh)j.wireframe===!0?(Rt.setLineWidth(j.wireframeLinewidth*ee()),xe.setMode(q.LINES)):xe.setMode(q.TRIANGLES);else if(W.isLine){let Kt=j.linewidth;Kt===void 0&&(Kt=1),Rt.setLineWidth(Kt*ee()),W.isLineSegments?xe.setMode(q.LINES):W.isLineLoop?xe.setMode(q.LINE_LOOP):xe.setMode(q.LINE_STRIP)}else W.isPoints?xe.setMode(q.POINTS):W.isSprite&&xe.setMode(q.TRIANGLES);if(W.isBatchedMesh)xe.renderMultiDraw(W._multiDrawStarts,W._multiDrawCounts,W._multiDrawCount);else if(W.isInstancedMesh)xe.renderInstances(ge,Ie,W.count);else if(J.isInstancedBufferGeometry){let Kt=J._maxInstanceCount!==void 0?J._maxInstanceCount:1/0,qs=Math.min(J.instanceCount,Kt);xe.renderInstances(ge,Ie,qs)}else xe.render(ge,Ie)};function le(T,H,J){T.transparent===!0&&T.side===Un&&T.forceSinglePass===!1?(T.side=pn,T.needsUpdate=!0,jn(T,H,J),T.side=Ti,T.needsUpdate=!0,jn(T,H,J),T.side=Un):jn(T,H,J)}this.compile=function(T,H,J=null){J===null&&(J=T),g=kt.get(J),g.init(),R.push(g),J.traverseVisible(function(W){W.isLight&&W.layers.test(H.layers)&&(g.pushLight(W),W.castShadow&&g.pushShadow(W))}),T!==J&&T.traverseVisible(function(W){W.isLight&&W.layers.test(H.layers)&&(g.pushLight(W),W.castShadow&&g.pushShadow(W))}),g.setupLights(E._useLegacyLights);let j=new Set;return T.traverse(function(W){let wt=W.material;if(wt)if(Array.isArray(wt))for(let Dt=0;Dt<wt.length;Dt++){let Ut=wt[Dt];le(Ut,J,W),j.add(Ut)}else le(wt,J,W),j.add(wt)}),R.pop(),g=null,j},this.compileAsync=function(T,H,J=null){let j=this.compile(T,H,J);return new Promise(W=>{function wt(){if(j.forEach(function(Dt){Yt.get(Dt).currentProgram.isReady()&&j.delete(Dt)}),j.size===0){W(T);return}setTimeout(wt,10)}Ft.get("KHR_parallel_shader_compile")!==null?wt():setTimeout(wt,10)})};let he=null;function we(T){he&&he(T)}function Ce(){Le.stop()}function de(){Le.start()}let Le=new ou;Le.setAnimationLoop(we),typeof self<"u"&&Le.setContext(self),this.setAnimationLoop=function(T){he=T,jt.setAnimationLoop(T),T===null?Le.stop():Le.start()},jt.addEventListener("sessionstart",Ce),jt.addEventListener("sessionend",de),this.render=function(T,H){if(H!==void 0&&H.isCamera!==!0){console.error("THREE.WebGLRenderer.render: camera is not an instance of THREE.Camera.");return}if(L===!0)return;T.matrixWorldAutoUpdate===!0&&T.updateMatrixWorld(),H.parent===null&&H.matrixWorldAutoUpdate===!0&&H.updateMatrixWorld(),jt.enabled===!0&&jt.isPresenting===!0&&(jt.cameraAutoUpdate===!0&&jt.updateCamera(H),H=jt.getCamera()),T.isScene===!0&&T.onBeforeRender(E,T,H,I),g=kt.get(T,R.length),g.init(),R.push(g),It.multiplyMatrices(H.projectionMatrix,H.matrixWorldInverse),G.setFromProjectionMatrix(It),mt=this.localClippingEnabled,nt=Gt.init(this.clippingPlanes,mt),M=yt.get(T,f.length),M.init(),f.push(M),$e(T,H,0,E.sortObjects),M.finish(),E.sortObjects===!0&&M.sort($,K),this.info.render.frame++,nt===!0&&Gt.beginShadows();let J=g.state.shadowsArray;if(ht.render(J,T,H),nt===!0&&Gt.endShadows(),this.info.autoReset===!0&&this.info.reset(),ne.render(M,T),g.setupLights(E._useLegacyLights),H.isArrayCamera){let j=H.cameras;for(let W=0,wt=j.length;W<wt;W++){let Dt=j[W];Ws(M,T,Dt,Dt.viewport)}}else Ws(M,T,H);I!==null&&(C.updateMultisampleRenderTarget(I),C.updateRenderTargetMipmap(I)),T.isScene===!0&&T.onAfterRender(E,T,H),Nt.resetDefaultState(),it=-1,w=null,R.pop(),R.length>0?g=R[R.length-1]:g=null,f.pop(),f.length>0?M=f[f.length-1]:M=null};function $e(T,H,J,j){if(T.visible===!1)return;if(T.layers.test(H.layers)){if(T.isGroup)J=T.renderOrder;else if(T.isLOD)T.autoUpdate===!0&&T.update(H);else if(T.isLight)g.pushLight(T),T.castShadow&&g.pushShadow(T);else if(T.isSprite){if(!T.frustumCulled||G.intersectsSprite(T)){j&&Ht.setFromMatrixPosition(T.matrixWorld).applyMatrix4(It);let Dt=ct.update(T),Ut=T.material;Ut.visible&&M.push(T,Dt,Ut,J,Ht.z,null)}}else if((T.isMesh||T.isLine||T.isPoints)&&(!T.frustumCulled||G.intersectsObject(T))){let Dt=ct.update(T),Ut=T.material;if(j&&(T.boundingSphere!==void 0?(T.boundingSphere===null&&T.computeBoundingSphere(),Ht.copy(T.boundingSphere.center)):(Dt.boundingSphere===null&&Dt.computeBoundingSphere(),Ht.copy(Dt.boundingSphere.center)),Ht.applyMatrix4(T.matrixWorld).applyMatrix4(It)),Array.isArray(Ut)){let zt=Dt.groups;for(let qt=0,Zt=zt.length;qt<Zt;qt++){let Jt=zt[qt],ge=Ut[Jt.materialIndex];ge&&ge.visible&&M.push(T,Dt,ge,J,Ht.z,Jt)}}else Ut.visible&&M.push(T,Dt,Ut,J,Ht.z,null)}}let wt=T.children;for(let Dt=0,Ut=wt.length;Dt<Ut;Dt++)$e(wt[Dt],H,J,j)}function Ws(T,H,J,j){let W=T.opaque,wt=T.transmissive,Dt=T.transparent;g.setupLightsView(J),nt===!0&&Gt.setGlobalState(E.clippingPlanes,J),wt.length>0&&$a(W,wt,H,J),j&&Rt.viewport(A.copy(j)),W.length>0&&Qi(W,H,J),wt.length>0&&Qi(wt,H,J),Dt.length>0&&Qi(Dt,H,J),Rt.buffers.depth.setTest(!0),Rt.buffers.depth.setMask(!0),Rt.buffers.color.setMask(!0),Rt.setPolygonOffset(!1)}function $a(T,H,J,j){if((J.isScene===!0?J.overrideMaterial:null)!==null)return;let wt=Vt.isWebGL2;Tt===null&&(Tt=new je(1,1,{generateMipmaps:!0,type:Ft.has("EXT_color_buffer_half_float")?xn:Ei,minFilter:Yi,samples:wt?4:0})),E.getDrawingBufferSize(Wt),wt?Tt.setSize(Wt.x,Wt.y):Tt.setSize(ma(Wt.x),ma(Wt.y));let Dt=E.getRenderTarget();E.setRenderTarget(Tt),E.getClearColor(at),F=E.getClearAlpha(),F<1&&E.setClearColor(16777215,.5),E.clear();let Ut=E.toneMapping;E.toneMapping=wi,Qi(T,J,j),C.updateMultisampleRenderTarget(Tt),C.updateRenderTargetMipmap(Tt);let zt=!1;for(let qt=0,Zt=H.length;qt<Zt;qt++){let Jt=H[qt],ge=Jt.object,Ee=Jt.geometry,Ie=Jt.material,yn=Jt.group;if(Ie.side===Un&&ge.layers.test(j.layers)){let xe=Ie.side;Ie.side=pn,Ie.needsUpdate=!0,Ar(ge,J,j,Ee,Ie,yn),Ie.side=xe,Ie.needsUpdate=!0,zt=!0}}zt===!0&&(C.updateMultisampleRenderTarget(Tt),C.updateRenderTargetMipmap(Tt)),E.setRenderTarget(Dt),E.setClearColor(at,F),E.toneMapping=Ut}function Qi(T,H,J){let j=H.isScene===!0?H.overrideMaterial:null;for(let W=0,wt=T.length;W<wt;W++){let Dt=T[W],Ut=Dt.object,zt=Dt.geometry,qt=j===null?Dt.material:j,Zt=Dt.group;Ut.layers.test(J.layers)&&Ar(Ut,H,J,zt,qt,Zt)}}function Ar(T,H,J,j,W,wt){T.onBeforeRender(E,H,J,j,W,wt),T.modelViewMatrix.multiplyMatrices(J.matrixWorldInverse,T.matrixWorld),T.normalMatrix.getNormalMatrix(T.modelViewMatrix),W.onBeforeRender(E,H,J,j,T,wt),W.transparent===!0&&W.side===Un&&W.forceSinglePass===!1?(W.side=pn,W.needsUpdate=!0,E.renderBufferDirect(J,H,j,W,T,wt),W.side=Ti,W.needsUpdate=!0,E.renderBufferDirect(J,H,j,W,T,wt),W.side=Un):E.renderBufferDirect(J,H,j,W,T,wt),T.onAfterRender(E,H,J,j,W,wt)}function jn(T,H,J){H.isScene!==!0&&(H=Bt);let j=Yt.get(T),W=g.state.lights,wt=g.state.shadowsArray,Dt=W.state.version,Ut=Lt.getParameters(T,W.state,wt,H,J),zt=Lt.getProgramCacheKey(Ut),qt=j.programs;j.environment=T.isMeshStandardMaterial?H.environment:null,j.fog=H.fog,j.envMap=(T.isMeshStandardMaterial?Y:b).get(T.envMap||j.environment),qt===void 0&&(T.addEventListener("dispose",xt),qt=new Map,j.programs=qt);let Zt=qt.get(zt);if(Zt!==void 0){if(j.currentProgram===Zt&&j.lightsStateVersion===Dt)return Cr(T,Ut),Zt}else Ut.uniforms=Lt.getUniforms(T),T.onBuild(J,Ut,E),T.onBeforeCompile(Ut,E),Zt=Lt.acquireProgram(Ut,zt),qt.set(zt,Zt),j.uniforms=Ut.uniforms;let Jt=j.uniforms;return(!T.isShaderMaterial&&!T.isRawShaderMaterial||T.clipping===!0)&&(Jt.clippingPlanes=Gt.uniform),Cr(T,Ut),j.needsLights=Qa(T),j.lightsStateVersion=Dt,j.needsLights&&(Jt.ambientLightColor.value=W.state.ambient,Jt.lightProbe.value=W.state.probe,Jt.directionalLights.value=W.state.directional,Jt.directionalLightShadows.value=W.state.directionalShadow,Jt.spotLights.value=W.state.spot,Jt.spotLightShadows.value=W.state.spotShadow,Jt.rectAreaLights.value=W.state.rectArea,Jt.ltc_1.value=W.state.rectAreaLTC1,Jt.ltc_2.value=W.state.rectAreaLTC2,Jt.pointLights.value=W.state.point,Jt.pointLightShadows.value=W.state.pointShadow,Jt.hemisphereLights.value=W.state.hemi,Jt.directionalShadowMap.value=W.state.directionalShadowMap,Jt.directionalShadowMatrix.value=W.state.directionalShadowMatrix,Jt.spotShadowMap.value=W.state.spotShadowMap,Jt.spotLightMatrix.value=W.state.spotLightMatrix,Jt.spotLightMap.value=W.state.spotLightMap,Jt.pointShadowMap.value=W.state.pointShadowMap,Jt.pointShadowMatrix.value=W.state.pointShadowMatrix),j.currentProgram=Zt,j.uniformsList=null,Zt}function Xs(T){if(T.uniformsList===null){let H=T.currentProgram.getUniforms();T.uniformsList=Is.seqWithValue(H.seq,T.uniforms)}return T.uniformsList}function Cr(T,H){let J=Yt.get(T);J.outputColorSpace=H.outputColorSpace,J.batching=H.batching,J.instancing=H.instancing,J.instancingColor=H.instancingColor,J.skinning=H.skinning,J.morphTargets=H.morphTargets,J.morphNormals=H.morphNormals,J.morphColors=H.morphColors,J.morphTargetsCount=H.morphTargetsCount,J.numClippingPlanes=H.numClippingPlanes,J.numIntersection=H.numClipIntersection,J.vertexAlphas=H.vertexAlphas,J.vertexTangents=H.vertexTangents,J.toneMapping=H.toneMapping}function Ys(T,H,J,j,W){H.isScene!==!0&&(H=Bt),C.resetTextureUnits();let wt=H.fog,Dt=j.isMeshStandardMaterial?H.environment:null,Ut=I===null?E.outputColorSpace:I.isXRRenderTarget===!0?I.texture.colorSpace:li,zt=(j.isMeshStandardMaterial?Y:b).get(j.envMap||Dt),qt=j.vertexColors===!0&&!!J.attributes.color&&J.attributes.color.itemSize===4,Zt=!!J.attributes.tangent&&(!!j.normalMap||j.anisotropy>0),Jt=!!J.morphAttributes.position,ge=!!J.morphAttributes.normal,Ee=!!J.morphAttributes.color,Ie=wi;j.toneMapped&&(I===null||I.isXRRenderTarget===!0)&&(Ie=E.toneMapping);let yn=J.morphAttributes.position||J.morphAttributes.normal||J.morphAttributes.color,xe=yn!==void 0?yn.length:0,Kt=Yt.get(j),qs=g.state.lights;if(nt===!0&&(mt===!0||T!==w)){let sn=T===w&&j.id===it;Gt.setState(j,T,sn)}let ve=!1;j.version===Kt.__version?(Kt.needsLights&&Kt.lightsStateVersion!==qs.state.version||Kt.outputColorSpace!==Ut||W.isBatchedMesh&&Kt.batching===!1||!W.isBatchedMesh&&Kt.batching===!0||W.isInstancedMesh&&Kt.instancing===!1||!W.isInstancedMesh&&Kt.instancing===!0||W.isSkinnedMesh&&Kt.skinning===!1||!W.isSkinnedMesh&&Kt.skinning===!0||W.isInstancedMesh&&Kt.instancingColor===!0&&W.instanceColor===null||W.isInstancedMesh&&Kt.instancingColor===!1&&W.instanceColor!==null||Kt.envMap!==zt||j.fog===!0&&Kt.fog!==wt||Kt.numClippingPlanes!==void 0&&(Kt.numClippingPlanes!==Gt.numPlanes||Kt.numIntersection!==Gt.numIntersection)||Kt.vertexAlphas!==qt||Kt.vertexTangents!==Zt||Kt.morphTargets!==Jt||Kt.morphNormals!==ge||Kt.morphColors!==Ee||Kt.toneMapping!==Ie||Vt.isWebGL2===!0&&Kt.morphTargetsCount!==xe)&&(ve=!0):(ve=!0,Kt.__version=j.version);let zn=Kt.currentProgram;ve===!0&&(zn=jn(j,H,W));let hi=!1,kn=!1,Zs=!1,De=zn.getUniforms(),$n=Kt.uniforms;if(Rt.useProgram(zn.program)&&(hi=!0,kn=!0,Zs=!0),j.id!==it&&(it=j.id,kn=!0),hi||w!==T){De.setValue(q,"projectionMatrix",T.projectionMatrix),De.setValue(q,"viewMatrix",T.matrixWorldInverse);let sn=De.map.cameraPosition;sn!==void 0&&sn.setValue(q,Ht.setFromMatrixPosition(T.matrixWorld)),Vt.logarithmicDepthBuffer&&De.setValue(q,"logDepthBufFC",2/(Math.log(T.far+1)/Math.LN2)),(j.isMeshPhongMaterial||j.isMeshToonMaterial||j.isMeshLambertMaterial||j.isMeshBasicMaterial||j.isMeshStandardMaterial||j.isShaderMaterial)&&De.setValue(q,"isOrthographic",T.isOrthographicCamera===!0),w!==T&&(w=T,kn=!0,Zs=!0)}if(W.isSkinnedMesh){De.setOptional(q,W,"bindMatrix"),De.setOptional(q,W,"bindMatrixInverse");let sn=W.skeleton;sn&&(Vt.floatVertexTextures?(sn.boneTexture===null&&sn.computeBoneTexture(),De.setValue(q,"boneTexture",sn.boneTexture,C)):console.warn("THREE.WebGLRenderer: SkinnedMesh can only be used with WebGL 2. With WebGL 1 OES_texture_float and vertex textures support is required."))}W.isBatchedMesh&&(De.setOptional(q,W,"batchingTexture"),De.setValue(q,"batchingTexture",W._matricesTexture,C));let Js=J.morphAttributes;if((Js.position!==void 0||Js.normal!==void 0||Js.color!==void 0&&Vt.isWebGL2===!0)&&P.update(W,J,zn),(kn||Kt.receiveShadow!==W.receiveShadow)&&(Kt.receiveShadow=W.receiveShadow,De.setValue(q,"receiveShadow",W.receiveShadow)),j.isMeshGouraudMaterial&&j.envMap!==null&&($n.envMap.value=zt,$n.flipEnvMap.value=zt.isCubeTexture&&zt.isRenderTargetTexture===!1?-1:1),kn&&(De.setValue(q,"toneMappingExposure",E.toneMappingExposure),Kt.needsLights&&Ka($n,Zs),wt&&j.fog===!0&&St.refreshFogUniforms($n,wt),St.refreshMaterialUniforms($n,j,k,Z,Tt),Is.upload(q,Xs(Kt),$n,C)),j.isShaderMaterial&&j.uniformsNeedUpdate===!0&&(Is.upload(q,Xs(Kt),$n,C),j.uniformsNeedUpdate=!1),j.isSpriteMaterial&&De.setValue(q,"center",W.center),De.setValue(q,"modelViewMatrix",W.modelViewMatrix),De.setValue(q,"normalMatrix",W.normalMatrix),De.setValue(q,"modelMatrix",W.matrixWorld),j.isShaderMaterial||j.isRawShaderMaterial){let sn=j.uniformsGroups;for(let ts=0,Rr=sn.length;ts<Rr;ts++)if(Vt.isWebGL2){let es=sn[ts];$t.update(es,zn),$t.bind(es,zn)}else console.warn("THREE.WebGLRenderer: Uniform Buffer Objects can only be used with WebGL 2.")}return zn}function Ka(T,H){T.ambientLightColor.needsUpdate=H,T.lightProbe.needsUpdate=H,T.directionalLights.needsUpdate=H,T.directionalLightShadows.needsUpdate=H,T.pointLights.needsUpdate=H,T.pointLightShadows.needsUpdate=H,T.spotLights.needsUpdate=H,T.spotLightShadows.needsUpdate=H,T.rectAreaLights.needsUpdate=H,T.hemisphereLights.needsUpdate=H}function Qa(T){return T.isMeshLambertMaterial||T.isMeshToonMaterial||T.isMeshPhongMaterial||T.isMeshStandardMaterial||T.isShadowMaterial||T.isShaderMaterial&&T.lights===!0}this.getActiveCubeFace=function(){return z},this.getActiveMipmapLevel=function(){return N},this.getRenderTarget=function(){return I},this.setRenderTargetTextures=function(T,H,J){Yt.get(T.texture).__webglTexture=H,Yt.get(T.depthTexture).__webglTexture=J;let j=Yt.get(T);j.__hasExternalTextures=!0,j.__hasExternalTextures&&(j.__autoAllocateDepthBuffer=J===void 0,j.__autoAllocateDepthBuffer||Ft.has("WEBGL_multisampled_render_to_texture")===!0&&(console.warn("THREE.WebGLRenderer: Render-to-texture extension was disabled because an external texture was provided"),j.__useRenderToTexture=!1))},this.setRenderTargetFramebuffer=function(T,H){let J=Yt.get(T);J.__webglFramebuffer=H,J.__useDefaultFramebuffer=H===void 0},this.setRenderTarget=function(T,H=0,J=0){I=T,z=H,N=J;let j=!0,W=null,wt=!1,Dt=!1;if(T){let zt=Yt.get(T);zt.__useDefaultFramebuffer!==void 0?(Rt.bindFramebuffer(q.FRAMEBUFFER,null),j=!1):zt.__webglFramebuffer===void 0?C.setupRenderTarget(T):zt.__hasExternalTextures&&C.rebindTextures(T,Yt.get(T.texture).__webglTexture,Yt.get(T.depthTexture).__webglTexture);let qt=T.texture;(qt.isData3DTexture||qt.isDataArrayTexture||qt.isCompressedArrayTexture)&&(Dt=!0);let Zt=Yt.get(T).__webglFramebuffer;T.isWebGLCubeRenderTarget?(Array.isArray(Zt[H])?W=Zt[H][J]:W=Zt[H],wt=!0):Vt.isWebGL2&&T.samples>0&&C.useMultisampledRTT(T)===!1?W=Yt.get(T).__webglMultisampledFramebuffer:Array.isArray(Zt)?W=Zt[J]:W=Zt,A.copy(T.viewport),X.copy(T.scissor),tt=T.scissorTest}else A.copy(et).multiplyScalar(k).floor(),X.copy(rt).multiplyScalar(k).floor(),tt=vt;if(Rt.bindFramebuffer(q.FRAMEBUFFER,W)&&Vt.drawBuffers&&j&&Rt.drawBuffers(T,W),Rt.viewport(A),Rt.scissor(X),Rt.setScissorTest(tt),wt){let zt=Yt.get(T.texture);q.framebufferTexture2D(q.FRAMEBUFFER,q.COLOR_ATTACHMENT0,q.TEXTURE_CUBE_MAP_POSITIVE_X+H,zt.__webglTexture,J)}else if(Dt){let zt=Yt.get(T.texture),qt=H||0;q.framebufferTextureLayer(q.FRAMEBUFFER,q.COLOR_ATTACHMENT0,zt.__webglTexture,J||0,qt)}it=-1},this.readRenderTargetPixels=function(T,H,J,j,W,wt,Dt){if(!(T&&T.isWebGLRenderTarget)){console.error("THREE.WebGLRenderer.readRenderTargetPixels: renderTarget is not THREE.WebGLRenderTarget.");return}let Ut=Yt.get(T).__webglFramebuffer;if(T.isWebGLCubeRenderTarget&&Dt!==void 0&&(Ut=Ut[Dt]),Ut){Rt.bindFramebuffer(q.FRAMEBUFFER,Ut);try{let zt=T.texture,qt=zt.format,Zt=zt.type;if(qt!==On&&dt.convert(qt)!==q.getParameter(q.IMPLEMENTATION_COLOR_READ_FORMAT)){console.error("THREE.WebGLRenderer.readRenderTargetPixels: renderTarget is not in RGBA or implementation defined format.");return}let Jt=Zt===xn&&(Ft.has("EXT_color_buffer_half_float")||Vt.isWebGL2&&Ft.has("EXT_color_buffer_float"));if(Zt!==Ei&&dt.convert(Zt)!==q.getParameter(q.IMPLEMENTATION_COLOR_READ_TYPE)&&!(Zt===Mi&&(Vt.isWebGL2||Ft.has("OES_texture_float")||Ft.has("WEBGL_color_buffer_float")))&&!Jt){console.error("THREE.WebGLRenderer.readRenderTargetPixels: renderTarget is not in UnsignedByteType or implementation defined type.");return}H>=0&&H<=T.width-j&&J>=0&&J<=T.height-W&&q.readPixels(H,J,j,W,dt.convert(qt),dt.convert(Zt),wt)}finally{let zt=I!==null?Yt.get(I).__webglFramebuffer:null;Rt.bindFramebuffer(q.FRAMEBUFFER,zt)}}},this.copyFramebufferToTexture=function(T,H,J=0){let j=Math.pow(2,-J),W=Math.floor(H.image.width*j),wt=Math.floor(H.image.height*j);C.setTexture2D(H,0),q.copyTexSubImage2D(q.TEXTURE_2D,J,0,0,T.x,T.y,W,wt),Rt.unbindTexture()},this.copyTextureToTexture=function(T,H,J,j=0){let W=H.image.width,wt=H.image.height,Dt=dt.convert(J.format),Ut=dt.convert(J.type);C.setTexture2D(J,0),q.pixelStorei(q.UNPACK_FLIP_Y_WEBGL,J.flipY),q.pixelStorei(q.UNPACK_PREMULTIPLY_ALPHA_WEBGL,J.premultiplyAlpha),q.pixelStorei(q.UNPACK_ALIGNMENT,J.unpackAlignment),H.isDataTexture?q.texSubImage2D(q.TEXTURE_2D,j,T.x,T.y,W,wt,Dt,Ut,H.image.data):H.isCompressedTexture?q.compressedTexSubImage2D(q.TEXTURE_2D,j,T.x,T.y,H.mipmaps[0].width,H.mipmaps[0].height,Dt,H.mipmaps[0].data):q.texSubImage2D(q.TEXTURE_2D,j,T.x,T.y,Dt,Ut,H.image),j===0&&J.generateMipmaps&&q.generateMipmap(q.TEXTURE_2D),Rt.unbindTexture()},this.copyTextureToTexture3D=function(T,H,J,j,W=0){if(E.isWebGL1Renderer){console.warn("THREE.WebGLRenderer.copyTextureToTexture3D: can only be used with WebGL2.");return}let wt=T.max.x-T.min.x+1,Dt=T.max.y-T.min.y+1,Ut=T.max.z-T.min.z+1,zt=dt.convert(j.format),qt=dt.convert(j.type),Zt;if(j.isData3DTexture)C.setTexture3D(j,0),Zt=q.TEXTURE_3D;else if(j.isDataArrayTexture||j.isCompressedArrayTexture)C.setTexture2DArray(j,0),Zt=q.TEXTURE_2D_ARRAY;else{console.warn("THREE.WebGLRenderer.copyTextureToTexture3D: only supports THREE.DataTexture3D and THREE.DataTexture2DArray.");return}q.pixelStorei(q.UNPACK_FLIP_Y_WEBGL,j.flipY),q.pixelStorei(q.UNPACK_PREMULTIPLY_ALPHA_WEBGL,j.premultiplyAlpha),q.pixelStorei(q.UNPACK_ALIGNMENT,j.unpackAlignment);let Jt=q.getParameter(q.UNPACK_ROW_LENGTH),ge=q.getParameter(q.UNPACK_IMAGE_HEIGHT),Ee=q.getParameter(q.UNPACK_SKIP_PIXELS),Ie=q.getParameter(q.UNPACK_SKIP_ROWS),yn=q.getParameter(q.UNPACK_SKIP_IMAGES),xe=J.isCompressedTexture?J.mipmaps[W]:J.image;q.pixelStorei(q.UNPACK_ROW_LENGTH,xe.width),q.pixelStorei(q.UNPACK_IMAGE_HEIGHT,xe.height),q.pixelStorei(q.UNPACK_SKIP_PIXELS,T.min.x),q.pixelStorei(q.UNPACK_SKIP_ROWS,T.min.y),q.pixelStorei(q.UNPACK_SKIP_IMAGES,T.min.z),J.isDataTexture||J.isData3DTexture?q.texSubImage3D(Zt,W,H.x,H.y,H.z,wt,Dt,Ut,zt,qt,xe.data):J.isCompressedArrayTexture?(console.warn("THREE.WebGLRenderer.copyTextureToTexture3D: untested support for compressed srcTexture."),q.compressedTexSubImage3D(Zt,W,H.x,H.y,H.z,wt,Dt,Ut,zt,xe.data)):q.texSubImage3D(Zt,W,H.x,H.y,H.z,wt,Dt,Ut,zt,qt,xe),q.pixelStorei(q.UNPACK_ROW_LENGTH,Jt),q.pixelStorei(q.UNPACK_IMAGE_HEIGHT,ge),q.pixelStorei(q.UNPACK_SKIP_PIXELS,Ee),q.pixelStorei(q.UNPACK_SKIP_ROWS,Ie),q.pixelStorei(q.UNPACK_SKIP_IMAGES,yn),W===0&&j.generateMipmaps&&q.generateMipmap(Zt),Rt.unbindTexture()},this.initTexture=function(T){T.isCubeTexture?C.setTextureCube(T,0):T.isData3DTexture?C.setTexture3D(T,0):T.isDataArrayTexture||T.isCompressedArrayTexture?C.setTexture2DArray(T,0):C.setTexture2D(T,0),Rt.unbindTexture()},this.resetState=function(){z=0,N=0,I=null,Rt.reset(),Nt.reset()},typeof __THREE_DEVTOOLS__<"u"&&__THREE_DEVTOOLS__.dispatchEvent(new CustomEvent("observe",{detail:this}))}get coordinateSystem(){return ai}get outputColorSpace(){return this._outputColorSpace}set outputColorSpace(t){this._outputColorSpace=t;let e=this.getContext();e.drawingBufferColorSpace=t===Ol?"display-p3":"srgb",e.unpackColorSpace=fe.workingColorSpace===Va?"display-p3":"srgb"}get outputEncoding(){return console.warn("THREE.WebGLRenderer: Property .outputEncoding has been removed. Use .outputColorSpace instead."),this.outputColorSpace===Re?Xi:tu}set outputEncoding(t){console.warn("THREE.WebGLRenderer: Property .outputEncoding has been removed. Use .outputColorSpace instead."),this.outputColorSpace=t===Xi?Re:li}get useLegacyLights(){return console.warn("THREE.WebGLRenderer: The property .useLegacyLights has been deprecated. Migrate your lighting according to the following guide: https://discourse.threejs.org/t/updates-to-lighting-in-three-js-r155/53733."),this._useLegacyLights}set useLegacyLights(t){console.warn("THREE.WebGLRenderer: The property .useLegacyLights has been deprecated. Migrate your lighting according to the following guide: https://discourse.threejs.org/t/updates-to-lighting-in-three-js-r155/53733."),this._useLegacyLights=t}},fl=class extends yr{};fl.prototype.isWebGL1Renderer=!0;var Aa=class extends nn{constructor(){super(),this.isScene=!0,this.type="Scene",this.background=null,this.environment=null,this.fog=null,this.backgroundBlurriness=0,this.backgroundIntensity=1,this.overrideMaterial=null,typeof __THREE_DEVTOOLS__<"u"&&__THREE_DEVTOOLS__.dispatchEvent(new CustomEvent("observe",{detail:this}))}copy(t,e){return super.copy(t,e),t.background!==null&&(this.background=t.background.clone()),t.environment!==null&&(this.environment=t.environment.clone()),t.fog!==null&&(this.fog=t.fog.clone()),this.backgroundBlurriness=t.backgroundBlurriness,this.backgroundIntensity=t.backgroundIntensity,t.overrideMaterial!==null&&(this.overrideMaterial=t.overrideMaterial.clone()),this.matrixAutoUpdate=t.matrixAutoUpdate,this}toJSON(t){let e=super.toJSON(t);return this.fog!==null&&(e.object.fog=this.fog.toJSON()),this.backgroundBlurriness>0&&(e.object.backgroundBlurriness=this.backgroundBlurriness),this.backgroundIntensity!==1&&(e.object.backgroundIntensity=this.backgroundIntensity),e}};var Ca=class extends cn{constructor(t,e,n,s=1){super(t,e,n),this.isInstancedBufferAttribute=!0,this.meshPerAttribute=s}copy(t){return super.copy(t),this.meshPerAttribute=t.meshPerAttribute,this}toJSON(){let t=super.toJSON();return t.meshPerAttribute=this.meshPerAttribute,t.isInstancedBufferAttribute=!0,t}},Ts=new _e,Nh=new _e,sa=[],Oh=new ci,B0=new _e,or=new Je,lr=new Ai,Ra=class extends Je{constructor(t,e,n){super(t,e),this.isInstancedMesh=!0,this.instanceMatrix=new Ca(new Float32Array(n*16),16),this.instanceColor=null,this.count=n,this.boundingBox=null,this.boundingSphere=null;for(let s=0;s<n;s++)this.setMatrixAt(s,B0)}computeBoundingBox(){let t=this.geometry,e=this.count;this.boundingBox===null&&(this.boundingBox=new ci),t.boundingBox===null&&t.computeBoundingBox(),this.boundingBox.makeEmpty();for(let n=0;n<e;n++)this.getMatrixAt(n,Ts),Oh.copy(t.boundingBox).applyMatrix4(Ts),this.boundingBox.union(Oh)}computeBoundingSphere(){let t=this.geometry,e=this.count;this.boundingSphere===null&&(this.boundingSphere=new Ai),t.boundingSphere===null&&t.computeBoundingSphere(),this.boundingSphere.makeEmpty();for(let n=0;n<e;n++)this.getMatrixAt(n,Ts),lr.copy(t.boundingSphere).applyMatrix4(Ts),this.boundingSphere.union(lr)}copy(t,e){return super.copy(t,e),this.instanceMatrix.copy(t.instanceMatrix),t.instanceColor!==null&&(this.instanceColor=t.instanceColor.clone()),this.count=t.count,t.boundingBox!==null&&(this.boundingBox=t.boundingBox.clone()),t.boundingSphere!==null&&(this.boundingSphere=t.boundingSphere.clone()),this}getColorAt(t,e){e.fromArray(this.instanceColor.array,t*3)}getMatrixAt(t,e){e.fromArray(this.instanceMatrix.array,t*16)}raycast(t,e){let n=this.matrixWorld,s=this.count;if(or.geometry=this.geometry,or.material=this.material,or.material!==void 0&&(this.boundingSphere===null&&this.computeBoundingSphere(),lr.copy(this.boundingSphere),lr.applyMatrix4(n),t.ray.intersectsSphere(lr)!==!1))for(let r=0;r<s;r++){this.getMatrixAt(r,Ts),Nh.multiplyMatrices(n,Ts),or.matrixWorld=Nh,or.raycast(t,sa);for(let o=0,a=sa.length;o<a;o++){let l=sa[o];l.instanceId=r,l.object=this,e.push(l)}sa.length=0}}setColorAt(t,e){this.instanceColor===null&&(this.instanceColor=new Ca(new Float32Array(this.instanceMatrix.count*3),3)),e.toArray(this.instanceColor.array,t*3)}setMatrixAt(t,e){e.toArray(this.instanceMatrix.array,t*16)}updateMorphTargets(){}dispose(){this.dispatchEvent({type:"dispose"})}};var br=class extends Ci{constructor(t){super(),this.isPointsMaterial=!0,this.type="PointsMaterial",this.color=new Xt(16777215),this.map=null,this.alphaMap=null,this.size=1,this.sizeAttenuation=!0,this.fog=!0,this.setValues(t)}copy(t){return super.copy(t),this.color.copy(t.color),this.map=t.map,this.alphaMap=t.alphaMap,this.size=t.size,this.sizeAttenuation=t.sizeAttenuation,this.fog=t.fog,this}},Fh=new _e,pl=new qi,ra=new Ai,aa=new B,Pa=class extends nn{constructor(t=new _n,e=new br){super(),this.isPoints=!0,this.type="Points",this.geometry=t,this.material=e,this.updateMorphTargets()}copy(t,e){return super.copy(t,e),this.material=Array.isArray(t.material)?t.material.slice():t.material,this.geometry=t.geometry,this}raycast(t,e){let n=this.geometry,s=this.matrixWorld,r=t.params.Points.threshold,o=n.drawRange;if(n.boundingSphere===null&&n.computeBoundingSphere(),ra.copy(n.boundingSphere),ra.applyMatrix4(s),ra.radius+=r,t.ray.intersectsSphere(ra)===!1)return;Fh.copy(s).invert(),pl.copy(t.ray).applyMatrix4(Fh);let a=r/((this.scale.x+this.scale.y+this.scale.z)/3),l=a*a,h=n.index,d=n.attributes.position;if(h!==null){let m=Math.max(0,o.start),x=Math.min(h.count,o.start+o.count);for(let v=m,M=x;v<M;v++){let g=h.getX(v);aa.fromBufferAttribute(d,g),Bh(aa,g,l,s,t,e,this)}}else{let m=Math.max(0,o.start),x=Math.min(d.count,o.start+o.count);for(let v=m,M=x;v<M;v++)aa.fromBufferAttribute(d,v),Bh(aa,v,l,s,t,e,this)}}updateMorphTargets(){let e=this.geometry.morphAttributes,n=Object.keys(e);if(n.length>0){let s=e[n[0]];if(s!==void 0){this.morphTargetInfluences=[],this.morphTargetDictionary={};for(let r=0,o=s.length;r<o;r++){let a=s[r].name||String(r);this.morphTargetInfluences.push(0),this.morphTargetDictionary[a]=r}}}}};function Bh(i,t,e,n,s,r,o){let a=pl.distanceSqToPoint(i);if(a<e){let l=new B;pl.closestPointToPoint(i,l),l.applyMatrix4(n);let h=s.ray.origin.distanceTo(l);if(h<s.near||h>s.far)return;r.push({distance:h,distanceToRay:Math.sqrt(a),point:l,index:t,face:null,object:o})}}var zs=class extends Sn{constructor(t,e,n,s,r,o,a,l,h){super(t,e,n,s,r,o,a,l,h),this.isCanvasTexture=!0,this.needsUpdate=!0}};var La=class i extends _n{constructor(t=1,e=32,n=0,s=Math.PI*2){super(),this.type="CircleGeometry",this.parameters={radius:t,segments:e,thetaStart:n,thetaLength:s},e=Math.max(3,e);let r=[],o=[],a=[],l=[],h=new B,u=new At;o.push(0,0,0),a.push(0,0,1),l.push(.5,.5);for(let d=0,m=3;d<=e;d++,m+=3){let x=n+d/e*s;h.x=t*Math.cos(x),h.y=t*Math.sin(x),o.push(h.x,h.y,h.z),a.push(0,0,1),u.x=(o[m]/t+1)/2,u.y=(o[m+1]/t+1)/2,l.push(u.x,u.y)}for(let d=1;d<=e;d++)r.push(d,d+1,0);this.setIndex(r),this.setAttribute("position",new hn(o,3)),this.setAttribute("normal",new hn(a,3)),this.setAttribute("uv",new hn(l,2))}copy(t){return super.copy(t),this.parameters=Object.assign({},t.parameters),this}static fromJSON(t){return new i(t.radius,t.segments,t.thetaStart,t.thetaLength)}};var Ia=class extends Be{constructor(t){super(t),this.isRawShaderMaterial=!0,this.type="RawShaderMaterial"}},Da=class extends Ci{constructor(t){super(),this.isMeshStandardMaterial=!0,this.defines={STANDARD:""},this.type="MeshStandardMaterial",this.color=new Xt(16777215),this.roughness=1,this.metalness=0,this.map=null,this.lightMap=null,this.lightMapIntensity=1,this.aoMap=null,this.aoMapIntensity=1,this.emissive=new Xt(0),this.emissiveIntensity=1,this.emissiveMap=null,this.bumpMap=null,this.bumpScale=1,this.normalMap=null,this.normalMapType=eu,this.normalScale=new At(1,1),this.displacementMap=null,this.displacementScale=1,this.displacementBias=0,this.roughnessMap=null,this.metalnessMap=null,this.alphaMap=null,this.envMap=null,this.envMapIntensity=1,this.wireframe=!1,this.wireframeLinewidth=1,this.wireframeLinecap="round",this.wireframeLinejoin="round",this.flatShading=!1,this.fog=!0,this.setValues(t)}copy(t){return super.copy(t),this.defines={STANDARD:""},this.color.copy(t.color),this.roughness=t.roughness,this.metalness=t.metalness,this.map=t.map,this.lightMap=t.lightMap,this.lightMapIntensity=t.lightMapIntensity,this.aoMap=t.aoMap,this.aoMapIntensity=t.aoMapIntensity,this.emissive.copy(t.emissive),this.emissiveMap=t.emissiveMap,this.emissiveIntensity=t.emissiveIntensity,this.bumpMap=t.bumpMap,this.bumpScale=t.bumpScale,this.normalMap=t.normalMap,this.normalMapType=t.normalMapType,this.normalScale.copy(t.normalScale),this.displacementMap=t.displacementMap,this.displacementScale=t.displacementScale,this.displacementBias=t.displacementBias,this.roughnessMap=t.roughnessMap,this.metalnessMap=t.metalnessMap,this.alphaMap=t.alphaMap,this.envMap=t.envMap,this.envMapIntensity=t.envMapIntensity,this.wireframe=t.wireframe,this.wireframeLinewidth=t.wireframeLinewidth,this.wireframeLinecap=t.wireframeLinecap,this.wireframeLinejoin=t.wireframeLinejoin,this.flatShading=t.flatShading,this.fog=t.fog,this}};function oa(i,t,e){return!i||!e&&i.constructor===t?i:typeof t.BYTES_PER_ELEMENT=="number"?new t(i):Array.prototype.slice.call(i)}function z0(i){return ArrayBuffer.isView(i)&&!(i instanceof DataView)}var ks=class{constructor(t,e,n,s){this.parameterPositions=t,this._cachedIndex=0,this.resultBuffer=s!==void 0?s:new e.constructor(n),this.sampleValues=e,this.valueSize=n,this.settings=null,this.DefaultSettings_={}}evaluate(t){let e=this.parameterPositions,n=this._cachedIndex,s=e[n],r=e[n-1];n:{t:{let o;e:{i:if(!(t<s)){for(let a=n+2;;){if(s===void 0){if(t<r)break i;return n=e.length,this._cachedIndex=n,this.copySampleValue_(n-1)}if(n===a)break;if(r=s,s=e[++n],t<s)break t}o=e.length;break e}if(!(t>=r)){let a=e[1];t<a&&(n=2,r=a);for(let l=n-2;;){if(r===void 0)return this._cachedIndex=0,this.copySampleValue_(0);if(n===l)break;if(s=r,r=e[--n-1],t>=r)break t}o=n,n=0;break e}break n}for(;n<o;){let a=n+o>>>1;t<e[a]?o=a:n=a+1}if(s=e[n],r=e[n-1],r===void 0)return this._cachedIndex=0,this.copySampleValue_(0);if(s===void 0)return n=e.length,this._cachedIndex=n,this.copySampleValue_(n-1)}this._cachedIndex=n,this.intervalChanged_(n,r,s)}return this.interpolate_(n,r,t,s)}getSettings_(){return this.settings||this.DefaultSettings_}copySampleValue_(t){let e=this.resultBuffer,n=this.sampleValues,s=this.valueSize,r=t*s;for(let o=0;o!==s;++o)e[o]=n[r+o];return e}interpolate_(){throw new Error("call to abstract method")}intervalChanged_(){}},ml=class extends ks{constructor(t,e,n,s){super(t,e,n,s),this._weightPrev=-0,this._offsetPrev=-0,this._weightNext=-0,this._offsetNext=-0,this.DefaultSettings_={endingStart:Xc,endingEnd:Xc}}intervalChanged_(t,e,n){let s=this.parameterPositions,r=t-2,o=t+1,a=s[r],l=s[o];if(a===void 0)switch(this.getSettings_().endingStart){case Yc:r=t,a=2*e-n;break;case qc:r=s.length-2,a=e+s[r]-s[r+1];break;default:r=t,a=n}if(l===void 0)switch(this.getSettings_().endingEnd){case Yc:o=t,l=2*n-e;break;case qc:o=1,l=n+s[1]-s[0];break;default:o=t-1,l=e}let h=(n-e)*.5,u=this.valueSize;this._weightPrev=h/(e-a),this._weightNext=h/(l-n),this._offsetPrev=r*u,this._offsetNext=o*u}interpolate_(t,e,n,s){let r=this.resultBuffer,o=this.sampleValues,a=this.valueSize,l=t*a,h=l-a,u=this._offsetPrev,d=this._offsetNext,m=this._weightPrev,x=this._weightNext,v=(n-e)/(s-e),M=v*v,g=M*v,f=-m*g+2*m*M-m*v,R=(1+m)*g+(-1.5-2*m)*M+(-.5+m)*v+1,E=(-1-x)*g+(1.5+x)*M+.5*v,L=x*g-x*M;for(let z=0;z!==a;++z)r[z]=f*o[u+z]+R*o[h+z]+E*o[l+z]+L*o[d+z];return r}},gl=class extends ks{constructor(t,e,n,s){super(t,e,n,s)}interpolate_(t,e,n,s){let r=this.resultBuffer,o=this.sampleValues,a=this.valueSize,l=t*a,h=l-a,u=(n-e)/(s-e),d=1-u;for(let m=0;m!==a;++m)r[m]=o[h+m]*d+o[l+m]*u;return r}},xl=class extends ks{constructor(t,e,n,s){super(t,e,n,s)}interpolate_(t){return this.copySampleValue_(t-1)}},Bn=class{constructor(t,e,n,s){if(t===void 0)throw new Error("THREE.KeyframeTrack: track name is undefined");if(e===void 0||e.length===0)throw new Error("THREE.KeyframeTrack: no keyframes in track named "+t);this.name=t,this.times=oa(e,this.TimeBufferType),this.values=oa(n,this.ValueBufferType),this.setInterpolation(s||this.DefaultInterpolation)}static toJSON(t){let e=t.constructor,n;if(e.toJSON!==this.toJSON)n=e.toJSON(t);else{n={name:t.name,times:oa(t.times,Array),values:oa(t.values,Array)};let s=t.getInterpolation();s!==t.DefaultInterpolation&&(n.interpolation=s)}return n.type=t.ValueTypeName,n}InterpolantFactoryMethodDiscrete(t){return new xl(this.times,this.values,this.getValueSize(),t)}InterpolantFactoryMethodLinear(t){return new gl(this.times,this.values,this.getValueSize(),t)}InterpolantFactoryMethodSmooth(t){return new ml(this.times,this.values,this.getValueSize(),t)}setInterpolation(t){let e;switch(t){case ca:e=this.InterpolantFactoryMethodDiscrete;break;case ha:e=this.InterpolantFactoryMethodLinear;break;case Mo:e=this.InterpolantFactoryMethodSmooth;break}if(e===void 0){let n="unsupported interpolation for "+this.ValueTypeName+" keyframe track named "+this.name;if(this.createInterpolant===void 0)if(t!==this.DefaultInterpolation)this.setInterpolation(this.DefaultInterpolation);else throw new Error(n);return console.warn("THREE.KeyframeTrack:",n),this}return this.createInterpolant=e,this}getInterpolation(){switch(this.createInterpolant){case this.InterpolantFactoryMethodDiscrete:return ca;case this.InterpolantFactoryMethodLinear:return ha;case this.InterpolantFactoryMethodSmooth:return Mo}}getValueSize(){return this.values.length/this.times.length}shift(t){if(t!==0){let e=this.times;for(let n=0,s=e.length;n!==s;++n)e[n]+=t}return this}scale(t){if(t!==1){let e=this.times;for(let n=0,s=e.length;n!==s;++n)e[n]*=t}return this}trim(t,e){let n=this.times,s=n.length,r=0,o=s-1;for(;r!==s&&n[r]<t;)++r;for(;o!==-1&&n[o]>e;)--o;if(++o,r!==0||o!==s){r>=o&&(o=Math.max(o,1),r=o-1);let a=this.getValueSize();this.times=n.slice(r,o),this.values=this.values.slice(r*a,o*a)}return this}validate(){let t=!0,e=this.getValueSize();e-Math.floor(e)!==0&&(console.error("THREE.KeyframeTrack: Invalid value size in track.",this),t=!1);let n=this.times,s=this.values,r=n.length;r===0&&(console.error("THREE.KeyframeTrack: Track is empty.",this),t=!1);let o=null;for(let a=0;a!==r;a++){let l=n[a];if(typeof l=="number"&&isNaN(l)){console.error("THREE.KeyframeTrack: Time is not a valid number.",this,a,l),t=!1;break}if(o!==null&&o>l){console.error("THREE.KeyframeTrack: Out of order keys.",this,a,l,o),t=!1;break}o=l}if(s!==void 0&&z0(s))for(let a=0,l=s.length;a!==l;++a){let h=s[a];if(isNaN(h)){console.error("THREE.KeyframeTrack: Value is not a valid number.",this,a,h),t=!1;break}}return t}optimize(){let t=this.times.slice(),e=this.values.slice(),n=this.getValueSize(),s=this.getInterpolation()===Mo,r=t.length-1,o=1;for(let a=1;a<r;++a){let l=!1,h=t[a],u=t[a+1];if(h!==u&&(a!==1||h!==t[0]))if(s)l=!0;else{let d=a*n,m=d-n,x=d+n;for(let v=0;v!==n;++v){let M=e[d+v];if(M!==e[m+v]||M!==e[x+v]){l=!0;break}}}if(l){if(a!==o){t[o]=t[a];let d=a*n,m=o*n;for(let x=0;x!==n;++x)e[m+x]=e[d+x]}++o}}if(r>0){t[o]=t[r];for(let a=r*n,l=o*n,h=0;h!==n;++h)e[l+h]=e[a+h];++o}return o!==t.length?(this.times=t.slice(0,o),this.values=e.slice(0,o*n)):(this.times=t,this.values=e),this}clone(){let t=this.times.slice(),e=this.values.slice(),n=this.constructor,s=new n(this.name,t,e);return s.createInterpolant=this.createInterpolant,s}};Bn.prototype.TimeBufferType=Float32Array;Bn.prototype.ValueBufferType=Float32Array;Bn.prototype.DefaultInterpolation=ha;var Ji=class extends Bn{};Ji.prototype.ValueTypeName="bool";Ji.prototype.ValueBufferType=Array;Ji.prototype.DefaultInterpolation=ca;Ji.prototype.InterpolantFactoryMethodLinear=void 0;Ji.prototype.InterpolantFactoryMethodSmooth=void 0;var _l=class extends Bn{};_l.prototype.ValueTypeName="color";var vl=class extends Bn{};vl.prototype.ValueTypeName="number";var yl=class extends ks{constructor(t,e,n,s){super(t,e,n,s)}interpolate_(t,e,n,s){let r=this.resultBuffer,o=this.sampleValues,a=this.valueSize,l=(n-e)/(s-e),h=t*a;for(let u=h+a;h!==u;h+=4)Fn.slerpFlat(r,0,o,h-a,o,h,l);return r}},Mr=class extends Bn{InterpolantFactoryMethodLinear(t){return new yl(this.times,this.values,this.getValueSize(),t)}};Mr.prototype.ValueTypeName="quaternion";Mr.prototype.DefaultInterpolation=ha;Mr.prototype.InterpolantFactoryMethodSmooth=void 0;var ji=class extends Bn{};ji.prototype.ValueTypeName="string";ji.prototype.ValueBufferType=Array;ji.prototype.DefaultInterpolation=ca;ji.prototype.InterpolantFactoryMethodLinear=void 0;ji.prototype.InterpolantFactoryMethodSmooth=void 0;var bl=class extends Bn{};bl.prototype.ValueTypeName="vector";var Ml=class{constructor(t,e,n){let s=this,r=!1,o=0,a=0,l,h=[];this.onStart=void 0,this.onLoad=t,this.onProgress=e,this.onError=n,this.itemStart=function(u){a++,r===!1&&s.onStart!==void 0&&s.onStart(u,o,a),r=!0},this.itemEnd=function(u){o++,s.onProgress!==void 0&&s.onProgress(u,o,a),o===a&&(r=!1,s.onLoad!==void 0&&s.onLoad())},this.itemError=function(u){s.onError!==void 0&&s.onError(u)},this.resolveURL=function(u){return l?l(u):u},this.setURLModifier=function(u){return l=u,this},this.addHandler=function(u,d){return h.push(u,d),this},this.removeHandler=function(u){let d=h.indexOf(u);return d!==-1&&h.splice(d,2),this},this.getHandler=function(u){for(let d=0,m=h.length;d<m;d+=2){let x=h[d],v=h[d+1];if(x.global&&(x.lastIndex=0),x.test(u))return v}return null}}},k0=new Ml,Sl=class{constructor(t){this.manager=t!==void 0?t:k0,this.crossOrigin="anonymous",this.withCredentials=!1,this.path="",this.resourcePath="",this.requestHeader={}}load(){}loadAsync(t,e){let n=this;return new Promise(function(s,r){n.load(t,s,e,r)})}parse(){}setCrossOrigin(t){return this.crossOrigin=t,this}setWithCredentials(t){return this.withCredentials=t,this}setPath(t){return this.path=t,this}setResourcePath(t){return this.resourcePath=t,this}setRequestHeader(t){return this.requestHeader=t,this}};Sl.DEFAULT_MATERIAL_NAME="__DEFAULT";var Sr=class extends nn{constructor(t,e=1){super(),this.isLight=!0,this.type="Light",this.color=new Xt(t),this.intensity=e}dispose(){}copy(t,e){return super.copy(t,e),this.color.copy(t.color),this.intensity=t.intensity,this}toJSON(t){let e=super.toJSON(t);return e.object.color=this.color.getHex(),e.object.intensity=this.intensity,this.groundColor!==void 0&&(e.object.groundColor=this.groundColor.getHex()),this.distance!==void 0&&(e.object.distance=this.distance),this.angle!==void 0&&(e.object.angle=this.angle),this.decay!==void 0&&(e.object.decay=this.decay),this.penumbra!==void 0&&(e.object.penumbra=this.penumbra),this.shadow!==void 0&&(e.object.shadow=this.shadow.toJSON()),e}},Ua=class extends Sr{constructor(t,e,n){super(t,n),this.isHemisphereLight=!0,this.type="HemisphereLight",this.position.copy(nn.DEFAULT_UP),this.updateMatrix(),this.groundColor=new Xt(e)}copy(t,e){return super.copy(t,e),this.groundColor.copy(t.groundColor),this}},Xo=new _e,zh=new B,kh=new B,Na=class{constructor(t){this.camera=t,this.bias=0,this.normalBias=0,this.radius=1,this.blurSamples=8,this.mapSize=new At(512,512),this.map=null,this.mapPass=null,this.matrix=new _e,this.autoUpdate=!0,this.needsUpdate=!1,this._frustum=new _r,this._frameExtents=new At(1,1),this._viewportCount=1,this._viewports=[new Se(0,0,1,1)]}getViewportCount(){return this._viewportCount}getFrustum(){return this._frustum}updateMatrices(t){let e=this.camera,n=this.matrix;zh.setFromMatrixPosition(t.matrixWorld),e.position.copy(zh),kh.setFromMatrixPosition(t.target.matrixWorld),e.lookAt(kh),e.updateMatrixWorld(),Xo.multiplyMatrices(e.projectionMatrix,e.matrixWorldInverse),this._frustum.setFromProjectionMatrix(Xo),n.set(.5,0,0,.5,0,.5,0,.5,0,0,.5,.5,0,0,0,1),n.multiply(Xo)}getViewport(t){return this._viewports[t]}getFrameExtents(){return this._frameExtents}dispose(){this.map&&this.map.dispose(),this.mapPass&&this.mapPass.dispose()}copy(t){return this.camera=t.camera.clone(),this.bias=t.bias,this.radius=t.radius,this.mapSize.copy(t.mapSize),this}clone(){return new this.constructor().copy(this)}toJSON(){let t={};return this.bias!==0&&(t.bias=this.bias),this.normalBias!==0&&(t.normalBias=this.normalBias),this.radius!==1&&(t.radius=this.radius),(this.mapSize.x!==512||this.mapSize.y!==512)&&(t.mapSize=this.mapSize.toArray()),t.camera=this.camera.toJSON(!1).object,delete t.camera.matrix,t}};var Hh=new _e,cr=new B,Yo=new B,wl=class extends Na{constructor(){super(new en(90,1,.5,500)),this.isPointLightShadow=!0,this._frameExtents=new At(4,2),this._viewportCount=6,this._viewports=[new Se(2,1,1,1),new Se(0,1,1,1),new Se(3,1,1,1),new Se(1,1,1,1),new Se(3,0,1,1),new Se(1,0,1,1)],this._cubeDirections=[new B(1,0,0),new B(-1,0,0),new B(0,0,1),new B(0,0,-1),new B(0,1,0),new B(0,-1,0)],this._cubeUps=[new B(0,1,0),new B(0,1,0),new B(0,1,0),new B(0,1,0),new B(0,0,1),new B(0,0,-1)]}updateMatrices(t,e=0){let n=this.camera,s=this.matrix,r=t.distance||n.far;r!==n.far&&(n.far=r,n.updateProjectionMatrix()),cr.setFromMatrixPosition(t.matrixWorld),n.position.copy(cr),Yo.copy(n.position),Yo.add(this._cubeDirections[e]),n.up.copy(this._cubeUps[e]),n.lookAt(Yo),n.updateMatrixWorld(),s.makeTranslation(-cr.x,-cr.y,-cr.z),Hh.multiplyMatrices(n.projectionMatrix,n.matrixWorldInverse),this._frustum.setFromProjectionMatrix(Hh)}},Oa=class extends Sr{constructor(t,e,n=0,s=2){super(t,e),this.isPointLight=!0,this.type="PointLight",this.distance=n,this.decay=s,this.shadow=new wl}get power(){return this.intensity*4*Math.PI}set power(t){this.intensity=t/(4*Math.PI)}dispose(){this.shadow.dispose()}copy(t,e){return super.copy(t,e),this.distance=t.distance,this.decay=t.decay,this.shadow=t.shadow.clone(),this}},El=class extends Na{constructor(){super(new Bs(-5,5,5,-5,.5,500)),this.isDirectionalLightShadow=!0}},Fa=class extends Sr{constructor(t,e){super(t,e),this.isDirectionalLight=!0,this.type="DirectionalLight",this.position.copy(nn.DEFAULT_UP),this.updateMatrix(),this.target=new nn,this.shadow=new El}dispose(){this.shadow.dispose()}copy(t){return super.copy(t),this.target=t.target.clone(),this.shadow=t.shadow.clone(),this}};var Ba=class{constructor(t=!0){this.autoStart=t,this.startTime=0,this.oldTime=0,this.elapsedTime=0,this.running=!1}start(){this.startTime=Vh(),this.oldTime=this.startTime,this.elapsedTime=0,this.running=!0}stop(){this.getElapsedTime(),this.running=!1,this.autoStart=!1}getElapsedTime(){return this.getDelta(),this.elapsedTime}getDelta(){let t=0;if(this.autoStart&&!this.running)return this.start(),0;if(this.running){let e=Vh();t=(e-this.oldTime)/1e3,this.oldTime=e,this.elapsedTime+=t}return t}};function Vh(){return(typeof performance>"u"?Date:performance).now()}var zl="\\[\\]\\.:\\/",H0=new RegExp("["+zl+"]","g"),kl="[^"+zl+"]",V0="[^"+zl.replace("\\.","")+"]",G0=/((?:WC+[\/:])*)/.source.replace("WC",kl),W0=/(WCOD+)?/.source.replace("WCOD",V0),X0=/(?:\.(WC+)(?:\[(.+)\])?)?/.source.replace("WC",kl),Y0=/\.(WC+)(?:\[(.+)\])?/.source.replace("WC",kl),q0=new RegExp("^"+G0+W0+X0+Y0+"$"),Z0=["material","materials","bones","map"],Tl=class{constructor(t,e,n){let s=n||Me.parseTrackName(e);this._targetGroup=t,this._bindings=t.subscribe_(e,s)}getValue(t,e){this.bind();let n=this._targetGroup.nCachedObjects_,s=this._bindings[n];s!==void 0&&s.getValue(t,e)}setValue(t,e){let n=this._bindings;for(let s=this._targetGroup.nCachedObjects_,r=n.length;s!==r;++s)n[s].setValue(t,e)}bind(){let t=this._bindings;for(let e=this._targetGroup.nCachedObjects_,n=t.length;e!==n;++e)t[e].bind()}unbind(){let t=this._bindings;for(let e=this._targetGroup.nCachedObjects_,n=t.length;e!==n;++e)t[e].unbind()}},Me=class i{constructor(t,e,n){this.path=e,this.parsedPath=n||i.parseTrackName(e),this.node=i.findNode(t,this.parsedPath.nodeName),this.rootNode=t,this.getValue=this._getValue_unbound,this.setValue=this._setValue_unbound}static create(t,e,n){return t&&t.isAnimationObjectGroup?new i.Composite(t,e,n):new i(t,e,n)}static sanitizeNodeName(t){return t.replace(/\s/g,"_").replace(H0,"")}static parseTrackName(t){let e=q0.exec(t);if(e===null)throw new Error("PropertyBinding: Cannot parse trackName: "+t);let n={nodeName:e[2],objectName:e[3],objectIndex:e[4],propertyName:e[5],propertyIndex:e[6]},s=n.nodeName&&n.nodeName.lastIndexOf(".");if(s!==void 0&&s!==-1){let r=n.nodeName.substring(s+1);Z0.indexOf(r)!==-1&&(n.nodeName=n.nodeName.substring(0,s),n.objectName=r)}if(n.propertyName===null||n.propertyName.length===0)throw new Error("PropertyBinding: can not parse propertyName from trackName: "+t);return n}static findNode(t,e){if(e===void 0||e===""||e==="."||e===-1||e===t.name||e===t.uuid)return t;if(t.skeleton){let n=t.skeleton.getBoneByName(e);if(n!==void 0)return n}if(t.children){let n=function(r){for(let o=0;o<r.length;o++){let a=r[o];if(a.name===e||a.uuid===e)return a;let l=n(a.children);if(l)return l}return null},s=n(t.children);if(s)return s}return null}_getValue_unavailable(){}_setValue_unavailable(){}_getValue_direct(t,e){t[e]=this.targetObject[this.propertyName]}_getValue_array(t,e){let n=this.resolvedProperty;for(let s=0,r=n.length;s!==r;++s)t[e++]=n[s]}_getValue_arrayElement(t,e){t[e]=this.resolvedProperty[this.propertyIndex]}_getValue_toArray(t,e){this.resolvedProperty.toArray(t,e)}_setValue_direct(t,e){this.targetObject[this.propertyName]=t[e]}_setValue_direct_setNeedsUpdate(t,e){this.targetObject[this.propertyName]=t[e],this.targetObject.needsUpdate=!0}_setValue_direct_setMatrixWorldNeedsUpdate(t,e){this.targetObject[this.propertyName]=t[e],this.targetObject.matrixWorldNeedsUpdate=!0}_setValue_array(t,e){let n=this.resolvedProperty;for(let s=0,r=n.length;s!==r;++s)n[s]=t[e++]}_setValue_array_setNeedsUpdate(t,e){let n=this.resolvedProperty;for(let s=0,r=n.length;s!==r;++s)n[s]=t[e++];this.targetObject.needsUpdate=!0}_setValue_array_setMatrixWorldNeedsUpdate(t,e){let n=this.resolvedProperty;for(let s=0,r=n.length;s!==r;++s)n[s]=t[e++];this.targetObject.matrixWorldNeedsUpdate=!0}_setValue_arrayElement(t,e){this.resolvedProperty[this.propertyIndex]=t[e]}_setValue_arrayElement_setNeedsUpdate(t,e){this.resolvedProperty[this.propertyIndex]=t[e],this.targetObject.needsUpdate=!0}_setValue_arrayElement_setMatrixWorldNeedsUpdate(t,e){this.resolvedProperty[this.propertyIndex]=t[e],this.targetObject.matrixWorldNeedsUpdate=!0}_setValue_fromArray(t,e){this.resolvedProperty.fromArray(t,e)}_setValue_fromArray_setNeedsUpdate(t,e){this.resolvedProperty.fromArray(t,e),this.targetObject.needsUpdate=!0}_setValue_fromArray_setMatrixWorldNeedsUpdate(t,e){this.resolvedProperty.fromArray(t,e),this.targetObject.matrixWorldNeedsUpdate=!0}_getValue_unbound(t,e){this.bind(),this.getValue(t,e)}_setValue_unbound(t,e){this.bind(),this.setValue(t,e)}bind(){let t=this.node,e=this.parsedPath,n=e.objectName,s=e.propertyName,r=e.propertyIndex;if(t||(t=i.findNode(this.rootNode,e.nodeName),this.node=t),this.getValue=this._getValue_unavailable,this.setValue=this._setValue_unavailable,!t){console.warn("THREE.PropertyBinding: No target node found for track: "+this.path+".");return}if(n){let h=e.objectIndex;switch(n){case"materials":if(!t.material){console.error("THREE.PropertyBinding: Can not bind to material as node does not have a material.",this);return}if(!t.material.materials){console.error("THREE.PropertyBinding: Can not bind to material.materials as node.material does not have a materials array.",this);return}t=t.material.materials;break;case"bones":if(!t.skeleton){console.error("THREE.PropertyBinding: Can not bind to bones as node does not have a skeleton.",this);return}t=t.skeleton.bones;for(let u=0;u<t.length;u++)if(t[u].name===h){h=u;break}break;case"map":if("map"in t){t=t.map;break}if(!t.material){console.error("THREE.PropertyBinding: Can not bind to material as node does not have a material.",this);return}if(!t.material.map){console.error("THREE.PropertyBinding: Can not bind to material.map as node.material does not have a map.",this);return}t=t.material.map;break;default:if(t[n]===void 0){console.error("THREE.PropertyBinding: Can not bind to objectName of node undefined.",this);return}t=t[n]}if(h!==void 0){if(t[h]===void 0){console.error("THREE.PropertyBinding: Trying to bind to objectIndex of objectName, but is undefined.",this,t);return}t=t[h]}}let o=t[s];if(o===void 0){let h=e.nodeName;console.error("THREE.PropertyBinding: Trying to update property for track: "+h+"."+s+" but it wasn't found.",t);return}let a=this.Versioning.None;this.targetObject=t,t.needsUpdate!==void 0?a=this.Versioning.NeedsUpdate:t.matrixWorldNeedsUpdate!==void 0&&(a=this.Versioning.MatrixWorldNeedsUpdate);let l=this.BindingType.Direct;if(r!==void 0){if(s==="morphTargetInfluences"){if(!t.geometry){console.error("THREE.PropertyBinding: Can not bind to morphTargetInfluences because node does not have a geometry.",this);return}if(!t.geometry.morphAttributes){console.error("THREE.PropertyBinding: Can not bind to morphTargetInfluences because node does not have a geometry.morphAttributes.",this);return}t.morphTargetDictionary[r]!==void 0&&(r=t.morphTargetDictionary[r])}l=this.BindingType.ArrayElement,this.resolvedProperty=o,this.propertyIndex=r}else o.fromArray!==void 0&&o.toArray!==void 0?(l=this.BindingType.HasFromToArray,this.resolvedProperty=o):Array.isArray(o)?(l=this.BindingType.EntireArray,this.resolvedProperty=o):this.propertyName=s;this.getValue=this.GetterByBindingType[l],this.setValue=this.SetterByBindingTypeAndVersioning[l][a]}unbind(){this.node=null,this.getValue=this._getValue_unbound,this.setValue=this._setValue_unbound}};Me.Composite=Tl;Me.prototype.BindingType={Direct:0,EntireArray:1,ArrayElement:2,HasFromToArray:3};Me.prototype.Versioning={None:0,NeedsUpdate:1,MatrixWorldNeedsUpdate:2};Me.prototype.GetterByBindingType=[Me.prototype._getValue_direct,Me.prototype._getValue_array,Me.prototype._getValue_arrayElement,Me.prototype._getValue_toArray];Me.prototype.SetterByBindingTypeAndVersioning=[[Me.prototype._setValue_direct,Me.prototype._setValue_direct_setNeedsUpdate,Me.prototype._setValue_direct_setMatrixWorldNeedsUpdate],[Me.prototype._setValue_array,Me.prototype._setValue_array_setNeedsUpdate,Me.prototype._setValue_array_setMatrixWorldNeedsUpdate],[Me.prototype._setValue_arrayElement,Me.prototype._setValue_arrayElement_setNeedsUpdate,Me.prototype._setValue_arrayElement_setMatrixWorldNeedsUpdate],[Me.prototype._setValue_fromArray,Me.prototype._setValue_fromArray_setNeedsUpdate,Me.prototype._setValue_fromArray_setMatrixWorldNeedsUpdate]];var nx=new Float32Array(1);var za=class{constructor(t,e,n=0,s=1/0){this.ray=new qi(t,e),this.near=n,this.far=s,this.camera=null,this.layers=new xr,this.params={Mesh:{},Line:{threshold:1},LOD:{},Points:{threshold:1},Sprite:{}}}set(t,e){this.ray.set(t,e)}setFromCamera(t,e){e.isPerspectiveCamera?(this.ray.origin.setFromMatrixPosition(e.matrixWorld),this.ray.direction.set(t.x,t.y,.5).unproject(e).sub(this.ray.origin).normalize(),this.camera=e):e.isOrthographicCamera?(this.ray.origin.set(t.x,t.y,(e.near+e.far)/(e.near-e.far)).unproject(e),this.ray.direction.set(0,0,-1).transformDirection(e.matrixWorld),this.camera=e):console.error("THREE.Raycaster: Unsupported camera type: "+e.type)}intersectObject(t,e=!0,n=[]){return Al(t,this,n,e),n.sort(Gh),n}intersectObjects(t,e=!0,n=[]){for(let s=0,r=t.length;s<r;s++)Al(t[s],this,n,e);return n.sort(Gh),n}};function Gh(i,t){return i.distance-t.distance}function Al(i,t,e,n){if(i.layers.test(t.layers)&&i.raycast(t,e),n===!0){let s=i.children;for(let r=0,o=s.length;r<o;r++)Al(s[r],t,e,!0)}}var wr=class{constructor(t=1,e=0,n=0){return this.radius=t,this.phi=e,this.theta=n,this}set(t,e,n){return this.radius=t,this.phi=e,this.theta=n,this}copy(t){return this.radius=t.radius,this.phi=t.phi,this.theta=t.theta,this}makeSafe(){return this.phi=Math.max(1e-6,Math.min(Math.PI-1e-6,this.phi)),this}setFromVector3(t){return this.setFromCartesianCoords(t.x,t.y,t.z)}setFromCartesianCoords(t,e,n){return this.radius=Math.sqrt(t*t+e*e+n*n),this.radius===0?(this.theta=0,this.phi=0):(this.theta=Math.atan2(t,n),this.phi=Math.acos(tn(e/this.radius,-1,1))),this}clone(){return new this.constructor().copy(this)}};typeof __THREE_DEVTOOLS__<"u"&&__THREE_DEVTOOLS__.dispatchEvent(new CustomEvent("register",{detail:{revision:"160"}}));typeof window<"u"&&(window.__THREE__?console.warn("WARNING: Multiple instances of Three.js being imported."):window.__THREE__="160");var fu={type:"change"},Hl={type:"start"},pu={type:"end"},Wa=new qi,mu=new Dn,j0=Math.cos(70*iu.DEG2RAD),Xa=class extends Jn{constructor(t,e){super(),this.object=t,this.domElement=e,this.domElement.style.touchAction="none",this.enabled=!0,this.target=new B,this.cursor=new B,this.minDistance=0,this.maxDistance=1/0,this.minZoom=0,this.maxZoom=1/0,this.minTargetRadius=0,this.maxTargetRadius=1/0,this.minPolarAngle=0,this.maxPolarAngle=Math.PI,this.minAzimuthAngle=-1/0,this.maxAzimuthAngle=1/0,this.enableDamping=!1,this.dampingFactor=.05,this.enableZoom=!0,this.zoomSpeed=1,this.enableRotate=!0,this.rotateSpeed=1,this.enablePan=!0,this.panSpeed=1,this.screenSpacePanning=!0,this.keyPanSpeed=7,this.zoomToCursor=!1,this.autoRotate=!1,this.autoRotateSpeed=2,this.keys={LEFT:"ArrowLeft",UP:"ArrowUp",RIGHT:"ArrowRight",BOTTOM:"ArrowDown"},this.mouseButtons={LEFT:$i.ROTATE,MIDDLE:$i.DOLLY,RIGHT:$i.PAN},this.touches={ONE:Ki.ROTATE,TWO:Ki.DOLLY_PAN},this.target0=this.target.clone(),this.position0=this.object.position.clone(),this.zoom0=this.object.zoom,this._domElementKeyEvents=null,this.getPolarAngle=function(){return a.phi},this.getAzimuthalAngle=function(){return a.theta},this.getDistance=function(){return this.object.position.distanceTo(this.target)},this.listenToKeyEvents=function(P){P.addEventListener("keydown",ct),this._domElementKeyEvents=P},this.stopListenToKeyEvents=function(){this._domElementKeyEvents.removeEventListener("keydown",ct),this._domElementKeyEvents=null},this.saveState=function(){n.target0.copy(n.target),n.position0.copy(n.object.position),n.zoom0=n.object.zoom},this.reset=function(){n.target.copy(n.target0),n.object.position.copy(n.position0),n.object.zoom=n.zoom0,n.object.updateProjectionMatrix(),n.dispatchEvent(fu),n.update(),r=s.NONE},this.update=(function(){let P=new B,lt=new Fn().setFromUnitVectors(t.up,new B(0,1,0)),_t=lt.clone().invert(),dt=new B,Nt=new Fn,$t=new B,re=2*Math.PI;return function(gt=null){let U=n.object.position;P.copy(U).sub(n.target),P.applyQuaternion(lt),a.setFromVector3(P),n.autoRotate&&r===s.NONE&&X(w(gt)),n.enableDamping?(a.theta+=l.theta*n.dampingFactor,a.phi+=l.phi*n.dampingFactor):(a.theta+=l.theta,a.phi+=l.phi);let ft=n.minAzimuthAngle,xt=n.maxAzimuthAngle;isFinite(ft)&&isFinite(xt)&&(ft<-Math.PI?ft+=re:ft>Math.PI&&(ft-=re),xt<-Math.PI?xt+=re:xt>Math.PI&&(xt-=re),ft<=xt?a.theta=Math.max(ft,Math.min(xt,a.theta)):a.theta=a.theta>(ft+xt)/2?Math.max(ft,a.theta):Math.min(xt,a.theta)),a.phi=Math.max(n.minPolarAngle,Math.min(n.maxPolarAngle,a.phi)),a.makeSafe(),n.enableDamping===!0?n.target.addScaledVector(u,n.dampingFactor):n.target.add(u),n.target.sub(n.cursor),n.target.clampLength(n.minTargetRadius,n.maxTargetRadius),n.target.add(n.cursor),n.zoomToCursor&&N||n.object.isOrthographicCamera?a.radius=K(a.radius):a.radius=K(a.radius*h),P.setFromSpherical(a),P.applyQuaternion(_t),U.copy(n.target).add(P),n.object.lookAt(n.target),n.enableDamping===!0?(l.theta*=1-n.dampingFactor,l.phi*=1-n.dampingFactor,u.multiplyScalar(1-n.dampingFactor)):(l.set(0,0,0),u.set(0,0,0));let Pt=!1;if(n.zoomToCursor&&N){let Ot=null;if(n.object.isPerspectiveCamera){let le=P.length();Ot=K(le*h);let he=le-Ot;n.object.position.addScaledVector(L,he),n.object.updateMatrixWorld()}else if(n.object.isOrthographicCamera){let le=new B(z.x,z.y,0);le.unproject(n.object),n.object.zoom=Math.max(n.minZoom,Math.min(n.maxZoom,n.object.zoom/h)),n.object.updateProjectionMatrix(),Pt=!0;let he=new B(z.x,z.y,0);he.unproject(n.object),n.object.position.sub(he).add(le),n.object.updateMatrixWorld(),Ot=P.length()}else console.warn("WARNING: OrbitControls.js encountered an unknown camera type - zoom to cursor disabled."),n.zoomToCursor=!1;Ot!==null&&(this.screenSpacePanning?n.target.set(0,0,-1).transformDirection(n.object.matrix).multiplyScalar(Ot).add(n.object.position):(Wa.origin.copy(n.object.position),Wa.direction.set(0,0,-1).transformDirection(n.object.matrix),Math.abs(n.object.up.dot(Wa.direction))<j0?t.lookAt(n.target):(mu.setFromNormalAndCoplanarPoint(n.object.up,n.target),Wa.intersectPlane(mu,n.target))))}else n.object.isOrthographicCamera&&(n.object.zoom=Math.max(n.minZoom,Math.min(n.maxZoom,n.object.zoom/h)),n.object.updateProjectionMatrix(),Pt=!0);return h=1,N=!1,Pt||dt.distanceToSquared(n.object.position)>o||8*(1-Nt.dot(n.object.quaternion))>o||$t.distanceToSquared(n.target)>0?(n.dispatchEvent(fu),dt.copy(n.object.position),Nt.copy(n.object.quaternion),$t.copy(n.target),!0):!1}})(),this.dispose=function(){n.domElement.removeEventListener("contextmenu",yt),n.domElement.removeEventListener("pointerdown",Yt),n.domElement.removeEventListener("pointercancel",b),n.domElement.removeEventListener("wheel",ot),n.domElement.removeEventListener("pointermove",C),n.domElement.removeEventListener("pointerup",b),n._domElementKeyEvents!==null&&(n._domElementKeyEvents.removeEventListener("keydown",ct),n._domElementKeyEvents=null)};let n=this,s={NONE:-1,ROTATE:0,DOLLY:1,PAN:2,TOUCH_ROTATE:3,TOUCH_PAN:4,TOUCH_DOLLY_PAN:5,TOUCH_DOLLY_ROTATE:6},r=s.NONE,o=1e-6,a=new wr,l=new wr,h=1,u=new B,d=new At,m=new At,x=new At,v=new At,M=new At,g=new At,f=new At,R=new At,E=new At,L=new B,z=new At,N=!1,I=[],it={};function w(P){return P!==null?2*Math.PI/60*n.autoRotateSpeed*P:2*Math.PI/60/60*n.autoRotateSpeed}function A(P){let lt=Math.abs(P)/(100*(window.devicePixelRatio|0));return Math.pow(.95,n.zoomSpeed*lt)}function X(P){l.theta-=P}function tt(P){l.phi-=P}let at=(function(){let P=new B;return function(_t,dt){P.setFromMatrixColumn(dt,0),P.multiplyScalar(-_t),u.add(P)}})(),F=(function(){let P=new B;return function(_t,dt){n.screenSpacePanning===!0?P.setFromMatrixColumn(dt,1):(P.setFromMatrixColumn(dt,0),P.crossVectors(n.object.up,P)),P.multiplyScalar(_t),u.add(P)}})(),V=(function(){let P=new B;return function(_t,dt){let Nt=n.domElement;if(n.object.isPerspectiveCamera){let $t=n.object.position;P.copy($t).sub(n.target);let re=P.length();re*=Math.tan(n.object.fov/2*Math.PI/180),at(2*_t*re/Nt.clientHeight,n.object.matrix),F(2*dt*re/Nt.clientHeight,n.object.matrix)}else n.object.isOrthographicCamera?(at(_t*(n.object.right-n.object.left)/n.object.zoom/Nt.clientWidth,n.object.matrix),F(dt*(n.object.top-n.object.bottom)/n.object.zoom/Nt.clientHeight,n.object.matrix)):(console.warn("WARNING: OrbitControls.js encountered an unknown camera type - pan disabled."),n.enablePan=!1)}})();function Z(P){n.object.isPerspectiveCamera||n.object.isOrthographicCamera?h/=P:(console.warn("WARNING: OrbitControls.js encountered an unknown camera type - dolly/zoom disabled."),n.enableZoom=!1)}function k(P){n.object.isPerspectiveCamera||n.object.isOrthographicCamera?h*=P:(console.warn("WARNING: OrbitControls.js encountered an unknown camera type - dolly/zoom disabled."),n.enableZoom=!1)}function $(P,lt){if(!n.zoomToCursor)return;N=!0;let _t=n.domElement.getBoundingClientRect(),dt=P-_t.left,Nt=lt-_t.top,$t=_t.width,re=_t.height;z.x=dt/$t*2-1,z.y=-(Nt/re)*2+1,L.set(z.x,z.y,1).unproject(n.object).sub(n.object.position).normalize()}function K(P){return Math.max(n.minDistance,Math.min(n.maxDistance,P))}function et(P){d.set(P.clientX,P.clientY)}function rt(P){$(P.clientX,P.clientX),f.set(P.clientX,P.clientY)}function vt(P){v.set(P.clientX,P.clientY)}function G(P){m.set(P.clientX,P.clientY),x.subVectors(m,d).multiplyScalar(n.rotateSpeed);let lt=n.domElement;X(2*Math.PI*x.x/lt.clientHeight),tt(2*Math.PI*x.y/lt.clientHeight),d.copy(m),n.update()}function nt(P){R.set(P.clientX,P.clientY),E.subVectors(R,f),E.y>0?Z(A(E.y)):E.y<0&&k(A(E.y)),f.copy(R),n.update()}function mt(P){M.set(P.clientX,P.clientY),g.subVectors(M,v).multiplyScalar(n.panSpeed),V(g.x,g.y),v.copy(M),n.update()}function Tt(P){$(P.clientX,P.clientY),P.deltaY<0?k(A(P.deltaY)):P.deltaY>0&&Z(A(P.deltaY)),n.update()}function It(P){let lt=!1;switch(P.code){case n.keys.UP:P.ctrlKey||P.metaKey||P.shiftKey?tt(2*Math.PI*n.rotateSpeed/n.domElement.clientHeight):V(0,n.keyPanSpeed),lt=!0;break;case n.keys.BOTTOM:P.ctrlKey||P.metaKey||P.shiftKey?tt(-2*Math.PI*n.rotateSpeed/n.domElement.clientHeight):V(0,-n.keyPanSpeed),lt=!0;break;case n.keys.LEFT:P.ctrlKey||P.metaKey||P.shiftKey?X(2*Math.PI*n.rotateSpeed/n.domElement.clientHeight):V(n.keyPanSpeed,0),lt=!0;break;case n.keys.RIGHT:P.ctrlKey||P.metaKey||P.shiftKey?X(-2*Math.PI*n.rotateSpeed/n.domElement.clientHeight):V(-n.keyPanSpeed,0),lt=!0;break}lt&&(P.preventDefault(),n.update())}function Wt(P){if(I.length===1)d.set(P.pageX,P.pageY);else{let lt=ne(P),_t=.5*(P.pageX+lt.x),dt=.5*(P.pageY+lt.y);d.set(_t,dt)}}function Ht(P){if(I.length===1)v.set(P.pageX,P.pageY);else{let lt=ne(P),_t=.5*(P.pageX+lt.x),dt=.5*(P.pageY+lt.y);v.set(_t,dt)}}function Bt(P){let lt=ne(P),_t=P.pageX-lt.x,dt=P.pageY-lt.y,Nt=Math.sqrt(_t*_t+dt*dt);f.set(0,Nt)}function ee(P){n.enableZoom&&Bt(P),n.enablePan&&Ht(P)}function q(P){n.enableZoom&&Bt(P),n.enableRotate&&Wt(P)}function Pe(P){if(I.length==1)m.set(P.pageX,P.pageY);else{let _t=ne(P),dt=.5*(P.pageX+_t.x),Nt=.5*(P.pageY+_t.y);m.set(dt,Nt)}x.subVectors(m,d).multiplyScalar(n.rotateSpeed);let lt=n.domElement;X(2*Math.PI*x.x/lt.clientHeight),tt(2*Math.PI*x.y/lt.clientHeight),d.copy(m)}function Ft(P){if(I.length===1)M.set(P.pageX,P.pageY);else{let lt=ne(P),_t=.5*(P.pageX+lt.x),dt=.5*(P.pageY+lt.y);M.set(_t,dt)}g.subVectors(M,v).multiplyScalar(n.panSpeed),V(g.x,g.y),v.copy(M)}function Vt(P){let lt=ne(P),_t=P.pageX-lt.x,dt=P.pageY-lt.y,Nt=Math.sqrt(_t*_t+dt*dt);R.set(0,Nt),E.set(0,Math.pow(R.y/f.y,n.zoomSpeed)),Z(E.y),f.copy(R);let $t=(P.pageX+lt.x)*.5,re=(P.pageY+lt.y)*.5;$($t,re)}function Rt(P){n.enableZoom&&Vt(P),n.enablePan&&Ft(P)}function pe(P){n.enableZoom&&Vt(P),n.enableRotate&&Pe(P)}function Yt(P){n.enabled!==!1&&(I.length===0&&(n.domElement.setPointerCapture(P.pointerId),n.domElement.addEventListener("pointermove",C),n.domElement.addEventListener("pointerup",b)),kt(P),P.pointerType==="touch"?Lt(P):Y(P))}function C(P){n.enabled!==!1&&(P.pointerType==="touch"?St(P):Q(P))}function b(P){Gt(P),I.length===0&&(n.domElement.releasePointerCapture(P.pointerId),n.domElement.removeEventListener("pointermove",C),n.domElement.removeEventListener("pointerup",b)),n.dispatchEvent(pu),r=s.NONE}function Y(P){let lt;switch(P.button){case 0:lt=n.mouseButtons.LEFT;break;case 1:lt=n.mouseButtons.MIDDLE;break;case 2:lt=n.mouseButtons.RIGHT;break;default:lt=-1}switch(lt){case $i.DOLLY:if(n.enableZoom===!1)return;rt(P),r=s.DOLLY;break;case $i.ROTATE:if(P.ctrlKey||P.metaKey||P.shiftKey){if(n.enablePan===!1)return;vt(P),r=s.PAN}else{if(n.enableRotate===!1)return;et(P),r=s.ROTATE}break;case $i.PAN:if(P.ctrlKey||P.metaKey||P.shiftKey){if(n.enableRotate===!1)return;et(P),r=s.ROTATE}else{if(n.enablePan===!1)return;vt(P),r=s.PAN}break;default:r=s.NONE}r!==s.NONE&&n.dispatchEvent(Hl)}function Q(P){switch(r){case s.ROTATE:if(n.enableRotate===!1)return;G(P);break;case s.DOLLY:if(n.enableZoom===!1)return;nt(P);break;case s.PAN:if(n.enablePan===!1)return;mt(P);break}}function ot(P){n.enabled===!1||n.enableZoom===!1||r!==s.NONE||(P.preventDefault(),n.dispatchEvent(Hl),Tt(P),n.dispatchEvent(pu))}function ct(P){n.enabled===!1||n.enablePan===!1||It(P)}function Lt(P){switch(ht(P),I.length){case 1:switch(n.touches.ONE){case Ki.ROTATE:if(n.enableRotate===!1)return;Wt(P),r=s.TOUCH_ROTATE;break;case Ki.PAN:if(n.enablePan===!1)return;Ht(P),r=s.TOUCH_PAN;break;default:r=s.NONE}break;case 2:switch(n.touches.TWO){case Ki.DOLLY_PAN:if(n.enableZoom===!1&&n.enablePan===!1)return;ee(P),r=s.TOUCH_DOLLY_PAN;break;case Ki.DOLLY_ROTATE:if(n.enableZoom===!1&&n.enableRotate===!1)return;q(P),r=s.TOUCH_DOLLY_ROTATE;break;default:r=s.NONE}break;default:r=s.NONE}r!==s.NONE&&n.dispatchEvent(Hl)}function St(P){switch(ht(P),r){case s.TOUCH_ROTATE:if(n.enableRotate===!1)return;Pe(P),n.update();break;case s.TOUCH_PAN:if(n.enablePan===!1)return;Ft(P),n.update();break;case s.TOUCH_DOLLY_PAN:if(n.enableZoom===!1&&n.enablePan===!1)return;Rt(P),n.update();break;case s.TOUCH_DOLLY_ROTATE:if(n.enableZoom===!1&&n.enableRotate===!1)return;pe(P),n.update();break;default:r=s.NONE}}function yt(P){n.enabled!==!1&&P.preventDefault()}function kt(P){I.push(P.pointerId)}function Gt(P){delete it[P.pointerId];for(let lt=0;lt<I.length;lt++)if(I[lt]==P.pointerId){I.splice(lt,1);return}}function ht(P){let lt=it[P.pointerId];lt===void 0&&(lt=new At,it[P.pointerId]=lt),lt.set(P.pageX,P.pageY)}function ne(P){let lt=P.pointerId===I[0]?I[1]:I[0];return it[lt]}n.domElement.addEventListener("contextmenu",yt),n.domElement.addEventListener("pointerdown",Yt),n.domElement.addEventListener("pointercancel",b),n.domElement.addEventListener("wheel",ot,{passive:!1}),this.update()}};var Ya={name:"CopyShader",uniforms:{tDiffuse:{value:null},opacity:{value:1}},vertexShader:`

		varying vec2 vUv;

		void main() {

			vUv = uv;
			gl_Position = projectionMatrix * modelViewMatrix * vec4( position, 1.0 );

		}`,fragmentShader:`

		uniform float opacity;

		uniform sampler2D tDiffuse;

		varying vec2 vUv;

		void main() {

			vec4 texel = texture2D( tDiffuse, vUv );
			gl_FragColor = opacity * texel;


		}`};var vn=class{constructor(){this.isPass=!0,this.enabled=!0,this.needsSwap=!0,this.clear=!1,this.renderToScreen=!1}setSize(){}render(){console.error("THREE.Pass: .render() must be implemented in derived pass.")}dispose(){}},$0=new Bs(-1,1,1,-1,0,1),Vl=class extends _n{constructor(){super(),this.setAttribute("position",new hn([-1,3,0,-1,-1,0,3,-1,0],3)),this.setAttribute("uv",new hn([0,2,0,0,2,0],2))}},K0=new Vl,Pi=class{constructor(t){this._mesh=new Je(K0,t)}dispose(){this._mesh.geometry.dispose()}render(t){t.render(this._mesh,$0)}get material(){return this._mesh.material}set material(t){this._mesh.material=t}};var Li=class extends vn{constructor(t,e){super(),this.textureID=e!==void 0?e:"tDiffuse",t instanceof Be?(this.uniforms=t.uniforms,this.material=t):t&&(this.uniforms=Ri.clone(t.uniforms),this.material=new Be({name:t.name!==void 0?t.name:"unspecified",defines:Object.assign({},t.defines),uniforms:this.uniforms,vertexShader:t.vertexShader,fragmentShader:t.fragmentShader})),this.fsQuad=new Pi(this.material)}render(t,e,n){this.uniforms[this.textureID]&&(this.uniforms[this.textureID].value=n.texture),this.fsQuad.material=this.material,this.renderToScreen?(t.setRenderTarget(null),this.fsQuad.render(t)):(t.setRenderTarget(e),this.clear&&t.clear(t.autoClearColor,t.autoClearDepth,t.autoClearStencil),this.fsQuad.render(t))}dispose(){this.material.dispose(),this.fsQuad.dispose()}};var Tr=class extends vn{constructor(t,e){super(),this.scene=t,this.camera=e,this.clear=!0,this.needsSwap=!1,this.inverse=!1}render(t,e,n){let s=t.getContext(),r=t.state;r.buffers.color.setMask(!1),r.buffers.depth.setMask(!1),r.buffers.color.setLocked(!0),r.buffers.depth.setLocked(!0);let o,a;this.inverse?(o=0,a=1):(o=1,a=0),r.buffers.stencil.setTest(!0),r.buffers.stencil.setOp(s.REPLACE,s.REPLACE,s.REPLACE),r.buffers.stencil.setFunc(s.ALWAYS,o,4294967295),r.buffers.stencil.setClear(a),r.buffers.stencil.setLocked(!0),t.setRenderTarget(n),this.clear&&t.clear(),t.render(this.scene,this.camera),t.setRenderTarget(e),this.clear&&t.clear(),t.render(this.scene,this.camera),r.buffers.color.setLocked(!1),r.buffers.depth.setLocked(!1),r.buffers.color.setMask(!0),r.buffers.depth.setMask(!0),r.buffers.stencil.setLocked(!1),r.buffers.stencil.setFunc(s.EQUAL,1,4294967295),r.buffers.stencil.setOp(s.KEEP,s.KEEP,s.KEEP),r.buffers.stencil.setLocked(!0)}},qa=class extends vn{constructor(){super(),this.needsSwap=!1}render(t){t.state.buffers.stencil.setLocked(!1),t.state.buffers.stencil.setTest(!1)}};var Za=class{constructor(t,e){if(this.renderer=t,this._pixelRatio=t.getPixelRatio(),e===void 0){let n=t.getSize(new At);this._width=n.width,this._height=n.height,e=new je(this._width*this._pixelRatio,this._height*this._pixelRatio,{type:xn}),e.texture.name="EffectComposer.rt1"}else this._width=e.width,this._height=e.height;this.renderTarget1=e,this.renderTarget2=e.clone(),this.renderTarget2.texture.name="EffectComposer.rt2",this.writeBuffer=this.renderTarget1,this.readBuffer=this.renderTarget2,this.renderToScreen=!0,this.passes=[],this.copyPass=new Li(Ya),this.copyPass.material.blending=Zn,this.clock=new Ba}swapBuffers(){let t=this.readBuffer;this.readBuffer=this.writeBuffer,this.writeBuffer=t}addPass(t){this.passes.push(t),t.setSize(this._width*this._pixelRatio,this._height*this._pixelRatio)}insertPass(t,e){this.passes.splice(e,0,t),t.setSize(this._width*this._pixelRatio,this._height*this._pixelRatio)}removePass(t){let e=this.passes.indexOf(t);e!==-1&&this.passes.splice(e,1)}isLastEnabledPass(t){for(let e=t+1;e<this.passes.length;e++)if(this.passes[e].enabled)return!1;return!0}render(t){t===void 0&&(t=this.clock.getDelta());let e=this.renderer.getRenderTarget(),n=!1;for(let s=0,r=this.passes.length;s<r;s++){let o=this.passes[s];if(o.enabled!==!1){if(o.renderToScreen=this.renderToScreen&&this.isLastEnabledPass(s),o.render(this.renderer,this.writeBuffer,this.readBuffer,t,n),o.needsSwap){if(n){let a=this.renderer.getContext(),l=this.renderer.state.buffers.stencil;l.setFunc(a.NOTEQUAL,1,4294967295),this.copyPass.render(this.renderer,this.writeBuffer,this.readBuffer,t),l.setFunc(a.EQUAL,1,4294967295)}this.swapBuffers()}Tr!==void 0&&(o instanceof Tr?n=!0:o instanceof qa&&(n=!1))}}this.renderer.setRenderTarget(e)}reset(t){if(t===void 0){let e=this.renderer.getSize(new At);this._pixelRatio=this.renderer.getPixelRatio(),this._width=e.width,this._height=e.height,t=this.renderTarget1.clone(),t.setSize(this._width*this._pixelRatio,this._height*this._pixelRatio)}this.renderTarget1.dispose(),this.renderTarget2.dispose(),this.renderTarget1=t,this.renderTarget2=t.clone(),this.writeBuffer=this.renderTarget1,this.readBuffer=this.renderTarget2}setSize(t,e){this._width=t,this._height=e;let n=this._width*this._pixelRatio,s=this._height*this._pixelRatio;this.renderTarget1.setSize(n,s),this.renderTarget2.setSize(n,s);for(let r=0;r<this.passes.length;r++)this.passes[r].setSize(n,s)}setPixelRatio(t){this._pixelRatio=t,this.setSize(this._width,this._height)}dispose(){this.renderTarget1.dispose(),this.renderTarget2.dispose(),this.copyPass.dispose()}};var Ja=class extends vn{constructor(t,e,n=null,s=null,r=null){super(),this.scene=t,this.camera=e,this.overrideMaterial=n,this.clearColor=s,this.clearAlpha=r,this.clear=!0,this.clearDepth=!1,this.needsSwap=!1,this._oldClearColor=new Xt}render(t,e,n){let s=t.autoClear;t.autoClear=!1;let r,o;this.overrideMaterial!==null&&(o=this.scene.overrideMaterial,this.scene.overrideMaterial=this.overrideMaterial),this.clearColor!==null&&(t.getClearColor(this._oldClearColor),t.setClearColor(this.clearColor)),this.clearAlpha!==null&&(r=t.getClearAlpha(),t.setClearAlpha(this.clearAlpha)),this.clearDepth==!0&&t.clearDepth(),t.setRenderTarget(this.renderToScreen?null:n),this.clear===!0&&t.clear(t.autoClearColor,t.autoClearDepth,t.autoClearStencil),t.render(this.scene,this.camera),this.clearColor!==null&&t.setClearColor(this._oldClearColor),this.clearAlpha!==null&&t.setClearAlpha(r),this.overrideMaterial!==null&&(this.scene.overrideMaterial=o),t.autoClear=s}};var gu={name:"LuminosityHighPassShader",shaderID:"luminosityHighPass",uniforms:{tDiffuse:{value:null},luminosityThreshold:{value:1},smoothWidth:{value:1},defaultColor:{value:new Xt(0)},defaultOpacity:{value:0}},vertexShader:`

		varying vec2 vUv;

		void main() {

			vUv = uv;

			gl_Position = projectionMatrix * modelViewMatrix * vec4( position, 1.0 );

		}`,fragmentShader:`

		uniform sampler2D tDiffuse;
		uniform vec3 defaultColor;
		uniform float defaultOpacity;
		uniform float luminosityThreshold;
		uniform float smoothWidth;

		varying vec2 vUv;

		void main() {

			vec4 texel = texture2D( tDiffuse, vUv );

			vec3 luma = vec3( 0.299, 0.587, 0.114 );

			float v = dot( texel.xyz, luma );

			vec4 outputColor = vec4( defaultColor.rgb, defaultOpacity );

			float alpha = smoothstep( luminosityThreshold, luminosityThreshold + smoothWidth, v );

			gl_FragColor = mix( outputColor, texel, alpha );

		}`};var Gs=class i extends vn{constructor(t,e,n,s){super(),this.strength=e!==void 0?e:1,this.radius=n,this.threshold=s,this.resolution=t!==void 0?new At(t.x,t.y):new At(256,256),this.clearColor=new Xt(0,0,0),this.renderTargetsHorizontal=[],this.renderTargetsVertical=[],this.nMips=5;let r=Math.round(this.resolution.x/2),o=Math.round(this.resolution.y/2);this.renderTargetBright=new je(r,o,{type:xn}),this.renderTargetBright.texture.name="UnrealBloomPass.bright",this.renderTargetBright.texture.generateMipmaps=!1;for(let d=0;d<this.nMips;d++){let m=new je(r,o,{type:xn});m.texture.name="UnrealBloomPass.h"+d,m.texture.generateMipmaps=!1,this.renderTargetsHorizontal.push(m);let x=new je(r,o,{type:xn});x.texture.name="UnrealBloomPass.v"+d,x.texture.generateMipmaps=!1,this.renderTargetsVertical.push(x),r=Math.round(r/2),o=Math.round(o/2)}let a=gu;this.highPassUniforms=Ri.clone(a.uniforms),this.highPassUniforms.luminosityThreshold.value=s,this.highPassUniforms.smoothWidth.value=.01,this.materialHighPassFilter=new Be({uniforms:this.highPassUniforms,vertexShader:a.vertexShader,fragmentShader:a.fragmentShader}),this.separableBlurMaterials=[];let l=[3,5,7,9,11];r=Math.round(this.resolution.x/2),o=Math.round(this.resolution.y/2);for(let d=0;d<this.nMips;d++)this.separableBlurMaterials.push(this.getSeperableBlurMaterial(l[d])),this.separableBlurMaterials[d].uniforms.invSize.value=new At(1/r,1/o),r=Math.round(r/2),o=Math.round(o/2);this.compositeMaterial=this.getCompositeMaterial(this.nMips),this.compositeMaterial.uniforms.blurTexture1.value=this.renderTargetsVertical[0].texture,this.compositeMaterial.uniforms.blurTexture2.value=this.renderTargetsVertical[1].texture,this.compositeMaterial.uniforms.blurTexture3.value=this.renderTargetsVertical[2].texture,this.compositeMaterial.uniforms.blurTexture4.value=this.renderTargetsVertical[3].texture,this.compositeMaterial.uniforms.blurTexture5.value=this.renderTargetsVertical[4].texture,this.compositeMaterial.uniforms.bloomStrength.value=e,this.compositeMaterial.uniforms.bloomRadius.value=.1;let h=[1,.8,.6,.4,.2];this.compositeMaterial.uniforms.bloomFactors.value=h,this.bloomTintColors=[new B(1,1,1),new B(1,1,1),new B(1,1,1),new B(1,1,1),new B(1,1,1)],this.compositeMaterial.uniforms.bloomTintColors.value=this.bloomTintColors;let u=Ya;this.copyUniforms=Ri.clone(u.uniforms),this.blendMaterial=new Be({uniforms:this.copyUniforms,vertexShader:u.vertexShader,fragmentShader:u.fragmentShader,blending:Ds,depthTest:!1,depthWrite:!1,transparent:!0}),this.enabled=!0,this.needsSwap=!1,this._oldClearColor=new Xt,this.oldClearAlpha=1,this.basic=new wn,this.fsQuad=new Pi(null)}dispose(){for(let t=0;t<this.renderTargetsHorizontal.length;t++)this.renderTargetsHorizontal[t].dispose();for(let t=0;t<this.renderTargetsVertical.length;t++)this.renderTargetsVertical[t].dispose();this.renderTargetBright.dispose();for(let t=0;t<this.separableBlurMaterials.length;t++)this.separableBlurMaterials[t].dispose();this.compositeMaterial.dispose(),this.blendMaterial.dispose(),this.basic.dispose(),this.fsQuad.dispose()}setSize(t,e){let n=Math.round(t/2),s=Math.round(e/2);this.renderTargetBright.setSize(n,s);for(let r=0;r<this.nMips;r++)this.renderTargetsHorizontal[r].setSize(n,s),this.renderTargetsVertical[r].setSize(n,s),this.separableBlurMaterials[r].uniforms.invSize.value=new At(1/n,1/s),n=Math.round(n/2),s=Math.round(s/2)}render(t,e,n,s,r){t.getClearColor(this._oldClearColor),this.oldClearAlpha=t.getClearAlpha();let o=t.autoClear;t.autoClear=!1,t.setClearColor(this.clearColor,0),r&&t.state.buffers.stencil.setTest(!1),this.renderToScreen&&(this.fsQuad.material=this.basic,this.basic.map=n.texture,t.setRenderTarget(null),t.clear(),this.fsQuad.render(t)),this.highPassUniforms.tDiffuse.value=n.texture,this.highPassUniforms.luminosityThreshold.value=this.threshold,this.fsQuad.material=this.materialHighPassFilter,t.setRenderTarget(this.renderTargetBright),t.clear(),this.fsQuad.render(t);let a=this.renderTargetBright;for(let l=0;l<this.nMips;l++)this.fsQuad.material=this.separableBlurMaterials[l],this.separableBlurMaterials[l].uniforms.colorTexture.value=a.texture,this.separableBlurMaterials[l].uniforms.direction.value=i.BlurDirectionX,t.setRenderTarget(this.renderTargetsHorizontal[l]),t.clear(),this.fsQuad.render(t),this.separableBlurMaterials[l].uniforms.colorTexture.value=this.renderTargetsHorizontal[l].texture,this.separableBlurMaterials[l].uniforms.direction.value=i.BlurDirectionY,t.setRenderTarget(this.renderTargetsVertical[l]),t.clear(),this.fsQuad.render(t),a=this.renderTargetsVertical[l];this.fsQuad.material=this.compositeMaterial,this.compositeMaterial.uniforms.bloomStrength.value=this.strength,this.compositeMaterial.uniforms.bloomRadius.value=this.radius,this.compositeMaterial.uniforms.bloomTintColors.value=this.bloomTintColors,t.setRenderTarget(this.renderTargetsHorizontal[0]),t.clear(),this.fsQuad.render(t),this.fsQuad.material=this.blendMaterial,this.copyUniforms.tDiffuse.value=this.renderTargetsHorizontal[0].texture,r&&t.state.buffers.stencil.setTest(!0),this.renderToScreen?(t.setRenderTarget(null),this.fsQuad.render(t)):(t.setRenderTarget(n),this.fsQuad.render(t)),t.setClearColor(this._oldClearColor,this.oldClearAlpha),t.autoClear=o}getSeperableBlurMaterial(t){let e=[];for(let n=0;n<t;n++)e.push(.39894*Math.exp(-.5*n*n/(t*t))/t);return new Be({defines:{KERNEL_RADIUS:t},uniforms:{colorTexture:{value:null},invSize:{value:new At(.5,.5)},direction:{value:new At(.5,.5)},gaussianCoefficients:{value:e}},vertexShader:`varying vec2 vUv;
				void main() {
					vUv = uv;
					gl_Position = projectionMatrix * modelViewMatrix * vec4( position, 1.0 );
				}`,fragmentShader:`#include <common>
				varying vec2 vUv;
				uniform sampler2D colorTexture;
				uniform vec2 invSize;
				uniform vec2 direction;
				uniform float gaussianCoefficients[KERNEL_RADIUS];

				void main() {
					float weightSum = gaussianCoefficients[0];
					vec3 diffuseSum = texture2D( colorTexture, vUv ).rgb * weightSum;
					for( int i = 1; i < KERNEL_RADIUS; i ++ ) {
						float x = float(i);
						float w = gaussianCoefficients[i];
						vec2 uvOffset = direction * invSize * x;
						vec3 sample1 = texture2D( colorTexture, vUv + uvOffset ).rgb;
						vec3 sample2 = texture2D( colorTexture, vUv - uvOffset ).rgb;
						diffuseSum += (sample1 + sample2) * w;
						weightSum += 2.0 * w;
					}
					gl_FragColor = vec4(diffuseSum/weightSum, 1.0);
				}`})}getCompositeMaterial(t){return new Be({defines:{NUM_MIPS:t},uniforms:{blurTexture1:{value:null},blurTexture2:{value:null},blurTexture3:{value:null},blurTexture4:{value:null},blurTexture5:{value:null},bloomStrength:{value:1},bloomFactors:{value:null},bloomTintColors:{value:null},bloomRadius:{value:0}},vertexShader:`varying vec2 vUv;
				void main() {
					vUv = uv;
					gl_Position = projectionMatrix * modelViewMatrix * vec4( position, 1.0 );
				}`,fragmentShader:`varying vec2 vUv;
				uniform sampler2D blurTexture1;
				uniform sampler2D blurTexture2;
				uniform sampler2D blurTexture3;
				uniform sampler2D blurTexture4;
				uniform sampler2D blurTexture5;
				uniform float bloomStrength;
				uniform float bloomRadius;
				uniform float bloomFactors[NUM_MIPS];
				uniform vec3 bloomTintColors[NUM_MIPS];

				float lerpBloomFactor(const in float factor) {
					float mirrorFactor = 1.2 - factor;
					return mix(factor, mirrorFactor, bloomRadius);
				}

				void main() {
					gl_FragColor = bloomStrength * ( lerpBloomFactor(bloomFactors[0]) * vec4(bloomTintColors[0], 1.0) * texture2D(blurTexture1, vUv) +
						lerpBloomFactor(bloomFactors[1]) * vec4(bloomTintColors[1], 1.0) * texture2D(blurTexture2, vUv) +
						lerpBloomFactor(bloomFactors[2]) * vec4(bloomTintColors[2], 1.0) * texture2D(blurTexture3, vUv) +
						lerpBloomFactor(bloomFactors[3]) * vec4(bloomTintColors[3], 1.0) * texture2D(blurTexture4, vUv) +
						lerpBloomFactor(bloomFactors[4]) * vec4(bloomTintColors[4], 1.0) * texture2D(blurTexture5, vUv) );
				}`})}};Gs.BlurDirectionX=new At(1,0);Gs.BlurDirectionY=new At(0,1);var xu={name:"VignetteShader",uniforms:{tDiffuse:{value:null},offset:{value:1},darkness:{value:1}},vertexShader:`

		varying vec2 vUv;

		void main() {

			vUv = uv;
			gl_Position = projectionMatrix * modelViewMatrix * vec4( position, 1.0 );

		}`,fragmentShader:`

		uniform float offset;
		uniform float darkness;

		uniform sampler2D tDiffuse;

		varying vec2 vUv;

		void main() {

			// Eskil's vignette

			vec4 texel = texture2D( tDiffuse, vUv );
			vec2 uv = ( vUv - vec2( 0.5 ) ) * vec2( offset );
			gl_FragColor = vec4( mix( texel.rgb, vec3( 1.0 - darkness ), dot( uv, uv ) ), texel.a );

		}`};var _u={name:"FXAAShader",uniforms:{tDiffuse:{value:null},resolution:{value:new At(1/1024,1/512)}},vertexShader:`

		varying vec2 vUv;

		void main() {

			vUv = uv;
			gl_Position = projectionMatrix * modelViewMatrix * vec4( position, 1.0 );

		}`,fragmentShader:`
		precision highp float;

		uniform sampler2D tDiffuse;

		uniform vec2 resolution;

		varying vec2 vUv;

		// FXAA 3.11 implementation by NVIDIA, ported to WebGL by Agost Biro (biro@archilogic.com)

		//----------------------------------------------------------------------------------
		// File:        es3-keplerFXAAassetsshaders/FXAA_DefaultES.frag
		// SDK Version: v3.00
		// Email:       gameworks@nvidia.com
		// Site:        http://developer.nvidia.com/
		//
		// Copyright (c) 2014-2015, NVIDIA CORPORATION. All rights reserved.
		//
		// Redistribution and use in source and binary forms, with or without
		// modification, are permitted provided that the following conditions
		// are met:
		//  * Redistributions of source code must retain the above copyright
		//    notice, this list of conditions and the following disclaimer.
		//  * Redistributions in binary form must reproduce the above copyright
		//    notice, this list of conditions and the following disclaimer in the
		//    documentation and/or other materials provided with the distribution.
		//  * Neither the name of NVIDIA CORPORATION nor the names of its
		//    contributors may be used to endorse or promote products derived
		//    from this software without specific prior written permission.
		//
		// THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS ''AS IS'' AND ANY
		// EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
		// IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
		// PURPOSE ARE DISCLAIMED.  IN NO EVENT SHALL THE COPYRIGHT OWNER OR
		// CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
		// EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
		// PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
		// PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY
		// OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
		// (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
		// OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
		//
		//----------------------------------------------------------------------------------

		#ifndef FXAA_DISCARD
			//
			// Only valid for PC OpenGL currently.
			// Probably will not work when FXAA_GREEN_AS_LUMA = 1.
			//
			// 1 = Use discard on pixels which don't need AA.
			//     For APIs which enable concurrent TEX+ROP from same surface.
			// 0 = Return unchanged color on pixels which don't need AA.
			//
			#define FXAA_DISCARD 0
		#endif

		/*--------------------------------------------------------------------------*/
		#define FxaaTexTop(t, p) texture2D(t, p, -100.0)
		#define FxaaTexOff(t, p, o, r) texture2D(t, p + (o * r), -100.0)
		/*--------------------------------------------------------------------------*/

		#define NUM_SAMPLES 5

		// assumes colors have premultipliedAlpha, so that the calculated color contrast is scaled by alpha
		float contrast( vec4 a, vec4 b ) {
			vec4 diff = abs( a - b );
			return max( max( max( diff.r, diff.g ), diff.b ), diff.a );
		}

		/*============================================================================

									FXAA3 QUALITY - PC

		============================================================================*/

		/*--------------------------------------------------------------------------*/
		vec4 FxaaPixelShader(
			vec2 posM,
			sampler2D tex,
			vec2 fxaaQualityRcpFrame,
			float fxaaQualityEdgeThreshold,
			float fxaaQualityinvEdgeThreshold
		) {
			vec4 rgbaM = FxaaTexTop(tex, posM);
			vec4 rgbaS = FxaaTexOff(tex, posM, vec2( 0.0, 1.0), fxaaQualityRcpFrame.xy);
			vec4 rgbaE = FxaaTexOff(tex, posM, vec2( 1.0, 0.0), fxaaQualityRcpFrame.xy);
			vec4 rgbaN = FxaaTexOff(tex, posM, vec2( 0.0,-1.0), fxaaQualityRcpFrame.xy);
			vec4 rgbaW = FxaaTexOff(tex, posM, vec2(-1.0, 0.0), fxaaQualityRcpFrame.xy);
			// . S .
			// W M E
			// . N .

			bool earlyExit = max( max( max(
					contrast( rgbaM, rgbaN ),
					contrast( rgbaM, rgbaS ) ),
					contrast( rgbaM, rgbaE ) ),
					contrast( rgbaM, rgbaW ) )
					< fxaaQualityEdgeThreshold;
			// . 0 .
			// 0 0 0
			// . 0 .

			#if (FXAA_DISCARD == 1)
				if(earlyExit) FxaaDiscard;
			#else
				if(earlyExit) return rgbaM;
			#endif

			float contrastN = contrast( rgbaM, rgbaN );
			float contrastS = contrast( rgbaM, rgbaS );
			float contrastE = contrast( rgbaM, rgbaE );
			float contrastW = contrast( rgbaM, rgbaW );

			float relativeVContrast = ( contrastN + contrastS ) - ( contrastE + contrastW );
			relativeVContrast *= fxaaQualityinvEdgeThreshold;

			bool horzSpan = relativeVContrast > 0.;
			// . 1 .
			// 0 0 0
			// . 1 .

			// 45 deg edge detection and corners of objects, aka V/H contrast is too similar
			if( abs( relativeVContrast ) < .3 ) {
				// locate the edge
				vec2 dirToEdge;
				dirToEdge.x = contrastE > contrastW ? 1. : -1.;
				dirToEdge.y = contrastS > contrastN ? 1. : -1.;
				// . 2 .      . 1 .
				// 1 0 2  ~=  0 0 1
				// . 1 .      . 0 .

				// tap 2 pixels and see which ones are "outside" the edge, to
				// determine if the edge is vertical or horizontal

				vec4 rgbaAlongH = FxaaTexOff(tex, posM, vec2( dirToEdge.x, -dirToEdge.y ), fxaaQualityRcpFrame.xy);
				float matchAlongH = contrast( rgbaM, rgbaAlongH );
				// . 1 .
				// 0 0 1
				// . 0 H

				vec4 rgbaAlongV = FxaaTexOff(tex, posM, vec2( -dirToEdge.x, dirToEdge.y ), fxaaQualityRcpFrame.xy);
				float matchAlongV = contrast( rgbaM, rgbaAlongV );
				// V 1 .
				// 0 0 1
				// . 0 .

				relativeVContrast = matchAlongV - matchAlongH;
				relativeVContrast *= fxaaQualityinvEdgeThreshold;

				if( abs( relativeVContrast ) < .3 ) { // 45 deg edge
					// 1 1 .
					// 0 0 1
					// . 0 1

					// do a simple blur
					return mix(
						rgbaM,
						(rgbaN + rgbaS + rgbaE + rgbaW) * .25,
						.4
					);
				}

				horzSpan = relativeVContrast > 0.;
			}

			if(!horzSpan) rgbaN = rgbaW;
			if(!horzSpan) rgbaS = rgbaE;
			// . 0 .      1
			// 1 0 1  ->  0
			// . 0 .      1

			bool pairN = contrast( rgbaM, rgbaN ) > contrast( rgbaM, rgbaS );
			if(!pairN) rgbaN = rgbaS;

			vec2 offNP;
			offNP.x = (!horzSpan) ? 0.0 : fxaaQualityRcpFrame.x;
			offNP.y = ( horzSpan) ? 0.0 : fxaaQualityRcpFrame.y;

			bool doneN = false;
			bool doneP = false;

			float nDist = 0.;
			float pDist = 0.;

			vec2 posN = posM;
			vec2 posP = posM;

			int iterationsUsed = 0;
			int iterationsUsedN = 0;
			int iterationsUsedP = 0;
			for( int i = 0; i < NUM_SAMPLES; i++ ) {
				iterationsUsed = i;

				float increment = float(i + 1);

				if(!doneN) {
					nDist += increment;
					posN = posM + offNP * nDist;
					vec4 rgbaEndN = FxaaTexTop(tex, posN.xy);
					doneN = contrast( rgbaEndN, rgbaM ) > contrast( rgbaEndN, rgbaN );
					iterationsUsedN = i;
				}

				if(!doneP) {
					pDist += increment;
					posP = posM - offNP * pDist;
					vec4 rgbaEndP = FxaaTexTop(tex, posP.xy);
					doneP = contrast( rgbaEndP, rgbaM ) > contrast( rgbaEndP, rgbaN );
					iterationsUsedP = i;
				}

				if(doneN || doneP) break;
			}


			if ( !doneP && !doneN ) return rgbaM; // failed to find end of edge

			float dist = min(
				doneN ? float( iterationsUsedN ) / float( NUM_SAMPLES - 1 ) : 1.,
				doneP ? float( iterationsUsedP ) / float( NUM_SAMPLES - 1 ) : 1.
			);

			// hacky way of reduces blurriness of mostly diagonal edges
			// but reduces AA quality
			dist = pow(dist, .5);

			dist = 1. - dist;

			return mix(
				rgbaM,
				rgbaN,
				dist * .5
			);
		}

		void main() {
			const float edgeDetectionQuality = .2;
			const float invEdgeDetectionQuality = 1. / edgeDetectionQuality;

			gl_FragColor = FxaaPixelShader(
				vUv,
				tDiffuse,
				resolution,
				edgeDetectionQuality, // [0,1] contrast needed, otherwise early discard
				invEdgeDetectionQuality
			);

		}
	`};var vu={name:"OutputShader",uniforms:{tDiffuse:{value:null},toneMappingExposure:{value:1}},vertexShader:`
		precision highp float;

		uniform mat4 modelViewMatrix;
		uniform mat4 projectionMatrix;

		attribute vec3 position;
		attribute vec2 uv;

		varying vec2 vUv;

		void main() {

			vUv = uv;
			gl_Position = projectionMatrix * modelViewMatrix * vec4( position, 1.0 );

		}`,fragmentShader:`
	
		precision highp float;

		uniform sampler2D tDiffuse;

		#include <tonemapping_pars_fragment>
		#include <colorspace_pars_fragment>

		varying vec2 vUv;

		void main() {

			gl_FragColor = texture2D( tDiffuse, vUv );

			// tone mapping

			#ifdef LINEAR_TONE_MAPPING

				gl_FragColor.rgb = LinearToneMapping( gl_FragColor.rgb );

			#elif defined( REINHARD_TONE_MAPPING )

				gl_FragColor.rgb = ReinhardToneMapping( gl_FragColor.rgb );

			#elif defined( CINEON_TONE_MAPPING )

				gl_FragColor.rgb = OptimizedCineonToneMapping( gl_FragColor.rgb );

			#elif defined( ACES_FILMIC_TONE_MAPPING )

				gl_FragColor.rgb = ACESFilmicToneMapping( gl_FragColor.rgb );

			#elif defined( AGX_TONE_MAPPING )

				gl_FragColor.rgb = AgXToneMapping( gl_FragColor.rgb );

			#endif

			// color space

			#ifdef SRGB_TRANSFER

				gl_FragColor = sRGBTransferOETF( gl_FragColor );

			#endif

		}`};var ja=class extends vn{constructor(){super();let t=vu;this.uniforms=Ri.clone(t.uniforms),this.material=new Ia({name:t.name,uniforms:this.uniforms,vertexShader:t.vertexShader,fragmentShader:t.fragmentShader}),this.fsQuad=new Pi(this.material),this._outputColorSpace=null,this._toneMapping=null}render(t,e,n){this.uniforms.tDiffuse.value=n.texture,this.uniforms.toneMappingExposure.value=t.toneMappingExposure,(this._outputColorSpace!==t.outputColorSpace||this._toneMapping!==t.toneMapping)&&(this._outputColorSpace=t.outputColorSpace,this._toneMapping=t.toneMapping,this.material.defines={},fe.getTransfer(this._outputColorSpace)===me&&(this.material.defines.SRGB_TRANSFER=""),this._toneMapping===Ll?this.material.defines.LINEAR_TONE_MAPPING="":this._toneMapping===Il?this.material.defines.REINHARD_TONE_MAPPING="":this._toneMapping===Dl?this.material.defines.CINEON_TONE_MAPPING="":this._toneMapping===Er?this.material.defines.ACES_FILMIC_TONE_MAPPING="":this._toneMapping===Ul&&(this.material.defines.AGX_TONE_MAPPING=""),this.material.needsUpdate=!0),this.renderToScreen===!0?(t.setRenderTarget(null),this.fsQuad.render(t)):(t.setRenderTarget(e),this.clear&&t.clear(t.autoClearColor,t.autoClearDepth,t.autoClearStencil),this.fsQuad.render(t))}dispose(){this.material.dispose(),this.fsQuad.dispose()}};var Q0=`.pw { position: relative; width: 100%; height: 100%; overflow: hidden; background: #2a1d4a; color: #fff; font-family: "Malgun Gothic", "Apple SD Gothic Neo", sans-serif; }

  .pw { --bg: rgba(36,22,60,.82); --bd: rgba(255,255,255,.35); --ac: #ffaa64; }
  
  canvas.gl { display: block; }
  button { font: inherit; color: inherit; cursor: pointer; }
  #rail { position: absolute; left: 0; top: 0; bottom: 0; width: 56px; background: rgba(28,16,48,.88); border-right: 2px solid var(--bd); display: flex; flex-direction: column; align-items: center; padding-top: 10px; gap: 6px; z-index: 5; }
  #rail .logo { font-weight: 800; font-size: 11px; letter-spacing: .05em; margin-bottom: 8px; opacity: .85; text-align: center; line-height: 1.1; }
  #rail button { width: 44px; height: 48px; background: transparent; border: 2px solid transparent; font-size: 20px; display: flex; flex-direction: column; align-items: center; justify-content: center; gap: 1px; }
  #rail button span { font-size: 10px; font-weight: 700; opacity: .85; }
  #rail button:hover { background: rgba(255,255,255,.08); }
  #rail button.on { background: rgba(255,170,100,.9); border-color: #fff; color: #3a1f4a; }
  #panel { position: absolute; left: 56px; top: 0; bottom: 0; width: 340px; background: var(--bg); border-right: 2px solid var(--bd); backdrop-filter: blur(6px); transform: translateX(-110%); transition: transform .22s; z-index: 4; overflow-y: auto; padding: 14px 16px 30px; box-sizing: border-box; }
  #panel.open { transform: none; }
  #panel h2 { margin: 0 0 12px; font-size: 16px; letter-spacing: .04em; }
  #panel h3 { margin: 16px 0 6px; font-size: 12px; opacity: .8; font-weight: 700; }
  .sec { display: none; } .sec.on { display: block; }
  .row { display: flex; flex-wrap: wrap; gap: 5px; align-items: center; }
  .chip { background: rgba(255,255,255,.08); border: 2px solid var(--bd); padding: 4px 9px; font-size: 12px; font-weight: 700; }
  .chip.on { background: var(--ac); color: #3a1f4a; border-color: #fff; }
  .chip.dis { opacity: .35; pointer-events: none; }
  .sw { width: 22px; height: 22px; border: 2px solid rgba(255,255,255,.4); padding: 0; }
  .sw.on { border-color: #fff; outline: 2px solid var(--ac); }
  input[type=color] { width: 28px; height: 26px; padding: 0; border: 2px solid var(--bd); background: none; }
  input[type=text], select { background: rgba(0,0,0,.3); color: #fff; border: 2px solid var(--bd); padding: 5px 8px; font: inherit; font-size: 13px; width: 100%; box-sizing: border-box; }
  .btn { background: var(--ac); color: #3a1f4a; border: 2px solid #fff; padding: 7px 14px; font-weight: 800; font-size: 13px; }
  .btn.sub { background: rgba(255,255,255,.1); color: #fff; border-color: var(--bd); }
  .btn.danger { background: #c4402e; color: #fff; }
  #previews { display: flex; gap: 8px; justify-content: center; background: rgba(0,0,0,.28); border: 2px solid var(--bd); padding: 10px 6px 6px; margin-bottom: 10px; }
  #previews div { text-align: center; font-size: 10px; opacity: .85; } #previews canvas { image-rendering: pixelated; display: block; margin: 0 auto 2px; }
  .card { display: flex; align-items: center; gap: 10px; background: rgba(255,255,255,.07); border: 2px solid var(--bd); padding: 6px 8px; margin-bottom: 7px; cursor: pointer; }
  .card.sel { border-color: var(--ac); background: rgba(255,170,100,.15); }
  .card canvas { image-rendering: pixelated; width: 36px; height: 44px; } .card .t { flex: 1; font-size: 13px; font-weight: 700; } .card .t small { display: block; font-weight: 400; font-size: 11px; opacity: .8; }
  .card button { padding: 3px 7px; font-size: 11px; background: rgba(255,255,255,.1); border: 2px solid var(--bd); }
  label.tg { display: flex; justify-content: space-between; align-items: center; font-size: 13px; padding: 6px 0; } label.tg input { width: 18px; height: 18px; }
  input[type=range] { width: 100%; }
  #toast { position: absolute; left: 50%; bottom: 24px; transform: translateX(-50%); background: var(--bg); border: 2px solid var(--bd); padding: 8px 16px; font-size: 13px; opacity: 0; transition: opacity .25s; z-index: 6; pointer-events: none; }
  #bubbles { position: absolute; inset: 0; pointer-events: none; overflow: hidden; }
  .bubble { position: absolute; transform: translate(-50%, -100%); background: #fff; color: #2b1d33; font-size: 12px; font-weight: 700; padding: 3px 7px; border: 2px solid #2b1d33; box-shadow: 0 2px 0 rgba(0,0,0,.25); white-space: nowrap; opacity: 0; transition: opacity .25s; }
  .bubble::after { content: ""; position: absolute; left: 50%; bottom: -7px; margin-left: -4px; border: 4px solid transparent; border-top-color: #2b1d33; }
  .bubble.show { opacity: 1; } .pw.nobubble .bubble { display: none; }
  .name { position: absolute; transform: translate(-50%, 0); font-size: 11px; font-weight: 700; text-shadow: 0 1px 0 #2b1d33, 0 0 4px #2b1d33; opacity: 0; transition: opacity .2s; white-space: nowrap; }
  .name.show { opacity: .95; }
  #roomtags .rt { position: absolute; transform: translate(-50%, -50%); font-size: 12px; font-weight: 800; letter-spacing: .12em; padding: 2px 8px; background: rgba(28,16,48,.55); border: 2px solid rgba(255,255,255,.3); opacity: .85; pointer-events: none; }
  .pw.noroomtag #roomtags { display: none; }
`,tx=`<div class="pw"><canvas id="gl" class="gl"></canvas>
<div id="bubbles"></div><div id="roomtags" style="position:absolute;inset:0;pointer-events:none"></div>

<div id="rail">
  <div class="logo">PIXEL<br>HOUSE</div>
  <button data-p="cast">👥<span>친구들</span></button>
  <button data-p="create">✨<span>캐릭터</span></button>
  <button data-p="scene">🎬<span>장면</span></button>
  <button data-p="settings">⚙️<span>설정</span></button>
</div>

<div id="panel">
  <div class="sec" id="s-cast">
    <h2>👥 친구들</h2>
    <div id="castList"></div>
    <button class="btn" id="newChar" style="width:100%;margin-top:6px">＋ 새 캐릭터 만들기</button>
  </div>

  <div class="sec" id="s-create">
    <h2 id="createTitle">✨ 캐릭터 만들기</h2>
    <div id="previews"><div><canvas id="pv0"></canvas>앞</div><div><canvas id="pv1"></canvas>걷기</div><div><canvas id="pv2"></canvas>뒤</div></div>
    <input type="text" id="cName" maxlength="8" placeholder="이름 (최대 8자)">
    <h3>헤어스타일</h3><div class="row" id="o-hairStyle"></div>
    <h3>머리 색</h3><div class="row" id="o-hair"></div>
    <h3>눈 색</h3><div class="row" id="o-eye"></div>
    <h3>피부색</h3><div class="row" id="o-skin"></div>
    <h3>상의</h3><div class="row" id="o-top"></div>
    <h3>상의 색</h3><div class="row" id="o-topC"></div>
    <h3>하의 <small id="dressNote" style="opacity:.7"></small></h3><div class="row" id="o-bottom"></div>
    <h3>하의 색</h3><div class="row" id="o-botC"></div>
    <h3>모자</h3><div class="row" id="o-hat"></div>
    <h3>모자 색</h3><div class="row" id="o-hatC"></div>
    <div class="row" style="margin-top:18px">
      <button class="btn" id="cSave">집에 추가하기</button>
      <button class="btn sub" id="cRand">🎲 랜덤</button>
      <button class="btn sub" id="cCancel">취소</button>
    </div>
  </div>

  <div class="sec" id="s-scene">
    <h2>🎬 장면 테스트</h2>
    <h3>누구에게?</h3><select id="sceneWho"></select>
    <h3>이동</h3><div class="row" id="sceneGo"></div>
    <h3>장소 (선택)</h3><select id="scenePlace"></select>
    <h3>행동</h3><div class="row" id="sceneAct"></div>
    <h3>이야기 읽기 테스트</h3>
    <textarea id="storyIn" rows="4" placeholder="예) 모리는 소파에 앉아 TV를 봤다. 별이는 졸려서 침대로 갔다." style="width:100%;box-sizing:border-box;background:rgba(0,0,0,.3);color:#fff;border:2px solid var(--bd);padding:6px 8px;font:inherit;font-size:13px;resize:vertical"></textarea>
    <div class="row" style="margin-top:6px"><button class="btn" id="storyGo">읽고 반응하기</button><button class="btn sub" id="storyEx">예시 넣기</button></div>
    <div id="storyOut" style="margin-top:8px;font-size:12px;line-height:1.55"></div>
    <p style="font-size:11px;opacity:.7;margin-top:16px;line-height:1.5">나중에 마리나라 확장에서 <code>postMessage({type:'scene', who:'모리', action:'sleep'})</code> 로 같은 명령을 보낼 수 있게 해 둔 자리예요.</p>
  </div>

  <div class="sec" id="s-settings">
    <h2>⚙️ 설정</h2>
    <h3>시간대</h3><div class="row" id="setTod"></div>
    <h3>표시</h3>
    <label class="tg">말풍선<input type="checkbox" id="setBubble" checked></label>
    <label class="tg">방 이름표<input type="checkbox" id="setRoomTag" checked></label>
    <label class="tg">이름표 항상 보기<input type="checkbox" id="setNames"></label>
    <label class="tg">빛 번짐(블룸)<input type="checkbox" id="setBloom" checked></label>
    <h3>배경</h3>
    <div class="row" id="bgSwatches"></div>
    <div class="row" style="margin-top:6px"><input type="color" id="bgColor"><span style="font-size:12px">배경 색 직접 고르기</span></div>
    <div class="row" style="margin-top:8px"><button class="btn sub" id="bgImgBtn">🖼 이미지 넣기</button><button class="btn sub" id="bgImgClear">이미지 지우기</button><input type="file" id="bgFile" accept="image/*" style="display:none"></div>
    <div id="bgImgOpts" style="display:none;margin-top:8px"><div class="row"><button class="chip" data-bm="cover">꽉 채우기</button><button class="chip" data-bm="tile">무늬로 반복</button></div><div style="font-size:12px;margin-top:8px">무늬 크기 <span id="bgTileVal">160</span>px</div><input type="range" id="bgTile" min="40" max="600" step="10" value="160"></div>
    <h3>성능</h3><div class="row" id="setQuality"></div><div style="font-size:11px;opacity:.7;margin-top:4px;line-height:1.5">버벅이면 '낮음'을 쓰세요 (30프레임, 그림자·번짐 끔).</div>
    <h3>움직임</h3>
    <label class="tg">스스로 움직이기<input type="checkbox" id="setAuto" checked></label>
    <label class="tg">카메라 천천히 회전<input type="checkbox" id="setRotate"></label>
    <div style="font-size:12px;margin-top:8px">걷는 속도 <span id="spdVal">1.0</span>×</div><input type="range" id="setSpeed" min="0.5" max="2.5" step="0.1" value="1">
    <h3>데이터</h3>
    <div class="row"><button class="btn sub" id="resetCast">기본 캐릭터로 되돌리기</button></div>
  </div>
</div>
<div id="toast"></div></div>`;function yu(i,t={}){let e=i.shadowRoot||i.attachShadow({mode:"open"});e.innerHTML=`<style>${Q0}</style>${tx}`;let n=e.querySelector(".pw"),s=c=>e.querySelector(c),r=c=>e.querySelectorAll(c),o=()=>n.clientWidth||800,a=()=>n.clientHeight||450,l=!0,h=10,u=!1,d=.5;function m(c){return()=>{c|=0,c=c+1831565813|0;let p=Math.imul(c^c>>>15,1|c);return p=p+Math.imul(p^p>>>7,61|p)^p,((p^p>>>14)>>>0)/4294967296}}let x=m(21),v=(c,p=Math.random)=>c[Math.floor(p()*c.length)];function M(c,p,_=0){let S=Math.imul(c|0,374761393)^Math.imul(p|0,668265263)^Math.imul((_|0)+1,2147483647);return S=Math.imul(S^S>>>13,1274126177),((S^S>>>16)>>>0)/4294967296}function g(c,p,_=0){let S=Math.floor(c),y=Math.floor(p),O=c-S,st=p-y,bt=O*O*(3-2*O),pt=st*st*(3-2*st),ut=M(S,y,_),D=M(S+1,y,_),Et=M(S,y+1,_),Qt=M(S+1,y+1,_);return ut+(D-ut)*bt+(Et-ut)*pt+(ut-D-Et+Qt)*bt*pt}let f=new Xt,R=new Xt;function E(c,p,_){return f.setHex(c),R.setHex(p),f.lerp(R,_).getHex()}let L=c=>new Xt(c),z=(c,p,_)=>new B(c,p,_),N=c=>typeof c=="number"?"#"+c.toString(16).padStart(6,"0"):c,I=(c,p)=>{let _=Math.min(255,(c>>16&255)*p)|0,S=Math.min(255,(c>>8&255)*p)|0,y=Math.min(255,(c&255)*p)|0;return"#"+(1<<24|_<<16|S<<8|y).toString(16).slice(1)},it={get(c,p){try{let _=localStorage.getItem(c);return _?JSON.parse(_):p}catch{return p}},set(c,p){try{localStorage.setItem(c,JSON.stringify(p))}catch{}}};class w{constructor(p=d){this.size=p,this.d=[]}add(p,_,S,y,O=1){this.d.push([p,_,S,y,O])}box(p,_,S,y,O,st,bt){for(let pt=p;pt<=y;pt++)for(let ut=_;ut<=O;ut++)for(let D=S;D<=st;D++)this.add(pt,ut,D,typeof bt=="function"?bt(pt,ut,D):bt)}build(p,{shadow:_=!0,jit:S=.04}={}){let y=this.d.length,O=this.size,st=new Ra(new Zi(O,O,O),p,Math.max(y,1)),bt=new _e,pt=new Xt;for(let ut=0;ut<y;ut++){let[D,Et,Qt,ue,ie]=this.d[ut];bt.makeScale(ie,ie,ie),bt.setPosition(D*O,Qt*O,Et*O),st.setMatrixAt(ut,bt),pt.setHex(ue),S&&pt.offsetHSL(0,0,(M(D*7+3,Et*13+1,Math.floor(Qt*4))-.5)*S*2),st.setColorAt(ut,pt)}return st.count=y,st.castShadow=st.receiveShadow=_,st.frustumCulled=!1,st}}let A=new yr({canvas:s("#gl"),antialias:!1,preserveDrawingBuffer:!0});A.setPixelRatio(Math.min(devicePixelRatio,2)),A.setSize(o(),a()),A.outputColorSpace=Re,A.toneMapping=Er,A.shadowMap.enabled=!0,A.shadowMap.type=Cl,A.shadowMap.autoUpdate=!1;let X=new Aa;A.setClearColor(0,0);let tt=new en(36,o()/a(),.5,1800);tt.position.set(0,19,31);let at=new Xa(tt,A.domElement);at.target.set(0,1.5,.5),at.enableDamping=!0,at.dampingFactor=.07,at.enablePan=!1,at.minDistance=9,at.maxDistance=58,at.minPolarAngle=.35,at.maxPolarAngle=1.3,at.minAzimuthAngle=-.85,at.maxAzimuthAngle=.85,at.autoRotateSpeed=.5;let F={dusk:{top:L(3811960),mid:L(13593234),hor:L(16296044),fog:L(9263784),keyCol:L(16756856),keyInt:2.6,hSky:L(11571416),hGnd:L(5914728),hInt:.8,den:.0085,stars:.3,glow:1,win:L(16756848),lamp:.75,bloom:.45,expo:1.15,tint:L(16772834),sun:z(-.9,.16,-.4),disc:L(16763024),discK:1,key:z(-.3,.8,.5)},night:{top:L(461350),mid:L(1777510),hor:L(4012680),fog:L(1907538),keyCol:L(9086719),keyInt:.7,hSky:L(4870816),hGnd:L(2366528),hInt:.85,den:.0105,stars:1,glow:1.9,win:L(1976934),lamp:1.5,bloom:.75,expo:1.3,tint:L(12633328),sun:z(.55,.45,-.7),disc:L(12570879),discK:.65,key:z(.35,.8,.5)},day:{top:L(4032224),mid:L(9227762),hor:L(15267071),fog:L(11852016),keyCol:L(16773336),keyInt:3.2,hSky:L(13626111),hGnd:L(9079400),hInt:1.3,den:.006,stars:0,glow:.5,win:L(14676735),lamp:.12,bloom:.15,expo:1.1,tint:L(16777215),sun:z(-.5,.65,-.5),disc:L(16774344),discK:1,key:z(-.3,.9,.5)}},V=c=>{let p={};for(let _ in c)p[_]=c[_].clone?c[_].clone():c[_];return p},Z=V(F.dusk),k=Object.assign({mode:"dusk",bubble:!0,roomtag:!0,names:!1,bloom:!0,auto:!0,rotate:!1,speed:1,quality:"mid",bgColor:"#241a3a",bgMode:"cover",bgTile:160},it.get("house.settings.v1",{})),$=k.mode;Object.assign(Z,V(F[$]));function K(c,p){let _=F[$],S=p?1:1-Math.exp(-c*2.2);for(let y in Z){let O=Z[y],st=_[y];typeof O=="number"?Z[y]=O+(st-O)*S:O.lerp(st,S)}}let et=new Fa(16756856,2.6);et.castShadow=!0,et.shadow.mapSize.set(2048,2048),Object.assign(et.shadow.camera,{left:-20,right:20,top:14,bottom:-14,near:1,far:100}),et.shadow.normalBias=.03,et.shadow.bias=-4e-4,X.add(et,et.target);let rt=new Ua(11571416,5914728,1.15);X.add(rt);let vt=[[-5,3.6,-4],[7,3.6,-4.5],[-6,3.6,4],[7,3.6,4]].map(c=>{let p=new Oa(16763024,8,14,1.7);return p.position.set(...c),X.add(p),p}),G=-24,nt=23,mt=-16,Tt=15,It=9,Wt=3,Ht=4,Bt=0,ee=(c,p)=>p<Bt?c<Ht?"kitchen":"bedroom":c<Ht?"living":"bath",q={kitchen:"주방",bedroom:"안방",living:"거실",bath:"화장실"},Pe={kitchen:15916196,bedroom:14468332,living:15257524,bath:12904178},Ft=9067062,Vt=new Da({roughness:.9,metalness:0}),Rt=new wn({color:16777215}),pe=new wn({color:16777215}),Yt=new wn({color:16777215}),C=(c,p)=>c*1e3+p,b=new Set,Y=new Set,Q=[],ot=new Si;X.add(ot);let ct=new w,Lt=new w,St=new w,yt=(c,p,_)=>c>=p&&c<=_;function kt(c,p){for(let y of Pt)if(y.type==="rug"){let O={i0:y.i,i1:y.i+y.p.w-1,j0:y.j,j1:y.j+y.p.d-1};if(yt(c,O.i0,O.i1)&&yt(p,O.j0,O.j1))return c===O.i0||c===O.i1||p===O.j0||p===O.j1?y.p.b:(c+p)%4===0?E(y.p.a,y.p.b,.2):y.p.a}let _=ee(c,p);if(_==="kitchen")return c+p&1?15920350:14734522;if(_==="bath")return c+p&1?16055295:12574958;let S=p&1?13146720:12291156;return M(c>>3,p,4)<.18?E(S,15253640,.5):S}let Gt=null;function ht(){let c=new w;for(let p=G-1;p<=nt+1;p++)for(let _=mt-1;_<=Tt+1;_++)c.add(p,_,0,kt(p,_));for(let p=1;p<=7;p++){let _=[0,0,1,3,6,9,12,15][p],S=[0,9067062,6965854,5786224,4734050,3812946,3023940,2366520][p];for(let y=G-2+_;y<=nt+2-_;y++)for(let O=mt-2+_;O<=Tt+2-_*.7;O++)c.add(y,Math.round(O),-p,M(y,O,p)<.15?E(S,16777215,.08):S)}Gt&&(ot.remove(Gt),Gt.geometry.dispose(),Gt.dispose()),Gt=c.build(Vt,{jit:.035}),ot.add(Gt)}let ne=[{ax:"j",pos:mt-1,a0:-10,a1:-5,k0:5,k1:8},{ax:"j",pos:mt-1,a0:14,a1:19,k0:4,k1:8},{ax:"i",pos:G-1,a0:2,a1:4,k0:4,k1:8},{ax:"i",pos:G-1,a0:12,a1:14,k0:4,k1:8},{ax:"i",pos:nt+1,a0:-13,a1:-10,k0:4,k1:7},{ax:"i",pos:nt+1,a0:8,a1:10,k0:5,k1:7}];function P(c,p,_){for(let S of ne){let y=S.ax==="j"?c:p;if((S.ax==="j"?p:c)!==S.pos||!yt(y,S.a0,S.a1)||!yt(_,S.k0,S.k1))continue;let st=y===S.a0||y===S.a1||_===S.k0||_===S.k1,bt=y===Math.floor((S.a0+S.a1)/2)||_===Math.floor((S.k0+S.k1)/2);return st||bt&&S.a1-S.a0>2?"frame":"glass"}return null}function lt(c,p,_,S){let y=P(c,p,_);if(y==="glass"){St.add(c,p,_,16777215);return}if(y==="frame"){ct.add(c,p,_,16051420);return}let O=Pe[S];_===1?O=E(O,Ft,.55):_===It?O=16051420:S==="bath"&&_<=3?O=c+p+_&1?16055295:14216950:(_+(c|0)+p)%5===0&&M(c,p,_)<.2&&(O=E(O,16777215,.12)),ct.add(c,p,_,O)}for(let c=G-1;c<=nt+1;c++)for(let p=1;p<=It;p++)lt(c,mt-1,p,c<Ht?"kitchen":"bedroom");for(let c=mt;c<=Tt;c++)for(let p=1;p<=It;p++)lt(G-1,c,p,c<Bt?"kitchen":"living"),lt(nt+1,c,p,c<Bt?"bedroom":"bath");for(let c=mt-1;c<=Tt;c++)b.add(C(G-1,c)),b.add(C(nt+1,c));for(let c=G-1;c<=nt+1;c++)b.add(C(c,mt-1));let _t=[[-9,-6],[6,9]],dt=[[-18,-6],[12,15]],Nt=c=>_t.some(([p,_])=>yt(c,p,_)),$t=c=>dt.some(([p,_])=>yt(c,p,_)),re=c=>_t.some(([p,_])=>c===p-1||c===_+1),jt=c=>dt.some(([p,_])=>c===p-1||c===_+1);function gt(c,p,_){let S=_?6:Wt;for(let y=1;y<=S;y++)ct.add(c,p,y,_?y===6?12861486:Ft:y===Wt?14207152:y===1?12098168:15853784)}for(let c=mt;c<=Tt;c++)Nt(c)||(gt(Ht,c,re(c)),b.add(C(Ht,c)));for(let c=G;c<=nt;c++)c!==Ht&&!$t(c)&&(gt(c,Bt,jt(c)),b.add(C(c,Bt)));for(let c=G-1;c<=nt+1;c++){let p=yt(c,-9,-6);for(let _=1;_<=(p&&(c===-9||c===-6)?6:1);_++)ct.add(c,Tt+1,_,p&&_===6?12861486:Ft);yt(c,-8,-7)||b.add(C(c,Tt+1))}for(let c=-9;c<=-6;c++)ct.add(c,Tt+1,6,12861486);Lt.add(-10,Tt+1,4,16762976,.8),Lt.add(-5,Tt+1,4,16762976,.8);let U=[14172206,4890840,16046170,6995818,10124008,15769792,15764010],ft={counter:{name:"조리대",size:c=>[c.w||4,2],build({P:c,w:p,p:_}){for(let S=0;S<p;S++)for(let y=0;y<2;y++){let O=S%3===0&&y===1?9724470:11829836;c(S,y,1,O),c(S,y,2,O),c(S,y,3,15854560)}for(let S of _.items||[])c(S.x,S.z,S.k,S.col,S.sc)}},sink:{name:"싱크대",size:()=>[3,2],build({P:c}){for(let p=0;p<3;p++)for(let _=0;_<2;_++)c(p,_,1,11829836),c(p,_,2,11829836),c(p,_,3,8046832);c(1,0,4,9079446,.35),c(1,0,4.45,9079446,.35)},slots:()=>[{kind:"cook",walk:[1,2],at:[1,2],face:[0,-1],pose:"stand",txt:"설거지 중",say:["쓱싹쓱싹","♪"]}]},stove:{name:"가스레인지",size:()=>[3,2],build({P:c,G:p}){for(let _=0;_<3;_++)for(let S=0;S<2;S++)c(_,S,1,6974070),c(_,S,2,6974070),c(_,S,3,2763312);p(1,1,3.75,16747056,.5),c(2,1,4,10132136,.9),c(2,1,4.55,8026760,.5)},slots:()=>[{kind:"cook",walk:[1,2],at:[1,2],face:[0,-1],pose:"stand",txt:"요리 중",say:["보글보글","맛있겠다","간 맞추는 중"],steam:!0}],emit:()=>[{type:"steam",x:2,z:1,k:5}]},upper_cabinet:{name:"벽 찬장",size:c=>[c.w||4,1],noBlock:!0,build({P:c,w:p}){for(let _=0;_<p;_++)for(let S=6;S<=8;S++)c(_,0,S,S===6&&_%3===0?6963752:9067066);for(let _=1;_<p;_+=3)c(_,1,7,15255672,.3)}},fridge:{name:"냉장고",size:()=>[2,2],build({P:c,box:p}){p(0,0,1,1,1,7,(_,S,y)=>y===5?12107976:15265522),c(1,2,3,9079446,.4),c(1,2,6,9079446,.4)}},table:{name:"식탁",size:c=>[c.w||6,c.d||4],build({P:c,w:p,d:_}){for(let S=0;S<p;S++)for(let y=0;y<_;y++)c(S,y,2,13145948);for(let[S,y]of[[0,0],[p-1,0],[0,_-1],[p-1,_-1]])c(S,y,1,9067062);c(3,1,3,16053496,.6),c(3,1,3.45,15764010,.4),c(2,2,3.3,14172206,.35),c(4,2,3.3,16046170,.35)}},chair:{name:"의자",size:()=>[1,2],build({P:c,p}){c(0,0,1,12077624),c(0,0,2,12077624),(p.backH||3)>=3&&c(0,0,3,12077624),c(0,1,1,14180426)},slots:c=>[{kind:"eat",walk:[c.p.side||-1,1],at:[0,1],face:[0,1],pose:"sit",y:.75,txt:"식사 중",say:["냠냠","맛있다!","잘 먹겠습니다","한 입 더!"]}]},bed:{name:"침대",size:()=>[8,6],build({P:c,box:p}){p(0,0,1,0,5,2,9067062),p(7,0,1,7,5,5,9067062);for(let _=1;_<=6;_++)for(let S=0;S<6;S++)c(_,S,1,9067062),c(_,S,2,_>=5?16315628:(_+S)%2?15239848:15769784);c(6,1,2.75,16777215,.6),c(6,4,2.75,16777215,.6),c(2,4,2.9,12092492,.6),c(2,4,3.3,12092492,.4)},slots:()=>[{kind:"sleep",walk:[3,6],at:[4,3],face:[1,0],pose:"lie",y:1.25,txt:"자는 중",say:["zzz","zZ…","쿨쿨"]}]},nightstand:{name:"협탁",size:()=>[2,2],build({P:c,G:p,box:_}){_(0,0,1,1,1,2,10512444),c(1,0,3,16051420,.5),p(1,0,3.75,16767120,.7)}},wardrobe:{name:"옷장",size:()=>[4,2],build({P:c,box:p}){p(0,0,1,3,1,8,(_,S)=>_===1&&S===1?6963752:9067066),c(1,2,4,15255672,.3),c(2,2,4,15255672,.3)},slots:()=>[{kind:"dress",walk:[1,2],at:[1,2],face:[0,-1],pose:"stand",txt:"옷 고르는 중",say:["뭐 입지?","이거 어때?"]}]},dresser:{name:"화장대",size:()=>[3,2],build({P:c,box:p}){p(0,0,1,2,1,3,11829836);for(let _=0;_<3;_++)for(let S=5;S<=7;S++)c(_,0,S,_===0||_===2||S===5||S===7?9067062:13167864)}},curtain:{name:"커튼",size:()=>[1,1],noBlock:!0,build({P:c}){for(let p=4;p<=8;p++)c(0,0,p,11565272)}},plant:{name:"화분",size:()=>[3,3],build({P:c,p}){c(1,1,1,12869678),c(1,1,2,12869678,.9);for(let _=-1;_<=1;_++)for(let S=-1;S<=1;S++)for(let y=0;y<=2;y++)Math.abs(_)+Math.abs(S)+(y?0:1)<=2&&M(_+(p.seed||0),S,y)<.85&&c(1+_,1+S,3+y,M(_+9,S,y)<.5?5216826:7321162)}},bathtub:{name:"욕조",size:()=>[8,5],build({P:c}){for(let p=0;p<8;p++)for(let _=0;_<5;_++){let S=p===0||_===0||_===4||p===7;c(p,_,1,S?16053496:(p+_)%3?8048880:10150136),S&&c(p,_,2,16053496)}for(let[p,_]of[[2.2,1],[4.2,3],[6.2,1],[3.2,3],[5.2,2]])c(p,_,1.7,16777215,.5);c(1,1,1.75,16767050,.45),c(0,2,3,10132136,.4),c(0,2,3.6,10132136,.4),c(1,2,3.6,10132136,.4)},slots:()=>[{kind:"bath",walk:[3,5],at:[3,2],face:[0,1],pose:"bath",y:.95,txt:"목욕 중",say:["으아~ 시원해","♪","거품 거품"]}],emit:()=>[{type:"bubbles",x:4,z:2,k:2}]},toilet:{name:"변기",size:()=>[2,3],build({box:c}){c(0,0,1,1,0,4,16053496),c(0,1,1,1,2,2,16053496),c(0,2,3,1,2,3,15263984)}},vanity:{name:"세면대",size:()=>[4,2],build({P:c,box:p}){p(0,0,1,3,1,3,13152400),p(1,0,3,2,1,3,13627647);for(let _=0;_<4;_++)for(let S=5;S<=8;S++)c(_,-1,S,_===0||_===3||S===5||S===8?9067062:13627647)},slots:()=>[{kind:"wash",walk:[1,2],at:[1,2],face:[0,-1],pose:"stand",txt:"세수 중",say:["쓱쓱","양치 중…"]}]},washer:{name:"세탁기",size:()=>[3,3],build({box:c}){c(0,0,1,2,2,4,(p,_,S)=>p===1&&_===2&&S>=2&&S<=3?6990040:16053496)},slots:()=>[{kind:"wash",walk:[1,-1],at:[1,-1],face:[0,1],pose:"stand",txt:"빨래 중",say:["뽀송뽀송","돌아간다~"]}]},basket:{name:"빨래바구니",size:()=>[2,2],build({P:c,box:p}){p(0,0,1,1,1,2,11829836),c(0,0,3,15226698,.5),c(1,0,3,4890840,.5)}},tv_unit:{name:"TV장",size:c=>[c.w||7,1],build({P:c,T:p,w:_}){for(let S=0;S<_;S++)c(S,0,1,9067066),c(S,0,2,9067066);for(let S=1;S<_-1;S++)for(let y=3;y<=6;y++)S>=2&&S<=_-3&&y>=4&&y<=5?p(S,0,y,16777215):c(S,0,y,2236970);for(let S=2;S<=_-3;S++)for(let y=7;y<=8;y++)c(S,0,y,(S+y)%2?15769664:S===3?6994136:14180426)}},sofa:{name:"소파",size:()=>[11,4],build({P:c}){for(let p=0;p<4;p++)for(let _ of[0,10])for(let S=1;S<=3;S++)c(_,p,S,12077624);for(let p=1;p<=9;p++){for(let _=1;_<=3;_++)c(p,_,1,14180426),c(p,_,2,p%3===1&&_>=2?12865596:15235682);for(let _=1;_<=3;_++)c(p,0,_,_===3?12865596:14180426)}},slots:()=>[[3,["재밌다","ㅋㅋㅋ","다음 화!"]],[5,["어, 저거다","헉"]],[7,["과자 먹고 싶다","♪"]]].map(([c,p])=>({kind:"tv",walk:[c,4],at:[c,2],face:[0,1],pose:"sit",y:1.25,txt:"TV 보는 중",say:p}))},coffee_table:{name:"테이블",size:()=>[3,5],build({P:c}){for(let p=0;p<3;p++)for(let _=0;_<5;_++)c(p,_,2,10514496);for(let[p,_]of[[0,0],[2,0],[0,4],[2,4]])c(p,_,1,8014380);c(1,2,3,14172206,.55),c(0,1,3,16051420,.4)}},floor_lamp:{name:"스탠드",size:()=>[1,1],build({P:c,G:p}){for(let _=1;_<=6;_++)c(0,0,_,4864560);p(0,0,7,16767120,1.1)}},bookshelf:{name:"책장",size:()=>[4,2],build({box:c}){c(0,0,1,3,1,7,(p,_,S)=>S%2===1||_===0||M(p,S,6)<.12?9067066:U[Math.floor(M(p,S,7)*U.length)])},slots:()=>[{kind:"read",walk:[1,2],at:[1,2],face:[0,-1],pose:"stand",txt:"책 고르는 중",say:["이 책 재밌나?","흠…"]}]},armchair:{name:"안락의자",size:()=>[3,4],build({box:c}){c(0,0,1,2,0,2,3836096),c(0,1,1,2,3,1,4890840),c(0,1,2,2,3,2,5945576)},slots:()=>[{kind:"read",walk:[1,4],at:[1,2],face:[0,1],pose:"sit",y:1.25,txt:"책 읽는 중",say:["…","한 장만 더"]}]},rug:{name:"러그",size:c=>[c.w,c.d],noBlock:!0,floor:!0}},xt=Object.keys(ft),Pt=[{type:"counter",i:-23,j:-16,p:{w:2}},{type:"sink",i:-21,j:-16},{type:"counter",i:-18,j:-16,p:{w:2,items:[{x:0,z:1,k:3.7,col:16051420,sc:.35}]}},{type:"stove",i:-16,j:-16},{type:"counter",i:-13,j:-16,p:{w:10,items:[{x:7,z:1,k:4,col:14172206,sc:.8},{x:4,z:1,k:3.75,col:15764010,sc:.45},{x:5,z:1,k:3.75,col:14172206,sc:.4}]}},{type:"upper_cabinet",i:-23,j:-16,p:{w:12}},{type:"fridge",i:-24,j:-13,rot:3},{type:"table",i:-12,j:-9,p:{w:6,d:4}},{type:"chair",i:-11,j:-11,rot:0,p:{backH:3,side:-1}},{type:"chair",i:-8,j:-11,rot:0,p:{backH:3,side:1}},{type:"chair",i:-11,j:-5,rot:2,p:{backH:2,side:1}},{type:"chair",i:-8,j:-5,rot:2,p:{backH:2,side:-1}},{type:"plant",i:-3,j:-15},{type:"rug",i:-13,j:-11,p:{w:8,d:8,a:15235162,b:12865596}},{type:"bed",i:16,j:-12},{type:"nightstand",i:22,j:-14},{type:"nightstand",i:22,j:-6},{type:"wardrobe",i:5,j:-16},{type:"dresser",i:10,j:-16},{type:"curtain",i:13,j:-16},{type:"curtain",i:20,j:-16},{type:"plant",i:5,j:-4,p:{seed:3}},{type:"rug",i:9,j:-11,p:{w:8,d:8,a:15771840,b:14188700}},{type:"bathtub",i:16,j:1},{type:"toilet",i:21,j:9,rot:1},{type:"vanity",i:21,j:12,rot:1},{type:"washer",i:6,j:13},{type:"basket",i:11,j:14},{type:"rug",i:17,j:7,p:{w:5,d:3,a:9097448,b:5941448}},{type:"tv_unit",i:-24,j:5,rot:3,p:{w:7}},{type:"sofa",i:-16,j:3,rot:1},{type:"coffee_table",i:-20,j:6},{type:"floor_lamp",i:-11,j:14},{type:"bookshelf",i:0,j:1},{type:"armchair",i:-6,j:11,rot:1},{type:"plant",i:1,j:12,p:{seed:7}},{type:"rug",i:-22,j:3,p:{w:12,d:11,a:3840676,b:2781050}},{type:"rug",i:-9,j:13,p:{w:4,d:3,a:8018492,b:5914408}}];Pt.forEach((c,p)=>{c.id=c.id||c.type+"-"+p,c.rot=c.rot||0,c.p=c.p||{}});function Ot(c,p,_){let S=(c.rot||0)&3;return{W:S&1?_:p,D:S&1?p:_,pt:(y,O)=>S===0?[y,O]:S===1?[_-1-O,y]:S===2?[p-1-y,_-1-O]:[O,p-1-y],fc:(y,O)=>S===0?[y,O]:S===1?[-O,y]:S===2?[-y,-O]:[O,-y]}}let le=c=>{let p=ft[c.type],[_,S]=p.size(c.p),y=Ot(c,_,S);return{i0:c.i,j0:c.j,i1:c.i+y.W-1,j1:c.j+y.D-1}};function he(){let c=[{kind:"out",walk:[-8,15],at:[-8,15],face:[0,1],pose:"stand",txt:"외출 중",say:["다녀올게!","금방 올게~"],arch:!0}];for(let p of ne){let _=Math.floor((p.a0+p.a1)/2),S,y,O;if(p.ax==="j")S=_,y=p.pos+2,O=[0,-1];else{let st=p.pos===G-1;S=st?p.pos+2:p.pos-2,y=_,O=[st?-1:1,0]}!Y.has(C(S,y))&&yt(S,G,nt)&&yt(y,mt,Tt)&&c.push({kind:"view",walk:[S,y],at:[S,y],face:O,pose:"stand",txt:"창밖 구경 중",say:["노을 예쁘다","구름이다","저 구름 봐!","…"],arch:!0})}return c}let we=[],Ce=null,de=null,Le=null;function $e(){let c=new w,p=new w,_=new w;Y=new Set(b),we.length=0;let S=[];for(let y of Pt){let O=ft[y.type];if(!O)continue;let[st,bt]=O.size(y.p),pt=Ot(y,st,bt),ut=(ae,Ae)=>{let[ke,qe]=pt.pt(ae,Ae);return[y.i+ke,y.j+qe]},D=ae=>(Ae,ke,qe,ce,He=1)=>{let[Ct,Te]=ut(Ae,ke);ae.add(Ct,Te,qe,ce,He)},Et=D(c),Qt=D(p),ue=D(_),Oe={P:Et,G:Qt,T:ue,box:(ae,Ae,ke,qe,ce,He,Ct)=>{for(let Te=ae;Te<=qe;Te++)for(let Yn=Ae;Yn<=ce;Yn++)for(let un=ke;un<=He;un++)Et(Te,Yn,un,typeof Ct=="function"?Ct(Te,Yn,un):Ct)},w:st,d:bt,p:y.p};if(O.build&&O.build(Oe),!O.noBlock)for(let ae=0;ae<st;ae++)for(let Ae=0;Ae<bt;Ae++)Y.add(C(...ut(ae,Ae)));if(O.slots)for(let ae of O.slots(Oe)){let Ae=pt.fc(...ae.face);S.push({...ae,walk:ut(...ae.walk),at:ut(...ae.at),face:Ae,owner:y.id})}if(O.emit)for(let ae of O.emit(Oe)){let[Ae,ke]=pt.pt(ae.x,ae.z);we.push({type:ae.type,x:(y.i+Ae)*d,z:(y.j+ke)*d,y:ae.k*d,owner:y.id})}}if(Ee=S.concat(he()),Ce){ot.remove(Ce,de,Le);for(let y of[Ce,de,Le])y.geometry.dispose(),y.dispose()}Ce=c.build(Vt,{jit:.04}),de=p.build(Rt,{shadow:!1,jit:0}),Le=_.build(Yt,{shadow:!1,jit:0}),ot.add(Ce,de,Le),ht(),Zt(),h=3;for(let y of Q)if(ss(y),y.plan=null,y.path=null,y.state="idle",y.timer=.4,!Ut(...is(y))){let[O,st]=is(y),bt=zt.reduce((pt,ut)=>Math.hypot(ut[0]-O,ut[1]-st)<Math.hypot(pt[0]-O,pt[1]-st)?ut:pt,zt[0]);y.pos.set(bt[0]*d,0,bt[1]*d)}}function Ws(c,p){let _=le(c),S=ft[c.type];if(!(yt(_.i0,G,nt)&&yt(_.i1,G,nt)&&yt(_.j0,mt,Tt)&&yt(_.j1,mt,Tt)))return!1;if(S.noBlock)return!0;for(let y=_.i0;y<=_.i1;y++)for(let O=_.j0;O<=_.j1;O++)if(b.has(C(y,O)))return!1;for(let y of Pt){if(y.id===p||y===c||ft[y.type].noBlock)continue;let O=le(y);if(_.i0<=O.i1&&_.i1>=O.i0&&_.j0<=O.j1&&_.j1>=O.j0)return!1}return!0}function $a(c,p,_,S){let y=Pt.find(st=>st.id===c);if(!y)return!1;let O={...y,i:p,j:_,rot:S??y.rot};return Ws(O,c)?(Object.assign(y,{i:p,j:_,rot:O.rot}),$e(),!0):!1}function Qi(c,p,_,S=0,y={}){let O={id:c+"-"+Math.random().toString(36).slice(2,6),type:c,i:p,j:_,rot:S,p:y};return!ft[c]||!Ws(O)?null:(Pt.push(O),$e(),O.id)}function Ar(c){let p=Pt.findIndex(_=>_.id===c);return p<0?!1:(Pt.splice(p,1),$e(),!0)}ot.add(ct.build(Vt,{jit:.025})),ot.add(St.build(pe,{shadow:!1,jit:0})),ot.add(Lt.build(Rt,{shadow:!1,jit:0}));let jn={kitchen:[-13,-8],bedroom:[14,-9],living:[-10,8],bath:[14,8]},Xs={};for(let c in jn){let p=document.createElement("div");p.className="rt",p.textContent=q[c],s("#roomtags").appendChild(p),Xs[c]=p}let Cr=(()=>{let c=document.createElement("canvas");c.width=c.height=64;let p=c.getContext("2d"),_=p.createRadialGradient(32,32,0,32,32,32);_.addColorStop(0,"rgba(255,255,255,1)"),_.addColorStop(.35,"rgba(255,255,255,.55)"),_.addColorStop(1,"rgba(255,255,255,0)"),p.fillStyle=_,p.fillRect(0,0,64,64);let S=new zs(c);return S.colorSpace=Re,S})();function Ys(c,p,_,S,y=1){let O=new _n;O.setAttribute("position",new cn(new Float32Array(c*3),3));let st=new Pa(O,new br({map:Cr,size:p,color:_,transparent:!0,opacity:y,blending:S,depthWrite:!1}));return st.frustumCulled=!1,X.add(st),st}let Ka=Ys(18,.8,16777215,oi,.35),Qa=Array.from({length:18},()=>({t:Math.random()*3})),T=Ys(50,.14,16773320,Ds,.6),H=Array.from({length:50},()=>({x:(Math.random()-.5)*22,y:.8+Math.random()*3,z:(Math.random()-.5)*14,ph:Math.random()*6,sp:.2+Math.random()*.4})),J=Ys(10,.3,16777215,oi,.7),j=Array.from({length:10},()=>({t:Math.random()*4})),W=30,wt=64,Dt=new Uint8Array(wt*wt),Ut=(c,p)=>c+W>=0&&p+W>=0&&c+W<wt&&p+W<wt&&Dt[(c+W)*wt+p+W]===1,zt=[],qt={kitchen:[],bedroom:[],living:[],bath:[]};function Zt(){Dt.fill(0),zt.length=0;for(let c in qt)qt[c].length=0;for(let c=G;c<=nt;c++)for(let p=mt;p<=Tt;p++)Y.has(C(c,p))||(Dt[(c+W)*wt+p+W]=1);for(let c of[-8,-7])Dt[(c+W)*wt+Tt+1+W]=1;for(let c=G;c<=nt;c++)for(let p=mt;p<=Tt;p++)Ut(c,p)&&(zt.push([c,p]),qt[ee(c,p)].push([c,p]))}function Jt(c,p,_,S){if(!Ut(_,S)||!Ut(c,p))return null;let y=(ut,D)=>(ut+W)*wt+D+W,O=new Map([[y(c,p),0]]),st=new Map,bt=new Set,pt=[[0,c,p]];for(;pt.length;){let ut=0;for(let ue=1;ue<pt.length;ue++)pt[ue][0]<pt[ut][0]&&(ut=ue);let[,D,Et]=pt.splice(ut,1)[0],Qt=y(D,Et);if(!bt.has(Qt)){if(bt.add(Qt),D===_&&Et===S){let ue=[[D,Et]],ie=Qt;for(;st.has(ie);){let Oe=st.get(ie);ue.push([Oe[0],Oe[1]]),ie=y(Oe[0],Oe[1])}return ue.reverse()}for(let ue=-1;ue<=1;ue++)for(let ie=-1;ie<=1;ie++){if(!ue&&!ie)continue;let Oe=D+ue,ae=Et+ie;if(!Ut(Oe,ae)||ue&&ie&&(!Ut(D+ue,Et)||!Ut(D,Et+ie)))continue;let Ae=O.get(Qt)+(ue&&ie?1.414:1),ke=y(Oe,ae);if(O.has(ke)&&O.get(ke)<=Ae)continue;O.set(ke,Ae),st.set(ke,[D,Et]);let qe=Math.abs(_-Oe),ce=Math.abs(S-ae);pt.push([Ae+(qe+ce)+(1.414-2)*Math.min(qe,ce),Oe,ae])}}}return null}let ge=.25,Ee=[];$e();let Ie=["cook","eat","sleep","view","dress","bath","wash","tv","read","out"],yn={sleep:"잠자기",tv:"TV 보기",cook:"요리",eat:"식사",bath:"목욕",wash:"씻기·빨래",read:"독서",view:"창밖 구경",dress:"옷 고르기",out:"외출",chat:"대화",intimate:"19♥"},xe={kitchen:"주방",living:"거실",bedroom:"안방",bath:"화장실"},Kt={sleep:["잠","자다","침대","꿈","sleep"],tv:["tv","티비","텔레비전","소파"],cook:["요리","부엌","주방","cook"],eat:["식사","밥","먹","eat"],bath:["목욕","욕조","bath"],wash:["씻","세수","양치","빨래"],read:["책","독서"],view:["창밖","창문"],out:["외출","나가","산책"],chat:["대화","수다","이야기"]},qs=[["sleep",["잠","자러","자고","자는","잔다","잤","졸","침대에 누","눕","꿈나라","취침","낮잠","sleep"]],["tv",["tv","티비","텔레비전","시청","드라마","영화"]],["cook",["요리","조리","끓","볶","설거지","cook"]],["eat",["식사","밥","먹","식탁","간식","점심","저녁을","아침을"]],["bath",["목욕","샤워","욕조","bath"]],["wash",["세수","양치","씻","빨래","세탁"]],["read",["독서","책을","책장","읽"]],["dress",["갈아입","옷장","옷을"]],["view",["창밖","창문","노을","구경"]],["out",["외출","나갔","나가","산책","집을 나","장보"]],["chat",["대화","수다","얘기","말을 걸","이야기를 나","속삭"]]],ve=["섹스","성관계","정사","잠자리를","몸을 섞","애무","알몸","나체","옷을 벗","벗겼","절정","삽입","쾌감","오르가","sex","nsfw","naked","orgasm","moan"],zn=[["table",["식탁","밥상"]],["bed",["침대","이불"]],["sofa",["소파"]],["bathtub",["욕조","욕탕"]],["vanity",["세면대"]],["washer",["세탁기"]],["sink",["싱크대"]],["stove",["가스레인지","레인지"]],["bookshelf",["책장","서재"]],["armchair",["안락의자"]],["wardrobe",["옷장"]],["door",["현관","문 앞"]],["window",["창가","창문"]],["living",["거실"]],["kitchen",["주방","부엌"]],["bedroom",["안방","침실"]],["bath",["화장실","욕실"]]],hi={table:{furn:["table"],kinds:["eat"]},bed:{furn:["bed"],kinds:["sleep"]},sofa:{furn:["sofa"],kinds:["tv"]},bathtub:{furn:["bathtub"],kinds:["bath"]},vanity:{furn:["vanity"],kinds:["wash"]},washer:{furn:["washer"],kinds:["wash"]},sink:{furn:["sink"],kinds:["cook"]},stove:{furn:["stove"],kinds:["cook"]},bookshelf:{furn:["bookshelf"],kinds:["read"]},armchair:{furn:["armchair"],kinds:["read"]},wardrobe:{furn:["wardrobe"],kinds:["dress"]},door:{kinds:["out"]},window:{kinds:["view"]},living:{room:"living"},kitchen:{room:"kitchen"},bedroom:{room:"bedroom"},bath:{room:"bath"}},kn={table:"식탁",bed:"침대",sofa:"소파",bathtub:"욕조",vanity:"세면대",washer:"세탁기",sink:"싱크대",stove:"가스레인지",bookshelf:"책장",armchair:"안락의자",wardrobe:"옷장",door:"현관",window:"창가",living:"거실",kitchen:"주방",bedroom:"안방",bath:"화장실"},Zs=c=>{let p=String(c).toLowerCase();for(let[_,S]of zn)if(S.some(y=>p.includes(y)))return _;return null},De=c=>!!(hi[c]&&hi[c].room),$n=c=>Pt.find(p=>p.id===c);function Js(c){let p=hi[c];if(!p)return[];if(p.room)return Ee.filter(S=>ee(S.at[0],S.at[1])===p.room);let _=[];return p.furn&&(_=Ee.filter(S=>{let y=S.owner&&$n(S.owner);return y&&p.furn.includes(y.type)})),!_.length&&p.kinds&&(_=Ee.filter(S=>p.kinds.includes(S.kind))),_}function sn(c){let p=hi[c];if(!p)return[];if(p.room)return qt[p.room].slice();if(c==="door")return[[-8,15],[-7,15],[-9,14],[-8,14],[-7,14]].filter(([S,y])=>Ut(S,y));if(c==="window")return Ee.filter(S=>S.kind==="view").map(S=>S.at);let _=[];for(let S of Pt)if(p.furn&&p.furn.includes(S.type)){let y=le(S),O=(y.i0+y.i1)/2,st=(y.j0+y.j1)/2;for(let bt=y.i0-1;bt<=y.i1+1;bt++)for(let pt=y.j0-1;pt<=y.j1+1;pt++)(bt<y.i0||bt>y.i1||pt<y.j0||pt>y.j1)&&Ut(bt,pt)&&_.push([bt,pt,Math.hypot(bt-O,pt-st)])}return _.sort((S,y)=>S[2]-y[2]),_.map(S=>[S[0],S[1]])}function ts(c,p){if(!c||c.length<2)return null;let _=p?c[Math.floor(Math.random()*c.length)]:c[Math.floor(Math.random()*Math.min(c.length,4))],S=c.find(y=>y!==_&&Math.hypot(y[0]-_[0],y[1]-_[1])<=1.5)||c.find(y=>y!==_);return S?[_,S]:null}function Rr(c){let p=[];for(let _ of String(c).matchAll(/[^.!?\n]+[.!?]?/g)){let S=_[0].trim();if(!S)continue;let y=S.toLowerCase(),O=null,st=null,bt=ve.find(Et=>y.includes(Et));if(bt&&(O="intimate",st=bt),!O)for(let[Et,Qt]of qs){let ue=Qt.find(ie=>y.includes(ie));if(ue){O=Et,st=ue;break}}let pt=null,ut=null;for(let[Et,Qt]of zn){let ue=Qt.find(ie=>y.includes(ie));if(ue){pt=Et,ut=ue;break}}if(!O&&pt){let Et=hi[pt];O=Et.room?"goto_"+Et.room:Et.kinds[0],st=ut}let D=Q.filter(Et=>S.includes(Et.def.name)).map(Et=>Et.def.name);p.push({sentence:S,who:D.length?D:["*"],action:O,keyword:st,place:pt,placeKeyword:ut})}return p}function es(c){let p=Rr(c);for(let _ of p)if(_.action)if(_.action==="intimate")_.who[0]!=="*"&&rs(_.who[0],"intimate",_.who[1],_.place);else if(_.action==="chat"&&_.who.length>=2)rs(_.who[0],"chat",_.who[1],_.place);else for(let S of _.who)rs(S,_.action,void 0,_.place);return p}let bu=c=>c.startsWith("goto_")?xe[c.slice(5)]+"(으)로 이동":yn[c]||c,Ue=18,ze=22,ns=.088,to=[43,29,51];function Mu(c,p,_,S,y,O){let st=document.createElement("canvas");st.width=Ue,st.height=ze;let bt=st.getContext("2d"),pt=y===1||y===2?1:0,ut=y===3,D=(oe,be,We,an,Rn,mi=1)=>{bt.fillStyle=N(Rn),bt.fillRect(1+oe,1+be+(mi?pt:0),We,an)},{skin:Et,hair:Qt,eye:ue,top:ie,topC:Oe,bottom:ae,botC:Ae,hat:ke,hatC:qe,hairStyle:ce}=O,He=I(Et,.88),Ct=N(Qt),Te=I(Qt,.75),Yn=I(Qt,1.25),un=N(Oe),Ze=I(Oe,.78),dn=N(Ae),Dr=I(Ae,.75),Ur="#3a2a30",uo="#2a1d2a",fo=N(ue),er=I(qe,.78),ku=I(qe,1.15),hc="#c85a64",fi="#f06a9a",pi=ie==="dress",uc=ie==="hood"||ie==="shirt",dc=oe=>y===1&&oe==="l"||y===2&&oe==="r"?1:0,po=(oe,be,We,an)=>{ae==="pants"&&!pi?D(oe,15,be,4-We,an?Dr:dn,0):ae==="shorts"&&!pi?(D(oe,15,be,2,an?Dr:dn,0),D(oe,17,be,2-We,Et,0)):D(oe,15,be,4-We,Et,0),D(oe,19-We,be,1,Ur,0)},mo=oe=>{ke==="cap"?(D(5,2,6,2,qe),D(6,1,4,1,qe),oe==="f"?D(4,4,8,1,er):oe==="s"?D(9,4,3,1,er):D(5,4,6,1,er)):ke==="straw"&&(D(6,1,4,2,qe),D(6,2,4,1,er),D(3,3,10,1,ku),oe!=="b"&&D(4,4,8,1,er))};if(S<2){if(ut){let Rn=(ae==="pants"||ae==="shorts")&&!pi?dn:N(Et);D(5,15,6,1,Rn,0),D(7,16,2,1,Rn,0),D(5,16,2,1,Ur,0),D(9,16,2,1,Ur,0)}else po(5,3,dc("l"),!1),po(8,3,dc("r"),!0);let oe=y===1?1:y===2?-1:0,be=oe>0?1:0,We=oe<0?1:0,an=(Rn,mi,fc)=>{uc?(D(Rn,10+mi,1,3,fc),D(Rn,13+mi,1,1,Et)):(D(Rn,10+mi,1,2,fc),D(Rn,12+mi,1,2,Et))};an(3,be,un),an(12,We,Ze),D(4,9,8,6,un),D(10,10,2,5,Ze),pi?(D(3,15,10,2,un),D(3,16,10,1,Ze)):ae==="skirt"?(D(4,14,8,1,dn),D(3,15,10,2,dn),D(3,16,10,1,Dr)):D(4,14,8,1,dn),S===0?((ie==="tee"||pi)&&D(7,9,2,1,Et),ie==="hood"&&(D(5,9,6,1,Ze),D(7,10,1,2,"#f4f0e8"),D(9,10,1,2,"#f4f0e8"),D(6,12,4,2,Ze)),ie==="shirt"&&(D(6,9,4,1,"#f4f4f8"),D(8,11,1,1,"#f4f4f8"),D(8,13,1,1,"#f4f4f8")),pi&&D(7,10,2,1,Ze)):ie==="hood"&&D(5,9,6,2,Ze),D(5,3,6,6,Et),S===0&&(D(6,6,1,1,uo),D(6,7,1,1,fo),D(9,6,1,1,uo),D(9,7,1,1,fo),D(5,7,1,1,"#f09a9a"),D(10,7,1,1,"#f09a9a"),D(8,8,1,1,hc)),S===0?(ce!=="spiky"&&(D(6,2,4,1,Ct),D(5,3,6,1,Ct)),(ce==="short"||ce==="pony"||ce==="twin"||ce==="bun")&&(D(5,4,2,1,Ct),D(9,4,2,1,Ct),D(5,5,1,1,Ct),D(10,5,1,1,Ct),D(7,4,1,1,Ct)),ce==="bob"&&(D(5,4,6,1,Ct),D(4,3,1,6,Ct),D(11,3,1,6,Ct),D(5,5,1,3,Ct),D(10,5,1,3,Ct),D(7,3,2,1,Yn)),ce==="long"&&(D(5,4,2,1,Ct),D(9,4,2,1,Ct),D(5,5,1,4,Ct),D(10,5,1,4,Ct),D(4,9,2,5,Ct),D(10,9,2,5,Ct),D(4,13,2,1,Te),D(10,13,2,1,Te)),ce==="twin"&&(D(3,5,2,5,Ct),D(11,5,2,5,Ct),D(3,5,2,1,fi),D(11,5,2,1,fi),D(3,9,2,1,Te),D(11,9,2,1,Te)),ce==="spiky"&&(D(5,2,6,2,Ct),D(5,1,1,1,Ct),D(7,0,1,2,Ct),D(9,1,1,1,Ct),D(10,0,1,1,Ct),D(5,4,1,2,Ct),D(10,4,1,2,Ct),D(7,4,1,1,Ct)),ce==="bun"&&D(7,0,2,2,Ct),ce==="pony"&&D(11,3,1,2,fi),mo("f")):(D(5,2,6,6,Ct),D(5,8,6,1,Te),ce==="long"&&(D(5,8,6,5,Ct),D(5,12,6,1,Te)),ce==="bob"&&(D(4,2,8,7,Ct),D(4,8,8,1,Te)),ce==="twin"&&(D(4,2,8,6,Ct),D(3,5,2,5,Ct),D(11,5,2,5,Ct),D(3,5,2,1,fi),D(11,5,2,1,fi)),ce==="pony"&&(D(7,5,2,1,fi),D(7,6,2,6,Ct),D(7,12,2,1,Te)),ce==="spiky"&&(D(5,1,1,1,Ct),D(7,0,1,2,Ct),D(9,1,1,1,Ct),D(10,0,1,1,Ct)),ce==="bun"&&D(7,0,2,2,Ct),mo("b"))}else{let oe=y===1?1:y===2?-1:0,be=y===0?[[6,0,!0],[8,0,!1]]:y===1?[[4,1,!0],[9,0,!1]]:[[9,1,!0],[4,0,!1]];if(ut){let an=(ae==="pants"||ae==="shorts")&&!pi?dn:N(Et);D(6,15,5,2,an,0),D(11,15,2,2,Ur,0)}else for(let[an,Rn,mi]of be)po(an,2,Rn,mi);D(5,9,6,6,un),D(5,9,1,6,Ze),pi?(D(4,15,8,2,un),D(4,16,8,1,Ze)):ae==="skirt"?(D(5,14,6,1,dn),D(4,15,8,2,dn),D(4,16,8,1,Dr)):D(5,14,6,1,dn);let We=7+oe;if(uc?(D(We,10,2,3,Ze),D(We,13,2,1,Et)):(D(We,10,2,2,Ze),D(We,12,2,2,Et)),ce==="long"&&(D(4,3,3,10,Ct),D(4,12,3,1,Te)),D(5,3,6,6,Et),D(9,6,1,1,uo),D(9,7,1,1,fo),D(10,7,1,1,He),D(9,8,1,1,hc),ce!=="spiky"&&(D(5,2,6,2,Ct),D(5,3,4,3,Ct),D(5,6,2,2,Te),D(9,4,1,1,Ct)),ce==="bob"&&(D(4,3,4,6,Ct),D(4,8,4,1,Te)),ce==="twin"&&(D(4,5,2,5,Ct),D(4,5,2,1,fi)),ce==="pony"){let an=y?2:3;D(an,4,2,1,fi),D(an,5,2,6,Ct),D(an,10,2,1,Te)}ce==="spiky"&&(D(5,2,6,2,Ct),D(5,3,4,3,Ct),D(5,1,1,1,Ct),D(7,0,1,2,Ct),D(9,1,1,1,Ct),D(5,6,2,2,Te)),ce==="bun"&&D(4,1,3,2,Ct),mo("s")}let Hu=bt.getImageData(0,0,Ue,ze),Nr=Hu.data,cs=new Uint8ClampedArray(Nr),nr=(oe,be)=>oe<0||be<0||oe>=Ue||be>=ze?0:Nr[(be*Ue+oe)*4+3];for(let oe=0;oe<ze;oe++)for(let be=0;be<Ue;be++)if(!nr(be,oe)&&(nr(be-1,oe)||nr(be+1,oe)||nr(be,oe-1)||nr(be,oe+1))){let We=(oe*Ue+be)*4;cs[We]=to[0],cs[We+1]=to[1],cs[We+2]=to[2],cs[We+3]=255}for(let oe=3;oe<Nr.length;oe+=4)Nr[oe]&&(cs[oe]=255);bt.putImageData(new ImageData(cs,Ue,ze),0,0),c.drawImage(st,p,_)}function eo(c){let p=document.createElement("canvas");p.width=Ue*4,p.height=ze*3;let _=p.getContext("2d");for(let S=0;S<3;S++)for(let y=0;y<4;y++)Mu(_,y*Ue,S*ze,S,y,c);return p}function Gl(c){let p=new zs(eo(c));return p.magFilter=Ye,p.minFilter=Ye,p.generateMipmaps=!1,p.colorSpace=Re,p.repeat.set(1/4,1/3),p}let En={hairStyle:[["short","짧은머리"],["bob","단발"],["long","긴머리"],["twin","양갈래"],["pony","포니테일"],["spiky","뾰족머리"],["bun","올림머리"]],top:[["tee","티셔츠"],["hood","후드티"],["shirt","셔츠"],["dress","원피스"]],bottom:[["pants","긴바지"],["shorts","반바지"],["skirt","치마"]],hat:[["none","없음"],["cap","캡모자"],["straw","밀짚모자"]]},ye={hair:[2499120,5913128,9067066,15253594,12865582,15235752,5929696,10124008,15262960,4173962],eye:[2759978,6963752,3832536,4173962,10115808,15226698,15251514,8030872],skin:[16769224,16176048,15185039,13209190,9263676,5913130],cloth:[15226698,15764042,16046170,6995818,5947568,4890840,10124008,15769792,16052456,3885690,4864602,2499120]},Wl=[{id:"c1",name:"모리",skin:16176048,hair:5913128,eye:6963752,hairStyle:"short",top:"hood",topC:15226698,bottom:"pants",botC:3885690,hat:"none",hatC:16046170},{id:"c2",name:"별이",skin:16769224,hair:15235752,eye:10115808,hairStyle:"twin",top:"dress",topC:16046170,bottom:"skirt",botC:6965898,hat:"none",hatC:16046170},{id:"c3",name:"하루",skin:15185039,hair:2499120,eye:3832536,hairStyle:"spiky",top:"tee",topC:4890840,bottom:"shorts",botC:4864602,hat:"cap",hatC:15226698},{id:"c4",name:"루나",skin:16176048,hair:5929696,eye:4173962,hairStyle:"long",top:"shirt",topC:16052456,bottom:"skirt",botC:3885690,hat:"none",hatC:16046170}],Hn=it.get("house.cast.v1",null)||Wl.map(c=>({...c})),Xl=s("#bubbles"),Su=.3,wu=new vr(1,1).translate(0,.5,0),Eu=new La(.34,14).rotateX(-Math.PI/2),no={chat:["안녕!","오늘 뭐 했어?","♪","배고파…","후후","♥","이리 와봐!","같이 TV 볼래?"],wander:["♪","흠~","…!","뭐 하지?"]},Pr={idle:"멍하니 있는 중",chat:"수다 떠는 중",wander:"집 안을 거니는 중"},Yl=()=>"c"+Math.random().toString(36).slice(2,8);function Lr(c,p){let _=Gl(c),S=new wn({map:_,alphaTest:.5,color:16777215,side:Un}),y=new Je(wu,S);y.rotation.order="YXZ",y.scale.set(Ue*ns,ze*ns,1),X.add(y);let O=new Je(Eu,new wn({color:0,transparent:!0,opacity:.3,depthWrite:!1,polygonOffset:!0,polygonOffsetFactor:-2}));X.add(O);let st=document.createElement("div");st.className="bubble",Xl.appendChild(st);let bt=document.createElement("div");bt.className="name",bt.textContent=c.name,Xl.appendChild(bt);let[pt,ut]=p||v(zt),D={def:c,sp:y,sh:O,tex:_,mat:S,el:st,nm:bt,pos:new B(pt*d,0,ut*d),path:null,pi:0,state:"idle",timer:.5+Math.random()*2,kind:"wander",spot:null,pose:"stand",spotY:ge,face:new At(0,1),phase:Math.random()*5,say:"",sayT:0,chatCd:3+Math.random()*6,speed:.85+Math.random()*.2,hidden:!1,act:Pr.idle,forced:!1};return y.userData.char=D,Q.push(D),D}function io(c){X.remove(c.sp),X.remove(c.sh),c.el.remove(),c.nm.remove(),c.tex.dispose(),Q.splice(Q.indexOf(c),1),An===c&&(An=null)}function Tu(c){c.tex.dispose(),c.tex=Gl(c.def),c.mat.map=c.tex,c.mat.needsUpdate=!0,c.nm.textContent=c.def.name}let ql=c=>Math.round(c/d),is=c=>[ql(c.pos.x),ql(c.pos.z)];function ss(c){c.spot&&(c.pose!=="stand"||c.hidden)&&c.pos.set(c.spot.walk[0]*d,0,c.spot.walk[1]*d),c.pose="stand",c.hidden=!1,c.spot=null}function Zl(c,p){return Q.some(_=>_!==p&&(_.spot===c||_.plan&&_.plan.spot===c))}function Jl(c,p,_=!1){ss(c);let[S,y]=is(c),O=Jt(S,y,p.walk[0],p.walk[1]);return O?(c.plan={spot:p},c.path=O,c.pi=1,c.state=(O.length<2,"walk"),c.kind=p.kind,c.act=p.txt,c.forced=_,O.length<2&&(c.path=[O[0],O[0]],c.pi=1),!0):(c.state="idle",c.timer=1,!1)}function js(c,p,_,S=Pr.wander,y=!1){ss(c);let[O,st]=is(c),bt=Jt(O,st,p,_);return!bt||bt.length<2?(c.state="idle",c.timer=.6,!1):(c.plan={spot:null},c.path=bt,c.pi=1,c.state="walk",c.kind="wander",c.act=S,c.forced=y,!0)}function Au(c){let p={dusk:{tv:3,cook:2,eat:2,read:1.2,view:1.2,wash:1,bath:1,sleep:.4,dress:.6,wander:1.5,out:.5},night:{tv:2,cook:.4,eat:.4,read:1,view:.6,wash:1.5,bath:1.5,sleep:5,dress:.6,wander:.5,out:.1},day:{tv:1.5,cook:2.5,eat:2.5,read:1.5,view:1.5,wash:1,bath:.5,sleep:.3,dress:.8,wander:2,out:1.5}}[$],_=0;for(let st in p)_+=p[st];let S=Math.random()*_,y="wander";for(let st in p)if(S-=p[st],S<=0){y=st;break}if(y==="wander"){let[st,bt]=is(c),pt=zt.filter(([Et,Qt])=>Math.hypot(Et-st,Qt-bt)>4&&Math.hypot(Et-st,Qt-bt)<14),[ut,D]=v(pt.length?pt:zt);js(c,ut,D);return}let O=Ee.filter(st=>st.kind===y&&!Zl(st,c));if(!O.length){c.state="idle",c.timer=1.5;return}Jl(c,v(O))}function jl(c,p,_){let S=p-c.pos.x,y=_-c.pos.z,O=Math.hypot(S,y)||1;c.face.set(S/O,y/O)}function Ii(c,p){c.say=v(p),c.sayT=2.8}function so(c){let p=c.plan&&c.plan.spot;c.state="act",c.path=null,p?(c.spot=p,c.pose=p.pose,c.spotY=p.y??ge,c.pos.set(p.at[0]*d,0,p.at[1]*d),c.face.set(p.face[0],p.face[1]),p.kind==="out"?(c.hidden=!0,c.timer=10+Math.random()*14):c.timer=p.kind==="sleep"?22+Math.random()*20:p.kind==="bath"?14+Math.random()*10:10+Math.random()*14,Math.random()<.85&&Ii(c,p.say)):c.kind==="intimate"?(c.timer=20+Math.random()*8,c.say="19♥",c.sayT=c.timer,c.act="둘만의 시간 (19♥)",c.partner&&jl(c,c.partner.pos.x,c.partner.pos.z)):(c.timer=.8+Math.random()*2,Math.random()<.3&&Ii(c,no.wander))}function $l(c,p){for(let[_,S]of[[c,p],[p,c]])ss(_),_.state="chat",_.path=null,_.timer=4+Math.random()*2,_.chatCd=16+Math.random()*10,_.act=Pr.chat,_.forced=!1,jl(_,S.pos.x,S.pos.z);Ii(c,no.chat),p.sayT=-1.2}let Vn=new B,$s=new B,Tn=new B,Cu=new B(0,1,0);function Kl(c,p){tt.getWorldDirection(Vn),Vn.y=0,Vn.normalize(),$s.crossVectors(Vn,Cu).normalize();let _=Math.atan2(-Vn.x,-Vn.z),S=(Math.PI/2-at.getPolarAngle())*Su;for(let y of Q){y.chatCd-=p,y.sayT-=p;let O=!1;if(y.state==="idle")y.timer-=p,y.timer<=0&&k.auto&&Au(y);else if(y.state==="walk"){let He=y.path[y.pi],Ct=He[0]*d,Te=He[1]*d,Yn=Ct-y.pos.x,un=Te-y.pos.z,Ze=Math.hypot(Yn,un),dn=y.speed*k.speed*p;Ze<=dn?(y.pos.x=Ct,y.pos.z=Te,y.pi++,y.pi>=y.path.length&&so(y)):(y.pos.x+=Yn/Ze*dn,y.pos.z+=un/Ze*dn,y.face.set(Yn/Ze,un/Ze),O=!0)}else if(y.state==="act")if(y.timer-=p,y.timer<=0){let He=y.hidden;ss(y),y.state="idle",y.timer=.3+Math.random()*1.5,y.act=Pr.idle,y.forced=!1,He&&Ii(y,["다녀왔어!","밖에 좋더라"])}else y.spot&&y.spot.kind!=="sleep"&&Math.random()<p*.1&&Ii(y,y.spot.say);else y.state==="chat"&&(y.timer-=p,y.timer<=0?(y.state="idle",y.timer=.3):y.sayT<=0&&Ii(y,no.chat));if((y.state==="walk"||y.state==="idle")&&y.chatCd<=0&&!y.hidden&&k.auto){for(let He of Q)if(!(He===y||He.hidden||He.state!=="walk"&&He.state!=="idle"||He.chatCd>0)&&Math.hypot(He.pos.x-y.pos.x,He.pos.z-y.pos.z)<1.1){$l(y,He);break}}y.state==="walk"&&y.kind==="chat"&&y.partner&&Math.hypot(y.partner.pos.x-y.pos.x,y.partner.pos.z-y.pos.z)<1.4&&!y.partner.hidden&&($l(y,y.partner),y.partner=null),y.phase+=O?p*y.speed*k.speed*4.2:0;let st=O?Math.floor(y.phase)%2===0?1:2:0,bt=y.face.x*Vn.x+y.face.y*Vn.z,pt=y.face.x*$s.x+y.face.y*$s.z,ut,D=1,Et=st;Math.abs(pt)>Math.abs(bt)?(ut=2,D=pt>=0?1:-1):ut=bt>0?1:0;let Qt=1,ue=0,ie=ge,Oe=!1;y.pose==="sit"?(Qt=.82,ie=y.spotY,Et=3):y.pose==="bath"?(Qt=.55,ie=y.spotY,Et=0,ut=0,D=1):y.pose==="lie"&&(Oe=!0,ue=-Math.PI/2,ie=y.spotY+.28,Et=0,ut=0,D=1);let ae=y.tex,Ae=1-(ut+1)/3;ae.repeat.set(D/4,Qt/3),ae.offset.x=(D>0?Et:Et+1)/4,ae.offset.y=Ae+(1-Qt)/3;let ke=ze*ns*Qt;y.sp.scale.set(Ue*ns,ke,1),y.mat.color.copy(Z.tint),y.sp.rotation.set(-S,_,ue);let qe=-Vn.x*.12,ce=-Vn.z*.12;Oe?y.sp.position.set(y.pos.x-$s.x*ke/2+qe,ie,y.pos.z-$s.z*ke/2+ce):y.sp.position.set(y.pos.x+qe,ie-(Qt<1?0:ns),y.pos.z+ce),y.sp.visible=!y.hidden,y.sh.position.set(y.pos.x,ge+.03,y.pos.z),y.sh.visible=!y.hidden&&y.pose==="stand",y.topY=Oe?ie+.7:ie+ze*ns*Qt+.1}}function ro(c){return!c||c==="*"||c==="all"?Q.slice():Q.filter(p=>p.def.name===c||p.def.id===c)}function rs(c,p,_,S){let y=ro(c);if(!y.length)return!1;for(let O of y)if(p==="chat"){let st=_&&ro(_)[0]||Q.filter(Et=>Et!==O&&!Et.hidden).sort((Et,Qt)=>Math.hypot(Et.pos.x-O.pos.x,Et.pos.z-O.pos.z)-Math.hypot(Qt.pos.x-O.pos.x,Qt.pos.z-O.pos.z))[0];if(!st)continue;ss(st),st.state="idle",st.timer=3;let[bt,pt]=is(st),ut=[[1,0],[-1,0],[0,1],[0,-1],[1,1],[-1,-1]].map(([Et,Qt])=>[bt+Et,pt+Qt]).filter(([Et,Qt])=>Ut(Et,Qt)),D=S?ts(sn(S),De(S)):null;if(D)for(let[Et,Qt,ue]of[[O,D[0],st],[st,D[1],O]]){let ie=js(Et,Qt[0],Qt[1],kn[S]+"에서 대화하러 가는 중",!0);Et.kind="chat",Et.partner=ue,Et.chatCd=0,ie||(Et.plan={spot:null},so(Et))}else ut.length&&js(O,...ut[0],"대화하러 가는 중",!0)&&(O.kind="chat",O.partner=st,O.chatCd=0,st.chatCd=0)}else if(p==="intimate"){if(O.kind==="intimate"&&O.state!=="idle")continue;let st=_&&ro(_)[0]||Q.filter(pt=>pt!==O&&!pt.hidden).sort((pt,ut)=>Math.hypot(pt.pos.x-O.pos.x,pt.pos.z-O.pos.z)-Math.hypot(ut.pos.x-O.pos.x,ut.pos.z-O.pos.z))[0];if(!st||st===O)continue;let bt=S?ts(sn(S),De(S)):null;if(!bt){let pt=Ee.find(D=>D.kind==="sleep"),ut=pt?pt.walk:[0,3];bt=[[0,0],[1,0],[-1,0],[0,1],[0,-1],[1,1],[-1,1]].map(([D,Et])=>[ut[0]+D,ut[1]+Et]).filter(([D,Et])=>Ut(D,Et))}if(bt.length<2)continue;for(let[pt,ut,D]of[[O,bt[0],st],[st,bt[1],O]]){let Et=js(pt,ut[0],ut[1],"둘만의 시간 (19♥)",!0);pt.kind="intimate",pt.partner=D,pt.chatCd=90,Et||(pt.plan={spot:null},so(pt))}}else if(p.startsWith("goto_")){let st=p.slice(5),bt=qt[st];if(!bt)continue;let[pt,ut]=v(bt);js(O,pt,ut,q[st]+"(으)로 이동 중",!0)}else if(Ie.includes(p)){let st=Ee.filter(pt=>pt.kind===p);if(S){let pt=Js(S),ut=st.filter(D=>pt.includes(D));ut.length&&(st=ut)}let bt=st.filter(pt=>!Zl(pt,O));Jl(O,v(bt.length?bt:st),!0)}return!0}let Ql=c=>{let p=c.data;p&&p.type==="scene"&&typeof p.action=="string"?rs(p.who,p.action,p.partner,p.place):p&&p.type==="story"&&typeof p.text=="string"&&es(p.text)};window.addEventListener("message",Ql);let ex=null,An=null;function Ru(){let c=o(),p=a();for(let _ of Q){Tn.set(_.pos.x,_.topY??2.2,_.pos.z).project(tt);let S=!_.hidden&&Tn.z<1&&Math.abs(Tn.x)<1.1&&Math.abs(Tn.y)<1.1,y=Math.round((Tn.x*.5+.5)*c),O=Math.round((-Tn.y*.5+.5)*p);(_._x!==y||_._y!==O)&&(_.el.style.left=y+"px",_.el.style.top=O-2+"px",_.nm.style.left=y+"px",_.nm.style.top=O+2+"px",_._x=y,_._y=O),_.el.textContent!==_.say&&(_.el.textContent=_.say);let st=S&&_.sayT>0,bt=S&&(k.names||_===An);_._sb!==st&&(_.el.classList.toggle("show",st),_._sb=st),_._sn!==bt&&(_.nm.classList.toggle("show",bt),_._sn=bt)}if(k.roomtag)for(let _ in jn){Tn.set(jn[_][0]*d,.4,jn[_][1]*d).project(tt);let S=Math.round((Tn.x*.5+.5)*c),y=Math.round((-Tn.y*.5+.5)*p),O=Xs[_];(O._x!==S||O._y!==y)&&(O.style.left=S+"px",O.style.top=y+"px",O._x=S,O._y=y)}}let tc=new za,ec=new At,Ir=null;A.domElement.addEventListener("pointerdown",c=>{Ir=[c.clientX,c.clientY]}),A.domElement.addEventListener("pointerup",c=>{if(!Ir||Math.hypot(c.clientX-Ir[0],c.clientY-Ir[1])>5)return;let p=A.domElement.getBoundingClientRect();ec.set((c.clientX-p.left)/p.width*2-1,-((c.clientY-p.top)/p.height)*2+1),tc.setFromCamera(ec,tt);let _=tc.intersectObjects(Q.filter(S=>!S.hidden).map(S=>S.sp),!1)[0];An=_?_.object.userData.char:null,Ui()});function Gn(c){let p=s("#toast");p.textContent=c,p.style.opacity=1,clearTimeout(Gn.h),Gn.h=setTimeout(()=>p.style.opacity=0,1800)}let ui=null;function Di(c){ui===c&&(c=null),ui=c,s("#panel").classList.toggle("open",!!c),r("#rail button").forEach(p=>p.classList.toggle("on",p.dataset.p===c||c==="create"&&p.dataset.p==="create")),r(".sec").forEach(p=>p.classList.toggle("on",p.id==="s-"+c)),c==="cast"&&Ui(),c==="create"&&(Wn||oo(null)),c==="scene"&&Qs()}r("#rail button").forEach(c=>c.addEventListener("click",()=>{c.dataset.p==="create"&&(Wn=Wn),Di(c.dataset.p)}));function Pu(c){let p=document.createElement("canvas");p.width=Ue,p.height=ze;let _=p.getContext("2d");return _.imageSmoothingEnabled=!1,_.drawImage(eo(c),0,0,Ue,ze,0,0,Ue,ze),p}function Ui(){let c=s("#castList");c.innerHTML="",Q.forEach(p=>{let _=document.createElement("div");_.className="card"+(p===An?" sel":""),_.appendChild(Pu(p.def));let S=document.createElement("div");S.className="t",S.innerHTML=`${p.def.name}<small>${p.act}</small>`,_.appendChild(S);let y=document.createElement("button");y.textContent="수정",y.onclick=st=>{st.stopPropagation(),oo(p),Di("create"),ui==="create"||Di("create")},_.appendChild(y);let O=document.createElement("button");O.textContent="삭제",O.onclick=st=>{if(st.stopPropagation(),Q.length<=1)return Gn("최소 1명은 있어야 해요");io(p),Hn=Q.map(bt=>bt.def),it.set("house.cast.v1",Hn),Ui(),Qs()},_.appendChild(O),_.onclick=()=>{An=An===p?null:p,Ui()},c.appendChild(_)}),s("#newChar").style.display=Q.length>=8?"none":""}let Lu=setInterval(()=>{ui==="cast"&&Ui()},1500);s("#newChar").onclick=()=>{oo(null),ui=null,Di("create")};let Ne=null,Wn=null,ao=!0,nc=null,ic={};function Iu(c){let p=s("#o-"+c);p.innerHTML="",En[c].forEach(([_,S])=>{let y=document.createElement("button");y.className="chip",y.textContent=S,y.dataset.v=_,y.onclick=()=>{Ne[c]=_,Ks()},p.appendChild(y)})}function as(c,p){let _=s("#o-"+c);_.innerHTML="",p.forEach(y=>{let O=document.createElement("button");O.className="sw",O.style.background=N(y),O.dataset.v=y,O.onclick=()=>{Ne[c]=y,Ks()},_.appendChild(O)});let S=document.createElement("input");S.type="color",S.oninput=()=>{Ne[c]=parseInt(S.value.slice(1),16),Ks(!0)},_.appendChild(S),ic[c]=S}["hairStyle","top","bottom","hat"].forEach(Iu),as("hair",ye.hair),as("eye",ye.eye),as("skin",ye.skin),as("topC",ye.cloth),as("botC",ye.cloth),as("hatC",ye.cloth);function Ks(c){for(let _ of["hairStyle","top","bottom","hat"])r("#o-"+_+" .chip").forEach(S=>S.classList.toggle("on",S.dataset.v===Ne[_]));for(let _ of["hair","eye","skin","topC","botC","hatC"])r("#o-"+_+" .sw").forEach(S=>S.classList.toggle("on",+S.dataset.v===Ne[_])),c||(ic[_].value=N(Ne[_]));let p=Ne.top==="dress";s("#o-bottom").classList.toggle("dis",p),s("#o-botC").classList.toggle("dis",p),s("#dressNote").textContent=p?"(원피스는 하의가 없어요)":"",r("#o-bottom .chip").forEach(_=>_.classList.toggle("dis",p)),s("#o-hatC").style.opacity=Ne.hat==="none"?.35:1,ao=!0}function oo(c){Wn=c,Ne=c?{...c.def}:{id:Yl(),name:"",skin:v(ye.skin),hair:v(ye.hair),eye:v(ye.eye),hairStyle:v(En.hairStyle)[0],top:v(En.top)[0],topC:v(ye.cloth),bottom:v(En.bottom)[0],botC:v(ye.cloth),hat:"none",hatC:v(ye.cloth)},s("#cName").value=Ne.name,s("#createTitle").textContent=c?"✏️ 캐릭터 수정":"✨ 캐릭터 만들기",s("#cSave").textContent=c?"저장하기":"집에 추가하기",Ks()}s("#cName").oninput=c=>{Ne.name=c.target.value},s("#cRand").onclick=()=>{let c=Ne.name;Ne={id:Ne.id,name:c,skin:v(ye.skin),hair:v(ye.hair),eye:v(ye.eye),hairStyle:v(En.hairStyle)[0],top:v(En.top)[0],topC:v(ye.cloth),bottom:v(En.bottom)[0],botC:v(ye.cloth),hat:Math.random()<.25?v(En.hat.slice(1))[0]:"none",hatC:v(ye.cloth)},Ks()},s("#cCancel").onclick=()=>{Wn=null,ui="create",Di("create")},s("#cSave").onclick=()=>{let c=(Ne.name||"").trim();if(!c)return Gn("이름을 입력해 주세요");if(Q.some(p=>p!==Wn&&p.def.name===c))return Gn("같은 이름이 이미 있어요");if(Ne.name=c,Wn)Wn.def={...Ne},Tu(Wn),Gn(c+" 저장했어요");else{if(Q.length>=8)return Gn("최대 8명까지예요");let p=Lr({...Ne},[-7,14]);p.state="idle",p.timer=.4,Ii(p,["안녕! 잘 부탁해","여기가 우리 집이구나!"]),Gn(c+" 입주 완료!")}Hn=Q.map(p=>p.def),it.set("house.cast.v1",Hn),Wn=null,ui="create",Di("cast"),Qs()};let Du=[0,1,2].map(c=>{let p=s("#pv"+c);return p.width=Ue*5,p.height=ze*5,p.getContext("2d")});function sc(c){if(!l||(requestAnimationFrame(sc),ui!=="create"||!Ne))return;ao&&(nc=eo(Ne),ao=!1),[[0,0],[Math.floor(c/200)%2+1,2],[0,1]].forEach(([_,S],y)=>{let O=Du[y];O.imageSmoothingEnabled=!1,O.clearRect(0,0,Ue*5,ze*5),O.fillStyle="rgba(255,255,255,.07)",O.fillRect(0,0,Ue*5,ze*5),O.drawImage(nc,_*Ue,S*ze,Ue,ze,0,0,Ue*5,ze*5)})}requestAnimationFrame(sc);function Qs(){let c=s("#sceneWho"),p=c.value;c.innerHTML='<option value="*">모두</option>'+Q.map(y=>`<option value="${y.def.id}">${y.def.name}</option>`).join(""),[...c.options].some(y=>y.value===p)&&(c.value=p);let _=s("#scenePlace");_.options.length||(_.innerHTML='<option value="">장소 지정 안 함</option>'+Object.keys(kn).map(y=>'<option value="'+y+'">'+kn[y]+"</option>").join(""));let S=(y,O,st)=>{y.innerHTML="";for(let bt in O){let pt=document.createElement("button");pt.className="chip",pt.textContent=O[bt],pt.onclick=()=>rs(c.value,st+bt,void 0,st==="goto_"?void 0:_.value||void 0),y.appendChild(pt)}};S(s("#sceneGo"),xe,"goto_"),S(s("#sceneAct"),yn,"")}s("#storyEx").onclick=()=>{s("#storyIn").value=Q.slice(0,3).map((c,p)=>[c.def.name+"는 소파에 앉아 TV를 봤다.",c.def.name+"는 졸려서 침대로 가서 잠들었다.",c.def.name+"는 주방에서 요리를 시작했다."][p]).join(`
`)},s("#storyGo").onclick=()=>{let c=es(s("#storyIn").value),p=s("#storyOut");if(p.innerHTML="",!c.length){p.textContent="읽을 문장이 없어요.";return}for(let _ of c){let S=document.createElement("div");S.style.cssText="padding:4px 0;border-top:1px solid rgba(255,255,255,.15)",S.textContent=_.action?`✔ "${_.sentence}" → ${_.who.join(", ")==="*"?"모두":_.who.join(", ")}: ${bu(_.action)} (키워드 '${_.keyword}'${_.place?", 장소 "+kn[_.place]:""})`:`— "${_.sentence}" → 반응 없음`,p.appendChild(S)}};function Uu(c){if(c=String(c||"").trim().slice(0,16),!c||Q.some(_=>_.def.name===c)||Q.length>=8)return!1;let p={id:Yl(),name:c,skin:v(ye.skin),hair:v(ye.hair),eye:v(ye.eye),hairStyle:v(En.hairStyle)[0],top:v(En.top)[0],topC:v(ye.cloth),bottom:v(En.bottom)[0],botC:v(ye.cloth),hat:"none",hatC:v(ye.cloth)};return Lr(p,[-7,14]),Hn=Q.map(_=>_.def),it.set("house.cast.v1",Hn),Ui(),Qs(),!0}let Ni={low:{pr:1,shadow:0,bloom:!1,fxaa:!1,fps:30},mid:{pr:1.25,shadow:1024,bloom:!0,fxaa:!0,fps:60},high:{pr:2,shadow:2048,bloom:!0,fxaa:!0,fps:60}},Nu={low:"낮음",mid:"보통",high:"높음"},Ou=["#241a3a","#000000","#ffffff","#f3e9dc","#2f3a4a","#6f4a8a","#a8d8e8","#f4b6c8","#cfe8c8"],rn=null,di={tDiffuse:{value:null},tBg:{value:null},bgColor:{value:new B(.14,.1,.23)},hasImg:{value:0},mode:{value:0},tilePx:{value:160},imgAspect:{value:1},res:{value:new At(o(),a())}};function rc(){let c=parseInt(String(k.bgColor).slice(1),16)||0;di.bgColor.value.set((c>>16&255)/255,(c>>8&255)/255,(c&255)/255),di.hasImg.value=rn?1:0,di.tBg.value=rn,di.mode.value=k.bgMode==="tile"?1:0,di.tilePx.value=k.bgTile*A.getPixelRatio(),s("#bgImgOpts").style.display=rn?"block":"none",s("#bgTileVal").textContent=k.bgTile,s("#bgColor").value=k.bgColor,r("#bgImgOpts [data-bm]").forEach(p=>p.classList.toggle("on",p.dataset.bm===k.bgMode))}function ac(c,p){let _=Math.min(1,1280/Math.max(c.width,c.height)),S=document.createElement("canvas");if(S.width=Math.max(1,Math.round(c.width*_)),S.height=Math.max(1,Math.round(c.height*_)),S.getContext("2d").drawImage(c,0,0,S.width,S.height),rn&&rn.dispose(),rn=new zs(S),rn.colorSpace=fn,rn.wrapS=rn.wrapT=mr,rn.minFilter=Yi,rn.generateMipmaps=!0,rn.needsUpdate=!0,di.imgAspect.value=S.width/S.height,p)try{localStorage.setItem("house.bgimg.v1",S.toDataURL("image/jpeg",.85))}catch{Gn("이미지가 너무 커서 저장은 못 했어요 (이번에만 적용)")}Cn()}function oc(){let c=Ni[k.quality]||Ni.mid,p=Math.min(window.devicePixelRatio||1,c.pr);A.setPixelRatio(p),Xn.setPixelRatio(p),co.enabled=c.fxaa,A.shadowMap.enabled=c.shadow>0,et.castShadow=c.shadow>0,Vt.needsUpdate=!0,c.shadow&&(et.shadow.mapSize.set(c.shadow,c.shadow),et.shadow.map&&(et.shadow.map.dispose(),et.shadow.map=null)),os.enabled=k.bloom&&c.bloom,h=3,ho()}function Cn(){n.classList.toggle("nobubble",!k.bubble),n.classList.toggle("noroomtag",!k.roomtag);let c=Ni[k.quality]||Ni.mid;os.enabled=k.bloom&&c.bloom,at.autoRotate=k.rotate,s("#spdVal").textContent=(+k.speed).toFixed(1),r("#setTod .chip").forEach(p=>p.classList.toggle("on",p.dataset.m===$)),r("#setQuality .chip").forEach(p=>p.classList.toggle("on",p.dataset.q===k.quality)),rc(),it.set("house.settings.v1",{...k,mode:$})}{let c=s("#setTod");[["dusk","🌇 노을"],["night","🌙 밤"],["day","☀️ 낮"]].forEach(([p,_])=>{let S=document.createElement("button");S.className="chip",S.dataset.m=p,S.textContent=_,S.onclick=()=>{$=p,Cn()},c.appendChild(S)})}{let c=s("#setQuality");for(let p in Ni){let _=document.createElement("button");_.className="chip",_.dataset.q=p,_.textContent=Nu[p],_.onclick=()=>{k.quality=p,oc(),Cn()},c.appendChild(_)}}let Oi=(c,p,_)=>{let S=s(c);S.type==="checkbox"?S.checked=!!k[p]:S.value=k[p],S.oninput=()=>{k[p]=S.type==="checkbox"?S.checked:+S.value,Cn()}};Oi("#setBubble","bubble"),Oi("#setRoomTag","roomtag"),Oi("#setNames","names"),Oi("#setBloom","bloom"),Oi("#setAuto","auto"),Oi("#setRotate","rotate"),Oi("#setSpeed","speed");{let c=s("#bgSwatches");Ou.forEach(p=>{let _=document.createElement("button");_.className="sw",_.style.background=p,_.onclick=()=>{k.bgColor=p,Cn()},c.appendChild(_)})}s("#bgColor").oninput=c=>{k.bgColor=c.target.value,Cn()},s("#bgImgBtn").onclick=()=>s("#bgFile").click(),s("#bgFile").onchange=c=>{let p=c.target.files&&c.target.files[0];if(c.target.value="",!p)return;let _=URL.createObjectURL(p),S=new Image;S.onload=()=>{ac(S,!0),URL.revokeObjectURL(_)},S.onerror=()=>Gn("이미지를 열 수 없어요"),S.src=_},s("#bgImgClear").onclick=()=>{rn&&(rn.dispose(),rn=null);try{localStorage.removeItem("house.bgimg.v1")}catch{}Cn()},r("#bgImgOpts [data-bm]").forEach(c=>{c.onclick=()=>{k.bgMode=c.dataset.bm,Cn()}}),s("#bgTile").value=k.bgTile,s("#bgTile").oninput=c=>{k.bgTile=+c.target.value,Cn()},s("#resetCast").onclick=()=>{confirm("캐릭터를 기본 4명으로 되돌릴까요?")&&([...Q].forEach(io),Hn=Wl.map(c=>({...c})),it.set("house.cast.v1",Hn),Hn.forEach(c=>Lr({...c})),Ui(),Qs())};let Fu=new je(o()*A.getPixelRatio(),a()*A.getPixelRatio(),{type:xn}),Xn=new Za(A,Fu);Xn.addPass(new Ja(X,tt));let os=new Gs(new At(o(),a()),.45,.55,.62);Xn.addPass(os);{let c=os.blendMaterial;c.blending=Rl,c.blendEquation=ri,c.blendSrc=pr,c.blendDst=ka,c.blendSrcAlpha=Pl,c.blendDstAlpha=ka,c.needsUpdate=!0}let lo=new Li(xu);lo.uniforms.offset.value=1,lo.uniforms.darkness.value=1,Xn.addPass(lo),Xn.addPass(new ja),Xn.addPass(new Li(new Be({uniforms:di,vertexShader:"varying vec2 vUv; void main(){ vUv = uv; gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0); }",fragmentShader:`uniform sampler2D tDiffuse, tBg; uniform vec3 bgColor; uniform float hasImg, mode, tilePx, imgAspect; uniform vec2 res; varying vec2 vUv;
    void main(){
      vec4 s = texture2D(tDiffuse, vUv); vec3 bg = bgColor;
      if (hasImg > 0.5) {
        vec2 uv;
        if (mode < 0.5) { float ra = res.x / res.y; vec2 sc = ra > imgAspect ? vec2(1.0, imgAspect / ra) : vec2(ra / imgAspect, 1.0); uv = (vUv - 0.5) * sc + 0.5; }
        else { uv = vec2(vUv.x * res.x / tilePx, vUv.y * res.y / (tilePx / imgAspect)); }
        bg = texture2D(tBg, uv).rgb;
      }
      gl_FragColor = vec4(s.rgb + bg * (1.0 - clamp(s.a, 0.0, 1.0)), 1.0);
    }`})));let co=new Li(_u);Xn.addPass(co),Hn.forEach(c=>Lr({...c}));function Bu(){et.color.copy(Z.keyCol),et.intensity=Z.keyInt,et.position.copy(Z.key).normalize().multiplyScalar(50),et.target.position.set(0,0,0),rt.color.copy(Z.hSky),rt.groundColor.copy(Z.hGnd),rt.intensity=Z.hInt,Rt.color.setScalar(Z.glow),pe.color.copy(Z.win),os.strength=Z.bloom,A.toneMappingExposure=Z.expo;for(let c of vt)c.intensity=9*Z.lamp}let tr=performance.now()/1e3,Kn=0,lc=0;function zu(){let c=performance.now()/1e3;if(u||document.hidden){tr=c;return}let p=Ni[k.quality]||Ni.mid;if(p.fps<60&&c-tr<1/p.fps-.004)return;let _=Math.min(.05,c-tr);tr=c,Kn+=_,K(_),Bu();let S=Z.key.x+Z.key.y*3+Z.key.z*7+Z.keyInt*11;Math.abs(S-lc)>1e-4&&(lc=S,h=Math.max(h,1)),h>0&&(A.shadowMap.needsUpdate=!0,h--);let y=Q.some(ut=>ut.spot&&ut.spot.kind==="tv"&&ut.state==="act");Yt.color.set(y?E(5943551,16765088,(Math.sin(Kn*3)*.5+.5)*(Math.sin(Kn*1.3)*.5+.5)):1315868).multiplyScalar(y?1.2+Z.glow*.3:1);let O=Ka.geometry.attributes.position,st=we.find(ut=>ut.type==="steam"),bt=!!st&&Q.some(ut=>ut.spot&&ut.spot.steam&&ut.state==="act");Qa.forEach((ut,D)=>{ut.t+=_*(bt?.6:0),ut.t>3&&(ut.t=0),O.setXYZ(D,st?st.x+Math.sin(ut.t*2+D)*.2:0,bt?st.y+ut.t*.6:-50,st?st.z+Math.cos(ut.t+D)*.15:0)}),O.needsUpdate=!0,O=T.geometry.attributes.position,H.forEach((ut,D)=>O.setXYZ(D,ut.x+Math.sin(Kn*ut.sp+ut.ph)*.8,ut.y+Math.sin(Kn*ut.sp*1.4+ut.ph)*.4,ut.z+Math.cos(Kn*ut.sp*.7+ut.ph)*.6)),O.needsUpdate=!0;let pt=we.find(ut=>ut.type==="bubbles");O=J.geometry.attributes.position,j.forEach((ut,D)=>{ut.t=(ut.t+_*.5)%2,O.setXYZ(D,pt?pt.x+Math.sin(D*5+ut.t)*1.4+D%3*.3-.4:0,pt?pt.y-.8+ut.t*.3:-50,pt?pt.z+D%4*.25-.3:0)}),O.needsUpdate=!0,Kl(Kn,_),Ru(),An&&!An.hidden?at.target.lerp(Tn.set(An.pos.x,1.2,An.pos.z),.05):at.target.lerp(Tn.set(0,1.5,.5),.04),at.update(),Xn.render()}let ho=()=>{!o()||!a()||(A.setSize(o(),a()),Xn.setSize(o(),a()),tt.aspect=o()/a(),tt.updateProjectionMatrix(),di.res.value.set(o()*A.getPixelRatio(),a()*A.getPixelRatio()),co.material.uniforms.resolution.value.set(1/(o()*A.getPixelRatio()),1/(a()*A.getPixelRatio())),rc())},cc=new ResizeObserver(ho);cc.observe(n);let ls={addByName:Uu,placeOf:Zs,placeIsRoom:De,do:rs,chars:Q,setMode:c=>{$=c,K(0,!0),Cn()},KEYWORDS:Kt,interpret:Rr,applyStory:es,tick:(c,p=.05)=>{for(let _=0;_<c/p;_++)Kn+=p,Kl(Kn,p);return Q.map(_=>_.def.name+":"+_.state+":"+_.kind+":"+_.pos.x.toFixed(1)+","+_.pos.z.toFixed(1)).join(" ")},camera:tt,controls:at,showPanel:Di,layout:Pt,catalog:ft,rebuild:$e,move:$a,add:Qi,remove:Ar,spots:()=>Ee,three:{renderer:A,composer:Xn,scene:X,bloom:os},pause:c=>{u=!!c,tr=performance.now()/1e3}};ls.destroy=()=>{l=!1,A.setAnimationLoop(null),cc.disconnect(),clearInterval(Lu),window.removeEventListener("message",Ql);for(let c of[...Q])io(c);A.dispose(),e.innerHTML="",t.global&&window[t.global]===ls&&delete window[t.global]},ls.resize=ho,t.global&&(window[t.global]=ls),oc(),Cn();try{let c=localStorage.getItem("house.bgimg.v1");if(c){let p=new Image;p.onload=()=>ac(p,!1),p.src=c}}catch{}return A.setAnimationLoop(zu),requestAnimationFrame(()=>requestAnimationFrame(()=>{ls.ready=!0,window.__ready=!0})),ls}(function(){if(window.__pixelWorldExt)try{window.__pixelWorldExt.destroy()}catch{}let i="pixelworld.ext.v1",e=Object.assign({field:"자세,행동,posture,pose,action,activity",chatId:"",poll:!0,sec:3,autoAdd:!0,w:760,h:480},(()=>{try{return JSON.parse(localStorage.getItem(i))||{}}catch{return{}}})()),n=()=>{try{localStorage.setItem(i,JSON.stringify(e))}catch{}},s=(...w)=>{try{(window.marinara&&window.marinara.log?window.marinara.log.info:console.log)("[pixel-world]",...w)}catch{console.log("[pixel-world]",...w)}},r=document.createElement("div");r.id="pixel-world-ext",r.style.cssText=`position:fixed;right:16px;bottom:16px;width:${e.w}px;height:${e.h}px;min-width:380px;min-height:280px;max-width:98vw;max-height:96vh;z-index:2147483000;display:flex;flex-direction:column;background:#2a1d4a;border:2px solid #fff;box-shadow:0 6px 24px rgba(0,0,0,.55);resize:both;overflow:hidden;font:12px sans-serif;color:#fff;box-sizing:border-box`;let o="cursor:pointer;background:rgba(255,255,255,.12);color:#fff;border:1px solid rgba(255,255,255,.4);padding:1px 7px;font:inherit";r.innerHTML=`
    <div id="pw-head" style="display:flex;align-items:center;gap:6px;padding:4px 8px;background:#3a2a5e;cursor:move;user-select:none;flex:none">
      <b>Pixel World</b><span id="pw-dot" style="opacity:.8;flex:1;overflow:hidden;text-overflow:ellipsis;white-space:nowrap">트래커 대기 중…</span>
      <button id="pw-set" style="${o}" title="트래커 연결 설정">⚙</button>
      <button id="pw-full" style="${o}" title="크게/작게">⛶</button>
      <button id="pw-min" style="${o}" title="접기">–</button>
      <button id="pw-x" style="${o}" title="닫기">✕</button>
    </div>
    <div id="pw-cfg" style="display:none;padding:8px;background:#33244f;border-bottom:1px solid rgba(255,255,255,.25);flex:none;line-height:1.9">
      <label>읽을 트래커 필드 이름 (콤마로 여러 개) <input id="pw-field" style="width:100%;box-sizing:border-box"></label>
      <label>채팅 ID (비우면 자동) <input id="pw-chat" style="width:100%;box-sizing:border-box" placeholder="자동"></label>
      <label><input type="checkbox" id="pw-poll"> 트래커 자동으로 읽기</label> &nbsp;
      <label>주기 <input id="pw-sec" type="number" min="1" max="30" style="width:48px"> 초</label> &nbsp;
      <label><input type="checkbox" id="pw-add"> 섬에 없는 이름은 자동 추가</label>
      <div><button id="pw-now" style="${o}">지금 읽기</button></div>
    </div>
    <div id="pw-island" style="flex:1;min-height:0;position:relative"></div>
    <div id="pw-log" style="flex:none;padding:3px 8px;background:#33244f;font-size:11px;opacity:.9;max-height:54px;overflow:auto"></div>`,document.body.appendChild(r);let a=w=>r.querySelector(w),l=yu(a("#pw-island"),{global:"pixelWorld"}),h=[],u=w=>{h.unshift(`${new Date().toLocaleTimeString()} ${w}`),h.length=Math.min(h.length,4),a("#pw-log").innerHTML=h.map(A=>`<div>${A.replace(/</g,"&lt;")}</div>`).join("")},d=w=>{a("#pw-dot").textContent=w};a("#pw-head").addEventListener("mousedown",w=>{if(w.target.tagName==="BUTTON")return;let A=r.getBoundingClientRect(),X=w.clientX-A.left,tt=w.clientY-A.top;r.style.left=A.left+"px",r.style.top=A.top+"px",r.style.right="auto",r.style.bottom="auto";let at=V=>{r.style.left=Math.max(0,Math.min(innerWidth-80,V.clientX-X))+"px",r.style.top=Math.max(0,Math.min(innerHeight-30,V.clientY-tt))+"px"},F=()=>{removeEventListener("mousemove",at),removeEventListener("mouseup",F)};addEventListener("mousemove",at),addEventListener("mouseup",F)});let m=!1,x=null,v=!1;a("#pw-full").onclick=()=>{m=!m,m?(x=r.style.cssText,r.style.cssText+=";left:24px;top:24px;right:24px;bottom:24px;width:auto;height:auto;resize:none"):r.style.cssText=x,l.resize()},a("#pw-min").onclick=()=>{v=!v,l.pause(v),a("#pw-island").style.display=v?"none":"",a("#pw-log").style.display=v?"none":"",r.style.height=v?"auto":e.h+"px",r.style.minHeight=v?"0":"280px",r.style.resize=v?"none":"both"},a("#pw-set").onclick=()=>{let w=a("#pw-cfg");w.style.display=w.style.display==="none"?"block":"none"},a("#pw-x").onclick=()=>it(),a("#pw-field").value=e.field,a("#pw-chat").value=e.chatId,a("#pw-poll").checked=e.poll,a("#pw-sec").value=e.sec,a("#pw-add").checked=e.autoAdd;let M=()=>{e.field=a("#pw-field").value,e.chatId=a("#pw-chat").value.trim(),e.poll=a("#pw-poll").checked,e.sec=Math.max(1,+a("#pw-sec").value||3),e.autoAdd=a("#pw-add").checked,n(),I()};for(let w of["#pw-field","#pw-chat","#pw-poll","#pw-sec","#pw-add"])a(w).addEventListener("change",M);a("#pw-now").onclick=()=>{R.clear(),N(!0)};let g=new Set("·:：/|()[]-–—,".split("")),f=w=>w.split("").map(A=>g.has(A)?" ":A).join("").split(" ").filter(Boolean).join(" ").slice(0,16),R=new Map,E=!1,L=null;async function z(){if(e.chatId)return e.chatId;try{let at=window.marinara&&window.marinara.context&&window.marinara.context.get&&window.marinara.context.get();if(at&&at.chatId)return at.chatId}catch{}let w=location.href.match(/[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}/i);if(w)return w[0];let A=await fetch("/api/chats",{credentials:"same-origin"});if(!A.ok)throw new Error("채팅 목록 "+A.status);let X=await A.json(),tt=Array.isArray(X)?X:X.chats||X.items||[];return tt.sort((at,F)=>String(F.updatedAt||F.createdAt||"").localeCompare(String(at.updatedAt||at.createdAt||""))),tt[0]&&tt[0].id}async function N(w){if(!E){E=!0;try{let A=await z();if(!A){d("채팅을 찾지 못했어요");return}let X=await fetch("/api/chats/"+encodeURIComponent(A)+"/game-state",{credentials:"same-origin"});if(!X.ok){d("트래커 읽기 실패 ("+X.status+")");return}let tt=await X.json();if(!tt){d("트래커 데이터가 아직 없어요 (트래커 에이전트를 켜 주세요)");return}let at=e.field.split(",").map(k=>k.trim().toLowerCase()).filter(Boolean),F=[];for(let k of tt.presentCharacters||[])for(let $ of Object.keys(k.customFields||{}))F.push({owner:k.name,key:$,value:k.customFields[$]});for(let k of tt.playerStats&&tt.playerStats.customTrackerFields||[])F.push({owner:null,key:k.name,value:k.value});for(let k of tt.worldCustomFields||[])F.push({owner:null,key:k.name,value:k.value});let V=new Map;for(let k of F){let $=String(k.key||""),K=$.toLowerCase(),et=k.value==null?"":String(k.value),rt=at.find(G=>K.includes(G));if(!rt||!et)continue;let vt=k.owner;if(!vt){let G=K.indexOf(rt);vt=f($.slice(0,G)+" "+$.slice(G+rt.length))}vt&&V.set(vt,(V.get(vt)?V.get(vt)+". ":"")+et)}let Z=null;for(let k of F){let $=String(k.key||"").toLowerCase();if(($.includes("장소")||$.includes("위치")||$.includes("location"))&&k.value){let K=l.placeOf(String(k.value));if(K&&l.placeIsRoom(K)){Z=K;break}}}for(let[k,$]of V){let K=$+"|"+Z;if(R.get(k)===K)continue;if(R.set(k,K),!l.chars.some(G=>G.def.name===k))if(e.autoAdd&&l.addByName(k))u("섬에 "+k+" 추가");else{u("섬에 '"+k+"'이(가) 없어요");continue}let et=l.interpret($).filter(G=>G.action),rt=et[et.length-1],vt=rt&&(rt.place||Z);rt?(l.do(k,rt.action,rt.action==="intimate"||rt.action==="chat"?rt.who.find(G=>G!==k&&G!=="*"):void 0,vt),u(k+' ← "'+$.slice(0,30)+'" → '+rt.action+(vt?" @"+vt:"")+" ('"+rt.keyword+"')"),s("tracker",k,$,rt.action)):u(k+' ← "'+$.slice(0,30)+'" → 해당 행동 없음')}d("트래커 연결됨 · 필드 "+F.length+"개 중 행동 "+V.size+"명"),w&&!V.size&&u("'"+e.field+"' 단어가 들어간 필드가 없어요. 찾은 필드: "+F.map(k=>k.key).slice(0,12).join(", "))}catch(A){d("트래커 읽기 오류: "+A.message)}finally{E=!1}}}function I(){clearInterval(L),e.poll&&(L=setInterval(()=>{document.hidden||N(!1)},e.sec*1e3))}I(),setTimeout(()=>N(!0),1500);function it(){clearInterval(L);try{l.destroy()}catch{}r.remove(),delete window.__pixelWorldExt}window.__pixelWorldExt={destroy:it,app:l,readTracker:N},window.marinara&&window.marinara.onCleanup&&window.marinara.onCleanup(it)})();})();
